<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ja">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../gui/aboutdialog.ui" line="15"/>
        <source>About qBittorrent</source>
        <translation>qBittorrent について</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="52"/>
        <source>About</source>
        <translation>qBittorrent について</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="81"/>
        <source>Author</source>
        <translation>作者</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="87"/>
        <source>Current maintainer</source>
        <translation>現在のメンテナー</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="93"/>
        <source>Greece</source>
        <translation>ギリシャ</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="113"/>
        <location filename="../gui/aboutdialog.ui" line="204"/>
        <source>Nationality:</source>
        <translation>国籍:</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="120"/>
        <location filename="../gui/aboutdialog.ui" line="197"/>
        <source>E-mail:</source>
        <translation>E メール:</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="127"/>
        <location filename="../gui/aboutdialog.ui" line="190"/>
        <source>Name:</source>
        <translation>氏名:</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="157"/>
        <source>Original author</source>
        <translation>オリジナルの作者</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="163"/>
        <source>France</source>
        <translation>フランス</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="241"/>
        <source>Special Thanks</source>
        <translation>謝辞</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="267"/>
        <source>Translators</source>
        <translation>翻訳</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="293"/>
        <source>License</source>
        <translation>ライセンス</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="319"/>
        <source>Libraries</source>
        <translation>ライブラリ</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="325"/>
        <source>qBittorrent was built with the following libraries:</source>
        <translation>qBittorrent は以下のライブラリを使用してビルドされています:</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.h" line="70"/>
        <source>An advanced BitTorrent client programmed in C++, based on Qt toolkit and libtorrent-rasterbar.</source>
        <translation>Qt ツールキットと libtorrent-rasterbar を使用して C++ で書かれた高度な BitTorrent クライアントです。</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.h" line="71"/>
        <source>Copyright %1 2006-2018 The qBittorrent project</source>
        <translation>Copyright %1 2006-2018 The qBittorrent project</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.h" line="72"/>
        <source>Home Page:</source>
        <translation>ホームページ:</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.h" line="73"/>
        <source>Forum:</source>
        <translation>フォーラム:</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.h" line="74"/>
        <source>Bug Tracker:</source>
        <translation>バグトラッカー:</translation>
    </message>
</context>
<context>
    <name>AddNewTorrentDialog</name>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="58"/>
        <source>Save at</source>
        <translation>保存先</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="87"/>
        <source>Never show again</source>
        <translation>次回から表示しない</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="104"/>
        <source>Torrent settings</source>
        <translation>Torrent 設定</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="110"/>
        <source>Set as default category</source>
        <translation>デフォルトのカテゴリにする</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="119"/>
        <source>Category:</source>
        <translation>カテゴリ:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="144"/>
        <source>Start torrent</source>
        <translation>Torrent を開始する</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="204"/>
        <source>Torrent information</source>
        <translation>Torrent 情報</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="154"/>
        <source>Skip hash check</source>
        <translation>ハッシュチェックを省略する</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="257"/>
        <source>Size:</source>
        <translation>サイズ:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="223"/>
        <source>Hash:</source>
        <translation>ハッシュ:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="271"/>
        <source>Comment:</source>
        <translation>コメント:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="250"/>
        <source>Date:</source>
        <translation>作成日時:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="19"/>
        <source>Torrent Management Mode:</source>
        <translation>Torrent 管理モード:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="26"/>
        <source>Automatic mode means that various torrent properties(eg save path) will be decided by the associated category</source>
        <translation>自動モードでは Torrent の様々なプロパティ (保存先など) が割り当てられたカテゴリから自動決定されます</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="30"/>
        <source>Manual</source>
        <translation>手動</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="35"/>
        <source>Automatic</source>
        <translation>自動</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="67"/>
        <source>Remember last used save path</source>
        <translation>最後に使用した保存先</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="77"/>
        <source>When checked, the .torrent file will not be deleted despite the settings at the &quot;Download&quot; page of the options dialog</source>
        <translation>チェックマークをつけると、Torrent ファイルはオプションダイアログの &quot;ダウンロード&quot; ページの設定にかかわらず削除されません</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="80"/>
        <source>Do not delete .torrent file</source>
        <translation>.torrent ファイルを削除しない</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="177"/>
        <source>Create subfolder</source>
        <translation>サブフォルダーを作成</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="187"/>
        <source>Download in sequential order</source>
        <translation>シーケンシャルのダウンロードする</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="194"/>
        <source>Download first and last pieces first</source>
        <translation>最初と最後のピースを先にダウンロード</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="376"/>
        <source>Normal</source>
        <translation>通常</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="381"/>
        <source>High</source>
        <translation>高い</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="386"/>
        <source>Maximum</source>
        <translation>最高</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="391"/>
        <source>Do not download</source>
        <translation>ダウンロードしない</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="276"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="282"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="707"/>
        <source>I/O Error</source>
        <translation>I/O エラー</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="290"/>
        <source>Invalid torrent</source>
        <translation>無効な Torrent</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="494"/>
        <source>Renaming</source>
        <translation>名前の変更</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="499"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="523"/>
        <source>Rename error</source>
        <translation>変名エラー</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="500"/>
        <source>The name is empty or contains forbidden characters, please choose a different one.</source>
        <translation>名前が入力されていないか使用できない文字が含まれています。ほかの名前を入力してください。</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="733"/>
        <source>Not Available</source>
        <comment>This comment is unavailable</comment>
        <translation>利用できません</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="734"/>
        <source>Not Available</source>
        <comment>This date is unavailable</comment>
        <translation>利用できません</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="742"/>
        <source>Not available</source>
        <translation>不明</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="326"/>
        <source>Invalid magnet link</source>
        <translation>無効なマグネットリンク</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="276"/>
        <source>The torrent file &apos;%1&apos; does not exist.</source>
        <translation>Torrent ファイル &apos;%1&apos; が存在しません。</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="282"/>
        <source>The torrent file &apos;%1&apos; cannot be read from the disk. Probably you don&apos;t have enough permissions.</source>
        <translation>Torrent ファイル &apos;%1&apos; をディスクから読み込めません。おそらくアクセス権がありません。</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="290"/>
        <source>Failed to load the torrent: %1.
Error: %2</source>
        <comment>Don&apos;t remove the &apos;
&apos; characters. They insert a newline.</comment>
        <translation>Torrent の読み込みに失敗: %1.
エラー: %2</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="326"/>
        <source>This magnet link was not recognized</source>
        <translation>このマグネットリンクは認識されませんでした</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="355"/>
        <source>Magnet link</source>
        <translation>マグネットリンク</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="361"/>
        <source>Retrieving metadata...</source>
        <translation>メタデータを回収しています...</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="445"/>
        <source>Not Available</source>
        <comment>This size is unavailable.</comment>
        <translation>利用できません</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="447"/>
        <source>Free space on disk: %1</source>
        <translation>ディスクの空き容量: %1</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="102"/>
        <source>Choose save path</source>
        <translation>保存先の選択</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="303"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="308"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="312"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="337"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="342"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="346"/>
        <source>Torrent is already present</source>
        <translation>Torrent はすでに存在します</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="303"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="337"/>
        <source>Torrent &apos;%1&apos; is already in the transfer list. Trackers haven&apos;t been merged because it is a private torrent.</source>
        <translation>Torrent &apos;%1&apos; はすでに転送リストにあります。プライベート Torrent のためトラッカーはマージされません。</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="308"/>
        <source>Torrent &apos;%1&apos; is already in the transfer list. Trackers have been merged.</source>
        <translation>Torrent &apos;%1&apos; はすでに転送リストにあります。トラッカーはマージされます。</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="312"/>
        <source>Torrent is already queued for processing.</source>
        <translation>Torrent はすでに処理待ち状態です。</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="342"/>
        <source>Magnet link &apos;%1&apos; is already in the transfer list. Trackers have been merged.</source>
        <translation>マグネットリンク &apos;%1&apos; はすでに転送リストにあります。トラッカーはマージされます。</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="346"/>
        <source>Magnet link is already queued for processing.</source>
        <translation>マグネットリンクはすでに処理待ち状態です。</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="494"/>
        <source>New name:</source>
        <translation>新しい名前:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="524"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="562"/>
        <source>This name is already in use in this folder. Please use a different name.</source>
        <translation>同じ名前のファイルがこのフォルダー内に存在します。別の名前を指定してください。</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="561"/>
        <source>The folder could not be renamed</source>
        <translation>フォルダー名を変更できませんでした</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="609"/>
        <source>Rename...</source>
        <translation>名前の変更...</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="613"/>
        <source>Priority</source>
        <translation>優先度</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="708"/>
        <source>Invalid metadata</source>
        <translation>不正なメタデータ</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="715"/>
        <source>Parsing metadata...</source>
        <translation>メタデータを解析しています...</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="719"/>
        <source>Metadata retrieval complete</source>
        <translation>メタデータの回収が完了しました</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="774"/>
        <source>Download Error</source>
        <translation>ダウンロードエラー</translation>
    </message>
</context>
<context>
    <name>AdvancedSettings</name>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="258"/>
        <location filename="../gui/advancedsettings.cpp" line="336"/>
        <source> MiB</source>
        <translation> MiB</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="398"/>
        <source>Outgoing ports (Min) [0: Disabled]</source>
        <translation>送出側ポート (最小) [0: 無効]</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="403"/>
        <source>Outgoing ports (Max) [0: Disabled]</source>
        <translation>送出側ポート (最大) [0: 無効]</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="413"/>
        <source>Recheck torrents on completion</source>
        <translation>Torrent 完了時に再チェックする</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="419"/>
        <source>Transfer list refresh interval</source>
        <translation>転送リストのリフレッシュ間隔</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="418"/>
        <source> ms</source>
        <comment> milliseconds</comment>
        <translation> ms</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="126"/>
        <source>Setting</source>
        <translation>設定</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="126"/>
        <source>Value</source>
        <comment>Value set for this setting</comment>
        <translation>値</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="254"/>
        <location filename="../gui/advancedsettings.cpp" line="266"/>
        <source> (disabled)</source>
        <translation> (無効)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="256"/>
        <source> (auto)</source>
        <translation> (自動)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="264"/>
        <source> min</source>
        <comment> minutes</comment>
        <translation> 分</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="277"/>
        <source>All addresses</source>
        <translation>全アドレス</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="314"/>
        <source>qBittorrent Section</source>
        <translation>qBittorrent セクション</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="317"/>
        <location filename="../gui/advancedsettings.cpp" line="322"/>
        <source>Open documentation</source>
        <translation>ドキュメントを開く</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="320"/>
        <source>libtorrent Section</source>
        <translation>libtorrent セクション</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="330"/>
        <source>Asynchronous I/O threads</source>
        <translation>非同期 I/O スレッド数</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="337"/>
        <source>Outstanding memory when checking torrents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="351"/>
        <source>Disk cache</source>
        <translation>ディスクキャッシュ</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="356"/>
        <source> s</source>
        <comment> seconds</comment>
        <translation> s</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="357"/>
        <source>Disk cache expiry interval</source>
        <translation>ディスクキャッシュ有効期限</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="360"/>
        <source>Enable OS cache</source>
        <translation>OS のキャッシュを有効にする</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="363"/>
        <source>Guided read cache</source>
        <translation>誘導読み込みキャッシュ</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="367"/>
        <source>Coalesce reads &amp; writes</source>
        <translation>コアレス読み込み &amp; 書き込みを有効にする</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="371"/>
        <source>Send upload piece suggestions</source>
        <translation>アップロードピースサジェッションを送信する</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="375"/>
        <location filename="../gui/advancedsettings.cpp" line="380"/>
        <source> KiB</source>
        <translation> KiB</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="377"/>
        <source>Send buffer watermark</source>
        <translation>バッファーのウォーターマークを送信する</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="382"/>
        <source>Send buffer low watermark</source>
        <translation>バッファーの最低ウォーターマークを送信する</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="387"/>
        <source>Send buffer watermark factor</source>
        <translation>バッファーのウォーターマークファクターを送信する</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="405"/>
        <source>Prefer TCP</source>
        <translation>TCP 優先</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="405"/>
        <source>Peer proportional (throttles TCP)</source>
        <translation>ピア比例 (TCP を調整)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="410"/>
        <source>Allow multiple connections from the same IP address</source>
        <translation>同一 IP アドレスからの複数接続を許可する</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="422"/>
        <source>Resolve peer countries (GeoIP)</source>
        <translation>ピアの国籍を解決する (GeoIP)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="425"/>
        <source>Resolve peer host names</source>
        <translation>ピアのホスト名を解決する</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="433"/>
        <source>Strict super seeding</source>
        <translation>厳密なスーパーシード</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="458"/>
        <source>Network Interface (requires restart)</source>
        <translation>ネットワークインターフェース (再起動が必要)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="461"/>
        <source>Optional IP Address to bind to (requires restart)</source>
        <translation>バインドする IP アドレス (再起動が必要)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="464"/>
        <source>Listen on IPv6 address (requires restart)</source>
        <translation>IPV6 アドレスを待ち受ける (再起動が必要)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="472"/>
        <source>Display notifications</source>
        <translation>通知を行う</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="475"/>
        <source>Display notifications for added torrents</source>
        <translation>Torrent が追加されたときに通知する</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="478"/>
        <source>Download tracker&apos;s favicon</source>
        <translation>トラッカーのファビコンをダウンロードする</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="482"/>
        <source>Save path history length</source>
        <translation>保存パス履歴の長さ</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="485"/>
        <source>Enable speed graphs</source>
        <translation>速度グラフを有効にする</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="495"/>
        <source>Fixed slots</source>
        <translation>スロット数固定</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="495"/>
        <source>Upload rate based</source>
        <translation>アップロード速度ベース</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="497"/>
        <source>Upload slots behavior</source>
        <translation>アップロードスロットの挙動</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="499"/>
        <source>Round-robin</source>
        <translation>ラウンドロビン</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="499"/>
        <source>Fastest upload</source>
        <translation>最速アップロード</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="499"/>
        <source>Anti-leech</source>
        <translation>アンチリーチ</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="501"/>
        <source>Upload choking algorithm</source>
        <translation>アップロードチョークアルゴリズム</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="513"/>
        <source>Confirm torrent recheck</source>
        <translation>Torrent の再チェック時に確認する</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="517"/>
        <source>Confirm removal of all tags</source>
        <translation>すべてのタグを削除するとき確認する</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="521"/>
        <source>Always announce to all trackers in a tier</source>
        <translation>常にティア内の全トラッカーにアナウンスする</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="525"/>
        <source>Always announce to all tiers</source>
        <translation>常に全ティアにアナウンスする</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="435"/>
        <source>Any interface</source>
        <comment>i.e. Any network interface</comment>
        <translation>どれか</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="393"/>
        <source>Save resume data interval</source>
        <comment>How often the fastresume file is saved.</comment>
        <translation>再開データ保存間隔</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="407"/>
        <source>%1-TCP mixed mode algorithm</source>
        <comment>uTP-TCP mixed mode algorithm</comment>
        <translation>%1-TCP 混在モードアルゴリズム</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="430"/>
        <source>Maximum number of half-open connections [0: Unlimited]</source>
        <translation>最大半開接続数 [0 無制限]</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="467"/>
        <source>IP Address to report to trackers (requires restart)</source>
        <translation>トラッカーに報告する IP アドレス (再起動が必要)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="488"/>
        <source>Enable embedded tracker</source>
        <translation>埋め込みトラッカーを有効にする</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="493"/>
        <source>Embedded tracker port</source>
        <translation>埋め込みトラッカーポート</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="505"/>
        <source>Check for software updates</source>
        <translation>ソフトウェアアップデートをチェックする</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="509"/>
        <source>Use system icon theme</source>
        <translation>システムのアイコンテーマを使用する</translation>
    </message>
</context>
<context>
    <name>Application</name>
    <message>
        <location filename="../app/application.cpp" line="160"/>
        <source>qBittorrent %1 started</source>
        <comment>qBittorrent v3.2.0alpha started</comment>
        <translation>qBittorrent %1 を起動しました</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="311"/>
        <source>Torrent: %1, running external program, command: %2</source>
        <translation>Torrent: %1, 外部プログラムを実行しています。コマンド: %2</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="338"/>
        <source>Torrent name: %1</source>
        <translation>Torrent 名: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="339"/>
        <source>Torrent size: %1</source>
        <translation>Torrent サイズ: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="340"/>
        <source>Save path: %1</source>
        <translation>保存パス: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="341"/>
        <source>The torrent was downloaded in %1.</source>
        <comment>The torrent was downloaded in 1 hour and 20 seconds</comment>
        <translation>Torrent は %1 にダウンロードされました。</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="343"/>
        <source>Thank you for using qBittorrent.</source>
        <translation>qBittorrent をご利用いただきありがとうございます。</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="350"/>
        <source>[qBittorrent] &apos;%1&apos; has finished downloading</source>
        <translation>[qBittorrent] &apos;%1&apos; のダウンロードが完了しました</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="364"/>
        <source>Torrent: %1, sending mail notification</source>
        <translation>Torrent: %1, 通知メールを送信しています</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="528"/>
        <source>Application failed to start.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="541"/>
        <source>Information</source>
        <translation>情報</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="542"/>
        <source>To control qBittorrent, access the Web UI at %1</source>
        <translation>qBittorrent を操作するには、%1 から WebUI にアクセスしてください</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="547"/>
        <source>The Web UI administrator username is: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="548"/>
        <source>The Web UI administrator password is still the default one: %1</source>
        <translation>Web UI 管理者パスワードはまだデフォルトのままです: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="549"/>
        <source>This is a security risk, please consider changing your password from program preferences.</source>
        <translation>これはセキュリティリスクになります。プログラム設定からパスワードを変更してください。</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="712"/>
        <source>Saving torrent progress...</source>
        <translation>Torrent の進行状況を保存しています...</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="770"/>
        <source>Portable mode and explicit profile directory options are mutually exclusive</source>
        <translation>ポータブルモードとプロファイルディレクトリの直接指定は排他関係になります</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="773"/>
        <source>Portable mode implies relative fastresume</source>
        <translation>ポータブルモードは相対的に高速再開になります</translation>
    </message>
</context>
<context>
    <name>AsyncFileStorage</name>
    <message>
        <location filename="../base/asyncfilestorage.cpp" line="41"/>
        <source>Could not create directory &apos;%1&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AuthController</name>
    <message>
        <location filename="../webui/api/authcontroller.cpp" line="52"/>
        <source>WebAPI login failure. Reason: IP has been banned, IP: %1, username: %2</source>
        <translation>WebAPI ログインに失敗しました。理由: IP アドレスは BAN されています。IP: %1, ユーザー名: %2</translation>
    </message>
    <message>
        <location filename="../webui/api/authcontroller.cpp" line="56"/>
        <source>Your IP address has been banned after too many failed authentication attempts.</source>
        <translation>多数の認証失敗により、あなたの IP アドレスは BAN (アクセス禁止) されました。</translation>
    </message>
    <message>
        <location filename="../webui/api/authcontroller.cpp" line="71"/>
        <source>WebAPI login success. IP: %1</source>
        <translation>WebAPI ログインに成功しました。 IP: %1</translation>
    </message>
    <message>
        <location filename="../webui/api/authcontroller.cpp" line="76"/>
        <source>WebAPI login failure. Reason: invalid credentials, attempt count: %1, IP: %2, username: %3</source>
        <translation>WebAPI ログインに失敗しました。理由: 不正な認証, 試行回数: %1, IP: %2, ユーザー名: %3</translation>
    </message>
</context>
<context>
    <name>AutomatedRssDownloader</name>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="240"/>
        <source>Save to:</source>
        <translation>保存先:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="14"/>
        <source>RSS Downloader</source>
        <translation>RSS ダウンローダー</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="28"/>
        <source>Auto downloading of RSS torrents is disabled now! You can enable it in application settings.</source>
        <translation>RSS Torrent の自動ダウンロードは現在無効になっています。アプリケーションの設定で有効にできます。</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="59"/>
        <source>Download Rules</source>
        <translation>ダウンロードルール</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="99"/>
        <source>Rule Definition</source>
        <translation>ルール定義</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="105"/>
        <source>Use Regular Expressions</source>
        <translation>正規表現を使用する</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="186"/>
        <source>Smart Episode Filter will check the episode number to prevent downloading of duplicates.
Supports the formats: S01E01, 1x1, 2017.01.01 and 01.01.2017 (Date formats also support - as a separator)</source>
        <translation>スマートエピソードフィルターは重複した回のダウンロードを回避します。
サポートする形式: S01E01, 1x1, 2017.01.01 and 01.01.2017 (- を区切り文字とした日付形式もサポート)</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="190"/>
        <source>Use Smart Episode Filter</source>
        <translation>スマートエピソードフィルターを使用する</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="114"/>
        <source>Must Contain:</source>
        <translation>マッチする文字列:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="121"/>
        <source>Must Not Contain:</source>
        <translation>除外する文字列:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="128"/>
        <source>Episode Filter:</source>
        <translation>エピソードフィルター:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="212"/>
        <source>Assign Category:</source>
        <translation>カテゴリの割り当て:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="228"/>
        <source>Save to a Different Directory</source>
        <translation>別のディレクトリへ保存する</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="268"/>
        <source>Ignore Subsequent Matches for (0 to Disable)</source>
        <comment>... X days</comment>
        <translation>以後の一致は無視する (0 で無効)</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="278"/>
        <source>Disabled</source>
        <translation>無効</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="281"/>
        <source> days</source>
        <translation> 日</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="314"/>
        <source>Add Paused:</source>
        <translation>追加時に開始:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="322"/>
        <source>Use global settings</source>
        <translation>全体設定を利用</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="327"/>
        <source>Always</source>
        <translation>常に開始</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="332"/>
        <source>Never</source>
        <translation>開始しない</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="353"/>
        <source>Apply Rule to Feeds:</source>
        <translation>フィードに適用するルール:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="375"/>
        <source>Matching RSS Articles</source>
        <translation>マッチする RSS 記事</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="403"/>
        <source>&amp;Import...</source>
        <translation>&amp;インポート...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="413"/>
        <source>&amp;Export...</source>
        <translation>&amp;エクスポート...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="87"/>
        <source>Matches articles based on episode filter.</source>
        <translation>エピソードフィルイターで記事をマッチします。</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="87"/>
        <source>Example: </source>
        <translation>例: </translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="88"/>
        <source> will match 2, 5, 8 through 15, 30 and onward episodes of season one</source>
        <comment>example X will match</comment>
        <translation> シーズン 1 の第 2 話、5 話、8 話～15 話、30 話以降にマッチします</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="89"/>
        <source>Episode filter rules: </source>
        <translation>エピソードフィルターのルール: </translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="89"/>
        <source>Season number is a mandatory non-zero value</source>
        <translation>シーズン番号は 0 以外でなければなりません</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="91"/>
        <source>Filter must end with semicolon</source>
        <translation>フィルターはセミコロンで終了しなければなりません</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="92"/>
        <source>Three range types for episodes are supported: </source>
        <translation>3 種類の範囲指定をサポートしています: </translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="93"/>
        <source>Single number: &lt;b&gt;1x25;&lt;/b&gt; matches episode 25 of season one</source>
        <translation>単一番号: &lt;b&gt;1x25;&lt;/b&gt; はシーズン 1 の第 25 話にマッチします</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="94"/>
        <source>Normal range: &lt;b&gt;1x25-40;&lt;/b&gt; matches episodes 25 through 40 of season one</source>
        <translation>通常の範囲指定: &lt;b&gt;1x25-40;&lt;/b&gt; はシーズン 1 の第 25 話から 40 話にマッチします</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="90"/>
        <source>Episode number is a mandatory positive value</source>
        <translation>第何話かは正数でなければなりません</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="63"/>
        <source>Rules</source>
        <translation>ルール</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="64"/>
        <source>Rules (legacy)</source>
        <translation>ルール (レガシー)</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="95"/>
        <source>Infinite range: &lt;b&gt;1x25-;&lt;/b&gt; matches episodes 25 and upward of season one, and all episodes of later seasons</source>
        <translation>範囲の未指定: &lt;b&gt;1x25-;&lt;/b&gt; は一シーズンの第25話以降と、それ以降の前シーズンにマッチします</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="277"/>
        <source>Last Match: %1 days ago</source>
        <translation>最後のマッチ: %1 日前</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="279"/>
        <source>Last Match: Unknown</source>
        <translation>最後のマッチ: 不明</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="362"/>
        <source>New rule name</source>
        <translation>新しいルール名</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="362"/>
        <source>Please type the name of the new download rule.</source>
        <translation>新しいダウンロードルールの名前を入力してください。</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="367"/>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="519"/>
        <source>Rule name conflict</source>
        <translation>ルール名の衝突</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="368"/>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="520"/>
        <source>A rule with this name already exists, please choose another name.</source>
        <translation>この名前のルールはすでに存在しています。別の名前を選んでください。</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="382"/>
        <source>Are you sure you want to remove the download rule named &apos;%1&apos;?</source>
        <translation>ダウンロードルール &apos;%1&apos; を削除してよろしいですか?</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="384"/>
        <source>Are you sure you want to remove the selected download rules?</source>
        <translation>選択したダウンロードルールを削除してよろしいですか?</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="385"/>
        <source>Rule deletion confirmation</source>
        <translation>ルールの削除の確認</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="394"/>
        <source>Destination directory</source>
        <translation>保存先ディレクトリ</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="402"/>
        <source>Invalid action</source>
        <translation>不正なアクション</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="403"/>
        <source>The list is empty, there is nothing to export.</source>
        <translation>リストが空です。エクスポートされるものはありません。</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="409"/>
        <source>Export RSS rules</source>
        <translation>RSS ルールのエクスポート</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="432"/>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="449"/>
        <source>I/O Error</source>
        <translation>I/O エラー</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="433"/>
        <source>Failed to create the destination file. Reason: %1</source>
        <translation>出力ファイルの作成に失敗しました。理由: %1</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="441"/>
        <source>Import RSS rules</source>
        <translation>RSS ルールのインポート</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="450"/>
        <source>Failed to open the file. Reason: %1</source>
        <translation>ファイルのオープンに失敗しました。理由: %1</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="465"/>
        <source>Import Error</source>
        <translation>インポートエラー</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="466"/>
        <source>Failed to import the selected rules file. Reason: %1</source>
        <translation>選択したルールファイルのインポートに失敗しました。理由: %1</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="473"/>
        <source>Add new rule...</source>
        <translation>新しいルールの追加...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="481"/>
        <source>Delete rule</source>
        <translation>ルールの削除</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="483"/>
        <source>Rename rule...</source>
        <translation>ルール名の変更...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="486"/>
        <source>Delete selected rules</source>
        <translation>選択したルールの削除</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="489"/>
        <source>Clear downloaded episodes...</source>
        <translation>ダウンロードした回をクリア...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="513"/>
        <source>Rule renaming</source>
        <translation>ルール名の変更</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="513"/>
        <source>Please type the new rule name</source>
        <translation>新しいルール名を入力してください</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="539"/>
        <source>Clear downloaded episodes</source>
        <translation>ダウンロードした回をクリア</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="540"/>
        <source>Are you sure you want to clear the list of downloaded episodes for the selected rule?</source>
        <translation>選択したルールのダウンロード済み回のリストをクリアしますか?</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="644"/>
        <source>Regex mode: use Perl-compatible regular expressions</source>
        <translation>正規表現モード: Perl 互換の正規表現を試用します</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="686"/>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="724"/>
        <source>Position %1: %2</source>
        <translation>位置 %1: %2</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="647"/>
        <source>Wildcard mode: you can use</source>
        <translation>ワイルドカードモード: 以下の文字が使えます</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="648"/>
        <source>? to match any single character</source>
        <translation>? は任意の一文字にマッチします</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="649"/>
        <source>* to match zero or more of any characters</source>
        <translation>* は任意の0文字以上の文字列にマッチします</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="650"/>
        <source>Whitespaces count as AND operators (all words, any order)</source>
        <translation>空白は AND 演算子とみなされます (単語の順序は任意)</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="651"/>
        <source>| is used as OR operator</source>
        <translation>| は OR 演算子として使用します</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="652"/>
        <source>If word order is important use * instead of whitespace.</source>
        <translation>単語の順序が重要ならば空白でなく * を使用してください。</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="659"/>
        <source>An expression with an empty %1 clause (e.g. %2)</source>
        <comment>We talk about regex/wildcards in the RSS filters section here. So a valid sentence would be: An expression with an empty | clause (e.g. expr|)</comment>
        <translation>空の %1 節のときの表現 (例: %2)</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="663"/>
        <source> will match all articles.</source>
        <translation> 全記事にマッチします。</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="664"/>
        <source> will exclude all articles.</source>
        <translation> 全記事にマッチしません。</translation>
    </message>
</context>
<context>
    <name>BanListOptionsDialog</name>
    <message>
        <location filename="../gui/banlistoptionsdialog.ui" line="14"/>
        <source>List of banned IP addresses</source>
        <translation>BAN した IP アドレスのリスト</translation>
    </message>
    <message>
        <location filename="../gui/banlistoptionsdialog.ui" line="77"/>
        <source>Ban IP</source>
        <translation>BAN した IP</translation>
    </message>
    <message>
        <location filename="../gui/banlistoptionsdialog.ui" line="84"/>
        <source>Delete</source>
        <translation>削除</translation>
    </message>
    <message>
        <location filename="../gui/banlistoptionsdialog.cpp" line="87"/>
        <location filename="../gui/banlistoptionsdialog.cpp" line="97"/>
        <source>Warning</source>
        <translation>警告</translation>
    </message>
    <message>
        <location filename="../gui/banlistoptionsdialog.cpp" line="87"/>
        <source>The entered IP address is invalid.</source>
        <translation>入力された IP アドレスは正しくありません。</translation>
    </message>
    <message>
        <location filename="../gui/banlistoptionsdialog.cpp" line="97"/>
        <source>The entered IP is already banned.</source>
        <translation>入力した IP アドレスはすでに BAN されています。</translation>
    </message>
</context>
<context>
    <name>BitTorrent::Session</name>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="603"/>
        <source>Restart is required to toggle PeX support</source>
        <translation>PeX サポートを切り換えるには再起動が必要です</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1252"/>
        <source>Could not get GUID of configured network interface. Binding to IP %1</source>
        <translation>IP %1 にバインドされたネットワークインターフェースに設定された GUID を取得できませんでした</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1754"/>
        <source>Embedded Tracker [ON]</source>
        <translation>埋め込みトラッカー [ON]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1756"/>
        <source>Failed to start the embedded tracker!</source>
        <translation>埋め込みトラッカーの起動に失敗しました!</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1759"/>
        <source>Embedded Tracker [OFF]</source>
        <translation>埋め込みトラッカー [OFF]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2472"/>
        <source>System network status changed to %1</source>
        <comment>e.g: System network status changed to ONLINE</comment>
        <translation>システムのネットワーク状態を %1 に変更しました</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2472"/>
        <source>ONLINE</source>
        <translation>オンライン</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2472"/>
        <source>OFFLINE</source>
        <translation>オフライン</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2494"/>
        <source>Network configuration of %1 has changed, refreshing session binding</source>
        <comment>e.g: Network configuration of tun0 has changed, refreshing session binding</comment>
        <translation>%1 のネットワーク構成が変更されました。セッションバインディングをリフレッシュします</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2511"/>
        <source>Configured network interface address %1 isn&apos;t valid.</source>
        <comment>Configured network interface address 124.5.1568.1 isn&apos;t valid.</comment>
        <translation>設定されたネットワークインターフェースアドレス %1 は正しくありません。</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="489"/>
        <location filename="../base/bittorrent/session.cpp" line="2858"/>
        <source>Encryption support [%1]</source>
        <translation>暗号化サポート [%1]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="490"/>
        <location filename="../base/bittorrent/session.cpp" line="2859"/>
        <source>FORCED</source>
        <translation>強制</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2983"/>
        <source>%1 is not a valid IP address and was rejected while applying the list of banned addresses.</source>
        <translation>%1 は不正な IP アドレスのため BAN アドレスリストの適用中に削除されました。</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="488"/>
        <location filename="../base/bittorrent/session.cpp" line="3250"/>
        <source>Anonymous mode [%1]</source>
        <translation>匿名モード [%1]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3742"/>
        <source>Unable to decode &apos;%1&apos; torrent file.</source>
        <translation>Torrent ファイル &apos;%1&apos; をデコードできません。</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3880"/>
        <source>Recursive download of file &apos;%1&apos; embedded in torrent &apos;%2&apos;</source>
        <comment>Recursive download of &apos;test.torrent&apos; embedded in torrent &apos;test2&apos;</comment>
        <translation>Torrent &apos;%2&apos; に埋め込まれたファイル &apos;%1&apos; の再帰ダウンロード</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3986"/>
        <source>Queue positions were corrected in %1 resume files</source>
        <translation>再開ファイル %1 内のキューの位置を直しました</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4242"/>
        <source>Couldn&apos;t save &apos;%1.torrent&apos;</source>
        <translation>&apos;%1.torrent&apos; を保存できませんでした</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4289"/>
        <source>&apos;%1&apos; was removed from the transfer list.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>&apos;%1&apos; が転送リストから削除されました。</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4302"/>
        <source>&apos;%1&apos; was removed from the transfer list and hard disk.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>&apos;%1&apos; が転送リストおよびストレージから削除されました。</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4314"/>
        <source>&apos;%1&apos; was removed from the transfer list but the files couldn&apos;t be deleted. Error: %2</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>&apos;%1&apos; が転送リストから削除されましたがファイルは削除されませんでした。エラー: %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4379"/>
        <source>because %1 is disabled.</source>
        <comment>this peer was blocked because uTP is disabled.</comment>
        <translation>%1 が無効になっています。</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4382"/>
        <source>because %1 is disabled.</source>
        <comment>this peer was blocked because TCP is disabled.</comment>
        <translation>%1 が無効になっています。</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4400"/>
        <source>URL seed lookup failed for URL: &apos;%1&apos;, message: %2</source>
        <translation>URL シードのルックアップに失敗しました ― URL: &apos;%1&apos;, メッセージ: %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4448"/>
        <source>qBittorrent failed listening on interface %1 port: %2/%3. Reason: %4.</source>
        <comment>e.g: qBittorrent failed listening on interface 192.168.0.1 port: TCP/6881. Reason: already in use.</comment>
        <translation>qBittorrent はインターフェース %1 ポート %2/%3 での待ち受けに失敗しました。 理由: %4.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2100"/>
        <source>Downloading &apos;%1&apos;, please wait...</source>
        <comment>e.g: Downloading &apos;xxx.torrent&apos;, please wait...</comment>
        <translation>&apos;%1&apos; をダウンロードしています。お待ちください...</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1216"/>
        <location filename="../base/bittorrent/session.cpp" line="2588"/>
        <source>qBittorrent is trying to listen on any interface port: %1</source>
        <comment>e.g: qBittorrent is trying to listen on any interface port: TCP/6881</comment>
        <translation>qBittorrent はいずれかのインターフェースでの待ち受けを試みています。ポート: %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2530"/>
        <source>The network interface defined is invalid: %1</source>
        <translation>定義されたネットワークインターフェースは無効です: %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1229"/>
        <location filename="../base/bittorrent/session.cpp" line="2599"/>
        <source>qBittorrent is trying to listen on interface %1 port: %2</source>
        <comment>e.g: qBittorrent is trying to listen on interface 192.168.0.1 port: TCP/6881</comment>
        <translation>qBittorrent はインターフェース %1 ポート %2 での待ち受けを試みています</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="483"/>
        <source>Peer ID: </source>
        <translation>ピア ID: </translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="484"/>
        <source>HTTP User-Agent is &apos;%1&apos;</source>
        <translation>HTTP User-Agent は &apos;%1&apos;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="485"/>
        <location filename="../base/bittorrent/session.cpp" line="574"/>
        <source>DHT support [%1]</source>
        <translation>DHT サポート [%1]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="485"/>
        <location filename="../base/bittorrent/session.cpp" line="486"/>
        <location filename="../base/bittorrent/session.cpp" line="487"/>
        <location filename="../base/bittorrent/session.cpp" line="488"/>
        <location filename="../base/bittorrent/session.cpp" line="490"/>
        <location filename="../base/bittorrent/session.cpp" line="574"/>
        <location filename="../base/bittorrent/session.cpp" line="589"/>
        <location filename="../base/bittorrent/session.cpp" line="2859"/>
        <location filename="../base/bittorrent/session.cpp" line="3250"/>
        <source>ON</source>
        <translation>ON</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="485"/>
        <location filename="../base/bittorrent/session.cpp" line="486"/>
        <location filename="../base/bittorrent/session.cpp" line="487"/>
        <location filename="../base/bittorrent/session.cpp" line="488"/>
        <location filename="../base/bittorrent/session.cpp" line="490"/>
        <location filename="../base/bittorrent/session.cpp" line="574"/>
        <location filename="../base/bittorrent/session.cpp" line="589"/>
        <location filename="../base/bittorrent/session.cpp" line="2859"/>
        <location filename="../base/bittorrent/session.cpp" line="3250"/>
        <source>OFF</source>
        <translation>OFF</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="486"/>
        <location filename="../base/bittorrent/session.cpp" line="589"/>
        <source>Local Peer Discovery support [%1]</source>
        <translation>ローカルピア検出 (LSD) サポート [%1]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="487"/>
        <source>PeX support [%1]</source>
        <translation>PeX support [%1]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1804"/>
        <source>&apos;%1&apos; reached the maximum ratio you set. Removed.</source>
        <translation>&apos;%1&apos; は設定された最大共有比に達しましたので削除しました。</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1809"/>
        <source>&apos;%1&apos; reached the maximum ratio you set. Paused.</source>
        <translation>&apos;%1&apos; は設定された最大共有比に達しましたので停止しました。</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1829"/>
        <source>&apos;%1&apos; reached the maximum seeding time you set. Removed.</source>
        <translation>&apos;%1&apos; は設定された最大シード時間に達しましたので削除しました。</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1834"/>
        <source>&apos;%1&apos; reached the maximum seeding time you set. Paused.</source>
        <translation>&apos;%1&apos; は最大シード時間に達しましたので停止しました。</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2564"/>
        <source>qBittorrent didn&apos;t find an %1 local address to listen on</source>
        <comment>qBittorrent didn&apos;t find an IPv4 local address to listen on</comment>
        <translation>qBittorrent は待ち受ける %1 ローカルアドレスを検出できませんでした</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2592"/>
        <source>qBittorrent failed to listen on any interface port: %1. Reason: %2.</source>
        <comment>e.g: qBittorrent failed to listen on any interface port: TCP/6881. Reason: no such interface</comment>
        <translation>qBittorrent はすべてのインターフェースでの待ち受けに失敗しました。ポート: %1. 理由: %2.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3647"/>
        <source>Tracker &apos;%1&apos; was added to torrent &apos;%2&apos;</source>
        <translation>Torrent &apos;%2&apos; にトラッカー &apos;%1&apos; が追加されました</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3659"/>
        <source>Tracker &apos;%1&apos; was deleted from torrent &apos;%2&apos;</source>
        <translation>Torrent &apos;%2&apos; からトラッカー &apos;%1&apos; が削除されました</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3676"/>
        <source>URL seed &apos;%1&apos; was added to torrent &apos;%2&apos;</source>
        <translation>Torrent &apos;%2&apos; に URL シード &apos;%1&apos; が追加されました</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3683"/>
        <source>URL seed &apos;%1&apos; was removed from torrent &apos;%2&apos;</source>
        <translation>Torrent &apos;%2&apos; から URL シード &apos;%1&apos; が削除されました</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3821"/>
        <source>Cannot write to torrent resume folder.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3825"/>
        <source>Cannot create torrent resume folder.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3928"/>
        <source>Unable to resume torrent &apos;%1&apos;.</source>
        <comment>e.g: Unable to resume torrent &apos;hash&apos;.</comment>
        <translation>Torrent &apos;%1&apos; の再開に失敗しました。</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4005"/>
        <source>Couldn&apos;t load torrents queue from &apos;%1&apos;. Error: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4055"/>
        <source>Successfully parsed the provided IP filter: %1 rules were applied.</source>
        <comment>%1 is a number</comment>
        <translation>IP フィルターは正常に解析されました: %1 個のルールが適用されました。</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4065"/>
        <source>Error: Failed to parse the provided IP filter.</source>
        <translation>エラー: IP フィルターの解析に失敗しました。</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4228"/>
        <source>&apos;%1&apos; restored.</source>
        <comment>&apos;torrent name&apos; restored.</comment>
        <translation>&apos;%1&apos; を復元しました。</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4273"/>
        <source>Couldn&apos;t add torrent. Reason: %1</source>
        <translation>Torrent を追加できませんでした: %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4249"/>
        <source>&apos;%1&apos; added to download list.</source>
        <comment>&apos;torrent name&apos; was added to download list.</comment>
        <translation>&apos;%1&apos; をダウンロードリストに追加しました。</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4341"/>
        <source>An I/O error occurred, &apos;%1&apos; paused. %2</source>
        <translation>I/O エラーが発生しました。&apos;%1&apos; を停止しました。 %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4351"/>
        <source>UPnP/NAT-PMP: Port mapping failure, message: %1</source>
        <translation>UPnP/NAT-PMP: ポートマッピングに失敗しました。メッセージ: %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4357"/>
        <source>UPnP/NAT-PMP: Port mapping successful, message: %1</source>
        <translation>UPnP/NAT-PMP: ポートマッピングに成功しました。メッセージ: %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4367"/>
        <source>due to IP filter.</source>
        <comment>this peer was blocked due to ip filter.</comment>
        <translation>IP フィルターによる。</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4370"/>
        <source>due to port filter.</source>
        <comment>this peer was blocked due to port filter.</comment>
        <translation>ポートフィルターによる。</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4373"/>
        <source>due to i2p mixed mode restrictions.</source>
        <comment>this peer was blocked due to i2p mixed mode restrictions.</comment>
        <translation>i2p 混在モード制限による。</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4376"/>
        <source>because it has a low port.</source>
        <comment>this peer was blocked because it has a low port.</comment>
        <translation>低いポート番号による。</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4421"/>
        <source>qBittorrent is successfully listening on interface %1 port: %2/%3</source>
        <comment>e.g: qBittorrent is successfully listening on interface 192.168.0.1 port: TCP/6881</comment>
        <translation>qBittorrent はインターフェース %1, ポート: %2/%3 での待ち受けを正常に開始しました</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4458"/>
        <source>External IP: %1</source>
        <comment>e.g. External IP: 192.168.0.1</comment>
        <translation>外部 IP: %1</translation>
    </message>
</context>
<context>
    <name>BitTorrent::TorrentCreatorThread</name>
    <message>
        <location filename="../base/bittorrent/torrentcreatorthread.cpp" line="189"/>
        <source>create new torrent file failed</source>
        <translation>新規 Torrent ファイルの作成失敗</translation>
    </message>
</context>
<context>
    <name>BitTorrent::TorrentHandle</name>
    <message>
        <location filename="../base/bittorrent/torrenthandle.cpp" line="1332"/>
        <source>Download first and last piece first: %1, torrent: &apos;%2&apos;</source>
        <translation>最初と最後のピースを先にダウンロード: %1, torrent: &apos;%2&apos;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrenthandle.cpp" line="1333"/>
        <source>On</source>
        <translation>On</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrenthandle.cpp" line="1333"/>
        <source>Off</source>
        <translation>Off</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrenthandle.cpp" line="1449"/>
        <source>Successfully moved torrent: %1. New path: %2</source>
        <translation>Torrent の移動に成功しました:: %1, 新しいパス: %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrenthandle.cpp" line="1484"/>
        <source>Could not move torrent: &apos;%1&apos;. Reason: %2</source>
        <translation>Torrent を移動せきませんでした: &apos;%1&apos;. 理由: %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrenthandle.cpp" line="1679"/>
        <source>File sizes mismatch for torrent &apos;%1&apos;, pausing it.</source>
        <translation>Torrent &apos;%1&apos;のファイルサイズが一致しません。解析しています。</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrenthandle.cpp" line="1682"/>
        <source>Fast resume data was rejected for torrent &apos;%1&apos;. Reason: %2. Checking again...</source>
        <translation>Torrent &apos;%1&apos; の高速再開データが拒否されました。理由: %2。再チェックしています...</translation>
    </message>
</context>
<context>
    <name>CategoryFilterModel</name>
    <message>
        <location filename="../gui/categoryfiltermodel.cpp" line="241"/>
        <source>Categories</source>
        <translation>カテゴリ</translation>
    </message>
    <message>
        <location filename="../gui/categoryfiltermodel.cpp" line="395"/>
        <source>All</source>
        <translation>すべて</translation>
    </message>
    <message>
        <location filename="../gui/categoryfiltermodel.cpp" line="402"/>
        <source>Uncategorized</source>
        <translation>カテゴリなし</translation>
    </message>
</context>
<context>
    <name>CategoryFilterWidget</name>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="114"/>
        <source>Add category...</source>
        <translation>カテゴリの追加...</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="122"/>
        <source>Add subcategory...</source>
        <translation>サブカテゴリの追加...</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="128"/>
        <source>Edit category...</source>
        <translation>カテゴリの編集...</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="133"/>
        <source>Remove category</source>
        <translation>カテゴリの削除</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="139"/>
        <source>Remove unused categories</source>
        <translation>未使用のカテゴリを削除</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="146"/>
        <source>Resume torrents</source>
        <translation>Torrent の再開</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="151"/>
        <source>Pause torrents</source>
        <translation>Torrent の停止</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="156"/>
        <source>Delete torrents</source>
        <translation>Torrent の削除</translation>
    </message>
</context>
<context>
    <name>CookiesDialog</name>
    <message>
        <location filename="../gui/cookiesdialog.ui" line="14"/>
        <source>Manage Cookies</source>
        <translation>Cookie の管理</translation>
    </message>
</context>
<context>
    <name>CookiesModel</name>
    <message>
        <location filename="../gui/cookiesmodel.cpp" line="49"/>
        <source>Domain</source>
        <translation>ドメイン</translation>
    </message>
    <message>
        <location filename="../gui/cookiesmodel.cpp" line="51"/>
        <source>Path</source>
        <translation>パス</translation>
    </message>
    <message>
        <location filename="../gui/cookiesmodel.cpp" line="53"/>
        <source>Name</source>
        <translation>名前</translation>
    </message>
    <message>
        <location filename="../gui/cookiesmodel.cpp" line="55"/>
        <source>Value</source>
        <translation>値</translation>
    </message>
    <message>
        <location filename="../gui/cookiesmodel.cpp" line="57"/>
        <source>Expiration Date</source>
        <translation>有効期限</translation>
    </message>
</context>
<context>
    <name>DeletionConfirmationDialog</name>
    <message>
        <location filename="../gui/deletionconfirmationdialog.ui" line="20"/>
        <source>Deletion confirmation</source>
        <translation>削除の確認</translation>
    </message>
    <message>
        <location filename="../gui/deletionconfirmationdialog.ui" line="67"/>
        <source>Remember choice</source>
        <translation>次回から確認しない</translation>
    </message>
    <message>
        <location filename="../gui/deletionconfirmationdialog.ui" line="91"/>
        <source>Also delete the files on the hard disk</source>
        <translation>ストレージ上のファイルも削除する</translation>
    </message>
    <message>
        <location filename="../gui/deletionconfirmationdialog.h" line="52"/>
        <source>Are you sure you want to delete &apos;%1&apos; from the transfer list?</source>
        <comment>Are you sure you want to delete &apos;ubuntu-linux-iso&apos; from the transfer list?</comment>
        <translation>&apos;%1&apos; を転送リストから削除してよろしいですか?</translation>
    </message>
    <message>
        <location filename="../gui/deletionconfirmationdialog.h" line="54"/>
        <source>Are you sure you want to delete these %1 torrents from the transfer list?</source>
        <comment>Are you sure you want to delete these 5 torrents from the transfer list?</comment>
        <translation>これら %1 個の Torrent を転送リストから削除してよろしいですか?</translation>
    </message>
</context>
<context>
    <name>DownloadFromURLDialog</name>
    <message>
        <location filename="../gui/downloadfromurldialog.ui" line="14"/>
        <source>Download from URLs</source>
        <translation>URL からダウンロード</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldialog.ui" line="26"/>
        <source>Add torrent links</source>
        <translation>Torrent リンクを追加してください</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldialog.ui" line="48"/>
        <source>One link per line (HTTP links, Magnet links and info-hashes are supported)</source>
        <translation>1 行に 1 リンク (HTTP リンク、マグネットリンクおよび情報ハッシュをサポートしています)</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldialog.cpp" line="64"/>
        <source>Download</source>
        <translation>ダウンロード</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldialog.cpp" line="105"/>
        <source>No URL entered</source>
        <translation>URL が入力されていません</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldialog.cpp" line="105"/>
        <source>Please type at least one URL.</source>
        <translation>1 個以上の URL を入力してください。</translation>
    </message>
</context>
<context>
    <name>DownloadedPiecesBar</name>
    <message>
        <location filename="../gui/properties/downloadedpiecesbar.cpp" line="175"/>
        <source>White: Missing pieces</source>
        <translation>白: 不足のピース</translation>
    </message>
    <message>
        <location filename="../gui/properties/downloadedpiecesbar.cpp" line="176"/>
        <source>Green: Partial pieces</source>
        <translation>緑: 不完全なピース</translation>
    </message>
    <message>
        <location filename="../gui/properties/downloadedpiecesbar.cpp" line="177"/>
        <source>Blue: Completed pieces</source>
        <translation>青: 完了したピース</translation>
    </message>
</context>
<context>
    <name>ExecutionLogWidget</name>
    <message>
        <location filename="../gui/executionlogwidget.ui" line="39"/>
        <source>General</source>
        <translation>全般</translation>
    </message>
    <message>
        <location filename="../gui/executionlogwidget.ui" line="45"/>
        <source>Blocked IPs</source>
        <translation>ブロックした IP</translation>
    </message>
    <message>
        <location filename="../gui/executionlogwidget.cpp" line="107"/>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; was blocked %2</source>
        <comment>x.y.z.w was blocked</comment>
        <translation>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; はブロックされました %2</translation>
    </message>
    <message>
        <location filename="../gui/executionlogwidget.cpp" line="109"/>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; was banned</source>
        <comment>x.y.z.w was banned</comment>
        <translation>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; は BAN されました</translation>
    </message>
</context>
<context>
    <name>FeedListWidget</name>
    <message>
        <location filename="../gui/rss/feedlistwidget.cpp" line="50"/>
        <source>RSS feeds</source>
        <translation>RSS フィード</translation>
    </message>
    <message>
        <location filename="../gui/rss/feedlistwidget.cpp" line="62"/>
        <location filename="../gui/rss/feedlistwidget.cpp" line="116"/>
        <source>Unread  (%1)</source>
        <translation>未読 (%1)</translation>
    </message>
</context>
<context>
    <name>FileLogger</name>
    <message>
        <location filename="../app/filelogger.cpp" line="171"/>
        <source>An error occurred while trying to open the log file. Logging to file is disabled.</source>
        <translation>ログファイルをオープンしようとしたらエラーが発生しました。ロギングは無効になります。</translation>
    </message>
</context>
<context>
    <name>FileSystemPathEdit</name>
    <message>
        <location filename="../gui/fspathedit.cpp" line="56"/>
        <source>...</source>
        <comment>Launch file dialog button text (brief)</comment>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit.cpp" line="58"/>
        <source>&amp;Browse...</source>
        <comment>Launch file dialog button text (full)</comment>
        <translation>閲覧(&amp;B)...</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit.cpp" line="60"/>
        <source>Choose a file</source>
        <comment>Caption for file open/save dialog</comment>
        <translation>ファイルの選択</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit.cpp" line="62"/>
        <source>Choose a folder</source>
        <comment>Caption for directory open dialog</comment>
        <translation>フォルダーの選択</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit.cpp" line="101"/>
        <source>Any file</source>
        <translation>すべてのファイル</translation>
    </message>
</context>
<context>
    <name>FileSystemWatcher</name>
    <message>
        <location filename="../base/filesystemwatcher.cpp" line="83"/>
        <source>Watching remote folder: &quot;%1&quot;</source>
        <translation>監視リモートフォルダー: &quot;%1&quot;</translation>
    </message>
    <message>
        <location filename="../base/filesystemwatcher.cpp" line="92"/>
        <source>Watching local folder: &quot;%1&quot;</source>
        <translation>監視ローカルフォルダー: &quot;%1&quot;</translation>
    </message>
</context>
<context>
    <name>FilterParserThread</name>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="128"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="276"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="438"/>
        <source>I/O Error: Could not open IP filter file in read mode.</source>
        <translation>I/O エラー: IP フィルターファイルを読み込みモードで開けませんでした。</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="213"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="344"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="353"/>
        <source>IP filter line %1 is malformed.</source>
        <translation>IP フィルターの行 %1 が不正です。</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="222"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="362"/>
        <source>IP filter line %1 is malformed. Start IP of the range is malformed.</source>
        <translation>IP フィルターの行 %1 が不正です。IP レンジの先頭が正しくありません。</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="231"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="371"/>
        <source>IP filter line %1 is malformed. End IP of the range is malformed.</source>
        <translation>IP フィルターの行 %1 が不正です。IP レンジの最後が正しくありません。</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="239"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="379"/>
        <source>IP filter line %1 is malformed. One IP is IPv4 and the other is IPv6!</source>
        <translation>IP フィルターの行 %1 が不正です。IPv6 のなかに IPv4 がまぎれています!</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="253"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="392"/>
        <source>IP filter exception thrown for line %1. Exception is: %2</source>
        <translation>IP フィルター例外が行 %1 から送出されました。例外は: %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="263"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="402"/>
        <source>%1 extra IP filter parsing errors occurred.</source>
        <comment>513 extra IP filter parsing errors occurred.</comment>
        <translation>%1 個の IP フィルター解析エラーが発生しました。</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="449"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="461"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="482"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="491"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="501"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="511"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="531"/>
        <source>Parsing Error: The filter file is not a valid PeerGuardian P2B file.</source>
        <translation>解析エラー: フィルターファイルは正しい PeerGuardian P2B ファイルではありません。</translation>
    </message>
</context>
<context>
    <name>GeoIPDatabase</name>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="94"/>
        <location filename="../base/net/private/geoipdatabase.cpp" line="124"/>
        <source>Unsupported database file size.</source>
        <translation>未サポートのデータベースファイルサイズです。</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="223"/>
        <source>Metadata error: &apos;%1&apos; entry not found.</source>
        <translation>メタデータエラー: &apos;%1&apos; エントリが見つかりません。</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="224"/>
        <source>Metadata error: &apos;%1&apos; entry has invalid type.</source>
        <translation>メタデータエラー: &apos;%1&apos; エントリは不正なタイプです。</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="233"/>
        <source>Unsupported database version: %1.%2</source>
        <translation>未サポートのデータベースバージョン: %1.%2</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="240"/>
        <source>Unsupported IP version: %1</source>
        <translation>未サポートの IP バージョン: %1</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="247"/>
        <source>Unsupported record size: %1</source>
        <translation>未サポートのレコードサイズ: %1</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="260"/>
        <source>Invalid database type: %1</source>
        <translation>不正なデータベースタイプ: %1</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="281"/>
        <source>Database corrupted: no data section found.</source>
        <translation>破損したデータベース: データセクションが見つかりません。</translation>
    </message>
</context>
<context>
    <name>Http::Connection</name>
    <message>
        <location filename="../base/http/connection.cpp" line="69"/>
        <source>Http request size exceeds limiation, closing socket. Limit: %ld, IP: %s</source>
        <translation>HTTP リクエストサイズが上限に達しました。ソケットをクローズします。上限: %ld, IP: %s</translation>
    </message>
    <message>
        <location filename="../base/http/connection.cpp" line="82"/>
        <source>Bad Http request, closing socket. IP: %s</source>
        <translation>不正な HTTP リスエストです。ソケットをクローズします。IP: %s</translation>
    </message>
</context>
<context>
    <name>IPSubnetWhitelistOptionsDialog</name>
    <message>
        <location filename="../gui/ipsubnetwhitelistoptionsdialog.ui" line="14"/>
        <source>List of whitelisted IP subnets</source>
        <translation>ホワイトリストに登録された IP サブネットの一覧</translation>
    </message>
    <message>
        <location filename="../gui/ipsubnetwhitelistoptionsdialog.ui" line="53"/>
        <source>Example: 172.17.32.0/24, fdff:ffff:c8::/40</source>
        <translation>例: 172.17.32.0/24, fdff:ffff:c8::/40</translation>
    </message>
    <message>
        <location filename="../gui/ipsubnetwhitelistoptionsdialog.ui" line="64"/>
        <source>Add subnet</source>
        <translation>サブネットの追加</translation>
    </message>
    <message>
        <location filename="../gui/ipsubnetwhitelistoptionsdialog.ui" line="71"/>
        <source>Delete</source>
        <translation>削除</translation>
    </message>
    <message>
        <location filename="../gui/ipsubnetwhitelistoptionsdialog.cpp" line="90"/>
        <source>Error</source>
        <translation>エラー</translation>
    </message>
    <message>
        <location filename="../gui/ipsubnetwhitelistoptionsdialog.cpp" line="90"/>
        <source>The entered subnet is invalid.</source>
        <translation>入力されたサブネットは正しくありません。</translation>
    </message>
</context>
<context>
    <name>LogListWidget</name>
    <message>
        <location filename="../gui/loglistwidget.cpp" line="50"/>
        <source>Copy</source>
        <translation>コピー</translation>
    </message>
    <message>
        <location filename="../gui/loglistwidget.cpp" line="51"/>
        <source>Clear</source>
        <translation>クリア</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../gui/mainwindow.ui" line="43"/>
        <source>&amp;Edit</source>
        <translation>編集(&amp;E)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="68"/>
        <source>&amp;Tools</source>
        <translation>ツール(&amp;T)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="89"/>
        <source>&amp;File</source>
        <translation>ファイル(&amp;F)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="58"/>
        <source>&amp;Help</source>
        <translation>ヘルプ(&amp;H)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="72"/>
        <source>On Downloads &amp;Done</source>
        <translation>ダウンロード完了時(&amp;D)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="99"/>
        <source>&amp;View</source>
        <translation>表示(&amp;V)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="180"/>
        <source>&amp;Options...</source>
        <translation>オプション(&amp;O)...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="190"/>
        <source>&amp;Resume</source>
        <translation>再開(&amp;R)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="223"/>
        <source>Torrent &amp;Creator</source>
        <translation>Torrent クリエーター(&amp;C)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="228"/>
        <source>Set Upload Limit...</source>
        <translation>アップロード速度制限の設定...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="233"/>
        <source>Set Download Limit...</source>
        <translation>ダウンロード速度制限の設定...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="243"/>
        <source>Set Global Download Limit...</source>
        <translation>全体のダウンロード速度制限の設定...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="248"/>
        <source>Set Global Upload Limit...</source>
        <translation>全体のアップロード速度制限の設定...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="253"/>
        <source>Minimum Priority</source>
        <translation>最低優先度</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="261"/>
        <source>Top Priority</source>
        <translation>最高優先度</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="269"/>
        <source>Decrease Priority</source>
        <translation>優先度を下げる</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="277"/>
        <source>Increase Priority</source>
        <translation>優先度を上げる</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="288"/>
        <location filename="../gui/mainwindow.ui" line="291"/>
        <source>Alternative Speed Limits</source>
        <translation>代替速度制限</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="299"/>
        <source>&amp;Top Toolbar</source>
        <translation>トップツールバー(&amp;T)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="302"/>
        <source>Display Top Toolbar</source>
        <translation>トップツールバーを表示します</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="310"/>
        <source>Status &amp;Bar</source>
        <translation>ステータスバー(&amp;B)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="318"/>
        <source>S&amp;peed in Title Bar</source>
        <translation>タイトルバーに速度を表示(&amp;P)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="321"/>
        <source>Show Transfer Speed in Title Bar</source>
        <translation>タイトルバーに転送速度を表示します</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="329"/>
        <source>&amp;RSS Reader</source>
        <translation>RSS リーダー(&amp;R)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="337"/>
        <source>Search &amp;Engine</source>
        <translation>検索エンジン(&amp;E)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="342"/>
        <source>L&amp;ock qBittorrent</source>
        <translation>qBittorrent をロック(&amp;O)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="353"/>
        <source>Do&amp;nate!</source>
        <translation>寄付(&amp;N)!</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="472"/>
        <source>Close Window</source>
        <translation>ウィンドウを閉じる</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="200"/>
        <source>R&amp;esume All</source>
        <translation>すべて再開(&amp;E)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="424"/>
        <source>Manage Cookies...</source>
        <translation>Cookie の管理...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="427"/>
        <source>Manage stored network cookies</source>
        <translation>保存されている Cookie を管理します</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="443"/>
        <source>Normal Messages</source>
        <translation>一般メッセージ</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="451"/>
        <source>Information Messages</source>
        <translation>情報メッセージ</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="459"/>
        <source>Warning Messages</source>
        <translation>警告メッセージ</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="467"/>
        <source>Critical Messages</source>
        <translation>危機的メッセージ</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="103"/>
        <source>&amp;Log</source>
        <translation>ログ(&amp;L)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="364"/>
        <source>&amp;Exit qBittorrent</source>
        <translation>qBittorrent を終了(&amp;E)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="372"/>
        <source>&amp;Suspend System</source>
        <translation>システムをサスペンド(&amp;S)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="380"/>
        <source>&amp;Hibernate System</source>
        <translation>システムをハイバーネート(&amp;H)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="388"/>
        <source>S&amp;hutdown System</source>
        <translation>システムをシャットダウン(&amp;H)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="396"/>
        <source>&amp;Disabled</source>
        <translation>なにもしない(&amp;D)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="411"/>
        <source>&amp;Statistics</source>
        <translation>統計情報(&amp;S)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="416"/>
        <source>Check for Updates</source>
        <translation>更新をチェック</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="419"/>
        <source>Check for Program Updates</source>
        <translation>プログラムの更新情報をチェックします</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="185"/>
        <source>&amp;About</source>
        <translation>qBittorrent について(&amp;A)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="195"/>
        <source>&amp;Pause</source>
        <translation>停止(&amp;P)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="210"/>
        <source>&amp;Delete</source>
        <translation>削除(&amp;D)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="205"/>
        <source>P&amp;ause All</source>
        <translation>すべて停止(&amp;A)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="167"/>
        <source>&amp;Add Torrent File...</source>
        <translation>Torrent ファイルの追加(&amp;A)...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="170"/>
        <source>Open</source>
        <translation>開く</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="175"/>
        <source>E&amp;xit</source>
        <translation>終了(&amp;X)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="218"/>
        <source>Open URL</source>
        <translation>URL を開く</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="238"/>
        <source>&amp;Documentation</source>
        <translation>ドキュメント(&amp;D)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="345"/>
        <source>Lock</source>
        <translation>ロック</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="401"/>
        <location filename="../gui/mainwindow.ui" line="435"/>
        <location filename="../gui/mainwindow.cpp" line="1678"/>
        <source>Show</source>
        <translation>表示</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1865"/>
        <source>Check for program updates</source>
        <translation>プログラムの更新情報をチェックします</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="215"/>
        <source>Add Torrent &amp;Link...</source>
        <translation>Torrent リンクの追加(&amp;L)...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="356"/>
        <source>If you like qBittorrent, please donate!</source>
        <translation>qBittorrent を気に入っていただけましたか? でしたら寄付をお願いします!</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1900"/>
        <location filename="../gui/mainwindow.cpp" line="1902"/>
        <source>Execution Log</source>
        <translation>実行ログ</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="653"/>
        <source>Clear the password</source>
        <translation>パスワードのクリア</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="235"/>
        <source>Filter torrent list...</source>
        <translation>Torrent リストをフィルター...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="206"/>
        <source>&amp;Set Password</source>
        <translation>パスワードの設定(&amp;S)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="174"/>
        <source>Preferences</source>
        <translation>設定</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="208"/>
        <source>&amp;Clear Password</source>
        <translation>パスワードのクリア(&amp;C)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="261"/>
        <source>Transfers</source>
        <translation>転送</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="422"/>
        <location filename="../gui/mainwindow.cpp" line="1247"/>
        <source>qBittorrent is minimized to tray</source>
        <translation>qBittorrent はシステムトレイに最小化されました</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="422"/>
        <location filename="../gui/mainwindow.cpp" line="1158"/>
        <location filename="../gui/mainwindow.cpp" line="1247"/>
        <source>This behavior can be changed in the settings. You won&apos;t be reminded again.</source>
        <translation>この振る舞いは設定から変更できます。この通知は次回からは表示されません。</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="462"/>
        <source>Torrent file association</source>
        <translation>Torrent ファイルの関連付け</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="463"/>
        <source>qBittorrent is not the default application to open torrent files or Magnet links.
Do you want to associate qBittorrent to torrent files and Magnet links?</source>
        <translation>qBittorrent は Torrent ファイルやマグネットリンクを開くデフォルトアプリケーションではありません。 
qBittorrent を Torrent ファイルおよびマグネットリンクに関連付けますか?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="546"/>
        <source>Icons Only</source>
        <translation>アイコンのみ</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="548"/>
        <source>Text Only</source>
        <translation>文字のみ</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="550"/>
        <source>Text Alongside Icons</source>
        <translation>アイコンの横に文字</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="552"/>
        <source>Text Under Icons</source>
        <translation>アイコンの下に文字</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="554"/>
        <source>Follow System Style</source>
        <translation>システムの設定に従う</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="637"/>
        <location filename="../gui/mainwindow.cpp" line="1050"/>
        <source>UI lock password</source>
        <translation>UI ロックパスワード</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="638"/>
        <location filename="../gui/mainwindow.cpp" line="1051"/>
        <source>Please type the UI lock password:</source>
        <translation>UI ロックパスワードを入力してください:</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="643"/>
        <source>The password should contain at least 3 characters</source>
        <translation>パスワードは 3 文字以上でなくてはなりません</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="654"/>
        <source>Are you sure you want to clear the password?</source>
        <translation>パスワードをクリアしてよろしいですか?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="707"/>
        <source>Use regular expressions</source>
        <translation>正規表現を使用</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="729"/>
        <source>Search</source>
        <translation>検索</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="745"/>
        <source>Transfers (%1)</source>
        <translation>転送 (%1)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="839"/>
        <source>Error</source>
        <translation>エラー</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="839"/>
        <source>Failed to add torrent: %1</source>
        <translation>Torrent の追加に失敗しました: %1</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="846"/>
        <source>Torrent added</source>
        <translation>Torrent が追加</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="846"/>
        <source>&apos;%1&apos; was added.</source>
        <comment>e.g: xxx.avi was added.</comment>
        <translation>&apos;%1&apos; が追加されました。</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="852"/>
        <source>Download completion</source>
        <translation>ダウンロード完了</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="858"/>
        <source>I/O Error</source>
        <comment>i.e: Input/Output Error</comment>
        <translation>I/O エラー</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="951"/>
        <source>Recursive download confirmation</source>
        <translation>再帰的ダウンロードの確認</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="957"/>
        <source>Yes</source>
        <translation>はい</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="958"/>
        <source>No</source>
        <translation>いいえ</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="959"/>
        <source>Never</source>
        <translation>すべてしない</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="984"/>
        <source>Global Upload Speed Limit</source>
        <translation>全体のアップロード速度上限</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="999"/>
        <source>Global Download Speed Limit</source>
        <translation>全体のダウンロード速度上限</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1072"/>
        <source>qBittorrent was just updated and needs to be restarted for the changes to be effective.</source>
        <translation>qBittorrent はアップデートされました。それを反映するために再起動が必要です。</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1158"/>
        <source>qBittorrent is closed to tray</source>
        <translation>qBittorrent はシステムトレイに閉じられました</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1171"/>
        <source>Some files are currently transferring.</source>
        <translation>一部のファイルは現在転送中です。</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1171"/>
        <source>Are you sure you want to quit qBittorrent?</source>
        <translation>qBittorrent を終了しますか?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1173"/>
        <source>&amp;No</source>
        <translation>いいえ(&amp;N)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1174"/>
        <source>&amp;Yes</source>
        <translation>はい(&amp;Y)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1175"/>
        <source>&amp;Always Yes</source>
        <translation>常にはい(&amp;A)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1577"/>
        <source>%1/s</source>
        <comment>s is a shorthand for seconds</comment>
        <translation>%1/s</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1786"/>
        <location filename="../gui/mainwindow.cpp" line="1792"/>
        <source>Missing Python Runtime</source>
        <translation>Python ランタイムが見つかりません</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1811"/>
        <source>Your Python version (%1) is outdated. Please upgrade to latest version for search engines to work.
Minimum requirement: 2.7.9 / 3.3.0.</source>
        <translation>Python バージョン (%1) はサポートされていません。検索エンジンを使用するには Python をアップグレードしてください。
サポートしているバージョン: 2.7.9 / 3.3.0 以上。</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1847"/>
        <source>qBittorrent Update Available</source>
        <translation>新しいバージョンの qBittorrent が利用できます</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1859"/>
        <source>Already Using the Latest qBittorrent Version</source>
        <translation>すでに最新の qBittorrent を使用しています</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="852"/>
        <source>&apos;%1&apos; has finished downloading.</source>
        <comment>e.g: xxx.avi has finished downloading.</comment>
        <translation>&apos;%1&apos; のダウンロードが完了しました。</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="859"/>
        <source>An I/O error occurred for torrent &apos;%1&apos;.
 Reason: %2</source>
        <comment>e.g: An error occurred for torrent &apos;xxx.avi&apos;.
 Reason: disk is full.</comment>
        <translation>Torrent &apos;%1&apos; で I/O エラーが発生しました。
 理由: %2</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="952"/>
        <source>The torrent &apos;%1&apos; contains torrent files, do you want to proceed with their download?</source>
        <translation>Torrent &apos;%1&apos; は Torrent ファイルを含んでいます。これらのダウンロードを行いますか?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="974"/>
        <source>Couldn&apos;t download file at URL &apos;%1&apos;, reason: %2.</source>
        <translation>URL &apos;%1&apos; のファイルをダウンロードできませんでした (理由: %2)。</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1787"/>
        <source>Python is required to use the search engine but it does not seem to be installed.
Do you want to install it now?</source>
        <translation>検索エンジンを使用するには Python が必要ですがインストールされていないようです。
いますぐインストールしますか?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1793"/>
        <source>Python is required to use the search engine but it does not seem to be installed.</source>
        <translation>検索エンジンを使用するには Python が必要ですがインストールされていないようです。</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1804"/>
        <location filename="../gui/mainwindow.cpp" line="1810"/>
        <source>Old Python Runtime</source>
        <translation>古い Python ランタイム</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1805"/>
        <source>Your Python version (%1) is outdated. Minimum requirement: 2.7.9 / 3.3.0.
Do you want to install a newer version now?</source>
        <translation>Python バージョン (%1) は古いためサポートされていません。バージョン 2.7.9 / 3.3.0.以降が必要です。
新しいバージョンをいまインストールしますか?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1848"/>
        <source>A new version is available.</source>
        <translation>新バージョンの qBittorrent を利用できます。</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1849"/>
        <source>Do you want to download %1?</source>
        <translation>%1 をダウンロードしますか?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1850"/>
        <source>Open changelog...</source>
        <translation>変更履歴を開く...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1860"/>
        <source>No updates available.
You are already using the latest version.</source>
        <translation>更新情報がありません。
すでに最新のバージョンを使用しています。</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1864"/>
        <source>&amp;Check for Updates</source>
        <translation>更新情報のチェック(&amp;C)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="2027"/>
        <source>Checking for Updates...</source>
        <translation>更新情報をチェックしています...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="2028"/>
        <source>Already checking for program updates in the background</source>
        <translation>プログラムの更新情報をバックグラウンドでチェックしています</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="2091"/>
        <source>Download error</source>
        <translation>ダウンロードエラー</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="2091"/>
        <source>Python setup could not be downloaded, reason: %1.
Please install it manually.</source>
        <translation>Python セットアップをダウンロードできませんでした。理由: %1。
手動でインストールしてください。</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="643"/>
        <location filename="../gui/mainwindow.cpp" line="1058"/>
        <source>Invalid password</source>
        <translation>不正なパスワード</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="678"/>
        <location filename="../gui/mainwindow.cpp" line="689"/>
        <location filename="../gui/mainwindow.cpp" line="691"/>
        <source>RSS (%1)</source>
        <translation>RSS (%1)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="973"/>
        <source>URL download error</source>
        <translation>URL ダウンロードエラー</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1058"/>
        <source>The password is invalid</source>
        <translation>パスワードが正しくありません</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1562"/>
        <location filename="../gui/mainwindow.cpp" line="1569"/>
        <source>DL speed: %1</source>
        <comment>e.g: Download speed: 10 KiB/s</comment>
        <translation>DL 速度: %1</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1565"/>
        <location filename="../gui/mainwindow.cpp" line="1571"/>
        <source>UP speed: %1</source>
        <comment>e.g: Upload speed: 10 KiB/s</comment>
        <translation>UP 速度: %1</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1584"/>
        <source>[D: %1, U: %2] qBittorrent %3</source>
        <comment>D = Download; U = Upload; %3 is qBittorrent version</comment>
        <translation>[D: %1, U: %2] qBittorrent %3</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1678"/>
        <source>Hide</source>
        <translation>隠す</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1169"/>
        <source>Exiting qBittorrent</source>
        <translation>qBittorrent の終了</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1373"/>
        <source>Open Torrent Files</source>
        <translation>Torrent ファイルを開く</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1374"/>
        <source>Torrent Files</source>
        <translation>Torrent ファイル</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1424"/>
        <source>Options were saved successfully.</source>
        <translation>オプションは正常に保存されました。</translation>
    </message>
</context>
<context>
    <name>Net::DNSUpdater</name>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="188"/>
        <source>Your dynamic DNS was successfully updated.</source>
        <translation>ダイナミック DNS は正常に更新されました。</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="193"/>
        <source>Dynamic DNS error: The service is temporarily unavailable, it will be retried in 30 minutes.</source>
        <translation>ダイナミック DNS エラー: サービスが一時的に利用できない状態です。30分後にリトライします。</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="203"/>
        <source>Dynamic DNS error: hostname supplied does not exist under specified account.</source>
        <translation>ダイナミック DNS エラー: 与えられたホスト名が指定されたアカウント下に存在しません。</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="209"/>
        <source>Dynamic DNS error: Invalid username/password.</source>
        <translation>ダイナミック DNS エラー: 不正なユーザー名/パスワードです。</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="215"/>
        <source>Dynamic DNS error: qBittorrent was blacklisted by the service, please report a bug at http://bugs.qbittorrent.org.</source>
        <translation>ダイナミック DNS エラー: qBittorrent はサービスのブラックリストに入っています。, バグとして http://bugs.qbittorrent.org に報告してください。</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="222"/>
        <source>Dynamic DNS error: %1 was returned by the service, please report a bug at http://bugs.qbittorrent.org.</source>
        <translation>ダイナミック DNS エラー: サービスから %1 が返されました。バグとして http://bugs.qbittorrent.org に報告してください。</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="229"/>
        <source>Dynamic DNS error: Your username was blocked due to abuse.</source>
        <translation>ダイナミック DNS エラー: あなたのユーザー名は不正利用を理由にブロックされました。</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="249"/>
        <source>Dynamic DNS error: supplied domain name is invalid.</source>
        <translation>ダイナミック DNS エラー: 与えられたドメイン名は無効です。</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="260"/>
        <source>Dynamic DNS error: supplied username is too short.</source>
        <translation>ダイナミック DNS エラー: 与えられたユーザー名は短すぎます。</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="271"/>
        <source>Dynamic DNS error: supplied password is too short.</source>
        <translation>ダイナミック DNS エラー: 与えられたパスワードは短すぎます。</translation>
    </message>
</context>
<context>
    <name>Net::DownloadHandler</name>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="127"/>
        <source>I/O Error</source>
        <translation>I/O エラー</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="140"/>
        <source>The file size is %1. It exceeds the download limit of %2.</source>
        <translation>ファイルサイズは %1 です。これは %2 のダウンロード制限を超えます。</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="174"/>
        <source>Unexpected redirect to magnet URI.</source>
        <translation>予期しないマグネット URL へのリダイレクトです。</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="206"/>
        <source>The remote host name was not found (invalid hostname)</source>
        <translation>リモートホスト名が見つかりませんでした (不正なホスト名)</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="208"/>
        <source>The operation was canceled</source>
        <translation>操作はキャンセルされました</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="210"/>
        <source>The remote server closed the connection prematurely, before the entire reply was received and processed</source>
        <translation>リモートサーバーは応答全体を受信して処理される前にクローズしました</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="212"/>
        <source>The connection to the remote server timed out</source>
        <translation>リモートサーバーへの接続はタイムアウトになりました</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="214"/>
        <source>SSL/TLS handshake failed</source>
        <translation>SSL/TLS ハンドシェイクに失敗しました</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="216"/>
        <source>The remote server refused the connection</source>
        <translation>リモートサーバーは接続を拒否しました</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="218"/>
        <source>The connection to the proxy server was refused</source>
        <translation>プロキシサーバーへの接続に失敗しました</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="220"/>
        <source>The proxy server closed the connection prematurely</source>
        <translation>プロキシサーバーは接続をクローズしました</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="222"/>
        <source>The proxy host name was not found</source>
        <translation>プロキシのホスト名が見つかりませんでした</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="224"/>
        <source>The connection to the proxy timed out or the proxy did not reply in time to the request sent</source>
        <translation>プロキシへの接続はタイムアウトになったか、プロキシはリクエスト送信時間内に応答しませんでした</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="226"/>
        <source>The proxy requires authentication in order to honor the request but did not accept any credentials offered</source>
        <translation>プロキシはリクエストを受けて認証を要求しましたが、提示されたすべての認証を受け付けませんでした</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="228"/>
        <source>The access to the remote content was denied (401)</source>
        <translation>リモートコンテンツへのアクセスは拒否されました (401)</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="230"/>
        <source>The operation requested on the remote content is not permitted</source>
        <translation>リモートコンテンツへの要求操作は許可されていません</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="232"/>
        <source>The remote content was not found at the server (404)</source>
        <translation>リモートコンテンツがサーバー内に見つかりませんでした (404)</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="234"/>
        <source>The remote server requires authentication to serve the content but the credentials provided were not accepted</source>
        <translation>リモートサーバーはコンテンツを提供するための認証を要求しましたが、提示された認証は受け付けられませんでした</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="236"/>
        <source>The Network Access API cannot honor the request because the protocol is not known</source>
        <translation>未知のプロトコルのため、ネットワークアクセス API はリクエストを受け入れることができませんでした</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="238"/>
        <source>The requested operation is invalid for this protocol</source>
        <translation>要求された操作はこのプロトコルでは正しくありません</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="240"/>
        <source>An unknown network-related error was detected</source>
        <translation>未知のネットワーク関連エラーが検出されました</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="242"/>
        <source>An unknown proxy-related error was detected</source>
        <translation>未知のプロキシ関連エラーが検出されました</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="244"/>
        <source>An unknown error related to the remote content was detected</source>
        <translation>リモートコンテンツに関連する未知のエラーが検出されました</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="246"/>
        <source>A breakdown in protocol was detected</source>
        <translation>プロトコルの断絶が検出されました</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="248"/>
        <source>Unknown error</source>
        <translation>未知のエラー</translation>
    </message>
</context>
<context>
    <name>Net::GeoIPManager</name>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="104"/>
        <location filename="../base/net/geoipmanager.cpp" line="434"/>
        <source>GeoIP database loaded. Type: %1. Build time: %2.</source>
        <translation>GeoIP データベースを読み込みました。タイプ: %1. ビルド日時: %2.</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="108"/>
        <location filename="../base/net/geoipmanager.cpp" line="455"/>
        <source>Couldn&apos;t load GeoIP database. Reason: %1</source>
        <translation>GeoIP データベースを読み込めませんでした。理由: %1</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="381"/>
        <source>Venezuela, Bolivarian Republic of</source>
        <translation>ベネズエラ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="384"/>
        <source>Viet Nam</source>
        <translation>ベトナム</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="394"/>
        <location filename="../base/net/geoipmanager.cpp" line="398"/>
        <source>N/A</source>
        <translation>N/A</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="144"/>
        <source>Andorra</source>
        <translation>アンドラ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="145"/>
        <source>United Arab Emirates</source>
        <translation>アラブ首長国連邦</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="146"/>
        <source>Afghanistan</source>
        <translation>アフガニスタン</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="147"/>
        <source>Antigua and Barbuda</source>
        <translation>アンティグア・バーブーダ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="148"/>
        <source>Anguilla</source>
        <translation>アンギラ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="149"/>
        <source>Albania</source>
        <translation>アルバニア</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="150"/>
        <source>Armenia</source>
        <translation>アルメニア</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="151"/>
        <source>Angola</source>
        <translation>アンゴラ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="152"/>
        <source>Antarctica</source>
        <translation>南極大陸</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="153"/>
        <source>Argentina</source>
        <translation>アルゼンチン</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="154"/>
        <source>American Samoa</source>
        <translation>アメリカ領サモア</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="155"/>
        <source>Austria</source>
        <translation>オーストリア</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="156"/>
        <source>Australia</source>
        <translation>オーストラリア</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="157"/>
        <source>Aruba</source>
        <translation>アルバ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="159"/>
        <source>Azerbaijan</source>
        <translation>アゼルバイジャン</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="160"/>
        <source>Bosnia and Herzegovina</source>
        <translation>ボスニア・ヘルツェゴビナ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="161"/>
        <source>Barbados</source>
        <translation>バルバドス</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="162"/>
        <source>Bangladesh</source>
        <translation>バングラデシュ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="163"/>
        <source>Belgium</source>
        <translation>ベルギー</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="164"/>
        <source>Burkina Faso</source>
        <translation>ブルキナ・ファソ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="165"/>
        <source>Bulgaria</source>
        <translation>ブルガリア</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="166"/>
        <source>Bahrain</source>
        <translation>バーレーン</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="167"/>
        <source>Burundi</source>
        <translation>ブルンジ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="168"/>
        <source>Benin</source>
        <translation>ベナン</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="170"/>
        <source>Bermuda</source>
        <translation>バーミューダ諸島</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="171"/>
        <source>Brunei Darussalam</source>
        <translation>ブルネイ・ダルサラーム</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="174"/>
        <source>Brazil</source>
        <translation>ブラジル</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="175"/>
        <source>Bahamas</source>
        <translation>バハマ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="176"/>
        <source>Bhutan</source>
        <translation>ブータン</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="177"/>
        <source>Bouvet Island</source>
        <translation>ブーベ島</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="178"/>
        <source>Botswana</source>
        <translation>ボツワナ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="179"/>
        <source>Belarus</source>
        <translation>ベラルーシ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="180"/>
        <source>Belize</source>
        <translation>ベリーズ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="181"/>
        <source>Canada</source>
        <translation>カナダ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="182"/>
        <source>Cocos (Keeling) Islands</source>
        <translation>ココス (キーリング) 諸島</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="183"/>
        <source>Congo, The Democratic Republic of the</source>
        <translation>コンゴ民主共和国</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="184"/>
        <source>Central African Republic</source>
        <translation>中央アフリカ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="185"/>
        <source>Congo</source>
        <translation>コンゴ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="186"/>
        <source>Switzerland</source>
        <translation>スイス</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="188"/>
        <source>Cook Islands</source>
        <translation>クック諸島</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="189"/>
        <source>Chile</source>
        <translation>チリ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="190"/>
        <source>Cameroon</source>
        <translation>カメルーン</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="191"/>
        <source>China</source>
        <translation>中国</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="192"/>
        <source>Colombia</source>
        <translation>コロンビア</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="193"/>
        <source>Costa Rica</source>
        <translation>コスタリカ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="194"/>
        <source>Cuba</source>
        <translation>キューバ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="195"/>
        <source>Cape Verde</source>
        <translation>カーボベルデ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="196"/>
        <source>Curacao</source>
        <translation>キュラソー</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="197"/>
        <source>Christmas Island</source>
        <translation>クリスマス島</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="198"/>
        <source>Cyprus</source>
        <translation>キプロス</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="199"/>
        <source>Czech Republic</source>
        <translation>チェコ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="200"/>
        <source>Germany</source>
        <translation>ドイツ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="201"/>
        <source>Djibouti</source>
        <translation>ジブチ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="202"/>
        <source>Denmark</source>
        <translation>デンマーク</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="203"/>
        <source>Dominica</source>
        <translation>ドミニカ国</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="204"/>
        <source>Dominican Republic</source>
        <translation>ドミニカ共和国</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="205"/>
        <source>Algeria</source>
        <translation>アルジェリア</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="206"/>
        <source>Ecuador</source>
        <translation>エクアドル</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="207"/>
        <source>Estonia</source>
        <translation>エストニア</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="208"/>
        <source>Egypt</source>
        <translation>エジプト</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="209"/>
        <source>Western Sahara</source>
        <translation>西サハラ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="210"/>
        <source>Eritrea</source>
        <translation>エリトリア</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="211"/>
        <source>Spain</source>
        <translation>スペイン</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="212"/>
        <source>Ethiopia</source>
        <translation>エチオピア</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="213"/>
        <source>Finland</source>
        <translation>フィンランド</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="214"/>
        <source>Fiji</source>
        <translation>フィジー</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="215"/>
        <source>Falkland Islands (Malvinas)</source>
        <translation>フォークランド (マルビナス) 諸島</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="216"/>
        <source>Micronesia, Federated States of</source>
        <translation>ミクロネシア連邦</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="217"/>
        <source>Faroe Islands</source>
        <translation>フェロー諸島</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="218"/>
        <source>France</source>
        <translation>フランス</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="219"/>
        <source>Gabon</source>
        <translation>ガボン</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="220"/>
        <source>United Kingdom</source>
        <translation>イギリス</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="221"/>
        <source>Grenada</source>
        <translation>グレナダ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="222"/>
        <source>Georgia</source>
        <translation>ジョージア (グルジア)</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="223"/>
        <source>French Guiana</source>
        <translation>フランス領ギアナ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="225"/>
        <source>Ghana</source>
        <translation>ガーナ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="226"/>
        <source>Gibraltar</source>
        <translation>ジブラルタル</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="227"/>
        <source>Greenland</source>
        <translation>グリーンランド</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="228"/>
        <source>Gambia</source>
        <translation>ガンビア</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="229"/>
        <source>Guinea</source>
        <translation>ギニア</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="230"/>
        <source>Guadeloupe</source>
        <translation>グアドループ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="231"/>
        <source>Equatorial Guinea</source>
        <translation>赤道ギニア</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="232"/>
        <source>Greece</source>
        <translation>ギリシャ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="233"/>
        <source>South Georgia and the South Sandwich Islands</source>
        <translation>サウスジョージア・サウスサンドウィッチ諸島</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="234"/>
        <source>Guatemala</source>
        <translation>グアテマラ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="235"/>
        <source>Guam</source>
        <translation>グアム</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="236"/>
        <source>Guinea-Bissau</source>
        <translation>ギニアビサウ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="237"/>
        <source>Guyana</source>
        <translation>ガイアナ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="238"/>
        <source>Hong Kong</source>
        <translation>香港</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="239"/>
        <source>Heard Island and McDonald Islands</source>
        <translation>ハード島とマクドナルド諸島</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="240"/>
        <source>Honduras</source>
        <translation>ホンジュラス</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="241"/>
        <source>Croatia</source>
        <translation>クロアチア</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="242"/>
        <source>Haiti</source>
        <translation>ハイチ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="243"/>
        <source>Hungary</source>
        <translation>ハンガリー</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="244"/>
        <source>Indonesia</source>
        <translation>インドネシア</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="245"/>
        <source>Ireland</source>
        <translation>アイルランド</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="246"/>
        <source>Israel</source>
        <translation>イスラエル</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="248"/>
        <source>India</source>
        <translation>インド</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="249"/>
        <source>British Indian Ocean Territory</source>
        <translation>イギリス領インド洋地域</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="250"/>
        <source>Iraq</source>
        <translation>イラク</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="251"/>
        <source>Iran, Islamic Republic of</source>
        <translation>イラン</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="252"/>
        <source>Iceland</source>
        <translation>アイスランド</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="253"/>
        <source>Italy</source>
        <translation>イタリア</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="255"/>
        <source>Jamaica</source>
        <translation>ジャマイカ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="256"/>
        <source>Jordan</source>
        <translation>ヨルダン</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="257"/>
        <source>Japan</source>
        <translation>日本</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="258"/>
        <source>Kenya</source>
        <translation>ケニア</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="259"/>
        <source>Kyrgyzstan</source>
        <translation>キルギスタン</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="260"/>
        <source>Cambodia</source>
        <translation>カンボジア</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="261"/>
        <source>Kiribati</source>
        <translation>キリバス</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="262"/>
        <source>Comoros</source>
        <translation>コモロ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="263"/>
        <source>Saint Kitts and Nevis</source>
        <translation>セントクリストファー・ネイビス</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="264"/>
        <source>Korea, Democratic People&apos;s Republic of</source>
        <translation>北朝鮮</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="265"/>
        <source>Korea, Republic of</source>
        <translation>韓国</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="266"/>
        <source>Kuwait</source>
        <translation>クウェート</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="267"/>
        <source>Cayman Islands</source>
        <translation>ケイマン諸島</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="268"/>
        <source>Kazakhstan</source>
        <translation>カザフスタン</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="269"/>
        <source>Lao People&apos;s Democratic Republic</source>
        <translation>ラオス</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="270"/>
        <source>Lebanon</source>
        <translation>レバノン</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="271"/>
        <source>Saint Lucia</source>
        <translation>セントルシア</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="272"/>
        <source>Liechtenstein</source>
        <translation>リヒテンシュタイン</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="273"/>
        <source>Sri Lanka</source>
        <translation>スリランカ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="274"/>
        <source>Liberia</source>
        <translation>リベリア</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="275"/>
        <source>Lesotho</source>
        <translation>レソト</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="276"/>
        <source>Lithuania</source>
        <translation>リトアニア</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="277"/>
        <source>Luxembourg</source>
        <translation>ルクセンブルク</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="278"/>
        <source>Latvia</source>
        <translation>ラトビア</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="280"/>
        <source>Morocco</source>
        <translation>モロッコ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="281"/>
        <source>Monaco</source>
        <translation>モナコ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="282"/>
        <source>Moldova, Republic of</source>
        <translation>モルドバ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="285"/>
        <source>Madagascar</source>
        <translation>マダガスカル</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="286"/>
        <source>Marshall Islands</source>
        <translation>マーシャル諸島</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="288"/>
        <source>Mali</source>
        <translation>マリ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="289"/>
        <source>Myanmar</source>
        <translation>ミャンマー</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="290"/>
        <source>Mongolia</source>
        <translation>モンゴル</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="292"/>
        <source>Northern Mariana Islands</source>
        <translation>北マリアナ諸島</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="293"/>
        <source>Martinique</source>
        <translation>マルティニーク</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="294"/>
        <source>Mauritania</source>
        <translation>モーリタニア</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="295"/>
        <source>Montserrat</source>
        <translation>モントセラト</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="296"/>
        <source>Malta</source>
        <translation>マルタ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="297"/>
        <source>Mauritius</source>
        <translation>モーリシャス</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="298"/>
        <source>Maldives</source>
        <translation>モルディブ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="299"/>
        <source>Malawi</source>
        <translation>マワリ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="300"/>
        <source>Mexico</source>
        <translation>メキシコ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="301"/>
        <source>Malaysia</source>
        <translation>マレーシア</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="302"/>
        <source>Mozambique</source>
        <translation>モザンビーク</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="303"/>
        <source>Namibia</source>
        <translation>ナミビア</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="304"/>
        <source>New Caledonia</source>
        <translation>ニューカレドニア</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="305"/>
        <source>Niger</source>
        <translation>ニジェール</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="306"/>
        <source>Norfolk Island</source>
        <translation>ノーフォーク島</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="307"/>
        <source>Nigeria</source>
        <translation>ナイジェリア</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="308"/>
        <source>Nicaragua</source>
        <translation>ニカラグア</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="309"/>
        <source>Netherlands</source>
        <translation>オランダ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="310"/>
        <source>Norway</source>
        <translation>ノルウェイ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="311"/>
        <source>Nepal</source>
        <translation>ネパール</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="312"/>
        <source>Nauru</source>
        <translation>ナウル</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="313"/>
        <source>Niue</source>
        <translation>ニウエ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="314"/>
        <source>New Zealand</source>
        <translation>ニュージーランド</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="315"/>
        <source>Oman</source>
        <translation>オマーン</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="316"/>
        <source>Panama</source>
        <translation>パナマ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="317"/>
        <source>Peru</source>
        <translation>ペルー</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="318"/>
        <source>French Polynesia</source>
        <translation>フランス領ポリネシア</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="319"/>
        <source>Papua New Guinea</source>
        <translation>パプアニューギニア</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="320"/>
        <source>Philippines</source>
        <translation>フィリピン</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="321"/>
        <source>Pakistan</source>
        <translation>パキスタン</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="322"/>
        <source>Poland</source>
        <translation>ポーランド</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="323"/>
        <source>Saint Pierre and Miquelon</source>
        <translation>サンピエール島・ミクロン島</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="325"/>
        <source>Puerto Rico</source>
        <translation>プエルトリコ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="327"/>
        <source>Portugal</source>
        <translation>ポルトガル</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="328"/>
        <source>Palau</source>
        <translation>パラウ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="329"/>
        <source>Paraguay</source>
        <translation>パラグアイ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="330"/>
        <source>Qatar</source>
        <translation>カタール</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="331"/>
        <source>Reunion</source>
        <translation>レユニオン</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="332"/>
        <source>Romania</source>
        <translation>ルーマニア</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="334"/>
        <source>Russian Federation</source>
        <translation>ロシア</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="335"/>
        <source>Rwanda</source>
        <translation>ルワンダ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="336"/>
        <source>Saudi Arabia</source>
        <translation>サウジアラビア</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="337"/>
        <source>Solomon Islands</source>
        <translation>ソロモン諸島</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="338"/>
        <source>Seychelles</source>
        <translation>セーシェル</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="339"/>
        <source>Sudan</source>
        <translation>スーダン</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="340"/>
        <source>Sweden</source>
        <translation>スウェーデン</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="341"/>
        <source>Singapore</source>
        <translation>シンガポール</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="343"/>
        <source>Slovenia</source>
        <translation>スロベニア</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="344"/>
        <source>Svalbard and Jan Mayen</source>
        <translation>スヴァールバル諸島およびヤンマイエン島</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="345"/>
        <source>Slovakia</source>
        <translation>スロバキア</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="346"/>
        <source>Sierra Leone</source>
        <translation>シエラレオネ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="347"/>
        <source>San Marino</source>
        <translation>サンマリノ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="348"/>
        <source>Senegal</source>
        <translation>セネガル</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="349"/>
        <source>Somalia</source>
        <translation>ソマリア</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="350"/>
        <source>Suriname</source>
        <translation>スリナム</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="352"/>
        <source>Sao Tome and Principe</source>
        <translation>サントメ・プリンシペ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="353"/>
        <source>El Salvador</source>
        <translation>エルサルバドル</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="355"/>
        <source>Syrian Arab Republic</source>
        <translation>シリア</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="356"/>
        <source>Swaziland</source>
        <translation>スワジランド</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="357"/>
        <source>Turks and Caicos Islands</source>
        <translation>タークス・カイコス諸島</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="358"/>
        <source>Chad</source>
        <translation>チャド</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="359"/>
        <source>French Southern Territories</source>
        <translation>フランス領南方・南極地域</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="360"/>
        <source>Togo</source>
        <translation>トーゴ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="361"/>
        <source>Thailand</source>
        <translation>タイ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="362"/>
        <source>Tajikistan</source>
        <translation>タジキスタン</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="363"/>
        <source>Tokelau</source>
        <translation>トケラウ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="365"/>
        <source>Turkmenistan</source>
        <translation>トルクメニスタン</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="366"/>
        <source>Tunisia</source>
        <translation>チュニジア</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="367"/>
        <source>Tonga</source>
        <translation>トンガ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="423"/>
        <source>Could not decompress GeoIP database file.</source>
        <translation>GeoIP データベースファイルを展開できませんでした。</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="364"/>
        <source>Timor-Leste</source>
        <translation>東ティモール</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="172"/>
        <source>Bolivia, Plurinational State of</source>
        <translation>ボリビア</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="173"/>
        <source>Bonaire, Sint Eustatius and Saba</source>
        <translation>ボネール、シント・ユースタティウスおよびサバ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="187"/>
        <source>Cote d&apos;Ivoire</source>
        <translation>コートジボワール</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="279"/>
        <source>Libya</source>
        <translation>リビア</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="284"/>
        <source>Saint Martin (French part)</source>
        <translation>サン・マルタン</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="287"/>
        <source>Macedonia, The Former Yugoslav Republic of</source>
        <translation>マケドニア</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="291"/>
        <source>Macao</source>
        <translation>マカオ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="324"/>
        <source>Pitcairn</source>
        <translation>ピトケアン諸島</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="326"/>
        <source>Palestine, State of</source>
        <translation>パレスチナ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="342"/>
        <source>Saint Helena, Ascension and Tristan da Cunha</source>
        <translation>セント・ヘレナ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="351"/>
        <source>South Sudan</source>
        <translation>南スーダン</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="354"/>
        <source>Sint Maarten (Dutch part)</source>
        <translation>シント・マールテン</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="368"/>
        <source>Turkey</source>
        <translation>トルコ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="369"/>
        <source>Trinidad and Tobago</source>
        <translation>トリニダード・トバゴ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="370"/>
        <source>Tuvalu</source>
        <translation>ツバル</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="371"/>
        <source>Taiwan</source>
        <translation>台湾</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="372"/>
        <source>Tanzania, United Republic of</source>
        <translation>タンザニア</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="373"/>
        <source>Ukraine</source>
        <translation>ウクライナ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="374"/>
        <source>Uganda</source>
        <translation>ウガンダ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="375"/>
        <source>United States Minor Outlying Islands</source>
        <translation>合衆国領有小離島</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="376"/>
        <source>United States</source>
        <translation>アメリカ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="377"/>
        <source>Uruguay</source>
        <translation>ウルグアイ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="378"/>
        <source>Uzbekistan</source>
        <translation>ウズベキスタン</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="379"/>
        <source>Holy See (Vatican City State)</source>
        <translation>バチカン</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="380"/>
        <source>Saint Vincent and the Grenadines</source>
        <translation>セントビンセント・グレナディーン</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="382"/>
        <source>Virgin Islands, British</source>
        <translation>イギリス領ヴァージン諸島</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="383"/>
        <source>Virgin Islands, U.S.</source>
        <translation>アメリカ領ヴァージン諸島.</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="385"/>
        <source>Vanuatu</source>
        <translation>バヌアツ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="386"/>
        <source>Wallis and Futuna</source>
        <translation>ウォリス・フツナ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="387"/>
        <source>Samoa</source>
        <translation>サモア</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="388"/>
        <source>Yemen</source>
        <translation>イエメン</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="389"/>
        <source>Mayotte</source>
        <translation>マヨット</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="333"/>
        <source>Serbia</source>
        <translation>セルビア</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="390"/>
        <source>South Africa</source>
        <translation>南アフリカ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="391"/>
        <source>Zambia</source>
        <translation>ザンビア</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="283"/>
        <source>Montenegro</source>
        <translation>モンテネグロ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="392"/>
        <source>Zimbabwe</source>
        <translation>ジンバブエ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="158"/>
        <source>Aland Islands</source>
        <translation>オーランド諸島</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="224"/>
        <source>Guernsey</source>
        <translation>ガーンジー</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="247"/>
        <source>Isle of Man</source>
        <translation>マン島</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="254"/>
        <source>Jersey</source>
        <translation>ジャージー</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="169"/>
        <source>Saint Barthelemy</source>
        <translation>サン・バルテルミー島</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="444"/>
        <source>Couldn&apos;t save downloaded GeoIP database file.</source>
        <translation>ダウンロードした GeoIP データベースファイルを保存できませんでした。</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="447"/>
        <source>Successfully updated GeoIP database.</source>
        <translation>GeoIP データベースは正常に更新されました。</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="462"/>
        <source>Couldn&apos;t download GeoIP database file. Reason: %1</source>
        <translation>GeoIP データベースファイルをダウンロードできませんでした。理由: %1</translation>
    </message>
</context>
<context>
    <name>Net::PortForwarder</name>
    <message>
        <location filename="../base/net/portforwarder.cpp" line="129"/>
        <source>UPnP / NAT-PMP support [ON]</source>
        <translation>UPnP / NAT-PMP サポート [ON]</translation>
    </message>
    <message>
        <location filename="../base/net/portforwarder.cpp" line="145"/>
        <source>UPnP / NAT-PMP support [OFF]</source>
        <translation>UPnP / NAT-PMP サポート [OFF]</translation>
    </message>
</context>
<context>
    <name>Net::Smtp</name>
    <message>
        <location filename="../base/net/smtp.cpp" line="507"/>
        <source>Email Notification Error:</source>
        <translation>メール通知エラー:</translation>
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <location filename="../gui/optionsdialog.ui" line="14"/>
        <source>Options</source>
        <translation>オプション</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="52"/>
        <source>Behavior</source>
        <translation>振る舞い</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="57"/>
        <source>Downloads</source>
        <translation>ダウンロード</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="62"/>
        <source>Connection</source>
        <translation>接続</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="67"/>
        <source>Speed</source>
        <translation>速度</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="72"/>
        <source>BitTorrent</source>
        <translation>BitTorrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="77"/>
        <source>RSS</source>
        <translation>RSS</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="82"/>
        <source>Web UI</source>
        <translation>Web UI</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="87"/>
        <source>Advanced</source>
        <translation>詳細</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="133"/>
        <source>Language</source>
        <translation>言語</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="141"/>
        <source>User Interface Language:</source>
        <translation>ユーザーインターフェースの言語:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="169"/>
        <source>(Requires restart)</source>
        <translation>(再起動が必要)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="197"/>
        <source>Transfer List</source>
        <translation>転送リスト</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="203"/>
        <source>Confirm when deleting torrents</source>
        <translation>Torrent を削除するとき確認する</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="213"/>
        <source>Use alternating row colors</source>
        <extracomment>In transfer list, one every two rows will have grey background.</extracomment>
        <translation>行の背景色を交互に変える</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="225"/>
        <source>Hide zero and infinity values</source>
        <translation>値がゼロまたは無限の場合表示しない</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="233"/>
        <source>Always</source>
        <translation>常に</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="238"/>
        <source>Paused torrents only</source>
        <translation>停止中の Torrent のみ</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="267"/>
        <source>Action on double-click</source>
        <translation>ダブルクリック時の動作</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="276"/>
        <source>Downloading torrents:</source>
        <translation>ダウンロード中の Torrent:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="293"/>
        <location filename="../gui/optionsdialog.ui" line="319"/>
        <source>Start / Stop Torrent</source>
        <translation>Torrent の開始/停止</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="298"/>
        <location filename="../gui/optionsdialog.ui" line="324"/>
        <source>Open destination folder</source>
        <translation>保存先のフォルダーを開く</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="303"/>
        <location filename="../gui/optionsdialog.ui" line="329"/>
        <source>No action</source>
        <translation>なにもしない</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="311"/>
        <source>Completed torrents:</source>
        <translation>完了している Torrent:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="343"/>
        <source>Desktop</source>
        <translation>デスクトップ</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="349"/>
        <source>Start qBittorrent on Windows start up</source>
        <translation>Windows 起動時に qBittorrent を起動する</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="356"/>
        <source>Show splash screen on start up</source>
        <translation>起動時にスプラッシュスクリーンを表示する</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="366"/>
        <source>Start qBittorrent minimized</source>
        <translation>qBittorrent を最小化して起動する</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="373"/>
        <source>Confirmation on exit when torrents are active</source>
        <translation>終了時に Torrent が動作中だと確認する</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="383"/>
        <source>Confirmation on auto-exit when downloads finish</source>
        <translation>ダウンロード完了時の自動終了の確認</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="545"/>
        <source> KiB</source>
        <translation> KiB</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1125"/>
        <source>Email notification &amp;upon download completion</source>
        <translation>ダウンロード完了時にメールで通知する(&amp;U)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1220"/>
        <source>Run e&amp;xternal program on torrent completion</source>
        <translation>Torrent 完了時に外部プログラムを実行する(&amp;X)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1706"/>
        <source>IP Fi&amp;ltering</source>
        <translation>IP フィルタリング(&amp;L)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1906"/>
        <source>Schedule &amp;the use of alternative rate limits</source>
        <translation>代替速度制限を使用するスケジュール(&amp;T)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2238"/>
        <source>(&lt;a href=&quot;https://github.com/qbittorrent/qBittorrent/wiki/Anonymous-Mode&quot;&gt;More information&lt;/a&gt;)</source>
        <translation>(&lt;a href=&quot;https://github.com/qbittorrent/qBittorrent/wiki/Anonymous-Mode&quot;&gt;詳細情報&lt;/a&gt;)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2266"/>
        <source>&amp;Torrent Queueing</source>
        <translation>Torrent キュー(&amp;T)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2616"/>
        <source>Seed torrents until their seeding time reaches</source>
        <translation>指定シード時間に達するまでシードする</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2649"/>
        <source>A&amp;utomatically add these trackers to new downloads:</source>
        <translation>新しいダウンロードに以下のトラッカーを自動追加する(&amp;U):</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2722"/>
        <source>RSS Reader</source>
        <translation>RSS リーダー</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2728"/>
        <source>Enable fetching RSS feeds</source>
        <translation>RSS フィードの取得を有効にする</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2737"/>
        <source>Feeds refresh interval:</source>
        <translation>フィードの更新間隔:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2747"/>
        <source>Maximum number of articles per feed:</source>
        <translation>フィードあたりの最大記事数:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2581"/>
        <location filename="../gui/optionsdialog.ui" line="2757"/>
        <source> min</source>
        <extracomment>minutes</extracomment>
        <translation> 分</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2801"/>
        <source>RSS Torrent Auto Downloader</source>
        <translation>RSS Torrent 自動ダウンローダー</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2807"/>
        <source>Enable auto downloading of RSS torrents</source>
        <translation>RSS Torrent の自動ダウンロードを有効にする</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2814"/>
        <source>Edit auto downloading rules...</source>
        <translation>自動ダウンロードルールの編集...</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2824"/>
        <source>RSS Smart Episode Filter</source>
        <translation>RSS スマートエピソードフィルター</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2830"/>
        <source>Download REPACK/PROPER episodes</source>
        <translation>REPACK/PROPER エピソードをダウンロードする</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2837"/>
        <source>Filters:</source>
        <translation>フィルター:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2898"/>
        <source>Web User Interface (Remote control)</source>
        <translation>ウェブユーザーインターフェース (遠隔操作)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2912"/>
        <source>IP address:</source>
        <translation>IP アドレス:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2919"/>
        <source>IP address that the Web UI will bind to.
Specify an IPv4 or IPv6 address. You can specify &quot;0.0.0.0&quot; for any IPv4 address,
&quot;::&quot; for any IPv6 address, or &quot;*&quot; for both IPv4 and IPv6.</source>
        <translation>WebUI にバインドする IP アドレスです。
IPv4 または IPv6 アドレスで指定してください。&quot;0.0.0.0&quot; で IPv4 の全アドレス、
&quot;::&quot; で IPv6 の全アドレスになります。&quot;*&quot; で IPv4 および IPv6 の全アドレスになります。</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3188"/>
        <source>Server domains:</source>
        <translation>サーバードメイン:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3195"/>
        <source>Whitelist for filtering HTTP Host header values.
In order to defend against DNS rebinding attack,
you should put in domain names used by WebUI server.

Use &apos;;&apos; to split multiple entries. Can use wildcard &apos;*&apos;.</source>
        <translation>HTTP Host ヘッダーの値でフィルターするホワイトリストです。
DNS リバインディング攻撃から守るために、
WebUI サーバーで使用するドメイン名を入力してください。

&apos;;&apos; で分けて複数のエントリを周力できます。ワイルドカード &apos;*&apos; を利用できます。</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2960"/>
        <source>&amp;Use HTTPS instead of HTTP</source>
        <translation>HTTP でなく HTTPS を使用する(&amp;U)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3088"/>
        <source>Bypass authentication for clients on localhost</source>
        <translation>ローカルホストではクライアントの認証を行わない</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3095"/>
        <source>Bypass authentication for clients in whitelisted IP subnets</source>
        <translation>ホワイトリストに登録された IP サブネットのクライアントは認証を行わない</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3108"/>
        <source>IP subnet whitelist...</source>
        <translation>IP サブネットホワイトリスト...</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3214"/>
        <source>Upda&amp;te my dynamic domain name</source>
        <translation>ダイナミックドメイン名を更新する(&amp;T)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="402"/>
        <source>Minimize qBittorrent to notification area</source>
        <translation>最小化したら qBittorrent を通知エリアへ最小化する</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="412"/>
        <source>Close qBittorrent to notification area</source>
        <comment>i.e: The systray tray icon will still be visible when closing the main window.</comment>
        <translation>閉じたら qBittorrent を通知エリアへ最小化する</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="421"/>
        <source>Tray icon style:</source>
        <translation>トレイアイコンのスタイル:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="429"/>
        <source>Normal</source>
        <translation>通常</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="434"/>
        <source>Monochrome (Dark theme)</source>
        <translation>モノクローム (暗いテーマ)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="439"/>
        <source>Monochrome (Light theme)</source>
        <translation>モノクローム (明るいテーマ)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="452"/>
        <source>File association</source>
        <translation>ファイルの関連付け</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="458"/>
        <source>Use qBittorrent for .torrent files</source>
        <translation>.torrent ファイルに qBittorrent を使用する</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="465"/>
        <source>Use qBittorrent for magnet links</source>
        <translation>マグネットリンクに qBittorrent を使用する</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="478"/>
        <source>Power Management</source>
        <translation>電源管理</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="521"/>
        <source>Save path:</source>
        <translation>保存先:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="538"/>
        <source>Backup the log file after:</source>
        <translation>ログが次のファイルサイズになったらバックアップする:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="581"/>
        <source>Delete backup logs older than:</source>
        <translation>ログのバックアップの保存期限:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="605"/>
        <source>days</source>
        <comment>Delete backup logs older than 10 months</comment>
        <translation>日</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="610"/>
        <source>months</source>
        <comment>Delete backup logs older than 10 months</comment>
        <translation>月</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="615"/>
        <source>years</source>
        <comment>Delete backup logs older than 10 years</comment>
        <translation>年</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="689"/>
        <source>When adding a torrent</source>
        <translation>Torrent の追加時</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="707"/>
        <source>Bring torrent dialog to the front</source>
        <translation>Torrent ダイアログを最前面に表示する</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="730"/>
        <source>Do not start the download automatically</source>
        <comment>The torrent will be added to download list in pause state</comment>
        <translation>停止状態で追加する</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="737"/>
        <source>Should the .torrent file be deleted after adding it</source>
        <translation>転送リストに追加後 .torrent ファイルは削除されます</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="752"/>
        <source>Also delete .torrent files whose addition was cancelled</source>
        <translation>.torrent ファイルの追加をキャンセルしたときも削除されます</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="755"/>
        <source>Also when addition is cancelled</source>
        <translation>追加をキャンセルしたときも削除する</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="777"/>
        <source>Warning! Data loss possible!</source>
        <translation>注意: データを失う可能性があります!</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="813"/>
        <source>Saving Management</source>
        <translation>保存管理</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="821"/>
        <source>Default Torrent Management Mode:</source>
        <translation>デフォルトの Torrent 管理モード:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="833"/>
        <source>Automatic mode means that various torrent properties (e.g. save path) will be decided by the associated category</source>
        <translation>自動モードでは割り当てられたカテゴリによってさまざまな Torrent プロパティ (保存先など) が自動決定されます</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="837"/>
        <source>Manual</source>
        <translation>手動</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="842"/>
        <source>Automatic</source>
        <translation>自動</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="865"/>
        <source>When Torrent Category changed:</source>
        <translation>Torrent のカテゴリが変更されたとき:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="875"/>
        <source>Relocate torrent</source>
        <translation>Torrent を移動する</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="880"/>
        <source>Switch torrent to Manual Mode</source>
        <translation>Torrent を手動モードに切り換える</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="903"/>
        <source>When Default Save Path changed:</source>
        <translation>デフォルトの保存先が変更されたとき:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="916"/>
        <location filename="../gui/optionsdialog.ui" line="957"/>
        <source>Relocate affected torrents</source>
        <translation>影響のある Torrent を移動する</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="921"/>
        <location filename="../gui/optionsdialog.ui" line="962"/>
        <source>Switch affected torrents to Manual Mode</source>
        <translation>影響のある Torrent を手動モードに切り換える</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="987"/>
        <source>Use Subcategories</source>
        <translation>サブカテゴリを使用する</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1006"/>
        <source>Default Save Path:</source>
        <translation>デフォルトの保存先:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1020"/>
        <source>Keep incomplete torrents in:</source>
        <translation>未完了の Torrent の格納先:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1013"/>
        <source>Copy .torrent files to:</source>
        <translation>.torrent ファイルの保存先:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="393"/>
        <source>Show &amp;qBittorrent in notification area</source>
        <translation>qBittorrent を通知エリアに表示する(&amp;Q)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="501"/>
        <source>&amp;Log file</source>
        <translation>ログファイル(&amp;L)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="695"/>
        <source>Display &amp;torrent content and some options</source>
        <translation>Torrent の内容と一部オプションを表示する(&amp;T)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="720"/>
        <source>Create subfolder for torrents with multiple files</source>
        <translation>複数ファイルからなる Torrent にはサブフォルダーを作成する</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="740"/>
        <source>De&amp;lete .torrent files afterwards </source>
        <translation>追加後に .torrent ファイルを削除する(&amp;L) </translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="999"/>
        <source>Copy .torrent files for finished downloads to:</source>
        <translation>ダウンロードが完了した .torrent ファイルのコピー先:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="792"/>
        <source>Pre-allocate disk space for all files</source>
        <translation>すべてのファイルに対して事前にディスクスペースを割り当てる</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="484"/>
        <source>Inhibit system sleep when torrents are downloading</source>
        <translation>Torrent がダウンロード中はシステムのスリープを抑止する</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="491"/>
        <source>Inhibit system sleep when torrents are seeding</source>
        <translation>Torrent がシード中はシステムのスリープを抑止する</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="799"/>
        <source>Append .!qB extension to incomplete files</source>
        <translation>未完了のファイル名に拡張子 .!qB を付加する</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="806"/>
        <source>Enable recursive download dialog</source>
        <translation>再帰ダウンロードダイアログを有効にする</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="944"/>
        <source>When Category Save Path changed:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1041"/>
        <source>Automatically add torrents from:</source>
        <translation>自動的に Torrent を追加するフォルダー:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1088"/>
        <source>Add entry</source>
        <translation>エントリの追加</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1098"/>
        <source>Remove entry</source>
        <translation>エントリの削除</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1149"/>
        <source>SMTP server:</source>
        <translation>SMTP サーバー:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1171"/>
        <source>This server requires a secure connection (SSL)</source>
        <translation>このサーバーではセキュアな接続 (SSL) が必要</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1178"/>
        <location filename="../gui/optionsdialog.ui" line="3059"/>
        <source>Authentication</source>
        <translation>認証</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1190"/>
        <location filename="../gui/optionsdialog.ui" line="1667"/>
        <location filename="../gui/optionsdialog.ui" line="3115"/>
        <location filename="../gui/optionsdialog.ui" line="3272"/>
        <source>Username:</source>
        <translation>ユーザー名:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1200"/>
        <location filename="../gui/optionsdialog.ui" line="1677"/>
        <location filename="../gui/optionsdialog.ui" line="3122"/>
        <location filename="../gui/optionsdialog.ui" line="3286"/>
        <source>Password:</source>
        <translation>パスワード:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1288"/>
        <source>Enabled protocol:</source>
        <translation>有効なプロトコル:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1296"/>
        <source>TCP and μTP</source>
        <translation>TCP および μTP</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1316"/>
        <source>Listening Port</source>
        <translation>待ち受けポート</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1324"/>
        <source>Port used for incoming connections:</source>
        <translation>着信接続で使用するポート:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1344"/>
        <source>Random</source>
        <translation>ランダム</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1366"/>
        <source>Use UPnP / NAT-PMP port forwarding from my router</source>
        <translation>ルーターからのポート転送に UPnP / NAT-PMP を使用する</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1376"/>
        <source>Use different port on each startup</source>
        <translation>起動時に毎回異なるポートを使用する</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1386"/>
        <source>Connections Limits</source>
        <translation>接続制限</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1402"/>
        <source>Maximum number of connections per torrent:</source>
        <translation>Torrent あたりの最大接続数:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1412"/>
        <source>Global maximum number of connections:</source>
        <translation>全体の最大接続数:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1451"/>
        <source>Maximum number of upload slots per torrent:</source>
        <translation>Torrent あたりの最大アップロードスロット数:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1461"/>
        <source>Global maximum number of upload slots:</source>
        <translation>全体の最大アップロードスロット数:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1500"/>
        <source>Proxy Server</source>
        <translation>プロキシサーバー</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1508"/>
        <source>Type:</source>
        <translation>種類:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1516"/>
        <source>(None)</source>
        <translation>(なし)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1521"/>
        <source>SOCKS4</source>
        <translation>SOCKS4</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1526"/>
        <source>SOCKS5</source>
        <translation>SOCKS5</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1531"/>
        <source>HTTP</source>
        <translation>HTTP</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1542"/>
        <source>Host:</source>
        <translation>ホスト:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1562"/>
        <location filename="../gui/optionsdialog.ui" line="2928"/>
        <source>Port:</source>
        <translation>ポート:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1590"/>
        <source>Otherwise, the proxy server is only used for tracker connections</source>
        <translation>このオプションを有効にしない場合、プロキシはトラッカーとの接続のみに使用されます</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1593"/>
        <source>Use proxy for peer connections</source>
        <translation>ピアとの接続にプロキシを使用する</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1602"/>
        <source>Disable connections not supported by proxies</source>
        <translation>プロキシでサポートされていない接続は無効にする</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1612"/>
        <source>(&lt;a href=&quot;https://github.com/qbittorrent/qBittorrent/wiki/Disable-connections-not-supported-by-proxies&quot;&gt;More information&lt;/a&gt;)</source>
        <translation>(&lt;a href=&quot;https://github.com/qbittorrent/qBittorrent/wiki/Disable-connections-not-supported-by-proxies&quot;&gt;詳細情報&lt;/a&gt;)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1637"/>
        <source>RSS feeds, search engine, software updates or anything else other than torrent transfers and related operations (such as peer exchanges) will use a direct connection</source>
        <translation>RSS フィード、検索エンジン、ソフトウェアアップデートやその他 Torrent の転送および関連処理 (ピア交換など) に関係しない通信ではプロキシを使用しません</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1640"/>
        <source>Use proxy only for torrents</source>
        <translation>Torrent に対してのみプロキシを利用する</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1653"/>
        <source>A&amp;uthentication</source>
        <translation>認証(&amp;U)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1693"/>
        <source>Info: The password is saved unencrypted</source>
        <translation>注意: パスワードは暗号化されません</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1714"/>
        <source>Filter path (.dat, .p2p, .p2b):</source>
        <translation>フィルターパス (.dat, .p2p, .p2b):</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1730"/>
        <source>Reload the filter</source>
        <translation>フィルターの再読み込み</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1745"/>
        <source>Manually banned IP addresses...</source>
        <translation>手動で BAN した IP アドレス...</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1752"/>
        <source>Apply to trackers</source>
        <translation>トラッカーにも適用する</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1810"/>
        <source>Global Rate Limits</source>
        <translation>全体の速度制限</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1816"/>
        <location filename="../gui/optionsdialog.ui" line="1832"/>
        <location filename="../gui/optionsdialog.ui" line="1887"/>
        <location filename="../gui/optionsdialog.ui" line="2017"/>
        <source>∞</source>
        <translation>∞</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1819"/>
        <location filename="../gui/optionsdialog.ui" line="1835"/>
        <location filename="../gui/optionsdialog.ui" line="1890"/>
        <location filename="../gui/optionsdialog.ui" line="2020"/>
        <location filename="../gui/optionsdialog.ui" line="2405"/>
        <location filename="../gui/optionsdialog.ui" line="2418"/>
        <source> KiB/s</source>
        <translation> KiB/s</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1864"/>
        <location filename="../gui/optionsdialog.ui" line="2046"/>
        <source>Upload:</source>
        <translation>アップロード:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1871"/>
        <location filename="../gui/optionsdialog.ui" line="2053"/>
        <source>Download:</source>
        <translation>ダウンロード:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1881"/>
        <source>Alternative Rate Limits</source>
        <translation>代替速度制限</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1162"/>
        <location filename="../gui/optionsdialog.ui" line="1918"/>
        <source>From:</source>
        <extracomment>from (time1 to time2)</extracomment>
        <translation>開始:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1142"/>
        <location filename="../gui/optionsdialog.ui" line="1942"/>
        <source>To:</source>
        <extracomment>time1 to time2</extracomment>
        <translation>終了:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1969"/>
        <source>When:</source>
        <translation>曜日:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1983"/>
        <source>Every day</source>
        <translation>毎日</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1988"/>
        <source>Weekdays</source>
        <translation>平日</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1993"/>
        <source>Weekends</source>
        <translation>週末</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2063"/>
        <source>Rate Limits Settings</source>
        <translation>速度制限設定</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2083"/>
        <source>Apply rate limit to peers on LAN</source>
        <translation>LAN 上のピアに対しても速度制限を適用する</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2076"/>
        <source>Apply rate limit to transport overhead</source>
        <translation>トランスポートオーバーヘッドにも制限を適用する</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2069"/>
        <source>Apply rate limit to µTP protocol</source>
        <translation>速度制限を µTP プロトコルにも適用する</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2141"/>
        <source>Privacy</source>
        <translation>プライバシー</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2147"/>
        <source>Enable DHT (decentralized network) to find more peers</source>
        <translation>より多くのピアを見つけるため DHT (分散ネットワーク) を有効にする</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2157"/>
        <source>Exchange peers with compatible Bittorrent clients (µTorrent, Vuze, ...)</source>
        <translation>Bittorrent 互換クライアント (µTorrent, Vuze など) とピア情報を交換します</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2160"/>
        <source>Enable Peer Exchange (PeX) to find more peers</source>
        <translation>より多くのピアを見つけるためにピア交換 (PeX) を有効にする</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2170"/>
        <source>Look for peers on your local network</source>
        <translation>ローカルネットワーク内のピアも探します</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2173"/>
        <source>Enable Local Peer Discovery to find more peers</source>
        <translation>より多くのピアを見つけるためにローカルピア検出 (LSD) を有効にする</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2185"/>
        <source>Encryption mode:</source>
        <translation>暗号化モード:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2193"/>
        <source>Prefer encryption</source>
        <translation>暗号化を許可</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2198"/>
        <source>Require encryption</source>
        <translation>暗号化を強制</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2203"/>
        <source>Disable encryption</source>
        <translation>暗号化しない</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2228"/>
        <source>Enable when using a proxy or a VPN connection</source>
        <translation>プロキシまたは VPN 接続を使用する場合有効にします</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2231"/>
        <source>Enable anonymous mode</source>
        <translation>匿名モードを有効にする</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2281"/>
        <source>Maximum active downloads:</source>
        <translation>最大アクティブダウンロード数:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2301"/>
        <source>Maximum active uploads:</source>
        <translation>最大アクティブアップロード数:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2321"/>
        <source>Maximum active torrents:</source>
        <translation>最大アクティブ Torrent 数:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2380"/>
        <source>Do not count slow torrents in these limits</source>
        <translation>遅い Torrent はカウントしない</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2431"/>
        <source>Upload rate threshold:</source>
        <translation>アップロード速度しきい値:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2438"/>
        <source>Download rate threshold:</source>
        <translation>ダウンロード速度しきい値:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2471"/>
        <source> sec</source>
        <extracomment>seconds</extracomment>
        <translation> 秒</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2487"/>
        <source>Torrent inactivity timer:</source>
        <translation>Torrent 非活動時間:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2500"/>
        <source>Share Ratio Limiting</source>
        <translation>共有比上限</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2506"/>
        <source>Seed torrents until their ratio reaches</source>
        <translation>指定共有比に達するまでシードする</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2526"/>
        <source>then</source>
        <translation>達したら</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2627"/>
        <source>Pause them</source>
        <translation>停止する</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2632"/>
        <source>Remove them</source>
        <translation>削除する</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2950"/>
        <source>Use UPnP / NAT-PMP to forward the port from my router</source>
        <translation>ルーターからのポート転送に UPnP / NAT-PMP を使用する</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2975"/>
        <source>Certificate:</source>
        <translation>証明書:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2987"/>
        <source>Import SSL Certificate</source>
        <translation>SSL 証明書をインポート</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3012"/>
        <source>Key:</source>
        <translation>公開鍵:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3024"/>
        <source>Import SSL Key</source>
        <translation>SSL 公開鍵をインポート</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3046"/>
        <source>&lt;a href=https://httpd.apache.org/docs/current/ssl/ssl_faq.html#aboutcerts&gt;Information about certificates&lt;/a&gt;</source>
        <translation>&lt;a href=https://httpd.apache.org/docs/current/ssl/ssl_faq.html#aboutcerts&gt;証明書について&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3081"/>
        <source>Change current password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3132"/>
        <source>Use alternative Web UI</source>
        <translation>独自の Web UI を使用する</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3144"/>
        <source>Files location:</source>
        <translation>ファイルの場所:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3157"/>
        <source>Security</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3163"/>
        <source>Enable clickjacking protection</source>
        <translation>クリックジャッキング保護を有効にする</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3170"/>
        <source>Enable Cross-Site Request Forgery (CSRF) protection</source>
        <translation>クロスサイトリクエストフォージェリ (CSRF) 保護を有効にする</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3177"/>
        <source>Enable Host header validation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3226"/>
        <source>Service:</source>
        <translation>サービス:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3249"/>
        <source>Register</source>
        <translation>登録</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3258"/>
        <source>Domain name:</source>
        <translation>ドメイン名:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="149"/>
        <source>By enabling these options, you can &lt;strong&gt;irrevocably lose&lt;/strong&gt; your .torrent files!</source>
        <translation>これらのオプションによる .torrent ファイルの削除は &lt;strong&gt;後で取り消せません&lt;/strong&gt;!</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="151"/>
        <source>When these options are enabled, qBittorent will &lt;strong&gt;delete&lt;/strong&gt; .torrent files after they were successfully (the first option) or not (the second option) added to its download queue. This will be applied &lt;strong&gt;not only&lt;/strong&gt; to the files opened via &amp;ldquo;Add torrent&amp;rdquo; menu action but to those opened via &lt;strong&gt;file type association&lt;/strong&gt; as well</source>
        <translation>これらのオプションを有効にすると、qBittorent は .torrent ファイルが転送リストに正常に追加されたとき (最初のオプション) あるいはそうでなかったときも (2つめのオプション) .torrent ファイルを &lt;strong&gt;削除します&lt;/strong&gt;。これにはメニューから &amp;ldquo;Torrent を追加&amp;rdquo; したとき&lt;strong&gt;のみならず&lt;/strong&gt;、&lt;strong&gt;ファイルの関連付けによる追加&lt;/strong&gt;も含まれます</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="156"/>
        <source>If you enable the second option (&amp;ldquo;Also when addition is cancelled&amp;rdquo;) the .torrent file &lt;strong&gt;will be deleted&lt;/strong&gt; even if you press &amp;ldquo;&lt;strong&gt;Cancel&lt;/strong&gt;&amp;rdquo; in the &amp;ldquo;Add torrent&amp;rdquo; dialog</source>
        <translation>2つめのオプション (&amp;ldquo;追加をキャンセルしたときも削除する&amp;rdquo;) を有効にすると、&amp;ldquo;Torrent の追加&amp;rdquo; ダイアログで &amp;ldquo;&lt;strong&gt;キャンセル&lt;/strong&gt;&amp;rdquo; ボタンを押したときも .torrent ファイルを&lt;strong&gt;削除します&lt;/strong&gt;</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="213"/>
        <source>Choose Alternative UI files location</source>
        <translation>独自 UI ファイルの場所の選択</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="305"/>
        <source>Supported parameters (case sensitive):</source>
        <translation>サポートパラメーター (大文字小文字を区別):</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="306"/>
        <source>%N: Torrent name</source>
        <translation>%N: Torrent 名</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="307"/>
        <source>%L: Category</source>
        <translation>%L: カテゴリ</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="308"/>
        <source>%G: Tags (seperated by comma)</source>
        <translation>%G: タグ (コンマ区切り)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="309"/>
        <source>%F: Content path (same as root path for multifile torrent)</source>
        <translation>%F: コンテンツパス (Torrent 内ファイルのルート)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="310"/>
        <source>%R: Root path (first torrent subdirectory path)</source>
        <translation>%R: ルートパス (最初の Torrent のパス)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="311"/>
        <source>%D: Save path</source>
        <translation>%D: 保存パス</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="312"/>
        <source>%C: Number of files</source>
        <translation>%C: ファイル数</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="313"/>
        <source>%Z: Torrent size (bytes)</source>
        <translation>%Z: Torrent サイズ (バイト)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="314"/>
        <source>%T: Current tracker</source>
        <translation>%T: 現在のトラッカー</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="315"/>
        <source>%I: Info hash</source>
        <translation>%I: 情報ハッシュ</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="316"/>
        <source>Tip: Encapsulate parameter with quotation marks to avoid text being cut off at whitespace (e.g., &quot;%N&quot;)</source>
        <translation>ヒント: パラメーターに空白が含まれるときはダブルクオーテーションで括ってください (例: &quot;%N&quot;)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="385"/>
        <source>A torrent will be considered slow if its download and upload rates stay below these values for &quot;Torrent inactivity timer&quot; seconds</source>
        <translation>Torrent のダウンロードおよびアップロード速度が &quot;Torrent 非活動時間&quot; (秒) の間これらの値以下であれば、遅い Torrent とみなされます</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1481"/>
        <source>Select folder to monitor</source>
        <translation>監視フォルダーの選択</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1488"/>
        <source>Folder is already being monitored:</source>
        <translation>フォルダーはすでに監視されています:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1491"/>
        <source>Folder does not exist:</source>
        <translation>フォルダーが存在しません:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1494"/>
        <source>Folder is not readable:</source>
        <translation>フォルダーが読み込み不可です:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1505"/>
        <source>Adding entry failed</source>
        <translation>エントリ追加に失敗しました</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1765"/>
        <source>Location Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1765"/>
        <source>The alternative Web UI files location cannot be blank.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="439"/>
        <location filename="../gui/optionsdialog.cpp" line="442"/>
        <location filename="../gui/optionsdialog.cpp" line="1533"/>
        <location filename="../gui/optionsdialog.cpp" line="1535"/>
        <source>Choose export directory</source>
        <translation>エクスポートディレクトリの選択</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="436"/>
        <location filename="../gui/optionsdialog.cpp" line="449"/>
        <location filename="../gui/optionsdialog.cpp" line="452"/>
        <source>Choose a save directory</source>
        <translation>保存ディレクトリの選択</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="445"/>
        <source>Choose an IP filter file</source>
        <translation>IP フィルターファイルの選択</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="446"/>
        <source>All supported filters</source>
        <translation>サポートされている全フィルター</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1569"/>
        <source>SSL Certificate</source>
        <translation>SSL 証明書</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1619"/>
        <source>Parsing error</source>
        <translation>解析エラー</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1619"/>
        <source>Failed to parse the provided IP filter</source>
        <translation>与えられた IP フィルターの解析に失敗しました</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1621"/>
        <source>Successfully refreshed</source>
        <translation>正常にリフレッシュされました</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1621"/>
        <source>Successfully parsed the provided IP filter: %1 rules were applied.</source>
        <comment>%1 is a number</comment>
        <translation>提供された IP フィルターは正常に解析されました: %1 個のルールが適用されました。</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1594"/>
        <source>Invalid key</source>
        <translation>不正な鍵</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1594"/>
        <source>This is not a valid SSL key.</source>
        <translation>これは正常な SSL 鍵ではありません。</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1579"/>
        <source>Invalid certificate</source>
        <translation>不正な証明書</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="114"/>
        <source>Preferences</source>
        <translation>設定</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1569"/>
        <source>Import SSL certificate</source>
        <translation>SSL 証明書のインポート</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1579"/>
        <source>This is not a valid SSL certificate.</source>
        <translation>これは正常な SSL 証明書ではありません。</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1584"/>
        <source>Import SSL key</source>
        <translation>SSL キーのインポート</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1584"/>
        <source>SSL key</source>
        <translation>SSL キー</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1743"/>
        <source>Time Error</source>
        <translation>時刻エラー</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1743"/>
        <source>The start time and the end time can&apos;t be the same.</source>
        <translation>開始時刻と終了時刻は同じにできません。</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1752"/>
        <location filename="../gui/optionsdialog.cpp" line="1756"/>
        <source>Length Error</source>
        <translation>短すぎエラー</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1752"/>
        <source>The Web UI username must be at least 3 characters long.</source>
        <translation>Web UI のユーザー名は 3 文字以上にしてください。</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1756"/>
        <source>The Web UI password must be at least 6 characters long.</source>
        <translation>Web UI のパスワードは 6 文字以上にしてください。</translation>
    </message>
</context>
<context>
    <name>PeerInfo</name>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="283"/>
        <source>Interested(local) and Choked(peer)</source>
        <translation>インタレスト (ローカル)/チョーク(ピア)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="289"/>
        <source>interested(local) and unchoked(peer)</source>
        <translation>Dインタレスト(ローカル)/非チョーク(ピア)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="298"/>
        <source>interested(peer) and choked(local)</source>
        <translation>インタレスト(ピア)/チョーク(ローカル)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="304"/>
        <source>interested(peer) and unchoked(local)</source>
        <translation>インタレスト(ピア)/非チョーク(ローカル)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="312"/>
        <source>optimistic unchoke</source>
        <translation>楽観的非チョーク</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="319"/>
        <source>peer snubbed</source>
        <translation>ピアがスナッブ状態</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="326"/>
        <source>incoming connection</source>
        <translation>ピアが着信接続</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="333"/>
        <source>not interested(local) and unchoked(peer)</source>
        <translation>非インタレスト(ローカル)/非チョーク(ピア)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="340"/>
        <source>not interested(peer) and unchoked(local)</source>
        <translation>非インタレスト(ピア)/非チョーク(ローカル)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="347"/>
        <source>peer from PEX</source>
        <translation>PEX から取得したピア</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="354"/>
        <source>peer from DHT</source>
        <translation>DHT から取得したピア</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="361"/>
        <source>encrypted traffic</source>
        <translation>暗号化トラフィック</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="368"/>
        <source>encrypted handshake</source>
        <translation>暗号化ハンドシェイク</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="382"/>
        <source>peer from LSD</source>
        <translation>LSD から取得したピア</translation>
    </message>
</context>
<context>
    <name>PeerListWidget</name>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="73"/>
        <source>IP</source>
        <translation>IP</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="74"/>
        <source>Port</source>
        <translation>ポート</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="75"/>
        <source>Flags</source>
        <translation>フラグ</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="76"/>
        <source>Connection</source>
        <translation>接続</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="77"/>
        <source>Client</source>
        <comment>i.e.: Client application</comment>
        <translation>クライアント</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="78"/>
        <source>Progress</source>
        <comment>i.e: % downloaded</comment>
        <translation>進行状況</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="79"/>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>DL 速度</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="80"/>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>UP 速度</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="81"/>
        <source>Downloaded</source>
        <comment>i.e: total data downloaded</comment>
        <translation>DL 量</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="82"/>
        <source>Uploaded</source>
        <comment>i.e: total data uploaded</comment>
        <translation>UP 量</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="83"/>
        <source>Relevance</source>
        <comment>i.e: How relevant this peer is to us. How many pieces it has that we don&apos;t.</comment>
        <translation>関連性</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="84"/>
        <source>Files</source>
        <comment>i.e. files that are being downloaded right now</comment>
        <translation>ファイル</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="159"/>
        <source>Column visibility</source>
        <translation>表示するカラム</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="235"/>
        <source>Add a new peer...</source>
        <translation>新しいピアの追加...</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="243"/>
        <location filename="../gui/properties/peerlistwidget.cpp" line="282"/>
        <source>Ban peer permanently</source>
        <translation>ピアを永久にアクセス禁止にする</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="256"/>
        <source>Manually adding peer &apos;%1&apos;...</source>
        <translation>ピア &apos;%1&apos; を手動で追加しています...</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="260"/>
        <source>The peer &apos;%1&apos; could not be added to this torrent.</source>
        <translation>ピア &apos;%1&apos;をこの Torrent に追加できませんでした。</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="292"/>
        <source>Manually banning peer &apos;%1&apos;...</source>
        <translation>ピア &apos;%1&apos; を BANしています...</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="264"/>
        <location filename="../gui/properties/peerlistwidget.cpp" line="266"/>
        <source>Peer addition</source>
        <translation>ピアの追加</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="72"/>
        <source>Country</source>
        <translation>国</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="241"/>
        <source>Copy IP:port</source>
        <translation>IP:ポートをコピー</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="264"/>
        <source>Some peers could not be added. Check the Log for details.</source>
        <translation>一部のピアは追加できませんでした。詳細はログを参照してください。</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="266"/>
        <source>The peers were added to this torrent.</source>
        <translation>ピアをこの Torrent に追加しました。</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="282"/>
        <source>Are you sure you want to ban permanently the selected peers?</source>
        <translation>選択したピアを永久に BAN してよろしいですか?</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="283"/>
        <source>&amp;Yes</source>
        <translation>はい(&amp;Y)</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="283"/>
        <source>&amp;No</source>
        <translation>いいえ(&amp;N)</translation>
    </message>
</context>
<context>
    <name>PeersAdditionDialog</name>
    <message>
        <location filename="../gui/properties/peersadditiondialog.ui" line="14"/>
        <source>Add Peers</source>
        <translation>ピアの追加</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondialog.ui" line="20"/>
        <source>List of peers to add (one IP per line):</source>
        <translation>追加するピアのリスト (1 行に 1 IP):</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondialog.ui" line="33"/>
        <source>Format: IPv4:port / [IPv6]:port</source>
        <translation>形式: IPv4:ポート / [IPv6]:ポート</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondialog.cpp" line="60"/>
        <source>No peer entered</source>
        <translation>ピアが入力されていません</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondialog.cpp" line="61"/>
        <source>Please type at least one peer.</source>
        <translation>1 個以上のピアを入力してください。</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondialog.cpp" line="71"/>
        <source>Invalid peer</source>
        <translation>不正なピア</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondialog.cpp" line="72"/>
        <source>The peer &apos;%1&apos; is invalid.</source>
        <translation>ピア &apos;%1&apos; は正しくありません。</translation>
    </message>
</context>
<context>
    <name>PieceAvailabilityBar</name>
    <message>
        <location filename="../gui/properties/pieceavailabilitybar.cpp" line="161"/>
        <source>White: Unavailable pieces</source>
        <translation>白: 利用できないピース</translation>
    </message>
    <message>
        <location filename="../gui/properties/pieceavailabilitybar.cpp" line="162"/>
        <source>Blue: Available pieces</source>
        <translation>青: 利用可能なピース</translation>
    </message>
</context>
<context>
    <name>PiecesBar</name>
    <message>
        <location filename="../gui/properties/piecesbar.cpp" line="266"/>
        <source>Files in this piece:</source>
        <translation>このピースに含まれるファイル:</translation>
    </message>
    <message>
        <location filename="../gui/properties/piecesbar.cpp" line="270"/>
        <source>File in this piece</source>
        <translation>このピースに含まれるファイル</translation>
    </message>
    <message>
        <location filename="../gui/properties/piecesbar.cpp" line="272"/>
        <source>File in these pieces</source>
        <translation>これらのピースに含まれるファイル</translation>
    </message>
    <message>
        <location filename="../gui/properties/piecesbar.cpp" line="291"/>
        <source>Wait until metadata become available to see detailed information</source>
        <translation>メタデータから詳細情報を得られるまで待っています</translation>
    </message>
    <message>
        <location filename="../gui/properties/piecesbar.cpp" line="293"/>
        <source>Hold Shift key for detailed information</source>
        <translation>Shift キーを押すと詳細情報を表示します</translation>
    </message>
</context>
<context>
    <name>PluginSelectDialog</name>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="17"/>
        <source>Search plugins</source>
        <translation>検索エンジン</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="30"/>
        <source>Installed search plugins:</source>
        <translation>インストールされている検索プラグイン:</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="53"/>
        <source>Name</source>
        <translation>名前</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="58"/>
        <source>Version</source>
        <translation>バージョン</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="63"/>
        <source>Url</source>
        <translation>URL</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="68"/>
        <location filename="../gui/search/pluginselectdialog.ui" line="134"/>
        <source>Enabled</source>
        <translation>有効</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="81"/>
        <source>Warning: Be sure to comply with your country&apos;s copyright laws when downloading torrents from any of these search engines.</source>
        <translation>警告: これら検索エンジンから Torrent をダウンロードする際は、あなたの国の法を遵守していることを必ず確認してください。</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="96"/>
        <source>You can get new search engine plugins here: &lt;a href=&quot;http://plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</source>
        <translation>新しい検索プラグインはここから入手できます: &lt;a href=&quot;http://plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="108"/>
        <source>Install a new one</source>
        <translation>新しいものをインストール</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="115"/>
        <source>Check for updates</source>
        <translation>更新をチェック</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="122"/>
        <source>Close</source>
        <translation>閉じる</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="139"/>
        <source>Uninstall</source>
        <translation>アンインストール</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="159"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="221"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="280"/>
        <source>Yes</source>
        <translation>はい</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="163"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="202"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="225"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="284"/>
        <source>No</source>
        <translation>いいえ</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="208"/>
        <source>Uninstall warning</source>
        <translation>アンインストール警告</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="208"/>
        <source>Some plugins could not be uninstalled because they are included in qBittorrent. Only the ones you added yourself can be uninstalled.
Those plugins were disabled.</source>
        <translation>一部のプラグインは qBittorrent 自体に含まれているためアンインストールできません。アンインストールできるのはあなた自身で追加したものだけです。
以下のプラグインが無効になりました。</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="210"/>
        <source>Uninstall success</source>
        <translation>アンインストール成功</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="210"/>
        <source>All selected plugins were uninstalled successfully</source>
        <translation>選択された全プラグインは正常にアンインストールされました</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="323"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="422"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="436"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="468"/>
        <source>Search plugin update</source>
        <translation>検索エンジンの更新</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="323"/>
        <source>Plugins installed or updated: %1</source>
        <translation>プラグインはインストールまたは更新されました: %1</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="343"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="350"/>
        <source>New search engine plugin URL</source>
        <translation>新規検索エンジンプラグイン URL</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="344"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="351"/>
        <source>URL:</source>
        <translation>URL:</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="348"/>
        <source>Invalid link</source>
        <translation>不正なリンク</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="348"/>
        <source>The link doesn&apos;t seem to point to a search engine plugin.</source>
        <translation>リンクは検索エンジンプラグインを示していないようです。</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="364"/>
        <source>Select search plugins</source>
        <translation>検索プラグインの選択</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="365"/>
        <source>qBittorrent search plugin</source>
        <translation>qBittorrent 検索プラグイン</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="422"/>
        <source>All your plugins are already up to date.</source>
        <translation>全プラグインは最新です。</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="436"/>
        <source>Sorry, couldn&apos;t check for plugin updates. %1</source>
        <translation>プラグインの更新チェックができませんでした: %1</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="450"/>
        <source>Search plugin install</source>
        <translation>検索プラグインのインストール</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="451"/>
        <source>Couldn&apos;t install &quot;%1&quot; search engine plugin. %2</source>
        <translation>&quot;%1&quot; 検索エンジンプラグインをインストールできませんでした。%2</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="469"/>
        <source>Couldn&apos;t update &quot;%1&quot; search engine plugin. %2</source>
        <translation>&quot;%1&quot; 検索エンジンプラグインを更新できませんでした。%2</translation>
    </message>
</context>
<context>
    <name>PluginSourceDialog</name>
    <message>
        <location filename="../gui/search/pluginsourcedialog.ui" line="14"/>
        <source>Plugin source</source>
        <translation>プラグインのソース</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginsourcedialog.ui" line="27"/>
        <source>Search plugin source:</source>
        <translation>検索プラグインのソース:</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginsourcedialog.ui" line="36"/>
        <source>Local file</source>
        <translation>ローカルファイル</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginsourcedialog.ui" line="43"/>
        <source>Web link</source>
        <translation>ウェブリンク</translation>
    </message>
</context>
<context>
    <name>PowerManagement</name>
    <message>
        <location filename="../gui/powermanagement/powermanagement.cpp" line="77"/>
        <source>qBittorrent is active</source>
        <translation>qBittorrent は動作中です</translation>
    </message>
</context>
<context>
    <name>PreviewSelectDialog</name>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="55"/>
        <source>Preview</source>
        <translation>プレビュー</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="62"/>
        <source>Name</source>
        <translation>名前</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="63"/>
        <source>Size</source>
        <translation>サイズ</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="64"/>
        <source>Progress</source>
        <translation>進捗状況</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="97"/>
        <location filename="../gui/previewselectdialog.cpp" line="142"/>
        <source>Preview impossible</source>
        <translation>プレビュー不可</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="97"/>
        <location filename="../gui/previewselectdialog.cpp" line="142"/>
        <source>Sorry, we can&apos;t preview this file</source>
        <translation>すみません、このファイルをプレビューできません</translation>
    </message>
</context>
<context>
    <name>Private::FileLineEdit</name>
    <message>
        <location filename="../gui/fspathedit_p.cpp" line="305"/>
        <source>&apos;%1&apos; does not exist</source>
        <translation>&apos;%1&apos; は存在しません</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit_p.cpp" line="307"/>
        <source>&apos;%1&apos; does not point to a directory</source>
        <translation>&apos;%1&apos; はディレクトリではありません</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit_p.cpp" line="309"/>
        <source>&apos;%1&apos; does not point to a file</source>
        <translation>&apos;%1&apos; はファイルではありません</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit_p.cpp" line="311"/>
        <source>Does not have read permission in &apos;%1&apos;</source>
        <translation>&apos;%1&apos; の読み込み権がありません</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit_p.cpp" line="313"/>
        <source>Does not have write permission in &apos;%1&apos;</source>
        <translation>&apos;%1&apos; への書き込み権がありません</translation>
    </message>
</context>
<context>
    <name>PropListDelegate</name>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="119"/>
        <source>Not downloaded</source>
        <translation>ダウンロードしない</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="128"/>
        <location filename="../gui/properties/proplistdelegate.cpp" line="190"/>
        <source>Normal</source>
        <comment>Normal (priority)</comment>
        <translation>通常</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="137"/>
        <source>N/A</source>
        <translation>N/A</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="189"/>
        <source>Do not download</source>
        <comment>Do not download (priority)</comment>
        <translation>ダウンロードしない</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="122"/>
        <location filename="../gui/properties/proplistdelegate.cpp" line="191"/>
        <source>High</source>
        <comment>High (priority)</comment>
        <translation>高い</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="116"/>
        <source>Mixed</source>
        <comment>Mixed (priorities</comment>
        <translation>混在</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="125"/>
        <location filename="../gui/properties/proplistdelegate.cpp" line="192"/>
        <source>Maximum</source>
        <comment>Maximum (priority)</comment>
        <translation>最高</translation>
    </message>
</context>
<context>
    <name>PropTabBar</name>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="51"/>
        <source>General</source>
        <translation>全般</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="60"/>
        <source>Trackers</source>
        <translation>トラッカー</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="69"/>
        <source>Peers</source>
        <translation>ピア</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="78"/>
        <source>HTTP Sources</source>
        <translation>HTTP ソース</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="87"/>
        <source>Content</source>
        <translation>コンテンツ</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="98"/>
        <source>Speed</source>
        <translation>速度</translation>
    </message>
</context>
<context>
    <name>PropertiesWidget</name>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="330"/>
        <source>Downloaded:</source>
        <translation>ダウンロード量:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="107"/>
        <source>Availability:</source>
        <translation>可用性:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="78"/>
        <source>Progress:</source>
        <translation>進行状況:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="154"/>
        <source>Transfer</source>
        <translation>転送</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="546"/>
        <source>Time Active:</source>
        <extracomment>Time (duration) the torrent is active (not paused)</extracomment>
        <translation>動作時間:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="575"/>
        <source>ETA:</source>
        <translation>予想残り時間:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="504"/>
        <source>Uploaded:</source>
        <translation>アップロード量:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="433"/>
        <source>Seeds:</source>
        <translation>シード数:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="449"/>
        <source>Download Speed:</source>
        <translation>ダウンロード速度:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="185"/>
        <source>Upload Speed:</source>
        <translation>アップロード速度:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="214"/>
        <source>Peers:</source>
        <translation>ピア数:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="272"/>
        <source>Download Limit:</source>
        <translation>ダウンロード速度制限:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="346"/>
        <source>Upload Limit:</source>
        <translation>アップロード速度制限:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="591"/>
        <source>Wasted:</source>
        <translation>破棄:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="230"/>
        <source>Connections:</source>
        <translation>接続数:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="604"/>
        <source>Information</source>
        <translation>情報</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="863"/>
        <source>Comment:</source>
        <translation>コメント:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1023"/>
        <source>Select All</source>
        <translation>すべて選択</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1030"/>
        <source>Select None</source>
        <translation>すべて解除</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1106"/>
        <source>Normal</source>
        <translation>通常</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1101"/>
        <source>High</source>
        <translation>高い</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="288"/>
        <source>Share Ratio:</source>
        <translation>共有比:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="404"/>
        <source>Reannounce In:</source>
        <translation>次のアナウンスまで:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="362"/>
        <source>Last Seen Complete:</source>
        <translation>最後に完了ファイルを確認した日時:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="622"/>
        <source>Total Size:</source>
        <translation>全体サイズ:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="651"/>
        <source>Pieces:</source>
        <translation>ピース数:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="680"/>
        <source>Created By:</source>
        <translation>作成:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="709"/>
        <source>Added On:</source>
        <translation>追加日時:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="738"/>
        <source>Completed On:</source>
        <translation>完了日時:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="767"/>
        <source>Created On:</source>
        <translation>作成日時:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="796"/>
        <source>Torrent Hash:</source>
        <translation>Torrent ハッシュ:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="828"/>
        <source>Save Path:</source>
        <translation>保存パス:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1096"/>
        <source>Maximum</source>
        <translation>最高</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1088"/>
        <location filename="../gui/properties/propertieswidget.ui" line="1091"/>
        <source>Do not download</source>
        <translation>ダウンロードしない</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="454"/>
        <source>Never</source>
        <translation>なし</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="461"/>
        <source>%1 x %2 (have %3)</source>
        <comment>(torrent pieces) eg 152 x 4MB (have 25)</comment>
        <translation>%1 x %2 (保有 %3)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="404"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="407"/>
        <source>%1 (%2 this session)</source>
        <translation>%1 (%2 このセッション)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="416"/>
        <source>%1 (seeded for %2)</source>
        <comment>e.g. 4m39s (seeded for 3m10s)</comment>
        <translation>%1 (シード時間 %2)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="423"/>
        <source>%1 (%2 max)</source>
        <comment>%1 and %2 are numbers, e.g. 3 (10 max)</comment>
        <translation>%1 (最大 %2)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="436"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="440"/>
        <source>%1 (%2 total)</source>
        <comment>%1 and %2 are numbers, e.g. 3 (10 total)</comment>
        <translation>%1 (合計 %2)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="446"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="451"/>
        <source>%1 (%2 avg.)</source>
        <comment>%1 and %2 are speed rates, e.g. 200KiB/s (100KiB/s avg.)</comment>
        <translation>%1 (平均 %2)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="594"/>
        <source>Open</source>
        <translation>開く</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="595"/>
        <source>Open Containing Folder</source>
        <translation>含まれているフォルダーを開く</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="596"/>
        <source>Rename...</source>
        <translation>名前の変更...</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="601"/>
        <source>Priority</source>
        <translation>優先度</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="649"/>
        <source>New Web seed</source>
        <translation>新規ウェブシード</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="655"/>
        <source>Remove Web seed</source>
        <translation>ウェブシードの削除</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="657"/>
        <source>Copy Web seed URL</source>
        <translation>ウェブシード URL のコピー</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="658"/>
        <source>Edit Web seed URL</source>
        <translation>ウェブシード URL の編集</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="687"/>
        <source>New name:</source>
        <translation>新しい名前:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="721"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="759"/>
        <source>This name is already in use in this folder. Please use a different name.</source>
        <translation>この名前はこのフォルダー内ですでに使われています。別の名前をつけてください。</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="758"/>
        <source>The folder could not be renamed</source>
        <translation>フォルダー名を変更できませんでした</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="816"/>
        <source>&lt;center&gt;&lt;b&gt;Speed graphs are disabled&lt;/b&gt;&lt;p&gt;You may change this setting in Advanced Options &lt;/center&gt;</source>
        <translation>&lt;center&gt;&lt;b&gt;速度グラフは無効になっています&lt;/b&gt;&lt;p&gt;この設定は詳細オプションから変更できます &lt;/center&gt;</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="885"/>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="92"/>
        <source>Filter files...</source>
        <translation>ファイルをフィルター...</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="687"/>
        <source>Renaming</source>
        <translation>名前の変更</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="692"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="720"/>
        <source>Rename error</source>
        <translation>変名エラー</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="693"/>
        <source>The name is empty or contains forbidden characters, please choose a different one.</source>
        <translation>名前が入力されていないか使用できない文字が含まれています。ほかの名前を入力してください。</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="828"/>
        <source>New URL seed</source>
        <comment>New HTTP source</comment>
        <translation>新規 URL シード</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="829"/>
        <source>New URL seed:</source>
        <translation>新規 URL シード:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="835"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="886"/>
        <source>This URL seed is already in the list.</source>
        <translation>この URL シードはすでにリストにあります。</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="879"/>
        <source>Web seed editing</source>
        <translation>ウェブシードの編集</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="880"/>
        <source>Web seed URL:</source>
        <translation>ウェブシード URL:</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../app/main.cpp" line="133"/>
        <source>%1 is an unknown command line parameter.</source>
        <comment>--random-parameter is an unknown command line parameter.</comment>
        <translation>%1 は未知のコマンドラインパラメーターです。</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="143"/>
        <location filename="../app/main.cpp" line="152"/>
        <source>%1 must be the single command line parameter.</source>
        <translation>%1 は 1 個だけ指定できるコマンドラインパラメーターです。</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="175"/>
        <source>You cannot use %1: qBittorrent is already running for this user.</source>
        <translation>%1 を使用できません: qBittorrent はすでに起動しています。</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="520"/>
        <source>Usage:</source>
        <translation>使用法:</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="523"/>
        <source>Options:</source>
        <translation>オプション:</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="157"/>
        <source>Parameter &apos;%1&apos; must follow syntax &apos;%1=%2&apos;</source>
        <comment>e.g. Parameter &apos;--webui-port&apos; must follow syntax &apos;--webui-port=value&apos;</comment>
        <translation>パラメータ &apos;%1&apos; は &apos;%1=%2&apos; のような構文でなければなりません</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="203"/>
        <source>Parameter &apos;%1&apos; must follow syntax &apos;%1=%2&apos;</source>
        <comment>e.g. Parameter &apos;--webui-port&apos; must follow syntax &apos;--webui-port=&lt;value&gt;&apos;</comment>
        <translation>パラメーター &apos;%1&apos; は &apos;%1=%2&apos; のような構文でなければなりません</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="217"/>
        <source>Expected integer number in environment variable &apos;%1&apos;, but got &apos;%2&apos;</source>
        <translation>環境変数 &apos;%1&apos; は正数であることを期待していますが &apos;%2&apos; が得られました</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="270"/>
        <source>Parameter &apos;%1&apos; must follow syntax &apos;%1=%2&apos;</source>
        <comment>e.g. Parameter &apos;--add-paused&apos; must follow syntax &apos;--add-paused=&lt;true|false&gt;&apos;</comment>
        <translation>パラメーター &apos;%1&apos; は &apos;%1=%2&apos; のような構文でなければなりません</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="294"/>
        <source>Expected %1 in environment variable &apos;%2&apos;, but got &apos;%3&apos;</source>
        <translation>環境変数 &apos;%2&apos; は %1 であることを期待していますが &apos;%3; が得られました</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="528"/>
        <source>port</source>
        <translation>ポート番号</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="419"/>
        <source>%1 must specify a valid port (1 to 65535).</source>
        <translation>%1 には正しいポート番号 (1 to 65535) を設定してください。</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="525"/>
        <source>Display program version and exit</source>
        <translation>プログラムのバージョンを表示して終了する</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="527"/>
        <source>Display this help message and exit</source>
        <translation>このヘルプメッセージを表示して終了する</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="529"/>
        <source>Change the Web UI port</source>
        <translation>WebUI のポート番号を変更する</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="532"/>
        <source>Disable splash screen</source>
        <translation>スプラッシュ・スクリーンを表示しません</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="534"/>
        <source>Run in daemon-mode (background)</source>
        <translation>デーモンモード (バックグラウンド) で起動します</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="537"/>
        <source>dir</source>
        <extracomment>Use appropriate short form or abbreviation of &quot;directory&quot;</extracomment>
        <translation>ディレクトリ</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="538"/>
        <source>Store configuration files in &lt;dir&gt;</source>
        <translation>設定ファイルは &lt;dir&gt; に保存されます</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="539"/>
        <location filename="../app/cmdoptions.cpp" line="555"/>
        <source>name</source>
        <translation>名前</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="540"/>
        <source>Store configuration files in directories qBittorrent_&lt;name&gt;</source>
        <translation>設定ファイルはディレクトリ qBittorrent_&lt;name&gt; に保存されます</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="542"/>
        <source>Hack into libtorrent fastresume files and make file paths relative to the profile directory</source>
        <translation>libtorrent の高速再開をハックしファイルをプロファイルディレクトリへの相対パスに作成する</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="547"/>
        <source>files or URLs</source>
        <translation>ファイルまたは URL</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="548"/>
        <source>Download the torrents passed by the user</source>
        <translation>ユーザーから渡された Torrent をダウンロード</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="562"/>
        <source>Specify whether the &quot;Add New Torrent&quot; dialog opens when adding a torrent.</source>
        <translation>Torrent を追加するとき &quot;Torrent の追加&quot; ダイアログを表示するかどうか指定してください。</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="551"/>
        <source>Options when adding new torrents:</source>
        <translation>新規 Torrent を追加したときのオプション:</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="545"/>
        <source>Shortcut for %1</source>
        <comment>Shortcut for --profile=&lt;exe dir&gt;/profile --relative-fastresume</comment>
        <translation>ショートカット %1</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="552"/>
        <source>path</source>
        <translation>パス</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="552"/>
        <source>Torrent save path</source>
        <translation>Torrent 保存パス</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="553"/>
        <source>Add torrents as started or paused</source>
        <translation>追加時に開始するかしないか</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="554"/>
        <source>Skip hash check</source>
        <translation>ハッシュチェックを省略する</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="556"/>
        <source>Assign torrents to category. If the category doesn&apos;t exist, it will be created.</source>
        <translation>Torrent にカテゴリを割り当てる。カテゴリがないときは作成する。</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="558"/>
        <source>Download files in sequential order</source>
        <translation>連番に従ってダウンロード</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="560"/>
        <source>Download first and last pieces first</source>
        <translation>先頭と最後のピースを先にダウンロード</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="566"/>
        <source>Option values may be supplied via environment variables. For option named &apos;parameter-name&apos;, environment variable name is &apos;QBT_PARAMETER_NAME&apos; (in upper case, &apos;-&apos; replaced with &apos;_&apos;). To pass flag values, set the variable to &apos;1&apos; or &apos;TRUE&apos;. For example, to disable the splash screen: </source>
        <translation>オプションの値は環境変数から取られます。オプション名 &apos;parameter-name&apos; の値に対応する環境変数名は  &apos;QBT_PARAMETER_NAME&apos; (大文字、&apos;-&apos; は &apos;_&apos; に置き換え) です。フラグ値を渡す場合は、値に &apos;1&apos; または &apos;TRUE&apos; を指定します。スプラッシュスクリーンを表示しないようにするには: </translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="571"/>
        <source>Command line parameters take precedence over environment variables</source>
        <translation>コマンドラインパラメーターは環境変数より優先されます</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="582"/>
        <source>Help</source>
        <translation>ヘルプ</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="334"/>
        <source>Run application with -h option to read about command line parameters.</source>
        <translation>-h オプションを指定して起動するとコマンドラインパラメーターを表示します。</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="336"/>
        <source>Bad command line</source>
        <translation>不正なコマンドライン</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="342"/>
        <source>Bad command line: </source>
        <translation>不正なコマンドライン: </translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="356"/>
        <source>Legal Notice</source>
        <translation>法的通知</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="357"/>
        <source>qBittorrent is a file sharing program. When you run a torrent, its data will be made available to others by means of upload. Any content you share is your sole responsibility.</source>
        <translation>qBittorrent はファイル共有プログラムです。あなたが Torrent を実行するとき、そのデータはアップロードによって他の誰かが入手できるようになります。コンテンツの共有は、いかなる場合もあなた個人の責任において行ってください。</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="358"/>
        <source>No further notices will be issued.</source>
        <translation>この通知はこれ以降は表示されません。</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="370"/>
        <source>qBittorrent is a file sharing program. When you run a torrent, its data will be made available to others by means of upload. Any content you share is your sole responsibility.

No further notices will be issued.</source>
        <translation>qBittorrent はファイル共有プログラムです。あなたが Torrent を動作させるとき、そのデータはそれがアップロードされることで他人からも利用できるようになります。いかなるコンテンツでもあなたが共有することはあなた個人の責任になります。

これ以上の通知は行われません。</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="359"/>
        <source>Press %1 key to accept and continue...</source>
        <translation>続行するには %1 キーを押してください...</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="371"/>
        <source>Legal notice</source>
        <translation>法的通知</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="372"/>
        <source>Cancel</source>
        <translation>キャンセル</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="373"/>
        <source>I Agree</source>
        <translation>同意する</translation>
    </message>
    <message>
        <location filename="../app/upgrade.h" line="64"/>
        <location filename="../app/upgrade.h" line="78"/>
        <source>Upgrade</source>
        <translation>アップグレード</translation>
    </message>
    <message>
        <location filename="../app/upgrade.h" line="68"/>
        <source>You updated from an older version that saved things differently. You must migrate to the new saving system. You will not be able to use an older version than v3.3.0 again. Continue? [y/n]</source>
        <translation>このアップデートでは、過去のバージョンで保存された情報をこのバージョン用に移行する必要があります。変換を行うと v3.3.0 より古いバージョンで使用することはできなくなります。アップデートしますか? [y/n]</translation>
    </message>
    <message>
        <location filename="../app/upgrade.h" line="77"/>
        <source>You updated from an older version that saved things differently. You must migrate to the new saving system. If you continue, you will not be able to use an older version than v3.3.0 again.</source>
        <translation>このアップデートでは、過去のバージョンで保存された情報をこのバージョン用に移行する必要があります。変換を行うと v3.3.0 より古いバージョンで使用することはできなくなります。</translation>
    </message>
    <message>
        <location filename="../app/upgrade.h" line="210"/>
        <source>Couldn&apos;t migrate torrent with hash: %1</source>
        <translation>Torrent を移行できませんでした。ハッシュ: %1</translation>
    </message>
    <message>
        <location filename="../app/upgrade.h" line="213"/>
        <source>Couldn&apos;t migrate torrent. Invalid fastresume file name: %1</source>
        <translation>Torrent を移行できませんでした。高速再開ファイル名が正しくありません: %1</translation>
    </message>
    <message>
        <location filename="../base/settingsstorage.cpp" line="241"/>
        <source>Detected unclean program exit. Using fallback file to restore settings: %1</source>
        <translation>正常な手順を踏まないプログラム終了が検出されました。フォールバックファイルを使用して設定の復元を行います: %1</translation>
    </message>
    <message>
        <location filename="../base/settingsstorage.cpp" line="308"/>
        <source>An access error occurred while trying to write the configuration file.</source>
        <translation>設定ファイルへの書き込み中にアクセスエラーが発生しました。</translation>
    </message>
    <message>
        <location filename="../base/settingsstorage.cpp" line="311"/>
        <source>A format error occurred while trying to write the configuration file.</source>
        <translation>設定ファイルへの書き込み中にフォーマットエラーが発生しました。</translation>
    </message>
    <message>
        <location filename="../base/settingsstorage.cpp" line="314"/>
        <source>An unknown error occurred while trying to write the configuration file.</source>
        <translation>設定ファイルの書き込み中に未知のエラーが発生しました。</translation>
    </message>
</context>
<context>
    <name>RSS::AutoDownloader</name>
    <message>
        <location filename="../base/rss/rss_autodownloader.cpp" line="81"/>
        <location filename="../base/rss/rss_autodownloader.cpp" line="88"/>
        <source>Invalid data format.</source>
        <translation>不正なデータ形式です。</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_autodownloader.cpp" line="123"/>
        <source>Couldn&apos;t save RSS AutoDownloader data in %1. Error: %2</source>
        <translation>%1 の RSS 自動ダウンローダーを保存できませんでした。エラー: %2</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_autodownloader.cpp" line="277"/>
        <source>Invalid data format</source>
        <translation>不正なデータ形式</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_autodownloader.cpp" line="418"/>
        <source>Couldn&apos;t read RSS AutoDownloader rules from %1. Error: %2</source>
        <translation>%1 からの RSS 自動ダウンローダールールを読み込めませんでした。エラー: %2</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_autodownloader.cpp" line="430"/>
        <source>Couldn&apos;t load RSS AutoDownloader rules. Reason: %1</source>
        <translation>RSS 自動ダウンローダールールを読み込めませんでした。理由: %1</translation>
    </message>
</context>
<context>
    <name>RSS::Feed</name>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="211"/>
        <source>Failed to download RSS feed at &apos;%1&apos;. Reason: %2</source>
        <translation>&apos;%1&apos; の RSS フィードのダウンロードに失敗しました。理由: %2</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="243"/>
        <source>RSS feed at &apos;%1&apos; updated. Added %2 new articles.</source>
        <translation>&apos;%1&apos; のRSS フィードが更新されました。%2 件の新着記事が追加されました。</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="240"/>
        <source>Failed to parse RSS feed at &apos;%1&apos;. Reason: %2</source>
        <translation>&apos;%1&apos; のRSS フィードの解析に失敗しました。理由: %2</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="264"/>
        <source>Couldn&apos;t read RSS Session data from %1. Error: %2</source>
        <translation>%1 からの RSS フィードを読み込めませんでした。エラー: %2</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="275"/>
        <source>Couldn&apos;t parse RSS Session data. Error: %1</source>
        <translation>RSS セッションデータを解析できませんでした。エラー: %1</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="281"/>
        <source>Couldn&apos;t load RSS Session data. Invalid data format.</source>
        <translation>RSS セッションデータの読み込みに失敗しました。不正なデータ形式です。</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="290"/>
        <source>Couldn&apos;t load RSS article &apos;%1#%2&apos;. Invalid data format.</source>
        <translation>RSS 記事 &apos;%1#%2&apos; を読み込めませんでした。不正なデータ形式です。</translation>
    </message>
</context>
<context>
    <name>RSS::Private::Parser</name>
    <message>
        <location filename="../base/rss/private/rss_parser.cpp" line="578"/>
        <source>Invalid RSS feed.</source>
        <translation>不正な RSS フィードです。</translation>
    </message>
    <message>
        <location filename="../base/rss/private/rss_parser.cpp" line="581"/>
        <source>%1 (line: %2, column: %3, offset: %4).</source>
        <translation>%1 (行: %2, カラム: %3, オフセット: %4).</translation>
    </message>
</context>
<context>
    <name>RSS::Session</name>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="162"/>
        <source>RSS feed with given URL already exists: %1.</source>
        <translation>指定された URL の RSS フィードはすでに存在します: %1。</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="181"/>
        <source>Cannot move root folder.</source>
        <translation>ルートフォルダーは移動できません。</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="188"/>
        <location filename="../base/rss/rss_session.cpp" line="226"/>
        <source>Item doesn&apos;t exist: %1.</source>
        <translation>アイテムが存在しません: %1.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="219"/>
        <source>Cannot delete root folder.</source>
        <translation>ルートフォルダーは削除できません。</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="381"/>
        <source>Incorrect RSS Item path: %1.</source>
        <translation>不正な RSS アイテムパス: %1.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="387"/>
        <source>RSS item with given path already exists: %1.</source>
        <translation>指定されたパスの RSS アイテムはすでに存在します: %1.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="395"/>
        <source>Parent folder doesn&apos;t exist: %1.</source>
        <translation>親フォルダーが存在しません: %1.</translation>
    </message>
</context>
<context>
    <name>RSSWidget</name>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="17"/>
        <source>Search</source>
        <translation>検索</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="31"/>
        <source>Fetching of RSS feeds is disabled now! You can enable it in application settings.</source>
        <translation>RSS フィードの取得は現在無効になっています。設定から有効にできます。</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="43"/>
        <source>New subscription</source>
        <translation>新規購読</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="50"/>
        <location filename="../gui/rss/rsswidget.ui" line="174"/>
        <location filename="../gui/rss/rsswidget.ui" line="177"/>
        <source>Mark items read</source>
        <translation>既読にする</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="57"/>
        <source>Refresh RSS streams</source>
        <translation>RSS ストリームの更新</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="60"/>
        <source>Update all</source>
        <translation>すべて更新</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="80"/>
        <source>RSS Downloader...</source>
        <translation>RSS ダウンローダー...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="108"/>
        <source>Torrents: (double-click to download)</source>
        <translation>Torrent: (ダブルクリックでダウンロード)</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="137"/>
        <location filename="../gui/rss/rsswidget.ui" line="140"/>
        <source>Delete</source>
        <translation>削除</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="145"/>
        <source>Rename...</source>
        <translation>名前の変更...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="148"/>
        <source>Rename</source>
        <translation>名前の変更</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="153"/>
        <location filename="../gui/rss/rsswidget.ui" line="156"/>
        <source>Update</source>
        <translation>更新</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="161"/>
        <source>New subscription...</source>
        <translation>新規購読...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="166"/>
        <location filename="../gui/rss/rsswidget.ui" line="169"/>
        <source>Update all feeds</source>
        <translation>すべてのフィードの更新</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="182"/>
        <source>Download torrent</source>
        <translation>Torrent のダウンロード</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="187"/>
        <source>Open news URL</source>
        <translation>ニュースの URL を開く</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="192"/>
        <source>Copy feed URL</source>
        <translation>フィード URL を開く</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="197"/>
        <source>New folder...</source>
        <translation>新規フォルダー...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="215"/>
        <source>Please choose a folder name</source>
        <translation>フォルダー名を選択してください</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="215"/>
        <source>Folder name:</source>
        <translation>フォルダー名:</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="216"/>
        <source>New folder</source>
        <translation>新しいフォルダー</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="256"/>
        <source>Please type a RSS feed URL</source>
        <translation>RSS フィードの URL を入力してください</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="256"/>
        <source>Feed URL:</source>
        <translation>フィード URL:</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="297"/>
        <source>Deletion confirmation</source>
        <translation>削除の確認</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="297"/>
        <source>Are you sure you want to delete the selected RSS feeds?</source>
        <translation>選択した RSS フィードを削除しますか?</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="386"/>
        <source>Please choose a new name for this RSS feed</source>
        <translation>この RSS フィードの新しい名前を選択してください</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="386"/>
        <source>New feed name:</source>
        <translation>新しいフィード名:</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="393"/>
        <source>Rename failed</source>
        <translation>名前の変更に失敗</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="456"/>
        <source>Date: </source>
        <translation>日付: </translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="458"/>
        <source>Author: </source>
        <translation>作者: </translation>
    </message>
</context>
<context>
    <name>ScanFoldersDelegate</name>
    <message>
        <location filename="../gui/scanfoldersdelegate.cpp" line="99"/>
        <source>Select save location</source>
        <translation>保存場所の選択</translation>
    </message>
</context>
<context>
    <name>ScanFoldersModel</name>
    <message>
        <location filename="../base/scanfoldersmodel.cpp" line="150"/>
        <source>Monitored Folder</source>
        <translation>監視フォルダー</translation>
    </message>
    <message>
        <location filename="../base/scanfoldersmodel.cpp" line="153"/>
        <source>Override Save Location</source>
        <translation>保存先</translation>
    </message>
    <message>
        <location filename="../base/scanfoldersmodel.cpp" line="394"/>
        <source>Monitored folder</source>
        <translation>監視フォルダー</translation>
    </message>
    <message>
        <location filename="../base/scanfoldersmodel.cpp" line="396"/>
        <source>Default save location</source>
        <translation>デフォルトの保存先</translation>
    </message>
    <message>
        <location filename="../base/scanfoldersmodel.cpp" line="398"/>
        <source>Browse...</source>
        <translation>参照...</translation>
    </message>
</context>
<context>
    <name>SearchController</name>
    <message>
        <location filename="../webui/api/searchcontroller.cpp" line="164"/>
        <location filename="../webui/api/searchcontroller.cpp" line="170"/>
        <source>Offset is out of range</source>
        <translation>オフセットは範囲外です</translation>
    </message>
    <message>
        <location filename="../webui/api/searchcontroller.cpp" line="259"/>
        <source>All plugins are already up to date.</source>
        <translation>全プラグインは最新です。</translation>
    </message>
    <message>
        <location filename="../webui/api/searchcontroller.cpp" line="263"/>
        <source>Updating %1 plugins</source>
        <translation>%1 個のプラグインを更新しています</translation>
    </message>
    <message>
        <location filename="../webui/api/searchcontroller.cpp" line="267"/>
        <source>Updating plugin %1</source>
        <translation>プラグイン %1 を更新しています</translation>
    </message>
    <message>
        <location filename="../webui/api/searchcontroller.cpp" line="274"/>
        <source>Failed to check for plugin updates: %1</source>
        <translation>プラグインの更新チェックに失敗しました: %1</translation>
    </message>
</context>
<context>
    <name>SearchJobWidget</name>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="22"/>
        <source>Results(xxx)</source>
        <translation>検索結果(xxx)</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="45"/>
        <source>Search in:</source>
        <translation>検索対象:</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="55"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Some search engines search in torrent description and in torrent file names too. Whether such results will be shown in the list below is controlled by this mode.&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Everywhere &lt;/span&gt;disables filtering and shows everything returned by the search engines.&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Torrent names only&lt;/span&gt; shows only torrents whose names match the search query.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;一部の検索エンジンは Torrent ファイル名のほか Torrent の説明からも検索します。いずれにしろ、以下のリストに表示される結果はこのモードで制御されます。&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;すべて &lt;/span&gt;検索エンジンか返したすべての結果を表示します。&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Torrent 名のみ&lt;/span&gt;検索クエリと名前が一致した Torrent のみ表示します。&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="84"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set minimal and maximal allowed number of seeders&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;最小および最大シード数で絞り込みます&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="87"/>
        <source>Seeds:</source>
        <translation>シード数:</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="94"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Minimal number of seeds&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;最小シード数&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="116"/>
        <location filename="../gui/search/searchjobwidget.ui" line="204"/>
        <source>to</source>
        <translation>から</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="123"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Maximal number of seeds&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;最大シード数&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="126"/>
        <location filename="../gui/search/searchjobwidget.ui" line="216"/>
        <source>∞</source>
        <translation>∞</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="167"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set minimal and maximal allowed size of a torrent&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;最小および最大 Torrent サイズで絞り込みます&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="170"/>
        <source>Size:</source>
        <translation>サイズ:</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="179"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Minimal torrent size&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;最小 Torrent サイズ&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="213"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Maximal torrent size&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;最大 Torrent サイズ&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="78"/>
        <source>Name</source>
        <comment>i.e: file name</comment>
        <translation>名前</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="79"/>
        <source>Size</source>
        <comment>i.e: file size</comment>
        <translation>サイズ</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="80"/>
        <source>Seeders</source>
        <comment>i.e: Number of full sources</comment>
        <translation>シーダー</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="81"/>
        <source>Leechers</source>
        <comment>i.e: Number of partial sources</comment>
        <translation>リーチャー</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="82"/>
        <source>Search engine</source>
        <translation>検索エンジン</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="132"/>
        <source>Filter search results...</source>
        <translation>検索結果をフィルター...</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="290"/>
        <source>Results (showing &lt;i&gt;%1&lt;/i&gt; out of &lt;i&gt;%2&lt;/i&gt;):</source>
        <comment>i.e: Search results</comment>
        <translation>検索結果 ( &lt;i&gt;%2&lt;/i&gt; 件中 &lt;i&gt;%1&lt;/i&gt; 件を表示):</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="341"/>
        <source>Torrent names only</source>
        <translation>Torrent 名のみ</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="342"/>
        <source>Everywhere</source>
        <translation>すべて</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="363"/>
        <source>Use regular expressions</source>
        <translation>正規表現を使用</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="378"/>
        <source>Searching...</source>
        <translation>検索中...</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="380"/>
        <source>Search has finished</source>
        <translation>検索完了</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="382"/>
        <source>Search aborted</source>
        <translation>検索中止</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="384"/>
        <source>An error occurred during search...</source>
        <translation>検索中にエラーが発生...</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="386"/>
        <source>Search returned no results</source>
        <translation>検索結果は 0 件でした</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="410"/>
        <source>Column visibility</source>
        <translation>表示カラム</translation>
    </message>
</context>
<context>
    <name>SearchListDelegate</name>
    <message>
        <location filename="../gui/search/searchlistdelegate.cpp" line="62"/>
        <source>Unknown</source>
        <translation type="unfinished">不明</translation>
    </message>
</context>
<context>
    <name>SearchPluginManager</name>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="217"/>
        <source>Unknown search engine plugin file format.</source>
        <translation>未知の検索エンジンプラグインフォーマットです。</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="228"/>
        <source>Plugin already at version %1, which is greater than %2</source>
        <translation>プラグインはすでに %1 で、%2 より新しくなっています</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="229"/>
        <source>A more recent version of this plugin is already installed.</source>
        <translation>もっと新しいバージョンのこのプラグインがすでにインストールされています。</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="250"/>
        <source>Plugin %1 is not supported.</source>
        <translation>プラグイン  %1 はサポートされていません。</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="257"/>
        <location filename="../base/search/searchpluginmanager.cpp" line="260"/>
        <source>Plugin is not supported.</source>
        <translation>プラグインはサポートされていません。</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="266"/>
        <source>Plugin %1 has been successfully updated.</source>
        <translation>プラグイン %1 は正常に更新されました。</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="330"/>
        <source>All categories</source>
        <translation>全カテゴリ</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="331"/>
        <source>Movies</source>
        <translation>映画</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="332"/>
        <source>TV shows</source>
        <translation>TV ショー</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="333"/>
        <source>Music</source>
        <translation>音楽</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="334"/>
        <source>Games</source>
        <translation>ゲーム</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="335"/>
        <source>Anime</source>
        <translation>アニメ</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="336"/>
        <source>Software</source>
        <translation>ソフトウェア</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="337"/>
        <source>Pictures</source>
        <translation>画像</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="338"/>
        <source>Books</source>
        <translation>書籍</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="377"/>
        <source>Update server is temporarily unavailable. %1</source>
        <translation>アップデートサーバーは一時的に利用できません。%1</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="395"/>
        <location filename="../base/search/searchpluginmanager.cpp" line="397"/>
        <source>Failed to download the plugin file. %1</source>
        <translation>プラグインファイルのダウンロードに失敗しました。%1</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="523"/>
        <source>Plugin &quot;%1&quot; is outdated, updating to version %2</source>
        <translation>プラグイン &quot;%1&quot; は古くなっています。バージョン %2 に更新しています</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="529"/>
        <source>Incorrect update info received for %1 out of %2 plugins.</source>
        <translation>%2 個のプラグイン中から %1 の誤った更新情報を受信しました。</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="566"/>
        <source>Search plugin &apos;%1&apos; contains invalid version string (&apos;%2&apos;)</source>
        <translation>検索プラグイン &apos;%1&apos; には不正なバージョン文字列が含まれています。(&apos;%2&apos;)</translation>
    </message>
</context>
<context>
    <name>SearchWidget</name>
    <message>
        <location filename="../gui/search/searchwidget.ui" line="14"/>
        <location filename="../gui/search/searchwidget.ui" line="51"/>
        <location filename="../gui/search/searchwidget.cpp" line="286"/>
        <location filename="../gui/search/searchwidget.cpp" line="306"/>
        <location filename="../gui/search/searchwidget.cpp" line="377"/>
        <location filename="../gui/search/searchwidget.cpp" line="385"/>
        <source>Search</source>
        <translation>検索</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.ui" line="79"/>
        <source>There aren&apos;t any search plugins installed.
Click the &quot;Search plugins...&quot; button at the bottom right of the window to install some.</source>
        <translation>検索プラグインがインストールされていません。
ウィンドウ右下の &quot;検索プラグイン...&quot; ボタンをクリックして何かインストールしてください。</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.ui" line="122"/>
        <source>Download</source>
        <translation>ダウンロード</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.ui" line="132"/>
        <source>Go to description page</source>
        <translation>説明ページヘ移動</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.ui" line="142"/>
        <source>Copy description page URL</source>
        <translation>説明ページの URL をコピー</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.ui" line="162"/>
        <source>Search plugins...</source>
        <translation>検索プラグイン...</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="103"/>
        <source>A phrase to search for.</source>
        <translation>検索文字列を入力してください。</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="104"/>
        <source>Spaces in a search term may be protected by double quotes.</source>
        <translation>空白を含む文字列を検索したい場合はダブルクォーテーションで括ってください。</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="106"/>
        <source>Example:</source>
        <comment>Search phrase example</comment>
        <translation>例:</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="108"/>
        <source>&lt;b&gt;foo bar&lt;/b&gt;: search for &lt;b&gt;foo&lt;/b&gt; and &lt;b&gt;bar&lt;/b&gt;</source>
        <comment>Search phrase example, illustrates quotes usage, a pair of space delimited words, individal words are highlighted</comment>
        <translation>&lt;b&gt;foo bar&lt;/b&gt;: 文字列「&lt;b&gt;foo&lt;/b&gt;」と「&lt;b&gt;bar&lt;/b&gt;」を検索します</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="112"/>
        <source>&lt;b&gt;&amp;quot;foo bar&amp;quot;&lt;/b&gt;: search for &lt;b&gt;foo bar&lt;/b&gt;</source>
        <comment>Search phrase example, illustrates quotes usage, double quotedpair of space delimited words, the whole pair is highlighted</comment>
        <translation>&lt;b&gt;&amp;quot;foo bar&amp;quot;&lt;/b&gt;: 文字列「&lt;b&gt;foo bar&lt;/b&gt;」を検索します</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="187"/>
        <source>All plugins</source>
        <translation>すべてのプラグイン</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="186"/>
        <source>Only enabled</source>
        <translation>有効なもののみ</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="188"/>
        <source>Select...</source>
        <translation>選択...</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="299"/>
        <location filename="../gui/search/searchwidget.cpp" line="371"/>
        <location filename="../gui/search/searchwidget.cpp" line="373"/>
        <source>Search Engine</source>
        <translation>検索エンジン</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="299"/>
        <source>Please install Python to use the Search Engine.</source>
        <translation>検索エンジンを使用するには Python をインストールしてください。</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="316"/>
        <source>Empty search pattern</source>
        <translation>空の検索パターン</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="316"/>
        <source>Please type a search pattern first</source>
        <translation>まず検索パターンを入力してください</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="349"/>
        <source>Stop</source>
        <translation>停止</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="373"/>
        <source>Search has finished</source>
        <translation>検索完了</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="371"/>
        <source>Search has failed</source>
        <translation>検索に失敗しました</translation>
    </message>
</context>
<context>
    <name>ShutdownConfirmDialog</name>
    <message>
        <location filename="../gui/shutdownconfirmdialog.ui" line="64"/>
        <source>Don&apos;t show again</source>
        <translation>次回から表示しない</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="113"/>
        <source>qBittorrent will now exit.</source>
        <translation>qBittorrent を終了します。</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="114"/>
        <source>E&amp;xit Now</source>
        <translation>いま終了(&amp;X)</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="115"/>
        <source>Exit confirmation</source>
        <translation>終了の確認</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="118"/>
        <source>The computer is going to shutdown.</source>
        <translation>コンピューターはシャットダウンしようとしています。</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="119"/>
        <source>&amp;Shutdown Now</source>
        <translation>いまシャットダウン(&amp;S)</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="120"/>
        <source>Shutdown confirmation</source>
        <translation>シャットダウンの確認</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="123"/>
        <source>The computer is going to enter suspend mode.</source>
        <translation>コンピューターはサスペンドモードに入ろうとしています。</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="124"/>
        <source>&amp;Suspend Now</source>
        <translation>いまサスペンド(&amp;S)</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="125"/>
        <source>Suspend confirmation</source>
        <translation>サスペンドの確認</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="128"/>
        <source>The computer is going to enter hibernation mode.</source>
        <translation>コンピューターはハイバーネートモードに入ろうとしています。</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="129"/>
        <source>&amp;Hibernate Now</source>
        <translation>いまハイバーネート(&amp;H)</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="130"/>
        <source>Hibernate confirmation</source>
        <translation>ハイバーネートの確認</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="140"/>
        <source>You can cancel the action within %1 seconds.</source>
        <translation>あと %1 秒以内ならキャンセルできます。</translation>
    </message>
</context>
<context>
    <name>SpeedLimitDialog</name>
    <message>
        <location filename="../gui/speedlimitdialog.ui" line="26"/>
        <source>∞</source>
        <translation>∞</translation>
    </message>
    <message>
        <location filename="../gui/speedlimitdialog.ui" line="29"/>
        <source> KiB/s</source>
        <translation> KiB/s</translation>
    </message>
</context>
<context>
    <name>SpeedPlotView</name>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="164"/>
        <source>Total Upload</source>
        <translation>総アップロード</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="165"/>
        <source>Total Download</source>
        <translation>総ダウンロード</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="169"/>
        <source>Payload Upload</source>
        <translation>アップロードのペイロード</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="170"/>
        <source>Payload Download</source>
        <translation>ダウンロードのペイロード</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="174"/>
        <source>Overhead Upload</source>
        <translation>アップロードのオーバーヘッド</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="175"/>
        <source>Overhead Download</source>
        <translation>ダウンロードのオーバーヘッド</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="179"/>
        <source>DHT Upload</source>
        <translation>DHT でのアップロード</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="180"/>
        <source>DHT Download</source>
        <translation>DHT でのダウンロード</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="184"/>
        <source>Tracker Upload</source>
        <translation>トラッカーのアップロード</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="185"/>
        <source>Tracker Download</source>
        <translation>トラッカーのダウンロード</translation>
    </message>
</context>
<context>
    <name>SpeedWidget</name>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="68"/>
        <source>Period:</source>
        <translation>期間:</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="71"/>
        <source>1 Minute</source>
        <translation>1 分</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="72"/>
        <source>5 Minutes</source>
        <translation>5 分</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="73"/>
        <source>30 Minutes</source>
        <translation>30 分</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="74"/>
        <source>6 Hours</source>
        <translation>6 時間</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="106"/>
        <source>Select Graphs</source>
        <translation>グラフの選択</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="80"/>
        <source>Total Upload</source>
        <translation>総アップロード</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="81"/>
        <source>Total Download</source>
        <translation>総ダウンロード</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="82"/>
        <source>Payload Upload</source>
        <translation>アップロードのペイロード</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="83"/>
        <source>Payload Download</source>
        <translation>ダウンロードのペイロード</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="84"/>
        <source>Overhead Upload</source>
        <translation>アップロードのオーバーヘッド</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="85"/>
        <source>Overhead Download</source>
        <translation>ダウンロードのオーバーヘッド</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="86"/>
        <source>DHT Upload</source>
        <translation>DHT でのアップロード</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="87"/>
        <source>DHT Download</source>
        <translation>DHT でのダウンロード</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="88"/>
        <source>Tracker Upload</source>
        <translation>トラッカーのアップロード</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="89"/>
        <source>Tracker Download</source>
        <translation>トラッカーのダウンロード</translation>
    </message>
</context>
<context>
    <name>StacktraceDialog</name>
    <message>
        <location filename="../app/stacktracedialog.ui" line="14"/>
        <source>Crash info</source>
        <translation>クラッシュ情報</translation>
    </message>
</context>
<context>
    <name>StatsDialog</name>
    <message>
        <location filename="../gui/statsdialog.ui" line="14"/>
        <source>Statistics</source>
        <translation>統計情報</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="20"/>
        <source>User statistics</source>
        <translation>利用者統計</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="99"/>
        <source>Cache statistics</source>
        <translation>キャッシュ統計</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="105"/>
        <source>Read cache hits:</source>
        <translation>読み込みキャッシュヒット:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="184"/>
        <source>Average time in queue:</source>
        <translation>平均キュー待ち時間:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="33"/>
        <source>Connected peers:</source>
        <translation>接続ピア数:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="40"/>
        <source>All-time share ratio:</source>
        <translation>総合共有比:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="54"/>
        <source>All-time download:</source>
        <translation>総合ダウンロード量:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="75"/>
        <source>Session waste:</source>
        <translation>セッション破棄:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="82"/>
        <source>All-time upload:</source>
        <translation>総合アップロード量:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="126"/>
        <source>Total buffer size:</source>
        <translation>全バッファサイズ:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="136"/>
        <source>Performance statistics</source>
        <translation>性能統計</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="170"/>
        <source>Queued I/O jobs:</source>
        <translation>待ち I/O ジョブ数:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="177"/>
        <source>Write cache overload:</source>
        <translation>書き込みキャッシュオーバーロード:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="191"/>
        <source>Read cache overload:</source>
        <translation>読み込みキャッシュオーバーロード:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="198"/>
        <source>Total queued size:</source>
        <translation>総キューサイズ:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.cpp" line="106"/>
        <source>%1 ms</source>
        <comment>18 milliseconds</comment>
        <translation>%1 ms</translation>
    </message>
</context>
<context>
    <name>StatusBar</name>
    <message>
        <location filename="../gui/statusbar.cpp" line="68"/>
        <location filename="../gui/statusbar.cpp" line="188"/>
        <source>Connection status:</source>
        <translation>接続状態:</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="69"/>
        <location filename="../gui/statusbar.cpp" line="188"/>
        <source>No direct connections. This may indicate network configuration problems.</source>
        <translation>直接接続はありません。これはネットワーク構成に問題があることを示しているのかもしれません。</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="90"/>
        <location filename="../gui/statusbar.cpp" line="197"/>
        <source>DHT: %1 nodes</source>
        <translation>DHT: %1 ノード</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="161"/>
        <source>qBittorrent needs to be restarted!</source>
        <translation>qBittorrent の再起動が必要です!</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="178"/>
        <location filename="../gui/statusbar.cpp" line="184"/>
        <source>Connection Status:</source>
        <translation>接続状態:</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="178"/>
        <source>Offline. This usually means that qBittorrent failed to listen on the selected port for incoming connections.</source>
        <translation>オフライン。これは通常 qBittorrent が選択されたポートでの着信接続の待ち受けに失敗したことを意味します。</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="184"/>
        <source>Online</source>
        <translation>オンライン</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="240"/>
        <source>Click to switch to alternative speed limits</source>
        <translation>クリックすると代替速度制限に切り換えます</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="235"/>
        <source>Click to switch to regular speed limits</source>
        <translation>クリックすると通常の速度制限に切り換えます</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="252"/>
        <source>Global Download Speed Limit</source>
        <translation>全体のダウンロード速度制限</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="266"/>
        <source>Global Upload Speed Limit</source>
        <translation>全体のアップロード速度制限</translation>
    </message>
</context>
<context>
    <name>StatusFilterWidget</name>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="135"/>
        <source>All (0)</source>
        <comment>this is for the status filter</comment>
        <translation>すべて (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="138"/>
        <source>Downloading (0)</source>
        <translation>ダウンロード中 (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="141"/>
        <source>Seeding (0)</source>
        <translation>シード中 (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="144"/>
        <source>Completed (0)</source>
        <translation>完了 (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="147"/>
        <source>Resumed (0)</source>
        <translation>再開 (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="150"/>
        <source>Paused (0)</source>
        <translation>停止中 (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="153"/>
        <source>Active (0)</source>
        <translation>動作中 (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="156"/>
        <source>Inactive (0)</source>
        <translation>非動作中 (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="159"/>
        <source>Errored (0)</source>
        <translation>エラー (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="176"/>
        <source>All (%1)</source>
        <translation>すべて (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="177"/>
        <source>Downloading (%1)</source>
        <translation>ダウンロード中 (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="178"/>
        <source>Seeding (%1)</source>
        <translation>シード中 (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="179"/>
        <source>Completed (%1)</source>
        <translation>完了 (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="180"/>
        <source>Paused (%1)</source>
        <translation>停止中 (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="181"/>
        <source>Resumed (%1)</source>
        <translation>再開 (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="182"/>
        <source>Active (%1)</source>
        <translation>動作中 (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="183"/>
        <source>Inactive (%1)</source>
        <translation>非動作中 (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="184"/>
        <source>Errored (%1)</source>
        <translation>エラー (%1)</translation>
    </message>
</context>
<context>
    <name>TagFilterModel</name>
    <message>
        <location filename="../gui/tagfiltermodel.cpp" line="147"/>
        <source>Tags</source>
        <translation>タグ</translation>
    </message>
    <message>
        <location filename="../gui/tagfiltermodel.cpp" line="258"/>
        <source>All</source>
        <translation>すべて</translation>
    </message>
    <message>
        <location filename="../gui/tagfiltermodel.cpp" line="260"/>
        <source>Untagged</source>
        <translation>タグなし</translation>
    </message>
</context>
<context>
    <name>TagFilterWidget</name>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="113"/>
        <source>Add tag...</source>
        <translation>タグの追加...</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="120"/>
        <source>Remove tag</source>
        <translation>タグの削除</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="126"/>
        <source>Remove unused tags</source>
        <translation>未使用のタグの削除</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="133"/>
        <source>Resume torrents</source>
        <translation>Torrent の再開</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="139"/>
        <source>Pause torrents</source>
        <translation>Torrent の停止</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="145"/>
        <source>Delete torrents</source>
        <translation>Torrent の削除</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="188"/>
        <source>New Tag</source>
        <translation>新規タグ</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="188"/>
        <source>Tag:</source>
        <translation>タグ:</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="192"/>
        <source>Invalid tag name</source>
        <translation>不正なタグ名</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="193"/>
        <source>Tag name &apos;%1&apos; is invalid</source>
        <translation>タグ名 &apos;%1&apos; は正しくありません</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="208"/>
        <source>Tag exists</source>
        <translation>既存のタグ</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="208"/>
        <source>Tag name already exists.</source>
        <translation>タグ名はすでに存在します。</translation>
    </message>
</context>
<context>
    <name>TorrentCategoryDialog</name>
    <message>
        <location filename="../gui/torrentcategorydialog.ui" line="14"/>
        <source>Torrent Category Properties</source>
        <translation>Torrent カテゴリプロパティ</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.ui" line="35"/>
        <source>Name:</source>
        <translation>名前:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.ui" line="45"/>
        <source>Save path:</source>
        <translation>保存パス:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.cpp" line="43"/>
        <source>Choose save path</source>
        <translation>保存先の選択</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.cpp" line="58"/>
        <source>New Category</source>
        <translation>新規カテゴリ</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.cpp" line="67"/>
        <source>Invalid category name</source>
        <translation>不正なカテゴリ名</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.cpp" line="68"/>
        <source>Category name cannot contain &apos;\&apos;.
Category name cannot start/end with &apos;/&apos;.
Category name cannot contain &apos;//&apos; sequence.</source>
        <translation>カテゴリ名に &apos;\&apos; を含めることはできません。
カテゴリ名は &apos;/&apos; で開始または終了することはできません。
カテゴリ名に &apos;//&apos; の並びを含めることはできません。</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.cpp" line="74"/>
        <source>Category creation error</source>
        <translation>カテゴリ作成エラー</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.cpp" line="75"/>
        <source>Category with the given name already exists.
Please choose a different name and try again.</source>
        <translation>このカテゴリ名はすでに存在します。
別の名前を指定してください。</translation>
    </message>
</context>
<context>
    <name>TorrentContentModel</name>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="207"/>
        <source>Name</source>
        <translation>名前</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="207"/>
        <source>Size</source>
        <translation>サイズ</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="207"/>
        <source>Progress</source>
        <translation>進行状況</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="207"/>
        <source>Download Priority</source>
        <translation>ダウンロード優先度</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="207"/>
        <source>Remaining</source>
        <translation>残り</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="207"/>
        <source>Availability</source>
        <translation>可用性</translation>
    </message>
</context>
<context>
    <name>TorrentCreatorDialog</name>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="17"/>
        <source>Torrent Creator</source>
        <translation>Torrent クリエーター</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="23"/>
        <source>Select file/folder to share</source>
        <translation>共有するファイル/フォルダーを選択してください</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="31"/>
        <source>Path:</source>
        <translation>パス:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="58"/>
        <source>[Drag and drop area]</source>
        <translation>[ここにドラッグアンドドロップしてください]</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="68"/>
        <location filename="../gui/torrentcreatordialog.cpp" line="111"/>
        <source>Select file</source>
        <translation>ファイルの選択</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="75"/>
        <location filename="../gui/torrentcreatordialog.cpp" line="104"/>
        <source>Select folder</source>
        <translation>フォルダーの選択</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="87"/>
        <source>Settings</source>
        <translation>設定</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="95"/>
        <source>Piece size:</source>
        <translation>ピースサイズ:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="109"/>
        <source>Auto</source>
        <translation>自動</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="114"/>
        <source>16 KiB</source>
        <translation>16 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="119"/>
        <source>32 KiB</source>
        <translation>32 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="124"/>
        <source>64 KiB</source>
        <translation>64 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="129"/>
        <source>128 KiB</source>
        <translation>128 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="134"/>
        <source>256 KiB</source>
        <translation>256 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="139"/>
        <source>512 KiB</source>
        <translation>512 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="144"/>
        <source>1 MiB</source>
        <translation>1 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="149"/>
        <source>2 MiB</source>
        <translation>2 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="154"/>
        <source>4 MiB</source>
        <translation>4 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="159"/>
        <source>8 MiB</source>
        <translation>8 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="164"/>
        <source>16 MiB</source>
        <translation>16 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="169"/>
        <source>32 MiB</source>
        <translation>32 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="177"/>
        <source>Calculate number of pieces:</source>
        <translation>ピース数を計算:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="206"/>
        <source>Private torrent (Won&apos;t distribute on DHT network)</source>
        <translation>プライベート Torrent (DHT ネットワークには配信されません)</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="213"/>
        <source>Start seeding immediately</source>
        <translation>すぐにシードを開始する</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="223"/>
        <source>Ignore share ratio limits for this torrent</source>
        <translation>この Torrent では共有費を無視する</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="230"/>
        <source>Optimize alignment</source>
        <translation>アラインメントを最適化</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="243"/>
        <source>Fields</source>
        <translation>フィールド</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="249"/>
        <source>You can separate tracker tiers / groups with an empty line.</source>
        <comment>A tracker tier is a group of trackers, consisting of a main tracker and its mirrors.</comment>
        <translation>空行を入れることでトラッカーをティア/グループに分けることができます。</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="259"/>
        <source>Web seed URLs:</source>
        <translation>ウェブシード URL:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="280"/>
        <source>Tracker URLs:</source>
        <translation>トラッカー URL:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="287"/>
        <source>Comments:</source>
        <translation>コメント:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="294"/>
        <source>Source:</source>
        <translation>ソース:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="309"/>
        <source>Progress:</source>
        <translation>進行状況:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="70"/>
        <source>Create Torrent</source>
        <translation>Torrent を作成</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="148"/>
        <location filename="../gui/torrentcreatordialog.cpp" line="182"/>
        <location filename="../gui/torrentcreatordialog.cpp" line="194"/>
        <source>Torrent creation failed</source>
        <translation>Torrent 作成失敗</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="148"/>
        <source>Reason: Path to file/folder is not readable.</source>
        <translation>理由: ファイル/フォルダーへのパスが読み込み不可です。</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="155"/>
        <source>Select where to save the new torrent</source>
        <translation>新規 Torrent の保存先を選択してください</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="155"/>
        <source>Torrent Files (*.torrent)</source>
        <translation>Torrent ファイル (*.torrent)</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="182"/>
        <source>Reason: %1</source>
        <translation>理由: %1</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="194"/>
        <source>Reason: Created torrent is invalid. It won&apos;t be added to download list.</source>
        <translation>理由: Torrent の作成に失敗しました。これはダウンロードリストには追加されません。</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="205"/>
        <source>Torrent creator</source>
        <translation>Torrent クリエーター</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="206"/>
        <source>Torrent created:</source>
        <translation>Torrent を作成しました:</translation>
    </message>
</context>
<context>
    <name>TorrentInfo</name>
    <message>
        <location filename="../base/bittorrent/torrentinfo.cpp" line="111"/>
        <source>File size exceeds max limit %1</source>
        <translation>ファイルサイズが上限の %1 に達しました</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrentinfo.cpp" line="121"/>
        <source>Torrent file read error: %1</source>
        <translation>Torrent ファイル読み込みエラー: %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrentinfo.cpp" line="126"/>
        <source>Torrent file read error: size mismatch</source>
        <translation>Torrent ファイル読み込みエラー: サイズの不一致</translation>
    </message>
</context>
<context>
    <name>TorrentsController</name>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="585"/>
        <source>Error: &apos;%1&apos; is not a valid torrent file.</source>
        <translation>エラー: &apos;%1&apos; は正常な Torrent ファイルではありません。</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="706"/>
        <source>Priority must be an integer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="709"/>
        <source>Priority is not valid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="715"/>
        <source>Torrent&apos;s metadata has not yet downloaded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="723"/>
        <source>File IDs must be integers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="725"/>
        <source>File ID is not valid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="861"/>
        <location filename="../webui/api/torrentscontroller.cpp" line="872"/>
        <location filename="../webui/api/torrentscontroller.cpp" line="883"/>
        <location filename="../webui/api/torrentscontroller.cpp" line="894"/>
        <source>Torrent queueing must be enabled</source>
        <translation>Torrent キューイングを有効にしなければなりません</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="908"/>
        <source>Save path cannot be empty</source>
        <translation>保存先を入力してください</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="995"/>
        <location filename="../webui/api/torrentscontroller.cpp" line="1012"/>
        <source>Category cannot be empty</source>
        <translation>カテゴリを指定してください</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="1001"/>
        <source>Unable to create category</source>
        <translation>カテゴリを作成できません</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="1015"/>
        <source>Unable to edit category</source>
        <translation>カテゴリを編集できません</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="912"/>
        <source>Cannot make save path</source>
        <translation>保存先パスを作成できません</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="916"/>
        <source>Cannot write to directory</source>
        <translation>ディレクトリに書き込めません</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="920"/>
        <source>WebUI Set location: moving &quot;%1&quot;, from &quot;%2&quot; to &quot;%3&quot;</source>
        <translation>WebUI の場所の設定: &quot;%1&quot; を &quot;%2&quot; からto &quot;%3&quot; へ移動</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="934"/>
        <source>Incorrect torrent name</source>
        <translation>不正な Torrent 名</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="983"/>
        <location filename="../webui/api/torrentscontroller.cpp" line="998"/>
        <source>Incorrect category name</source>
        <translation>不正なカテゴリ名</translation>
    </message>
</context>
<context>
    <name>TrackerFiltersList</name>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="204"/>
        <source>All (0)</source>
        <comment>this is for the tracker filter</comment>
        <translation>すべて (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="207"/>
        <source>Trackerless (0)</source>
        <translation>トラッカーなし (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="210"/>
        <source>Error (0)</source>
        <translation>エラー (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="213"/>
        <source>Warning (0)</source>
        <translation>警告 (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="258"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="313"/>
        <source>Trackerless (%1)</source>
        <translation>トラッカーなし (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="355"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="387"/>
        <source>Error (%1)</source>
        <translation>エラー (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="368"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="402"/>
        <source>Warning (%1)</source>
        <translation>警告 (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="463"/>
        <source>Resume torrents</source>
        <translation>Torrent の再開</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="464"/>
        <source>Pause torrents</source>
        <translation>Torrent の停止</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="465"/>
        <source>Delete torrents</source>
        <translation>Torrent の削除</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="499"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="513"/>
        <source>All (%1)</source>
        <comment>this is for the tracker filter</comment>
        <translation>すべて (%1)</translation>
    </message>
</context>
<context>
    <name>TrackerListWidget</name>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="262"/>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="352"/>
        <source>Working</source>
        <translation>稼働中</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="263"/>
        <source>Disabled</source>
        <translation>無効</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="284"/>
        <location filename="../webui/api/torrentscontroller.cpp" line="161"/>
        <source>This torrent is private</source>
        <translation>この Torrent はプライベートです</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="356"/>
        <source>Updating...</source>
        <translation>更新中...</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="360"/>
        <source>Not working</source>
        <translation>稼働していません</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="364"/>
        <source>Not contacted yet</source>
        <translation>まだ接触していません</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="370"/>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="371"/>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="372"/>
        <source>N/A</source>
        <translation>N/A</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="457"/>
        <source>Tracker editing</source>
        <translation>トラッカー編集中</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="457"/>
        <source>Tracker URL:</source>
        <translation>トラッカー URL:</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="462"/>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="472"/>
        <source>Tracker editing failed</source>
        <translation>トラッカー編集失敗</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="462"/>
        <source>The tracker URL entered is invalid.</source>
        <translation>入力されたトラッカー URL が正しくありません。</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="472"/>
        <source>The tracker URL already exists.</source>
        <translation>トラッカー URL はすでに存在します。</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="526"/>
        <source>Add a new tracker...</source>
        <translation>新規トラッカーを追加...</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="531"/>
        <source>Edit tracker URL...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="532"/>
        <source>Remove tracker</source>
        <translation>トラッカーを削除</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="533"/>
        <source>Copy tracker URL</source>
        <translation>トラッカー URL をコピー</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="538"/>
        <source>Force reannounce to selected trackers</source>
        <translation>選択したトラッカーに強制再アナウンス</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="540"/>
        <source>Force reannounce to all trackers</source>
        <translation>全トラッカーに強制再アナウンス</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="587"/>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="588"/>
        <source>Status</source>
        <translation>状態</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="590"/>
        <source>Seeds</source>
        <translation>シード</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="589"/>
        <source>Peers</source>
        <translation>ピア</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="591"/>
        <source>Leeches</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="592"/>
        <source>Downloaded</source>
        <translation>ダウンロード</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="593"/>
        <source>Message</source>
        <translation>メッセージ</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="613"/>
        <source>Column visibility</source>
        <translation>表示カラム</translation>
    </message>
</context>
<context>
    <name>TrackerLoginDialog</name>
    <message>
        <location filename="../gui/trackerlogindialog.ui" line="14"/>
        <location filename="../gui/trackerlogindialog.ui" line="47"/>
        <source>Tracker authentication</source>
        <translation>トラッカー認証</translation>
    </message>
    <message>
        <location filename="../gui/trackerlogindialog.ui" line="64"/>
        <source>Tracker:</source>
        <translation>トラッカー:</translation>
    </message>
    <message>
        <location filename="../gui/trackerlogindialog.ui" line="86"/>
        <source>Login</source>
        <translation>ログイン</translation>
    </message>
    <message>
        <location filename="../gui/trackerlogindialog.ui" line="94"/>
        <source>Username:</source>
        <translation>ユーザー名:</translation>
    </message>
    <message>
        <location filename="../gui/trackerlogindialog.ui" line="117"/>
        <source>Password:</source>
        <translation>パスワード:</translation>
    </message>
    <message>
        <location filename="../gui/trackerlogindialog.cpp" line="46"/>
        <source>Log in</source>
        <translation>ログイン</translation>
    </message>
</context>
<context>
    <name>TrackersAdditionDialog</name>
    <message>
        <location filename="../gui/properties/trackersadditiondialog.ui" line="14"/>
        <source>Trackers addition dialog</source>
        <translation>トラッカーの追加ダイアログ</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondialog.ui" line="20"/>
        <source>List of trackers to add (one per line):</source>
        <translation>トラッカーのリスト (1 行に 1 トラッカー):</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondialog.ui" line="37"/>
        <source>µTorrent compatible list URL:</source>
        <translation>µTorrent 互換リスト URL:</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondialog.cpp" line="117"/>
        <source>No change</source>
        <translation>変更なし</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondialog.cpp" line="117"/>
        <source>No additional trackers were found.</source>
        <translation>追加するトラッカーが見つかりませんでした。</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondialog.cpp" line="125"/>
        <source>Download error</source>
        <translation>ダウンロードエラー</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondialog.cpp" line="125"/>
        <source>The trackers list could not be downloaded, reason: %1</source>
        <translation>トラッカーリストをダウンロードできませんでした。理由: %1</translation>
    </message>
</context>
<context>
    <name>TransferListDelegate</name>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="231"/>
        <source>Downloading</source>
        <translation>ダウンロード中</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="237"/>
        <source>Downloading metadata</source>
        <comment>used when loading a magnet link</comment>
        <translation>メタデータダウンロード中</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="243"/>
        <source>Allocating</source>
        <comment>qBittorrent is allocating the files on disk</comment>
        <translation>割り当て中</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="269"/>
        <source>Paused</source>
        <translation>停止</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="254"/>
        <source>Queued</source>
        <comment>i.e. torrent is queued</comment>
        <translation>待機中</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="247"/>
        <source>Seeding</source>
        <comment>Torrent is complete and in upload-only mode</comment>
        <translation>シード中</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="234"/>
        <source>Stalled</source>
        <comment>Torrent is waiting for download to begin</comment>
        <translation>ダウンロード待ち</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="240"/>
        <source>[F] Downloading</source>
        <comment>used when the torrent is forced started. You probably shouldn&apos;t translate the F.</comment>
        <translation>[F] ダウンロード中</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="250"/>
        <source>[F] Seeding</source>
        <comment>used when the torrent is forced started. You probably shouldn&apos;t translate the F.</comment>
        <translation>[F] シード中</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="258"/>
        <source>Checking</source>
        <comment>Torrent local data is being checked</comment>
        <translation>チェック中</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="262"/>
        <source>Queued for checking</source>
        <comment>i.e. torrent is queued for hash checking</comment>
        <translation>チェック待ち</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="266"/>
        <source>Checking resume data</source>
        <comment>used when loading the torrents from disk after qbt is launched. It checks the correctness of the .fastresume file. Normally it is completed in a fraction of a second, unless loading many many torrents.</comment>
        <translation>再開データのチェック中</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="272"/>
        <source>Completed</source>
        <translation>完了</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="275"/>
        <source>Moving</source>
        <comment>Torrent local data are being moved/relocated</comment>
        <translation>移動中</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="278"/>
        <source>Missing Files</source>
        <translation>ファイルがありません</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="281"/>
        <source>Errored</source>
        <comment>torrent status, the torrent has an error</comment>
        <translation>エラー</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="127"/>
        <source>%1 (seeded for %2)</source>
        <comment>e.g. 4m39s (seeded for 3m10s)</comment>
        <translation>%1 (シード時間 %2)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="188"/>
        <source>%1 ago</source>
        <comment>e.g.: 1h 20m ago</comment>
        <translation>%1 前</translation>
    </message>
</context>
<context>
    <name>TransferListFiltersWidget</name>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="592"/>
        <source>Status</source>
        <translation>状態</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="600"/>
        <source>Categories</source>
        <translation>カテゴリ</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="619"/>
        <source>Tags</source>
        <translation>タグ</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="637"/>
        <source>Trackers</source>
        <translation>トラッカー</translation>
    </message>
</context>
<context>
    <name>TransferListModel</name>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="98"/>
        <source>Name</source>
        <comment>i.e: torrent name</comment>
        <translation>名前</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="99"/>
        <source>Size</source>
        <comment>i.e: torrent size</comment>
        <translation>サイズ</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="100"/>
        <source>Done</source>
        <comment>% Done</comment>
        <translation>完了</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="101"/>
        <source>Status</source>
        <comment>Torrent status (e.g. downloading, seeding, paused)</comment>
        <translation>状態</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="102"/>
        <source>Seeds</source>
        <comment>i.e. full sources (often untranslated)</comment>
        <translation>シード</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="103"/>
        <source>Peers</source>
        <comment>i.e. partial sources (often untranslated)</comment>
        <translation>ピア</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="104"/>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>DL 速度</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="105"/>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>UP 速度</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="106"/>
        <source>Ratio</source>
        <comment>Share ratio</comment>
        <translation>共有比</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="107"/>
        <source>ETA</source>
        <comment>i.e: Estimated Time of Arrival / Time left</comment>
        <translation>予想残り時間</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="108"/>
        <source>Category</source>
        <translation>カテゴリ</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="109"/>
        <source>Tags</source>
        <translation>タグ</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="110"/>
        <source>Added On</source>
        <comment>Torrent was added to transfer list on 01/01/2010 08:00</comment>
        <translation>追加日時</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="111"/>
        <source>Completed On</source>
        <comment>Torrent was completed on 01/01/2010 08:00</comment>
        <translation>完了日時</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="112"/>
        <source>Tracker</source>
        <translation>トラッカー</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="113"/>
        <source>Down Limit</source>
        <comment>i.e: Download limit</comment>
        <translation>DL 制限</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="114"/>
        <source>Up Limit</source>
        <comment>i.e: Upload limit</comment>
        <translation>UP 制限</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="115"/>
        <source>Downloaded</source>
        <comment>Amount of data downloaded (e.g. in MB)</comment>
        <translation>ダウンロード済み</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="116"/>
        <source>Uploaded</source>
        <comment>Amount of data uploaded (e.g. in MB)</comment>
        <translation>アップロード済み</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="117"/>
        <source>Session Download</source>
        <comment>Amount of data downloaded since program open (e.g. in MB)</comment>
        <translation>セッション内 DL 量</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="118"/>
        <source>Session Upload</source>
        <comment>Amount of data uploaded since program open (e.g. in MB)</comment>
        <translation>セッション内 UP 量</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="119"/>
        <source>Remaining</source>
        <comment>Amount of data left to download (e.g. in MB)</comment>
        <translation>残り</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="120"/>
        <source>Time Active</source>
        <comment>Time (duration) the torrent is active (not paused)</comment>
        <translation>動作時間</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="121"/>
        <source>Save path</source>
        <comment>Torrent save path</comment>
        <translation>保存先</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="122"/>
        <source>Completed</source>
        <comment>Amount of data completed (e.g. in MB)</comment>
        <translation>完了</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="123"/>
        <source>Ratio Limit</source>
        <comment>Upload share ratio limit</comment>
        <translation>共有比制限</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="124"/>
        <source>Last Seen Complete</source>
        <comment>Indicates the time when the torrent was last seen complete/whole</comment>
        <translation>完了ファイルの最終確認日時</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="125"/>
        <source>Last Activity</source>
        <comment>Time passed since a chunk was downloaded/uploaded</comment>
        <translation>最終動作</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="126"/>
        <source>Total Size</source>
        <comment>i.e. Size including unwanted data</comment>
        <translation>合計サイズ</translation>
    </message>
</context>
<context>
    <name>TransferListWidget</name>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="704"/>
        <source>Column visibility</source>
        <translation>表示カラム</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="399"/>
        <source>Choose save path</source>
        <translation>保存先パスの選択</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="617"/>
        <source>Torrent Download Speed Limiting</source>
        <translation>Torrent ダウンロード速度制限</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="642"/>
        <source>Torrent Upload Speed Limiting</source>
        <translation>Torrent アップロード速度制限</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="686"/>
        <source>Recheck confirmation</source>
        <translation>再チェックの確認</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="686"/>
        <source>Are you sure you want to recheck the selected torrent(s)?</source>
        <translation>選択した Torrent を再チェックしますか?</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="833"/>
        <source>Rename</source>
        <translation>名前の変更</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="833"/>
        <source>New name:</source>
        <translation>新しい名前:</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="868"/>
        <source>Resume</source>
        <comment>Resume/start the torrent</comment>
        <translation>再開</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="872"/>
        <source>Force Resume</source>
        <comment>Force Resume/start the torrent</comment>
        <translation>強制再開</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="870"/>
        <source>Pause</source>
        <comment>Pause the torrent</comment>
        <translation>停止</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="406"/>
        <source>Set location: moving &quot;%1&quot;, from &quot;%2&quot; to &quot;%3&quot;</source>
        <comment>Set location: moving &quot;ubuntu_16_04.iso&quot;, from &quot;/home/dir1&quot; to &quot;/home/dir2&quot;</comment>
        <translation>保存先の設定: &apos;%1&apos; を &apos;%2&apos; から &apos;%3&apos; へ</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="775"/>
        <source>Add Tags</source>
        <translation>タグの追加</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="783"/>
        <source>Remove All Tags</source>
        <translation>全タグの削除</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="783"/>
        <source>Remove all tags from selected torrents?</source>
        <translation>選択した Torrent から全タグを削除しますか?</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="797"/>
        <source>Comma-separated tags:</source>
        <translation>カンマ区切りのタグ:</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="804"/>
        <source>Invalid tag</source>
        <translation>不正なタグ</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="805"/>
        <source>Tag name: &apos;%1&apos; is invalid</source>
        <translation>タグ名: &apos;%1&apos; は正しくありません</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="874"/>
        <source>Delete</source>
        <comment>Delete the torrent</comment>
        <translation>削除</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="876"/>
        <source>Preview file...</source>
        <translation>ファイルのプレビュー...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="878"/>
        <source>Limit share ratio...</source>
        <translation>共有比上限...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="880"/>
        <source>Limit upload rate...</source>
        <translation>アップロード速度制限...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="882"/>
        <source>Limit download rate...</source>
        <translation>ダウンロード速度制限...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="884"/>
        <source>Open destination folder</source>
        <translation>作成先のフォルダーを開く</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="886"/>
        <source>Move up</source>
        <comment>i.e. move up in the queue</comment>
        <translation>上げる</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="888"/>
        <source>Move down</source>
        <comment>i.e. Move down in the queue</comment>
        <translation>下げる</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="890"/>
        <source>Move to top</source>
        <comment>i.e. Move to top of the queue</comment>
        <translation>先頭へ</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="892"/>
        <source>Move to bottom</source>
        <comment>i.e. Move to bottom of the queue</comment>
        <translation>最後へ</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="894"/>
        <source>Set location...</source>
        <translation>場所の移動...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="898"/>
        <source>Force reannounce</source>
        <translation>強制再アナウンス</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="902"/>
        <source>Copy name</source>
        <translation>名前をコピー</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="904"/>
        <source>Copy hash</source>
        <translation>ハッシュをコピー</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="914"/>
        <source>Download first and last pieces first</source>
        <translation>先頭と最後のピースを先にダウンロード</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="917"/>
        <source>Automatic Torrent Management</source>
        <translation>自動 Torrent 管理</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="919"/>
        <source>Automatic mode means that various torrent properties(eg save path) will be decided by the associated category</source>
        <translation>自動モードでは Torrent の様々なプロパティ (保存先など) が割り当てられたカテゴリから自動決定されます</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1022"/>
        <source>Category</source>
        <translation>カテゴリ</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1023"/>
        <source>New...</source>
        <comment>New category...</comment>
        <translation>新規...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1024"/>
        <source>Reset</source>
        <comment>Reset category</comment>
        <translation>リセット</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1041"/>
        <source>Tags</source>
        <translation>タグ</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1042"/>
        <source>Add...</source>
        <comment>Add / assign multiple tags...</comment>
        <translation>追加...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1043"/>
        <source>Remove All</source>
        <comment>Remove all tags</comment>
        <translation>すべて削除</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1105"/>
        <source>Priority</source>
        <translation>優先度</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="896"/>
        <source>Force recheck</source>
        <translation>強制再チェック</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="900"/>
        <source>Copy magnet link</source>
        <translation>マグネットリンクをコピー</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="906"/>
        <source>Super seeding mode</source>
        <translation>スーパーシードモード</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="909"/>
        <source>Rename...</source>
        <translation>名前の変更...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="911"/>
        <source>Download in sequential order</source>
        <translation>シーケンシャルにダウンロード</translation>
    </message>
</context>
<context>
    <name>UpDownRatioDialog</name>
    <message>
        <location filename="../gui/updownratiodialog.ui" line="14"/>
        <source>Torrent Upload/Download Ratio Limiting</source>
        <translation>Torrent アップロード/ダウンロード速度制限</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodialog.ui" line="20"/>
        <source>Use global share limit</source>
        <translation>全体の共有比上限を使用</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodialog.ui" line="23"/>
        <location filename="../gui/updownratiodialog.ui" line="33"/>
        <location filename="../gui/updownratiodialog.ui" line="45"/>
        <source>buttonGroup</source>
        <translation>buttonGroup</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodialog.ui" line="30"/>
        <source>Set no share limit</source>
        <translation>共有比上限なし</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodialog.ui" line="42"/>
        <source>Set share limit to</source>
        <translation>共有比上限を指定</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodialog.ui" line="100"/>
        <source>ratio</source>
        <translation>共有比</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodialog.ui" line="107"/>
        <source>minutes</source>
        <translation>分</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodialog.cpp" line="85"/>
        <source>No share limit method selected</source>
        <translation>共有比上限の指定方法が選択されていません</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodialog.cpp" line="86"/>
        <source>Please select a limit method first</source>
        <translation>共有比上限の指定方法を選択してください</translation>
    </message>
</context>
<context>
    <name>Utils::ForeignApps</name>
    <message>
        <location filename="../base/utils/foreignapps.cpp" line="80"/>
        <source>Python detected, executable name: &apos;%1&apos;, version: %2</source>
        <translation>Python を検出しました。実行ファイル名: &apos;%1&apos;, バージョン: %2</translation>
    </message>
    <message>
        <location filename="../base/utils/foreignapps.cpp" line="270"/>
        <source>Python not detected</source>
        <translation>Python が見つかりませんでした</translation>
    </message>
</context>
<context>
    <name>WebApplication</name>
    <message>
        <location filename="../webui/webapplication.cpp" line="182"/>
        <source>Unacceptable file type, only regular file is allowed.</source>
        <translation>許されないファイルタイプです。通常ファイルのみ使用できます。</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="189"/>
        <source>Symlinks inside alternative UI folder are forbidden.</source>
        <translation>独自 UI フォルダー内にシンボリックリンクは使用できません。</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="426"/>
        <source>Using built-in Web UI.</source>
        <translation>ビルトイン Web UI を使用しています。</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="428"/>
        <source>Using custom Web UI. Location: &quot;%1&quot;.</source>
        <translation>カスタム Web UI (%1) を使用しています。</translation>
    </message>
    <message>
        <source>Web UI translation for selected locale (%1) is successfully loaded.</source>
        <translation type="vanished">Web UI の言語 (%1) を正常に読み込みました。</translation>
    </message>
    <message>
        <source>Couldn&apos;t load Web UI translation for selected locale (%1). Falling back to default (en).</source>
        <translation type="vanished">Web UI の言語 (%1) を読み込めませんでした。デフォルトの (en) にフォールバックします。</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="438"/>
        <source>Web UI translation for selected locale (%1) has been successfully loaded.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="442"/>
        <source>Couldn&apos;t load Web UI translation for selected locale (%1).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="500"/>
        <source>Exceeded the maximum allowed file size (%1)!</source>
        <translation>利用できる最大のファイルサイズ (%1) に達しました!</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="712"/>
        <source>WebUI: Origin header &amp; Target origin mismatch! Source IP: &apos;%1&apos;. Origin header: &apos;%2&apos;. Target origin: &apos;%3&apos;</source>
        <translation>WebUI: オリジンヘッダーとターゲットオリジンが一致しません! ソース IP: &apos;%1&apos;. オリジンヘッダー: &apos;%2&apos;. ターゲットオリジン: &apos;%3&apos;</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="721"/>
        <source>WebUI: Referer header &amp; Target origin mismatch! Source IP: &apos;%1&apos;. Referer header: &apos;%2&apos;. Target origin: &apos;%3&apos;</source>
        <translation>WebUI: リファラーヘッダーとターゲットオリジンが一致しません! ソース IP: &apos;%1&apos;. リファラーヘッダー: &apos;%2&apos;. ターゲットオリジン: &apos;%3&apos;</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="738"/>
        <source>WebUI: Invalid Host header, port mismatch. Request source IP: &apos;%1&apos;. Server port: &apos;%2&apos;. Received Host header: &apos;%3&apos;</source>
        <translation>WebUI: 不正なホストヘッダー、ポートの不一致です。リクエストソース IP: &apos;%1&apos;. サーバーポート番号: &apos;%2&apos;. 受信ホストヘッダー: &apos;%3&apos;</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="770"/>
        <source>WebUI: Invalid Host header. Request source IP: &apos;%1&apos;. Received Host header: &apos;%2&apos;</source>
        <translation>WebUI: 不正なホストヘッダーです。リクエストソース IP: &apos;%1&apos;. 受信ホストヘッダー: &apos;%2&apos;</translation>
    </message>
</context>
<context>
    <name>WebUI</name>
    <message>
        <location filename="../webui/webui.cpp" line="86"/>
        <source>Web UI: HTTPS setup successful</source>
        <translation>Web UI: HTTPS セットアップは正常に完了しました</translation>
    </message>
    <message>
        <location filename="../webui/webui.cpp" line="88"/>
        <source>Web UI: HTTPS setup failed, fallback to HTTP</source>
        <translation>Web UI: HTTPS セットアップに失敗しました。HTTP にフォールバックします</translation>
    </message>
    <message>
        <location filename="../webui/webui.cpp" line="100"/>
        <source>Web UI: Now listening on IP: %1, port: %2</source>
        <translation>Web UI: IP: %1, ポート番号: %2 で待ち受けています</translation>
    </message>
    <message>
        <location filename="../webui/webui.cpp" line="103"/>
        <source>Web UI: Unable to bind to IP: %1, port: %2. Reason: %3</source>
        <translation>Web UI: IP: %1, ポート番号: %2 にバインドできませんでした。理由: %3</translation>
    </message>
</context>
<context>
    <name>fsutils</name>
    <message>
        <location filename="../base/private/profile_p.cpp" line="92"/>
        <source>Downloads</source>
        <translation>ダウンロード</translation>
    </message>
</context>
<context>
    <name>misc</name>
    <message>
        <location filename="../base/utils/misc.cpp" line="81"/>
        <source>B</source>
        <comment>bytes</comment>
        <translation>B</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="82"/>
        <source>KiB</source>
        <comment>kibibytes (1024 bytes)</comment>
        <translation>KiB</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="83"/>
        <source>MiB</source>
        <comment>mebibytes (1024 kibibytes)</comment>
        <translation>MiB</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="84"/>
        <source>GiB</source>
        <comment>gibibytes (1024 mibibytes)</comment>
        <translation>GiB</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="85"/>
        <source>TiB</source>
        <comment>tebibytes (1024 gibibytes)</comment>
        <translation>TiB</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="86"/>
        <source>PiB</source>
        <comment>pebibytes (1024 tebibytes)</comment>
        <translation>PiB</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="87"/>
        <source>EiB</source>
        <comment>exbibytes (1024 pebibytes)</comment>
        <translation>EiB</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="268"/>
        <source>/s</source>
        <comment>per second</comment>
        <translation>/s</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="368"/>
        <source>%1h %2m</source>
        <comment>e.g: 3hours 5minutes</comment>
        <translation>%1時間 %2分</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="373"/>
        <source>%1d %2h</source>
        <comment>e.g: 2days 10hours</comment>
        <translation>%1日 %2時間</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="277"/>
        <source>Unknown</source>
        <comment>Unknown (size)</comment>
        <translation>不明</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="148"/>
        <source>qBittorrent will shutdown the computer now because all downloads are complete.</source>
        <translation>すべてのダウンロードが完了したので qBittorrent はコンピューターをシャットダウンします。</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="359"/>
        <source>&lt; 1m</source>
        <comment>&lt; 1 minute</comment>
        <translation>&lt; 1 分</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="363"/>
        <source>%1m</source>
        <comment>e.g: 10minutes</comment>
        <translation>%1 分</translation>
    </message>
</context>
<context>
    <name>preview</name>
    <message>
        <location filename="../gui/previewselectdialog.ui" line="14"/>
        <source>Preview selection</source>
        <translation>選択範囲のプレビュー</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.ui" line="20"/>
        <source>The following files support previewing, please select one of them:</source>
        <translation>以下のファイルのプレビューをサポートしています。どれか 1 つ選んでください：</translation>
    </message>
</context>
</TS>
