Convert SVG icons to PNG
------------------------

install npm

Execute:
```
npm install
```

Convert icons by running:
```
grunt
```