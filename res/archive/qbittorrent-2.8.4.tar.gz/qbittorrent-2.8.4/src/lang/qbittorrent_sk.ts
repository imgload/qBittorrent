<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="sk">
<context>
    <name>AboutDlg</name>
    <message>
        <source>About qBittorrent</source>
        <translation>O aplikácii qBittorrent</translation>
    </message>
    <message>
        <source>About</source>
        <translation>O aplikácii</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation>Meno:</translation>
    </message>
    <message>
        <source>Country:</source>
        <translation>Krajina:</translation>
    </message>
    <message>
        <source>E-mail:</source>
        <translation>E-mail:</translation>
    </message>
    <message>
        <source>Christophe Dumez</source>
        <translation>Christophe Dumez</translation>
    </message>
    <message>
        <source>France</source>
        <translation>Francúzsko</translation>
    </message>
    <message>
        <source>Translation</source>
        <translation>Preklad</translation>
    </message>
    <message>
        <source>License</source>
        <translation>Licencia</translation>
    </message>
    <message>
        <source>&lt;h3&gt;&lt;b&gt;qBittorrent&lt;/b&gt;&lt;/h3&gt;</source>
        <translation>&lt;h3&gt;&lt;b&gt;qBittorrent&lt;/b&gt;&lt;/h3&gt;</translation>
    </message>
    <message>
        <source>chris@qbittorrent.org</source>
        <translation>chris@qbittorrent.org</translation>
    </message>
    <message>
        <source>Thanks to</source>
        <translation>Poďakovanie</translation>
    </message>
    <message utf8="true">
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;A Bittorrent client programmed in C++, based on Qt4 toolkit &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;and libtorrent-rasterbar. &lt;br /&gt;&lt;br /&gt;Copyright ©2006-2010 Christophe Dumez&lt;br /&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Home Page:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://www.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;http://www.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Forum:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://forum.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;http://forum.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;IRC:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; #qbittorrent on Freenode&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;Klient siete Bittorrent naprogramovaný v C++, založený na sade nástrojov Qt4 &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;a libtorrent-rasterbar. &lt;br /&gt;&lt;br /&gt;Copyright ©2006-2010 Christophe Dumez&lt;br /&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Domovská stránka:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://www.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;http://www.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Forum:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://forum.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;http://forum.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;IRC:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; #qbittorrent na Freenode&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message utf8="true">
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;An advanced BitTorrent client programmed in C++, based on Qt4 toolkit and libtorrent-rasterbar. &lt;br /&gt;&lt;br /&gt;Copyright ©2006-2011 Christophe Dumez&lt;br /&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Home Page:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://www.qbittorrent.org&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans&apos;; text-decoration: underline; color:#0057ae;&quot;&gt;http://www.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Bug Tracker:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://bugs.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;http://bugs.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Forum:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://forum.qbittorrent.org&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans&apos;; text-decoration: underline; color:#0057ae;&quot;&gt;http://forum.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;IRC:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; #qbittorrent on Freenode&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;Pokročílý klient siete Bittorrent naprogramovaný v C++, založený na sade nástrojov Qt4 a libtorrent-rasterbar. &lt;br /&gt;&lt;br /&gt;Copyright ©2006-2011 Christophe Dumez&lt;br /&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Domovská stránka:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://www.qbittorrent.org&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans&apos;; text-decoration: underline; color:#0057ae;&quot;&gt;http://www.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Sledovanie chýb:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://bugs.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;http://bugs.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Fórum:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://forum.qbittorrent.org&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans&apos;; text-decoration: underline; color:#0057ae;&quot;&gt;http://forum.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;IRC:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; #qbittorrent na Freenode&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
</context>
<context>
    <name>AdvancedSettings</name>
    <message>
        <source>Property</source>
        <translation type="obsolete">Vlastnosť</translation>
    </message>
    <message>
        <source>Value</source>
        <translation type="obsolete">Hodnota</translation>
    </message>
    <message>
        <source>Ignore transfer limits on local network</source>
        <translation>Ignorovať prenosové limity na lokálnej sieti</translation>
    </message>
    <message>
        <source>Include TCP/IP overhead in transfer limits</source>
        <translation type="obsolete">Zarátavať réžiu TCP/IP do prenosových limitov</translation>
    </message>
    <message>
        <source>Disk write cache size</source>
        <translation>Veľkosť vyrovnávacej pamäte pre zápis na disk</translation>
    </message>
    <message>
        <source> MiB</source>
        <translation>MiB</translation>
    </message>
    <message>
        <source>Outgoing ports (Min) [0: Disabled]</source>
        <translation>Odcházajúce porty (min) [0: Vyonuté]</translation>
    </message>
    <message>
        <source>Outgoing ports (Max) [0: Disabled]</source>
        <translation>Odcházajúce porty (max) [0: Vyonuté]</translation>
    </message>
    <message>
        <source>Recheck torrents on completion</source>
        <translation>Znovu skontrolovať torrenty po dokončení</translation>
    </message>
    <message>
        <source>Transfer list refresh interval</source>
        <translation>Interval obnovovania zoznamu prenosov</translation>
    </message>
    <message>
        <source> ms</source>
        <comment> milliseconds</comment>
        <translation>ms</translation>
    </message>
    <message>
        <source>Resolve peer countries (GeoIP)</source>
        <translation>Prekladať názvy krajín rovesníkov (GeoIP)</translation>
    </message>
    <message>
        <source>Resolve peer host names</source>
        <translation>Prekladať názvy počítačov rovesníkov</translation>
    </message>
    <message>
        <source>Maximum number of half-open connections [0: Disabled]</source>
        <translation>Maximálny počet polootvorených spojení [0: vypnuté]</translation>
    </message>
    <message>
        <source>Strict super seeding</source>
        <translation>Prísne super seedovanie</translation>
    </message>
    <message>
        <source>Network Interface (requires restart)</source>
        <translation>Sieťové rozhranie (vyžaduje reštart)</translation>
    </message>
    <message>
        <source>Any interface</source>
        <comment>i.e. Any network interface</comment>
        <translation>t.j. Ľubovoľné sieťové rozhranie</translation>
    </message>
    <message>
        <source>Display program notification baloons</source>
        <translation type="obsolete">Zobrazovať bublinové upozornenia programu</translation>
    </message>
    <message>
        <source>Display program notification balloons</source>
        <translation type="obsolete">Zobrazovať bublinové upozornenia programu</translation>
    </message>
    <message>
        <source>Enable embedded tracker</source>
        <translation>Zapnúť zabudovaný tracker</translation>
    </message>
    <message>
        <source>Embedded tracker port</source>
        <translation>Port zabudovaného trackera</translation>
    </message>
    <message>
        <source>Check for software updates</source>
        <translation>Skontrolovať aktualizácie softvéru</translation>
    </message>
    <message>
        <source>Use system icon theme</source>
        <translation>Používať vzhľad ikon systému</translation>
    </message>
    <message>
        <source>Confirm torrent deletion</source>
        <translation>Potvrdenie zmazania torrentu</translation>
    </message>
    <message>
        <source>IP Address to report to trackers (requires restart)</source>
        <translation>Akú IP adresu oznamovať trackeru (vyžaduje reštart)</translation>
    </message>
    <message>
        <source>Display program on-screen notifications</source>
        <translation>Zobrazovať OSD upozornenia</translation>
    </message>
    <message>
        <source>Setting</source>
        <translation>Nastavenie</translation>
    </message>
    <message>
        <source>Value</source>
        <comment>Value set for this setting</comment>
        <translation>Hodnota</translation>
    </message>
    <message>
        <source>Exchange trackers with other peers</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AutomatedRssDownloader</name>
    <message>
        <source>Automated RSS Downloader</source>
        <translation>Automatické sťahovanie RSS</translation>
    </message>
    <message>
        <source>Enable the automated RSS downloader</source>
        <translation>Zapnúť automatické sťahovanie RSS</translation>
    </message>
    <message>
        <source>Download rules</source>
        <translation>Pravidlá sťahovania</translation>
    </message>
    <message>
        <source>Rule definition</source>
        <translation>Definícia pravidla</translation>
    </message>
    <message>
        <source>Must contain:</source>
        <translation>Musí obsahovať:</translation>
    </message>
    <message>
        <source>Must not contain:</source>
        <translation>Nesmie obsahovať:</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Assign label:</source>
        <translation>Priradiť označenie:</translation>
    </message>
    <message>
        <source>Apply rule to feeds:</source>
        <translation>Použiť pravidlo na kanáy:</translation>
    </message>
    <message>
        <source>Matching RSS articles</source>
        <translation>Zodpovedajúce RSS články</translation>
    </message>
    <message>
        <source>Save to a different directory</source>
        <translation>Uložiť do iného adresára</translation>
    </message>
    <message>
        <source>Save to:</source>
        <translation>Uložiť do:</translation>
    </message>
    <message>
        <source>Import...</source>
        <translation>Importovať...</translation>
    </message>
    <message>
        <source>Export...</source>
        <translation>Exportovať...</translation>
    </message>
    <message>
        <source>New rule name</source>
        <translation>Nový názov pravidla</translation>
    </message>
    <message>
        <source>Please type the name of the new download rule.</source>
        <translation>Prosím, napíšte nový názov pre tonto pravidlo sťahovania.</translation>
    </message>
    <message>
        <source>Rule name conflict</source>
        <translation>Konflikt v názvoch pravidel</translation>
    </message>
    <message>
        <source>A rule with this name already exists, please choose another name.</source>
        <translation>Pravidlo s týmto názvom už existuje. Prosím, zvoľte iný názov.</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the download rule named %1?</source>
        <translation>Ste si istý, že chcete odstrániť pravidlo sťahovania s názvom %1?</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the selected download rules?</source>
        <translation>Ste si istý, že chcete odstrániť vybrané pravidlá sťahovania?</translation>
    </message>
    <message>
        <source>Rule deletion confirmation</source>
        <translation>Potvrdenie zmazania pravidla</translation>
    </message>
    <message>
        <source>Destination directory</source>
        <translation>Cieľový adresár</translation>
    </message>
    <message>
        <source>Invalid action</source>
        <translation>Neplatná operácia</translation>
    </message>
    <message>
        <source>The list is empty, there is nothing to export.</source>
        <translation>Zoznam je prázdny, niet čo exportovať.</translation>
    </message>
    <message>
        <source>Where would you like to save the list?</source>
        <translation>Kam chcete uložiť tento súbor?</translation>
    </message>
    <message>
        <source>Rules list (*.rssrules)</source>
        <translation>Zoznam pravidiel (*.rssrules)</translation>
    </message>
    <message>
        <source>I/O Error</source>
        <translation>V/V Chyba</translation>
    </message>
    <message>
        <source>Failed to create the destination file</source>
        <translation>Nepodarilo sa vytvoriť cieľový súbor</translation>
    </message>
    <message>
        <source>Please point to the RSS download rules file</source>
        <translation>Prosím, vyberte súbor s pravidlami sťahovania RSS</translation>
    </message>
    <message>
        <source>Rules list (*.rssrules *.filters)</source>
        <translation>Zoznam pravidiel (*.rssrules *.filters)</translation>
    </message>
    <message>
        <source>Import Error</source>
        <translation>Chyba importu</translation>
    </message>
    <message>
        <source>Failed to import the selected rules file</source>
        <translation>Nepodarilo sa importovať vybraný súbor pravidiel</translation>
    </message>
    <message>
        <source>Add new rule...</source>
        <translation>Pridať nové pravidlo...</translation>
    </message>
    <message>
        <source>Delete rule</source>
        <translation>Zmazať pravidlo</translation>
    </message>
    <message>
        <source>Rename rule...</source>
        <translation>Premenovať pravidlo...</translation>
    </message>
    <message>
        <source>Delete selected rules</source>
        <translation>Zmazať vybrané pravidlá</translation>
    </message>
    <message>
        <source>Rule renaming</source>
        <translation>Premenovanie pravidiel</translation>
    </message>
    <message>
        <source>Please type the new rule name</source>
        <translation>Prosím, napíšte názov nového pravidla</translation>
    </message>
    <message>
        <source>Use regular expressions</source>
        <translation>Používať regulárne výrazy</translation>
    </message>
    <message>
        <source>Regex mode: use Perl-like regular expressions</source>
        <translation>Režim regulárnych výrazov: používať štýl Perl</translation>
    </message>
    <message>
        <source>Wildcard mode: you can use&lt;ul&gt;&lt;li&gt;? to match any single character&lt;/li&gt;&lt;li&gt;* to match zero or more of any characters&lt;/li&gt;&lt;li&gt;Whitespaces count as AND operators&lt;/li&gt;&lt;/ul&gt;</source>
        <translation>Režim zástupných znakov: &lt;ul&gt;&lt;li&gt;? zodpovedá ľubovoľnému jednotlivému znaku&lt;/li&gt;&lt;li&gt;* zodpovedá nula alebo viac ľubovoľným znakom&lt;/li&gt;&lt;li&gt;Netlačiteľné znaky sa počítajú ako operátory AND&lt;/li&gt;&lt;/ul&gt;</translation>
    </message>
    <message>
        <source>Wildcard mode: you can use&lt;ul&gt;&lt;li&gt;? to match any single character&lt;/li&gt;&lt;li&gt;* to match zero or more of any characters&lt;/li&gt;&lt;li&gt;| is used as OR operator&lt;/li&gt;&lt;/ul&gt;</source>
        <translation>Režim zástupných znakov: &lt;ul&gt;&lt;li&gt;? zodpovedá ľubovoľnému jednotlivému znaku&lt;/li&gt;&lt;li&gt;* zodpovedá nula alebo viac ľubovoľným znakom&lt;/li&gt;&lt;li&gt;| sa používa ako operátor OR&lt;/li&gt;&lt;/ul&gt;</translation>
    </message>
</context>
<context>
    <name>Bittorrent</name>
    <message>
        <source>%1 reached the maximum ratio you set.</source>
        <translation type="obsolete">%1 dosiahol maximálny požadovaný pomer.</translation>
    </message>
    <message>
        <source>qBittorrent is bound to port: TCP/%1</source>
        <comment>e.g: qBittorrent is bound to port: 6881</comment>
        <translation type="obsolete">qBittorrent sa viaže na port: TCP/%1</translation>
    </message>
    <message>
        <source>UPnP support [ON]</source>
        <translation type="obsolete">Podpora UPnP [zapnutá]</translation>
    </message>
    <message>
        <source>UPnP support [OFF]</source>
        <translation type="obsolete">Podpora UPnP [vypnutá]</translation>
    </message>
    <message>
        <source>NAT-PMP support [ON]</source>
        <translation type="obsolete">Podpora NAT-PMP [zapnutá]</translation>
    </message>
    <message>
        <source>NAT-PMP support [OFF]</source>
        <translation type="obsolete">Podpora NAT-PMP [vypnutá]</translation>
    </message>
    <message>
        <source>DHT support [ON], port: UDP/%1</source>
        <translation type="obsolete">Podpora DHT [ZAP], port: UDP/%1</translation>
    </message>
    <message>
        <source>DHT support [OFF]</source>
        <translation type="obsolete">Podpora DHT [vypnutá]</translation>
    </message>
    <message>
        <source>PeX support [ON]</source>
        <translation type="obsolete">Podpora PeX [zapnutá]</translation>
    </message>
    <message>
        <source>Local Peer Discovery [ON]</source>
        <translation type="obsolete">Local Peer Discovery [zapnutá]</translation>
    </message>
    <message>
        <source>Local Peer Discovery support [OFF]</source>
        <translation type="obsolete">Podpora Local Peer Discovery support [vypnutá]</translation>
    </message>
    <message>
        <source>Encryption support [ON]</source>
        <translation type="obsolete">Podpora šifrovania [zapnuté]</translation>
    </message>
    <message>
        <source>Encryption support [FORCED]</source>
        <translation type="obsolete">Podpora šifrovania [vynútené]</translation>
    </message>
    <message>
        <source>Encryption support [OFF]</source>
        <translation type="obsolete">Podpora šifrovania [vypnuté]</translation>
    </message>
    <message>
        <source>Web User Interface Error - Unable to bind Web UI to port %1</source>
        <translation type="obsolete">Chyba webového rozhrania - nepodaril sa bind webového rozhrania na port %1</translation>
    </message>
    <message>
        <source>&apos;%1&apos; was removed from transfer list and hard disk.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation type="obsolete">„%1“ bol odstránený zo zoznamu sťahovaných a z pevného disku.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; was removed from transfer list.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation type="obsolete">„%1“ bol odstránený zo zoznamu sťahovaných.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is not a valid magnet URI.</source>
        <translation type="obsolete">„%1“ nie je platný magnet URI.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is already in download list.</source>
        <comment>e.g: &apos;xxx.avi&apos; is already in download list.</comment>
        <translation type="obsolete">„%1“ sa už nachádza v zozname sťahovaných.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; resumed. (fast resume)</source>
        <comment>&apos;/home/y/xxx.torrent&apos; was resumed. (fast resume)</comment>
        <translation type="obsolete">„%1“ bol obnovený. (rýchle obnovenie)</translation>
    </message>
    <message>
        <source>&apos;%1&apos; added to download list.</source>
        <comment>&apos;/home/y/xxx.torrent&apos; was added to download list.</comment>
        <translation type="obsolete">„%1“ bol pridaný do zoznamu na sťahovanie.</translation>
    </message>
    <message>
        <source>Unable to decode torrent file: &apos;%1&apos;</source>
        <comment>e.g: Unable to decode torrent file: &apos;/home/y/xxx.torrent&apos;</comment>
        <translation type="obsolete">Nepodarilo sa dekódovať torrent súbor: „%1“</translation>
    </message>
    <message>
        <source>This file is either corrupted or this isn&apos;t a torrent.</source>
        <translation type="obsolete">Tento súbor je buď poškodený alebo to nie je torrent.</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;was blocked due to your IP filter&lt;/i&gt;</source>
        <comment>x.y.z.w was blocked</comment>
        <translation type="obsolete">&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;zablokoval váš filter IP adries&lt;/i&gt;</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;was banned due to corrupt pieces&lt;/i&gt;</source>
        <comment>x.y.z.w was banned</comment>
        <translation type="obsolete">&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;zablokovaný kvôli posielaniu poškodených častí&lt;/i&gt;</translation>
    </message>
    <message>
        <source>Recursive download of file %1 embedded in torrent %2</source>
        <comment>Recursive download of test.torrent embedded in torrent test2</comment>
        <translation type="obsolete">Rekurzívne sťahovanie súboru %1 vnoreného v torrente %2</translation>
    </message>
    <message>
        <source>Unable to decode %1 torrent file.</source>
        <translation type="obsolete">Nepodarilo sa dekódovať torrent súbor %1.</translation>
    </message>
    <message>
        <source>UPnP/NAT-PMP: Port mapping failure, message: %1</source>
        <translation type="obsolete">UPnP/NAT-PMP: Zlyhanie mapovania portov, správa: %1</translation>
    </message>
    <message>
        <source>UPnP/NAT-PMP: Port mapping successful, message: %1</source>
        <translation type="obsolete">UPnP/NAT-PMP: Mapovanie portov úspešné, správa: %1</translation>
    </message>
    <message>
        <source>Fast resume data was rejected for torrent %1, checking again...</source>
        <translation type="obsolete">Rýchle obnovenie torrentu %1 bolo odmietnuté, prebieha opätovná kontrola...</translation>
    </message>
    <message>
        <source>Url seed lookup failed for url: %1, message: %2</source>
        <translation type="obsolete">Vyhľadanie url seedu zlyhalo pre url: %1, správa: %2</translation>
    </message>
    <message>
        <source>Downloading &apos;%1&apos;, please wait...</source>
        <comment>e.g: Downloading &apos;xxx.torrent&apos;, please wait...</comment>
        <translation type="obsolete">Prebieha sťahovanie „%1“, čakajte prosím...</translation>
    </message>
    <message>
        <source>Using a disk cache size of %1 MiB</source>
        <translation type="obsolete">Používa sa veľkosť vyrovnávacej diskovej pamäte %1 MiB</translation>
    </message>
    <message>
        <source>PeX support [OFF]</source>
        <translation type="obsolete">Podpora PeX [VYP]</translation>
    </message>
    <message>
        <source>Restart is required to toggle PeX support</source>
        <translation type="obsolete">Na prepnutie podpory PeX je potrebný reštart</translation>
    </message>
    <message>
        <source>The Web UI is listening on port %1</source>
        <translation type="obsolete">Webové rozhranie počúva na porte %1</translation>
    </message>
    <message>
        <source>HTTP user agent is %1</source>
        <translation type="obsolete">HTTP user agent je %1</translation>
    </message>
    <message>
        <source>Reason: %1</source>
        <translation type="obsolete">Dôvod: %1</translation>
    </message>
    <message>
        <source>Note: new trackers were added to the existing torrent.</source>
        <translation type="obsolete">Pozn.: Do existujúceho torrentu boli pridané nové trackery.</translation>
    </message>
    <message>
        <source>Note: new URL seeds were added to the existing torrent.</source>
        <translation type="obsolete">Pozn.: Do existujúceho torrentu boli pridané nové URL seedy.</translation>
    </message>
    <message>
        <source>An I/O error occured, &apos;%1&apos; paused.</source>
        <translation type="obsolete">Vyskytla sa V/V chyba, „%1“ pozastavené.</translation>
    </message>
    <message>
        <source>Removing torrent %1...</source>
        <translation type="obsolete">Odstraňuje sa torrent %1...</translation>
    </message>
    <message>
        <source>Pausing torrent %1...</source>
        <translation type="obsolete">Pozastavuje sa torrent %1...</translation>
    </message>
    <message>
        <source>Error: The torrent %1 does not contain any file.</source>
        <translation type="obsolete">Chyba: Torrent %1 neobsahuje žiaden súbor.</translation>
    </message>
    <message>
        <source>File sizes mismatch for torrent %1, pausing it.</source>
        <translation type="obsolete">Veľkosti súborov sa líšia pri torrente %1, pozastavuje sa.</translation>
    </message>
    <message>
        <source>Torrent name: %1</source>
        <translation type="obsolete">Názov torrentu: %1</translation>
    </message>
    <message>
        <source>Torrent size: %1</source>
        <translation type="obsolete">Veľkosť torrentu: %1</translation>
    </message>
    <message>
        <source>The torrent was downloaded in %1.</source>
        <comment>The torrent was downloaded in 1 hour and 20 seconds</comment>
        <translation type="obsolete">Torrent bol stiahnutý za %1.</translation>
    </message>
    <message>
        <source>Thank you for using qBittorrent.</source>
        <translation type="obsolete">Ďakujeme, že používate qBittorrent.</translation>
    </message>
    <message>
        <source>[qBittorrent] %1 has finished downloading</source>
        <translation type="obsolete">[qBittorrent] sťahovanie %1 bolo dokončené</translation>
    </message>
</context>
<context>
    <name>ConsoleDlg</name>
    <message>
        <source>General</source>
        <translation type="obsolete">Všeobecné</translation>
    </message>
    <message>
        <source>Blocked IPs</source>
        <translation type="obsolete">Zablokované IP</translation>
    </message>
    <message>
        <source>qBittorrent log viewer</source>
        <translation type="obsolete">Prehliadač záznamov qBittorrent</translation>
    </message>
</context>
<context>
    <name>CookiesDlg</name>
    <message>
        <source>Cookies management</source>
        <translation>Správa cookies</translation>
    </message>
    <message>
        <source>Key</source>
        <extracomment>As in Key/Value pair</extracomment>
        <translation>Kľúč</translation>
    </message>
    <message>
        <source>Value</source>
        <extracomment>As in Key/Value pair</extracomment>
        <translation>Hodnota</translation>
    </message>
    <message>
        <source>Common keys for cookies are : &apos;%1&apos;, &apos;%2&apos;.
You should get this information from your Web browser preferences.</source>
        <translation>Bežné kľúče cookies sú : &apos;%1&apos;, &apos;%2&apos;.
Túto informáciu by ste mali zistiť z nastavení svojho webového prehliadača.</translation>
    </message>
</context>
<context>
    <name>DNSUpdater</name>
    <message>
        <source>Your dynamic DNS was successfuly updated.</source>
        <translation>Váš dynamický DNS záznam bol úspešne aktualizovaný.</translation>
    </message>
    <message>
        <source>Dynamic DNS error: The service is temporarily unavailable, it will be retried in 30 minutes.</source>
        <translation>Chyba dynamického DNS: Služba je dočasne nedostupná, pokus sa zopakuje o 30 minút.</translation>
    </message>
    <message>
        <source>Dynamic DNS error: hostname supplied does not exist under specified account.</source>
        <translation>Chyba dynamického DNS: Zadaný názov hostiteľa v uvedenom účte neexistuje.</translation>
    </message>
    <message>
        <source>Dynamic DNS error: Invalid username/password.</source>
        <translation>Chyba dynamického DNS: Neplatné používateľské meno alebo heslo.</translation>
    </message>
    <message>
        <source>Dynamic DNS error: qBittorrent was blacklisted by the service, please report a bug at http://bugs.qbittorrent.org.</source>
        <translation>Chyba dynamického DNS: qBittorrent bol zaradenú na čiernu listinu služby, prosím, nahláste chybu na http://bugs.qbittorrent.org.</translation>
    </message>
    <message>
        <source>Dynamic DNS error: %1 was returned by the service, please report a bug at http://bugs.qbittorrent.org.</source>
        <translation>Chyba dynamického DNS: Služba vrátila %1, prosím, nahláste chybu na http://bugs.qbittorrent.org.</translation>
    </message>
    <message>
        <source>Dynamic DNS error: Your username was blocked due to abuse.</source>
        <translation>Chyba dynamického DNS: Vaše používateľské meno bolo zablokované z dôvodu zneužitia.</translation>
    </message>
    <message>
        <source>Dynamic DNS error: supplied domain name is invalid.</source>
        <translation>Chyba dynamického DNS: Zadaný názov domény nie je platný.</translation>
    </message>
    <message>
        <source>Dynamic DNS error: supplied username is too short.</source>
        <translation>Chyba dynamického DNS: Zadané používateľské meno je príliš krátke.</translation>
    </message>
    <message>
        <source>Dynamic DNS error: supplied password is too short.</source>
        <translation>Chyba dynamického DNS: Zadané heslo je príliš krátke.</translation>
    </message>
</context>
<context>
    <name>DownloadThread</name>
    <message>
        <source>I/O Error</source>
        <translation>V/V Chyba</translation>
    </message>
    <message>
        <source>The remote host name was not found (invalid hostname)</source>
        <translation>Názov vzdialeného počítača nebol zistený (neplatný názov počítača)</translation>
    </message>
    <message>
        <source>The operation was canceled</source>
        <translation>Operácia bola zrušená</translation>
    </message>
    <message>
        <source>The remote server closed the connection prematurely, before the entire reply was received and processed</source>
        <translation>Vzdialený server predčasne zatvoril spojenie predtým, než bola prijatá a spracovaná celá odpoveď</translation>
    </message>
    <message>
        <source>The connection to the remote server timed out</source>
        <translation>Čas spojenia so vzdialeným serverom vypršal</translation>
    </message>
    <message>
        <source>SSL/TLS handshake failed</source>
        <translation>SSL/TLS handshake zlyhal</translation>
    </message>
    <message>
        <source>The remote server refused the connection</source>
        <translation>Vzdialený server odmietol spojenie</translation>
    </message>
    <message>
        <source>The connection to the proxy server was refused</source>
        <translation>Spojenie s proxy serverom bolo odmietnuté</translation>
    </message>
    <message>
        <source>The proxy server closed the connection prematurely</source>
        <translation>Proxy server predčasne zatvoril spojenie</translation>
    </message>
    <message>
        <source>The proxy host name was not found</source>
        <translation>Názov proxy servera nebol nájdený</translation>
    </message>
    <message>
        <source>The connection to the proxy timed out or the proxy did not reply in time to the request sent</source>
        <translation>Čas spojenia s proxy serverom vypršal alebo proxy server neodpovedal včas na zaslanú požiadavku</translation>
    </message>
    <message>
        <source>The proxy requires authentication in order to honour the request but did not accept any credentials offered</source>
        <translation>Proxy vyžaduje autentifikáciu aby mohol splniť požiadavku, ale neprijal žiadne z ponúknutých prihlasovacích údajov</translation>
    </message>
    <message>
        <source>The access to the remote content was denied (401)</source>
        <translation>Prístup k vzdialenému obsahu bol zamietnutý (401)</translation>
    </message>
    <message>
        <source>The operation requested on the remote content is not permitted</source>
        <translation>Požadovaná operácia so vzdialeným obsahom nie je povolená</translation>
    </message>
    <message>
        <source>The remote content was not found at the server (404)</source>
        <translation>Vzdialený obsah nebol nájdený na serveri (404)</translation>
    </message>
    <message>
        <source>The remote server requires authentication to serve the content but the credentials provided were not accepted</source>
        <translation>Vzdialený server vyžaduje na poskytnutie obsahu autentifikáciu, ale neprijal žiadne z ponúknutých prihlasovacích údajov</translation>
    </message>
    <message>
        <source>The Network Access API cannot honor the request because the protocol is not known</source>
        <translation>Network Access API neprijalo požiadavku, pretože nie je známy protokol</translation>
    </message>
    <message>
        <source>The requested operation is invalid for this protocol</source>
        <translation>Požadovaná operácia nie je platná pre tento protokol</translation>
    </message>
    <message>
        <source>An unknown network-related error was detected</source>
        <translation>Bola zistená neznáma chyba týkajúca sa siete</translation>
    </message>
    <message>
        <source>An unknown proxy-related error was detected</source>
        <translation>Bola zistená neznáma chyba týkajúca sa proxy</translation>
    </message>
    <message>
        <source>An unknown error related to the remote content was detected</source>
        <translation>Bola zistená neznáma chyba týkajúca sa vzdialeného obsahu</translation>
    </message>
    <message>
        <source>A breakdown in protocol was detected</source>
        <translation>Bola zistená porucha v protokole</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Neznáma chyba</translation>
    </message>
</context>
<context>
    <name>EventManager</name>
    <message>
        <source>%1/s</source>
        <comment>e.g. 120 KiB/s</comment>
        <translation>%1/s</translation>
    </message>
    <message>
        <source>Working</source>
        <translation>Pracuje sa</translation>
    </message>
    <message>
        <source>Updating...</source>
        <translation>Prebieha aktualizácia...</translation>
    </message>
    <message>
        <source>Not working</source>
        <translation>Nefunguje</translation>
    </message>
    <message>
        <source>Not contacted yet</source>
        <translation>Zatiaľ nekontaktovaný</translation>
    </message>
    <message>
        <source>this session</source>
        <translation>táto relácia</translation>
    </message>
    <message>
        <source>/s</source>
        <comment>/second (i.e. per second)</comment>
        <translation>/s</translation>
    </message>
    <message>
        <source>Seeded for %1</source>
        <comment>e.g. Seeded for 3m10s</comment>
        <translation>Seedovaný %1</translation>
    </message>
    <message>
        <source>%1 max</source>
        <comment>e.g. 10 max</comment>
        <translation>max %1</translation>
    </message>
</context>
<context>
    <name>ExecutionLog</name>
    <message>
        <source>Form</source>
        <translation type="obsolete">Formulár</translation>
    </message>
    <message>
        <source>General</source>
        <translation>Všeobecné</translation>
    </message>
    <message>
        <source>Blocked IPs</source>
        <translation>Zablokované IP</translation>
    </message>
</context>
<context>
    <name>FeedDownloader</name>
    <message>
        <source>RSS Feed downloader</source>
        <translation type="obsolete">Sťahovanie RSS kanála</translation>
    </message>
    <message>
        <source>RSS feed:</source>
        <translation type="obsolete">RSS kanál:</translation>
    </message>
    <message>
        <source>Feed name</source>
        <translation type="obsolete">Názov kanála</translation>
    </message>
    <message>
        <source>Automatically download torrents from this feed</source>
        <translation type="obsolete">Automaticky sťahovať torrenty z tohto kanála</translation>
    </message>
    <message>
        <source>Download filters</source>
        <translation type="obsolete">Filtre sťahovania</translation>
    </message>
    <message>
        <source>Filters:</source>
        <translation type="obsolete">Filtre:</translation>
    </message>
    <message>
        <source>Filter settings</source>
        <translation type="obsolete">Nastavenia filtrov</translation>
    </message>
    <message>
        <source>Matches:</source>
        <translation type="obsolete">Zodpovedá:</translation>
    </message>
    <message>
        <source>Does not match:</source>
        <translation type="obsolete">Nezodpovedá:</translation>
    </message>
    <message>
        <source>Destination folder:</source>
        <translation type="obsolete">Cieľový priečinok:</translation>
    </message>
    <message>
        <source>...</source>
        <translation type="obsolete">...</translation>
    </message>
    <message>
        <source>Filter testing</source>
        <translation type="obsolete">Testovanie filtra</translation>
    </message>
    <message>
        <source>Torrent title:</source>
        <translation type="obsolete">Názov torrentu:</translation>
    </message>
    <message>
        <source>Result:</source>
        <translation type="obsolete">Výsledok:</translation>
    </message>
    <message>
        <source>Test</source>
        <translation type="obsolete">Test</translation>
    </message>
    <message>
        <source>Import...</source>
        <translation type="obsolete">Import...</translation>
    </message>
    <message>
        <source>Export...</source>
        <translation type="obsolete">Export...</translation>
    </message>
    <message>
        <source>Rename filter</source>
        <translation type="obsolete">Premenovať filter</translation>
    </message>
    <message>
        <source>Remove filter</source>
        <translation type="obsolete">Odstrániť filter</translation>
    </message>
    <message>
        <source>Add filter</source>
        <translation type="obsolete">Pridať filter</translation>
    </message>
</context>
<context>
    <name>FeedDownloaderDlg</name>
    <message>
        <source>New filter</source>
        <translation type="obsolete">Nový filter</translation>
    </message>
    <message>
        <source>Please choose a name for this filter</source>
        <translation type="obsolete">Prosím, vyberte názov pre tento filter</translation>
    </message>
    <message>
        <source>Filter name:</source>
        <translation type="obsolete">Názov filtra:</translation>
    </message>
    <message>
        <source>Invalid filter name</source>
        <translation type="obsolete">Neplatný názov filtra</translation>
    </message>
    <message>
        <source>The filter name cannot be left empty.</source>
        <translation type="obsolete">Názov filtra nemôže byť prázdny.</translation>
    </message>
    <message>
        <source>This filter name is already in use.</source>
        <translation type="obsolete">Tento názov filtra už existuje.</translation>
    </message>
    <message>
        <source>Filter testing error</source>
        <translation type="obsolete">Chyba pri testovaní filtra</translation>
    </message>
    <message>
        <source>Please specify a test torrent name.</source>
        <translation type="obsolete">Prosím, uveďte názov testovacieho torrentu.</translation>
    </message>
    <message>
        <source>matches</source>
        <translation type="obsolete">zodpovedá</translation>
    </message>
    <message>
        <source>does not match</source>
        <translation type="obsolete">nezodpovedá</translation>
    </message>
    <message>
        <source>Select file to import</source>
        <translation type="obsolete">Vyberte súbor na import</translation>
    </message>
    <message>
        <source>Filters Files</source>
        <translation type="obsolete">Filtre Súbory</translation>
    </message>
    <message>
        <source>Import successful</source>
        <translation type="obsolete">Import prebehol úspešne</translation>
    </message>
    <message>
        <source>Filters import was successful.</source>
        <translation type="obsolete">Import filtrov prebehol úspešne.</translation>
    </message>
    <message>
        <source>Import failure</source>
        <translation type="obsolete">Chyba importu</translation>
    </message>
    <message>
        <source>Filters could not be imported due to an I/O error.</source>
        <translation type="obsolete">Nebolo možné importovať filtre z dôvodu V/V chyby.</translation>
    </message>
    <message>
        <source>Select destination file</source>
        <translation type="obsolete">Vyberte cieľový súbor</translation>
    </message>
    <message>
        <source>Export successful</source>
        <translation type="obsolete">Export prebehol úspešne</translation>
    </message>
    <message>
        <source>Filters export was successful.</source>
        <translation type="obsolete">Export filtrov prebehol úspešne.</translation>
    </message>
    <message>
        <source>Export failure</source>
        <translation type="obsolete">Chyba exportu</translation>
    </message>
    <message>
        <source>Filters could not be exported due to an I/O error.</source>
        <translation type="obsolete">Nebolo možné exportovať filtre z dôvodu V/V chyby.</translation>
    </message>
    <message>
        <source>Choose save path</source>
        <translation type="obsolete">Ukladať kam</translation>
    </message>
</context>
<context>
    <name>FeedList</name>
    <message>
        <source>Unread</source>
        <translation type="obsolete">Neprečítané</translation>
    </message>
</context>
<context>
    <name>FeedListWidget</name>
    <message>
        <source>RSS feeds</source>
        <translation>RSS kanály
</translation>
    </message>
    <message>
        <source>Unread</source>
        <translation>Neprečítané</translation>
    </message>
</context>
<context>
    <name>GUI</name>
    <message>
        <source>Open Torrent Files</source>
        <translation type="obsolete">Otvoriť torrent súbory</translation>
    </message>
    <message>
        <source>Torrent Files</source>
        <translation type="obsolete">Torrent súbory</translation>
    </message>
    <message>
        <source>qBittorrent</source>
        <translation type="obsolete">qBittorrent</translation>
    </message>
    <message>
        <source>Transfers</source>
        <translation type="obsolete">Prenosy</translation>
    </message>
    <message>
        <source>qBittorrent %1</source>
        <comment>e.g: qBittorrent v0.x</comment>
        <translation type="obsolete">qBittorrent %1</translation>
    </message>
    <message>
        <source>DL speed: %1 KiB/s</source>
        <comment>e.g: Download speed: 10 KiB/s</comment>
        <translation type="obsolete">Rýchlosť sťahovania: %1 KiB/s</translation>
    </message>
    <message>
        <source>UP speed: %1 KiB/s</source>
        <comment>e.g: Upload speed: 10 KiB/s</comment>
        <translation type="obsolete">Rýchlosť nahrávania: %1 KiB/s</translation>
    </message>
    <message>
        <source>%1 has finished downloading.</source>
        <comment>e.g: xxx.avi has finished downloading.</comment>
        <translation type="obsolete">%1 je stiahnutý.</translation>
    </message>
    <message>
        <source>I/O Error</source>
        <comment>i.e: Input/Output Error</comment>
        <translation type="obsolete">V/V Chyba</translation>
    </message>
    <message>
        <source>Search</source>
        <translation type="obsolete">Vyhľadávanie</translation>
    </message>
    <message>
        <source>An I/O error occured for torrent %1.
 Reason: %2</source>
        <comment>e.g: An error occured for torrent xxx.avi.
 Reason: disk is full.</comment>
        <translation type="obsolete">Vyskytla sa V/V chyba pri torrente %1.
 Dôvod: %2</translation>
    </message>
    <message>
        <source>Alt+1</source>
        <comment>shortcut to switch to first tab</comment>
        <translation type="obsolete">Alt+1</translation>
    </message>
    <message>
        <source>Url download error</source>
        <translation type="obsolete">Chyba sťahovania url</translation>
    </message>
    <message>
        <source>Couldn&apos;t download file at url: %1, reason: %2.</source>
        <translation type="obsolete">Nebolo možné stiahnuť súbor z url: %1, dôvod: %2.</translation>
    </message>
    <message>
        <source>Ctrl+F</source>
        <comment>shortcut to switch to search tab</comment>
        <translation type="obsolete">Ctrl+F</translation>
    </message>
    <message>
        <source>Options were saved successfully.</source>
        <translation type="obsolete">Nastavenia boli úspešne uložené.</translation>
    </message>
    <message>
        <source>Download completion</source>
        <translation type="obsolete">Dokončenie sťahovnia</translation>
    </message>
    <message>
        <source>Some files are currently transferring.
Are you sure you want to quit qBittorrent?</source>
        <translation type="obsolete">Niektoré súbory sa práve prenášajú.
Ste si istý, že chcete ukončiť Bittorrent?</translation>
    </message>
    <message>
        <source>Alt+2</source>
        <comment>shortcut to switch to third tab</comment>
        <translation type="obsolete">Alt+2</translation>
    </message>
    <message>
        <source>Alt+3</source>
        <comment>shortcut to switch to fourth tab</comment>
        <translation type="obsolete">Alt+3</translation>
    </message>
    <message>
        <source>Global Upload Speed Limit</source>
        <translation type="obsolete">Globálne rýchlostné obmedzenie nahrávania</translation>
    </message>
    <message>
        <source>Global Download Speed Limit</source>
        <translation type="obsolete">Globálne rýchlostné obmedzenie sťahovania</translation>
    </message>
    <message>
        <source>qBittorrent %1 (Down: %2/s, Up: %3/s)</source>
        <comment>%1 is qBittorrent version</comment>
        <translation type="obsolete">qBittorrent %1 (sťah: %2/s, nahr: %3/s)</translation>
    </message>
    <message>
        <source>Recursive download confirmation</source>
        <translation type="obsolete">Potvrdenie rekurzívneho sťahovania</translation>
    </message>
    <message>
        <source>The torrent %1 contains torrent files, do you want to proceed with their download?</source>
        <translation type="obsolete">Torrent %1 obsahuje ďalšie súbory torrent. Chcete začať sťahovať aj tie?</translation>
    </message>
    <message>
        <source>Torrent file association</source>
        <translation type="obsolete">Asociácia typu súboru .torrent</translation>
    </message>
    <message>
        <source>qBittorrent is not the default application to open torrent files or Magnet links.
Do you want to associate qBittorrent to torrent files and Magnet links?</source>
        <translation type="obsolete">qBittorrent nie je predvolená aplikácia na otváranie súborov torrent a odkazov Magnet.
Chcete asociovať qbittorrent so súbormi torrent a odkazmi Magnet?</translation>
    </message>
    <message>
        <source>Transfers (%1)</source>
        <translation type="obsolete">Prenosy (%1)</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation type="obsolete">Áno</translation>
    </message>
    <message>
        <source>No</source>
        <translation type="obsolete">Nie</translation>
    </message>
    <message>
        <source>Never</source>
        <translation type="obsolete">Nikdy</translation>
    </message>
    <message>
        <source>Always</source>
        <translation type="obsolete">Vždy</translation>
    </message>
    <message>
        <source>Exiting qBittorrent</source>
        <translation type="obsolete">Ukončuje sa qBittorrent</translation>
    </message>
    <message>
        <source>Set the password...</source>
        <translation type="obsolete">Nastaviť heslo...</translation>
    </message>
    <message>
        <source>Password update</source>
        <translation type="obsolete">Aktualizovať heslo</translation>
    </message>
    <message>
        <source>The UI lock password has been successfully updated</source>
        <translation type="obsolete">Heslo na zamknutie používateľského rozhrania bolo úspešne aktualizované</translation>
    </message>
    <message>
        <source>UI lock password</source>
        <translation type="obsolete">Heslo na zamknutie používateľského rozhrania</translation>
    </message>
    <message>
        <source>Please type the UI lock password:</source>
        <translation type="obsolete">Prosím, napíšte heslo na zamknutie používateľského rozhrania:</translation>
    </message>
    <message>
        <source>Invalid password</source>
        <translation type="obsolete">Neplatné heslo</translation>
    </message>
    <message>
        <source>The password is invalid</source>
        <translation type="obsolete">Heslo nie je platné</translation>
    </message>
    <message>
        <source>A newer version is available</source>
        <translation type="obsolete">Je dostupná novšia verzia</translation>
    </message>
    <message>
        <source>A newer version of qBittorrent is available on Sourceforge.
Would you like to update qBittorrent to version %1?</source>
        <translation type="obsolete">qBittorrent má novú verziu dostupnú zo Sourceforge.
Chcete aktualizovať qBittorrent na verziu %1?</translation>
    </message>
    <message>
        <source>Impossible to update qBittorrent</source>
        <translation type="obsolete">Nie je možné aktualizovať qBittorrent</translation>
    </message>
    <message>
        <source>qBittorrent failed to update, reason: %1</source>
        <translation type="obsolete">qBittorrent sa nepodarilo aktualizovať. Dôvod: %1</translation>
    </message>
</context>
<context>
    <name>GeoIP</name>
    <message>
        <source>Australia</source>
        <translation type="obsolete">Austrália</translation>
    </message>
    <message>
        <source>Argentina</source>
        <translation type="obsolete">Argentína</translation>
    </message>
    <message>
        <source>Austria</source>
        <translation type="obsolete">Rakúsko</translation>
    </message>
    <message>
        <source>United Arab Emirates</source>
        <translation type="obsolete">Spojené arabské emiráty</translation>
    </message>
    <message>
        <source>Brazil</source>
        <translation type="obsolete">Brazília</translation>
    </message>
    <message>
        <source>Bulgaria</source>
        <translation type="obsolete">Bulharsko</translation>
    </message>
    <message>
        <source>Belarus</source>
        <translation type="obsolete">Bielorusko</translation>
    </message>
    <message>
        <source>Belgium</source>
        <translation type="obsolete">Belgicko</translation>
    </message>
    <message>
        <source>Bosnia</source>
        <translation type="obsolete">Bosna</translation>
    </message>
    <message>
        <source>Canada</source>
        <translation type="obsolete">Kanada</translation>
    </message>
    <message>
        <source>Czech Republic</source>
        <translation type="obsolete">Česko</translation>
    </message>
    <message>
        <source>China</source>
        <translation type="obsolete">Čína</translation>
    </message>
    <message>
        <source>Costa Rica</source>
        <translation type="obsolete">Kostarika</translation>
    </message>
    <message>
        <source>Switzerland</source>
        <translation type="obsolete">Švajčiarsko</translation>
    </message>
    <message>
        <source>Germany</source>
        <translation type="obsolete">Nemecko</translation>
    </message>
    <message>
        <source>Denmark</source>
        <translation type="obsolete">Dánsko</translation>
    </message>
    <message>
        <source>Algeria</source>
        <translation type="obsolete">Alžírsko</translation>
    </message>
    <message>
        <source>Spain</source>
        <translation type="obsolete">Španielsko</translation>
    </message>
    <message>
        <source>Egypt</source>
        <translation type="obsolete">Egypt</translation>
    </message>
    <message>
        <source>Finland</source>
        <translation type="obsolete">Fínsko</translation>
    </message>
    <message>
        <source>France</source>
        <translation type="obsolete">Francúzsko</translation>
    </message>
    <message>
        <source>United Kingdom</source>
        <translation type="obsolete">Spojené kráľovstvo</translation>
    </message>
    <message>
        <source>Greece</source>
        <translation type="obsolete">Grécko</translation>
    </message>
    <message>
        <source>Georgia</source>
        <translation type="obsolete">Gruzínsko</translation>
    </message>
    <message>
        <source>Hungary</source>
        <translation type="obsolete">Maďarsko</translation>
    </message>
    <message>
        <source>Croatia</source>
        <translation type="obsolete">Chorvátsko</translation>
    </message>
    <message>
        <source>Italy</source>
        <translation type="obsolete">Taliansko</translation>
    </message>
    <message>
        <source>India</source>
        <translation type="obsolete">India</translation>
    </message>
    <message>
        <source>Israel</source>
        <translation type="obsolete">Izrael</translation>
    </message>
    <message>
        <source>Ireland</source>
        <translation type="obsolete">Írsko</translation>
    </message>
    <message>
        <source>Iceland</source>
        <translation type="obsolete">Island</translation>
    </message>
    <message>
        <source>Indonesia</source>
        <translation type="obsolete">Indonézia</translation>
    </message>
    <message>
        <source>Japan</source>
        <translation type="obsolete">Japonsko</translation>
    </message>
    <message>
        <source>South Korea</source>
        <translation type="obsolete">Kórejská republika</translation>
    </message>
    <message>
        <source>Luxembourg</source>
        <translation type="obsolete">Luxembursko</translation>
    </message>
    <message>
        <source>Malaysia</source>
        <translation type="obsolete">Malajzia</translation>
    </message>
    <message>
        <source>Mexico</source>
        <translation type="obsolete">Mexiko</translation>
    </message>
    <message>
        <source>Serbia</source>
        <translation type="obsolete">Srbsko</translation>
    </message>
    <message>
        <source>Morocco</source>
        <translation type="obsolete">Maroko</translation>
    </message>
    <message>
        <source>Netherlands</source>
        <translation type="obsolete">Holandsko</translation>
    </message>
    <message>
        <source>Norway</source>
        <translation type="obsolete">Nórsko</translation>
    </message>
    <message>
        <source>New Zealand</source>
        <translation type="obsolete">Nový Zéland</translation>
    </message>
    <message>
        <source>Portugal</source>
        <translation type="obsolete">Portugalsko</translation>
    </message>
    <message>
        <source>Poland</source>
        <translation type="obsolete">Poľsko</translation>
    </message>
    <message>
        <source>Pakistan</source>
        <translation type="obsolete">Pakistan</translation>
    </message>
    <message>
        <source>Philippines</source>
        <translation type="obsolete">Filipíny</translation>
    </message>
    <message>
        <source>Russia</source>
        <translation type="obsolete">Rusko</translation>
    </message>
    <message>
        <source>Romania</source>
        <translation type="obsolete">Rumunsko</translation>
    </message>
    <message>
        <source>France (Reunion Island)</source>
        <translation type="obsolete">Francúzsko (ostrov Réunion)</translation>
    </message>
    <message>
        <source>Sweden</source>
        <translation type="obsolete">Švédsko</translation>
    </message>
    <message>
        <source>Slovakia</source>
        <translation type="obsolete">Slovensko</translation>
    </message>
    <message>
        <source>Singapore</source>
        <translation type="obsolete">Singapur</translation>
    </message>
    <message>
        <source>Slovenia</source>
        <translation type="obsolete">Slovinsko</translation>
    </message>
    <message>
        <source>Turkey</source>
        <translation type="obsolete">Turecko</translation>
    </message>
    <message>
        <source>Thailand</source>
        <translation type="obsolete">Thajsko</translation>
    </message>
    <message>
        <source>USA</source>
        <translation type="obsolete">Spojené štáty</translation>
    </message>
    <message>
        <source>Ukraine</source>
        <translation type="obsolete">Ukrajina</translation>
    </message>
    <message>
        <source>South Africa</source>
        <translation type="obsolete">Južná Afrika</translation>
    </message>
    <message>
        <source>Saudi Arabia</source>
        <translation type="obsolete">Saudská Arábia</translation>
    </message>
</context>
<context>
    <name>HeadlessLoader</name>
    <message>
        <source>Information</source>
        <translation>Informácie</translation>
    </message>
    <message>
        <source>To control qBittorrent, access the Web UI at http://localhost:%1</source>
        <translation>qBittorrentmôžete ovládať z webového rozhrania na adrese http://localhost:%1</translation>
    </message>
    <message>
        <source>The Web UI administrator user name is: %1</source>
        <translation>Používateľské meno správcu webového rozhrania je: %1</translation>
    </message>
    <message>
        <source>The Web UI administrator password is still the default one: %1</source>
        <translation>Heslo správcu webového rozhrania je stále predvolená hodnota: %1</translation>
    </message>
    <message>
        <source>This is a security risk, please consider changing your password from program preferences.</source>
        <translation>Toto je bezpečnostné riziko. Prosím, zmeňte si heslo v Nastaveniach programu.</translation>
    </message>
</context>
<context>
    <name>HttpConnection</name>
    <message>
        <source>Your IP address has been banned after too many failed authentication attempts.</source>
        <translation>Vaša IP adresa bola zablokovaná po príliš mnohých pokusoch o autentifikáciu.</translation>
    </message>
    <message>
        <source>D: %1/s - T: %2</source>
        <comment>Download speed: x KiB/s - Transferred: x MiB</comment>
        <translation>Sťah.: %1/s - Pren.: %2</translation>
    </message>
    <message>
        <source>U: %1/s - T: %2</source>
        <comment>Upload speed: x KiB/s - Transferred: x MiB</comment>
        <translation>Nahr.: %1/s - Pren.: %2</translation>
    </message>
</context>
<context>
    <name>HttpServer</name>
    <message>
        <source>File</source>
        <translation>Súbor</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Upraviť</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Pomocník</translation>
    </message>
    <message>
        <source>Delete from HD</source>
        <translation type="obsolete">Zmazať z disku</translation>
    </message>
    <message>
        <source>Download Torrents from their URL or Magnet link</source>
        <translation>Stiahnuť torrenty z ich URL alebo Magnet odkazu</translation>
    </message>
    <message>
        <source>Only one link per line</source>
        <translation>Iba jeden odkaz na riadok</translation>
    </message>
    <message>
        <source>Download</source>
        <translation>Stiahnuť</translation>
    </message>
    <message>
        <source>Download local torrent</source>
        <translation>Stiahnuť lokálny torrent</translation>
    </message>
    <message>
        <source>Torrent files were correctly added to download list.</source>
        <translation>Torrenty boli úspešne pridané do zoznamu sťahovaných.</translation>
    </message>
    <message>
        <source>Point to torrent file</source>
        <translation>Ukázať na torrent</translation>
    </message>
    <message>
        <source>Are you sure you want to delete the selected torrents from the transfer list and hard disk?</source>
        <translation>Ste s istý, že chcete zmazať vybrané torrenty zo zoznamu prenosov a pevného disku?</translation>
    </message>
    <message>
        <source>Download rate limit must be greater than 0 or disabled.</source>
        <translation>Obmedzenie rýchlosti sťahovania musí byť väčšie ako 0 alebo vypnuté.</translation>
    </message>
    <message>
        <source>Upload rate limit must be greater than 0 or disabled.</source>
        <translation>Obmedzenie rýchlosti nahrávania musí byť väčšie ako 0 alebo vypnuté.</translation>
    </message>
    <message>
        <source>Maximum number of connections limit must be greater than 0 or disabled.</source>
        <translation>Maximálny počet spojení musí byť väčší ako 0 alebo vypnutý.</translation>
    </message>
    <message>
        <source>Maximum number of connections per torrent limit must be greater than 0 or disabled.</source>
        <translation>Maximálny počet spojení na torrent musí byť väčší ako 0 alebo vypnutý.</translation>
    </message>
    <message>
        <source>Maximum number of upload slots per torrent limit must be greater than 0 or disabled.</source>
        <translation>Maximálny počet nahrávacích pozící musí byť väčší ako 0 alebo vypnutý.</translation>
    </message>
    <message>
        <source>Unable to save program preferences, qBittorrent is probably unreachable.</source>
        <translation>Nepodarilo sa uložiť nastavenia programu, qBittorrent je pravdepodobne nedostupný.</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Jazyk</translation>
    </message>
    <message>
        <source>The port used for incoming connections must be greater than 1024 and less than 65535.</source>
        <translation>Port pre prichádzajúce spojenia musí byť medzi 1024 a 65535.</translation>
    </message>
    <message>
        <source>The port used for the Web UI must be greater than 1024 and less than 65535.</source>
        <translation>Port pre webové rozhranie musí byť medzi 1024 a 65535.</translation>
    </message>
    <message>
        <source>The Web UI username must be at least 3 characters long.</source>
        <translation>Používateľské meno pre webové rozhranie musí mať dĺžku aspoň 3 znaky.</translation>
    </message>
    <message>
        <source>The Web UI password must be at least 3 characters long.</source>
        <translation>Heslo pre webové rozhranie musí mať dĺžku aspoň 3 znaky.</translation>
    </message>
    <message>
        <source>Downloaded</source>
        <comment>Is the file downloaded or not?</comment>
        <translation>Stiahnuté</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Uložiť</translation>
    </message>
    <message>
        <source>qBittorrent client is not reachable</source>
        <translation>Klient qBittorrent nie je dostupný</translation>
    </message>
    <message>
        <source>HTTP Server</source>
        <translation>HTTP server</translation>
    </message>
    <message>
        <source>Torrent path</source>
        <translation>Cesta k torrentu</translation>
    </message>
    <message>
        <source>Torrent name</source>
        <translation>Názov torrentu</translation>
    </message>
    <message>
        <source>The following parameters are supported:</source>
        <translation>Nasledovné parametre sú podporované:</translation>
    </message>
</context>
<context>
    <name>LegalNotice</name>
    <message>
        <source>Legal Notice</source>
        <translation>Právny oznam</translation>
    </message>
    <message>
        <source>Legal notice</source>
        <translation>Právne upozornenie</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušiť</translation>
    </message>
    <message>
        <source>I Agree</source>
        <translation>Súhlasím</translation>
    </message>
    <message>
        <source>qBittorrent is a file sharing program. When you run a torrent, its data will be made available to others by means of upload. Any content you share is your sole responsibility.

No further notices will be issued.</source>
        <translation>qBittorrent je program na zdieľanie súborov. Keď spustíte torrent, jeho dáta sa sprástupnia iným prostredníctvom nahrávania. Za akýkoľvek obsah, ktorý zdieľate, nesiete zodpovednosť vy.

Už vás nebudeme ďalej upozorňovať.</translation>
    </message>
    <message>
        <source>Press %1 key to accept and continue...</source>
        <translation>Pokračujte stlačením klávesu %1...</translation>
    </message>
</context>
<context>
    <name>LineEdit</name>
    <message>
        <source>Clear the text</source>
        <translation>Vyčistiť pole</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>&amp;Edit</source>
        <translation>&amp;Úpravy</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Súbor</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Pomocník</translation>
    </message>
    <message>
        <source>Preview file</source>
        <translation type="obsolete">Náhľad súboru</translation>
    </message>
    <message>
        <source>Clear log</source>
        <translation type="obsolete">Vyčistiť záznam</translation>
    </message>
    <message>
        <source>Decrease priority</source>
        <translation>Znížiť prioritu</translation>
    </message>
    <message>
        <source>Increase priority</source>
        <translation>Zvýšiť prioritu</translation>
    </message>
    <message>
        <source>&amp;Tools</source>
        <translation>Nás&amp;troje</translation>
    </message>
    <message>
        <source>&amp;View</source>
        <translation>&amp;Zobraziť</translation>
    </message>
    <message>
        <source>&amp;Add File...</source>
        <translation type="obsolete">Prid&amp;ať súbor...</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation type="obsolete">&amp;Ukončiť</translation>
    </message>
    <message>
        <source>&amp;Options...</source>
        <translation>Mo&amp;žnosti...</translation>
    </message>
    <message>
        <source>Add &amp;URL...</source>
        <translation type="obsolete">Pridať &amp;URL...</translation>
    </message>
    <message>
        <source>Torrent &amp;creator</source>
        <translation>Tvor&amp;ca torrentu</translation>
    </message>
    <message>
        <source>Set upload limit...</source>
        <translation>Nastaviť obmedzenie nahrávania...</translation>
    </message>
    <message>
        <source>Set download limit...</source>
        <translation>Nastaviť obmedzenie šťahovania...</translation>
    </message>
    <message>
        <source>Set global download limit...</source>
        <translation>Nastaviť globálne obmedzenie sťahovania...</translation>
    </message>
    <message>
        <source>Set global upload limit...</source>
        <translation>Nastaviť globálne obmedzenie nahrávania...</translation>
    </message>
    <message>
        <source>&amp;Log viewer...</source>
        <translation type="obsolete">Preh&amp;liadač záznamov...</translation>
    </message>
    <message>
        <source>Top &amp;tool bar</source>
        <translation>Horný panel nás&amp;trojov</translation>
    </message>
    <message>
        <source>Display top tool bar</source>
        <translation>Zobrazovať horný panel nástrojov</translation>
    </message>
    <message>
        <source>&amp;Speed in title bar</source>
        <translation>Rýchlo&amp;sť v titulnom pruhu</translation>
    </message>
    <message>
        <source>Show transfer speed in title bar</source>
        <translation>Zobraziť prenosovú rýchlosť v titulnom pruhu</translation>
    </message>
    <message>
        <source>Alternative speed limits</source>
        <translation>Alternatívne rýchlostné obmedzenia</translation>
    </message>
    <message>
        <source>&amp;About</source>
        <translation>O &amp;aplikácii</translation>
    </message>
    <message>
        <source>&amp;Pause</source>
        <translation>&amp;Pozastaviť</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation></translation>
    </message>
    <message>
        <source>P&amp;ause All</source>
        <translation>Poz&amp;astaviť všetky</translation>
    </message>
    <message>
        <source>Visit &amp;Website</source>
        <translation>Navštíviť &amp;webstránku</translation>
    </message>
    <message>
        <source>Report a &amp;bug</source>
        <translation>Oznámiť chy&amp;bu</translation>
    </message>
    <message>
        <source>&amp;Documentation</source>
        <translation>&amp;Dokumentácia</translation>
    </message>
    <message>
        <source>&amp;RSS reader</source>
        <translation>Čítačka &amp;RSS</translation>
    </message>
    <message>
        <source>Search &amp;engine</source>
        <translation>&amp;Vyhľadávač</translation>
    </message>
    <message>
        <source>Lock qBittorrent</source>
        <translation>Zamknúť qBittorrent</translation>
    </message>
    <message>
        <source>Ctrl+L</source>
        <translation>Ctrl+L</translation>
    </message>
    <message>
        <source>Shutdown computer when downloads complete</source>
        <translation type="obsolete">Vypnúť počítač po dokončení sťahovaní</translation>
    </message>
    <message>
        <source>&amp;Resume</source>
        <translation>Pok&amp;račovať</translation>
    </message>
    <message>
        <source>R&amp;esume All</source>
        <translation>Pokračovať vš&amp;etky</translation>
    </message>
    <message>
        <source>Shutdown qBittorrent when downloads complete</source>
        <translation type="obsolete">Vypnúť qBittorrent po dokončení sťahovaní</translation>
    </message>
    <message>
        <source>Exit</source>
        <translation>Ukončiť</translation>
    </message>
    <message>
        <source>Import torrent...</source>
        <translation>Importovať torrent...</translation>
    </message>
    <message>
        <source>Donate money</source>
        <translation>Venovať peniaze</translation>
    </message>
    <message>
        <source>If you like qBittorrent, please donate!</source>
        <translation>Ak sa vám qBittorrent páči, prosím, prispejte!</translation>
    </message>
    <message>
        <source>qBittorrent %1</source>
        <comment>e.g: qBittorrent v0.x</comment>
        <translation>qBittorrent %1</translation>
    </message>
    <message>
        <source>Set the password...</source>
        <translation>Nastaviť heslo...</translation>
    </message>
    <message>
        <source>Transfers</source>
        <translation>Prenosy</translation>
    </message>
    <message>
        <source>Torrent file association</source>
        <translation>Asociácia typu súboru .torrent</translation>
    </message>
    <message>
        <source>qBittorrent is not the default application to open torrent files or Magnet links.
Do you want to associate qBittorrent to torrent files and Magnet links?</source>
        <translation>qBittorrent nie je predvolená aplikácia na otváranie súborov torrent a odkazov Magnet.
Chcete asociovať qBittorrent so súbormi torrent a odkazmi Magnet?</translation>
    </message>
    <message>
        <source>UI lock password</source>
        <translation>Heslo na zamknutie používateľského rozhrania</translation>
    </message>
    <message>
        <source>Please type the UI lock password:</source>
        <translation>Prosím, napíšte heslo na zamknutie používateľského rozhrania:</translation>
    </message>
    <message>
        <source>Password update</source>
        <translation>Aktualizovať heslo</translation>
    </message>
    <message>
        <source>The UI lock password has been successfully updated</source>
        <translation>Heslo na zamknutie používateľského rozhrania bolo úspešne aktualizované</translation>
    </message>
    <message>
        <source>RSS</source>
        <translation>RSS</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Vyhľadávanie</translation>
    </message>
    <message>
        <source>Transfers (%1)</source>
        <translation>Prenosy (%1)</translation>
    </message>
    <message>
        <source>Download completion</source>
        <translation>Dokončenie sťahovnia</translation>
    </message>
    <message>
        <source>%1 has finished downloading.</source>
        <comment>e.g: xxx.avi has finished downloading.</comment>
        <translation>%1 je stiahnutý.</translation>
    </message>
    <message>
        <source>I/O Error</source>
        <comment>i.e: Input/Output Error</comment>
        <translation>V/V Chyba</translation>
    </message>
    <message>
        <source>An I/O error occured for torrent %1.
 Reason: %2</source>
        <comment>e.g: An error occured for torrent xxx.avi.
 Reason: disk is full.</comment>
        <translation>Vyskytla sa V/V chyba pri torrente %1.
 Dôvod: %2</translation>
    </message>
    <message>
        <source>Alt+1</source>
        <comment>shortcut to switch to first tab</comment>
        <translation>Alt+1</translation>
    </message>
    <message>
        <source>Alt+2</source>
        <comment>shortcut to switch to third tab</comment>
        <translation>Alt+2</translation>
    </message>
    <message>
        <source>Ctrl+F</source>
        <comment>shortcut to switch to search tab</comment>
        <translation>Ctrl+F</translation>
    </message>
    <message>
        <source>Alt+3</source>
        <comment>shortcut to switch to fourth tab</comment>
        <translation>Alt+3</translation>
    </message>
    <message>
        <source>Recursive download confirmation</source>
        <translation>Potvrdenie rekurzívneho sťahovania</translation>
    </message>
    <message>
        <source>The torrent %1 contains torrent files, do you want to proceed with their download?</source>
        <translation>Torrent %1 obsahuje ďalšie súbory torrent. Chcete začať sťahovať aj tie?</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Áno</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Nie</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Nikdy</translation>
    </message>
    <message>
        <source>Url download error</source>
        <translation>Chyba sťahovania url</translation>
    </message>
    <message>
        <source>Couldn&apos;t download file at url: %1, reason: %2.</source>
        <translation>Nebolo možné stiahnuť súbor z url: %1, dôvod: %2.</translation>
    </message>
    <message>
        <source>Global Upload Speed Limit</source>
        <translation>Globálne rýchlostné obmedzenie nahrávania</translation>
    </message>
    <message>
        <source>Global Download Speed Limit</source>
        <translation>Globálne rýchlostné obmedzenie sťahovania</translation>
    </message>
    <message>
        <source>Invalid password</source>
        <translation>Neplatné heslo</translation>
    </message>
    <message>
        <source>The password is invalid</source>
        <translation>Heslo nie je platné</translation>
    </message>
    <message>
        <source>Exiting qBittorrent</source>
        <translation>Ukončuje sa qBittorrent</translation>
    </message>
    <message>
        <source>Some files are currently transferring.
Are you sure you want to quit qBittorrent?</source>
        <translation>Niektoré súbory sa práve prenášajú.
Ste si istý, že chcete ukončiť Bittorrent?</translation>
    </message>
    <message>
        <source>Always</source>
        <translation>Vždy</translation>
    </message>
    <message>
        <source>Open Torrent Files</source>
        <translation>Otvoriť torrent súbory</translation>
    </message>
    <message>
        <source>Torrent Files</source>
        <translation>Torrent súbory</translation>
    </message>
    <message>
        <source>Options were saved successfully.</source>
        <translation>Nastavenia boli úspešne uložené.</translation>
    </message>
    <message>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <source>DL speed: %1 KiB/s</source>
        <comment>e.g: Download speed: 10 KiB/s</comment>
        <translation>Rýchlosť sťahovania: %1 KiB/s</translation>
    </message>
    <message>
        <source>UP speed: %1 KiB/s</source>
        <comment>e.g: Upload speed: 10 KiB/s</comment>
        <translation>Rýchlosť nahrávania: %1 KiB/s</translation>
    </message>
    <message>
        <source>qBittorrent %1 (Down: %2/s, Up: %3/s)</source>
        <comment>%1 is qBittorrent version</comment>
        <translation>qBittorrent %1 (sťah: %2/s, nahr: %3/s)</translation>
    </message>
    <message>
        <source>A newer version is available</source>
        <translation>Je dostupná novšia verzia</translation>
    </message>
    <message>
        <source>A newer version of qBittorrent is available on Sourceforge.
Would you like to update qBittorrent to version %1?</source>
        <translation>qBittorrent má novú verziu dostupnú na Sourceforge.
Chcete aktualizovať qBittorrent na verziu %1?</translation>
    </message>
    <message>
        <source>Impossible to update qBittorrent</source>
        <translation>Nie je možné aktualizovať qBittorrent</translation>
    </message>
    <message>
        <source>qBittorrent failed to update, reason: %1</source>
        <translation>qBittorrent sa nepodarilo aktualizovať. Dôvod: %1</translation>
    </message>
    <message>
        <source>&amp;Add torrent file...</source>
        <translation>Prid&amp;ať súbor torrent...</translation>
    </message>
    <message>
        <source>Add &amp;link to torrent...</source>
        <translation>Pridať &amp;odkaz na torrent...</translation>
    </message>
    <message>
        <source>Import existing torrent...</source>
        <translation>Importovať existujúci torrent...</translation>
    </message>
    <message>
        <source>Execution &amp;Log</source>
        <translation>&amp;Záznam spustení</translation>
    </message>
    <message>
        <source>Execution Log</source>
        <translation>Záznam spustení</translation>
    </message>
    <message>
        <source>Auto-Shutdown on downloads completion</source>
        <translation>Vypnúť počítač po dokončení sťahovaní</translation>
    </message>
    <message>
        <source>Exit qBittorrent</source>
        <translation>Ukončiť qBittorrent</translation>
    </message>
    <message>
        <source>Suspend system</source>
        <translation>Uspať systém</translation>
    </message>
    <message>
        <source>Shutdown system</source>
        <translation>Vypnúť systém</translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Vypnuté</translation>
    </message>
    <message>
        <source>The password should contain at least 3 characters</source>
        <translation>Heslo by malo obsahovať aspoň 3 znaky</translation>
    </message>
</context>
<context>
    <name>PeerAdditionDlg</name>
    <message>
        <source>Invalid IP</source>
        <translation>Neplatná IP</translation>
    </message>
    <message>
        <source>The IP you provided is invalid.</source>
        <translation>IP, ktorú ste poskytli je neplatná.</translation>
    </message>
</context>
<context>
    <name>PeerListDelegate</name>
    <message>
        <source>/s</source>
        <comment>/second (i.e. per second)</comment>
        <translation>/s</translation>
    </message>
</context>
<context>
    <name>PeerListWidget</name>
    <message>
        <source>IP</source>
        <translation>IP</translation>
    </message>
    <message>
        <source>Client</source>
        <comment>i.e.: Client application</comment>
        <translation>Klient</translation>
    </message>
    <message>
        <source>Progress</source>
        <comment>i.e: % downloaded</comment>
        <translation>Priebeh</translation>
    </message>
    <message>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Rýchlosť sťahovania</translation>
    </message>
    <message>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Rýchlosť nahrávania</translation>
    </message>
    <message>
        <source>Downloaded</source>
        <comment>i.e: total data downloaded</comment>
        <translation>Stiahnuté</translation>
    </message>
    <message>
        <source>Uploaded</source>
        <comment>i.e: total data uploaded</comment>
        <translation>Nahrané</translation>
    </message>
    <message>
        <source>Ban peer permanently</source>
        <translation>Zablokovať rovesníka na stálo</translation>
    </message>
    <message>
        <source>Peer addition</source>
        <translation>Pridanie rovesníka</translation>
    </message>
    <message>
        <source>The peer was added to this torrent.</source>
        <translation>Rovesník bol pridaný k tomuto torrentu.</translation>
    </message>
    <message>
        <source>The peer could not be added to this torrent.</source>
        <translation>Rovesníka nebolo možné pridať k tomuto torrentu.</translation>
    </message>
    <message>
        <source>Are you sure? -- qBittorrent</source>
        <translation>Ste si istý? -- qBittorrent</translation>
    </message>
    <message>
        <source>Are you sure you want to ban permanently the selected peers?</source>
        <translation>Ste si istý, že chcete zmazať natrvalo zablokovať vybraného rovesníka?</translation>
    </message>
    <message>
        <source>&amp;Yes</source>
        <translation>Án&amp;o</translation>
    </message>
    <message>
        <source>&amp;No</source>
        <translation>&amp;Nie</translation>
    </message>
    <message>
        <source>Manually banning peer %1...</source>
        <translation>Manuálne zablokovaný rovesník %1...</translation>
    </message>
    <message>
        <source>Upload rate limiting</source>
        <translation>Obmedzenie rýchlosti nahrávania</translation>
    </message>
    <message>
        <source>Download rate limiting</source>
        <translation>Obmedzenie rýchlosti sťahovania</translation>
    </message>
    <message>
        <source>Add a new peer...</source>
        <translation>Pridať nového rovesníka...</translation>
    </message>
    <message>
        <source>Limit download rate...</source>
        <translation>Obmedziť rýchlosť sťahovania...</translation>
    </message>
    <message>
        <source>Limit upload rate...</source>
        <translation>Obmedziť rýchlosť nahrávania...</translation>
    </message>
    <message>
        <source>Copy IP</source>
        <translation>Kopírovať IP</translation>
    </message>
    <message>
        <source>Connection</source>
        <translation>Spojenie</translation>
    </message>
</context>
<context>
    <name>Preferences</name>
    <message>
        <source>UI</source>
        <extracomment>User Interface</extracomment>
        <translation type="obsolete">Rozhranie</translation>
    </message>
    <message>
        <source>Downloads</source>
        <translation>Sťahovania</translation>
    </message>
    <message>
        <source>Connection</source>
        <translation>Spojenie</translation>
    </message>
    <message>
        <source>Bittorrent</source>
        <translation type="obsolete">Bittorrent</translation>
    </message>
    <message>
        <source>Proxy</source>
        <translation type="obsolete">Proxy</translation>
    </message>
    <message>
        <source>Web UI</source>
        <translation>Webové rozhranie</translation>
    </message>
    <message>
        <source>Language:</source>
        <translation type="obsolete">Jazyk:</translation>
    </message>
    <message>
        <source>(Requires restart)</source>
        <translation>Obnoviť RSS kanály</translation>
    </message>
    <message>
        <source>Visual style:</source>
        <translation type="obsolete">Vizuálny štýl:</translation>
    </message>
    <message>
        <source>Transfer list</source>
        <translation type="obsolete">Zoznam prenosov</translation>
    </message>
    <message>
        <source>Use alternating row colors</source>
        <extracomment>In transfer list, one every two rows will have grey background.</extracomment>
        <translation>Používať striedavé farby pozadia riadkov</translation>
    </message>
    <message>
        <source>File system</source>
        <translation type="obsolete">Súborový systém</translation>
    </message>
    <message>
        <source>Torrent queueing</source>
        <translation type="obsolete">Zaraďovanie torrentov do frontu</translation>
    </message>
    <message>
        <source>Maximum active downloads:</source>
        <translation>Maximum aktívnych sťahovaní:</translation>
    </message>
    <message>
        <source>Maximum active uploads:</source>
        <translation>Max. aktívnych nahrávaní:</translation>
    </message>
    <message>
        <source>Maximum active torrents:</source>
        <translation>Maximum aktívnych torrentov:</translation>
    </message>
    <message>
        <source>When adding a torrent</source>
        <translation>Pri pridávaní torrentu</translation>
    </message>
    <message>
        <source>Display torrent content and some options</source>
        <translation>Zobraziť obsah torrentu a nejaké voľby</translation>
    </message>
    <message>
        <source>Listening port</source>
        <translation type="obsolete">Počúvať na porte</translation>
    </message>
    <message>
        <source>Port used for incoming connections:</source>
        <translation>Port pre prichádzajúce spojenia:</translation>
    </message>
    <message>
        <source>Random</source>
        <translation>Náhodný</translation>
    </message>
    <message>
        <source>Enable UPnP port mapping</source>
        <translation type="obsolete">Zapnúť mapovanie portov UPnP</translation>
    </message>
    <message>
        <source>Enable NAT-PMP port mapping</source>
        <translation type="obsolete">Zapnúť mapovanie portov NAT-PMP</translation>
    </message>
    <message>
        <source>Connections limit</source>
        <translation type="obsolete">Limit spojení</translation>
    </message>
    <message>
        <source>Global maximum number of connections:</source>
        <translation>Maximálny globálny počet spojení:</translation>
    </message>
    <message>
        <source>Maximum number of connections per torrent:</source>
        <translation>Maximálny počet spojení na torrent:</translation>
    </message>
    <message>
        <source>Maximum number of upload slots per torrent:</source>
        <translation>Maximálny počet slotov pre nahrávanie na torrent:</translation>
    </message>
    <message>
        <source>Upload:</source>
        <translation>Nahrávanie:</translation>
    </message>
    <message>
        <source>Download:</source>
        <translation>Sťahovanie:</translation>
    </message>
    <message>
        <source>KiB/s</source>
        <translation>KiB/s</translation>
    </message>
    <message>
        <source>Bittorrent features</source>
        <translation type="obsolete">Možnosti siete Bittorrent</translation>
    </message>
    <message>
        <source>Enable DHT network (decentralized)</source>
        <translation type="obsolete">Zapnúť sieť DHT (decentralizovaná)</translation>
    </message>
    <message>
        <source>Use a different port for DHT and Bittorrent</source>
        <translation type="obsolete">Používať odlišný port pre DHT a Bittorrent</translation>
    </message>
    <message>
        <source>DHT port:</source>
        <translation>Port DHT:</translation>
    </message>
    <message>
        <source>Enable Peer Exchange / PeX (requires restart)</source>
        <translation type="obsolete">Zapnúť Peer eXchange / PeX (vyžaduje reštart)</translation>
    </message>
    <message>
        <source>Enable Local Peer Discovery</source>
        <translation type="obsolete">Zapnúť Local Peer Discovery</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation type="obsolete">Zapnuté</translation>
    </message>
    <message>
        <source>Forced</source>
        <translation type="obsolete">Vynútené</translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation type="obsolete">Vypnuté</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation>Typ:</translation>
    </message>
    <message>
        <source>(None)</source>
        <translation>(žiadny)</translation>
    </message>
    <message>
        <source>HTTP</source>
        <translation>HTTP</translation>
    </message>
    <message>
        <source>Port:</source>
        <translation>Port:</translation>
    </message>
    <message>
        <source>Authentication</source>
        <translation>Autentifikácia</translation>
    </message>
    <message>
        <source>Username:</source>
        <translation>Meno používateľa:</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation>Heslo:</translation>
    </message>
    <message>
        <source>SOCKS5</source>
        <translation>SOCKS5</translation>
    </message>
    <message>
        <source>HTTP Server</source>
        <translation type="obsolete">HTTP Server</translation>
    </message>
    <message>
        <source>Filter path (.dat, .p2p, .p2b):</source>
        <translation>Cesta k filtrom (.dat, .p2p, .p2b):</translation>
    </message>
    <message>
        <source>HTTP Communications (trackers, Web seeds, search engine)</source>
        <translation type="obsolete">HTTP komunikácia (trackery, web seedy, vyhľadávač)</translation>
    </message>
    <message>
        <source>Host:</source>
        <translation>Počítač:</translation>
    </message>
    <message>
        <source>Peer Communications</source>
        <translation type="obsolete">Komunikácia s rovesníkmi</translation>
    </message>
    <message>
        <source>SOCKS4</source>
        <translation>SOCKS4</translation>
    </message>
    <message>
        <source>Speed</source>
        <translation>Rýchlosť</translation>
    </message>
    <message>
        <source>Global speed limits</source>
        <translation type="obsolete">Globálne rýchlostné obmedzenia</translation>
    </message>
    <message>
        <source>Alternative global speed limits</source>
        <translation type="obsolete">Alternatívne globálne rýchlostné obmedzenia</translation>
    </message>
    <message>
        <source>to</source>
        <extracomment>time1 to time2</extracomment>
        <translation>do</translation>
    </message>
    <message>
        <source>Every day</source>
        <translation>Každý deň</translation>
    </message>
    <message>
        <source>Week days</source>
        <translation>Pracovné dni</translation>
    </message>
    <message>
        <source>Week ends</source>
        <translation>Víkendy</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Rozšírené</translation>
    </message>
    <message>
        <source>Copy .torrent files to:</source>
        <translation>Kopírovať .torrent súbory do:</translation>
    </message>
    <message>
        <source>Remove folder</source>
        <translation>Odstrániť priečinok</translation>
    </message>
    <message>
        <source>No action</source>
        <translation>Žiadna činnosť</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>Možnosti</translation>
    </message>
    <message>
        <source>Visual Appearance</source>
        <translation type="obsolete">Vzhľad</translation>
    </message>
    <message>
        <source>Action on double-click</source>
        <translation>Operácia po dvojitom kliknutí</translation>
    </message>
    <message>
        <source>Downloading torrents:</source>
        <translation>Sťahujú sa torrenty:</translation>
    </message>
    <message>
        <source>Start / Stop</source>
        <translation type="obsolete">Spustiť/zastaviť</translation>
    </message>
    <message>
        <source>Open destination folder</source>
        <translation>Otvoriť cieľový priečinok</translation>
    </message>
    <message>
        <source>Completed torrents:</source>
        <translation>Dokončené torrenty:</translation>
    </message>
    <message>
        <source>Desktop</source>
        <translation>Plocha</translation>
    </message>
    <message>
        <source>Show splash screen on start up</source>
        <translation>Zobraziť pri spustení štartovaciu obrazovku</translation>
    </message>
    <message>
        <source>Start qBittorrent minimized</source>
        <translation>Spustiť qBittorrent minimalizovaný</translation>
    </message>
    <message>
        <source>Show qBittorrent icon in notification area</source>
        <translation type="obsolete">Zobraziť qBittorrent v oznamovacej oblasti</translation>
    </message>
    <message>
        <source>Minimize qBittorrent to notification area</source>
        <translation>Minimalizovať qBittorrent do oznamovacej oblasti</translation>
    </message>
    <message>
        <source>Close qBittorrent to notification area</source>
        <comment>i.e: The systray tray icon will still be visible when closing the main window.</comment>
        <translation>Zatvoriť qBittorrent do oznamovacej oblasti</translation>
    </message>
    <message>
        <source>Do not start the download automatically</source>
        <comment>The torrent will be added to download list in pause state</comment>
        <translation>Torrent sa pridá do zoznamu sťahovaných v stave pozastavený</translation>
    </message>
    <message>
        <source>Save files to location:</source>
        <translation>Ukladať súbory do priečinka:</translation>
    </message>
    <message>
        <source>Append the label of the torrent to the save path</source>
        <translation>Pridať označenie torrentu k ceste, kam sa ukladá</translation>
    </message>
    <message>
        <source>Pre-allocate disk space for all files</source>
        <translation>Dopredu alokovať miesto pre všetky súbory</translation>
    </message>
    <message>
        <source>Keep incomplete torrents in:</source>
        <translation>Ponechať neúplné torrenty v:</translation>
    </message>
    <message>
        <source>Append .!qB extension to incomplete files&apos; names</source>
        <translation type="obsolete">Pridávať nedosťahovaným súborom príponu.!qB</translation>
    </message>
    <message>
        <source>Automatically add torrents from:</source>
        <translation>Automaticky pridať torrenty z:</translation>
    </message>
    <message>
        <source>Add folder...</source>
        <translation>Pridať priečinok ...</translation>
    </message>
    <message>
        <source>IP Filtering</source>
        <translation>IP filter</translation>
    </message>
    <message>
        <source>Schedule the use of alternative speed limits</source>
        <translation type="obsolete">Naplánovať použitie alternatívnych rýchlostných obmedzení</translation>
    </message>
    <message>
        <source>from</source>
        <extracomment>from (time1 to time2)</extracomment>
        <translation>od</translation>
    </message>
    <message>
        <source>When:</source>
        <translation>Kedy:</translation>
    </message>
    <message>
        <source>Look for peers on your local network</source>
        <translation>Hľadať rovesníkov na vašej lokálnej sieti</translation>
    </message>
    <message>
        <source>Protocol encryption:</source>
        <translation type="obsolete">Šifrovanie protokolu:</translation>
    </message>
    <message>
        <source>Enable Web User Interface (Remote control)</source>
        <translation>Zapnúť webové rozhranie (diaľkové ovládanie)</translation>
    </message>
    <message>
        <source>Share ratio limiting</source>
        <translation type="obsolete">Obmedzenie pomeru zdieľania</translation>
    </message>
    <message>
        <source>Seed torrents until their ratio reaches</source>
        <translation>Seedovať torrenty pokým ich pomer nedosiahne</translation>
    </message>
    <message>
        <source>then</source>
        <translation>potom</translation>
    </message>
    <message>
        <source>Pause them</source>
        <translation>ich pozastaviť</translation>
    </message>
    <message>
        <source>Remove them</source>
        <translation>ich odstrániť</translation>
    </message>
    <message utf8="true">
        <source>Exchange peers with compatible Bittorrent clients (µTorrent, Vuze, ...)</source>
        <translation>Vymieňať si zoznam rovesníkov s kompatibilnými klientmi siete Bittorrent (µTorrent, Vuze, ...)</translation>
    </message>
    <message>
        <source>Email notification upon download completion</source>
        <translation>Upozornenie o dokončení sťahovania emailom</translation>
    </message>
    <message>
        <source>Destination email:</source>
        <translation>Cieľový email:</translation>
    </message>
    <message>
        <source>SMTP server:</source>
        <translation>SMTP server:</translation>
    </message>
    <message>
        <source>Run an external program on torrent completion</source>
        <translation>Po dokončení sťahovania spustiť externý program</translation>
    </message>
    <message>
        <source>Use %f to pass the torrent path in parameters</source>
        <translation type="obsolete">Pomocou %f môžete odovzdať v parametroch cestu k torrentu</translation>
    </message>
    <message>
        <source>Proxy server</source>
        <translation type="obsolete">Proxy server</translation>
    </message>
    <message>
        <source>BitTorrent</source>
        <translation>Bittorrent</translation>
    </message>
    <message>
        <source>Start / Stop Torrent</source>
        <translation>Spustiť/zastaviť torrent</translation>
    </message>
    <message>
        <source>Use UPnP / NAT-PMP port forwarding from my router</source>
        <translation>Použiť presmerovanie portov UPnP/NAT-PMP z môjho smerovača</translation>
    </message>
    <message>
        <source>Privacy</source>
        <translation>Súkromie</translation>
    </message>
    <message>
        <source>Enable DHT (decentralized network) to find more peers</source>
        <translation>Zapnúť DHT (decentralizovaná sieť) - umožní nájsť viac rovesníkov</translation>
    </message>
    <message>
        <source>Use a different port for DHT and BitTorrent</source>
        <translation>Používať odlišný port pre DHT a Bittorrent</translation>
    </message>
    <message>
        <source>Enable Peer Exchange (PeX) to find more peers</source>
        <translation>Zapnúť Peer eXchange (PeX) - umožní nájsť viac rovesníkov</translation>
    </message>
    <message>
        <source>Enable Local Peer Discovery to find more peers</source>
        <translation>Zapnúť Local Peer Discovery - umožní nájsť viac rovesníkov</translation>
    </message>
    <message>
        <source>Encryption mode:</source>
        <translation></translation>
    </message>
    <message>
        <source>Prefer encryption</source>
        <translation>Uprednostňovať šifrovanie</translation>
    </message>
    <message>
        <source>Require encryption</source>
        <translation>Vyžadovať šifrovanie</translation>
    </message>
    <message>
        <source>Disable encryption</source>
        <translation>Vypnúť šifrovanie</translation>
    </message>
    <message>
        <source>User Interface</source>
        <translation type="obsolete">Používateľské rozhranie</translation>
    </message>
    <message>
        <source>Reload the filter</source>
        <translation>Znovu načítať filter</translation>
    </message>
    <message>
        <source>Behavior</source>
        <translation>Správanie</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Jazyk</translation>
    </message>
    <message>
        <source>Power Management</source>
        <translation>Správa napájania</translation>
    </message>
    <message>
        <source>Inhibit system sleep when torrents are active</source>
        <translation>Potlačiť prechod systému do režimu spánku ak sú torrenty aktívne</translation>
    </message>
    <message>
        <source>Bypass authentication for localhost</source>
        <translation>Obísť autentifikáciu pri prihlasovaní z lokálneho počítača</translation>
    </message>
    <message>
        <source>Ask for program exit confirmation</source>
        <translation>Potvrdenie ukončenia programu</translation>
    </message>
    <message>
        <source>Use monochrome system tray icon (requires restart)</source>
        <translation type="obsolete">Používať monochromatickú ikonu v oznamovacej oblasti (vyžaduje reštart)</translation>
    </message>
    <message>
        <source>The following parameters are supported:
&lt;ul&gt;
&lt;li&gt;%f: Torrent path&lt;/li&gt;
&lt;li&gt;%n: Torrent name&lt;/li&gt;
&lt;/ul&gt;</source>
        <translation>Nasledovné parametre sú podporované:
&lt;ul&gt;
&lt;li&gt;%f: Cesta k torrentu&lt;/li&gt;
&lt;li&gt;%n: Názov torrentu&lt;/li&gt;
&lt;/ul&gt;</translation>
    </message>
    <message>
        <source>Tray icon style:</source>
        <translation>Štýl ikony v oznamovacej oblasti:</translation>
    </message>
    <message>
        <source>Normal</source>
        <translation>Normálny</translation>
    </message>
    <message>
        <source>Monochrome (Dark theme)</source>
        <translation>Monochromatický (tmavá téma)</translation>
    </message>
    <message>
        <source>Monochrome (Light theme)</source>
        <translation>Monochromatický (svetlá téma)</translation>
    </message>
    <message>
        <source>This server requires a secure connection (SSL)</source>
        <translation>Tento server vyžaduje zabezpečené pripojenie (SSL)</translation>
    </message>
    <message>
        <source>User Interface Language:</source>
        <translation>Jazyk používateľského rozhrania:</translation>
    </message>
    <message>
        <source>Transfer List</source>
        <translation>Zoznam prenosov</translation>
    </message>
    <message>
        <source>Show qBittorrent in notification area</source>
        <translation>Zobraziť qBittorrent v oznamovacej oblasti</translation>
    </message>
    <message>
        <source>Hard Disk</source>
        <translation>Pevný disk</translation>
    </message>
    <message>
        <source>Listening Port</source>
        <translation>Počúvať na porte</translation>
    </message>
    <message>
        <source>Connections Limits</source>
        <translation>Limit spojení</translation>
    </message>
    <message>
        <source>Proxy Server</source>
        <translation>Proxy server</translation>
    </message>
    <message>
        <source>Torrent Queueing</source>
        <translation>Zaraďovanie torrentov do frontu</translation>
    </message>
    <message>
        <source>Share Ratio Limiting</source>
        <translation>Obmedzenie pomeru zdieľania</translation>
    </message>
    <message>
        <source>Use UPnP / NAT-PMP to forward the port from my router</source>
        <translation>Použiť presmerovanie portov UPnP/NAT-PMP z môjho smerovača</translation>
    </message>
    <message>
        <source>Update my dynamic domain name</source>
        <translation>Aktualizovať môj dynamický názov domény</translation>
    </message>
    <message>
        <source>Service:</source>
        <translation>Služba:</translation>
    </message>
    <message>
        <source>Register</source>
        <translation>Zaregistrovať sa</translation>
    </message>
    <message>
        <source>Domain name:</source>
        <translation>Názov domény:</translation>
    </message>
    <message>
        <source>Global Rate Limits</source>
        <translation>Globálne rýchlostné obmedzenia</translation>
    </message>
    <message>
        <source>Apply rate limit to uTP connections</source>
        <translation>Použiť rýchlostné obmedzenie na spojenia uTP</translation>
    </message>
    <message>
        <source>Apply rate limit to transport overhead</source>
        <translation>Použiť rýchlostné obmedzenie na réžiu prenosu</translation>
    </message>
    <message>
        <source>Alternative Global Rate Limits</source>
        <translation>Alternatívne globálne rýchlostné obmedzenia</translation>
    </message>
    <message>
        <source>Schedule the use of alternative rate limits</source>
        <translation>Naplánovať použitie alternatívnych rýchlostných obmedzení</translation>
    </message>
    <message>
        <source>Enable bandwidth management (uTP)</source>
        <translation>Zapnúť správu šírky pásma (uTP)</translation>
    </message>
    <message>
        <source>Otherwise, the proxy server is only used for tracker connections</source>
        <translation>Inak sa proxy server použije iba na pripojenia k trackeru</translation>
    </message>
    <message>
        <source>Use proxy for peer connections</source>
        <translation>Používať proxy na spojenia s rovesníkmi</translation>
    </message>
    <message>
        <source>Append .!qB extension to incomplete files</source>
        <translation>Pridávať príponu .!qB k neúplným súborom</translation>
    </message>
    <message>
        <source>Use HTTPS instead of HTTP</source>
        <translation>Používať HTTPS namiesto HTTP</translation>
    </message>
    <message>
        <source>Import SSL Certificate</source>
        <translation>Importovať certifikát SSL</translation>
    </message>
    <message>
        <source>Import SSL Key</source>
        <translation>Importovať kľúč SSL</translation>
    </message>
    <message>
        <source>Certificate:</source>
        <translation>Certifikát:</translation>
    </message>
    <message>
        <source>Key:</source>
        <translation>Kľúč:</translation>
    </message>
    <message>
        <source>&lt;a href=http://httpd.apache.org/docs/2.1/ssl/ssl_faq.html#aboutcerts&gt;Information about certificates&lt;/a&gt;</source>
        <translation>&lt;a href=http://httpd.apache.org/docs/2.1/ssl/ssl_faq.html#aboutcerts&gt;Informácie o certifikátoch&lt;/a&gt;</translation>
    </message>
</context>
<context>
    <name>PreviewSelect</name>
    <message>
        <source>Name</source>
        <translation>Názov</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Veľkosť</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation>Priebeh</translation>
    </message>
    <message>
        <source>Preview impossible</source>
        <translation>Náhľad nie je možný</translation>
    </message>
    <message>
        <source>Sorry, we can&apos;t preview this file</source>
        <translation>Prepáčte, tento súbor sa nedá otvoriť ako náhľad</translation>
    </message>
</context>
<context>
    <name>ProgramUpdater</name>
    <message>
        <source>Could not create the file %1</source>
        <translation type="obsolete">Nepodarilo sa vytvoriť súbor %1</translation>
    </message>
    <message>
        <source>Failed to download the update at %1</source>
        <comment>%1 is an URL</comment>
        <translation type="obsolete">Nepodarilo sa stiahnuť aktualizáciu z %1</translation>
    </message>
</context>
<context>
    <name>PropListDelegate</name>
    <message>
        <source>Normal</source>
        <comment>Normal (priority)</comment>
        <translation>Normálna</translation>
    </message>
    <message>
        <source>High</source>
        <comment>High (priority)</comment>
        <translation>Vysoká</translation>
    </message>
    <message>
        <source>Maximum</source>
        <comment>Maximum (priority)</comment>
        <translation>Maximálna</translation>
    </message>
    <message>
        <source>Not downloaded</source>
        <translation>Nestiahnuté</translation>
    </message>
    <message>
        <source>Mixed</source>
        <comment>Mixed (priorities</comment>
        <translation>Ziešané</translation>
    </message>
</context>
<context>
    <name>PropTabBar</name>
    <message>
        <source>General</source>
        <translation>Všeobecné</translation>
    </message>
    <message>
        <source>Trackers</source>
        <translation>Trackery</translation>
    </message>
    <message>
        <source>Peers</source>
        <translation>Rovesníci</translation>
    </message>
    <message>
        <source>URL Seeds</source>
        <translation type="obsolete">URL seedy</translation>
    </message>
    <message>
        <source>Files</source>
        <translation type="obsolete">Súbory</translation>
    </message>
    <message>
        <source>HTTP Sources</source>
        <translation>HTTP zdroje</translation>
    </message>
    <message>
        <source>Content</source>
        <translation>Obsah</translation>
    </message>
</context>
<context>
    <name>PropertiesWidget</name>
    <message>
        <source>Save path:</source>
        <translation>Uložiť kam:</translation>
    </message>
    <message>
        <source>Torrent hash:</source>
        <translation>Haš torrentu:</translation>
    </message>
    <message>
        <source>Share ratio:</source>
        <translation>Pomer zdieľania:</translation>
    </message>
    <message>
        <source>General</source>
        <translation type="obsolete">Všeobecné</translation>
    </message>
    <message>
        <source>Trackers</source>
        <translation type="obsolete">Trackery</translation>
    </message>
    <message>
        <source>URL seeds</source>
        <translation type="obsolete">URL seedy</translation>
    </message>
    <message>
        <source>Files</source>
        <translation type="obsolete">Súbory</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Priorita</translation>
    </message>
    <message>
        <source>New url seed</source>
        <comment>New HTTP source</comment>
        <translation>Nový HTTP zdroj</translation>
    </message>
    <message>
        <source>New url seed:</source>
        <translation>Nový URL seed:</translation>
    </message>
    <message>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <source>This url seed is already in the list.</source>
        <translation>Tento URL seed je už v zozname.</translation>
    </message>
    <message>
        <source>Choose save path</source>
        <translation>Zvoľte cieľový adresár</translation>
    </message>
    <message>
        <source>Save path creation error</source>
        <translation type="obsolete">Chyba pri vytváraní cieľového adresára</translation>
    </message>
    <message>
        <source>Could not create the save path</source>
        <translation type="obsolete">Nepodarilo sa vytvoriť cieľový adresár</translation>
    </message>
    <message>
        <source>Downloaded:</source>
        <translation>Stiahnuté:</translation>
    </message>
    <message>
        <source>Transfer</source>
        <translation>Prenos</translation>
    </message>
    <message>
        <source>Uploaded:</source>
        <translation>Nahrané:</translation>
    </message>
    <message>
        <source>Wasted:</source>
        <translation>Premrhané:</translation>
    </message>
    <message>
        <source>UP limit:</source>
        <translation>Limit nahr.:</translation>
    </message>
    <message>
        <source>DL limit:</source>
        <translation>Limit sťah.:</translation>
    </message>
    <message>
        <source>Time elapsed:</source>
        <translation type="obsolete">Uplynulý čas:</translation>
    </message>
    <message>
        <source>Connections:</source>
        <translation>Spojení:</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Informácie</translation>
    </message>
    <message>
        <source>Created on:</source>
        <translation>Vytvorené:</translation>
    </message>
    <message>
        <source>Peers</source>
        <translation type="obsolete">Rovesníkov</translation>
    </message>
    <message>
        <source>Normal</source>
        <translation>Normálna</translation>
    </message>
    <message>
        <source>Maximum</source>
        <translation>Maximálna</translation>
    </message>
    <message>
        <source>High</source>
        <translation>Vysoká</translation>
    </message>
    <message>
        <source>this session</source>
        <translation>táto relácia</translation>
    </message>
    <message>
        <source>%1 max</source>
        <comment>e.g. 10 max</comment>
        <translation>max. %1</translation>
    </message>
    <message>
        <source>Availability:</source>
        <translation>Dostupnosť:</translation>
    </message>
    <message>
        <source>/s</source>
        <comment>/second (i.e. per second)</comment>
        <translation>/s</translation>
    </message>
    <message>
        <source>Seeded for %1</source>
        <comment>e.g. Seeded for 3m10s</comment>
        <translation>Seedovanie trvalo %1</translation>
    </message>
    <message>
        <source>Comment:</source>
        <translation>Komentár:</translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation>Premenovať...</translation>
    </message>
    <message>
        <source>New name:</source>
        <translation>Nový názov:</translation>
    </message>
    <message>
        <source>The file could not be renamed</source>
        <translation>Nebolo možné premenovať súbor</translation>
    </message>
    <message>
        <source>This name is already in use in this folder. Please use a different name.</source>
        <translation>Tento názov sa v tomto adresári už používa. Prosím, zvoľte iný názov.</translation>
    </message>
    <message>
        <source>The folder could not be renamed</source>
        <translation>Nebolo možné premenovať adresár</translation>
    </message>
    <message>
        <source>Rename the file</source>
        <translation>Premenovať súbor</translation>
    </message>
    <message>
        <source>This file name contains forbidden characters, please choose a different one.</source>
        <translation>Tento názov súboru obsahuje nepovolené znaky, preto zvoľte iný.</translation>
    </message>
    <message>
        <source>I/O Error</source>
        <translation>V/V chyba</translation>
    </message>
    <message>
        <source>This file does not exist yet.</source>
        <translation>Tento súbor zatiaľ neexistuje.</translation>
    </message>
    <message>
        <source>This folder does not exist yet.</source>
        <translation>Tento priečinok zatiaľ neexistuje.</translation>
    </message>
    <message>
        <source>Reannounce in:</source>
        <translation>Znova ohlásiť o:</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Vybrať všetky</translation>
    </message>
    <message>
        <source>Select None</source>
        <translation>Nevybrať nič</translation>
    </message>
    <message>
        <source>Do not download</source>
        <translation>Nesťahovať</translation>
    </message>
    <message>
        <source>Pieces size:</source>
        <translation>Veľkosť častí:</translation>
    </message>
    <message>
        <source>Time active:</source>
        <extracomment>Time (duration) the torrent is active (not paused)</extracomment>
        <translation>Čas aktivity:</translation>
    </message>
    <message>
        <source>Torrent content:</source>
        <translation>Obsah torrentu:</translation>
    </message>
</context>
<context>
    <name>QBtSession</name>
    <message>
        <source>%1 reached the maximum ratio you set.</source>
        <translation>%1 dosiahol maximálny požadovaný pomer.</translation>
    </message>
    <message>
        <source>Removing torrent %1...</source>
        <translation>Odstraňuje sa torrent %1...</translation>
    </message>
    <message>
        <source>Pausing torrent %1...</source>
        <translation>Pozastavuje sa torrent %1...</translation>
    </message>
    <message>
        <source>qBittorrent is bound to port: TCP/%1</source>
        <comment>e.g: qBittorrent is bound to port: 6881</comment>
        <translation>qBittorrent sa viaže na port: TCP/%1</translation>
    </message>
    <message>
        <source>UPnP support [ON]</source>
        <translation type="obsolete">Podpora UPnP [zapnutá]</translation>
    </message>
    <message>
        <source>UPnP support [OFF]</source>
        <translation type="obsolete">Podpora UPnP [vypnutá]</translation>
    </message>
    <message>
        <source>NAT-PMP support [ON]</source>
        <translation type="obsolete">Podpora NAT-PMP [zapnutá]</translation>
    </message>
    <message>
        <source>NAT-PMP support [OFF]</source>
        <translation type="obsolete">Podpora NAT-PMP [vypnutá]</translation>
    </message>
    <message>
        <source>HTTP user agent is %1</source>
        <translation>HTTP user agent je %1</translation>
    </message>
    <message>
        <source>Using a disk cache size of %1 MiB</source>
        <translation type="obsolete">Používa sa veľkosť diskovej vyrovnávacej pamäte %1 MiB</translation>
    </message>
    <message>
        <source>DHT support [ON], port: UDP/%1</source>
        <translation>Podpora DHT [ZAP], port: UDP/%1</translation>
    </message>
    <message>
        <source>DHT support [OFF]</source>
        <translation>Podpora DHT [vypnutá]</translation>
    </message>
    <message>
        <source>PeX support [ON]</source>
        <translation>Podpora PeX [zapnutá]</translation>
    </message>
    <message>
        <source>PeX support [OFF]</source>
        <translation>Podpora PeX [VYP]</translation>
    </message>
    <message>
        <source>Restart is required to toggle PeX support</source>
        <translation>Na prepnutie podpory PeX je potrebný reštart</translation>
    </message>
    <message>
        <source>Local Peer Discovery [ON]</source>
        <translation type="obsolete">Local Peer Discovery [zapnutá]</translation>
    </message>
    <message>
        <source>Local Peer Discovery support [OFF]</source>
        <translation>Podpora Local Peer Discovery support [vypnutá]</translation>
    </message>
    <message>
        <source>Encryption support [ON]</source>
        <translation>Podpora šifrovania [zapnuté]</translation>
    </message>
    <message>
        <source>Encryption support [FORCED]</source>
        <translation>Podpora šifrovania [vynútené]</translation>
    </message>
    <message>
        <source>Encryption support [OFF]</source>
        <translation>Podpora šifrovania [vypnuté]</translation>
    </message>
    <message>
        <source>Embedded Tracker [ON]</source>
        <translation>Zabudovaný tracker [zapnuté]</translation>
    </message>
    <message>
        <source>Failed to start the embedded tracker!</source>
        <translation>Nepodarilo sa spustiť zabudovaný tracker!</translation>
    </message>
    <message>
        <source>Embedded Tracker [OFF]</source>
        <translation>Zabudovaný tracker [vypnuté]</translation>
    </message>
    <message>
        <source>The Web UI is listening on port %1</source>
        <translation>Webové rozhranie počúva na porte %1</translation>
    </message>
    <message>
        <source>Web User Interface Error - Unable to bind Web UI to port %1</source>
        <translation>Chyba webového rozhrania - nepodaril sa bind webového rozhrania na port %1</translation>
    </message>
    <message>
        <source>&apos;%1&apos; was removed from transfer list and hard disk.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>„%1“ bol odstránený zo zoznamu sťahovaných a z pevného disku.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; was removed from transfer list.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>„%1“ bol odstránený zo zoznamu sťahovaných.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is not a valid magnet URI.</source>
        <translation>„%1“ nie je platný magnet URI.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is already in download list.</source>
        <comment>e.g: &apos;xxx.avi&apos; is already in download list.</comment>
        <translation>„%1“ sa už nachádza v zozname sťahovaných.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; resumed. (fast resume)</source>
        <comment>&apos;/home/y/xxx.torrent&apos; was resumed. (fast resume)</comment>
        <translation>„%1“ bol obnovený. (rýchle obnovenie)</translation>
    </message>
    <message>
        <source>&apos;%1&apos; added to download list.</source>
        <comment>&apos;/home/y/xxx.torrent&apos; was added to download list.</comment>
        <translation>„%1“ bol pridaný do zoznamu na sťahovanie.</translation>
    </message>
    <message>
        <source>Unable to decode torrent file: &apos;%1&apos;</source>
        <comment>e.g: Unable to decode torrent file: &apos;/home/y/xxx.torrent&apos;</comment>
        <translation>Nepodarilo sa dekódovať torrent súbor: „%1“</translation>
    </message>
    <message>
        <source>This file is either corrupted or this isn&apos;t a torrent.</source>
        <translation>Tento súbor je buď poškodený alebo to nie je torrent.</translation>
    </message>
    <message>
        <source>Error: The torrent %1 does not contain any file.</source>
        <translation>Chyba: Torrent %1 neobsahuje žiaden súbor.</translation>
    </message>
    <message>
        <source>Note: new trackers were added to the existing torrent.</source>
        <translation>Pozn.: Do existujúceho torrentu boli pridané nové trackery.</translation>
    </message>
    <message>
        <source>Note: new URL seeds were added to the existing torrent.</source>
        <translation>Pozn.: Do existujúceho torrentu boli pridané nové URL seedy.</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;was blocked due to your IP filter&lt;/i&gt;</source>
        <comment>x.y.z.w was blocked</comment>
        <translation>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;zablokoval váš filter IP adries&lt;/i&gt;</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;was banned due to corrupt pieces&lt;/i&gt;</source>
        <comment>x.y.z.w was banned</comment>
        <translation>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;zablokovaný kvôli posielaniu poškodených častí&lt;/i&gt;</translation>
    </message>
    <message>
        <source>Recursive download of file %1 embedded in torrent %2</source>
        <comment>Recursive download of test.torrent embedded in torrent test2</comment>
        <translation>Rekurzívne sťahovanie súboru %1 vnoreného v torrente %2</translation>
    </message>
    <message>
        <source>Unable to decode %1 torrent file.</source>
        <translation>Nepodarilo sa dekódovať torrent súbor %1.</translation>
    </message>
    <message>
        <source>Torrent name: %1</source>
        <translation>Názov torrentu: %1</translation>
    </message>
    <message>
        <source>Torrent size: %1</source>
        <translation>Veľkosť torrentu: %1</translation>
    </message>
    <message>
        <source>Save path: %1</source>
        <translation>Uložiť do: %1</translation>
    </message>
    <message>
        <source>The torrent was downloaded in %1.</source>
        <comment>The torrent was downloaded in 1 hour and 20 seconds</comment>
        <translation>Torrent bol stiahnutý za %1.</translation>
    </message>
    <message>
        <source>Thank you for using qBittorrent.</source>
        <translation>Ďakujeme, že používate qBittorrent.</translation>
    </message>
    <message>
        <source>[qBittorrent] %1 has finished downloading</source>
        <translation>[qBittorrent] sťahovanie %1 bolo dokončené</translation>
    </message>
    <message>
        <source>An I/O error occured, &apos;%1&apos; paused.</source>
        <translation>Vyskytla sa V/V chyba, „%1“ pozastavené.</translation>
    </message>
    <message>
        <source>Reason: %1</source>
        <translation>Dôvod: %1</translation>
    </message>
    <message>
        <source>UPnP/NAT-PMP: Port mapping failure, message: %1</source>
        <translation>UPnP/NAT-PMP: Zlyhanie mapovania portov, správa: %1</translation>
    </message>
    <message>
        <source>UPnP/NAT-PMP: Port mapping successful, message: %1</source>
        <translation>UPnP/NAT-PMP: Mapovanie portov úspešné, správa: %1</translation>
    </message>
    <message>
        <source>File sizes mismatch for torrent %1, pausing it.</source>
        <translation>Veľkosti súborov sa líšia pri torrente %1, pozastavuje sa.</translation>
    </message>
    <message>
        <source>Fast resume data was rejected for torrent %1, checking again...</source>
        <translation>Rýchle obnovenie torrentu %1 bolo odmietnuté, prebieha opätovná kontrola...</translation>
    </message>
    <message>
        <source>Url seed lookup failed for url: %1, message: %2</source>
        <translation>Vyhľadanie url seedu zlyhalo pre url: %1, správa: %2</translation>
    </message>
    <message>
        <source>Downloading &apos;%1&apos;, please wait...</source>
        <comment>e.g: Downloading &apos;xxx.torrent&apos;, please wait...</comment>
        <translation>Prebieha sťahovanie „%1“, čakajte prosím...</translation>
    </message>
    <message>
        <source>The network interface defined is invalid: %1</source>
        <translation>Definované sieťové rozhranie je neplatné: %1</translation>
    </message>
    <message>
        <source>Trying any other network interface available instead.</source>
        <translation>Namiesto toho sa skúša ľubovoľné iné sieťové rozhranie.</translation>
    </message>
    <message>
        <source>Listening on IP address %1 on network interface %2...</source>
        <translation>Počúva sa na IP adrese %1 na sieťovom rozhraní %2...</translation>
    </message>
    <message>
        <source>Failed to listen on network interface %1</source>
        <translation>Nepodarilo sa spustiť počúvanie na sieťovom rozhraní %1</translation>
    </message>
    <message>
        <source>UPnP / NAT-PMP support [ON]</source>
        <translation>Podpora UPnP/NAT-PMP [zapnutá]</translation>
    </message>
    <message>
        <source>UPnP / NAT-PMP support [OFF]</source>
        <translation>Podpora UPnP/NAT-PMP [vypnutá]</translation>
    </message>
    <message>
        <source>Local Peer Discovery support [ON]</source>
        <translation>Podpora Local Peer Discovery [zapnutá]</translation>
    </message>
    <message>
        <source>Successfuly parsed the provided IP filter: %1 rules were applied.</source>
        <comment>%1 is a number</comment>
        <translation>Poskytnutý filter IP úspešne spracovaný: %1 pravidiel bolo použitých.</translation>
    </message>
    <message>
        <source>Error: Failed to parse the provided IP filter.</source>
        <translation>Chyba: Nepodarilo sa spracovať poskytnutý filter IP.</translation>
    </message>
    <message>
        <source>Reporting IP address %1 to trackers...</source>
        <translation>Trackerom sa oznamuje IP adresa %1...</translation>
    </message>
    <message>
        <source>The computer will now go to sleep mode unless you cancel within the next 15 seconds...</source>
        <translation>Počítač prejde do režimu spánku ak to nezrušíte do 15 sekúnd odteraz...</translation>
    </message>
    <message>
        <source>The computer will now be switched off unless you cancel within the next 15 seconds...</source>
        <translation>Počítač sa vypne ak to nezrušíte do 15 sekúnd odteraz...</translation>
    </message>
    <message>
        <source>qBittorrent will now exit unless you cancel within the next 15 seconds...</source>
        <translation>qBittorrent sa ukončí ak to nezrušíte do 15 sekúnd odteraz...</translation>
    </message>
</context>
<context>
    <name>RSS</name>
    <message>
        <source>Search</source>
        <translation>Vyhľadávanie</translation>
    </message>
    <message>
        <source>Refresh RSS streams</source>
        <translation>Obnoviť RSS streamy</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Zmazať</translation>
    </message>
    <message>
        <source>Rename</source>
        <translation>Premenovať</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Torrents:&lt;/span&gt; &lt;span style=&quot; font-style:italic;&quot;&gt;(double-click to download)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Torrenty:&lt;/span&gt; &lt;span style=&quot; font-style:italic;&quot;&gt;(stiahnite dvojitým kliknutím)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Download torrent</source>
        <translation>Stiahnuť torrent</translation>
    </message>
    <message>
        <source>Open news URL</source>
        <translation>Otvoriť URL kanála</translation>
    </message>
    <message>
        <source>Copy feed URL</source>
        <translation>Skopírovať URL kanála</translation>
    </message>
    <message>
        <source>New subscription</source>
        <translation>Nové predplatné</translation>
    </message>
    <message>
        <source>Mark items read</source>
        <translation>Označiť položku ako prečítané</translation>
    </message>
    <message>
        <source>Update all</source>
        <translation>Aktualizovať všetky</translation>
    </message>
    <message>
        <source>Update all feeds</source>
        <translation>Aktualizovať všetky kanálu</translation>
    </message>
    <message>
        <source>RSS feeds</source>
        <translation type="obsolete">RSS kanály
</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Aktualizovať</translation>
    </message>
    <message>
        <source>Feed URL</source>
        <translation type="obsolete">URL kanála</translation>
    </message>
    <message>
        <source>Article title</source>
        <translation type="obsolete">Názov článku</translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation>Premenovať...</translation>
    </message>
    <message>
        <source>New subscription...</source>
        <translation>Nový odber...</translation>
    </message>
    <message>
        <source>RSS feed downloader...</source>
        <translation type="obsolete">Sťahovanie RSS kanálov...</translation>
    </message>
    <message>
        <source>New folder...</source>
        <translation>Nový priečinok ...</translation>
    </message>
    <message>
        <source>Manage cookies...</source>
        <translation>Správa cookies...</translation>
    </message>
    <message>
        <source>Settings...</source>
        <translation>Nastavenia...</translation>
    </message>
    <message>
        <source>RSS Downloader...</source>
        <translation>Sťahovanie RSS kanálov...</translation>
    </message>
</context>
<context>
    <name>RSSImp</name>
    <message>
        <source>Are you sure? -- qBittorrent</source>
        <translation>Ste si istý? -- qBittorrent</translation>
    </message>
    <message>
        <source>&amp;Yes</source>
        <translation>&amp;Áno</translation>
    </message>
    <message>
        <source>&amp;No</source>
        <translation>&amp;Nie</translation>
    </message>
    <message>
        <source>Please type a rss stream url</source>
        <translation>Prosím, napíšte URL RSS streamu</translation>
    </message>
    <message>
        <source>Stream URL:</source>
        <translation>URL streamu:</translation>
    </message>
    <message>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <source>This rss feed is already in the list.</source>
        <translation>Tento RSS kanál už je v zozname.</translation>
    </message>
    <message>
        <source>Date: </source>
        <translation>Dátum: </translation>
    </message>
    <message>
        <source>Author: </source>
        <translation>Autor: </translation>
    </message>
    <message>
        <source>Please choose a folder name</source>
        <translation>Prosím, vyberte názov priečinka</translation>
    </message>
    <message>
        <source>Folder name:</source>
        <translation>Názov priečinka:</translation>
    </message>
    <message>
        <source>New folder</source>
        <translation>Nový priečinok</translation>
    </message>
    <message>
        <source>Are you sure you want to delete these elements from the list?</source>
        <translation>Ste si istý, že chcete zmazať tieto prvky zo zoznamu?</translation>
    </message>
    <message>
        <source>Are you sure you want to delete this element from the list?</source>
        <translation>Ste si istý, že chcete zmazať tento prvok zo zoznamu?</translation>
    </message>
    <message>
        <source>Please choose a new name for this RSS feed</source>
        <translation>Prosím, vyberte nový názov pre tento RSS kanál</translation>
    </message>
    <message>
        <source>New feed name:</source>
        <translation>Nový názov kanála:</translation>
    </message>
    <message>
        <source>Name already in use</source>
        <translation>Názov sa už používa</translation>
    </message>
    <message>
        <source>This name is already used by another item, please choose another one.</source>
        <translation>Tento názov už používa iná položka. Prosím, zvoľte iný názov.</translation>
    </message>
    <message>
        <source>Overwrite attempt</source>
        <translation>Pokus o prepísanie</translation>
    </message>
    <message>
        <source>You cannot overwrite %1 item.</source>
        <comment>You cannot overwrite myFolder item.</comment>
        <translation>Nemôžete prepísať položku %1.</translation>
    </message>
    <message>
        <source>Unread</source>
        <translation>Neprečítané</translation>
    </message>
</context>
<context>
    <name>RssArticle</name>
    <message>
        <source>No description available</source>
        <translation type="obsolete">Popis nie je dostupný</translation>
    </message>
</context>
<context>
    <name>RssFeed</name>
    <message>
        <source>Automatically downloading %1 torrent from %2 RSS feed...</source>
        <translation>Automaticky sa sťahuje torrent %1 z RSS kanála %2...</translation>
    </message>
</context>
<context>
    <name>RssItem</name>
    <message>
        <source>No description available</source>
        <translation type="obsolete">Popis nie je dostupný</translation>
    </message>
</context>
<context>
    <name>RssSettings</name>
    <message>
        <source>RSS Reader Settings</source>
        <translation type="obsolete">Nastavenia čítačky RSS</translation>
    </message>
    <message>
        <source>RSS feeds refresh interval:</source>
        <translation type="obsolete">Interval obnovovania RSS kanálov:</translation>
    </message>
    <message>
        <source>minutes</source>
        <translation type="obsolete">minút</translation>
    </message>
    <message>
        <source>Maximum number of articles per feed:</source>
        <translation type="obsolete">Maximálny počet článkov na kanál:</translation>
    </message>
</context>
<context>
    <name>RssSettingsDlg</name>
    <message>
        <source>RSS Reader Settings</source>
        <translation>Nastavenia čítačky RSS</translation>
    </message>
    <message>
        <source>RSS feeds refresh interval:</source>
        <translation>Interval obnovovania RSS kanálov:</translation>
    </message>
    <message>
        <source>minutes</source>
        <translation>minút</translation>
    </message>
    <message>
        <source>Maximum number of articles per feed:</source>
        <translation>Maximálny počet článkov na kanál:</translation>
    </message>
</context>
<context>
    <name>RssStream</name>
    <message>
        <source>Automatically downloading %1 torrent from %2 RSS feed...</source>
        <translation type="obsolete">Automaticky sa sťahuje torrent %1 z RSS kanála %2...</translation>
    </message>
</context>
<context>
    <name>ScanFoldersModel</name>
    <message>
        <source>Watched Folder</source>
        <translation>Sledovaný priečinok</translation>
    </message>
    <message>
        <source>Download here</source>
        <translation>Stiahnuť sem</translation>
    </message>
</context>
<context>
    <name>SearchCategories</name>
    <message>
        <source>All categories</source>
        <translation>Všetky kategórie</translation>
    </message>
    <message>
        <source>Movies</source>
        <translation>Filmy</translation>
    </message>
    <message>
        <source>TV shows</source>
        <translation>TV relácie</translation>
    </message>
    <message>
        <source>Music</source>
        <translation>Hudba</translation>
    </message>
    <message>
        <source>Games</source>
        <translation>Hry</translation>
    </message>
    <message>
        <source>Anime</source>
        <translation>Anime</translation>
    </message>
    <message>
        <source>Software</source>
        <translation>Softvér</translation>
    </message>
    <message>
        <source>Pictures</source>
        <translation>Obrázky</translation>
    </message>
    <message>
        <source>Books</source>
        <translation>Knihy</translation>
    </message>
</context>
<context>
    <name>SearchEngine</name>
    <message>
        <source>Empty search pattern</source>
        <translation>Prázdny vyhľadávací vzor</translation>
    </message>
    <message>
        <source>Please type a search pattern first</source>
        <translation>Prosím, najprv zadajte vyhľadávací vzor</translation>
    </message>
    <message>
        <source>Results</source>
        <translation>Výsledky</translation>
    </message>
    <message>
        <source>Searching...</source>
        <translation>Hľadá sa...</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation>Vystrihnúť</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Kopírovať</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation>Vložiť</translation>
    </message>
    <message>
        <source>Clear field</source>
        <translation>Vyčistiť pole</translation>
    </message>
    <message>
        <source>Clear completion history</source>
        <translation>Vyčistiť históriu dopĺňania</translation>
    </message>
    <message>
        <source>Search Engine</source>
        <translation>Vyhľadávač</translation>
    </message>
    <message>
        <source>Search has finished</source>
        <translation>Hľadanie skončené</translation>
    </message>
    <message>
        <source>An error occured during search...</source>
        <translation>Počas vyhľadávania sa vyskytla chyba...</translation>
    </message>
    <message>
        <source>Search aborted</source>
        <translation>Vyhľadávanie preušené</translation>
    </message>
    <message>
        <source>Search returned no results</source>
        <translation>Vyhľadávanie nevrátilo žiadne výsledky</translation>
    </message>
    <message>
        <source>Results</source>
        <comment>i.e: Search results</comment>
        <translation>Výsledky</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Neznámy</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Vyhľadávanie</translation>
    </message>
    <message>
        <source>Download error</source>
        <translation>Chyba pri sťahovaní</translation>
    </message>
    <message>
        <source>Python setup could not be downloaded, reason: %1.
Please install it manually.</source>
        <translation>Nebolo možné stiahnuť inštalačný program Pythonu. Dôvod: %1
Prosím, nainštalujte ho ručne.</translation>
    </message>
    <message>
        <source>Missing Python Interpreter</source>
        <translation>Chýbajúci interpreter Pythonu</translation>
    </message>
    <message>
        <source>Python 2.x is required to use the search engine but it does not seem to be installed.
Do you want to install it now?</source>
        <translation>Na používanie vyhľadávača je potrebný Python 2.x, ale zdá sa, že nie je nainštalovaný.
Chcete ho nainštalovať teraz?</translation>
    </message>
    <message>
        <source>Confirmation</source>
        <translation>Potvrdenie</translation>
    </message>
    <message>
        <source>Are you sure you want to clear the history?</source>
        <translation>Ste si istý, že chcete vymazať históriu?</translation>
    </message>
</context>
<context>
    <name>SearchTab</name>
    <message>
        <source>Name</source>
        <comment>i.e: file name</comment>
        <translation>Názov</translation>
    </message>
    <message>
        <source>Size</source>
        <comment>i.e: file size</comment>
        <translation>Veľkosť</translation>
    </message>
    <message>
        <source>Seeders</source>
        <comment>i.e: Number of full sources</comment>
        <translation>Seederi</translation>
    </message>
    <message>
        <source>Leechers</source>
        <comment>i.e: Number of partial sources</comment>
        <translation>Leecheri</translation>
    </message>
    <message>
        <source>Search engine</source>
        <translation>Vyhľadávač</translation>
    </message>
</context>
<context>
    <name>ShutdownConfirmDlg</name>
    <message>
        <source>Shutdown confirmation</source>
        <translation>Potvrdenie vypnutia</translation>
    </message>
</context>
<context>
    <name>SpeedLimitDialog</name>
    <message>
        <source>KiB/s</source>
        <translation>KiB/s</translation>
    </message>
</context>
<context>
    <name>StatusBar</name>
    <message>
        <source>Connection status:</source>
        <translation>Stav spojenia:</translation>
    </message>
    <message>
        <source>No direct connections. This may indicate network configuration problems.</source>
        <translation>Žiadne priame spojenia. To môže znamenať problém s nastavením siete.</translation>
    </message>
    <message>
        <source>DHT: %1 nodes</source>
        <translation>DHT: %1 uzlov</translation>
    </message>
    <message>
        <source>Connection Status:</source>
        <translation>Stav spojenia:</translation>
    </message>
    <message>
        <source>Online</source>
        <translation>Online</translation>
    </message>
    <message>
        <source>Global Download Speed Limit</source>
        <translation>Globálne rýchlostné obmedzenie sťahovania</translation>
    </message>
    <message>
        <source>Global Upload Speed Limit</source>
        <translation>Globálne rýchlostné obmedzenie nahrávania</translation>
    </message>
    <message>
        <source>D: %1/s - T: %2</source>
        <comment>Download speed: x KiB/s - Transferred: x MiB</comment>
        <translation type="obsolete">Sťah.: %1/s - Pren.: %2</translation>
    </message>
    <message>
        <source>U: %1/s - T: %2</source>
        <comment>Upload speed: x KiB/s - Transferred: x MiB</comment>
        <translation type="obsolete">Nahr.: %1/s - Pren.: %2</translation>
    </message>
    <message>
        <source>D: %1 B/s - T: %2</source>
        <comment>Download speed: x B/s - Transferred: x MiB</comment>
        <translation type="obsolete">Sťah.: %1 B/s - Pren.: %2</translation>
    </message>
    <message>
        <source>U: %1 B/s - T: %2</source>
        <comment>Upload speed: x B/s - Transferred: x MiB</comment>
        <translation type="obsolete">Nahr.: %1 B/s - Pren.: %2</translation>
    </message>
    <message>
        <source>Offline. This usually means that qBittorrent failed to listen on the selected port for incoming connections.</source>
        <translation>Odpojený. To zvyčajne znamená, že qBittorrent nedokázal počúvať prichádzajúce spojenia na zvolenom porte.</translation>
    </message>
    <message>
        <source>Click to disable alternative speed limits</source>
        <translation type="obsolete">Kliknutím vypnete alternatívne globálne rýchlostné obmedzenia</translation>
    </message>
    <message>
        <source>Click to enable alternative speed limits</source>
        <translation type="obsolete">Kliknutím zapnete alternatívne globálne rýchlostné obmedzenia</translation>
    </message>
    <message>
        <source>qBittorrent needs to be restarted</source>
        <translation>Je potrebné reštartovať qBittorrent</translation>
    </message>
    <message>
        <source>qBittorrent was just updated and needs to be restarted for the changes to be effective.</source>
        <translation>qBittorrent bol práve aktualizovaný a je potrebné ho reštartovať, aby sa zmeny prejavili.</translation>
    </message>
    <message>
        <source>Click to switch to alternative speed limits</source>
        <translation>Kliknutím prepnete na alternatívne rýchlostné obmedzenia</translation>
    </message>
    <message>
        <source>Click to switch to regular speed limits</source>
        <translation>Kliknutím prepnete na bežné rýchlostné obmedzenia</translation>
    </message>
    <message>
        <source>%1/s</source>
        <comment>Per second</comment>
        <translation>%1/s</translation>
    </message>
</context>
<context>
    <name>TorrentCreatorDlg</name>
    <message>
        <source>Select a folder to add to the torrent</source>
        <translation>Vyberte adresár, ktorý sa má pridať do torrentu</translation>
    </message>
    <message>
        <source>Select a file to add to the torrent</source>
        <translation>Vyberte súbor, ktorý sa má pridať do torrentu</translation>
    </message>
    <message>
        <source>Please type an announce URL</source>
        <translation type="obsolete">Prosím, napíšte announce URL</translation>
    </message>
    <message>
        <source>Announce URL:</source>
        <comment>Tracker URL</comment>
        <translation type="obsolete">Announce URL:</translation>
    </message>
    <message>
        <source>Please type a web seed url</source>
        <translation type="obsolete">Prosím, napíšte web seed URL</translation>
    </message>
    <message>
        <source>Web seed URL:</source>
        <translation type="obsolete">Web seed URL:</translation>
    </message>
    <message>
        <source>No input path set</source>
        <translation>Nebola zadaná vstupná cesta</translation>
    </message>
    <message>
        <source>Please type an input path first</source>
        <translation>Napíšte prosím najprv vstupnú cestu</translation>
    </message>
    <message>
        <source>Select destination torrent file</source>
        <translation>Vybrať cieľový torrent súbor</translation>
    </message>
    <message>
        <source>Torrent Files</source>
        <translation>Torrent súbory</translation>
    </message>
    <message>
        <source>Torrent creation</source>
        <translation>Vytvorenie torrentu</translation>
    </message>
    <message>
        <source>Torrent creation was unsuccessful, reason: %1</source>
        <translation>Torrent nebol vytvorený, dôvod: %1</translation>
    </message>
    <message>
        <source>Created torrent file is invalid. It won&apos;t be added to download list.</source>
        <translation>Vytvorený torrent je neplatný. Nebude pridaný do zoznamu sťahovaných.</translation>
    </message>
    <message>
        <source>Torrent was created successfully:</source>
        <translation>Torrent bol úspešne vytvorený:</translation>
    </message>
</context>
<context>
    <name>TorrentFilesModel</name>
    <message>
        <source>Name</source>
        <translation>Názov</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Veľkosť</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation>Priebeh</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Priorita</translation>
    </message>
</context>
<context>
    <name>TorrentImportDlg</name>
    <message>
        <source>Torrent Import</source>
        <translation>Importovať torrent</translation>
    </message>
    <message>
        <source>This assistant will help you share with qBittorrent a torrent that you have already downloaded.</source>
        <translation>Asistent vám teraz pomôže zdieľať pomocou qBittorrentu torrent, ktorý ste už stiahli.</translation>
    </message>
    <message>
        <source>Torrent file to import:</source>
        <translation>Importovať torrent:</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Content location:</source>
        <translation>Umiestnenie obsahu:</translation>
    </message>
    <message>
        <source>Skip the data checking stage and start seeding immediately</source>
        <translation>Preskočiť kontrolu súborov a začať seedovať okamžite</translation>
    </message>
    <message>
        <source>Import</source>
        <translation>Importovať</translation>
    </message>
    <message>
        <source>Torrent file to import</source>
        <translation>Importovať torrent</translation>
    </message>
    <message>
        <source>Torrent files (*.torrent)</source>
        <translation>Torrent súbory (*.torrent)</translation>
    </message>
    <message>
        <source>%1 Files</source>
        <comment>%1 is a file extension (e.g. PDF)</comment>
        <translation>Súbory %1</translation>
    </message>
    <message>
        <source>Please provide the location of %1</source>
        <comment>%1 is a file name</comment>
        <translation>Prosím, napíšte umiestnenie %1</translation>
    </message>
    <message>
        <source>Please point to the location of the torrent: %1</source>
        <translation>Prosím, napíšte umiestnenie torrentu %1</translation>
    </message>
    <message>
        <source>Invalid torrent file</source>
        <translation>Neplatný torrent</translation>
    </message>
    <message>
        <source>This is not a valid torrent file.</source>
        <translation>Toto nie je platný torrent.</translation>
    </message>
</context>
<context>
    <name>TorrentModel</name>
    <message>
        <source>Name</source>
        <comment>i.e: torrent name</comment>
        <translation>Názov</translation>
    </message>
    <message>
        <source>Size</source>
        <comment>i.e: torrent size</comment>
        <translation>Veľkosť</translation>
    </message>
    <message>
        <source>Done</source>
        <comment>% Done</comment>
        <translation>Hotovo</translation>
    </message>
    <message>
        <source>Status</source>
        <comment>Torrent status (e.g. downloading, seeding, paused)</comment>
        <translation>Stav</translation>
    </message>
    <message>
        <source>Seeds</source>
        <comment>i.e. full sources (often untranslated)</comment>
        <translation>Seedov</translation>
    </message>
    <message>
        <source>Peers</source>
        <comment>i.e. partial sources (often untranslated)</comment>
        <translation>Rovesníkov</translation>
    </message>
    <message>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Rýchlosť sťahovania</translation>
    </message>
    <message>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Rýchlosť nahrávania</translation>
    </message>
    <message>
        <source>Ratio</source>
        <comment>Share ratio</comment>
        <translation>Pomer</translation>
    </message>
    <message>
        <source>ETA</source>
        <comment>i.e: Estimated Time of Arrival / Time left</comment>
        <translation>Odhad. čas</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Označenie</translation>
    </message>
    <message>
        <source>Added On</source>
        <comment>Torrent was added to transfer list on 01/01/2010 08:00</comment>
        <translation>Pridané</translation>
    </message>
    <message>
        <source>Completed On</source>
        <comment>Torrent was completed on 01/01/2010 08:00</comment>
        <translation>Dokončené</translation>
    </message>
    <message>
        <source>Tracker</source>
        <translation>Tracker</translation>
    </message>
    <message>
        <source>Down Limit</source>
        <comment>i.e: Download limit</comment>
        <translation>Limit sťah.</translation>
    </message>
    <message>
        <source>Up Limit</source>
        <comment>i.e: Upload limit</comment>
        <translation>Limit nahr.</translation>
    </message>
    <message>
        <source>Amount downloaded</source>
        <comment>Amount of data downloaded (e.g. in MB)</comment>
        <translation>Stiahnuté</translation>
    </message>
    <message>
        <source>Amount left</source>
        <comment>Amount of data left to download (e.g. in MB)</comment>
        <translation>Zostáva</translation>
    </message>
    <message>
        <source>Time Active</source>
        <comment>Time (duration) the torrent is active (not paused)</comment>
        <translation>Čas aktivity</translation>
    </message>
</context>
<context>
    <name>TrackerList</name>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Stav</translation>
    </message>
    <message>
        <source>Peers</source>
        <translation>Rovesníci</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Správa</translation>
    </message>
    <message>
        <source>[DHT]</source>
        <translation>[DHT]</translation>
    </message>
    <message>
        <source>Working</source>
        <translation>Pracuje sa</translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Vypnuté</translation>
    </message>
    <message>
        <source>This torrent is private</source>
        <translation>Torrent je súkromný</translation>
    </message>
    <message>
        <source>Updating...</source>
        <translation>Prebieha aktualizácia...</translation>
    </message>
    <message>
        <source>Not working</source>
        <translation>Nefunguje</translation>
    </message>
    <message>
        <source>Not contacted yet</source>
        <translation>Zatiaľ nekontaktovaný</translation>
    </message>
    <message>
        <source>[PeX]</source>
        <translation>[PeX]</translation>
    </message>
    <message>
        <source>[LSD]</source>
        <translation>[LSD]</translation>
    </message>
    <message>
        <source>Add a new tracker...</source>
        <translation>Pridať nový tracker...</translation>
    </message>
    <message>
        <source>Remove tracker</source>
        <translation>Odstrániť tracker</translation>
    </message>
    <message>
        <source>Force reannounce</source>
        <translation>Vynútiť opätovné ohlásenie</translation>
    </message>
</context>
<context>
    <name>TrackersAdditionDlg</name>
    <message>
        <source>Trackers addition dialog</source>
        <translation>Dialóg pre pridanie torrentu</translation>
    </message>
    <message>
        <source>List of trackers to add (one per line):</source>
        <translation>Pridať nasledovné trackery (jeden tracker na riadok):</translation>
    </message>
    <message utf8="true">
        <source>µTorrent compatible list URL:</source>
        <translation>Zoznam URL kompatibilný s µTorrent:</translation>
    </message>
    <message>
        <source>I/O Error</source>
        <translation>V/V Chyba</translation>
    </message>
    <message>
        <source>Error while trying to open the downloaded file.</source>
        <translation>Chyba počas pokusu otvoriť stiahnutý súbor.</translation>
    </message>
    <message>
        <source>No change</source>
        <translation>Bez zmeny</translation>
    </message>
    <message>
        <source>No additional trackers were found.</source>
        <translation>Neboli nájdené žiadne ďalšie trackery.</translation>
    </message>
    <message>
        <source>Download error</source>
        <translation>Chyba pri sťahovaní</translation>
    </message>
    <message>
        <source>The trackers list could not be downloaded, reason: %1</source>
        <translation>Trackery nebolo možné stiahnuť. Dôvod: %1</translation>
    </message>
</context>
<context>
    <name>TransferListDelegate</name>
    <message>
        <source>Downloading</source>
        <translation>Sťahuje sa</translation>
    </message>
    <message>
        <source>Paused</source>
        <translation>Pozastavený</translation>
    </message>
    <message>
        <source>Queued</source>
        <comment>i.e. torrent is queued</comment>
        <translation>Vo fronte</translation>
    </message>
    <message>
        <source>Seeding</source>
        <comment>Torrent is complete and in upload-only mode</comment>
        <translation>Seeduje sa</translation>
    </message>
    <message>
        <source>Stalled</source>
        <comment>Torrent is waiting for download to begin</comment>
        <translation>Bez pohybu</translation>
    </message>
    <message>
        <source>Checking</source>
        <comment>Torrent local data is being checked</comment>
        <translation></translation>
    </message>
    <message>
        <source>/s</source>
        <comment>/second (.i.e per second)</comment>
        <translation>/s</translation>
    </message>
    <message>
        <source>KiB/s</source>
        <comment>KiB/second (.i.e per second)</comment>
        <translation>KiB/s</translation>
    </message>
    <message>
        <source>Seeded for %1</source>
        <comment>e.g. Seeded for 3m10s</comment>
        <translation>Seedovanie trvalo %1</translation>
    </message>
</context>
<context>
    <name>TransferListFiltersWidget</name>
    <message>
        <source>All</source>
        <translation>Všetky</translation>
    </message>
    <message>
        <source>Downloading</source>
        <translation>Sťahované</translation>
    </message>
    <message>
        <source>Completed</source>
        <translation>Dokončené</translation>
    </message>
    <message>
        <source>Active</source>
        <translation>Aktívne</translation>
    </message>
    <message>
        <source>Inactive</source>
        <translation>Neaktívne</translation>
    </message>
    <message>
        <source>All labels</source>
        <translation>Všetky označenia</translation>
    </message>
    <message>
        <source>Unlabeled</source>
        <translation>Bez označenia</translation>
    </message>
    <message>
        <source>Remove label</source>
        <translation> Odstrániť označenie</translation>
    </message>
    <message>
        <source>New Label</source>
        <translation>Nové označenie</translation>
    </message>
    <message>
        <source>Label:</source>
        <translation>Označenie:</translation>
    </message>
    <message>
        <source>Invalid label name</source>
        <translation>Neplatný názov označenia</translation>
    </message>
    <message>
        <source>Please don&apos;t use any special characters in the label name.</source>
        <translation>Prosím, nepoužívajte v názve označenia špeciálne znaky.</translation>
    </message>
    <message>
        <source>Paused</source>
        <translation>Pozastavený</translation>
    </message>
    <message>
        <source>Add label...</source>
        <translation>Pridať označenie...</translation>
    </message>
    <message>
        <source>Resume torrents</source>
        <translation>Pokračovať v torrentoch</translation>
    </message>
    <message>
        <source>Pause torrents</source>
        <translation>Pozastaviť torrenty</translation>
    </message>
    <message>
        <source>Delete torrents</source>
        <translation>Zmazať torrenty</translation>
    </message>
</context>
<context>
    <name>TransferListWidget</name>
    <message>
        <source>ETA</source>
        <comment>i.e: Estimated Time of Arrival / Time left</comment>
        <translation type="obsolete">Odhad. čas</translation>
    </message>
    <message>
        <source>Column visibility</source>
        <translation>Viditeľnosť stĺpca</translation>
    </message>
    <message>
        <source>Open destination folder</source>
        <translation>Otvoriť cieľový priečinok</translation>
    </message>
    <message>
        <source>Force recheck</source>
        <translation>Vynútiť opätovnú kontrolu</translation>
    </message>
    <message>
        <source>Copy magnet link</source>
        <translation>Kopírovať magnet URI</translation>
    </message>
    <message>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation type="obsolete">Rýchlosť sťahovania</translation>
    </message>
    <message>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation type="obsolete">Rýchlosť nahrávania</translation>
    </message>
    <message>
        <source>Name</source>
        <comment>i.e: torrent name</comment>
        <translation type="obsolete">Názov</translation>
    </message>
    <message>
        <source>Size</source>
        <comment>i.e: torrent size</comment>
        <translation type="obsolete">Veľkosť</translation>
    </message>
    <message>
        <source>Done</source>
        <comment>% Done</comment>
        <translation type="obsolete">Hotovo</translation>
    </message>
    <message>
        <source>Status</source>
        <comment>Torrent status (e.g. downloading, seeding, paused)</comment>
        <translation type="obsolete">Stav</translation>
    </message>
    <message>
        <source>Seeds</source>
        <comment>i.e. full sources (often untranslated)</comment>
        <translation type="obsolete">Seedy</translation>
    </message>
    <message>
        <source>Peers</source>
        <comment>i.e. partial sources (often untranslated)</comment>
        <translation type="obsolete">Rovesníci</translation>
    </message>
    <message>
        <source>Ratio</source>
        <comment>Share ratio</comment>
        <translation type="obsolete">Pomer</translation>
    </message>
    <message>
        <source>Torrent Download Speed Limiting</source>
        <translation>Obmedzenie rýchlosti sťahovania torrentu</translation>
    </message>
    <message>
        <source>Torrent Upload Speed Limiting</source>
        <translation>Obmedzenie rýchlosti nahrávania torrentu</translation>
    </message>
    <message>
        <source>Super seeding mode</source>
        <translation>Režim super seedovania</translation>
    </message>
    <message>
        <source>Download in sequential order</source>
        <translation>Sťahovať v poradí</translation>
    </message>
    <message>
        <source>Download first and last piece first</source>
        <translation>Sťahovať najprv prvú a poslednú časť</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Označenie</translation>
    </message>
    <message>
        <source>New Label</source>
        <translation>Nové označenie</translation>
    </message>
    <message>
        <source>Label:</source>
        <translation>Označenie:</translation>
    </message>
    <message>
        <source>New...</source>
        <comment>New label...</comment>
        <translation>Nové...</translation>
    </message>
    <message>
        <source>Reset</source>
        <comment>Reset label</comment>
        <translation>Vrátiť</translation>
    </message>
    <message>
        <source>Rename</source>
        <translation>Premenovať</translation>
    </message>
    <message>
        <source>New name:</source>
        <translation>Nový názov:</translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation>Premenovať...</translation>
    </message>
    <message>
        <source>Invalid label name</source>
        <translation>Neplatný názov označenia</translation>
    </message>
    <message>
        <source>Please don&apos;t use any special characters in the label name.</source>
        <translation>Prosím, nepoužívajte v názve označenia špeciálne znaky.</translation>
    </message>
    <message>
        <source>Added On</source>
        <comment>Torrent was added to transfer list on 01/01/2010 08:00</comment>
        <translation type="obsolete">Pridané</translation>
    </message>
    <message>
        <source>Completed On</source>
        <comment>Torrent was completed on 01/01/2010 08:00</comment>
        <translation type="obsolete">Dokončené</translation>
    </message>
    <message>
        <source>Down Limit</source>
        <comment>i.e: Download limit</comment>
        <translation type="obsolete">Limit sťah.</translation>
    </message>
    <message>
        <source>Up Limit</source>
        <comment>i.e: Upload limit</comment>
        <translation type="obsolete">Limit nahr.</translation>
    </message>
    <message>
        <source>Choose save path</source>
        <translation>Zvoľte cieľový adresár</translation>
    </message>
    <message>
        <source>Save path creation error</source>
        <translation type="obsolete">Chyba pri vytváraní cieľového adresára</translation>
    </message>
    <message>
        <source>Could not create the save path</source>
        <translation type="obsolete">Nepodarilo sa vytvoriť cieľový adresár</translation>
    </message>
    <message>
        <source>Set location...</source>
        <translation>Nastaviť cieľ...</translation>
    </message>
    <message>
        <source>Preview file...</source>
        <translation>Náhľad súboru...</translation>
    </message>
    <message>
        <source>Limit upload rate...</source>
        <translation>Obmedziť rýchlosť nahrávania...</translation>
    </message>
    <message>
        <source>Limit download rate...</source>
        <translation>Obmedziť rýchlosť sťahovania...</translation>
    </message>
    <message>
        <source>Move up</source>
        <comment>i.e. move up in the queue</comment>
        <translation>Presunúť vyššie</translation>
    </message>
    <message>
        <source>Move down</source>
        <comment>i.e. Move down in the queue</comment>
        <translation>Presunúť nižšie</translation>
    </message>
    <message>
        <source>Move to top</source>
        <comment>i.e. Move to top of the queue</comment>
        <translation>Presunúť navrch</translation>
    </message>
    <message>
        <source>Move to bottom</source>
        <comment>i.e. Move to bottom of the queue</comment>
        <translation>Presunúť na spodok</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Priorita</translation>
    </message>
    <message>
        <source>Resume</source>
        <comment>Resume/start the torrent</comment>
        <translation>Pokračovať</translation>
    </message>
    <message>
        <source>Pause</source>
        <comment>Pause the torrent</comment>
        <translation>Pozastaviť</translation>
    </message>
    <message>
        <source>Delete</source>
        <comment>Delete the torrent</comment>
        <translation>Zmazať</translation>
    </message>
    <message>
        <source>Limit share ratio...</source>
        <translation>Obmedzenie pomeru zdieľania...</translation>
    </message>
</context>
<context>
    <name>UpDownRatioDlg</name>
    <message>
        <source>Torrent Upload/Download Ratio Limiting</source>
        <translation>Obmedzenie pomeru odoslaných/stiahnutých dát torrentu</translation>
    </message>
    <message>
        <source>Use global ratio limit</source>
        <translation>Použiť globálne obmedzenie pomeru</translation>
    </message>
    <message>
        <source>buttonGroup</source>
        <translation>buttonGroup</translation>
    </message>
    <message>
        <source>Set no ratio limit</source>
        <translation>Bez obmedzenia pomeru</translation>
    </message>
    <message>
        <source>Set ratio limit to</source>
        <translation>Nastaviť obmedzenie pomeru na</translation>
    </message>
</context>
<context>
    <name>UsageDisplay</name>
    <message>
        <source>Usage:</source>
        <translation>Použitie:</translation>
    </message>
    <message>
        <source>displays program version</source>
        <translation>zobrazí verziu programu</translation>
    </message>
    <message>
        <source>disable splash screen</source>
        <translation>vypnúť štartovaciu obrazovku</translation>
    </message>
    <message>
        <source>displays this help message</source>
        <translation>zobrazí túto správu Pomocníka</translation>
    </message>
    <message>
        <source>changes the webui port (current: %1)</source>
        <translation>zmení port webového rozhrania (momentálne: %1)</translation>
    </message>
    <message>
        <source>[files or urls]: downloads the torrents passed by the user (optional)</source>
        <translation>[súbory alebo URL]: stiahne uvedené torrenty (nepovinné)</translation>
    </message>
</context>
<context>
    <name>about</name>
    <message>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <source>I would like to thank the following people who volunteered to translate qBittorrent:</source>
        <translation>Rád by som poďakoval nasledovným dobrovoľníkom, ktorí preložili qBittorrent:</translation>
    </message>
    <message>
        <source>Please contact me if you would like to translate qBittorrent into your own language.</source>
        <translation>Prosím, kontaktujte ma ak chcete preložiť qBittorrent do vášho jazyka.</translation>
    </message>
</context>
<context>
    <name>addPeerDialog</name>
    <message>
        <source>Peer addition</source>
        <translation>Pridanie rovesníka</translation>
    </message>
    <message>
        <source>IP</source>
        <translation>IP</translation>
    </message>
    <message>
        <source>Port</source>
        <translation>Port</translation>
    </message>
</context>
<context>
    <name>addTorrentDialog</name>
    <message>
        <source>Torrent addition dialog</source>
        <translation>Dialóg pre pridanie torrentu</translation>
    </message>
    <message>
        <source>Save path:</source>
        <translation>Uložiť kam:</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Torrent content:</source>
        <translation>Obsah torrentu:</translation>
    </message>
    <message>
        <source>Add to download list in paused state</source>
        <translation>Pridať do zoznamu sťahovaných v stave pozastavený</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>Pridať</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Storno</translation>
    </message>
    <message>
        <source>Normal</source>
        <translation>Normálna</translation>
    </message>
    <message>
        <source>High</source>
        <translation>Vysoká</translation>
    </message>
    <message>
        <source>Maximum</source>
        <translation>Maximálna</translation>
    </message>
    <message>
        <source>Torrent size:</source>
        <translation>Veľkosť torrentu:</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Neznáma</translation>
    </message>
    <message>
        <source>Free disk space:</source>
        <translation>Voľné miesto na disku:</translation>
    </message>
    <message>
        <source>Download in sequential order (slower but good for previewing)</source>
        <translation>Sťahovať v postupnom poradí (pomalšie, ale lepšie pre náhľady)</translation>
    </message>
    <message>
        <source>Skip file checking and start seeding immediately</source>
        <translation>Preskočiť kontrolu súborov a začať seedovať okamžite</translation>
    </message>
    <message>
        <source>Label:</source>
        <translation>Označenie:</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Vybrať všetky</translation>
    </message>
    <message>
        <source>Select None</source>
        <translation>Nevybrať nič</translation>
    </message>
    <message>
        <source>Do not download</source>
        <translation>Nesťahovať</translation>
    </message>
</context>
<context>
    <name>authentication</name>
    <message>
        <source>Tracker authentication</source>
        <translation>Autentifikácia trackera</translation>
    </message>
    <message>
        <source>Tracker:</source>
        <translation>Tracker:</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Prihlásenie</translation>
    </message>
    <message>
        <source>Username:</source>
        <translation>Meno používateľa:</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation>Heslo:</translation>
    </message>
    <message>
        <source>Log in</source>
        <translation>Prihásiť sa</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Storno</translation>
    </message>
</context>
<context>
    <name>confirmDeletionDlg</name>
    <message>
        <source>Deletion confirmation - qBittorrent</source>
        <translation>Potvrdenie zmazania - qBittorrent</translation>
    </message>
    <message>
        <source>Are you sure you want to delete the selected torrents from the transfer list?</source>
        <translation>Ste s istý, že chcete zmazať vybrané torrenty zo zoznamu prenosov?</translation>
    </message>
    <message>
        <source>Remember choice</source>
        <translation>Pamätať si vyrovnávaciu pamäť</translation>
    </message>
    <message>
        <source>Also delete the files on the hard disk</source>
        <translation>Zmazať aj súbory na pevnom disku</translation>
    </message>
</context>
<context>
    <name>createTorrentDialog</name>
    <message>
        <source>Cancel</source>
        <translation>Storno</translation>
    </message>
    <message>
        <source>Torrent Creation Tool</source>
        <translation>Nástroj na vytvorenie Torrentu</translation>
    </message>
    <message>
        <source>Torrent file creation</source>
        <translation>Vytvorenie Torrent súboru</translation>
    </message>
    <message>
        <source>Announce urls (trackers):</source>
        <translation type="obsolete">Announce url (trackery):</translation>
    </message>
    <message>
        <source>Comment (optional):</source>
        <translation type="obsolete">Komentár (voliteľné):</translation>
    </message>
    <message>
        <source>Web seeds urls (optional):</source>
        <translation type="obsolete">URL web seedov (voliteľné):</translation>
    </message>
    <message>
        <source>File or folder to add to the torrent:</source>
        <translation>Súbor alebo priečinok, ktorý sa má pridať do torrentu:</translation>
    </message>
    <message>
        <source>Piece size:</source>
        <translation>Veľkosť časti:</translation>
    </message>
    <message>
        <source>32 KiB</source>
        <translation>32 KiB</translation>
    </message>
    <message>
        <source>64 KiB</source>
        <translation>64 KiB</translation>
    </message>
    <message>
        <source>128 KiB</source>
        <translation>128 KiB</translation>
    </message>
    <message>
        <source>256 KiB</source>
        <translation>256 KiB</translation>
    </message>
    <message>
        <source>512 KiB</source>
        <translation>512 KiB</translation>
    </message>
    <message>
        <source>1 MiB</source>
        <translation>1 MiB</translation>
    </message>
    <message>
        <source>2 MiB</source>
        <translation>2 MiB</translation>
    </message>
    <message>
        <source>4 MiB</source>
        <translation>4 MiB</translation>
    </message>
    <message>
        <source>Private (won&apos;t be distributed on DHT network if enabled)</source>
        <translation>Súkromný (ak je zapnuté, nebude sa šíriť pomocou siete DHT)</translation>
    </message>
    <message>
        <source>Start seeding after creation</source>
        <translation>Začať seedovanie po vytvorení</translation>
    </message>
    <message>
        <source>Create and save...</source>
        <translation>Vytvoriť a uložiť...</translation>
    </message>
    <message>
        <source>Progress:</source>
        <translation>Priebeh:</translation>
    </message>
    <message>
        <source>Add file</source>
        <translation>Pridať súbor</translation>
    </message>
    <message>
        <source>Add folder</source>
        <translation>Pridať priečinok</translation>
    </message>
    <message>
        <source>Tracker URLs:</source>
        <translation>URL trackera:</translation>
    </message>
    <message>
        <source>Web seeds urls:</source>
        <translation>URL web seedov:</translation>
    </message>
    <message>
        <source>Comment:</source>
        <translation>Komentár:</translation>
    </message>
    <message>
        <source>Auto</source>
        <translation>Auto</translation>
    </message>
</context>
<context>
    <name>createtorrent</name>
    <message>
        <source>Select destination torrent file</source>
        <translation type="obsolete">Vybrať cieľový torrent súbor</translation>
    </message>
    <message>
        <source>Torrent Files</source>
        <translation type="obsolete">Torrent súbory</translation>
    </message>
    <message>
        <source>No input path set</source>
        <translation type="obsolete">Nebola zadaná vstupná cesta</translation>
    </message>
    <message>
        <source>Please type an input path first</source>
        <translation type="obsolete">Napíšte prosím najprv vstupnú cestu</translation>
    </message>
    <message>
        <source>Torrent creation</source>
        <translation type="obsolete">Vytvorenie torrentu</translation>
    </message>
    <message>
        <source>Torrent was created successfully:</source>
        <translation type="obsolete">Torrent bol úspešne vytvorený:</translation>
    </message>
    <message>
        <source>Select a folder to add to the torrent</source>
        <translation type="obsolete">Vyberte adresár, ktorý sa má pridať do torrentu</translation>
    </message>
    <message>
        <source>Please type an announce URL</source>
        <translation type="obsolete">Prosím, napíšte announce URL</translation>
    </message>
    <message>
        <source>Torrent creation was unsuccessful, reason: %1</source>
        <translation type="obsolete">Torrent nebol vytvorený, dôvod: %1</translation>
    </message>
    <message>
        <source>Announce URL:</source>
        <comment>Tracker URL</comment>
        <translation type="obsolete">Announce URL:</translation>
    </message>
    <message>
        <source>Please type a web seed url</source>
        <translation type="obsolete">Prosím, napíšte web seed URL</translation>
    </message>
    <message>
        <source>Web seed URL:</source>
        <translation type="obsolete">Web seed URL:</translation>
    </message>
    <message>
        <source>Select a file to add to the torrent</source>
        <translation type="obsolete">Vyberte súbor, ktorý sa má pridať do torrentu</translation>
    </message>
    <message>
        <source>Created torrent file is invalid. It won&apos;t be added to download list.</source>
        <translation type="obsolete">Vytvorený torrent je neplatný. Nebude pridaný do zoznamu sťahovaných.</translation>
    </message>
</context>
<context>
    <name>downloadFromURL</name>
    <message>
        <source>Download from urls</source>
        <translation>Stiahnuť z viacerých url</translation>
    </message>
    <message>
        <source>Download Torrents from URLs</source>
        <translation type="obsolete">Stiahnuť torrenty z viacerých URL</translation>
    </message>
    <message>
        <source>Only one URL per line</source>
        <translation type="obsolete">Iba jeden URL na riadok</translation>
    </message>
    <message>
        <source>Download</source>
        <translation>Stiahnuť</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Storno</translation>
    </message>
    <message>
        <source>No URL entered</source>
        <translation>Nebolo zadané URL</translation>
    </message>
    <message>
        <source>Please type at least one URL.</source>
        <translation>Prosím, napíšte aspoň jedno URL.</translation>
    </message>
    <message>
        <source>Add torrent links</source>
        <translation>Pridať odkazy na torrent</translation>
    </message>
    <message>
        <source>Both HTTP and Magnet links are supported</source>
        <translation>Sú podporované odkazy HTTP aj Magnet</translation>
    </message>
</context>
<context>
    <name>downloadThread</name>
    <message>
        <source>I/O Error</source>
        <translation type="obsolete">V/V Chyba</translation>
    </message>
    <message>
        <source>The remote host name was not found (invalid hostname)</source>
        <translation type="obsolete">Názov vzdialeného počítača nebol zistený (neplatný názov)</translation>
    </message>
    <message>
        <source>The operation was canceled</source>
        <translation type="obsolete">Operácia bola zrušená</translation>
    </message>
    <message>
        <source>The remote server closed the connection prematurely, before the entire reply was received and processed</source>
        <translation type="obsolete">Vzdialený server predčasne zatvoril spojenie predtým, než bola prijatá a spracovaná celá odpoveď</translation>
    </message>
    <message>
        <source>The connection to the remote server timed out</source>
        <translation type="obsolete">Čas spojenia so vzdialeným serverom vypršal</translation>
    </message>
    <message>
        <source>SSL/TLS handshake failed</source>
        <translation type="obsolete">SSL/TLS handshake zlyhal</translation>
    </message>
    <message>
        <source>The remote server refused the connection</source>
        <translation type="obsolete">Vzdialený server odmietol spojenie</translation>
    </message>
    <message>
        <source>The connection to the proxy server was refused</source>
        <translation type="obsolete">Spojenie s proxy serverom bolo odmietnuté</translation>
    </message>
    <message>
        <source>The proxy server closed the connection prematurely</source>
        <translation type="obsolete">Proxy server predčasne zatvoril spojenie</translation>
    </message>
    <message>
        <source>The proxy host name was not found</source>
        <translation type="obsolete">Názov proxy servera nebol nájdený</translation>
    </message>
    <message>
        <source>The connection to the proxy timed out or the proxy did not reply in time to the request sent</source>
        <translation type="obsolete">Čas spojenia s proxy serverom vypršal alebo proxy server neodpovedal včas na zaslanú požiadavku</translation>
    </message>
    <message>
        <source>The proxy requires authentication in order to honour the request but did not accept any credentials offered</source>
        <translation type="obsolete">Proxy vyžaduje autentifikáciu aby mohol splniť požiadavku, ale neprijal žiadne z ponúknutých prihlasovacích údajov</translation>
    </message>
    <message>
        <source>The access to the remote content was denied (401)</source>
        <translation type="obsolete">Prístup k vzdialenému obsahu bol zamietnutý (401)</translation>
    </message>
    <message>
        <source>The operation requested on the remote content is not permitted</source>
        <translation type="obsolete">Požadovaná operácia so vzdialeným obsahom nie je povolená</translation>
    </message>
    <message>
        <source>The remote content was not found at the server (404)</source>
        <translation type="obsolete">Vzdialený obsah nebol nájdený na serveri (404)</translation>
    </message>
    <message>
        <source>The remote server requires authentication to serve the content but the credentials provided were not accepted</source>
        <translation type="obsolete">Vzdialený server vyžaduje na poskytnutie obsahu autentifikáciu, , ale neprijal žiadne z ponúknutých prihlasovacích údajov</translation>
    </message>
    <message>
        <source>The Network Access API cannot honor the request because the protocol is not known</source>
        <translation type="obsolete">Network Access API neprijalo požiadavku, pretože nie je známy protokol</translation>
    </message>
    <message>
        <source>The requested operation is invalid for this protocol</source>
        <translation type="obsolete">Požadovaná operácia nie je platná pre tento protokol</translation>
    </message>
    <message>
        <source>An unknown network-related error was detected</source>
        <translation type="obsolete">Bola zistená neznáma chyba týkajúca sa siete</translation>
    </message>
    <message>
        <source>An unknown proxy-related error was detected</source>
        <translation type="obsolete">Bola zistená neznáma chyba týkajúca sa proxy</translation>
    </message>
    <message>
        <source>An unknown error related to the remote content was detected</source>
        <translation type="obsolete">Bola zistená neznáma chyba týkajúca sa vzdialeného obsahu</translation>
    </message>
    <message>
        <source>A breakdown in protocol was detected</source>
        <translation type="obsolete">Bola zistená porucha v protokole</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation type="obsolete">Neznáma chyba</translation>
    </message>
</context>
<context>
    <name>engineSelect</name>
    <message>
        <source>Search plugins</source>
        <translation>Zásuvné moduly vyhľadávania</translation>
    </message>
    <message>
        <source>Installed search engines:</source>
        <translation>Nainštalované vyhľadávače:</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Názov</translation>
    </message>
    <message>
        <source>Url</source>
        <translation>Url</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Zapnuté</translation>
    </message>
    <message>
        <source>Install a new one</source>
        <translation>Nainštalovať nový</translation>
    </message>
    <message>
        <source>Check for updates</source>
        <translation>Skontrolovať aktualizácie</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Zatvoriť</translation>
    </message>
    <message>
        <source>Enable</source>
        <translation type="obsolete">Zapnúť</translation>
    </message>
    <message>
        <source>Disable</source>
        <translation type="obsolete">Vypnúť</translation>
    </message>
    <message>
        <source>Uninstall</source>
        <translation>Odinštalovať</translation>
    </message>
    <message>
        <source>You can get new search engine plugins here: &lt;a href=&quot;http://plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</source>
        <translation>Nové zásuvné moduly vyhľadávačov nájdete tu: &lt;a href=&quot;http://plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</translation>
    </message>
</context>
<context>
    <name>engineSelectDlg</name>
    <message>
        <source>Uninstall warning</source>
        <translation>Upozornenie o odstránení</translation>
    </message>
    <message>
        <source>Some plugins could not be uninstalled because they are included in qBittorrent.
 Only the ones you added yourself can be uninstalled.
However, those plugins were disabled.</source>
        <translation>Niektoré zásuvné moduly nebolo možné odstrániť, pretože sú súčasťou aplikácie qBittorrent.
 Iba tie, ktoré ste sami pridali je možné odstrániť.
Tieto moduly však boli vypnuté.</translation>
    </message>
    <message>
        <source>Uninstall success</source>
        <translation>Odstránenie prebehlo úspešne</translation>
    </message>
    <message>
        <source>Select search plugins</source>
        <translation>Zvoliť zásuvné moduly vyhľadávačov</translation>
    </message>
    <message>
        <source>qBittorrent search plugins</source>
        <translation>Zásuvné moduly vyhľadávania qBittorrent</translation>
    </message>
    <message>
        <source>Search plugin install</source>
        <translation>Inštalácia zásuvného modulu vyhľadávača</translation>
    </message>
    <message>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <source>A more recent version of %1 search engine plugin is already installed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>Novšia verzia zásuvného modulu vyhľadávača %1 je už nainštalovaná.</translation>
    </message>
    <message>
        <source>Search plugin update</source>
        <translation>Aktualizácia zásuvného modulu vyhľadávača</translation>
    </message>
    <message>
        <source>Sorry, update server is temporarily unavailable.</source>
        <translation>Je mi ľúto, aktualizačný server je dočasne nedostupný.</translation>
    </message>
    <message>
        <source>All your plugins are already up to date.</source>
        <translation>Všetky vaše vyhľadávacie zásuvné moduly sú už aktuálne.</translation>
    </message>
    <message>
        <source>%1 search engine plugin could not be updated, keeping old version.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>Zásuvný modul vyhľadávača %1 nebolo možné aktualizovať, zachovávam starú verziu.</translation>
    </message>
    <message>
        <source>%1 search engine plugin could not be installed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>Zásuvný modul vyhľadávača %1 nebolo možné nainštalovať.</translation>
    </message>
    <message>
        <source>All selected plugins were uninstalled successfully</source>
        <translation>Všetky zvolené zásuvné moduly boli úspešne odinštalované</translation>
    </message>
    <message>
        <source>%1 search engine plugin was successfully updated.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>Zásuvný modul vyhľadávača %1 bol úspešne aktualizovaný.</translation>
    </message>
    <message>
        <source>%1 search engine plugin was successfully installed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>Zásuvný modul vyhľadávača %1 bol úspešne nainštalovaný.</translation>
    </message>
    <message>
        <source>Sorry, %1 search plugin install failed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>Je mi ľúto, aktualizácia zásuvného modulu vyhľadávača %1 zlyhala.</translation>
    </message>
    <message>
        <source>New search engine plugin URL</source>
        <translation>URL zásuvného modulu nového vyhľadávača</translation>
    </message>
    <message>
        <source>URL:</source>
        <translation>URL:</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Áno</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Nie</translation>
    </message>
</context>
<context>
    <name>misc</name>
    <message>
        <source>Unknown</source>
        <translation>Neznámy</translation>
    </message>
    <message>
        <source>B</source>
        <comment>bytes</comment>
        <translation>B</translation>
    </message>
    <message>
        <source>KiB</source>
        <comment>kibibytes (1024 bytes)</comment>
        <translation>KiB</translation>
    </message>
    <message>
        <source>MiB</source>
        <comment>mebibytes (1024 kibibytes)</comment>
        <translation>MiB</translation>
    </message>
    <message>
        <source>GiB</source>
        <comment>gibibytes (1024 mibibytes)</comment>
        <translation>GiB</translation>
    </message>
    <message>
        <source>TiB</source>
        <comment>tebibytes (1024 gibibytes)</comment>
        <translation>TiB</translation>
    </message>
    <message>
        <source>Unknown</source>
        <comment>Unknown (size)</comment>
        <translation>Neznáma</translation>
    </message>
    <message>
        <source>&lt; 1m</source>
        <comment>&lt; 1 minute</comment>
        <translation>&lt; 1m</translation>
    </message>
    <message>
        <source>%1m</source>
        <comment>e.g: 10minutes</comment>
        <translation>%1m</translation>
    </message>
    <message>
        <source>%1h %2m</source>
        <comment>e.g: 3hours 5minutes</comment>
        <translation>%1h %2m</translation>
    </message>
    <message>
        <source>%1d %2h</source>
        <comment>e.g: 2days 10hours</comment>
        <translation>%1d %2h</translation>
    </message>
    <message>
        <source>qBittorrent will shutdown the computer now because all downloads are complete.</source>
        <translation>qBittorrent teraz vypne počítač, pretože sťahovanie všetkých torrentov bolo dokončené.</translation>
    </message>
</context>
<context>
    <name>options_imp</name>
    <message>
        <source>Choose a save directory</source>
        <translation>Vyberte adresár, kde sa bude ukladať</translation>
    </message>
    <message>
        <source>Choose an ip filter file</source>
        <translation>Zvoliť súbor IP filtra</translation>
    </message>
    <message>
        <source>Filters</source>
        <translation>Filtre</translation>
    </message>
    <message>
        <source>Choose export directory</source>
        <translation>Vyberte adresár, kde sa bude exportovať</translation>
    </message>
    <message>
        <source>Add directory to scan</source>
        <translation>Vyberte adresár, ktorý sa bude prehliadať</translation>
    </message>
    <message>
        <source>Folder is already being watched.</source>
        <translation>Priečinok sa už sleduje.</translation>
    </message>
    <message>
        <source>Folder does not exist.</source>
        <translation>Priečinok neexistuje.</translation>
    </message>
    <message>
        <source>Folder is not readable.</source>
        <translation>Priečinok nemožno prečítať.</translation>
    </message>
    <message>
        <source>Failure</source>
        <translation>Zlyhanie</translation>
    </message>
    <message>
        <source>Failed to add Scan Folder &apos;%1&apos;: %2</source>
        <translation>Nepodarilo sa pridať priečinok na prehľadanie: „%1“: %2</translation>
    </message>
    <message>
        <source>Parsing error</source>
        <translation>Chyba pri spracovaní</translation>
    </message>
    <message>
        <source>Failed to parse the provided IP filter</source>
        <translation>Nepodarilo sa spracovať poskytnutý filter IP</translation>
    </message>
    <message>
        <source>Succesfully refreshed</source>
        <translation type="obsolete">Obnovenie prebehlo úspešne</translation>
    </message>
    <message>
        <source>Successfuly parsed the provided IP filter: %1 rules were applied.</source>
        <comment>%1 is a number</comment>
        <translation>Poskytnutý filter IP úspešne spracovaný: %1 pravidiel bolo použitých.</translation>
    </message>
    <message>
        <source>Successfully refreshed</source>
        <translation>Úspešne obnovené</translation>
    </message>
    <message>
        <source>Invalid key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This is not a valid SSL key.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid certificate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This is not a valid SSL certificate.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SSL Certificate (*.crt *.pem)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SSL Key (*.key *.pem)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>pluginSourceDlg</name>
    <message>
        <source>Plugin source</source>
        <translation>Zdroj zásuvného modulu</translation>
    </message>
    <message>
        <source>Search plugin source:</source>
        <translation>Zdroj zásuvného modulu vyhľadávača:</translation>
    </message>
    <message>
        <source>Local file</source>
        <translation>Lokálny súbor</translation>
    </message>
    <message>
        <source>Web link</source>
        <translation>Webový odkaz</translation>
    </message>
</context>
<context>
    <name>preview</name>
    <message>
        <source>Preview selection</source>
        <translation>Výber náhľadu</translation>
    </message>
    <message>
        <source>File preview</source>
        <translation>Náhľad súboru</translation>
    </message>
    <message>
        <source>The following files support previewing, &lt;br&gt;please select one of them:</source>
        <translation>Nasledujúce súbory podporujú náhľad, &lt;br&gt;prosím vyberte jeden z nich:</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Náhľad</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Storno</translation>
    </message>
</context>
<context>
    <name>previewSelect</name>
    <message>
        <source>Preview impossible</source>
        <translation type="obsolete">Náhľad nemožný</translation>
    </message>
    <message>
        <source>Sorry, we can&apos;t preview this file</source>
        <translation type="obsolete">Prepáčte, tento súbor sa nedá otvoriť ako náhľad</translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="obsolete">Názov</translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="obsolete">Veľkosť</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation type="obsolete">Priebeh</translation>
    </message>
</context>
<context>
    <name>search_engine</name>
    <message>
        <source>Search</source>
        <translation>Vyhľadávanie</translation>
    </message>
    <message>
        <source>Status:</source>
        <translation>Stav:</translation>
    </message>
    <message>
        <source>Stopped</source>
        <translation>Zastavený</translation>
    </message>
    <message>
        <source>Download</source>
        <translation>Stiahnuť</translation>
    </message>
    <message>
        <source>Search engines...</source>
        <translation>Vyhľadávače...</translation>
    </message>
    <message>
        <source>Go to description page</source>
        <translation>Prejsť na stránku popisu</translation>
    </message>
</context>
<context>
    <name>torrentAdditionDialog</name>
    <message>
        <source>Unable to decode torrent file:</source>
        <translation>Nemohol som dekódovať torrent súbor:</translation>
    </message>
    <message>
        <source>Choose save path</source>
        <translation>Zvoľte cestu pre uloženie</translation>
    </message>
    <message>
        <source>Empty save path</source>
        <translation>Prázdna cesta pre uloženie</translation>
    </message>
    <message>
        <source>Please enter a save path</source>
        <translation>Prosím, zadajte cestu pre uloženie</translation>
    </message>
    <message>
        <source>Save path creation error</source>
        <translation>Chyba pri vytváraní cesty pre uloženie</translation>
    </message>
    <message>
        <source>Could not create the save path</source>
        <translation>Nemohol som vytvoriť cestu pre uloženie</translation>
    </message>
    <message>
        <source>Invalid file selection</source>
        <translation>Neplatný výber súboru</translation>
    </message>
    <message>
        <source>You must select at least one file in the torrent</source>
        <translation>Musíte vybrať aspoň jeden súbor z torrentu</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Priorita</translation>
    </message>
    <message>
        <source>(%1 left after torrent download)</source>
        <comment>e.g. (100MiB left after torrent download)</comment>
        <translation>(po stiahnutí torrentu zostane %1)</translation>
    </message>
    <message>
        <source>(%1 more are required to download)</source>
        <comment>e.g. (100MiB more are required to download)</comment>
        <translation>(na stiahnutie treba ďalších %1)</translation>
    </message>
    <message>
        <source>Seeding mode error</source>
        <translation>Chyba režimu seedovania</translation>
    </message>
    <message>
        <source>You chose to skip file checking. However, local files do not seem to exist in the current destionation folder. Please disable this feature or update the save path.</source>
        <translation>Rozhodli ste sa preskočiť kontrolu súborov. Zdá sa však, že lokálne súbory neexistujú v aktuálnom cieľovom priečinku torrentu. Prosím, vypnite túto možnosť alebo aktualizujte cieľovú cestu.</translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation>Premenovať...</translation>
    </message>
    <message>
        <source>New name:</source>
        <translation>Nový názov:</translation>
    </message>
    <message>
        <source>The file could not be renamed</source>
        <translation>Nepodarilo sa premenovať súbor</translation>
    </message>
    <message>
        <source>This name is already in use in this folder. Please use a different name.</source>
        <translation>Tento názov už používa iná položka. Prosím, zvoľte iný názov.</translation>
    </message>
    <message>
        <source>The folder could not be renamed</source>
        <translation>Nepodarilo sa premenovať adresár</translation>
    </message>
    <message>
        <source>Rename the file</source>
        <translation>Premenovať súbor</translation>
    </message>
    <message>
        <source>Unable to decode magnet link:</source>
        <translation>Nepodarilo sa dekódovať odkaz Magnet:</translation>
    </message>
    <message>
        <source>Magnet Link</source>
        <translation>Odkaz Magnet</translation>
    </message>
    <message>
        <source>Invalid label name</source>
        <translation>Neplatný názov označenia</translation>
    </message>
    <message>
        <source>Please don&apos;t use any special characters in the label name.</source>
        <translation>Prosím, nepoužívajte v názve označenia špeciálne znaky.</translation>
    </message>
    <message>
        <source>This file name contains forbidden characters, please choose a different one.</source>
        <translation>Tento názov súboru obsahuje nepovolené znaky, preto zvoľte iný.</translation>
    </message>
</context>
</TS>
