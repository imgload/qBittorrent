<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="ca_ES">
<context>
    <name>AboutDlg</name>
    <message>
        <location filename="../about.ui" line="21"/>
        <source>About qBittorrent</source>
        <translation>Sobre qBittorrent</translation>
    </message>
    <message>
        <location filename="../about.ui" line="83"/>
        <source>About</source>
        <translation>Sobre</translation>
    </message>
    <message utf8="true">
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;A Bittorrent client programmed in C++, based on Qt4 toolkit &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;and libtorrent-rasterbar. &lt;br /&gt;&lt;br /&gt;Copyright ©2006-2010 Christophe Dumez&lt;br /&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Home Page:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://www.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;http://www.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Forum:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://forum.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;http://forum.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;IRC:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; #qbittorrent on Freenode&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;Un client Bittorrent programat en C++, segons Qt4 toolkit &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;and libtorrent-rasterbar. &lt;br /&gt;&lt;br /&gt;Copyright ©2006-2010 Christophe Dumez&lt;br /&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Pàgina Oficial:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://www.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;http://www.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Forum:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://forum.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;http://forum.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;IRC:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; #qbittorrent on Freenode&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../about.ui" line="134"/>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
    <message>
        <location filename="../about.ui" line="157"/>
        <source>Name:</source>
        <translation>Nom:</translation>
    </message>
    <message>
        <location filename="../about.ui" line="195"/>
        <source>Country:</source>
        <translation>Pais:</translation>
    </message>
    <message>
        <location filename="../about.ui" line="220"/>
        <source>E-mail:</source>
        <translation>E-Mail:</translation>
    </message>
    <message>
        <location filename="../about.ui" line="164"/>
        <source>Christophe Dumez</source>
        <translation>Christophe Dumez</translation>
    </message>
    <message utf8="true">
        <location filename="../about.ui" line="105"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;An advanced BitTorrent client programmed in C++, based on Qt4 toolkit and libtorrent-rasterbar. &lt;br /&gt;&lt;br /&gt;Copyright ©2006-2011 Christophe Dumez&lt;br /&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Home Page:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://www.qbittorrent.org&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans&apos;; text-decoration: underline; color:#0057ae;&quot;&gt;http://www.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Bug Tracker:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://bugs.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;http://bugs.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Forum:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://forum.qbittorrent.org&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans&apos;; text-decoration: underline; color:#0057ae;&quot;&gt;http://forum.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;IRC:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; #qbittorrent on Freenode&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;Client avançat Bittorrent programat en C++, based on Qt4 toolkit and libtorrent-rasterbar. &lt;br /&gt;&lt;br /&gt;Copyright ©2006-2011 Christophe Dumez&lt;br /&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Home Page:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://www.qbittorrent.org&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans&apos;; text-decoration: underline; color:#0057ae;&quot;&gt;http://www.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Bug Tracker:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://bugs.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;http://bugs.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Forum:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://forum.qbittorrent.org&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans&apos;; text-decoration: underline; color:#0057ae;&quot;&gt;http://forum.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;IRC:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; #qbittorrent on Freenode&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../about.ui" line="202"/>
        <source>France</source>
        <translation>França</translation>
    </message>
    <message>
        <location filename="../about.ui" line="264"/>
        <source>Translation</source>
        <translation>Traducció</translation>
    </message>
    <message>
        <location filename="../about.ui" line="281"/>
        <source>License</source>
        <translation>Llicència</translation>
    </message>
    <message>
        <location filename="../about.ui" line="54"/>
        <source>&lt;h3&gt;&lt;b&gt;qBittorrent&lt;/b&gt;&lt;/h3&gt;</source>
        <translation>&lt;h3&gt;&lt;b&gt;qBittorrent&lt;/b&gt;&lt;/h3&gt;</translation>
    </message>
    <message>
        <location filename="../about.ui" line="227"/>
        <source>chris@qbittorrent.org</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../about.ui" line="251"/>
        <source>Thanks to</source>
        <translation>Gràcies a</translation>
    </message>
</context>
<context>
    <name>AdvancedSettings</name>
    <message>
        <source>Property</source>
        <translation type="obsolete">Propietat</translation>
    </message>
    <message>
        <source>Value</source>
        <translation type="obsolete">Valor</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="160"/>
        <source>Disk write cache size</source>
        <translation>Mida cache del Disc</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="159"/>
        <source> MiB</source>
        <translation> MiB</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="165"/>
        <source>Outgoing ports (Min) [0: Disabled]</source>
        <translation>Ports de sortida (Min) [0: Desactivat]</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="170"/>
        <source>Outgoing ports (Max) [0: Disabled]</source>
        <translation>Ports de sortida (Max) [0: Desactivat]</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="176"/>
        <source>Recheck torrents on completion</source>
        <translation>Verificar Torrents completats</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="182"/>
        <source>Transfer list refresh interval</source>
        <translation>Interval de refresc de la llista de transferència</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="181"/>
        <source> ms</source>
        <comment> milliseconds</comment>
        <translation> ms</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="50"/>
        <source>Setting</source>
        <translation>Ajustaments</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="50"/>
        <source>Value</source>
        <comment>Value set for this setting</comment>
        <translation>Valor</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="185"/>
        <source>Resolve peer countries (GeoIP)</source>
        <translation>Mostrar Parells per Països (GeoIP)</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="188"/>
        <source>Resolve peer host names</source>
        <translation>Mostrar Parells per nom de Host</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="193"/>
        <source>Maximum number of half-open connections [0: Disabled]</source>
        <translation>Capacitat màxima de connexions obertes [0: Desactivat]</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="200"/>
        <source>Strict super seeding</source>
        <translation>Sembra super estricta</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="212"/>
        <source>Network Interface (requires restart)</source>
        <translation>Selecció de Xarxa (cal reiniciar)</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="240"/>
        <source>Exchange trackers with other peers</source>
        <translation>Intercanvi de parells amb altres trackers</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="202"/>
        <source>Any interface</source>
        <comment>i.e. Any network interface</comment>
        <translation>Qualsevol Xarxa</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="215"/>
        <source>IP Address to report to trackers (requires restart)</source>
        <translation>Adreça IP per a informe d&apos;incidències als trackers (cal reiniciar)</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="218"/>
        <source>Display program on-screen notifications</source>
        <translation>Visualització en pantalla de les notificacions</translation>
    </message>
    <message>
        <source>Display program notification balloons</source>
        <translation type="obsolete">Mostrar globus de notificació</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="221"/>
        <source>Enable embedded tracker</source>
        <translation>Habilitar integració de tracker</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="226"/>
        <source>Embedded tracker port</source>
        <translation>Port d&apos;integració de tracker</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="229"/>
        <source>Check for software updates</source>
        <translation>Comprovar si hi ha actualitzacions</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="233"/>
        <source>Use system icon theme</source>
        <translation>Utilitza icones del tema actual</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="237"/>
        <source>Confirm torrent deletion</source>
        <translation>Confirmeu la supressió del torrent</translation>
    </message>
    <message>
        <source>Display program notification baloons</source>
        <translation type="obsolete">Mostra globus de notificació</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="173"/>
        <source>Ignore transfer limits on local network</source>
        <translation>Ignora límits de transferència de la xarxa local</translation>
    </message>
    <message>
        <source>Include TCP/IP overhead in transfer limits</source>
        <translation type="obsolete">Incloure TCP / IP en els límits generals de transferència</translation>
    </message>
</context>
<context>
    <name>AutomatedRssDownloader</name>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="14"/>
        <source>Automated RSS Downloader</source>
        <translation>Automatitzar Descàrrega de canals RSS</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="26"/>
        <source>Enable the automated RSS downloader</source>
        <translation>Activar Descàrrega automatitzada de canals RSS</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="48"/>
        <source>Download rules</source>
        <translation>Regles de Descàrregues</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="123"/>
        <source>Rule definition</source>
        <translation>Definició de regles</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="138"/>
        <source>Must contain:</source>
        <translation>Ha de contenir:</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="180"/>
        <source>Must not contain:</source>
        <translation>No ha de contenir:</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="129"/>
        <source>Use regular expressions</source>
        <translation>Utilitza expressions regulars</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="355"/>
        <source>Import...</source>
        <translation>Importar...</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="362"/>
        <source>Export...</source>
        <translation>Exportar...</translation>
    </message>
    <message>
        <source>Save torrent to:</source>
        <translation type="obsolete">Guardar torrent a:</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="286"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="233"/>
        <source>Assign label:</source>
        <translation>Etiquetar com:</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="252"/>
        <source>Save to a different directory</source>
        <translation>Guardar en un directori diferent</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="264"/>
        <source>Save to:</source>
        <translation>Guardar en:</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="308"/>
        <source>Apply rule to feeds:</source>
        <translation>Aplicar regles als canals:</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="330"/>
        <source>Matching RSS articles</source>
        <translation>Coincidència de canals RSS</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="304"/>
        <source>New rule name</source>
        <translation>Nova regla</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="304"/>
        <source>Please type the name of the new download rule.</source>
        <translation>Si us plau, escriviu el nom de la nova regla a descàrrega.</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="308"/>
        <location filename="../rss/automatedrssdownloader.cpp" line="423"/>
        <source>Rule name conflict</source>
        <translation>Conflicte amb el nom de la regla</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="308"/>
        <location filename="../rss/automatedrssdownloader.cpp" line="423"/>
        <source>A rule with this name already exists, please choose another name.</source>
        <translation>Ja existena una regla amb aquest nom, si us plau, trieu un altre nom.</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="326"/>
        <source>Are you sure you want to remove the download rule named %1?</source>
        <translation>Segur que voleu eliminar la regla de transferència anomenada %1?</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="328"/>
        <source>Are you sure you want to remove the selected download rules?</source>
        <translation>Segur que voleu eliminar les normes de descàrrega seleccionada?</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="329"/>
        <source>Rule deletion confirmation</source>
        <translation>Confirmar eliminar regla</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="345"/>
        <source>Destination directory</source>
        <translation>Directori de destinació</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="353"/>
        <source>Invalid action</source>
        <translation>Acció no vàlida</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="353"/>
        <source>The list is empty, there is nothing to export.</source>
        <translation>La llista està buida, no hi ha res per exportar.</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="357"/>
        <source>Where would you like to save the list?</source>
        <translation>On li agradaria guardar la llista?</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="357"/>
        <source>Rules list (*.rssrules)</source>
        <translation>Llista de regles (*.rssrules)</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="362"/>
        <source>I/O Error</source>
        <translation>Error d&apos;Entrada/Sortida</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="362"/>
        <source>Failed to create the destination file</source>
        <translation>No s&apos;ha pogut crear l&apos;arxiu de destí</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="370"/>
        <source>Please point to the RSS download rules file</source>
        <translation>Si us plau, seleccioneu les normes de descàrrega de canals RSS</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="370"/>
        <source>Rules list (*.rssrules *.filters)</source>
        <translation>Llista de regles (*.rssrules *.filters)</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="374"/>
        <source>Import Error</source>
        <translation>Error al importar</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="374"/>
        <source>Failed to import the selected rules file</source>
        <translation>No s&apos;ha pogut importar el fitxer de la regla seleccionada</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="385"/>
        <source>Add new rule...</source>
        <translation>Afegeix nova regla...</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="391"/>
        <source>Delete rule</source>
        <translation>Eliminar regla</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="393"/>
        <source>Rename rule...</source>
        <translation>Canviar el nom de la regla...</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="395"/>
        <source>Delete selected rules</source>
        <translation>Eliminar regles seleccionades</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="419"/>
        <source>Rule renaming</source>
        <translation>Regla renombrada</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="419"/>
        <source>Please type the new rule name</source>
        <translation>Si us plau, escriviu el nom de la nova regla</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="521"/>
        <source>Regex mode: use Perl-like regular expressions</source>
        <translation>Mode Regex: utilitza Perl-like en expressions regulars</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="525"/>
        <source>Wildcard mode: you can use&lt;ul&gt;&lt;li&gt;? to match any single character&lt;/li&gt;&lt;li&gt;* to match zero or more of any characters&lt;/li&gt;&lt;li&gt;Whitespaces count as AND operators&lt;/li&gt;&lt;/ul&gt;</source>
        <translation>Ús de comodins: es pot usar&lt;ul&gt;&lt;li&gt;? perquè coincideixi amb qualsevol caràcter individual&lt;/li&gt;&lt;li&gt;* per fer coincidir zero o més dels caràcters&lt;/li&gt;&lt;li&gt; com Espais en blanc i&lt;/li&gt;&lt;/ul&gt; per al operadore AND</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="527"/>
        <source>Wildcard mode: you can use&lt;ul&gt;&lt;li&gt;? to match any single character&lt;/li&gt;&lt;li&gt;* to match zero or more of any characters&lt;/li&gt;&lt;li&gt;| is used as OR operator&lt;/li&gt;&lt;/ul&gt;</source>
        <translation>Ús de comodins: es pot usar&lt;ul&gt;&lt;li&gt;? perquè coincideixi amb qualsevol caràcter individual&lt;/li&gt;&lt;li&gt;* per fer coincidir zero o més dels caràcters&lt;/li&gt;&lt;li&gt; com Espais en blanc i&lt;/li&gt;&lt;/ul&gt; per al operadore OR</translation>
    </message>
</context>
<context>
    <name>Bittorrent</name>
    <message>
        <source>%1 reached the maximum ratio you set.</source>
        <translation type="obsolete">%1 va assolir el ratio màxim establert.</translation>
    </message>
    <message>
        <source>Removing torrent %1...</source>
        <translation type="obsolete">Extraient torrent %1...</translation>
    </message>
    <message>
        <source>Pausing torrent %1...</source>
        <translation type="obsolete">Torrent Pausat %1...</translation>
    </message>
    <message>
        <source>qBittorrent is bound to port: TCP/%1</source>
        <comment>e.g: qBittorrent is bound to port: 6881</comment>
        <translation type="obsolete">qBittorrent està usant el port: TCP/%1</translation>
    </message>
    <message>
        <source>UPnP support [ON]</source>
        <translation type="obsolete">Suport per a UPnP [Encesa]</translation>
    </message>
    <message>
        <source>UPnP support [OFF]</source>
        <translation type="obsolete">Suport per a UPnP [Apagat]</translation>
    </message>
    <message>
        <source>NAT-PMP support [ON]</source>
        <translation type="obsolete">Suport per a NAT-PMP [Encesa]</translation>
    </message>
    <message>
        <source>NAT-PMP support [OFF]</source>
        <translation type="obsolete">Suport per a NAT-PMP[Apagat]</translation>
    </message>
    <message>
        <source>HTTP user agent is %1</source>
        <translation type="obsolete">HTTP d&apos;usuari es %1</translation>
    </message>
    <message>
        <source>Using a disk cache size of %1 MiB</source>
        <translation type="obsolete">Mida cache del Disc %1 MiB</translation>
    </message>
    <message>
        <source>DHT support [ON], port: UDP/%1</source>
        <translation type="obsolete">Suport per a DHT [Encesa], port: UPD/%1</translation>
    </message>
    <message>
        <source>DHT support [OFF]</source>
        <translation type="obsolete">Suport per a DHT [Apagat]</translation>
    </message>
    <message>
        <source>PeX support [ON]</source>
        <translation type="obsolete">Suport per a PeX [Encesa]</translation>
    </message>
    <message>
        <source>PeX support [OFF]</source>
        <translation type="obsolete">Suport PeX [Apagat]</translation>
    </message>
    <message>
        <source>Restart is required to toggle PeX support</source>
        <translation type="obsolete">És necessari reiniciar per activar suport PeX</translation>
    </message>
    <message>
        <source>Local Peer Discovery [ON]</source>
        <translation type="obsolete">Estat local de Parells [Encesa]</translation>
    </message>
    <message>
        <source>Local Peer Discovery support [OFF]</source>
        <translation type="obsolete">Suport per a estat local de Parells [Apagat]</translation>
    </message>
    <message>
        <source>Encryption support [ON]</source>
        <translation type="obsolete">Suport per a encriptat [Encesa]</translation>
    </message>
    <message>
        <source>Encryption support [FORCED]</source>
        <translation type="obsolete">Suport per a encriptat [forçat]</translation>
    </message>
    <message>
        <source>Encryption support [OFF]</source>
        <translation type="obsolete">Suport per a encriptat [Apagat]</translation>
    </message>
    <message>
        <source>The Web UI is listening on port %1</source>
        <translation type="obsolete">Port d&apos;escolta d&apos;Interfície Usuari Web %1</translation>
    </message>
    <message>
        <source>Web User Interface Error - Unable to bind Web UI to port %1</source>
        <translation type="obsolete">Error interfície d&apos;Usuari Web - No es pot enllaçar al port %1</translation>
    </message>
    <message>
        <source>&apos;%1&apos; was removed from transfer list and hard disk.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation type="obsolete">&apos;%1&apos; Va ser eliminat de la llista de transferència i del disc.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; was removed from transfer list.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation type="obsolete">&apos;%1&apos; Va ser eliminat de la llista de transferència.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is not a valid magnet URI.</source>
        <translation type="obsolete">&apos;%1&apos; no és una URI vàlida.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is already in download list.</source>
        <comment>e.g: &apos;xxx.avi&apos; is already in download list.</comment>
        <translation type="obsolete">&apos;%1&apos; ja està en la llista de descàrregues.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; resumed. (fast resume)</source>
        <comment>&apos;/home/y/xxx.torrent&apos; was resumed. (fast resume)</comment>
        <translation type="obsolete">&apos;%1&apos; reiniciat. (reinici ràpid)</translation>
    </message>
    <message>
        <source>&apos;%1&apos; added to download list.</source>
        <comment>&apos;/home/y/xxx.torrent&apos; was added to download list.</comment>
        <translation type="obsolete">&apos;%1&apos; agregat a la llista de descàrregues.</translation>
    </message>
    <message>
        <source>Unable to decode torrent file: &apos;%1&apos;</source>
        <comment>e.g: Unable to decode torrent file: &apos;/home/y/xxx.torrent&apos;</comment>
        <translation type="obsolete">Impossible descodificar l&apos;arxiu torrent: &apos;%1&apos;</translation>
    </message>
    <message>
        <source>This file is either corrupted or this isn&apos;t a torrent.</source>
        <translation type="obsolete">Aquest arxiu pot ser corrupte, o no ser un torrent.</translation>
    </message>
    <message>
        <source>Note: new trackers were added to the existing torrent.</source>
        <translation type="obsolete">Nota: nous Trackers s&apos;han afegit al torrent existent.</translation>
    </message>
    <message>
        <source>Note: new URL seeds were added to the existing torrent.</source>
        <translation type="obsolete">Nota: noves llavors URL s&apos;han afegit al Torrent existent.</translation>
    </message>
    <message>
        <source>Error: The torrent %1 does not contain any file.</source>
        <translation type="obsolete">Error: aquest torrent %1 no conté cap fitxer.</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;was blocked due to your IP filter&lt;/i&gt;</source>
        <comment>x.y.z.w was blocked</comment>
        <translation type="obsolete">&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;va ser bloquejat a causa del filtre IP&lt;/i&gt;</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;was banned due to corrupt pieces&lt;/i&gt;</source>
        <comment>x.y.z.w was banned</comment>
        <translation type="obsolete">&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;Va ser bloquejat a causa de fragments corruptes&lt;/i&gt;</translation>
    </message>
    <message>
        <source>Recursive download of file %1 embedded in torrent %2</source>
        <comment>Recursive download of test.torrent embedded in torrent test2</comment>
        <translation type="obsolete">Descàrrega recursiva d&apos;arxiu %1 incrustada en Torrent %2</translation>
    </message>
    <message>
        <source>Unable to decode %1 torrent file.</source>
        <translation type="obsolete">No es pot descodificar %1 arxiu torrent.</translation>
    </message>
    <message>
        <source>UPnP/NAT-PMP: Port mapping failure, message: %1</source>
        <translation type="obsolete">UPnP/NAT-PMP: Va fallar el mapatge del port, missatge: %1</translation>
    </message>
    <message>
        <source>UPnP/NAT-PMP: Port mapping successful, message: %1</source>
        <translation type="obsolete">UPnP/NAT-PMP: Mapatge del port reeixit, missatge: %1</translation>
    </message>
    <message>
        <source>Fast resume data was rejected for torrent %1, checking again...</source>
        <translation type="obsolete">Es van negar les dades per a reinici ràpid del torrent: %1, verificant de nou... </translation>
    </message>
    <message>
        <source>Reason: %1</source>
        <translation type="obsolete">Raó: %1</translation>
    </message>
    <message>
        <source>Torrent name: %1</source>
        <translation type="obsolete">Nom del torrent: %1</translation>
    </message>
    <message>
        <source>Torrent size: %1</source>
        <translation type="obsolete">Mida del torrent: %1</translation>
    </message>
    <message>
        <source>Save path: %1</source>
        <translation type="obsolete">Guardar ruta: %1</translation>
    </message>
    <message>
        <source>The torrent was downloaded in %1.</source>
        <comment>The torrent was downloaded in 1 hour and 20 seconds</comment>
        <translation type="obsolete">El torrernt es va descarregar a %1.</translation>
    </message>
    <message>
        <source>Thank you for using qBittorrent.</source>
        <translation type="obsolete">Gràcies per utilitzar qBittorrent.</translation>
    </message>
    <message>
        <source>[qBittorrent] %1 has finished downloading</source>
        <translation type="obsolete">[qBittorrent] %1 s&apos;ha finalitzat les descàrregues</translation>
    </message>
    <message>
        <source>An I/O error occured, &apos;%1&apos; paused.</source>
        <translation type="obsolete">Error E/S ocorregut, &apos;%1&apos; pausat.</translation>
    </message>
    <message>
        <source>File sizes mismatch for torrent %1, pausing it.</source>
        <translation type="obsolete">La mida del fitxer no coincideix amb el torrent %1, pausat.</translation>
    </message>
    <message>
        <source>Url seed lookup failed for url: %1, message: %2</source>
        <translation type="obsolete">Va fallar la recerca de llavor per l&apos;Url: %1, missatge: %2</translation>
    </message>
    <message>
        <source>Downloading &apos;%1&apos;, please wait...</source>
        <comment>e.g: Downloading &apos;xxx.torrent&apos;, please wait...</comment>
        <translation type="obsolete">Descarregant &apos;%1&apos;, si us plau esperi...</translation>
    </message>
</context>
<context>
    <name>ConsoleDlg</name>
    <message>
        <source>qBittorrent log viewer</source>
        <translation type="obsolete">qBittorrent visor de registres</translation>
    </message>
    <message>
        <source>General</source>
        <translation type="obsolete">General</translation>
    </message>
    <message>
        <source>Blocked IPs</source>
        <translation type="obsolete">IPs bloquejades</translation>
    </message>
</context>
<context>
    <name>CookiesDlg</name>
    <message>
        <location filename="../rss/cookiesdlg.ui" line="14"/>
        <source>Cookies management</source>
        <translation>Administració de Cookies</translation>
    </message>
    <message>
        <location filename="../rss/cookiesdlg.ui" line="36"/>
        <source>Key</source>
        <extracomment>As in Key/Value pair</extracomment>
        <translation>Clau</translation>
    </message>
    <message>
        <location filename="../rss/cookiesdlg.ui" line="41"/>
        <source>Value</source>
        <extracomment>As in Key/Value pair</extracomment>
        <translation>Valor</translation>
    </message>
    <message>
        <location filename="../rss/cookiesdlg.cpp" line="48"/>
        <source>Common keys for cookies are : &apos;%1&apos;, &apos;%2&apos;.
You should get this information from your Web browser preferences.</source>
        <translation>Les Claus per a les Cookies són : &apos;%1&apos;, &apos;%2&apos; 
Podeu obtenir aquesta informació de les preferències del seu navegador web.</translation>
    </message>
</context>
<context>
    <name>DNSUpdater</name>
    <message>
        <location filename="../dnsupdater.cpp" line="178"/>
        <source>Your dynamic DNS was successfuly updated.</source>
        <translation>DNS dinàmica actualitzada amb èxit.</translation>
    </message>
    <message>
        <location filename="../dnsupdater.cpp" line="182"/>
        <source>Dynamic DNS error: The service is temporarily unavailable, it will be retried in 30 minutes.</source>
        <translation>Error de DNS dinàmica: El servei no està disponible temporalment, nou reintent en 30 minuts.</translation>
    </message>
    <message>
        <location filename="../dnsupdater.cpp" line="192"/>
        <source>Dynamic DNS error: hostname supplied does not exist under specified account.</source>
        <translation>Error de DNS dinàmica: el nom d&apos;amfitrió proporcionat no existeix en el compte especificat.</translation>
    </message>
    <message>
        <location filename="../dnsupdater.cpp" line="198"/>
        <source>Dynamic DNS error: Invalid username/password.</source>
        <translation>Error DNS dinàmica: nom d&apos;usuari/contrasenya no vàlides.</translation>
    </message>
    <message>
        <location filename="../dnsupdater.cpp" line="203"/>
        <source>Dynamic DNS error: qBittorrent was blacklisted by the service, please report a bug at http://bugs.qbittorrent.org.</source>
        <translation>Error de DNS dinàmica: qBittorrent ha estat inclòs en la Llista Negra, si us plau, informar d&apos;això a http://bugs.qbittorrent.org.</translation>
    </message>
    <message>
        <location filename="../dnsupdater.cpp" line="209"/>
        <source>Dynamic DNS error: %1 was returned by the service, please report a bug at http://bugs.qbittorrent.org.</source>
        <translation>Error de DNS dinàmica: %1 ha estat rebutjat pel servei, si us plau, informe d&apos;aquest error a http://bugs.qbittorrent.org.</translation>
    </message>
    <message>
        <location filename="../dnsupdater.cpp" line="215"/>
        <source>Dynamic DNS error: Your username was blocked due to abuse.</source>
        <translation>Error de DNS dinàmica: El seu nom d&apos;usuari va ser bloquejat a causa de excessos.</translation>
    </message>
    <message>
        <location filename="../dnsupdater.cpp" line="236"/>
        <source>Dynamic DNS error: supplied domain name is invalid.</source>
        <translation>Error de DNS dinàmica: nom de domini proporcionat no vàlid.</translation>
    </message>
    <message>
        <location filename="../dnsupdater.cpp" line="248"/>
        <source>Dynamic DNS error: supplied username is too short.</source>
        <translation>Error de DNS dinàmica: el nom d&apos;usuari subministrat és massa curt.</translation>
    </message>
    <message>
        <location filename="../dnsupdater.cpp" line="260"/>
        <source>Dynamic DNS error: supplied password is too short.</source>
        <translation>Error de DNS dinàmica: contrasenya proporcionada massa curta.</translation>
    </message>
</context>
<context>
    <name>DownloadThread</name>
    <message>
        <location filename="../downloadthread.cpp" line="98"/>
        <location filename="../downloadthread.cpp" line="102"/>
        <source>I/O Error</source>
        <translation>Error d&apos;Entrada/Sortida</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="209"/>
        <source>The remote host name was not found (invalid hostname)</source>
        <translation>El nom host no s&apos;ha trobat (nom host no vàlid)</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="211"/>
        <source>The operation was canceled</source>
        <translation>L&apos;operació va ser cancel-lada</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="213"/>
        <source>The remote server closed the connection prematurely, before the entire reply was received and processed</source>
        <translation>El servidor remot va tancar la connexió abans de temps, abans que fos rebut i processat</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="215"/>
        <source>The connection to the remote server timed out</source>
        <translation>Connexió amb el servidor remot fallida, Temps d&apos;espera esgotat</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="217"/>
        <source>SSL/TLS handshake failed</source>
        <translation>SSL/TLS handshake fallida</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="219"/>
        <source>The remote server refused the connection</source>
        <translation>El servidor remot va rebutjar la connexió</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="221"/>
        <source>The connection to the proxy server was refused</source>
        <translation>La connexió amb el servidor proxy va ser rebutjada</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="223"/>
        <source>The proxy server closed the connection prematurely</source>
        <translation>Connexió tancada abans de temps pel servidor proxy</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="225"/>
        <source>The proxy host name was not found</source>
        <translation>El nom host del proxy  no s&apos;ha trobat</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="227"/>
        <source>The connection to the proxy timed out or the proxy did not reply in time to the request sent</source>
        <translation>La connexió amb el servidor proxy  s&apos;ha esgotat, o el proxy no va respondre a temps a la sol-licitud enviada</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="229"/>
        <source>The proxy requires authentication in order to honour the request but did not accept any credentials offered</source>
        <translation>El proxy requereix autenticació a fi d&apos;atendre la sol-licitud, però no va acceptar les credencials que va oferir</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="231"/>
        <source>The access to the remote content was denied (401)</source>
        <translation>L&apos;accés al contingut remot ha estat rebutjat (401)</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="233"/>
        <source>The operation requested on the remote content is not permitted</source>
        <translation>L&apos;operació sol-licitada en el contingut remot no està permesa</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="235"/>
        <source>The remote content was not found at the server (404)</source>
        <translation>El contingut remot no es troba al servidor (404)</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="237"/>
        <source>The remote server requires authentication to serve the content but the credentials provided were not accepted</source>
        <translation>El servidor remot requereix autenticació per servir el contingut, però les credencials proporcionades no són correctes</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="239"/>
        <source>The Network Access API cannot honor the request because the protocol is not known</source>
        <translation>L&apos;accés a la xarxa de l&apos;API no pot complir amb la sol licitud pel fet que el protocol és desconegut</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="241"/>
        <source>The requested operation is invalid for this protocol</source>
        <translation>L&apos;operació sol-licitada no és vàlida per a aquest protocol</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="243"/>
        <source>An unknown network-related error was detected</source>
        <translation>Error de Xarxa desconegut</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="245"/>
        <source>An unknown proxy-related error was detected</source>
        <translation>Error de Proxy desconegut</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="247"/>
        <source>An unknown error related to the remote content was detected</source>
        <translation>Error desconegut al servidor remot</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="249"/>
        <source>A breakdown in protocol was detected</source>
        <translation>Error de protocol</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="251"/>
        <source>Unknown error</source>
        <translation>Error desconegut</translation>
    </message>
</context>
<context>
    <name>EventManager</name>
    <message>
        <location filename="../webui/eventmanager.cpp" line="73"/>
        <location filename="../webui/eventmanager.cpp" line="87"/>
        <source>Working</source>
        <translation>treballant</translation>
    </message>
    <message>
        <location filename="../webui/eventmanager.cpp" line="76"/>
        <source>Updating...</source>
        <translation>Actualizant...</translation>
    </message>
    <message>
        <location filename="../webui/eventmanager.cpp" line="79"/>
        <location filename="../webui/eventmanager.cpp" line="90"/>
        <source>Not working</source>
        <translation>Sense servei</translation>
    </message>
    <message>
        <location filename="../webui/eventmanager.cpp" line="81"/>
        <location filename="../webui/eventmanager.cpp" line="92"/>
        <source>Not contacted yet</source>
        <translation>No connectat encara</translation>
    </message>
    <message>
        <location filename="../webui/eventmanager.cpp" line="405"/>
        <location filename="../webui/eventmanager.cpp" line="406"/>
        <source>this session</source>
        <translation>aquesta sessió</translation>
    </message>
    <message>
        <location filename="../webui/eventmanager.cpp" line="410"/>
        <location filename="../webui/eventmanager.cpp" line="414"/>
        <source>/s</source>
        <comment>/second (i.e. per second)</comment>
        <translation></translation>
    </message>
    <message>
        <location filename="../webui/eventmanager.cpp" line="417"/>
        <source>Seeded for %1</source>
        <comment>e.g. Seeded for 3m10s</comment>
        <translation>Complet des de %1</translation>
    </message>
    <message>
        <location filename="../webui/eventmanager.cpp" line="420"/>
        <source>%1 max</source>
        <comment>e.g. 10 max</comment>
        <translation></translation>
    </message>
    <message>
        <location filename="../webui/eventmanager.cpp" line="499"/>
        <location filename="../webui/eventmanager.cpp" line="508"/>
        <source>%1/s</source>
        <comment>e.g. 120 KiB/s</comment>
        <translation></translation>
    </message>
</context>
<context>
    <name>ExecutionLog</name>
    <message>
        <source>Form</source>
        <translation type="obsolete">Formulari</translation>
    </message>
    <message>
        <location filename="../executionlog.ui" line="27"/>
        <source>General</source>
        <translation>General</translation>
    </message>
    <message>
        <location filename="../executionlog.ui" line="41"/>
        <source>Blocked IPs</source>
        <translation>IPs bloquejades</translation>
    </message>
</context>
<context>
    <name>FeedDownloader</name>
    <message>
        <source>RSS Feed downloader</source>
        <translation type="obsolete">Descarregant canal RSS</translation>
    </message>
    <message>
        <source>RSS feed:</source>
        <translation type="obsolete">Canal RSS:</translation>
    </message>
    <message>
        <source>Feed name</source>
        <translation type="obsolete">Nom del Canal</translation>
    </message>
    <message>
        <source>Automatically download torrents from this feed</source>
        <translation type="obsolete">Descarregar automàticament torrents des d&apos;aquest Canal</translation>
    </message>
    <message>
        <source>Download filters</source>
        <translation type="obsolete">Descarregar filtres</translation>
    </message>
    <message>
        <source>Filters:</source>
        <translation type="obsolete">Filtres:</translation>
    </message>
    <message>
        <source>Filter settings</source>
        <translation type="obsolete">Ajusts de filtres</translation>
    </message>
    <message>
        <source>Matches:</source>
        <translation type="obsolete">Concordances:</translation>
    </message>
    <message>
        <source>Does not match:</source>
        <translation type="obsolete">No coincideixen amb:</translation>
    </message>
    <message>
        <source>Destination folder:</source>
        <translation type="obsolete">Carpeta de destinació:</translation>
    </message>
    <message>
        <source>...</source>
        <translation type="obsolete">...</translation>
    </message>
    <message>
        <source>Filter testing</source>
        <translation type="obsolete">Verifican filtres</translation>
    </message>
    <message>
        <source>Torrent title:</source>
        <translation type="obsolete">Titol Torrent:</translation>
    </message>
    <message>
        <source>Result:</source>
        <translation type="obsolete">Resultad:</translation>
    </message>
    <message>
        <source>Test</source>
        <translation type="obsolete">Prova</translation>
    </message>
    <message>
        <source>Import...</source>
        <translation type="obsolete">Importar...</translation>
    </message>
    <message>
        <source>Export...</source>
        <translation type="obsolete">Exportar...</translation>
    </message>
    <message>
        <source>Rename filter</source>
        <translation type="obsolete">Rebatejar filtre</translation>
    </message>
    <message>
        <source>Remove filter</source>
        <translation type="obsolete">Esborrar filtre</translation>
    </message>
    <message>
        <source>Add filter</source>
        <translation type="obsolete">Agregar filtre</translation>
    </message>
</context>
<context>
    <name>FeedDownloaderDlg</name>
    <message>
        <source>New filter</source>
        <translation type="obsolete">Nou filtre</translation>
    </message>
    <message>
        <source>Please choose a name for this filter</source>
        <translation type="obsolete">Si us plau, elegeixi un nom per a aquest filtre</translation>
    </message>
    <message>
        <source>Filter name:</source>
        <translation type="obsolete">Nom del filtre:</translation>
    </message>
    <message>
        <source>Invalid filter name</source>
        <translation type="obsolete">Nom no valgut per al filtre</translation>
    </message>
    <message>
        <source>The filter name cannot be left empty.</source>
        <translation type="obsolete">El nom del filtre no pot quedar buid.</translation>
    </message>
    <message>
        <source>This filter name is already in use.</source>
        <translation type="obsolete">Aquest nom de filtre ja s&apos;està usant.</translation>
    </message>
    <message>
        <source>Choose save path</source>
        <translation type="obsolete">Seleccioni la ruta on guardar-lo</translation>
    </message>
    <message>
        <source>Filter testing error</source>
        <translation type="obsolete">Error en la verificació del filtre</translation>
    </message>
    <message>
        <source>Please specify a test torrent name.</source>
        <translation type="obsolete">Si us plau, especifiqui el nom del torrent a verificar.</translation>
    </message>
    <message>
        <source>matches</source>
        <translation type="obsolete">Conté</translation>
    </message>
    <message>
        <source>does not match</source>
        <translation type="obsolete">no conté</translation>
    </message>
    <message>
        <source>Select file to import</source>
        <translation type="obsolete">Seleccioni l&apos;arxiu a importar</translation>
    </message>
    <message>
        <source>Filters Files</source>
        <translation type="obsolete">Filtre d&apos;arxius</translation>
    </message>
    <message>
        <source>Import successful</source>
        <translation type="obsolete">Importació satisfactòria</translation>
    </message>
    <message>
        <source>Filters import was successful.</source>
        <translation type="obsolete">Filtres importats satisfactòriament.</translation>
    </message>
    <message>
        <source>Import failure</source>
        <translation type="obsolete">Importació fallida</translation>
    </message>
    <message>
        <source>Filters could not be imported due to an I/O error.</source>
        <translation type="obsolete">Els filtres no poden ser importats a causa d&apos;un Error d&apos;Entrada/Sortida.</translation>
    </message>
    <message>
        <source>Select destination file</source>
        <translation type="obsolete">Seleccioni la ruta de l&apos;arxiu</translation>
    </message>
    <message>
        <source>Export successful</source>
        <translation type="obsolete">Exportació satisfactòria</translation>
    </message>
    <message>
        <source>Filters export was successful.</source>
        <translation type="obsolete">Filtres exportats satisfactòriament.</translation>
    </message>
    <message>
        <source>Export failure</source>
        <translation type="obsolete">Exportació fallida</translation>
    </message>
    <message>
        <source>Filters could not be exported due to an I/O error.</source>
        <translation type="obsolete">Els filtres no poden ser exportats a causa d&apos;un Error d&apos;Entrada/Sortida.</translation>
    </message>
</context>
<context>
    <name>FeedList</name>
    <message>
        <source>Unread</source>
        <translation type="obsolete">No llegit</translation>
    </message>
</context>
<context>
    <name>FeedListWidget</name>
    <message>
        <location filename="../rss/feedlistwidget.cpp" line="41"/>
        <source>RSS feeds</source>
        <translation>Canals RSS</translation>
    </message>
    <message>
        <location filename="../rss/feedlistwidget.cpp" line="43"/>
        <source>Unread</source>
        <translation>No llegits</translation>
    </message>
</context>
<context>
    <name>GUI</name>
    <message>
        <source>Open Torrent Files</source>
        <translation type="obsolete">Obrir arxius Torrent</translation>
    </message>
    <message>
        <source>Torrent Files</source>
        <translation type="obsolete">Arxius Torrent</translation>
    </message>
    <message>
        <source>qBittorrent</source>
        <translation type="obsolete">qBittorrent</translation>
    </message>
    <message>
        <source>Transfers</source>
        <translation type="obsolete">Transferint</translation>
    </message>
    <message>
        <source>qBittorrent %1</source>
        <comment>e.g: qBittorrent v0.x</comment>
        <translation type="obsolete">qBittorrent %1</translation>
    </message>
    <message>
        <source>DL speed: %1 KiB/s</source>
        <comment>e.g: Download speed: 10 KiB/s</comment>
        <translation type="obsolete">Vel. de Baixada: %1 KiB/s</translation>
    </message>
    <message>
        <source>UP speed: %1 KiB/s</source>
        <comment>e.g: Upload speed: 10 KiB/s</comment>
        <translation type="obsolete">Vel. de Pujada: %1 KiB/s</translation>
    </message>
    <message>
        <source>%1 has finished downloading.</source>
        <comment>e.g: xxx.avi has finished downloading.</comment>
        <translation type="obsolete">%1 ha acabat de descarregar-se.</translation>
    </message>
    <message>
        <source>I/O Error</source>
        <comment>i.e: Input/Output Error</comment>
        <translation type="obsolete">Error d&apos;Entrada/Sortida</translation>
    </message>
    <message>
        <source>Search</source>
        <translation type="obsolete">Buscar</translation>
    </message>
    <message>
        <source>Torrent file association</source>
        <translation type="obsolete">Associació d&apos;arxius Torrent</translation>
    </message>
    <message>
        <source>Set the password...</source>
        <translation type="obsolete">Definint la contrasenya...</translation>
    </message>
    <message>
        <source>qBittorrent is not the default application to open torrent files or Magnet links.
Do you want to associate qBittorrent to torrent files and Magnet links?</source>
        <translation type="obsolete">qBittorrent no és l&apos;aplicació per defecte per obrir arxius Torrent o enllaços Magnet.
¿Vol que qBittorrent sigui el programa per defecte per gestionar aquests arxius?</translation>
    </message>
    <message>
        <source>Password update</source>
        <translation type="obsolete">Actualització de contrasenya</translation>
    </message>
    <message>
        <source>The UI lock password has been successfully updated</source>
        <translation type="obsolete">La contrasenya de bloqueig de qBittorrent s&apos;ha actualitzat correctament</translation>
    </message>
    <message>
        <source>RSS</source>
        <translation type="obsolete">RSS</translation>
    </message>
    <message>
        <source>Transfers (%1)</source>
        <translation type="obsolete">Transferències (%1)</translation>
    </message>
    <message>
        <source>Download completion</source>
        <translation type="obsolete">Descàrrega completada</translation>
    </message>
    <message>
        <source>An I/O error occured for torrent %1.
 Reason: %2</source>
        <comment>e.g: An error occured for torrent xxx.avi.
 Reason: disk is full.</comment>
        <translation type="obsolete">Es va produir un Error d&apos;Entrada/Sortida, torrent %1.
Raó: %2</translation>
    </message>
    <message>
        <source>Alt+2</source>
        <comment>shortcut to switch to third tab</comment>
        <translation type="obsolete">Alt+2</translation>
    </message>
    <message>
        <source>Alt+3</source>
        <comment>shortcut to switch to fourth tab</comment>
        <translation type="obsolete">Alt+3</translation>
    </message>
    <message>
        <source>Recursive download confirmation</source>
        <translation type="obsolete">Confirmació descàrregues recursives</translation>
    </message>
    <message>
        <source>The torrent %1 contains torrent files, do you want to proceed with their download?</source>
        <translation type="obsolete">Aquest torrent %1 conté arxius torrent, vol seguir endavant amb la seva descàrrega?</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation type="obsolete">Sí</translation>
    </message>
    <message>
        <source>No</source>
        <translation type="obsolete">No</translation>
    </message>
    <message>
        <source>Never</source>
        <translation type="obsolete">Mai</translation>
    </message>
    <message>
        <source>Global Upload Speed Limit</source>
        <translation type="obsolete">Límit global de Pujada</translation>
    </message>
    <message>
        <source>Global Download Speed Limit</source>
        <translation type="obsolete">Límit global de Baixada</translation>
    </message>
    <message>
        <source>A newer version is available</source>
        <translation type="obsolete">Hi ha una nova versió disponible</translation>
    </message>
    <message>
        <source>A newer version of qBittorrent is available on Sourceforge.
Would you like to update qBittorrent to version %1?</source>
        <translation type="obsolete">Hi ha disponible una versió més recent de qBittorrent a Sourceforge.
¿Desitja actualitzar qBittorrent a la versión %1?</translation>
    </message>
    <message>
        <source>Impossible to update qBittorrent</source>
        <translation type="obsolete">Ha estat impossible actualitzar qBittorrent</translation>
    </message>
    <message>
        <source>qBittorrent failed to update, reason: %1</source>
        <translation type="obsolete">qBittorrent no va poder actualitzar-se, per la següent raó: %1</translation>
    </message>
    <message>
        <source>UI lock password</source>
        <translation type="obsolete">Contrasenya de bloqueig</translation>
    </message>
    <message>
        <source>Please type the UI lock password:</source>
        <translation type="obsolete">Si us plau, escrigui la contrasenya de bloqueig:</translation>
    </message>
    <message>
        <source>Invalid password</source>
        <translation type="obsolete">Contrasenya no vàlida</translation>
    </message>
    <message>
        <source>The password is invalid</source>
        <translation type="obsolete">La contrasenya no és vàlida</translation>
    </message>
    <message>
        <source>Exiting qBittorrent</source>
        <translation type="obsolete">Tancant qBittorrent</translation>
    </message>
    <message>
        <source>Always</source>
        <translation type="obsolete">Sempre</translation>
    </message>
    <message>
        <source>qBittorrent %1 (Down: %2/s, Up: %3/s)</source>
        <comment>%1 is qBittorrent version</comment>
        <translation type="obsolete">qBittorrent %1 (Baixada: %2/s, Pujada: %3/s)</translation>
    </message>
    <message>
        <source>Alt+1</source>
        <comment>shortcut to switch to first tab</comment>
        <translation type="obsolete">Alt+1</translation>
    </message>
    <message>
        <source>Url download error</source>
        <translation type="obsolete">Error de descàrrega d&apos;Url</translation>
    </message>
    <message>
        <source>Couldn&apos;t download file at url: %1, reason: %2.</source>
        <translation type="obsolete">No es va poder descarregar l&apos;arxiu en la url: %1, raó: %2.</translation>
    </message>
    <message>
        <source>Ctrl+F</source>
        <comment>shortcut to switch to search tab</comment>
        <translation type="obsolete">Ctrl + F</translation>
    </message>
    <message>
        <source>Some files are currently transferring.
Are you sure you want to quit qBittorrent?</source>
        <translation type="obsolete">Alguns arxius encara estan transferint.
Està segur que vol sortir?</translation>
    </message>
    <message>
        <source>Options were saved successfully.</source>
        <translation type="obsolete">Opcions guardades correctament.</translation>
    </message>
</context>
<context>
    <name>GeoIP</name>
    <message>
        <source>France</source>
        <translation type="obsolete">França</translation>
    </message>
    <message>
        <source>Saudi Arabia</source>
        <translation type="obsolete">Aràbia Saudi</translation>
    </message>
</context>
<context>
    <name>HeadlessLoader</name>
    <message>
        <location filename="../headlessloader.h" line="54"/>
        <source>Information</source>
        <translation>Informació</translation>
    </message>
    <message>
        <location filename="../headlessloader.h" line="55"/>
        <source>To control qBittorrent, access the Web UI at http://localhost:%1</source>
        <translation>Control qBittorrent, accés a interfície d&apos;usuari Web a http://localhost:%1</translation>
    </message>
    <message>
        <location filename="../headlessloader.h" line="56"/>
        <source>The Web UI administrator user name is: %1</source>
        <translation>Nom d&apos;usuari de l&apos;administrador Web: %1</translation>
    </message>
    <message>
        <location filename="../headlessloader.h" line="59"/>
        <source>The Web UI administrator password is still the default one: %1</source>
        <translation>La contrasenya de l&apos;administrador d&apos;interfície d&apos;usuari web continua sent per defecto:%1 </translation>
    </message>
    <message>
        <location filename="../headlessloader.h" line="60"/>
        <source>This is a security risk, please consider changing your password from program preferences.</source>
        <translation>Això és un risc de seguretat, si us plau consideri canviar la seva contrasenya de les preferències del programa.</translation>
    </message>
</context>
<context>
    <name>HttpConnection</name>
    <message>
        <location filename="../webui/httpconnection.cpp" line="150"/>
        <source>Your IP address has been banned after too many failed authentication attempts.</source>
        <translation>Després de molts intents de connexió, sembla ser que la teva direcció IP  ha estat restringida.</translation>
    </message>
    <message>
        <location filename="../webui/httpconnection.cpp" line="345"/>
        <source>D: %1/s - T: %2</source>
        <comment>Download speed: x KiB/s - Transferred: x MiB</comment>
        <translation>Baixada: %1/s - Total: %2</translation>
    </message>
    <message>
        <location filename="../webui/httpconnection.cpp" line="346"/>
        <source>U: %1/s - T: %2</source>
        <comment>Upload speed: x KiB/s - Transferred: x MiB</comment>
        <translation>Pujada: %1/s - Total: %2</translation>
    </message>
</context>
<context>
    <name>HttpServer</name>
    <message>
        <location filename="../webui/httpserver.cpp" line="120"/>
        <source>File</source>
        <translation>Arxiu</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="121"/>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="122"/>
        <source>Help</source>
        <translation>Ajuda</translation>
    </message>
    <message>
        <source>Delete from HD</source>
        <translation type="obsolete">Esborrar del disc</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="123"/>
        <source>Download Torrents from their URL or Magnet link</source>
        <translation>Descarregar Torrents des d&apos;URL o Enllaç (Link)</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="124"/>
        <source>Only one link per line</source>
        <translation>Només un enllaç (Link) per línia</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="125"/>
        <source>Download local torrent</source>
        <translation>Descarregar torrent local</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="126"/>
        <source>Torrent files were correctly added to download list.</source>
        <translation>Els arxius torrents es van afegir correctament a la llista de descàrrega.</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="127"/>
        <source>Point to torrent file</source>
        <translation>Indiqui un arxiu torrent</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="128"/>
        <source>Download</source>
        <translation>Descarregar</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="129"/>
        <source>Are you sure you want to delete the selected torrents from the transfer list and hard disk?</source>
        <translation>Està segur que vols esborrar els torrents seleccionats de la llista de transferència i del disc?</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="130"/>
        <source>Download rate limit must be greater than 0 or disabled.</source>
        <translation>El límit de la taxa de descàrrega ha de ser major que 0 o estar inhabilitat.</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="131"/>
        <source>Upload rate limit must be greater than 0 or disabled.</source>
        <translation>El límit de la taxa de pujada ha de ser major que 0 o estar inhabilitat.</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="132"/>
        <source>Maximum number of connections limit must be greater than 0 or disabled.</source>
        <translation>El nombre màxim del limiti de connexions ha de ser major que 0 o estar inhabilitat.</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="133"/>
        <source>Maximum number of connections per torrent limit must be greater than 0 or disabled.</source>
        <translation>El nombre màxim del limiti de connexions per torrent ha de ser major que 0 o estar inhabilitat.</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="134"/>
        <source>Maximum number of upload slots per torrent limit must be greater than 0 or disabled.</source>
        <translation>El nombre màxim de pujades de slots per torrent ha de ser major que 0 o estar inhabilitat.</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="135"/>
        <source>Unable to save program preferences, qBittorrent is probably unreachable.</source>
        <translation>No es pot guardar les preferències del programa, qbittorrent  probablement no és accessible.</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="136"/>
        <source>Language</source>
        <translation>Idioma</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="137"/>
        <source>Downloaded</source>
        <comment>Is the file downloaded or not?</comment>
        <translation>Baixat</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="138"/>
        <source>The port used for incoming connections must be greater than 1024 and less than 65535.</source>
        <translation>El port utilitzat per a connexions entrants ha de ser major de 1024 i menor de 65535.</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="139"/>
        <source>The port used for the Web UI must be greater than 1024 and less than 65535.</source>
        <translation>El port utilitzat per a la Interfície d&apos;Usuari Web ha de ser major de 1024 i menor de 65535.</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="140"/>
        <source>The Web UI username must be at least 3 characters long.</source>
        <translation>El nom d&apos;Interfície d&apos;Usuari web ha de ser d&apos;almenys 3 caràcters.</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="141"/>
        <source>The Web UI password must be at least 3 characters long.</source>
        <translation>La contrasenya d&apos;Interfície d&apos;Usuari Web ha de ser d&apos;almenys 3 caràcters.</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="142"/>
        <source>Save</source>
        <translation>Guardar</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="143"/>
        <source>qBittorrent client is not reachable</source>
        <translation>El client qBittorrent no és accessible</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="144"/>
        <source>HTTP Server</source>
        <translation>Servidor HTTP</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="145"/>
        <source>The following parameters are supported:</source>
        <translation>Els següents paràmetres són compatibles:</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="146"/>
        <source>Torrent path</source>
        <translation>Ruta torrent</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="147"/>
        <source>Torrent name</source>
        <translation>Nom torrent</translation>
    </message>
</context>
<context>
    <name>LegalNotice</name>
    <message>
        <location filename="../main.cpp" line="93"/>
        <source>Legal Notice</source>
        <translation>Avís Legal</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="94"/>
        <location filename="../main.cpp" line="105"/>
        <source>qBittorrent is a file sharing program. When you run a torrent, its data will be made available to others by means of upload. Any content you share is your sole responsibility.

No further notices will be issued.</source>
        <translation>qBittorrent és un programa per compartir arxius. Quan s&apos;executa un torrent, les seves dades es posaran a disposició dels altres per mitjà de pujada. I, sens dubte, qualsevol contingut que vostè comparteix és sota la seva responsabilitat.

Probablement això és una cosa que ja sabia, així que no li dirà cap altra vegada. </translation>
    </message>
    <message>
        <location filename="../main.cpp" line="95"/>
        <source>Press %1 key to accept and continue...</source>
        <translation>Premi qualsevol tecla per acceptar i continuar...</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="106"/>
        <source>Legal notice</source>
        <translation>Avís Legal</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="107"/>
        <source>Cancel</source>
        <translation>Cancel-lar</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="108"/>
        <source>I Agree</source>
        <translation>Estic d&apos;acord</translation>
    </message>
</context>
<context>
    <name>LineEdit</name>
    <message>
        <location filename="../lineedit/src/lineedit.cpp" line="30"/>
        <source>Clear the text</source>
        <translation>Esborrar el text</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="37"/>
        <source>&amp;Edit</source>
        <translation>&amp;Editar</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="60"/>
        <source>&amp;Tools</source>
        <translation>E&amp;ines</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="79"/>
        <source>&amp;File</source>
        <translation>&amp;Axiu</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="50"/>
        <source>&amp;Help</source>
        <translation>A&amp;yuda</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="88"/>
        <source>&amp;View</source>
        <translation>&amp;Veure</translation>
    </message>
    <message>
        <source>&amp;Add File...</source>
        <translation type="obsolete">&amp;Afegir arxius...</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation type="obsolete">&amp;Sortir</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="148"/>
        <source>&amp;Options...</source>
        <translation>&amp;Opcions...</translation>
    </message>
    <message>
        <source>Add &amp;URL...</source>
        <translation type="obsolete">Afegir &amp;URL...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="187"/>
        <source>Torrent &amp;creator</source>
        <translation>Crear &amp;Torrent</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="197"/>
        <source>Set upload limit...</source>
        <translation>Límit de Pujada...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="202"/>
        <source>Set download limit...</source>
        <translation>Límit de Baixada...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="153"/>
        <source>&amp;About</source>
        <translation>&amp;Sobre</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="163"/>
        <source>&amp;Pause</source>
        <translation>&amp;Pausar</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="168"/>
        <source>&amp;Delete</source>
        <translation>&amp;Esborrar</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="319"/>
        <source>P&amp;ause All</source>
        <translation>Pa&amp;usar Totes</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="158"/>
        <source>&amp;Resume</source>
        <translation>&amp;Reprendre</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="135"/>
        <source>&amp;Add torrent file...</source>
        <translation>&amp;Afegeix arxiu torrent...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="140"/>
        <location filename="../mainwindow.ui" line="143"/>
        <source>Exit</source>
        <translation>Sortir</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="314"/>
        <source>R&amp;esume All</source>
        <translation>R&amp;eprende Tot</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="177"/>
        <source>Visit &amp;Website</source>
        <translation>Visitar el meu lloc &amp;Web</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="64"/>
        <source>Auto-Shutdown on downloads completion</source>
        <translation>Tancar quan es completin les descàrregues</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="182"/>
        <source>Add &amp;link to torrent...</source>
        <translation>Afegeix &amp;enllaç torrent...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="192"/>
        <source>Report a &amp;bug</source>
        <translation>Comunicar un &amp;bug</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="207"/>
        <source>&amp;Documentation</source>
        <translation>&amp;Documentasió</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="212"/>
        <source>Set global download limit...</source>
        <translation>Límit global de Baixada...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="217"/>
        <source>Set global upload limit...</source>
        <translation>Límit global de Pujada...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="338"/>
        <source>Exit qBittorrent</source>
        <translation>Tancant qBittorrent</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="346"/>
        <source>Suspend system</source>
        <translation>Suspendre sistema</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="354"/>
        <source>Shutdown system</source>
        <translation>Tancar sistema</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="362"/>
        <source>Disabled</source>
        <translation>Deshabilitat</translation>
    </message>
    <message>
        <source>&amp;Log viewer...</source>
        <translation type="obsolete">Visor &amp;d&apos;registres...</translation>
    </message>
    <message>
        <source>Log viewer</source>
        <translation type="obsolete">Visor d&apos;registres</translation>
    </message>
    <message>
        <source>Shutdown computer when downloads complete</source>
        <translation type="obsolete">Tancar l&apos;equip en finalitzar les descàrregues</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="287"/>
        <location filename="../mainwindow.ui" line="290"/>
        <source>Lock qBittorrent</source>
        <translation>Bloca qBittorrent</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="293"/>
        <source>Ctrl+L</source>
        <translation>Ctrl+L</translation>
    </message>
    <message>
        <source>Shutdown qBittorrent when downloads complete</source>
        <translation type="obsolete">Apagar qBittorrent quan la descàrrega sigui completa</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="298"/>
        <source>Import existing torrent...</source>
        <translation>Importa torrent existent...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="301"/>
        <source>Import torrent...</source>
        <translation>Importar torrent...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="306"/>
        <source>Donate money</source>
        <translation>Donar</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="309"/>
        <source>If you like qBittorrent, please donate!</source>
        <translation>Si li agrada qBittorrent, si us plau feu una donació!</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="327"/>
        <source>Execution &amp;Log</source>
        <translation>Execució &amp;Log</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="330"/>
        <location filename="../mainwindow.cpp" line="1327"/>
        <source>Execution Log</source>
        <translation>Execució Log</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="241"/>
        <location filename="../mainwindow.ui" line="244"/>
        <source>Alternative speed limits</source>
        <translation>Límits de velocitat alternativa</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="274"/>
        <source>&amp;RSS reader</source>
        <translation>&amp;Lector RSS</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="282"/>
        <source>Search &amp;engine</source>
        <translation>&amp;Motor de cerca</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="252"/>
        <source>Top &amp;tool bar</source>
        <translation>Barra d&apos;eines &amp;superior</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="255"/>
        <source>Display top tool bar</source>
        <translation>Mostrar barra d&apos;eines superior</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="263"/>
        <source>&amp;Speed in title bar</source>
        <translation>&amp;Velocitat a la barra</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="266"/>
        <source>Show transfer speed in title bar</source>
        <translation>Mostra velocitat a la barra de títol</translation>
    </message>
    <message>
        <source>Preview file</source>
        <translation type="obsolete">Previsualitzar arxiu</translation>
    </message>
    <message>
        <source>Clear log</source>
        <translation type="obsolete">Netejar registre</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="222"/>
        <source>Decrease priority</source>
        <translation>Disminuir prioritat</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="230"/>
        <source>Increase priority</source>
        <translation>Incrementar prioritat</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="103"/>
        <location filename="../mainwindow.cpp" line="1251"/>
        <source>qBittorrent %1</source>
        <comment>e.g: qBittorrent v0.x</comment>
        <translation>qBittorrent %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="140"/>
        <source>Set the password...</source>
        <translation>Definint la contrasenya...</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="174"/>
        <source>Transfers</source>
        <translation>Transferint</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="287"/>
        <source>Torrent file association</source>
        <translation>Associació d&apos;arxius Torrent</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="288"/>
        <source>qBittorrent is not the default application to open torrent files or Magnet links.
Do you want to associate qBittorrent to torrent files and Magnet links?</source>
        <translation>qBittorrent no és l&apos;aplicació per defecte per obrir arxius Torrent o enllaços Magnet.
¿Vol que qBittorrent sigui el programa per defecte per gestionar aquests arxius?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="381"/>
        <location filename="../mainwindow.cpp" line="401"/>
        <location filename="../mainwindow.cpp" line="651"/>
        <source>UI lock password</source>
        <translation>Contrasenya de bloqueig</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="381"/>
        <location filename="../mainwindow.cpp" line="401"/>
        <location filename="../mainwindow.cpp" line="651"/>
        <source>Please type the UI lock password:</source>
        <translation>Si us plau, escrigui la contrasenya de bloqueig:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="385"/>
        <source>The password should contain at least 3 characters</source>
        <translation>Com a mínim la contrasenya ha de tenir 3 caràcters</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="391"/>
        <source>Password update</source>
        <translation>Actualització de contrasenya</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="391"/>
        <source>The UI lock password has been successfully updated</source>
        <translation>La contrasenya de bloqueig de qBittorrent s&apos;ha actualitzat correctament</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="417"/>
        <source>RSS</source>
        <translation>RSS</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="432"/>
        <source>Search</source>
        <translation>Cerca</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="442"/>
        <source>Transfers (%1)</source>
        <translation>Transferències (%1)</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="513"/>
        <source>Download completion</source>
        <translation>Descàrrega completada</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="513"/>
        <source>%1 has finished downloading.</source>
        <comment>e.g: xxx.avi has finished downloading.</comment>
        <translation>%1 ha acabat de descarregar-se.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="519"/>
        <source>I/O Error</source>
        <comment>i.e: Input/Output Error</comment>
        <translation>Error d&apos;Entrada/Sortida</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="519"/>
        <source>An I/O error occured for torrent %1.
 Reason: %2</source>
        <comment>e.g: An error occured for torrent xxx.avi.
 Reason: disk is full.</comment>
        <translation>Es va produir un Error d&apos;Entrada/Sortida, torrent %1.
Raó: %2</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="526"/>
        <source>Alt+1</source>
        <comment>shortcut to switch to first tab</comment>
        <translation>Alt+1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="528"/>
        <source>Alt+2</source>
        <comment>shortcut to switch to third tab</comment>
        <translation>Alt+2</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="530"/>
        <source>Ctrl+F</source>
        <comment>shortcut to switch to search tab</comment>
        <translation>Ctrl+F</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="532"/>
        <source>Alt+3</source>
        <comment>shortcut to switch to fourth tab</comment>
        <translation>Alt+3</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="572"/>
        <source>Recursive download confirmation</source>
        <translation>Confirmació descàrregues recursives</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="572"/>
        <source>The torrent %1 contains torrent files, do you want to proceed with their download?</source>
        <translation>Aquest torrent %1 conté arxius torrent, vol seguir endavant amb la seva descàrrega?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="573"/>
        <location filename="../mainwindow.cpp" line="744"/>
        <source>Yes</source>
        <translation>Sí</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="574"/>
        <location filename="../mainwindow.cpp" line="743"/>
        <source>No</source>
        <translation>No</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="575"/>
        <source>Never</source>
        <translation>Mai</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="589"/>
        <source>Url download error</source>
        <translation>Error de descàrrega d&apos;Url</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="589"/>
        <source>Couldn&apos;t download file at url: %1, reason: %2.</source>
        <translation>No es va poder descarregar l&apos;arxiu en la url: %1, raó: %2.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="600"/>
        <source>Global Upload Speed Limit</source>
        <translation>Velocitat límit global de pujada</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="619"/>
        <source>Global Download Speed Limit</source>
        <translation>Velocitat límit global de descàrrega</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="385"/>
        <location filename="../mainwindow.cpp" line="664"/>
        <source>Invalid password</source>
        <translation>Contrasenya no vàlida</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="664"/>
        <source>The password is invalid</source>
        <translation>La contrasenya no és vàlida</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="740"/>
        <source>Exiting qBittorrent</source>
        <translation>Tancant qBittorrent</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="741"/>
        <source>Some files are currently transferring.
Are you sure you want to quit qBittorrent?</source>
        <translation>Alguns arxius encara estan transferint.
Està segur que vol sortir?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="745"/>
        <source>Always</source>
        <translation>Sempre</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="903"/>
        <source>Open Torrent Files</source>
        <translation>Obrir arxius Torrent</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="904"/>
        <source>Torrent Files</source>
        <translation>Arxius Torrent</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="983"/>
        <source>Options were saved successfully.</source>
        <translation>Opcions guardades correctament.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1092"/>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1095"/>
        <location filename="../mainwindow.cpp" line="1102"/>
        <source>DL speed: %1 KiB/s</source>
        <comment>e.g: Download speed: 10 KiB/s</comment>
        <translation>Vel. de Baixada: %1 KiB/s</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1098"/>
        <location filename="../mainwindow.cpp" line="1104"/>
        <source>UP speed: %1 KiB/s</source>
        <comment>e.g: Upload speed: 10 KiB/s</comment>
        <translation>Vel. de Pujada: %1 KiB/s</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1109"/>
        <source>qBittorrent %1 (Down: %2/s, Up: %3/s)</source>
        <comment>%1 is qBittorrent version</comment>
        <translation>qBittorrent %1 (Baixada: %2/s, Pujada: %3/s)</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1289"/>
        <source>A newer version is available</source>
        <translation>Hi ha una nova versió disponible</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1290"/>
        <source>A newer version of qBittorrent is available on Sourceforge.
Would you like to update qBittorrent to version %1?</source>
        <translation>Hi ha disponible una versió més recent de qBittorrent a Sourceforge.
¿Desitja actualitzar qBittorrent a la versión %1?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1305"/>
        <source>Impossible to update qBittorrent</source>
        <translation>Ha estat impossible actualitzar qBittorrent</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1305"/>
        <source>qBittorrent failed to update, reason: %1</source>
        <translation>qBittorrent no va poder actualitzar-se, per la següent raó: %1</translation>
    </message>
</context>
<context>
    <name>PeerAdditionDlg</name>
    <message>
        <location filename="../properties/peeraddition.h" line="94"/>
        <source>Invalid IP</source>
        <translation>IP invàlida</translation>
    </message>
    <message>
        <location filename="../properties/peeraddition.h" line="95"/>
        <source>The IP you provided is invalid.</source>
        <translation>L&apos;IP facilitada no és vàlida.</translation>
    </message>
</context>
<context>
    <name>PeerListDelegate</name>
    <message>
        <location filename="../properties/peerlistdelegate.h" line="64"/>
        <source>/s</source>
        <comment>/second (i.e. per second)</comment>
        <translation>/s</translation>
    </message>
</context>
<context>
    <name>PeerListWidget</name>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="61"/>
        <source>IP</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="62"/>
        <source>Connection</source>
        <translation>Connexió</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="63"/>
        <source>Client</source>
        <comment>i.e.: Client application</comment>
        <translation>Client</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="64"/>
        <source>Progress</source>
        <comment>i.e: % downloaded</comment>
        <translation>Progrés</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="65"/>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Velocitat de Baixada</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="66"/>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Velocitat de Pujada</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="67"/>
        <source>Downloaded</source>
        <comment>i.e: total data downloaded</comment>
        <translation>Descarregat</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="68"/>
        <source>Uploaded</source>
        <comment>i.e: total data uploaded</comment>
        <translation>Pujat</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="139"/>
        <source>Add a new peer...</source>
        <translation>Afegir nou Parell...</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="148"/>
        <source>Copy IP</source>
        <translation>Copiar IP</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="150"/>
        <source>Limit download rate...</source>
        <translation>Taxa límit de Baixada...</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="151"/>
        <source>Limit upload rate...</source>
        <translation>Taxa límit de Pujada...</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="153"/>
        <source>Ban peer permanently</source>
        <translation>Prohibició permanent de Parells</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="164"/>
        <location filename="../properties/peerlistwidget.cpp" line="166"/>
        <source>Peer addition</source>
        <translation>Incorporar Parell</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="164"/>
        <source>The peer was added to this torrent.</source>
        <translation>Els parells es van agregar al torrent.</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="166"/>
        <source>The peer could not be added to this torrent.</source>
        <translation>Els parells no siguin poguts ser agregats al torrent.</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="196"/>
        <source>Are you sure? -- qBittorrent</source>
        <translation>Està segur? -- qBittorrent</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="196"/>
        <source>Are you sure you want to ban permanently the selected peers?</source>
        <translation>Segur que desitja prohibir-li la compartició permanent de Parells?</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="197"/>
        <source>&amp;Yes</source>
        <translation>&amp;Sí</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="197"/>
        <source>&amp;No</source>
        <translation>&amp;No</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="202"/>
        <source>Manually banning peer %1...</source>
        <translation>Prohibir manualment els Parells %1...</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="221"/>
        <source>Upload rate limiting</source>
        <translation>Límit taxa de pujada</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="249"/>
        <source>Download rate limiting</source>
        <translation>Límit taxa de baixada</translation>
    </message>
</context>
<context>
    <name>Preferences</name>
    <message>
        <source>UI</source>
        <extracomment>User Interface</extracomment>
        <translation type="obsolete">IU</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="93"/>
        <source>Downloads</source>
        <translation>Baixats</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="104"/>
        <source>Connection</source>
        <translation>Connexió</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="115"/>
        <source>Speed</source>
        <translation>Velocitat</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="134"/>
        <source>Web UI</source>
        <translation>IU Web</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="145"/>
        <source>Advanced</source>
        <translation>Avançat</translation>
    </message>
    <message>
        <source>Language:</source>
        <translation type="obsolete">Idioma:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="219"/>
        <source>(Requires restart)</source>
        <translation>(Es necessita reiniciar qBittorrent)</translation>
    </message>
    <message>
        <source>Visual style:</source>
        <translation type="obsolete">Estil Visual:</translation>
    </message>
    <message>
        <source>Transfer list</source>
        <translation type="obsolete">Llista de Transferència</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="253"/>
        <source>Use alternating row colors</source>
        <extracomment>In transfer list, one every two rows will have grey background.</extracomment>
        <translation>Usar colors alterns en la llista de Transferència</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="301"/>
        <location filename="../preferences/options.ui" line="327"/>
        <source>Start / Stop Torrent</source>
        <translation>Iniciar / Aturar Torrent</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="311"/>
        <location filename="../preferences/options.ui" line="337"/>
        <source>No action</source>
        <translation>Sense acció</translation>
    </message>
    <message>
        <source>File system</source>
        <translation type="obsolete">Opcions sobre arxius del Sistema</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="762"/>
        <source>Copy .torrent files to:</source>
        <translation>Copiar arxius. Torrent a:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="918"/>
        <source>The following parameters are supported:
&lt;ul&gt;
&lt;li&gt;%f: Torrent path&lt;/li&gt;
&lt;li&gt;%n: Torrent name&lt;/li&gt;
&lt;/ul&gt;</source>
        <translation>Els següents paràmetres són compatibles:
&lt;ul&gt;
&lt;li&gt;%f: Torrent ruta&lt;/li&gt;
&lt;li&gt;%n: Torrent nom&lt;/li&gt;
&lt;/ul&gt;</translation>
    </message>
    <message>
        <source>Torrent queueing</source>
        <translation type="obsolete">Gestió de Cues</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1980"/>
        <source>Maximum active downloads:</source>
        <translation>Màxim d&apos;arxius Baixant:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2000"/>
        <source>Maximum active uploads:</source>
        <translation>Màxim d&apos;arxius Pujant:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2020"/>
        <source>Maximum active torrents:</source>
        <translation>Màxim d&apos;arxius Torrents:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="504"/>
        <source>When adding a torrent</source>
        <translation>En afegir un torrent</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="20"/>
        <location filename="../preferences/options.ui" line="1504"/>
        <source>Options</source>
        <translation>Opcions</translation>
    </message>
    <message>
        <source>User Interface</source>
        <translation type="obsolete">Interfície d&apos;usuari</translation>
    </message>
    <message>
        <source>Visual Appearance</source>
        <translation type="obsolete">Aparença Visual</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="269"/>
        <source>Action on double-click</source>
        <translation>Acció a realitzar amb un Doble-click</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="284"/>
        <source>Downloading torrents:</source>
        <translation>Torrents Descarregant:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="306"/>
        <location filename="../preferences/options.ui" line="332"/>
        <source>Open destination folder</source>
        <translation>Obrir carpeta destí</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="319"/>
        <source>Completed torrents:</source>
        <translation>Torrents Completats:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="351"/>
        <source>Desktop</source>
        <translation>Escriptori</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="357"/>
        <source>Show splash screen on start up</source>
        <translation>Mostra pantalla de benvinguda en iniciar</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="367"/>
        <source>Start qBittorrent minimized</source>
        <translation>Iniciar qBittorrent minimitzat</translation>
    </message>
    <message>
        <source>Show qBittorrent icon in notification area</source>
        <translation type="obsolete">Mostra icona de qBittorrent en l&apos;àrea de notificació</translation>
    </message>
    <message>
        <source>Use monochrome system tray icon (requires restart)</source>
        <translation type="obsolete">Utilitza icona monocromàtic a la safata del sistema (cal reinicar)</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="393"/>
        <source>Minimize qBittorrent to notification area</source>
        <translation>Minimitzar qBittorrent en l&apos;àrea de notificació</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="403"/>
        <source>Close qBittorrent to notification area</source>
        <comment>i.e: The systray tray icon will still be visible when closing the main window.</comment>
        <translation>En tancar qBittorrent deixeu actiu en l&apos;àrea de notificació</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="412"/>
        <source>Tray icon style:</source>
        <translation>Estil de la icona al panell:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="420"/>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="425"/>
        <source>Monochrome (Dark theme)</source>
        <translation>Monochrome (Dark theme)</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="430"/>
        <source>Monochrome (Light theme)</source>
        <translation>Monochrome (Light theme)</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="374"/>
        <source>Ask for program exit confirmation</source>
        <translation>Demanar confirmació per sortir del programa</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="190"/>
        <source>User Interface Language:</source>
        <translation>Llenguatge de la interfície:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="247"/>
        <source>Transfer List</source>
        <translation>Llista de Transferència</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="384"/>
        <source>Show qBittorrent in notification area</source>
        <translation>Mostra qBittorrent en l&apos;àrea de notificació</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="446"/>
        <source>Power Management</source>
        <translation>Administració d&apos;energia</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="452"/>
        <source>Inhibit system sleep when torrents are active</source>
        <translation>Desactivar la suspensió de l&apos;equip quan encara queden torrents actius</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="513"/>
        <source>Display torrent content and some options</source>
        <translation>Mostrar el contingut del Torrent i opcions</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="523"/>
        <source>Do not start the download automatically</source>
        <comment>The torrent will be added to download list in pause state</comment>
        <translation>No iniciar la descàrrega de forma automàtica</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="539"/>
        <source>Hard Disk</source>
        <translation>Disc Dur</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="548"/>
        <source>Save files to location:</source>
        <translation>Guardar els arxius en la seva ubicació:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="596"/>
        <source>Append the label of the torrent to the save path</source>
        <translation>Afegir l&apos;etiqueta del torrent a la ruta on es guarda</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="606"/>
        <source>Pre-allocate disk space for all files</source>
        <translation>Pre-assignar espai al disc per a tots els arxius</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="613"/>
        <source>Keep incomplete torrents in:</source>
        <translation>Mantenir Torrents incomplets a:</translation>
    </message>
    <message>
        <source>Append .!qB extension to incomplete files&apos; names</source>
        <translation type="obsolete">Afegir l&apos;extensió.!qB als noms dels arxius incomplets</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="666"/>
        <source>Automatically add torrents from:</source>
        <translation>Carregar automàticament arxius Torrents des de:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="719"/>
        <source>Add folder...</source>
        <translation>Afegeix carpeta...</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="818"/>
        <source>Email notification upon download completion</source>
        <translation>Avisa&apos;m per correu electrònic de la finalització de les descàrregues</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="832"/>
        <source>Destination email:</source>
        <translation>Adreça de correu electrònic:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="842"/>
        <source>SMTP server:</source>
        <translation>Servidor SMTP:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="891"/>
        <source>This server requires a secure connection (SSL)</source>
        <translation>El servidor requereix una connexió segura (SSL)</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="903"/>
        <source>Run an external program on torrent completion</source>
        <translation>Executar un programa extern en acabar el torrent</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1241"/>
        <source>Otherwise, the proxy server is only used for tracker connections</source>
        <translation>Per contra, el servidor proxy s&apos;utilitzarà només per les connexions tracker</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1244"/>
        <source>Use proxy for peer connections</source>
        <translation>Utilitza proxy per a les connexions entre parells</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1402"/>
        <source>Global Rate Limits</source>
        <translation>Límits globals de Ràtio</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1520"/>
        <source>Apply rate limit to uTP connections</source>
        <translation>Aplicar límit de ràtio per a connexions uTP</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1527"/>
        <source>Apply rate limit to transport overhead</source>
        <translation>Aplicar límit de ràtio per transport sobrecarregat</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1540"/>
        <source>Alternative Global Rate Limits</source>
        <translation>Límits de Ràtio Global alternatiu</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1646"/>
        <source>Schedule the use of alternative rate limits</source>
        <translation>Programar l&apos;ús de límits de ràtio alternativa</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2249"/>
        <source>Use HTTPS instead of HTTP</source>
        <translation>Utilitza HTTPS en lloc de HTTP</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2292"/>
        <source>Import SSL Certificate</source>
        <translation>Importació de certificats SSL</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2345"/>
        <source>Import SSL Key</source>
        <translation>Importar clau SSL</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2280"/>
        <source>Certificate:</source>
        <translation>Certificat:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2333"/>
        <source>Key:</source>
        <translation>Clau:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2367"/>
        <source>&lt;a href=http://httpd.apache.org/docs/2.1/ssl/ssl_faq.html#aboutcerts&gt;Information about certificates&lt;/a&gt;</source>
        <translation>&lt;a href=http://httpd.apache.org/docs/2.1/ssl/ssl_faq.html#aboutcerts&gt;Informació sobre els certificats&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2436"/>
        <source>Update my dynamic domain name</source>
        <translation>Actualitzar el meu nom de domini dinàmic</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2448"/>
        <source>Service:</source>
        <translation>Servei:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2471"/>
        <source>Register</source>
        <translation>Registre</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2480"/>
        <source>Domain name:</source>
        <translation>Nom de domini:</translation>
    </message>
    <message>
        <source>Use %f to pass the torrent path in parameters</source>
        <translation type="obsolete">Utilitzeu %f per a passar el torrent la ruta dels paràmetres</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1010"/>
        <source>Use UPnP / NAT-PMP port forwarding from my router</source>
        <translation>Utilitza UPnP / NAT-PMP reenviament de ports del router</translation>
    </message>
    <message>
        <source>Proxy server</source>
        <translation type="obsolete">Servidor Proxy</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1357"/>
        <source>Reload the filter</source>
        <translation>Actualització del filtre</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1510"/>
        <source>Enable bandwidth management (uTP)</source>
        <translation>Habilitar gestió d&apos;ample de banda (uTP)</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1814"/>
        <source>Privacy</source>
        <translation>Privacitat</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1820"/>
        <source>Enable DHT (decentralized network) to find more peers</source>
        <translation>Activar DHT (xarxa descentralitzada) per trobar més parells</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1832"/>
        <source>Use a different port for DHT and BitTorrent</source>
        <translation>Utilitza difrentes port per DHT i BitTorrent</translation>
    </message>
    <message utf8="true">
        <location filename="../preferences/options.ui" line="1893"/>
        <source>Exchange peers with compatible Bittorrent clients (µTorrent, Vuze, ...)</source>
        <translation>Intercanviar parells amb clients Bittorrent compatibles (μTorrent, Vuze,...)</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1896"/>
        <source>Enable Peer Exchange (PeX) to find more peers</source>
        <translation>Habilitar intercanvi de parells (PEX) per trobar més parells</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1909"/>
        <source>Enable Local Peer Discovery to find more peers</source>
        <translation>Habilitar Trobat Local de Pares per trobar més parells</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1921"/>
        <source>Encryption mode:</source>
        <translation>Mode de xifrat:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1929"/>
        <source>Prefer encryption</source>
        <translation>Preferència de xifrat</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1934"/>
        <source>Require encryption</source>
        <translation>Necessiten xifrat</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1939"/>
        <source>Disable encryption</source>
        <translation>Deshabilitar xifrat</translation>
    </message>
    <message>
        <source>Share ratio limiting</source>
        <translation type="obsolete">Límit ratio compartició</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2093"/>
        <source>Seed torrents until their ratio reaches</source>
        <translation>Ratio compartició de llavors Torrent</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2125"/>
        <source>then</source>
        <translation>després</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2136"/>
        <source>Pause them</source>
        <translation>Pausar</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2141"/>
        <source>Remove them</source>
        <translation>Esborrar</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2190"/>
        <source>Enable Web User Interface (Remote control)</source>
        <translation>Habilitar interfície Web d&apos;usuari (Control remot)</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2239"/>
        <source>Use UPnP / NAT-PMP to forward the port from my router</source>
        <translation>Utilitza UPnP / NAT-PMP per transmetre al port del meu router</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2412"/>
        <source>Bypass authentication for localhost</source>
        <translation>Eludir la autenticació per localhost</translation>
    </message>
    <message>
        <source>Listening port</source>
        <translation type="obsolete">Port d&apos;escolta</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="968"/>
        <source>Port used for incoming connections:</source>
        <translation>Port utilitzat per a connexions entrants:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="988"/>
        <source>Random</source>
        <translation>Aleatori</translation>
    </message>
    <message>
        <source>Enable UPnP port mapping</source>
        <translation type="obsolete">Habilitar mapatge de ports UPnP</translation>
    </message>
    <message>
        <source>Enable NAT-PMP port mapping</source>
        <translation type="obsolete">Habilitar mapatge de ports NAT-PMP</translation>
    </message>
    <message>
        <source>Connections limit</source>
        <translation type="obsolete">Límit de connexions</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1031"/>
        <source>Global maximum number of connections:</source>
        <translation>Nombre global màxim de connexions:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1057"/>
        <source>Maximum number of connections per torrent:</source>
        <translation>Nombre màxim de connexions per torrent:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1080"/>
        <source>Maximum number of upload slots per torrent:</source>
        <translation>Nombre màxim de slots de pujada per torrent:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1420"/>
        <location filename="../preferences/options.ui" line="1575"/>
        <source>Upload:</source>
        <translation>Pujada:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1456"/>
        <location filename="../preferences/options.ui" line="1602"/>
        <source>Download:</source>
        <translation>Baixada:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1449"/>
        <location filename="../preferences/options.ui" line="1482"/>
        <location filename="../preferences/options.ui" line="1595"/>
        <location filename="../preferences/options.ui" line="1622"/>
        <source>KiB/s</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="79"/>
        <location filename="../preferences/options.ui" line="82"/>
        <source>Behavior</source>
        <translation>Comportament</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="123"/>
        <source>BitTorrent</source>
        <translation>Bittorrent</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="182"/>
        <source>Language</source>
        <translation>Idioma</translation>
    </message>
    <message>
        <source>Global speed limits</source>
        <translation type="obsolete">Límits de velocitat global</translation>
    </message>
    <message>
        <source>Alternative global speed limits</source>
        <translation type="obsolete">Límits de velocitat global alternativa</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1687"/>
        <source>to</source>
        <extracomment>time1 to time2</extracomment>
        <translation>a</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1739"/>
        <source>Every day</source>
        <translation>Tots</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1744"/>
        <source>Week days</source>
        <translation>Dies laborals</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1749"/>
        <source>Week ends</source>
        <translation>Caps de setmana</translation>
    </message>
    <message>
        <source>Bittorrent features</source>
        <translation type="obsolete">Característiques de Bittorrent</translation>
    </message>
    <message>
        <source>Enable DHT network (decentralized)</source>
        <translation type="obsolete">Habilitar xarxa DHT (descentralitzada)</translation>
    </message>
    <message>
        <source>Use a different port for DHT and Bittorrent</source>
        <translation type="obsolete">Utilitzar un port diferent per a la DHT i Bittorrent</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1852"/>
        <source>DHT port:</source>
        <translation>Port DHT:</translation>
    </message>
    <message>
        <source>Enable Peer Exchange / PeX (requires restart)</source>
        <translation type="obsolete">Activar intercanvi de Parells / PeX (és necessari reiniciar qBittorrent)</translation>
    </message>
    <message>
        <source>Enable Local Peer Discovery</source>
        <translation type="obsolete">Habilitar la font de recerca local de Parells</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation type="obsolete">Habilitat</translation>
    </message>
    <message>
        <source>Forced</source>
        <translation type="obsolete">Forçat</translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation type="obsolete">Deshabilitat</translation>
    </message>
    <message>
        <source>HTTP Communications (trackers, Web seeds, search engine)</source>
        <translation type="obsolete">Comunicacions HTTP (Trackers, Llavors de Web, Motors de Cerca)</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1187"/>
        <source>Host:</source>
        <translation></translation>
    </message>
    <message>
        <source>Peer Communications</source>
        <translation type="obsolete">Comunicacions Parelles</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1166"/>
        <source>SOCKS4</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1153"/>
        <source>Type:</source>
        <translation>Tipus:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="729"/>
        <source>Remove folder</source>
        <translation>Esborrar carpeta</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="960"/>
        <source>Listening Port</source>
        <translation>Port d&apos;escolta</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1025"/>
        <source>Connections Limits</source>
        <translation>Límits de connexió</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1145"/>
        <source>Proxy Server</source>
        <translation>Servidor Proxy</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1316"/>
        <source>IP Filtering</source>
        <translation>filtrat IP</translation>
    </message>
    <message>
        <source>Schedule the use of alternative speed limits</source>
        <translation type="obsolete">Calendari per utilització dels límits de velocitat alternativa</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1663"/>
        <source>from</source>
        <extracomment>from (time1 to time2)</extracomment>
        <translation>des de</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1731"/>
        <source>When:</source>
        <translation>Quan:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1906"/>
        <source>Look for peers on your local network</source>
        <translation>Podeu cercar parells a la teva xarxa local</translation>
    </message>
    <message>
        <source>Protocol encryption:</source>
        <translation type="obsolete">Protocol d&apos;encriptació:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1161"/>
        <source>(None)</source>
        <translation>(Cap)</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1176"/>
        <source>HTTP</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1213"/>
        <location filename="../preferences/options.ui" line="2204"/>
        <source>Port:</source>
        <translation>Port:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="852"/>
        <location filename="../preferences/options.ui" line="1254"/>
        <location filename="../preferences/options.ui" line="2380"/>
        <source>Authentication</source>
        <translation>Autentificació</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="659"/>
        <source>Append .!qB extension to incomplete files</source>
        <translation>Afegeix .!qB com extensió per als fitxers incomplets</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="864"/>
        <location filename="../preferences/options.ui" line="1268"/>
        <location filename="../preferences/options.ui" line="2419"/>
        <location filename="../preferences/options.ui" line="2494"/>
        <source>Username:</source>
        <translation>Nom d&apos;Usuari:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="874"/>
        <location filename="../preferences/options.ui" line="1288"/>
        <location filename="../preferences/options.ui" line="2426"/>
        <location filename="../preferences/options.ui" line="2508"/>
        <source>Password:</source>
        <translation>Contrasenya:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1171"/>
        <source>SOCKS5</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1328"/>
        <source>Filter path (.dat, .p2p, .p2b):</source>
        <translation>Ruta de Filtre (.dat, .p2p, .p2b):</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1965"/>
        <source>Torrent Queueing</source>
        <translation>Torrents en Cua</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2082"/>
        <source>Share Ratio Limiting</source>
        <translation>Límit de Ràtio de Compartició</translation>
    </message>
    <message>
        <source>HTTP Server</source>
        <translation type="obsolete">Servidor HTTP</translation>
    </message>
</context>
<context>
    <name>PreviewSelect</name>
    <message>
        <location filename="../previewselect.cpp" line="48"/>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <location filename="../previewselect.cpp" line="49"/>
        <source>Size</source>
        <translation>Mida</translation>
    </message>
    <message>
        <location filename="../previewselect.cpp" line="50"/>
        <source>Progress</source>
        <translation>Progrés</translation>
    </message>
    <message>
        <location filename="../previewselect.cpp" line="75"/>
        <location filename="../previewselect.cpp" line="110"/>
        <location filename="../previewselect.cpp" line="116"/>
        <source>Preview impossible</source>
        <translation>Impossible vista prèvia</translation>
    </message>
    <message>
        <location filename="../previewselect.cpp" line="75"/>
        <location filename="../previewselect.cpp" line="110"/>
        <location filename="../previewselect.cpp" line="116"/>
        <source>Sorry, we can&apos;t preview this file</source>
        <translation>Ho sento, no es pot realitzar una vista prèvia d&apos;aquest arxiu</translation>
    </message>
</context>
<context>
    <name>ProgramUpdater</name>
    <message>
        <source>Could not create the file %1</source>
        <translation type="obsolete">No es va poder crear l&apos;arxiu %1</translation>
    </message>
    <message>
        <source>Failed to download the update at %1</source>
        <comment>%1 is an URL</comment>
        <translation type="obsolete">Error en descarregar l&apos;actualització %1</translation>
    </message>
</context>
<context>
    <name>PropListDelegate</name>
    <message>
        <location filename="../properties/proplistdelegate.h" line="107"/>
        <source>Not downloaded</source>
        <translation>No descarregar</translation>
    </message>
    <message>
        <location filename="../properties/proplistdelegate.h" line="116"/>
        <location filename="../properties/proplistdelegate.h" line="171"/>
        <source>Normal</source>
        <comment>Normal (priority)</comment>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../properties/proplistdelegate.h" line="110"/>
        <location filename="../properties/proplistdelegate.h" line="172"/>
        <source>High</source>
        <comment>High (priority)</comment>
        <translation>Alt</translation>
    </message>
    <message>
        <location filename="../properties/proplistdelegate.h" line="104"/>
        <source>Mixed</source>
        <comment>Mixed (priorities</comment>
        <translation>Mixt</translation>
    </message>
    <message>
        <location filename="../properties/proplistdelegate.h" line="113"/>
        <location filename="../properties/proplistdelegate.h" line="173"/>
        <source>Maximum</source>
        <comment>Maximum (priority)</comment>
        <translation>Màxim</translation>
    </message>
</context>
<context>
    <name>PropTabBar</name>
    <message>
        <location filename="../properties/proptabbar.cpp" line="55"/>
        <source>General</source>
        <translation>General</translation>
    </message>
    <message>
        <location filename="../properties/proptabbar.cpp" line="62"/>
        <source>Trackers</source>
        <translation>Trackers</translation>
    </message>
    <message>
        <location filename="../properties/proptabbar.cpp" line="68"/>
        <source>Peers</source>
        <translation>Parells</translation>
    </message>
    <message>
        <location filename="../properties/proptabbar.cpp" line="74"/>
        <source>HTTP Sources</source>
        <translation>Fonts HTTP</translation>
    </message>
    <message>
        <location filename="../properties/proptabbar.cpp" line="80"/>
        <source>Content</source>
        <translation>Contingut</translation>
    </message>
    <message>
        <source>URL Seeds</source>
        <translation type="obsolete">URL Llavors</translation>
    </message>
    <message>
        <source>Files</source>
        <translation type="obsolete">Arxius</translation>
    </message>
</context>
<context>
    <name>PropertiesWidget</name>
    <message>
        <location filename="../properties/propertieswidget.ui" line="351"/>
        <source>Save path:</source>
        <translation>Directori de destí:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="459"/>
        <source>Torrent hash:</source>
        <translation>Hash de torrent:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="545"/>
        <source>Comment:</source>
        <translation>Comentari:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="211"/>
        <source>Share ratio:</source>
        <translation>Ratio de Compartició:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="82"/>
        <location filename="../properties/propertieswidget.ui" line="228"/>
        <source>Downloaded:</source>
        <translation>Baixat:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="136"/>
        <source>Availability:</source>
        <translation>Disponibilitat:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="171"/>
        <source>Transfer</source>
        <translation>Transferència</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="177"/>
        <source>Uploaded:</source>
        <translation>Pujada:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="279"/>
        <source>Wasted:</source>
        <translation>Perdut:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="296"/>
        <source>Time active:</source>
        <extracomment>Time (duration) the torrent is active (not paused)</extracomment>
        <translation>Temps actiu:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="502"/>
        <source>Pieces size:</source>
        <translation>Mida de la peça:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="774"/>
        <source>Torrent content:</source>
        <translation>Contingut del torrent:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="827"/>
        <source>Select All</source>
        <translation>Selecciona Totes</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="834"/>
        <source>Select None</source>
        <translation>Treure Seleccions</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="882"/>
        <location filename="../properties/propertieswidget.ui" line="885"/>
        <source>Do not download</source>
        <translation>No descarregar</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="194"/>
        <source>UP limit:</source>
        <translation>Límit Pujada:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="245"/>
        <source>DL limit:</source>
        <translation>Límit Baixada:</translation>
    </message>
    <message>
        <source>Time elapsed:</source>
        <translation type="obsolete">Temps transcorregut:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="262"/>
        <source>Connections:</source>
        <translation>Connexions:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="313"/>
        <source>Reannounce in:</source>
        <translation>Republicar en:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="339"/>
        <source>Information</source>
        <translation>Informació</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="413"/>
        <source>Created on:</source>
        <translation>Creat:</translation>
    </message>
    <message>
        <source>General</source>
        <translation type="obsolete">General</translation>
    </message>
    <message>
        <source>Trackers</source>
        <translation type="obsolete">Trackers</translation>
    </message>
    <message>
        <source>Peers</source>
        <translation type="obsolete">Parells</translation>
    </message>
    <message>
        <source>URL seeds</source>
        <translation type="obsolete">URL llavors</translation>
    </message>
    <message>
        <source>Files</source>
        <translation type="obsolete">Arxius</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="476"/>
        <source>Priority</source>
        <translation>Prioritat</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="867"/>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="877"/>
        <source>Maximum</source>
        <translation>Màxim</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="872"/>
        <source>High</source>
        <translation>Alt</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="329"/>
        <location filename="../properties/propertieswidget.cpp" line="330"/>
        <source>this session</source>
        <translation>en aquesta sessió</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="334"/>
        <location filename="../properties/propertieswidget.cpp" line="338"/>
        <source>/s</source>
        <comment>/second (i.e. per second)</comment>
        <translation></translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="341"/>
        <source>Seeded for %1</source>
        <comment>e.g. Seeded for 3m10s</comment>
        <translation>Llavors per %1</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="345"/>
        <source>%1 max</source>
        <comment>e.g. 10 max</comment>
        <translation></translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="435"/>
        <location filename="../properties/propertieswidget.cpp" line="457"/>
        <source>I/O Error</source>
        <translation>Error d&apos;Entrada/Sortida</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="435"/>
        <source>This file does not exist yet.</source>
        <translation>Aquest arxiu encara no existeix.</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="457"/>
        <source>This folder does not exist yet.</source>
        <translation>Aquest arxiu encara no existeix.</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="467"/>
        <source>Rename...</source>
        <translation>Rebatejar...</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="518"/>
        <source>Rename the file</source>
        <translation>Rebatejar arxiu Torrent</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="519"/>
        <source>New name:</source>
        <translation>Nou nom:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="523"/>
        <location filename="../properties/propertieswidget.cpp" line="555"/>
        <source>The file could not be renamed</source>
        <translation>No es pot canviar el nom d&apos;arxiu</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="524"/>
        <source>This file name contains forbidden characters, please choose a different one.</source>
        <translation>El nom introduït conté caràcters prohibits, si us plau n&apos;elegeixi un altre.</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="556"/>
        <location filename="../properties/propertieswidget.cpp" line="594"/>
        <source>This name is already in use in this folder. Please use a different name.</source>
        <translation>Aquest nom ja està en ús. Si us plau, usi un nom diferent.</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="593"/>
        <source>The folder could not be renamed</source>
        <translation>No es pot canviar el nom d&apos;arxiu</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="632"/>
        <source>New url seed</source>
        <comment>New HTTP source</comment>
        <translation>Nova llavor url</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="633"/>
        <source>New url seed:</source>
        <translation>Nova llavor url:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="638"/>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="639"/>
        <source>This url seed is already in the list.</source>
        <translation>Aquesta llavor url ja està en la llista.</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="681"/>
        <location filename="../properties/propertieswidget.cpp" line="684"/>
        <source>Choose save path</source>
        <translation>Seleccioni un directori de destinació</translation>
    </message>
    <message>
        <source>Save path creation error</source>
        <translation type="obsolete">Error en la creació del directori de destí</translation>
    </message>
    <message>
        <source>Could not create the save path</source>
        <translation type="obsolete">No es va poder crear el directori de destí</translation>
    </message>
</context>
<context>
    <name>QBtSession</name>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="226"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="232"/>
        <source>%1 reached the maximum ratio you set.</source>
        <translation>%1 va assolir el ratio màxim establert.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="227"/>
        <source>Removing torrent %1...</source>
        <translation>Extraient torrent %1...</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="233"/>
        <source>Pausing torrent %1...</source>
        <translation>Torrent Pausat %1...</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="287"/>
        <source>qBittorrent is bound to port: TCP/%1</source>
        <comment>e.g: qBittorrent is bound to port: 6881</comment>
        <translation>qBittorrent està usant el port: TCP/%1</translation>
    </message>
    <message>
        <source>UPnP support [ON]</source>
        <translation type="obsolete">Suport per a UPnP [Encesa]</translation>
    </message>
    <message>
        <source>UPnP support [OFF]</source>
        <translation type="obsolete">Suport per a UPnP [Apagat]</translation>
    </message>
    <message>
        <source>NAT-PMP support [ON]</source>
        <translation type="obsolete">Suport per a NAT-PMP [Encesa]</translation>
    </message>
    <message>
        <source>NAT-PMP support [OFF]</source>
        <translation type="obsolete">Suport per a NAT-PMP[Apagat]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="384"/>
        <source>HTTP user agent is %1</source>
        <translation>HTTP d&apos;usuari es %1</translation>
    </message>
    <message>
        <source>Using a disk cache size of %1 MiB</source>
        <translation type="obsolete">Mida cache del Disc %1 MiB</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="494"/>
        <source>DHT support [ON], port: UDP/%1</source>
        <translation>Suport per a DHT [Encesa], port: UPD/%1</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="496"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="500"/>
        <source>DHT support [OFF]</source>
        <translation>Suport per a DHT [Apagat]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="504"/>
        <source>PeX support [ON]</source>
        <translation>Suport per a PeX [Encesa]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="506"/>
        <source>PeX support [OFF]</source>
        <translation>Suport PeX [Apagat]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="509"/>
        <source>Restart is required to toggle PeX support</source>
        <translation>És necessari reiniciar per activar suport PeX</translation>
    </message>
    <message>
        <source>Local Peer Discovery [ON]</source>
        <translation type="obsolete">Estat local de Parells [Encesa]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="517"/>
        <source>Local Peer Discovery support [OFF]</source>
        <translation>Suport per a estat local de Parells [Apagat]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="529"/>
        <source>Encryption support [ON]</source>
        <translation>Suport per a encriptat [Encesa]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="534"/>
        <source>Encryption support [FORCED]</source>
        <translation>Suport per a encriptat [forçat]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="539"/>
        <source>Encryption support [OFF]</source>
        <translation>Suport per a encriptat [Apagat]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="600"/>
        <source>Embedded Tracker [ON]</source>
        <translation>Integrador de Tracker [Encès]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="602"/>
        <source>Failed to start the embedded tracker!</source>
        <translation>Error en iniciar l&apos;integrat de Tracker!</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="605"/>
        <source>Embedded Tracker [OFF]</source>
        <translation>Integrador de Tracker  [Apagat]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="659"/>
        <source>The Web UI is listening on port %1</source>
        <translation>Port d&apos;escolta d&apos;Interfície Usuari Web %1</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="661"/>
        <source>Web User Interface Error - Unable to bind Web UI to port %1</source>
        <translation>Error interfície d&apos;Usuari Web - No es pot enllaçar al port %1</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="796"/>
        <source>&apos;%1&apos; was removed from transfer list and hard disk.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>&apos;%1&apos; Va ser eliminat de la llista de transferència i del disc.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="798"/>
        <source>&apos;%1&apos; was removed from transfer list.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>&apos;%1&apos; Va ser eliminat de la llista de transferència.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="880"/>
        <source>&apos;%1&apos; is not a valid magnet URI.</source>
        <translation>&apos;%1&apos; no és una URI vàlida.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="896"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1018"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1023"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1025"/>
        <source>&apos;%1&apos; is already in download list.</source>
        <comment>e.g: &apos;xxx.avi&apos; is already in download list.</comment>
        <translation>&apos;%1&apos; ja està en la llista de descàrregues.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1169"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1177"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1182"/>
        <source>&apos;%1&apos; resumed. (fast resume)</source>
        <comment>&apos;/home/y/xxx.torrent&apos; was resumed. (fast resume)</comment>
        <translation>&apos;%1&apos; reiniciat. (reinici ràpid)</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="952"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1171"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1179"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1184"/>
        <source>&apos;%1&apos; added to download list.</source>
        <comment>&apos;/home/y/xxx.torrent&apos; was added to download list.</comment>
        <translation>&apos;%1&apos; agregat a la llista de descàrregues.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="375"/>
        <source>UPnP / NAT-PMP support [ON]</source>
        <translation>Suport UPnP / NAT-PMP [ON]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="378"/>
        <source>UPnP / NAT-PMP support [OFF]</source>
        <translation>Suport UPnP / NAT-PMP [OFF]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="440"/>
        <source>Reporting IP address %1 to trackers...</source>
        <translation>Adreça IP d&apos;Infomes %1 de trackers...</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="514"/>
        <source>Local Peer Discovery support [ON]</source>
        <translation>Suport Trobat Local de Pares [ON]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="987"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="994"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="996"/>
        <source>Unable to decode torrent file: &apos;%1&apos;</source>
        <comment>e.g: Unable to decode torrent file: &apos;/home/y/xxx.torrent&apos;</comment>
        <translation>Impossible descodificar l&apos;arxiu torrent: &apos;%1&apos;</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1000"/>
        <source>This file is either corrupted or this isn&apos;t a torrent.</source>
        <translation>Aquest arxiu pot ser corrupte, o no ser un torrent.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1040"/>
        <source>Error: The torrent %1 does not contain any file.</source>
        <translation>Error: aquest torrent %1 no conté cap fitxer.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1328"/>
        <source>Note: new trackers were added to the existing torrent.</source>
        <translation>Nota: nous Trackers s&apos;han afegit al torrent existent.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1354"/>
        <source>Note: new URL seeds were added to the existing torrent.</source>
        <translation>Nota: noves llavors URL s&apos;han afegit al Torrent existent.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1710"/>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;was blocked due to your IP filter&lt;/i&gt;</source>
        <comment>x.y.z.w was blocked</comment>
        <translation>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;va ser bloquejat a causa del filtre IP&lt;/i&gt;</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1712"/>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;was banned due to corrupt pieces&lt;/i&gt;</source>
        <comment>x.y.z.w was banned</comment>
        <translation>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;Va ser bloquejat a causa de fragments corruptes&lt;/i&gt;</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1890"/>
        <source>The network interface defined is invalid: %1</source>
        <translation>La interfície de la xarxa definida no és vàlida:%1</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1891"/>
        <source>Trying any other network interface available instead.</source>
        <translation>Tractant qualsevol interfície de xarxa disponibles en el seu lloc.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1914"/>
        <source>Listening on IP address %1 on network interface %2...</source>
        <translation>Escoltant l&apos;adreça IP %1 de la interfície de xarxa %2...</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1917"/>
        <source>Failed to listen on network interface %1</source>
        <translation>No s&apos;ha pogut escoltar la interfície de xarxa %1</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2113"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2115"/>
        <source>Recursive download of file %1 embedded in torrent %2</source>
        <comment>Recursive download of test.torrent embedded in torrent test2</comment>
        <translation>Descàrrega recursiva d&apos;arxiu %1 incrustada en Torrent %2</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2210"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2212"/>
        <source>Unable to decode %1 torrent file.</source>
        <translation>No es pot descodificar %1 arxiu torrent.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2260"/>
        <source>The computer will now go to sleep mode unless you cancel within the next 15 seconds...</source>
        <translation>L&apos;equip entrarà en 15 segons en estat de suspensió, a menys que ho cancel...</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2262"/>
        <source>The computer will now be switched off unless you cancel within the next 15 seconds...</source>
        <translation>L&apos;equip s&apos;apagarà en 15 segons, a menys que ho cancel...</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2264"/>
        <source>qBittorrent will now exit unless you cancel within the next 15 seconds...</source>
        <translation>qBittorrent serà tancat en 15 segons, a menys que ho cancel...</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2871"/>
        <source>Successfuly parsed the provided IP filter: %1 rules were applied.</source>
        <comment>%1 is a number</comment>
        <translation>Anàlisi reeixit de filtratge IP: %1 normes aplicades.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2877"/>
        <source>Error: Failed to parse the provided IP filter.</source>
        <translation>Error: No s&apos;ha pogut analitzar el filtratge IP.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2160"/>
        <source>Torrent name: %1</source>
        <translation>Nom del torrent: %1</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2161"/>
        <source>Torrent size: %1</source>
        <translation>Mida del torrent: %1</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2162"/>
        <source>Save path: %1</source>
        <translation>Guardar ruta: %1</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2163"/>
        <source>The torrent was downloaded in %1.</source>
        <comment>The torrent was downloaded in 1 hour and 20 seconds</comment>
        <translation>El torrernt es va descarregar a %1.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2164"/>
        <source>Thank you for using qBittorrent.</source>
        <translation>Gràcies per utilitzar qBittorrent.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2167"/>
        <source>[qBittorrent] %1 has finished downloading</source>
        <translation>[qBittorrent] %1 s&apos;ha finalitzat les descàrregues</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2427"/>
        <source>An I/O error occured, &apos;%1&apos; paused.</source>
        <translation>Error E/S ocorregut, &apos;%1&apos; pausat.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2428"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2558"/>
        <source>Reason: %1</source>
        <translation>Raó: %1</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2517"/>
        <source>UPnP/NAT-PMP: Port mapping failure, message: %1</source>
        <translation>UPnP/NAT-PMP: Va fallar el mapatge del port, missatge: %1</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2522"/>
        <source>UPnP/NAT-PMP: Port mapping successful, message: %1</source>
        <translation>UPnP/NAT-PMP: Mapatge del port reeixit, missatge: %1</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2553"/>
        <source>File sizes mismatch for torrent %1, pausing it.</source>
        <translation>La mida del fitxer no coincideix amb el torrent %1, pausat.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2557"/>
        <source>Fast resume data was rejected for torrent %1, checking again...</source>
        <translation>Es van negar les dades per a reinici ràpid del torrent: %1, verificant de nou... </translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2563"/>
        <source>Url seed lookup failed for url: %1, message: %2</source>
        <translation>Va fallar la recerca de llavor per l&apos;Url: %1, missatge: %2</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2692"/>
        <source>Downloading &apos;%1&apos;, please wait...</source>
        <comment>e.g: Downloading &apos;xxx.torrent&apos;, please wait...</comment>
        <translation>Descarregant &apos;%1&apos;, si us plau esperi...</translation>
    </message>
</context>
<context>
    <name>RSS</name>
    <message>
        <location filename="../rss/rss.ui" line="17"/>
        <source>Search</source>
        <translation>Cerca</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="25"/>
        <source>New subscription</source>
        <translation>Nova subscripció</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="35"/>
        <location filename="../rss/rss.ui" line="183"/>
        <location filename="../rss/rss.ui" line="186"/>
        <source>Mark items read</source>
        <translation>Marcar per llegir</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="54"/>
        <source>Update all</source>
        <translation>Actualitzar tot</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="83"/>
        <source>RSS Downloader...</source>
        <translation>Descarregar RSS...</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="90"/>
        <source>Settings...</source>
        <translation>Configuració...</translation>
    </message>
    <message>
        <source>Feed URL</source>
        <translation type="obsolete">Canal URL</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="154"/>
        <source>Rename...</source>
        <translation>Rebatejar...</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="162"/>
        <location filename="../rss/rss.ui" line="165"/>
        <source>Update</source>
        <translation>Actualitzar</translation>
    </message>
    <message>
        <source>RSS feed downloader...</source>
        <translation type="obsolete">Descarregar Canal RSS...</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="206"/>
        <source>New folder...</source>
        <translation>Nova carpeta...</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="211"/>
        <source>Manage cookies...</source>
        <translation>Administrar Cookies...</translation>
    </message>
    <message>
        <source>RSS feeds</source>
        <translation type="obsolete">Canals RSS</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="112"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Torrents:&lt;/span&gt; &lt;span style=&quot; font-style:italic;&quot;&gt;(double-click to download)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Torrents:&lt;/span&gt; &lt;span style=&quot; font-style:italic;&quot;&gt;(doble-click per iniciar la descàrrega)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Article title</source>
        <translation type="obsolete">Títol de l&apos;article</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="170"/>
        <source>New subscription...</source>
        <translation>Nova subscripció...</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="175"/>
        <location filename="../rss/rss.ui" line="178"/>
        <source>Update all feeds</source>
        <translation>Actualitzar tots els Canals</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="146"/>
        <location filename="../rss/rss.ui" line="149"/>
        <source>Delete</source>
        <translation>Esborrar</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="157"/>
        <source>Rename</source>
        <translation>Rebatejar</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="191"/>
        <source>Download torrent</source>
        <translation>Descarregar torrent</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="196"/>
        <source>Open news URL</source>
        <translation>Obrir nova URL</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="201"/>
        <source>Copy feed URL</source>
        <translation>Copiar Canal URL</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="51"/>
        <source>Refresh RSS streams</source>
        <translation>Actualitzar els Canals RSS</translation>
    </message>
</context>
<context>
    <name>RSSImp</name>
    <message>
        <location filename="../rss/rss_imp.cpp" line="203"/>
        <source>Please type a rss stream url</source>
        <translation>Si us plau escriu una URL d&apos;un Canal RSS</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="203"/>
        <source>Stream URL:</source>
        <translation>URL del Canal:</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="237"/>
        <location filename="../rss/rss_imp.cpp" line="241"/>
        <source>Are you sure? -- qBittorrent</source>
        <translation>Està segur? -- qBittorrent</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="238"/>
        <location filename="../rss/rss_imp.cpp" line="242"/>
        <source>&amp;Yes</source>
        <translation>&amp;Sí</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="238"/>
        <location filename="../rss/rss_imp.cpp" line="242"/>
        <source>&amp;No</source>
        <translation>&amp;No</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="149"/>
        <source>Please choose a folder name</source>
        <translation>Si us plau elegeixi un nom per a la carpeta</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="149"/>
        <source>Folder name:</source>
        <translation>Nom de la carpeta:</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="149"/>
        <source>New folder</source>
        <translation>Nova carpeta</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="170"/>
        <source>Overwrite attempt</source>
        <translation>Intentant sobreescriure</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="171"/>
        <source>You cannot overwrite %1 item.</source>
        <comment>You cannot overwrite myFolder item.</comment>
        <translation>Impossible sobreescriure %1 sector.</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="208"/>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="209"/>
        <source>This rss feed is already in the list.</source>
        <translation>Aquesta font de RSS ja està en la llista.</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="237"/>
        <source>Are you sure you want to delete these elements from the list?</source>
        <translation>Segur que vols esborrar aquests elements de la llista?</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="241"/>
        <source>Are you sure you want to delete this element from the list?</source>
        <translation>Segur que vols esborrar aquest element de la llista?</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="351"/>
        <source>Please choose a new name for this RSS feed</source>
        <translation>Si us plau, elegeixi un nou nom per al Canal RSS</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="351"/>
        <source>New feed name:</source>
        <translation>Nom del nou Canal:</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="355"/>
        <source>Name already in use</source>
        <translation>Aquest nom ja es troba en ús</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="355"/>
        <source>This name is already used by another item, please choose another one.</source>
        <translation>Aquest nom ja s&apos;està usant, si us plau, elegeixi un altre.</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="508"/>
        <source>Date: </source>
        <translation>Data:</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="511"/>
        <source>Author: </source>
        <translation>Autor:</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="554"/>
        <source>Unread</source>
        <translation>No llegits</translation>
    </message>
</context>
<context>
    <name>RssArticle</name>
    <message>
        <source>No description available</source>
        <translation type="obsolete">Sense descripció disponible</translation>
    </message>
</context>
<context>
    <name>RssFeed</name>
    <message>
        <location filename="../rss/rssfeed.cpp" line="292"/>
        <source>Automatically downloading %1 torrent from %2 RSS feed...</source>
        <translation>Descarregar automàtica %1 Torrent %2 Canal RSS...</translation>
    </message>
</context>
<context>
    <name>RssItem</name>
    <message>
        <source>No description available</source>
        <translation type="obsolete">Sense descripció disponible</translation>
    </message>
</context>
<context>
    <name>RssSettings</name>
    <message>
        <source>RSS Reader Settings</source>
        <translation type="obsolete">Ajustaments Lector RSS</translation>
    </message>
    <message>
        <source>RSS feeds refresh interval:</source>
        <translation type="obsolete">Interval d&apos;actualització de Canals RSS:</translation>
    </message>
    <message>
        <source>minutes</source>
        <translation type="obsolete">minuts</translation>
    </message>
    <message>
        <source>Maximum number of articles per feed:</source>
        <translation type="obsolete">Nombre màxim d&apos;articles per Canal:</translation>
    </message>
</context>
<context>
    <name>RssSettingsDlg</name>
    <message>
        <location filename="../rss/rsssettingsdlg.ui" line="14"/>
        <source>RSS Reader Settings</source>
        <translation>Ajustaments Lector RSS</translation>
    </message>
    <message>
        <location filename="../rss/rsssettingsdlg.ui" line="47"/>
        <source>RSS feeds refresh interval:</source>
        <translation>Interval d&apos;actualització de Canals RSS:</translation>
    </message>
    <message>
        <location filename="../rss/rsssettingsdlg.ui" line="70"/>
        <source>minutes</source>
        <translation>minuts</translation>
    </message>
    <message>
        <location filename="../rss/rsssettingsdlg.ui" line="77"/>
        <source>Maximum number of articles per feed:</source>
        <translation>Nombre màxim d&apos;articles per Canal:</translation>
    </message>
</context>
<context>
    <name>RssStream</name>
    <message>
        <source>Automatically downloading %1 torrent from %2 RSS feed...</source>
        <translation type="obsolete">Descarregar automàtica %1 Torrent %2 Canal RSS...</translation>
    </message>
</context>
<context>
    <name>ScanFoldersModel</name>
    <message>
        <location filename="../scannedfoldersmodel.cpp" line="103"/>
        <source>Watched Folder</source>
        <translation>Cerca fitxers .torrents</translation>
    </message>
    <message>
        <location filename="../scannedfoldersmodel.cpp" line="104"/>
        <source>Download here</source>
        <translation>Descarregar Torrent aquí</translation>
    </message>
</context>
<context>
    <name>SearchCategories</name>
    <message>
        <location filename="../searchengine/supportedengines.h" line="51"/>
        <source>All categories</source>
        <translation>Totes les categories</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="52"/>
        <source>Movies</source>
        <translation>Vídeos</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="53"/>
        <source>TV shows</source>
        <translation>Programes TV</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="54"/>
        <source>Music</source>
        <translation>Música</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="55"/>
        <source>Games</source>
        <translation>Jocs</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="56"/>
        <source>Anime</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="57"/>
        <source>Software</source>
        <translation>Programes</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="58"/>
        <source>Pictures</source>
        <translation>Imatges</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="59"/>
        <source>Books</source>
        <translation>Llibres</translation>
    </message>
</context>
<context>
    <name>SearchEngine</name>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="332"/>
        <source>Empty search pattern</source>
        <translation>Patró de recerca buit</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="332"/>
        <source>Please type a search pattern first</source>
        <translation>Si us plau escrigui un patró de recerca primer</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="370"/>
        <location filename="../searchengine/searchengine.cpp" line="466"/>
        <source>Results</source>
        <translation>Resultats</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="445"/>
        <source>Searching...</source>
        <translation>Buscant...</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="213"/>
        <source>Cut</source>
        <translation>Tallar</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="214"/>
        <source>Copy</source>
        <translation>Copiar</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="215"/>
        <source>Paste</source>
        <translation>Pegar</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="216"/>
        <source>Clear field</source>
        <translation>Esborrar de la llista</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="217"/>
        <source>Clear completion history</source>
        <translation>Netejar historial de recerques</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="236"/>
        <source>Confirmation</source>
        <translation>Confirmació</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="236"/>
        <source>Are you sure you want to clear the history?</source>
        <translation>Esteu segur que voleu esborrar l&apos;historial?</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="290"/>
        <location filename="../searchengine/searchengine.cpp" line="320"/>
        <location filename="../searchengine/searchengine.cpp" line="321"/>
        <source>Search</source>
        <translation>Cerca</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="301"/>
        <source>Missing Python Interpreter</source>
        <translation>Manca intèrpret de Python</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="302"/>
        <source>Python 2.x is required to use the search engine but it does not seem to be installed.
Do you want to install it now?</source>
        <translation>Python 2.x és necessari per utilitzar el motor de cerca però no sembla que estigui instal-lat.
¿Voleu instal-lo ara?</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="585"/>
        <source>Search Engine</source>
        <translation>Motor de cerca</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="585"/>
        <location filename="../searchengine/searchengine.cpp" line="600"/>
        <source>Search has finished</source>
        <translation>Recerca acabada</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="591"/>
        <source>An error occured during search...</source>
        <translation>Va ocórrer un error durant la recerca...</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="589"/>
        <location filename="../searchengine/searchengine.cpp" line="595"/>
        <source>Search aborted</source>
        <translation>Recerca avortada</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="178"/>
        <source>Download error</source>
        <translation>Error de descàrrega</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="178"/>
        <source>Python setup could not be downloaded, reason: %1.
Please install it manually.</source>
        <translation>La instal-lació de Python no es va poder realitzar, la raó:%1.
Si us plau, instal-li&apos;l de forma manual.</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="598"/>
        <source>Search returned no results</source>
        <translation>La recerca no va tornar resultats</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="605"/>
        <source>Results</source>
        <comment>i.e: Search results</comment>
        <translation>Resultats</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="641"/>
        <location filename="../searchengine/searchengine.cpp" line="647"/>
        <source>Unknown</source>
        <translation>Desconegut</translation>
    </message>
</context>
<context>
    <name>SearchTab</name>
    <message>
        <location filename="../searchengine/searchtab.cpp" line="55"/>
        <source>Name</source>
        <comment>i.e: file name</comment>
        <translation>Nom</translation>
    </message>
    <message>
        <location filename="../searchengine/searchtab.cpp" line="56"/>
        <source>Size</source>
        <comment>i.e: file size</comment>
        <translation>Mida</translation>
    </message>
    <message>
        <location filename="../searchengine/searchtab.cpp" line="57"/>
        <source>Seeders</source>
        <comment>i.e: Number of full sources</comment>
        <translation>Llavors</translation>
    </message>
    <message>
        <location filename="../searchengine/searchtab.cpp" line="58"/>
        <source>Leechers</source>
        <comment>i.e: Number of partial sources</comment>
        <translation>Leechers</translation>
    </message>
    <message>
        <location filename="../searchengine/searchtab.cpp" line="59"/>
        <source>Search engine</source>
        <translation>Motor de cerca</translation>
    </message>
</context>
<context>
    <name>ShutdownConfirmDlg</name>
    <message>
        <location filename="../qtlibtorrent/shutdownconfirm.h" line="44"/>
        <source>Shutdown confirmation</source>
        <translation>Tancar confirmació</translation>
    </message>
</context>
<context>
    <name>SpeedLimitDialog</name>
    <message>
        <location filename="../speedlimitdlg.h" line="84"/>
        <source>KiB/s</source>
        <translation>KiB/s</translation>
    </message>
</context>
<context>
    <name>StatusBar</name>
    <message>
        <location filename="../statusbar.h" line="67"/>
        <location filename="../statusbar.h" line="180"/>
        <source>Connection status:</source>
        <translation>Estat de la connexió:</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="67"/>
        <location filename="../statusbar.h" line="180"/>
        <source>No direct connections. This may indicate network configuration problems.</source>
        <translation>No hi ha connexions directes. Això pot indicar problemes en la configuració de la xarxa.</translation>
    </message>
    <message>
        <source>D: %1 B/s - T: %2</source>
        <comment>Download speed: x B/s - Transferred: x MiB</comment>
        <translation type="obsolete">Baixada: %1 B/s - Total: %2</translation>
    </message>
    <message>
        <source>U: %1 B/s - T: %2</source>
        <comment>Upload speed: x B/s - Transferred: x MiB</comment>
        <translation type="obsolete">Pujada: %1 B/s - Total: %2</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="95"/>
        <location filename="../statusbar.h" line="187"/>
        <source>DHT: %1 nodes</source>
        <translation>DHT: %1 nodes</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="150"/>
        <source>qBittorrent needs to be restarted</source>
        <translation>És necessari reiniciar qBittorrent</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="160"/>
        <source>qBittorrent was just updated and needs to be restarted for the changes to be effective.</source>
        <translation>qBittorrent ha estat actualitzat i ha de ser reiniciat perquè els canvis siguin efectius.</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="172"/>
        <location filename="../statusbar.h" line="177"/>
        <source>Connection Status:</source>
        <translation>Estat de la connexió:</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="172"/>
        <source>Offline. This usually means that qBittorrent failed to listen on the selected port for incoming connections.</source>
        <translation>Fora de línia. Això normalment significa que qBittorrent no pot escoltar el port seleccionat per a les connexions entrants.</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="177"/>
        <source>Online</source>
        <translation>En línea</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="193"/>
        <location filename="../statusbar.h" line="194"/>
        <source>%1/s</source>
        <comment>Per second</comment>
        <translation>%1/s</translation>
    </message>
    <message>
        <source>D: %1/s - T: %2</source>
        <comment>Download speed: x KiB/s - Transferred: x MiB</comment>
        <translation type="obsolete">Baixada: %1/s - Total: %2</translation>
    </message>
    <message>
        <source>U: %1/s - T: %2</source>
        <comment>Upload speed: x KiB/s - Transferred: x MiB</comment>
        <translation type="obsolete">Pujada: %1/s - Total: %2</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="204"/>
        <source>Click to switch to alternative speed limits</source>
        <translation>Cliqueu per canviar als límits de velocitat alternativa</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="200"/>
        <source>Click to switch to regular speed limits</source>
        <translation>Cliqueu per canviar als límits de velocitat normal</translation>
    </message>
    <message>
        <source>Click to disable alternative speed limits</source>
        <translation type="obsolete">Click per desactivar els límits de velocitat alternativa</translation>
    </message>
    <message>
        <source>Click to enable alternative speed limits</source>
        <translation type="obsolete">Click per activar els límits de velocitat alternativa</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="220"/>
        <source>Global Download Speed Limit</source>
        <translation>Velocitat límit global de descàrrega</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="245"/>
        <source>Global Upload Speed Limit</source>
        <translation>Velocitat límit global de pujada</translation>
    </message>
</context>
<context>
    <name>TorrentCreatorDlg</name>
    <message>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="73"/>
        <source>Select a folder to add to the torrent</source>
        <translation>Seleccioni una altra carpeta per agregar el torrent</translation>
    </message>
    <message>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="89"/>
        <source>Select a file to add to the torrent</source>
        <translation>Seleccioni un altre arxiu per agregar el torrent</translation>
    </message>
    <message>
        <source>Please type an announce URL</source>
        <translation type="obsolete">Si us plau escriu una URL d&apos;anunci</translation>
    </message>
    <message>
        <source>Announce URL:</source>
        <comment>Tracker URL</comment>
        <translation type="obsolete">URL d&apos;anunci:</translation>
    </message>
    <message>
        <source>Please type a web seed url</source>
        <translation type="obsolete">Si us plau escriu una url de llavor web</translation>
    </message>
    <message>
        <source>Web seed URL:</source>
        <translation type="obsolete">URL de llavor web:</translation>
    </message>
    <message>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="112"/>
        <source>No input path set</source>
        <translation>Sense ruta de destí establerta</translation>
    </message>
    <message>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="112"/>
        <source>Please type an input path first</source>
        <translation>Si us plau escriu primer una ruta d&apos;entrada</translation>
    </message>
    <message>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="122"/>
        <source>Select destination torrent file</source>
        <translation>Seleccioni una destí per a l&apos;arxiu torrent</translation>
    </message>
    <message>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="122"/>
        <source>Torrent Files</source>
        <translation>Arxius Torrent</translation>
    </message>
    <message>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="149"/>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="165"/>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="180"/>
        <source>Torrent creation</source>
        <translation>Crear Torrent</translation>
    </message>
    <message>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="149"/>
        <source>Torrent creation was unsuccessful, reason: %1</source>
        <translation>La creació del torrent no ha estat reeixida, raó: %1</translation>
    </message>
    <message>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="165"/>
        <source>Created torrent file is invalid. It won&apos;t be added to download list.</source>
        <translation>La creació de l&apos;arxiu torrent no és vàlida. No s&apos;afegirà a la llista de descàrregues.</translation>
    </message>
    <message>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="180"/>
        <source>Torrent was created successfully:</source>
        <translation>El Torrent es va crear amb èxit:</translation>
    </message>
</context>
<context>
    <name>TorrentFilesModel</name>
    <message>
        <location filename="../torrentfilesmodel.h" line="343"/>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <location filename="../torrentfilesmodel.h" line="343"/>
        <source>Size</source>
        <translation>Mida</translation>
    </message>
    <message>
        <location filename="../torrentfilesmodel.h" line="343"/>
        <source>Progress</source>
        <translation>Progrés</translation>
    </message>
    <message>
        <location filename="../torrentfilesmodel.h" line="343"/>
        <source>Priority</source>
        <translation>Prioritat</translation>
    </message>
</context>
<context>
    <name>TorrentImportDlg</name>
    <message>
        <location filename="../torrentimportdlg.ui" line="14"/>
        <source>Torrent Import</source>
        <translation>Importar Torrent</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.ui" line="38"/>
        <source>This assistant will help you share with qBittorrent a torrent that you have already downloaded.</source>
        <translation>Aquest assistent l&apos;ajudarà a compartir amb qBittorrent, un torrent ja descarregat.</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.ui" line="50"/>
        <source>Torrent file to import:</source>
        <translation>Arxiu Torrent per importar:</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.ui" line="66"/>
        <location filename="../torrentimportdlg.ui" line="94"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.ui" line="75"/>
        <source>Content location:</source>
        <translation>Ubicació del contingut:</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.ui" line="106"/>
        <source>Skip the data checking stage and start seeding immediately</source>
        <translation>Saltar-se la fase de control de dades i començar a sembrar tot seguit</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.ui" line="116"/>
        <source>Import</source>
        <translation>Importar</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.cpp" line="70"/>
        <source>Torrent file to import</source>
        <translation>Arxiu Torrent per importar</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.cpp" line="70"/>
        <source>Torrent files (*.torrent)</source>
        <translation>Arxius Torrent (*.torrent)</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.cpp" line="95"/>
        <source>%1 Files</source>
        <comment>%1 is a file extension (e.g. PDF)</comment>
        <translation>%1 Arxius</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.cpp" line="97"/>
        <source>Please provide the location of %1</source>
        <comment>%1 is a file name</comment>
        <translation>Si us plau, indiqui la ubicació del %1</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.cpp" line="134"/>
        <source>Please point to the location of the torrent: %1</source>
        <translation>Si us plau, elegeixi la ubicació del torrent: %1</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.cpp" line="242"/>
        <source>Invalid torrent file</source>
        <translation>Arxiu torrent no vàlid</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.cpp" line="242"/>
        <source>This is not a valid torrent file.</source>
        <translation>Això no és un arxiu torrent vàlid.</translation>
    </message>
</context>
<context>
    <name>TorrentModel</name>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="239"/>
        <source>Name</source>
        <comment>i.e: torrent name</comment>
        <translation>Nom</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="241"/>
        <source>Size</source>
        <comment>i.e: torrent size</comment>
        <translation>Mida</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="242"/>
        <source>Done</source>
        <comment>% Done</comment>
        <translation>Progrés</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="243"/>
        <source>Status</source>
        <comment>Torrent status (e.g. downloading, seeding, paused)</comment>
        <translation>Estat</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="244"/>
        <source>Seeds</source>
        <comment>i.e. full sources (often untranslated)</comment>
        <translation>Llavors</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="245"/>
        <source>Peers</source>
        <comment>i.e. partial sources (often untranslated)</comment>
        <translation>Parells</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="246"/>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Vel. Baixada</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="247"/>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Vel. Pujada</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="248"/>
        <source>Ratio</source>
        <comment>Share ratio</comment>
        <translation>Ratio</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="249"/>
        <source>ETA</source>
        <comment>i.e: Estimated Time of Arrival / Time left</comment>
        <translation>Temps estimat</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="250"/>
        <source>Label</source>
        <translation>Etiqueta</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="251"/>
        <source>Added On</source>
        <comment>Torrent was added to transfer list on 01/01/2010 08:00</comment>
        <translation>Afegit el</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="252"/>
        <source>Completed On</source>
        <comment>Torrent was completed on 01/01/2010 08:00</comment>
        <translation>Completat a</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="253"/>
        <source>Tracker</source>
        <translation>Tracker</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="254"/>
        <source>Down Limit</source>
        <comment>i.e: Download limit</comment>
        <translation>Límit Baixada</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="255"/>
        <source>Up Limit</source>
        <comment>i.e: Upload limit</comment>
        <translation>Límit Pujada</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="256"/>
        <source>Amount downloaded</source>
        <comment>Amount of data downloaded (e.g. in MB)</comment>
        <translation>Quantitat descarregada</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="257"/>
        <source>Amount left</source>
        <comment>Amount of data left to download (e.g. in MB)</comment>
        <translation>Quantitat que manca</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="258"/>
        <source>Time Active</source>
        <comment>Time (duration) the torrent is active (not paused)</comment>
        <translation>Temps actiu</translation>
    </message>
</context>
<context>
    <name>TrackerList</name>
    <message>
        <location filename="../properties/trackerlist.cpp" line="61"/>
        <source>URL</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="62"/>
        <source>Status</source>
        <translation>Estat</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="63"/>
        <source>Peers</source>
        <translation>Parells</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="64"/>
        <source>Message</source>
        <translation>Missatge</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="66"/>
        <source>[DHT]</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="69"/>
        <source>[PeX]</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="72"/>
        <source>[LSD]</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="209"/>
        <location filename="../properties/trackerlist.cpp" line="219"/>
        <location filename="../properties/trackerlist.cpp" line="225"/>
        <location filename="../properties/trackerlist.cpp" line="256"/>
        <location filename="../properties/trackerlist.cpp" line="274"/>
        <source>Working</source>
        <translation>Treballant</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="211"/>
        <location filename="../properties/trackerlist.cpp" line="221"/>
        <location filename="../properties/trackerlist.cpp" line="227"/>
        <source>Disabled</source>
        <translation>Deshabilitat</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="215"/>
        <source>This torrent is private</source>
        <translation>Aquest torrent és privat</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="260"/>
        <source>Updating...</source>
        <translation>Actualitzant...</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="264"/>
        <location filename="../properties/trackerlist.cpp" line="278"/>
        <source>Not working</source>
        <translation>Aturat</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="267"/>
        <location filename="../properties/trackerlist.cpp" line="281"/>
        <source>Not contacted yet</source>
        <translation>Encara sense connexió</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="349"/>
        <source>Add a new tracker...</source>
        <translation>Afegir nou tracker...</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="352"/>
        <source>Remove tracker</source>
        <translation>Esborrar traker</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="355"/>
        <source>Force reannounce</source>
        <translation>Forçar Re-publicar</translation>
    </message>
</context>
<context>
    <name>TrackersAdditionDlg</name>
    <message>
        <location filename="../properties/trackersadditiondlg.ui" line="14"/>
        <source>Trackers addition dialog</source>
        <translation>Diàleg per afegir trackers</translation>
    </message>
    <message>
        <location filename="../properties/trackersadditiondlg.ui" line="20"/>
        <source>List of trackers to add (one per line):</source>
        <translation>Llista de trackers a afegir (un per línia):</translation>
    </message>
    <message utf8="true">
        <location filename="../properties/trackersadditiondlg.ui" line="44"/>
        <source>µTorrent compatible list URL:</source>
        <translation>Llista d&apos;URL de µTorrent compatibles:</translation>
    </message>
    <message>
        <location filename="../properties/trackersadditiondlg.h" line="81"/>
        <source>I/O Error</source>
        <translation>Error d&apos;Entrada/Sortida</translation>
    </message>
    <message>
        <location filename="../properties/trackersadditiondlg.h" line="81"/>
        <source>Error while trying to open the downloaded file.</source>
        <translation>Error en intentar obrir l&apos;arxiu descarregat.</translation>
    </message>
    <message>
        <location filename="../properties/trackersadditiondlg.h" line="123"/>
        <source>No change</source>
        <translation>Sense canvis</translation>
    </message>
    <message>
        <location filename="../properties/trackersadditiondlg.h" line="123"/>
        <source>No additional trackers were found.</source>
        <translation>No es va trobar cap Tracker.</translation>
    </message>
    <message>
        <location filename="../properties/trackersadditiondlg.h" line="132"/>
        <source>Download error</source>
        <translation>Error de descàrrega</translation>
    </message>
    <message>
        <location filename="../properties/trackersadditiondlg.h" line="132"/>
        <source>The trackers list could not be downloaded, reason: %1</source>
        <translation>La llista de Trackers no va poder ser descarregada. Raó: %1</translation>
    </message>
</context>
<context>
    <name>TransferListDelegate</name>
    <message>
        <location filename="../transferlistdelegate.h" line="94"/>
        <source>Downloading</source>
        <translation>Descarregant</translation>
    </message>
    <message>
        <location filename="../transferlistdelegate.h" line="98"/>
        <source>Paused</source>
        <translation>Pausat</translation>
    </message>
    <message>
        <location filename="../transferlistdelegate.h" line="102"/>
        <source>Queued</source>
        <comment>i.e. torrent is queued</comment>
        <translation>A cua</translation>
    </message>
    <message>
        <location filename="../transferlistdelegate.h" line="106"/>
        <source>Seeding</source>
        <comment>Torrent is complete and in upload-only mode</comment>
        <translation>Sembrando</translation>
    </message>
    <message>
        <location filename="../transferlistdelegate.h" line="109"/>
        <source>Stalled</source>
        <comment>Torrent is waiting for download to begin</comment>
        <translation>Detinguda</translation>
    </message>
    <message>
        <location filename="../transferlistdelegate.h" line="113"/>
        <source>Checking</source>
        <comment>Torrent local data is being checked</comment>
        <translation>Verificant</translation>
    </message>
    <message>
        <location filename="../transferlistdelegate.h" line="127"/>
        <source>/s</source>
        <comment>/second (.i.e per second)</comment>
        <translation></translation>
    </message>
    <message>
        <location filename="../transferlistdelegate.h" line="136"/>
        <source>KiB/s</source>
        <comment>KiB/second (.i.e per second)</comment>
        <translation>KiB/s</translation>
    </message>
    <message>
        <location filename="../transferlistdelegate.h" line="146"/>
        <source>Seeded for %1</source>
        <comment>e.g. Seeded for 3m10s</comment>
        <translation>Sembrant %1</translation>
    </message>
</context>
<context>
    <name>TransferListFiltersWidget</name>
    <message>
        <location filename="../transferlistfilterswidget.h" line="205"/>
        <location filename="../transferlistfilterswidget.h" line="287"/>
        <source>All</source>
        <translation>Tots</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="208"/>
        <location filename="../transferlistfilterswidget.h" line="288"/>
        <source>Downloading</source>
        <translation>Descarregant</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="211"/>
        <location filename="../transferlistfilterswidget.h" line="289"/>
        <source>Completed</source>
        <translation>Completats</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="214"/>
        <location filename="../transferlistfilterswidget.h" line="290"/>
        <source>Paused</source>
        <translation>Pausats</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="217"/>
        <location filename="../transferlistfilterswidget.h" line="291"/>
        <source>Active</source>
        <translation>Actius</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="220"/>
        <location filename="../transferlistfilterswidget.h" line="292"/>
        <source>Inactive</source>
        <translation>Inactius</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="234"/>
        <location filename="../transferlistfilterswidget.h" line="469"/>
        <source>All labels</source>
        <translation>Etiquetades</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="237"/>
        <location filename="../transferlistfilterswidget.h" line="470"/>
        <source>Unlabeled</source>
        <translation>Sense Etiquetar</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="319"/>
        <source>Remove label</source>
        <translation>Esborrar etiqueta</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="320"/>
        <source>Add label...</source>
        <translation>Afegir Etiqueta...</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="322"/>
        <source>Resume torrents</source>
        <translation>Reprèn Torrents</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="323"/>
        <source>Pause torrents</source>
        <translation>Pausar torrents</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="324"/>
        <source>Delete torrents</source>
        <translation>Esborrar torrents</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="350"/>
        <source>New Label</source>
        <translation>Nova Etiqueta</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="350"/>
        <source>Label:</source>
        <translation>Etiqueta:</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="355"/>
        <source>Invalid label name</source>
        <translation>Nom d&apos;Etiqueta no vàlid</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="355"/>
        <source>Please don&apos;t use any special characters in the label name.</source>
        <translation>Si us plau, no utilitzi caràcters especials per al nom de l&apos;Etiqueta.</translation>
    </message>
</context>
<context>
    <name>TransferListWidget</name>
    <message>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation type="obsolete">Vel. Baixada</translation>
    </message>
    <message>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation type="obsolete">Vel. Pujada</translation>
    </message>
    <message>
        <source>ETA</source>
        <comment>i.e: Estimated Time of Arrival / Time left</comment>
        <translation type="obsolete">Temps estimat</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="524"/>
        <source>Column visibility</source>
        <translation>Visibilitat de columnes</translation>
    </message>
    <message>
        <source>Name</source>
        <comment>i.e: torrent name</comment>
        <translation type="obsolete">Nom</translation>
    </message>
    <message>
        <source>Size</source>
        <comment>i.e: torrent size</comment>
        <translation type="obsolete">Mida</translation>
    </message>
    <message>
        <source>Done</source>
        <comment>% Done</comment>
        <translation type="obsolete">Progrés</translation>
    </message>
    <message>
        <source>Status</source>
        <comment>Torrent status (e.g. downloading, seeding, paused)</comment>
        <translation type="obsolete">Estat</translation>
    </message>
    <message>
        <source>Seeds</source>
        <comment>i.e. full sources (often untranslated)</comment>
        <translation type="obsolete">Llavors</translation>
    </message>
    <message>
        <source>Peers</source>
        <comment>i.e. partial sources (often untranslated)</comment>
        <translation type="obsolete">Parells</translation>
    </message>
    <message>
        <source>Ratio</source>
        <comment>Share ratio</comment>
        <translation type="obsolete">Ratio</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="766"/>
        <source>Label</source>
        <translation>Etiqueta</translation>
    </message>
    <message>
        <source>Added On</source>
        <comment>Torrent was added to transfer list on 01/01/2010 08:00</comment>
        <translation type="obsolete">Afegit el</translation>
    </message>
    <message>
        <source>Completed On</source>
        <comment>Torrent was completed on 01/01/2010 08:00</comment>
        <translation type="obsolete">Completat a</translation>
    </message>
    <message>
        <source>Tracker</source>
        <translation type="obsolete">Tracker</translation>
    </message>
    <message>
        <source>Down Limit</source>
        <comment>i.e: Download limit</comment>
        <translation type="obsolete">Límit Baixada</translation>
    </message>
    <message>
        <source>Up Limit</source>
        <comment>i.e: Upload limit</comment>
        <translation type="obsolete">Límit Pujada</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="227"/>
        <source>Choose save path</source>
        <translation>Seleccioni un directori de destinació</translation>
    </message>
    <message>
        <source>Save path creation error</source>
        <translation type="obsolete">Error en la creació del directori de destí</translation>
    </message>
    <message>
        <source>Could not create the save path</source>
        <translation type="obsolete">No es va poder crear el directori de destí</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="449"/>
        <source>Torrent Download Speed Limiting</source>
        <translation>Límit de velocitat de Baixada Torrent</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="482"/>
        <source>Torrent Upload Speed Limiting</source>
        <translation>Límit de velocitat de Pujada Torrent</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="589"/>
        <source>New Label</source>
        <translation>Nova Etiqueta</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="589"/>
        <source>Label:</source>
        <translation>Etiqueta:</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="594"/>
        <source>Invalid label name</source>
        <translation>Nom d&apos;Etiqueta no vàlid</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="594"/>
        <source>Please don&apos;t use any special characters in the label name.</source>
        <translation>Si us plau, no utilitzi caràcters especials per al nom de l&apos;Etiqueta.</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="610"/>
        <source>Rename</source>
        <translation>Rebatejar</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="610"/>
        <source>New name:</source>
        <translation>Nou nom:</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="644"/>
        <source>Resume</source>
        <comment>Resume/start the torrent</comment>
        <translation>Reprende</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="646"/>
        <source>Pause</source>
        <comment>Pause the torrent</comment>
        <translation>Pausar</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="648"/>
        <source>Delete</source>
        <comment>Delete the torrent</comment>
        <translation>Esborrar</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="650"/>
        <source>Preview file...</source>
        <translation>Previsualitzar arxiu...</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="652"/>
        <source>Limit share ratio...</source>
        <translation>Límit ràtio compartició ...</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="654"/>
        <source>Limit upload rate...</source>
        <translation>Taxa límit de Pujada...</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="656"/>
        <source>Limit download rate...</source>
        <translation>Taxa límit de Baixada...</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="811"/>
        <source>Priority</source>
        <translation>Prioritat</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="658"/>
        <source>Open destination folder</source>
        <translation>Obrir carpeta destí</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="660"/>
        <source>Move up</source>
        <comment>i.e. move up in the queue</comment>
        <translation>Moure amunt</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="662"/>
        <source>Move down</source>
        <comment>i.e. Move down in the queue</comment>
        <translation>Moure avall</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="664"/>
        <source>Move to top</source>
        <comment>i.e. Move to top of the queue</comment>
        <translation>Moure al principi</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="666"/>
        <source>Move to bottom</source>
        <comment>i.e. Move to bottom of the queue</comment>
        <translation>Moure al final</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="668"/>
        <source>Set location...</source>
        <translation>Establir una destinació...</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="670"/>
        <source>Force recheck</source>
        <translation>Forçar verificació de arxiu</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="672"/>
        <source>Copy magnet link</source>
        <translation>Copiar magnet link</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="675"/>
        <source>Super seeding mode</source>
        <translation>Mode de SuperSembra</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="679"/>
        <source>Rename...</source>
        <translation>Rebatejar...</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="681"/>
        <source>Download in sequential order</source>
        <translation>Descarregar en ordre seqüencial</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="684"/>
        <source>Download first and last piece first</source>
        <translation>Descarregar primer, primeres i últimes parts</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="767"/>
        <source>New...</source>
        <comment>New label...</comment>
        <translation>Nou...</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="768"/>
        <source>Reset</source>
        <comment>Reset label</comment>
        <translation>Reset Etiquetas</translation>
    </message>
</context>
<context>
    <name>UpDownRatioDlg</name>
    <message>
        <location filename="../updownratiodlg.ui" line="14"/>
        <source>Torrent Upload/Download Ratio Limiting</source>
        <translation>Límits de ràtio de Pujada/Baixada</translation>
    </message>
    <message>
        <location filename="../updownratiodlg.ui" line="20"/>
        <source>Use global ratio limit</source>
        <translation>Utilitza límit de ràtio global</translation>
    </message>
    <message>
        <location filename="../updownratiodlg.ui" line="23"/>
        <location filename="../updownratiodlg.ui" line="33"/>
        <location filename="../updownratiodlg.ui" line="45"/>
        <source>buttonGroup</source>
        <translation>buttonGroup</translation>
    </message>
    <message>
        <location filename="../updownratiodlg.ui" line="30"/>
        <source>Set no ratio limit</source>
        <translation>Sense límits de ràtio</translation>
    </message>
    <message>
        <location filename="../updownratiodlg.ui" line="42"/>
        <source>Set ratio limit to</source>
        <translation>Limitar ràtio a</translation>
    </message>
</context>
<context>
    <name>UsageDisplay</name>
    <message>
        <location filename="../main.cpp" line="73"/>
        <source>Usage:</source>
        <translation>Us:</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="74"/>
        <source>displays program version</source>
        <translation>Mostra la versió del programa</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="76"/>
        <source>disable splash screen</source>
        <translation>Desactivar pantalla d&apos;inici</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="78"/>
        <source>displays this help message</source>
        <translation>Mostra missatge d&apos;ajuda</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="79"/>
        <source>changes the webui port (current: %1)</source>
        <translation>Canviar el port d&apos;IU Web (actual:%1)</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="80"/>
        <source>[files or urls]: downloads the torrents passed by the user (optional)</source>
        <translation>[arxius o URLs] : la descàrrega de torrents necessita aprovació per l&apos;usuari (opcional)</translation>
    </message>
</context>
<context>
    <name>about</name>
    <message>
        <location filename="../about_imp.h" line="51"/>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <location filename="../about_imp.h" line="61"/>
        <source>I would like to thank the following people who volunteered to translate qBittorrent:</source>
        <translation>Vull agrair a les següents persones que voluntàriament van traduir qBittorrent:</translation>
    </message>
    <message>
        <location filename="../about_imp.h" line="93"/>
        <source>Please contact me if you would like to translate qBittorrent into your own language.</source>
        <translation>Si us plau contacta&apos;m si vols traduir qBittorrent al teu propi idioma.</translation>
    </message>
</context>
<context>
    <name>addPeerDialog</name>
    <message>
        <location filename="../properties/peer.ui" line="20"/>
        <source>Peer addition</source>
        <translation>Incorporar Parell</translation>
    </message>
    <message>
        <location filename="../properties/peer.ui" line="36"/>
        <source>IP</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../properties/peer.ui" line="59"/>
        <source>Port</source>
        <translation>Port</translation>
    </message>
</context>
<context>
    <name>addTorrentDialog</name>
    <message>
        <location filename="../torrentadditiondlg.ui" line="14"/>
        <source>Torrent addition dialog</source>
        <translation>Diàleg per afegir un torrent</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="42"/>
        <source>Save path:</source>
        <translation>Directori de destí:</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="62"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="73"/>
        <source>Torrent size:</source>
        <translation>Mida torrent:</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="80"/>
        <location filename="../torrentadditiondlg.ui" line="101"/>
        <source>Unknown</source>
        <translation>Desconegut</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="94"/>
        <source>Free disk space:</source>
        <translation>Espai lliure al Disc:</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="132"/>
        <source>Label:</source>
        <translation>Etiqueta:</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="184"/>
        <source>Torrent content:</source>
        <translation>Contingut del torrent:</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="237"/>
        <source>Select All</source>
        <translation>Selecciona Totes</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="244"/>
        <source>Select None</source>
        <translation>Treure Seleccions</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="266"/>
        <source>Download in sequential order (slower but good for previewing)</source>
        <translation>Descarregar en ordre seqüencial (més lent, però millor per a la vista prèvia)</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="273"/>
        <source>Skip file checking and start seeding immediately</source>
        <translation>Anul-lar verificació i començar a sembrar tot seguit</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="352"/>
        <location filename="../torrentadditiondlg.ui" line="355"/>
        <source>Do not download</source>
        <translation>No descarregar</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="280"/>
        <source>Add to download list in paused state</source>
        <translation>Agregar la llista de descàrregues en estat pausat</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="308"/>
        <source>Add</source>
        <translation>Agregar</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="315"/>
        <source>Cancel</source>
        <translation>Cancel-lar</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="337"/>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="342"/>
        <source>High</source>
        <translation>Alt</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="347"/>
        <source>Maximum</source>
        <translation>Màxima</translation>
    </message>
</context>
<context>
    <name>authentication</name>
    <message>
        <location filename="../login.ui" line="16"/>
        <location filename="../login.ui" line="66"/>
        <source>Tracker authentication</source>
        <translation>Autentificació del Tracker</translation>
    </message>
    <message>
        <location filename="../login.ui" line="94"/>
        <source>Tracker:</source>
        <translation>Tracker:</translation>
    </message>
    <message>
        <location filename="../login.ui" line="127"/>
        <source>Login</source>
        <translation>Autentificar-se</translation>
    </message>
    <message>
        <location filename="../login.ui" line="147"/>
        <source>Username:</source>
        <translation>Usuari:</translation>
    </message>
    <message>
        <location filename="../login.ui" line="176"/>
        <source>Password:</source>
        <translation>Contrasenya:</translation>
    </message>
    <message>
        <location filename="../login.ui" line="219"/>
        <source>Log in</source>
        <translation>Connectar</translation>
    </message>
    <message>
        <location filename="../login.ui" line="226"/>
        <source>Cancel</source>
        <translation>Cancel-lar</translation>
    </message>
</context>
<context>
    <name>confirmDeletionDlg</name>
    <message>
        <location filename="../confirmdeletiondlg.ui" line="20"/>
        <source>Deletion confirmation - qBittorrent</source>
        <translation>Confirmar esborrament - qBittorrent</translation>
    </message>
    <message>
        <location filename="../confirmdeletiondlg.ui" line="47"/>
        <source>Are you sure you want to delete the selected torrents from the transfer list?</source>
        <translation>Segur que vols esborrar els torrents seleccionats de la llista de transferències?</translation>
    </message>
    <message>
        <location filename="../confirmdeletiondlg.ui" line="67"/>
        <source>Remember choice</source>
        <translation>Recordar sempre aquesta elecció</translation>
    </message>
    <message>
        <location filename="../confirmdeletiondlg.ui" line="94"/>
        <source>Also delete the files on the hard disk</source>
        <translation>Esborrar també l&apos;arxiu del disc físic</translation>
    </message>
</context>
<context>
    <name>createTorrentDialog</name>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="291"/>
        <source>Cancel</source>
        <translation>Cancel-lar</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="14"/>
        <source>Torrent Creation Tool</source>
        <translation>Eina de creació de Torrent</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="43"/>
        <source>Torrent file creation</source>
        <translation>Creació d&apos;arxiu torrent</translation>
    </message>
    <message>
        <source>Announce urls (trackers):</source>
        <translation type="obsolete">Url&apos;s d&apos;anunci (trackers):</translation>
    </message>
    <message>
        <source>Comment (optional):</source>
        <translation type="obsolete">Comentari (opcional):</translation>
    </message>
    <message>
        <source>Web seeds urls (optional):</source>
        <translation type="obsolete">Url&apos;s de llavors web (opcional):</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="53"/>
        <source>File or folder to add to the torrent:</source>
        <translation>Arxiu o carpeta a agregar al torrent:</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="65"/>
        <source>Add file</source>
        <translation>Nou arxius</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="72"/>
        <source>Add folder</source>
        <translation>Nova carpeta</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="83"/>
        <source>Tracker URLs:</source>
        <translation>Tracker URLs:</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="93"/>
        <source>Web seeds urls:</source>
        <translation>Llavors web urls:</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="103"/>
        <source>Comment:</source>
        <translation>Comentari:</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="150"/>
        <source>Piece size:</source>
        <translation>Mida de la peça:</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="167"/>
        <source>32 KiB</source>
        <translation>32 KiB</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="172"/>
        <source>64 KiB</source>
        <translation>64 KiB</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="177"/>
        <source>128 KiB</source>
        <translation>128 KiB</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="182"/>
        <source>256 KiB</source>
        <translation>256 KiB</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="187"/>
        <source>512 KiB</source>
        <translation>512 KiB</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="192"/>
        <source>1 MiB</source>
        <translation>1 MiB</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="197"/>
        <source>2 MiB</source>
        <translation>2 MiB</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="202"/>
        <source>4 MiB</source>
        <translation>4 MiB</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="210"/>
        <source>Auto</source>
        <translation>Auto</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="235"/>
        <source>Private (won&apos;t be distributed on DHT network if enabled)</source>
        <translation>Privat (no es distribuirà per xarxa DHT si s&apos;habilita)</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="242"/>
        <source>Start seeding after creation</source>
        <translation>Començar amb la sembra després de la creació</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="284"/>
        <source>Create and save...</source>
        <translation>Crear i guardar...</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="249"/>
        <source>Progress:</source>
        <translation>Progrés:</translation>
    </message>
</context>
<context>
    <name>createtorrent</name>
    <message>
        <source>Select destination torrent file</source>
        <translation type="obsolete">Selecciona una destí per a l&apos;arxiu torrent</translation>
    </message>
    <message>
        <source>Torrent Files</source>
        <translation type="obsolete">Arxiu Torrent</translation>
    </message>
    <message>
        <source>No input path set</source>
        <translation type="obsolete">Sense ruta de destí establerta</translation>
    </message>
    <message>
        <source>Please type an input path first</source>
        <translation type="obsolete">Si us plau escriu primer una ruta d&apos;entrada</translation>
    </message>
    <message>
        <source>Torrent creation</source>
        <translation type="obsolete">Crear Torrent</translation>
    </message>
    <message>
        <source>Torrent was created successfully:</source>
        <translation type="obsolete">El Torrent es va crear amb èxit:</translation>
    </message>
    <message>
        <source>Select a folder to add to the torrent</source>
        <translation type="obsolete">Selecciona una altra carpeta per agregar el torrent</translation>
    </message>
    <message>
        <source>Please type an announce URL</source>
        <translation type="obsolete">Si us plau escriu una URL d&apos;anunci</translation>
    </message>
    <message>
        <source>Torrent creation was unsuccessful, reason: %1</source>
        <translation type="obsolete">La creació del torrent no ha estat reeixida, raó: %1</translation>
    </message>
    <message>
        <source>Announce URL:</source>
        <comment>Tracker URL</comment>
        <translation type="obsolete">URL d&apos;anunci:</translation>
    </message>
    <message>
        <source>Please type a web seed url</source>
        <translation type="obsolete">Si us plau escriu una url de llavor web</translation>
    </message>
    <message>
        <source>Web seed URL:</source>
        <translation type="obsolete">URL de llavor web:</translation>
    </message>
    <message>
        <source>Select a file to add to the torrent</source>
        <translation type="obsolete">Seleccioni un altre arxiu per agregar el torrent</translation>
    </message>
    <message>
        <source>Created torrent file is invalid. It won&apos;t be added to download list.</source>
        <translation type="obsolete">La creació de l&apos;arxiu torrent no és vàlida. No s&apos;afegirà a la llista de descàrregues.</translation>
    </message>
</context>
<context>
    <name>downloadFromURL</name>
    <message>
        <source>Download Torrents from URLs</source>
        <translation type="obsolete">Descarregar torrents de URLs</translation>
    </message>
    <message>
        <source>Only one URL per line</source>
        <translation type="obsolete">Sol una URL per línia</translation>
    </message>
    <message>
        <location filename="../downloadfromurldlg.ui" line="45"/>
        <source>Add torrent links</source>
        <translation>Afegir enllaç torrent</translation>
    </message>
    <message>
        <location filename="../downloadfromurldlg.ui" line="78"/>
        <source>Both HTTP and Magnet links are supported</source>
        <translation>Els dos HTTP i Magnet links són suportats</translation>
    </message>
    <message>
        <location filename="../downloadfromurldlg.ui" line="106"/>
        <source>Download</source>
        <translation>Descarregar</translation>
    </message>
    <message>
        <location filename="../downloadfromurldlg.ui" line="113"/>
        <source>Cancel</source>
        <translation>Cancel-lar</translation>
    </message>
    <message>
        <location filename="../downloadfromurldlg.ui" line="14"/>
        <source>Download from urls</source>
        <translation>Descarregar d&apos;urls</translation>
    </message>
    <message>
        <location filename="../downloadfromurldlg.h" line="78"/>
        <source>No URL entered</source>
        <translation>No s&apos;ha escrit cap URL</translation>
    </message>
    <message>
        <location filename="../downloadfromurldlg.h" line="78"/>
        <source>Please type at least one URL.</source>
        <translation>Si us plau escriu almenys una URL.</translation>
    </message>
</context>
<context>
    <name>downloadThread</name>
    <message>
        <source>I/O Error</source>
        <translation type="obsolete">Error d&apos;Entrada/Sortida</translation>
    </message>
    <message>
        <source>The remote host name was not found (invalid hostname)</source>
        <translation type="obsolete">El nom host no s&apos;ha trobat (nom host no vàlid)</translation>
    </message>
    <message>
        <source>The operation was canceled</source>
        <translation type="obsolete">L&apos;operació va ser cancel-lada</translation>
    </message>
    <message>
        <source>The remote server closed the connection prematurely, before the entire reply was received and processed</source>
        <translation type="obsolete">El servidor remot va tancar la connexió abans de temps, abans que fos rebut i processat</translation>
    </message>
    <message>
        <source>The connection to the remote server timed out</source>
        <translation type="obsolete">Connexió amb el servidor remot fallida, Temps d&apos;espera esgotat</translation>
    </message>
    <message>
        <source>SSL/TLS handshake failed</source>
        <translation type="obsolete">SSL/TLS handshake fallida</translation>
    </message>
    <message>
        <source>The remote server refused the connection</source>
        <translation type="obsolete">El servidor remot va rebutjar la connexió</translation>
    </message>
    <message>
        <source>The connection to the proxy server was refused</source>
        <translation type="obsolete">La connexió amb el servidor proxy va ser rebutjada</translation>
    </message>
    <message>
        <source>The proxy server closed the connection prematurely</source>
        <translation type="obsolete">Connexió tancada abans de temps pel servidor proxy</translation>
    </message>
    <message>
        <source>The proxy host name was not found</source>
        <translation type="obsolete">El nom host del proxy  no s&apos;ha trobat</translation>
    </message>
    <message>
        <source>The connection to the proxy timed out or the proxy did not reply in time to the request sent</source>
        <translation type="obsolete">La connexió amb el servidor proxy  s&apos;ha esgotat, o el proxy no va respondre a temps a la sol-licitud enviada</translation>
    </message>
    <message>
        <source>The proxy requires authentication in order to honour the request but did not accept any credentials offered</source>
        <translation type="obsolete">El proxy requereix autenticació a fi d&apos;atendre la sol-licitud, però no va acceptar les credencials que va oferir</translation>
    </message>
    <message>
        <source>The access to the remote content was denied (401)</source>
        <translation type="obsolete">L&apos;accés al contingut remot ha estat rebutjat (401)</translation>
    </message>
    <message>
        <source>The operation requested on the remote content is not permitted</source>
        <translation type="obsolete">L&apos;operació sol-licitada en el contingut remot no està permesa</translation>
    </message>
    <message>
        <source>The remote content was not found at the server (404)</source>
        <translation type="obsolete">El contingut remot no es troba al servidor (404)</translation>
    </message>
    <message>
        <source>The remote server requires authentication to serve the content but the credentials provided were not accepted</source>
        <translation type="obsolete">El servidor remot requereix autenticació per servir el contingut, però les credencials proporcionades no són correctes</translation>
    </message>
    <message>
        <source>The Network Access API cannot honor the request because the protocol is not known</source>
        <translation type="obsolete">Protocol desconegut</translation>
    </message>
    <message>
        <source>The requested operation is invalid for this protocol</source>
        <translation type="obsolete">L&apos;operació sol-licitada no és vàlida per a aquest protocol</translation>
    </message>
    <message>
        <source>An unknown network-related error was detected</source>
        <translation type="obsolete">Error de Xarxa desconegut</translation>
    </message>
    <message>
        <source>An unknown proxy-related error was detected</source>
        <translation type="obsolete">Error de Proxy desconegut</translation>
    </message>
    <message>
        <source>An unknown error related to the remote content was detected</source>
        <translation type="obsolete">Error desconegut al servidor remot</translation>
    </message>
    <message>
        <source>A breakdown in protocol was detected</source>
        <translation type="obsolete">Error de protocol</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation type="obsolete">Error desconegut</translation>
    </message>
</context>
<context>
    <name>engineSelect</name>
    <message>
        <location filename="../searchengine/engineselect.ui" line="17"/>
        <source>Search plugins</source>
        <translation>Cerca plugins</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="30"/>
        <source>Installed search engines:</source>
        <translation>Motors de cerca instal-lats:</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="50"/>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="55"/>
        <source>Url</source>
        <translation>Url</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="60"/>
        <location filename="../searchengine/engineselect.ui" line="119"/>
        <source>Enabled</source>
        <translation>Habilitat</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="78"/>
        <source>You can get new search engine plugins here: &lt;a href=&quot;http://plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</source>
        <translation>Pots obtenir nous plugins de motors de cerca aquí &lt;a href=&quot;http:plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="93"/>
        <source>Install a new one</source>
        <translation>Instal-lar-ne un de nou</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="100"/>
        <source>Check for updates</source>
        <translation>Cerca actualitzacions</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="107"/>
        <source>Close</source>
        <translation>Tancar</translation>
    </message>
    <message>
        <source>Enable</source>
        <translation type="obsolete">Habilitar</translation>
    </message>
    <message>
        <source>Disable</source>
        <translation type="obsolete">Deshabilitar</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="124"/>
        <source>Uninstall</source>
        <translation>Desinstal-lar</translation>
    </message>
</context>
<context>
    <name>engineSelectDlg</name>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="174"/>
        <source>Uninstall warning</source>
        <translation>Alerta de desinstal-lació</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="174"/>
        <source>Some plugins could not be uninstalled because they are included in qBittorrent.
 Only the ones you added yourself can be uninstalled.
However, those plugins were disabled.</source>
        <translation>Alguns plugins no van poder ser instal-lats perquè estan inclosos en qBittorrent.
Només els que has agregat per tí mateix poden ser desinstal-lats.
De qualsevol manera, aquests plugins van ser deshabilitats.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="176"/>
        <source>Uninstall success</source>
        <translation>Desinstal-lació correcta</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="340"/>
        <source>Select search plugins</source>
        <translation>Seleccioni els plugins de recerca</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="341"/>
        <source>qBittorrent search plugins</source>
        <translation>Plugins de de recerca qBittorrent</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="237"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="262"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="267"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="276"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="279"/>
        <source>Search plugin install</source>
        <translation>Instal-lar plugin de recerca</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="117"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="188"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="299"/>
        <source>Yes</source>
        <translation>Sí</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="120"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="154"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="191"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="302"/>
        <source>No</source>
        <translation>No</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="237"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="262"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="267"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="276"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="279"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="393"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="426"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="447"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="454"/>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="237"/>
        <source>A more recent version of %1 search engine plugin is already installed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>Una versió més recent del plugin de motor de cerca %1 ja està instal-lada.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="393"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="426"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="447"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="454"/>
        <source>Search plugin update</source>
        <translation>Actualització del plugin de recerca</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="426"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="447"/>
        <source>Sorry, update server is temporarily unavailable.</source>
        <translation>Ho sento, el servidor d&apos;actualització aquesta temporalment no disponible.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="393"/>
        <source>All your plugins are already up to date.</source>
        <translation>Tots els teus plugins ja estan actualitzats.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="262"/>
        <source>%1 search engine plugin could not be updated, keeping old version.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>El plugin de motor de cerca %1 no va poder ser actualitzat, es mantindrà la versió antiga.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="267"/>
        <source>%1 search engine plugin could not be installed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>El plugin de motor de cerca %1 no va poder ser instal-lat.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="176"/>
        <source>All selected plugins were uninstalled successfully</source>
        <translation>Tots els plugins seleccionats van ser instal-lats reeixidament</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="276"/>
        <source>%1 search engine plugin was successfully updated.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>El plugin de motor de cerca %1 va ser actualitzat reeixidament.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="279"/>
        <source>%1 search engine plugin was successfully installed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>El plugin de motor de cerca %1 va ser instal-lat reeixidament.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="454"/>
        <source>Sorry, %1 search plugin install failed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>Ho lamento, la instal-lació del plugin de recerca %1 ha fallat.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="329"/>
        <source>New search engine plugin URL</source>
        <translation>URL del nou plugin  de motor de cerca</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="330"/>
        <source>URL:</source>
        <translation>URL:</translation>
    </message>
</context>
<context>
    <name>misc</name>
    <message>
        <location filename="../misc.cpp" line="307"/>
        <source>qBittorrent will shutdown the computer now because all downloads are complete.</source>
        <translation>qBittorrent tancarà l&apos;equip ara, perquè totes les baixades s&apos;han completat.</translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="85"/>
        <source>B</source>
        <comment>bytes</comment>
        <translation>B</translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="86"/>
        <source>KiB</source>
        <comment>kibibytes (1024 bytes)</comment>
        <translation>KiB</translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="87"/>
        <source>MiB</source>
        <comment>mebibytes (1024 kibibytes)</comment>
        <translation>MiB</translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="88"/>
        <source>GiB</source>
        <comment>gibibytes (1024 mibibytes)</comment>
        <translation>GiB</translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="89"/>
        <source>TiB</source>
        <comment>tebibytes (1024 gibibytes)</comment>
        <translation>TiB</translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="755"/>
        <source>%1h %2m</source>
        <comment>e.g: 3hours 5minutes</comment>
        <translation></translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="760"/>
        <source>%1d %2h</source>
        <comment>e.g: 2days 10hours</comment>
        <translation></translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="695"/>
        <location filename="../misc.cpp" line="700"/>
        <location filename="../misc.cpp" line="704"/>
        <location filename="../misc.cpp" line="707"/>
        <location filename="../misc.cpp" line="712"/>
        <location filename="../misc.cpp" line="715"/>
        <source>Unknown</source>
        <translation>Desconocido</translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="583"/>
        <source>Unknown</source>
        <comment>Unknown (size)</comment>
        <translation>Desconegut</translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="746"/>
        <source>&lt; 1m</source>
        <comment>&lt; 1 minute</comment>
        <translation>&lt;1m</translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="750"/>
        <source>%1m</source>
        <comment>e.g: 10minutes</comment>
        <translation>%1m</translation>
    </message>
</context>
<context>
    <name>options_imp</name>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1090"/>
        <location filename="../preferences/options_imp.cpp" line="1092"/>
        <location filename="../preferences/options_imp.cpp" line="1107"/>
        <location filename="../preferences/options_imp.cpp" line="1109"/>
        <source>Choose a save directory</source>
        <translation>Seleccioni un directori per guardar</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1012"/>
        <source>Add directory to scan</source>
        <translation>Afegir directori per escanejar</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1018"/>
        <source>Folder is already being watched.</source>
        <translation>Aquesta carpeta ja està seleccionada per escanejar.</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1021"/>
        <source>Folder does not exist.</source>
        <translation>La carpeta no existeix.</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1024"/>
        <source>Folder is not readable.</source>
        <translation>La carpeta no és llegible.</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1032"/>
        <source>Failure</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1032"/>
        <source>Failed to add Scan Folder &apos;%1&apos;: %2</source>
        <translation>No es pot escanejar aquesta carpetes &apos;%1&apos;:%2</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1055"/>
        <location filename="../preferences/options_imp.cpp" line="1057"/>
        <source>Choose export directory</source>
        <translation>Seleccioni directori d&apos;exportació</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1072"/>
        <location filename="../preferences/options_imp.cpp" line="1074"/>
        <source>Choose an ip filter file</source>
        <translation>Seleccioni un arxiu de filtre d&apos;ip</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1072"/>
        <location filename="../preferences/options_imp.cpp" line="1074"/>
        <source>Filters</source>
        <translation>Filtres</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1152"/>
        <source>SSL Certificate (*.crt *.pem)</source>
        <translation>Certificat SSL (*.crt *.pem)</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1163"/>
        <source>SSL Key (*.key *.pem)</source>
        <translation>Clau SSL (*.key *.pem)</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1194"/>
        <source>Parsing error</source>
        <translation>Error d&apos;anàlisi</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1194"/>
        <source>Failed to parse the provided IP filter</source>
        <translation>No s&apos;ha pogut analitzar el filtratge IP</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1196"/>
        <source>Successfully refreshed</source>
        <translation>Actualitzat amb èxit</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1263"/>
        <source>Invalid key</source>
        <translation>Clau no vàlida</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1263"/>
        <source>This is not a valid SSL key.</source>
        <translation>Aquesta no és una clau SSL vàlida.</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1278"/>
        <source>Invalid certificate</source>
        <translation>Certificat no vàlid</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1278"/>
        <source>This is not a valid SSL certificate.</source>
        <translation>Aquest no és un Certificat SSL vàlid.</translation>
    </message>
    <message>
        <source>Succesfully refreshed</source>
        <translation type="obsolete">Actualitzat amb èxit</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1196"/>
        <source>Successfuly parsed the provided IP filter: %1 rules were applied.</source>
        <comment>%1 is a number</comment>
        <translation>Anàlisi reeixit del filtrat IP: %1 normes aplicades.</translation>
    </message>
</context>
<context>
    <name>pluginSourceDlg</name>
    <message>
        <location filename="../searchengine/pluginsource.ui" line="13"/>
        <source>Plugin source</source>
        <translation>Font del plugin</translation>
    </message>
    <message>
        <location filename="../searchengine/pluginsource.ui" line="26"/>
        <source>Search plugin source:</source>
        <translation>Font del plugin de recerca:</translation>
    </message>
    <message>
        <location filename="../searchengine/pluginsource.ui" line="35"/>
        <source>Local file</source>
        <translation>Arxiu local</translation>
    </message>
    <message>
        <location filename="../searchengine/pluginsource.ui" line="42"/>
        <source>Web link</source>
        <translation>Vincle web</translation>
    </message>
</context>
<context>
    <name>preview</name>
    <message>
        <location filename="../preview.ui" line="16"/>
        <source>Preview selection</source>
        <translation>Selecció de vista prèvia</translation>
    </message>
    <message>
        <location filename="../preview.ui" line="51"/>
        <source>File preview</source>
        <translation>Vista prèvia d&apos;arxiu</translation>
    </message>
    <message>
        <location filename="../preview.ui" line="67"/>
        <source>The following files support previewing, &lt;br&gt;please select one of them:</source>
        <translation>Els següents arxius suporten vista prèvia, &lt;br&gt;por favor seleccioni un d&apos;ells:</translation>
    </message>
    <message>
        <location filename="../preview.ui" line="101"/>
        <source>Preview</source>
        <translation>Vista prèvia</translation>
    </message>
    <message>
        <location filename="../preview.ui" line="108"/>
        <source>Cancel</source>
        <translation>Cancel-lar</translation>
    </message>
</context>
<context>
    <name>previewSelect</name>
    <message>
        <source>Preview impossible</source>
        <translation type="obsolete">Impossible vista prèvia</translation>
    </message>
    <message>
        <source>Sorry, we can&apos;t preview this file</source>
        <translation type="obsolete">Ho sento, no es pot realitzar una vista prèvia d&apos;aquest arxiu</translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="obsolete">Nom</translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="obsolete">Mida</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation type="obsolete">Progrés</translation>
    </message>
</context>
<context>
    <name>search_engine</name>
    <message>
        <location filename="../searchengine/search.ui" line="14"/>
        <location filename="../searchengine/search.ui" line="44"/>
        <source>Search</source>
        <translation>Cerca</translation>
    </message>
    <message>
        <location filename="../searchengine/search.ui" line="67"/>
        <source>Status:</source>
        <translation>Estat:</translation>
    </message>
    <message>
        <location filename="../searchengine/search.ui" line="91"/>
        <source>Stopped</source>
        <translation>Detingut</translation>
    </message>
    <message>
        <location filename="../searchengine/search.ui" line="135"/>
        <source>Download</source>
        <translation>Descarregar</translation>
    </message>
    <message>
        <location filename="../searchengine/search.ui" line="145"/>
        <source>Go to description page</source>
        <translation>Pàgina de descripció</translation>
    </message>
    <message>
        <location filename="../searchengine/search.ui" line="165"/>
        <source>Search engines...</source>
        <translation>Motors de cerca...</translation>
    </message>
</context>
<context>
    <name>torrentAdditionDialog</name>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="241"/>
        <location filename="../torrentadditiondlg.cpp" line="244"/>
        <source>Unable to decode torrent file:</source>
        <translation>Impossible descodificar l&apos;arxiu torrent:</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="516"/>
        <location filename="../torrentadditiondlg.cpp" line="531"/>
        <location filename="../torrentadditiondlg.cpp" line="533"/>
        <source>Choose save path</source>
        <translation>Escollir directori de destí</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="199"/>
        <source>Unable to decode magnet link:</source>
        <translation>No es pot descodificar l&apos;enllaç magnet:</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="205"/>
        <source>Magnet Link</source>
        <translation>Enllaç magnet</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="337"/>
        <source>Rename...</source>
        <translation>Rebatejar...</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="381"/>
        <source>Rename the file</source>
        <translation>Rebatejar arxiu</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="382"/>
        <source>New name:</source>
        <translation>Nou nom:</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="386"/>
        <location filename="../torrentadditiondlg.cpp" line="416"/>
        <source>The file could not be renamed</source>
        <translation>No es pot canviar el nom d&apos;arxiu</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="387"/>
        <source>This file name contains forbidden characters, please choose a different one.</source>
        <translation>El nom introduït conté caràcters prohibits, si us plau n&apos;elegeixi un altre.</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="417"/>
        <location filename="../torrentadditiondlg.cpp" line="451"/>
        <source>This name is already in use in this folder. Please use a different name.</source>
        <translation>Aquest nom ja està en ús. Si us plau, usi un nom diferent.</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="450"/>
        <source>The folder could not be renamed</source>
        <translation>No es pot canviar el nom d&apos;arxiu</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="498"/>
        <source>(%1 left after torrent download)</source>
        <comment>e.g. (100MiB left after torrent download)</comment>
        <translation>(%1 disponible després de descarregar el torrent)</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="501"/>
        <source>(%1 more are required to download)</source>
        <comment>e.g. (100MiB more are required to download)</comment>
        <translation>(Es necessiten més %1)</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="586"/>
        <source>Empty save path</source>
        <translation>Ruta de destí buida</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="586"/>
        <source>Please enter a save path</source>
        <translation>Si us plau introdueixi un directori de destí</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="665"/>
        <source>Save path creation error</source>
        <translation>Error en la creació del directori de destí</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="665"/>
        <source>Could not create the save path</source>
        <translation>Impossible crear el directori de destí</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="607"/>
        <source>Invalid label name</source>
        <translation>Nom d&apos;Etiqueta no vàlid</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="607"/>
        <source>Please don&apos;t use any special characters in the label name.</source>
        <translation>Si us plau, no utilitzi caràcters especials per al nom de l&apos;Etiqueta.</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="650"/>
        <source>Seeding mode error</source>
        <translation>Error en la Sembra</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="650"/>
        <source>You chose to skip file checking. However, local files do not seem to exist in the current destionation folder. Please disable this feature or update the save path.</source>
        <translation>Vostè ha decidit ignorar la verificació d&apos;arxius. Tanmateix, els arxius locals no semblen existir a la carpeta de destí actual. Si us plau, desactivi aquesta funció o actualitzi la ruta de destinació.</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="657"/>
        <source>Invalid file selection</source>
        <translation>Selecció d&apos;arxiu invàlida</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="657"/>
        <source>You must select at least one file in the torrent</source>
        <translation>Ha de seleccionar almenys un arxiu torrent</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="341"/>
        <source>Priority</source>
        <translation>Prioritat</translation>
    </message>
</context>
</TS>
