<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="de">
<context>
    <name>AboutDlg</name>
    <message>
        <location filename="../about.ui" line="21"/>
        <source>About qBittorrent</source>
        <translation>Über qBittorrent</translation>
    </message>
    <message>
        <location filename="../about.ui" line="83"/>
        <source>About</source>
        <translation>Info</translation>
    </message>
    <message utf8="true">
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;A Bittorrent client programmed in C++, based on Qt4 toolkit &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;and libtorrent-rasterbar. &lt;br /&gt;&lt;br /&gt;Copyright ©2006-2010 Christophe Dumez&lt;br /&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Home Page:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://www.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;http://www.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Forum:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://forum.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;http://forum.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;IRC:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; #qbittorrent on Freenode&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;Ein Bittorrent Client programmiert in C++, basierend auf dem Qt4 Toolkit &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;und libtorrent-rasterbar. &lt;br /&gt;&lt;br /&gt;Copyright ©2006-2010 Christophe Dumez&lt;br /&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Home Page:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://www.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;http://www.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Forum:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://forum.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;http://forum.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;IRC:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; #qbittorrent auf Freenode&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../about.ui" line="134"/>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
    <message>
        <location filename="../about.ui" line="157"/>
        <source>Name:</source>
        <translation>Name:</translation>
    </message>
    <message>
        <location filename="../about.ui" line="195"/>
        <source>Country:</source>
        <translation>Land:</translation>
    </message>
    <message>
        <location filename="../about.ui" line="220"/>
        <source>E-mail:</source>
        <translation>E-mail:</translation>
    </message>
    <message>
        <location filename="../about.ui" line="164"/>
        <source>Christophe Dumez</source>
        <translation>Christophe Dumez</translation>
    </message>
    <message utf8="true">
        <location filename="../about.ui" line="105"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;An advanced BitTorrent client programmed in C++, based on Qt4 toolkit and libtorrent-rasterbar. &lt;br /&gt;&lt;br /&gt;Copyright ©2006-2011 Christophe Dumez&lt;br /&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Home Page:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://www.qbittorrent.org&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans&apos;; text-decoration: underline; color:#0057ae;&quot;&gt;http://www.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Bug Tracker:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://bugs.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;http://bugs.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Forum:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://forum.qbittorrent.org&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans&apos;; text-decoration: underline; color:#0057ae;&quot;&gt;http://forum.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;IRC:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; #qbittorrent on Freenode&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../about.ui" line="202"/>
        <source>France</source>
        <translation>Frankreich</translation>
    </message>
    <message>
        <location filename="../about.ui" line="264"/>
        <source>Translation</source>
        <translation>Übersetzung</translation>
    </message>
    <message>
        <location filename="../about.ui" line="281"/>
        <source>License</source>
        <translation>Lizenz</translation>
    </message>
    <message>
        <location filename="../about.ui" line="54"/>
        <source>&lt;h3&gt;&lt;b&gt;qBittorrent&lt;/b&gt;&lt;/h3&gt;</source>
        <translation>&lt;h3&gt;&lt;b&gt;qBittorrent&lt;/b&gt;&lt;/h3&gt;</translation>
    </message>
    <message>
        <location filename="../about.ui" line="227"/>
        <source>chris@qbittorrent.org</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../about.ui" line="251"/>
        <source>Thanks to</source>
        <translation>Dank an</translation>
    </message>
</context>
<context>
    <name>AdvancedSettings</name>
    <message>
        <source>Property</source>
        <translation type="obsolete">Eigenschaft</translation>
    </message>
    <message>
        <source>Value</source>
        <translation type="obsolete">Wert</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="160"/>
        <source>Disk write cache size</source>
        <translation>Größe des Plattencache zum schreiben</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="159"/>
        <source> MiB</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="50"/>
        <source>Setting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="50"/>
        <source>Value</source>
        <comment>Value set for this setting</comment>
        <translation type="unfinished">Wert</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="165"/>
        <source>Outgoing ports (Min) [0: Disabled]</source>
        <translation>Ausgehende Ports (Min) [0: Deaktiviert]</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="170"/>
        <source>Outgoing ports (Max) [0: Disabled]</source>
        <translation>Ausgehende Ports (Max) [0: Deaktiviert]</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="173"/>
        <source>Ignore transfer limits on local network</source>
        <translation>Transferlimits im lokalen Netzwerk ignorieren</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="240"/>
        <source>Exchange trackers with other peers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Include TCP/IP overhead in transfer limits</source>
        <translation type="obsolete">TCP/IP Overhead in Transferlimits einbeziehen</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="176"/>
        <source>Recheck torrents on completion</source>
        <translation>Torrents nach Abschluss der Übertragung erneut prüfen</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="182"/>
        <source>Transfer list refresh interval</source>
        <translation>Intervall zum Auffrischen der Transfer-Liste</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="181"/>
        <source> ms</source>
        <comment> milliseconds</comment>
        <translation></translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="185"/>
        <source>Resolve peer countries (GeoIP)</source>
        <translation>Herkunftsländer der Peers auflösen (GeoIP)</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="188"/>
        <source>Resolve peer host names</source>
        <translation>Hostnamen der Peers auflösen</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="193"/>
        <source>Maximum number of half-open connections [0: Disabled]</source>
        <translation>Maximale Anzahl halboffener Verbindungen [0: Deaktiviert]</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="200"/>
        <source>Strict super seeding</source>
        <translation>Striktes Super Seeding</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="212"/>
        <source>Network Interface (requires restart)</source>
        <translation>Netzwerk Interface (Neustart benötigt)</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="202"/>
        <source>Any interface</source>
        <comment>i.e. Any network interface</comment>
        <translation>Beliebiges Interface</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="215"/>
        <source>IP Address to report to trackers (requires restart)</source>
        <translation>IP Adresse die bei Trackern angegeben werden soll (Neustart benötigtr)</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="218"/>
        <source>Display program on-screen notifications</source>
        <translation type="unfinished">Benachrichtigungen auf dem Bildschirm anzeigen</translation>
    </message>
    <message>
        <source>Display program notification balloons</source>
        <translation type="obsolete">Zeige Benachrichtigungssprechblasen</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="221"/>
        <source>Enable embedded tracker</source>
        <translation>Eingebetteten Tracker aktivieren</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="226"/>
        <source>Embedded tracker port</source>
        <translation>Port des eingebetteten Trackers</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="229"/>
        <source>Check for software updates</source>
        <translation>Auf Software-Updates prüfen</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="233"/>
        <source>Use system icon theme</source>
        <translation>System-Icon-Theme benutzen</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="237"/>
        <source>Confirm torrent deletion</source>
        <translation>Löschen des Torrents bestätigen</translation>
    </message>
</context>
<context>
    <name>AutomatedRssDownloader</name>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="14"/>
        <source>Automated RSS Downloader</source>
        <translation>Automatisierter RSS Downloader</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="26"/>
        <source>Enable the automated RSS downloader</source>
        <translation>Automatisierten RSS Downloader aktivieren</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="48"/>
        <source>Download rules</source>
        <translation>Downloadregeln</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="123"/>
        <source>Rule definition</source>
        <translation>Regeldefinition</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="138"/>
        <source>Must contain:</source>
        <translation>Enthält:</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="180"/>
        <source>Must not contain:</source>
        <translation>Enthält nicht:</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="129"/>
        <source>Use regular expressions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="355"/>
        <source>Import...</source>
        <translation>Import...</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="362"/>
        <source>Export...</source>
        <translation>Export...</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="286"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="233"/>
        <source>Assign label:</source>
        <translation>Label zuweisen:</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="252"/>
        <source>Save to a different directory</source>
        <translation>In ein anderes Verzeicnis speichern</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="264"/>
        <source>Save to:</source>
        <translation>Speichern in:</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="308"/>
        <source>Apply rule to feeds:</source>
        <translation>Regeln auf Feeds anwenden:</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="330"/>
        <source>Matching RSS articles</source>
        <translation>Übereinstimmende RSS Artikel</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="304"/>
        <source>New rule name</source>
        <translation>Neuer Regelname</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="304"/>
        <source>Please type the name of the new download rule.</source>
        <translation>Bitte geben Sie einen neuen Namen für die Downloadregel ein.</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="308"/>
        <location filename="../rss/automatedrssdownloader.cpp" line="423"/>
        <source>Rule name conflict</source>
        <translation>Namenskonflikt</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="308"/>
        <location filename="../rss/automatedrssdownloader.cpp" line="423"/>
        <source>A rule with this name already exists, please choose another name.</source>
        <translation>Eine Regel mit diesem Namen existiert bereits, bitte wählen SIe einen anderen Namen.</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="326"/>
        <source>Are you sure you want to remove the download rule named %1?</source>
        <translation>Sind Sie sicher, daß Sie die Downloadregel &apos;%1&apos; entfernen möchten?</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="328"/>
        <source>Are you sure you want to remove the selected download rules?</source>
        <translation>Sind Sie sicher, daß Sie die ausgewählten Downloadregeln entfernen möchten?</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="329"/>
        <source>Rule deletion confirmation</source>
        <translation>Löschen der Regel bestätigen</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="345"/>
        <source>Destination directory</source>
        <translation>Zielverzeichnis</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="353"/>
        <source>Invalid action</source>
        <translation>Ungültige Aktion</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="353"/>
        <source>The list is empty, there is nothing to export.</source>
        <translation>Die Liste ist leer, es gibt nichts zu exportieren.</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="357"/>
        <source>Where would you like to save the list?</source>
        <translation>Wohin möchten Sie die Liste speichern?</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="357"/>
        <source>Rules list (*.rssrules)</source>
        <translation>Regelliste (*.rssrules)</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="362"/>
        <source>I/O Error</source>
        <translation>I/O Fehler</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="362"/>
        <source>Failed to create the destination file</source>
        <translation>Fehler beim Erstellen des Zielverzeichnisses</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="370"/>
        <source>Please point to the RSS download rules file</source>
        <translation>Bitte geben Sie die RSS-Downloadregeldatei an</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="370"/>
        <source>Rules list (*.rssrules *.filters)</source>
        <translation>Regel-Liste (*.rssrules *.filters)</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="374"/>
        <source>Import Error</source>
        <translation>Fehler beim Import</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="374"/>
        <source>Failed to import the selected rules file</source>
        <translation>Import der ausgewählten Regeldatei fehlgeschlagen</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="385"/>
        <source>Add new rule...</source>
        <translation>Neue Regel hinzufügen...</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="391"/>
        <source>Delete rule</source>
        <translation>Regel löschen</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="393"/>
        <source>Rename rule...</source>
        <translation>Regel umbenennen...</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="395"/>
        <source>Delete selected rules</source>
        <translation>Ausgewählte Regeln löschen</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="419"/>
        <source>Rule renaming</source>
        <translation>Regelumbenennung</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="419"/>
        <source>Please type the new rule name</source>
        <translation>Bitte geben Sie einen neuen Namen für die Regel ein</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="521"/>
        <source>Regex mode: use Perl-like regular expressions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="525"/>
        <source>Wildcard mode: you can use&lt;ul&gt;&lt;li&gt;? to match any single character&lt;/li&gt;&lt;li&gt;* to match zero or more of any characters&lt;/li&gt;&lt;li&gt;Whitespaces count as AND operators&lt;/li&gt;&lt;/ul&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="527"/>
        <source>Wildcard mode: you can use&lt;ul&gt;&lt;li&gt;? to match any single character&lt;/li&gt;&lt;li&gt;* to match zero or more of any characters&lt;/li&gt;&lt;li&gt;| is used as OR operator&lt;/li&gt;&lt;/ul&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Bittorrent</name>
    <message>
        <source>%1 reached the maximum ratio you set.</source>
        <translation type="obsolete">%1 hat das gesetzte maximale Verhältnis erreicht.</translation>
    </message>
    <message>
        <source>Removing torrent %1...</source>
        <translation type="obsolete">Entferne Torrent %1...</translation>
    </message>
    <message>
        <source>Pausing torrent %1...</source>
        <translation type="obsolete">Pausiere Torret %1...</translation>
    </message>
    <message>
        <source>qBittorrent is bound to port: TCP/%1</source>
        <comment>e.g: qBittorrent is bound to port: 6881</comment>
        <translation type="obsolete">qBittorrent lauscht auf Port: TCP/%1</translation>
    </message>
    <message>
        <source>UPnP support [ON]</source>
        <translation type="obsolete">UPNP Unterstützung [EIN]</translation>
    </message>
    <message>
        <source>UPnP support [OFF]</source>
        <translation type="obsolete">UPnP Unterstützung [AUS]</translation>
    </message>
    <message>
        <source>NAT-PMP support [ON]</source>
        <translation type="obsolete">NAT-PMP Unterstützung [EIN]</translation>
    </message>
    <message>
        <source>NAT-PMP support [OFF]</source>
        <translation type="obsolete">NAT-PMP Unterstützung [AUS]</translation>
    </message>
    <message>
        <source>HTTP user agent is %1</source>
        <translation type="obsolete">HTTP Benutzerprogramm ist %1</translation>
    </message>
    <message>
        <source>Using a disk cache size of %1 MiB</source>
        <translation type="obsolete">Verwende eine Plattencachegröße von %1 MiB</translation>
    </message>
    <message>
        <source>DHT support [ON], port: UDP/%1</source>
        <translation type="obsolete">DHT Unterstützung [EIN], Port: UDP/%1</translation>
    </message>
    <message>
        <source>DHT support [OFF]</source>
        <translation type="obsolete">DHT Unterstützung [AUS]</translation>
    </message>
    <message>
        <source>PeX support [ON]</source>
        <translation type="obsolete">PeX Unterstützung [EIN]</translation>
    </message>
    <message>
        <source>PeX support [OFF]</source>
        <translation type="obsolete">PeX Unterstützung [AUS]</translation>
    </message>
    <message>
        <source>Restart is required to toggle PeX support</source>
        <translation type="obsolete">Neustart erforderlich um PeX Unterstützung umzuschalten</translation>
    </message>
    <message>
        <source>Local Peer Discovery [ON]</source>
        <translation type="obsolete">Lokale Peer Auffindung [EIN]</translation>
    </message>
    <message>
        <source>Local Peer Discovery support [OFF]</source>
        <translation type="obsolete">Unterstützung für Lokale Peer Auffindung [AUS]</translation>
    </message>
    <message>
        <source>Encryption support [ON]</source>
        <translation type="obsolete">Verschlüsselung Unterstützung [EIN]</translation>
    </message>
    <message>
        <source>Encryption support [FORCED]</source>
        <translation type="obsolete">Unterstützung für Verschlüsselung [Erzwungen]</translation>
    </message>
    <message>
        <source>Encryption support [OFF]</source>
        <translation type="obsolete">Verschlüsselungs-Unterstützung [AUS]</translation>
    </message>
    <message>
        <source>The Web UI is listening on port %1</source>
        <translation type="obsolete">Das Webinterface lauscht auf Port %1</translation>
    </message>
    <message>
        <source>Web User Interface Error - Unable to bind Web UI to port %1</source>
        <translation type="obsolete">Web User Interface Fehler - Web UI Port &apos;%1&apos; ist nicht erreichbar</translation>
    </message>
    <message>
        <source>&apos;%1&apos; was removed from transfer list and hard disk.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation type="obsolete">&apos;%1&apos; wurde von der Transfer-Liste und von der Festplatte entfernt.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; was removed from transfer list.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation type="obsolete">&apos;%1&apos; wurde von der Transfer-Liste entfernt.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is not a valid magnet URI.</source>
        <translation type="obsolete">&apos;%1&apos; ist keine gültige Magnet URI.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is already in download list.</source>
        <comment>e.g: &apos;xxx.avi&apos; is already in download list.</comment>
        <translation type="obsolete">&apos;%1&apos; befindet sich bereits in der Download-Liste.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; resumed. (fast resume)</source>
        <comment>&apos;/home/y/xxx.torrent&apos; was resumed. (fast resume)</comment>
        <translation type="obsolete">&apos;%1&apos; wird fortgesetzt. (Schnelles Fortsetzen)</translation>
    </message>
    <message>
        <source>&apos;%1&apos; added to download list.</source>
        <comment>&apos;/home/y/xxx.torrent&apos; was added to download list.</comment>
        <translation type="obsolete">&apos;%1&apos; wurde der Download-Liste hinzugefügt.</translation>
    </message>
    <message>
        <source>Unable to decode torrent file: &apos;%1&apos;</source>
        <comment>e.g: Unable to decode torrent file: &apos;/home/y/xxx.torrent&apos;</comment>
        <translation type="obsolete">Konnte Torrent-Datei nicht dekodieren: &apos;%1&apos;</translation>
    </message>
    <message>
        <source>This file is either corrupted or this isn&apos;t a torrent.</source>
        <translation type="obsolete">Diese Datei ist entweder fehlerhaft oder kein Torrent.</translation>
    </message>
    <message>
        <source>Note: new trackers were added to the existing torrent.</source>
        <translation type="obsolete">Bemerkung: Dem Torrent wurde ein neuer Tracker hinzugefügt.</translation>
    </message>
    <message>
        <source>Note: new URL seeds were added to the existing torrent.</source>
        <translation type="obsolete">Bemerkung: Dem Torrent wurden neue URL-Seeds hinzugefügt.</translation>
    </message>
    <message>
        <source>Error: The torrent %1 does not contain any file.</source>
        <translation type="obsolete">Fehler: Der Torret %1 enthält keineDateien.</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;was blocked due to your IP filter&lt;/i&gt;</source>
        <comment>x.y.z.w was blocked</comment>
        <translation type="obsolete">&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;wurde aufgrund Ihrer IP Filter geblockt&lt;/i&gt;</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;was banned due to corrupt pieces&lt;/i&gt;</source>
        <comment>x.y.z.w was banned</comment>
        <translation type="obsolete">&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;wurde aufgrund von beschädigten Teilen gebannt&lt;/i&gt;</translation>
    </message>
    <message>
        <source>Recursive download of file %1 embedded in torrent %2</source>
        <comment>Recursive download of test.torrent embedded in torrent test2</comment>
        <translation type="obsolete">Rekursiver Download von Datei %1, eingebettet in Torrent %2</translation>
    </message>
    <message>
        <source>Unable to decode %1 torrent file.</source>
        <translation type="obsolete">Konnte Torrent-Datei %1 nicht dekodieren.</translation>
    </message>
    <message>
        <source>UPnP/NAT-PMP: Port mapping failure, message: %1</source>
        <translation type="obsolete">UPnP/NAT-PMP: Port Mapping Fehler, Fehlermeldung: %1</translation>
    </message>
    <message>
        <source>UPnP/NAT-PMP: Port mapping successful, message: %1</source>
        <translation type="obsolete">UPnP/NAT-PMP: Port Mapping Fehler, Meldung: %1</translation>
    </message>
    <message>
        <source>Fast resume data was rejected for torrent %1, checking again...</source>
        <translation type="obsolete">Fast-Resume Daten für den Torrent %1 wurden zurückgewiesen, prüfe erneut...</translation>
    </message>
    <message>
        <source>Reason: %1</source>
        <translation type="obsolete">Begründung: %1</translation>
    </message>
    <message>
        <source>An I/O error occured, &apos;%1&apos; paused.</source>
        <translation type="obsolete">Ein I/O Fehler ist aufgetreten, &apos;%1&apos; angehalten.</translation>
    </message>
    <message>
        <source>File sizes mismatch for torrent %1, pausing it.</source>
        <translation type="obsolete">Diskrepanz bei der Dateigröße des Torrent %1, Torrent wird angehalten.</translation>
    </message>
    <message>
        <source>Url seed lookup failed for url: %1, message: %2</source>
        <translation type="obsolete">URL Seed Lookup für die URL &apos;%1&apos; ist fehlgeschlagen, Begründung: %2</translation>
    </message>
    <message>
        <source>Downloading &apos;%1&apos;, please wait...</source>
        <comment>e.g: Downloading &apos;xxx.torrent&apos;, please wait...</comment>
        <translation type="obsolete">Lade &apos;%1&apos;, bitte warten...</translation>
    </message>
</context>
<context>
    <name>ConsoleDlg</name>
    <message>
        <source>qBittorrent log viewer</source>
        <translation type="obsolete">qBittorrent Logbetrachter</translation>
    </message>
    <message>
        <source>General</source>
        <translation type="obsolete">Allgemein</translation>
    </message>
    <message>
        <source>Blocked IPs</source>
        <translation type="obsolete">Geblockte IP&apos;s</translation>
    </message>
</context>
<context>
    <name>CookiesDlg</name>
    <message>
        <location filename="../rss/cookiesdlg.ui" line="14"/>
        <source>Cookies management</source>
        <translation>Cookie Verwaltung</translation>
    </message>
    <message>
        <location filename="../rss/cookiesdlg.ui" line="36"/>
        <source>Key</source>
        <extracomment>As in Key/Value pair</extracomment>
        <translation>Schlüssel</translation>
    </message>
    <message>
        <location filename="../rss/cookiesdlg.ui" line="41"/>
        <source>Value</source>
        <extracomment>As in Key/Value pair</extracomment>
        <translation>Wert</translation>
    </message>
    <message>
        <location filename="../rss/cookiesdlg.cpp" line="48"/>
        <source>Common keys for cookies are : &apos;%1&apos;, &apos;%2&apos;.
You should get this information from your Web browser preferences.</source>
        <translation>Gängige Schlüssel für Cookies sind: &apos;%1&apos;, &apos;%2&apos;.
Sie sollten diese Information aus den Voreinstellungen Ihres Webbrowsers erhalten.</translation>
    </message>
</context>
<context>
    <name>DNSUpdater</name>
    <message>
        <location filename="../dnsupdater.cpp" line="178"/>
        <source>Your dynamic DNS was successfuly updated.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dnsupdater.cpp" line="182"/>
        <source>Dynamic DNS error: The service is temporarily unavailable, it will be retried in 30 minutes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dnsupdater.cpp" line="192"/>
        <source>Dynamic DNS error: hostname supplied does not exist under specified account.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dnsupdater.cpp" line="198"/>
        <source>Dynamic DNS error: Invalid username/password.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dnsupdater.cpp" line="203"/>
        <source>Dynamic DNS error: qBittorrent was blacklisted by the service, please report a bug at http://bugs.qbittorrent.org.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dnsupdater.cpp" line="209"/>
        <source>Dynamic DNS error: %1 was returned by the service, please report a bug at http://bugs.qbittorrent.org.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dnsupdater.cpp" line="215"/>
        <source>Dynamic DNS error: Your username was blocked due to abuse.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dnsupdater.cpp" line="236"/>
        <source>Dynamic DNS error: supplied domain name is invalid.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dnsupdater.cpp" line="248"/>
        <source>Dynamic DNS error: supplied username is too short.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dnsupdater.cpp" line="260"/>
        <source>Dynamic DNS error: supplied password is too short.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DownloadThread</name>
    <message>
        <location filename="../downloadthread.cpp" line="98"/>
        <location filename="../downloadthread.cpp" line="102"/>
        <source>I/O Error</source>
        <translation>I/O Fehler</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="209"/>
        <source>The remote host name was not found (invalid hostname)</source>
        <translation>Der Hostname konnte nicht gefunden werden (ungültiger Hostname)</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="211"/>
        <source>The operation was canceled</source>
        <translation>Die Operation wurde abgebrochen</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="213"/>
        <source>The remote server closed the connection prematurely, before the entire reply was received and processed</source>
        <translation>Der Server hat die Verbindung beendet bevor die gesamte Antwort empfangen und verarbeitet werden konnte</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="215"/>
        <source>The connection to the remote server timed out</source>
        <translation>Zeitüberschreitung bei der Verbindung mit dem Server</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="217"/>
        <source>SSL/TLS handshake failed</source>
        <translation>SSL/TLS Handshake fehlgeschlagen</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="219"/>
        <source>The remote server refused the connection</source>
        <translation>Der Server hat die Verbindung verweigert</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="221"/>
        <source>The connection to the proxy server was refused</source>
        <translation>Die Verbindung zum Proxy-Server wurde verweigert</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="223"/>
        <source>The proxy server closed the connection prematurely</source>
        <translation>Der Proxy-Server hat die Verbindung vorzeitig beendet</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="225"/>
        <source>The proxy host name was not found</source>
        <translation>Der Proxy-Hostname wurde nicht gefunden</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="227"/>
        <source>The connection to the proxy timed out or the proxy did not reply in time to the request sent</source>
        <translation>Zeitüberschreitung beim Verbindungsaufbau mit dem Proxy oder der Proxy hat nicht in angemessener Zeit auf die Anfrage reagiert</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="229"/>
        <source>The proxy requires authentication in order to honour the request but did not accept any credentials offered</source>
        <translation>Der Proxy benötigt Authentifizierung hat jedoch keine der angebotenen Zugangsdaten akzeptiert</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="231"/>
        <source>The access to the remote content was denied (401)</source>
        <translation>Der Zugriff auf den Inhalt wurde verweigert (401)</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="233"/>
        <source>The operation requested on the remote content is not permitted</source>
        <translation>Die Operation ist nicht erlaubt</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="235"/>
        <source>The remote content was not found at the server (404)</source>
        <translation>Der Inhalte wurde auf dem Server nicht gefunden (404)</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="237"/>
        <source>The remote server requires authentication to serve the content but the credentials provided were not accepted</source>
        <translation>Der Server verlangt Authentifizierung, aber die angebotenen Zugangsdaten wurden nicht akzeptiert</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="239"/>
        <source>The Network Access API cannot honor the request because the protocol is not known</source>
        <translation>Die Network-Access-API konnte die Anfrage nicht bearbeiten, unbekanntes Protokoll</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="241"/>
        <source>The requested operation is invalid for this protocol</source>
        <translation>Die angeforderte Operation ist ungütlig für dieses Protokoll</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="243"/>
        <source>An unknown network-related error was detected</source>
        <translation>Ein unbekannter Netzwerk-Fehler ist aufgetreten</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="245"/>
        <source>An unknown proxy-related error was detected</source>
        <translation>Ein unbekannter Proxy-Fehler ist aufgetreten</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="247"/>
        <source>An unknown error related to the remote content was detected</source>
        <translation>Unbekannter Fehler in Zusammenhang mit dem Inhalt ist aufgetreten</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="249"/>
        <source>A breakdown in protocol was detected</source>
        <translation>Es ist eine Störung im Protokoll aufgetreten</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="251"/>
        <source>Unknown error</source>
        <translation>Unbekannter Fehler</translation>
    </message>
</context>
<context>
    <name>EventManager</name>
    <message>
        <location filename="../webui/eventmanager.cpp" line="73"/>
        <location filename="../webui/eventmanager.cpp" line="87"/>
        <source>Working</source>
        <translation>Funktioniert</translation>
    </message>
    <message>
        <location filename="../webui/eventmanager.cpp" line="76"/>
        <source>Updating...</source>
        <translation>Aktualisiere...</translation>
    </message>
    <message>
        <location filename="../webui/eventmanager.cpp" line="79"/>
        <location filename="../webui/eventmanager.cpp" line="90"/>
        <source>Not working</source>
        <translation>Funktioniert nicht</translation>
    </message>
    <message>
        <location filename="../webui/eventmanager.cpp" line="81"/>
        <location filename="../webui/eventmanager.cpp" line="92"/>
        <source>Not contacted yet</source>
        <translation>Noch nicht kontaktiert</translation>
    </message>
    <message>
        <location filename="../webui/eventmanager.cpp" line="405"/>
        <location filename="../webui/eventmanager.cpp" line="406"/>
        <source>this session</source>
        <translation>Diese Session</translation>
    </message>
    <message>
        <location filename="../webui/eventmanager.cpp" line="410"/>
        <location filename="../webui/eventmanager.cpp" line="414"/>
        <source>/s</source>
        <comment>/second (i.e. per second)</comment>
        <translation></translation>
    </message>
    <message>
        <location filename="../webui/eventmanager.cpp" line="417"/>
        <source>Seeded for %1</source>
        <comment>e.g. Seeded for 3m10s</comment>
        <translation>Geseeded seit %1</translation>
    </message>
    <message>
        <location filename="../webui/eventmanager.cpp" line="420"/>
        <source>%1 max</source>
        <comment>e.g. 10 max</comment>
        <translation>%1 max</translation>
    </message>
    <message>
        <location filename="../webui/eventmanager.cpp" line="499"/>
        <location filename="../webui/eventmanager.cpp" line="508"/>
        <source>%1/s</source>
        <comment>e.g. 120 KiB/s</comment>
        <translation>%1/Sekunde</translation>
    </message>
</context>
<context>
    <name>ExecutionLog</name>
    <message>
        <location filename="../executionlog.ui" line="27"/>
        <source>General</source>
        <translation>Allgemein</translation>
    </message>
    <message>
        <location filename="../executionlog.ui" line="41"/>
        <source>Blocked IPs</source>
        <translation>Geblockte IPs</translation>
    </message>
</context>
<context>
    <name>FeedDownloader</name>
    <message>
        <source>RSS Feed downloader</source>
        <translation type="obsolete">RSS-Feed-Downloader</translation>
    </message>
    <message>
        <source>RSS feed:</source>
        <translation type="obsolete">RSS-Feed:</translation>
    </message>
    <message>
        <source>Feed name</source>
        <translation type="obsolete">Feed-Name</translation>
    </message>
    <message>
        <source>Automatically download torrents from this feed</source>
        <translation type="obsolete">Torrents von diesem Feed automatisch laden</translation>
    </message>
    <message>
        <source>Download filters</source>
        <translation type="obsolete">Download-Filter</translation>
    </message>
    <message>
        <source>Filters:</source>
        <translation type="obsolete">Filter:</translation>
    </message>
    <message>
        <source>Filter settings</source>
        <translation type="obsolete">Filter-Einstellungen</translation>
    </message>
    <message>
        <source>Matches:</source>
        <translation type="obsolete">Übereinstimmungen:</translation>
    </message>
    <message>
        <source>Does not match:</source>
        <translation type="obsolete">Stimmt nicht überein:</translation>
    </message>
    <message>
        <source>Destination folder:</source>
        <translation type="obsolete">Zielverzeichnis:</translation>
    </message>
    <message>
        <source>...</source>
        <translation type="obsolete">...</translation>
    </message>
    <message>
        <source>Filter testing</source>
        <translation type="obsolete">Teste Filter</translation>
    </message>
    <message>
        <source>Torrent title:</source>
        <translation type="obsolete">Torrent-Titel:</translation>
    </message>
    <message>
        <source>Result:</source>
        <translation type="obsolete">Ergebnis:</translation>
    </message>
    <message>
        <source>Test</source>
        <translation type="obsolete">Test</translation>
    </message>
    <message>
        <source>Import...</source>
        <translation type="obsolete">Import...</translation>
    </message>
    <message>
        <source>Export...</source>
        <translation type="obsolete">Export...</translation>
    </message>
    <message>
        <source>Rename filter</source>
        <translation type="obsolete">Filter umbenennen</translation>
    </message>
    <message>
        <source>Remove filter</source>
        <translation type="obsolete">Filter löschen</translation>
    </message>
    <message>
        <source>Add filter</source>
        <translation type="obsolete">Filter hinzufügen</translation>
    </message>
</context>
<context>
    <name>FeedDownloaderDlg</name>
    <message>
        <source>New filter</source>
        <translation type="obsolete">Neuer Filter</translation>
    </message>
    <message>
        <source>Please choose a name for this filter</source>
        <translation type="obsolete">Bitte wählen Sie einen Namen für diesen Filter</translation>
    </message>
    <message>
        <source>Filter name:</source>
        <translation type="obsolete">Filter-Name:</translation>
    </message>
    <message>
        <source>Invalid filter name</source>
        <translation type="obsolete">Ungültiger Filter-Name</translation>
    </message>
    <message>
        <source>The filter name cannot be left empty.</source>
        <translation type="obsolete">Der Filter-Name darf nicht leer sein.</translation>
    </message>
    <message>
        <source>This filter name is already in use.</source>
        <translation type="obsolete">Dieser Filter-Name wird bereits verwendet.</translation>
    </message>
    <message>
        <source>Choose save path</source>
        <translation type="obsolete">Wählen Sie den Speicher-Pfad</translation>
    </message>
    <message>
        <source>Filter testing error</source>
        <translation type="obsolete">Fehler beim testen des Filters</translation>
    </message>
    <message>
        <source>Please specify a test torrent name.</source>
        <translation type="obsolete">Bitte geben Sie einen Torrent-Namen zum testen ein.</translation>
    </message>
    <message>
        <source>matches</source>
        <translation type="obsolete">stimmt überein</translation>
    </message>
    <message>
        <source>does not match</source>
        <translation type="obsolete">stimmt nicht überein</translation>
    </message>
    <message>
        <source>Select file to import</source>
        <translation type="obsolete">Wählen Sie eine Datei für den Import</translation>
    </message>
    <message>
        <source>Filters Files</source>
        <translation type="obsolete">Filter-Dateien</translation>
    </message>
    <message>
        <source>Import successful</source>
        <translation type="obsolete">Import erfolgreich</translation>
    </message>
    <message>
        <source>Filters import was successful.</source>
        <translation type="obsolete">Filter wurden erfolgreich importiert.</translation>
    </message>
    <message>
        <source>Import failure</source>
        <translation type="obsolete">Fehler beim Import</translation>
    </message>
    <message>
        <source>Filters could not be imported due to an I/O error.</source>
        <translation type="obsolete">Filter konnte nicht importiert werden aufgrund eines I/O Fehlers.</translation>
    </message>
    <message>
        <source>Select destination file</source>
        <translation type="obsolete">Zieldatei auswählen</translation>
    </message>
    <message>
        <source>Export successful</source>
        <translation type="obsolete">Export erfolgreich</translation>
    </message>
    <message>
        <source>Filters export was successful.</source>
        <translation type="obsolete">Filter wurden erfolgreich exportiert.</translation>
    </message>
    <message>
        <source>Export failure</source>
        <translation type="obsolete">Fehler beim Export</translation>
    </message>
    <message>
        <source>Filters could not be exported due to an I/O error.</source>
        <translation type="obsolete">Filter konnte nicht exportiert werden aufgrund eines I/O Fehlers.</translation>
    </message>
</context>
<context>
    <name>FeedList</name>
    <message>
        <source>Unread</source>
        <translation type="obsolete">Ungelesen</translation>
    </message>
</context>
<context>
    <name>FeedListWidget</name>
    <message>
        <location filename="../rss/feedlistwidget.cpp" line="41"/>
        <source>RSS feeds</source>
        <translation>RSS-Feeds</translation>
    </message>
    <message>
        <location filename="../rss/feedlistwidget.cpp" line="43"/>
        <source>Unread</source>
        <translation>Ungelesen</translation>
    </message>
</context>
<context>
    <name>GUI</name>
    <message>
        <source>qBittorrent</source>
        <translation type="obsolete">qBittorrent</translation>
    </message>
    <message>
        <source>Open Torrent Files</source>
        <translation type="obsolete">Öffne Torrent-Dateien</translation>
    </message>
    <message>
        <source>Torrent Files</source>
        <translation type="obsolete">Torrent-Dateien</translation>
    </message>
    <message>
        <source>Transfers</source>
        <translation type="obsolete">Übertragungen</translation>
    </message>
    <message>
        <source>qBittorrent %1</source>
        <comment>e.g: qBittorrent v0.x</comment>
        <translation type="obsolete">qBittorrent %1</translation>
    </message>
    <message>
        <source>DL speed: %1 KiB/s</source>
        <comment>e.g: Download speed: 10 KiB/s</comment>
        <translation type="obsolete">DL Geschwindigkeit: %1 KB/s</translation>
    </message>
    <message>
        <source>UP speed: %1 KiB/s</source>
        <comment>e.g: Upload speed: 10 KiB/s</comment>
        <translation type="obsolete">UP Geschwindigkeit: %1 KiB/s</translation>
    </message>
    <message>
        <source>%1 has finished downloading.</source>
        <comment>e.g: xxx.avi has finished downloading.</comment>
        <translation type="obsolete">%1 vollständig heruntergeladen.</translation>
    </message>
    <message>
        <source>I/O Error</source>
        <comment>i.e: Input/Output Error</comment>
        <translation type="obsolete">I/O Error</translation>
    </message>
    <message>
        <source>Search</source>
        <translation type="obsolete">Suche</translation>
    </message>
    <message>
        <source>Torrent file association</source>
        <translation type="obsolete">Verbindung zu Torrent Datei</translation>
    </message>
    <message>
        <source>qBittorrent is not the default application to open torrent files or Magnet links.
Do you want to associate qBittorrent to torrent files and Magnet links?</source>
        <translation type="obsolete">qBittorrent ist nicht die Standard Applikation um Torrent Dateien oder Magnet Links zu öffnen. Möchten Sie Torrent Dateien und Magnet Links immer mit qBittorent öffnen?</translation>
    </message>
    <message>
        <source>RSS</source>
        <translation type="obsolete">RSS</translation>
    </message>
    <message>
        <source>Transfers (%1)</source>
        <translation type="obsolete">Übertragungen (%1)</translation>
    </message>
    <message>
        <source>Download completion</source>
        <translation type="obsolete">Beendigung des Download</translation>
    </message>
    <message>
        <source>An I/O error occured for torrent %1.
 Reason: %2</source>
        <comment>e.g: An error occured for torrent xxx.avi.
 Reason: disk is full.</comment>
        <translation type="obsolete">Ein I/O Fehler ist aufegtreten für die Torrent Datei %1. Ursache: %2</translation>
    </message>
    <message>
        <source>Alt+2</source>
        <comment>shortcut to switch to third tab</comment>
        <translation type="obsolete">Alt+2</translation>
    </message>
    <message>
        <source>Recursive download confirmation</source>
        <translation type="obsolete">Rekursiven Downlaod bestätigen</translation>
    </message>
    <message>
        <source>The torrent %1 contains torrent files, do you want to proceed with their download?</source>
        <translation type="obsolete">Der Torrent %1 enthält Torrent Dateien, möchten Sie mit dem Download fortfahren?</translation>
    </message>
    <message>
        <source>A newer version is available</source>
        <translation type="obsolete">Eine neuere Version ist erhältlich</translation>
    </message>
    <message>
        <source>A newer version of qBittorrent is available on Sourceforge.
Would you like to update qBittorrent to version %1?</source>
        <translation type="obsolete">Eine neuere Version von qBittorrent ist auf Sourceforge erhätlich. Möchten Sie qBittorent auf die Version %1 aktualisieren?</translation>
    </message>
    <message>
        <source>Impossible to update qBittorrent</source>
        <translation type="obsolete">Aktuialisierung von qBittorrent nicht möglich</translation>
    </message>
    <message>
        <source>qBittorrent failed to update, reason: %1</source>
        <translation type="obsolete">qBittorrent konnte nicht aktualisiert werden, Begründung: %1</translation>
    </message>
    <message>
        <source>Exiting qBittorrent</source>
        <translation type="obsolete">Beende qBittorrent</translation>
    </message>
    <message>
        <source>Always</source>
        <translation type="obsolete">Immer</translation>
    </message>
    <message>
        <source>Alt+1</source>
        <comment>shortcut to switch to first tab</comment>
        <translation type="obsolete">Alt+1</translation>
    </message>
    <message>
        <source>Url download error</source>
        <translation type="obsolete">URL Download Fehler</translation>
    </message>
    <message>
        <source>Couldn&apos;t download file at url: %1, reason: %2.</source>
        <translation type="obsolete">Konnte Datei von URL: %1 nicht laden, Begründung: %2.</translation>
    </message>
    <message>
        <source>Ctrl+F</source>
        <comment>shortcut to switch to search tab</comment>
        <translation type="obsolete">Strg+F</translation>
    </message>
    <message>
        <source>Alt+3</source>
        <comment>shortcut to switch to fourth tab</comment>
        <translation type="obsolete">Alt+3</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation type="obsolete">Ja</translation>
    </message>
    <message>
        <source>No</source>
        <translation type="obsolete">Nein</translation>
    </message>
    <message>
        <source>Never</source>
        <translation type="obsolete">Niemals</translation>
    </message>
    <message>
        <source>Global Upload Speed Limit</source>
        <translation type="obsolete">Globale UL-Rate</translation>
    </message>
    <message>
        <source>Global Download Speed Limit</source>
        <translation type="obsolete">Globale DL-Rate</translation>
    </message>
    <message>
        <source>Some files are currently transferring.
Are you sure you want to quit qBittorrent?</source>
        <translation type="obsolete">Zur Zeit werden Dateien übertragen.
Sind Sie sicher, daß sie qBittorrent beenden möchten?</translation>
    </message>
    <message>
        <source>Options were saved successfully.</source>
        <translation type="obsolete">Optionen wurden erfolgreich gespeichert.</translation>
    </message>
</context>
<context>
    <name>GeoIP</name>
    <message>
        <source>Australia</source>
        <translation type="obsolete">Australien</translation>
    </message>
    <message>
        <source>Argentina</source>
        <translation type="obsolete">Argentinien</translation>
    </message>
    <message>
        <source>Austria</source>
        <translation type="obsolete">Österreich</translation>
    </message>
    <message>
        <source>United Arab Emirates</source>
        <translation type="obsolete">Vereinigte Arabische Emirate</translation>
    </message>
    <message>
        <source>Brazil</source>
        <translation type="obsolete">Brasilien</translation>
    </message>
    <message>
        <source>Bulgaria</source>
        <translation type="obsolete">Bulgarien</translation>
    </message>
    <message>
        <source>Belarus</source>
        <translation type="obsolete">Weißrussland</translation>
    </message>
    <message>
        <source>Belgium</source>
        <translation type="obsolete">Belgien</translation>
    </message>
    <message>
        <source>Bosnia</source>
        <translation type="obsolete">Bosniene</translation>
    </message>
    <message>
        <source>Canada</source>
        <translation type="obsolete">Kanada</translation>
    </message>
    <message>
        <source>Czech Republic</source>
        <translation type="obsolete">Tschechische Republik</translation>
    </message>
    <message>
        <source>China</source>
        <translation type="obsolete">China</translation>
    </message>
    <message>
        <source>Costa Rica</source>
        <translation type="obsolete">Costa Rica</translation>
    </message>
    <message>
        <source>Switzerland</source>
        <translation type="obsolete">Schweiz</translation>
    </message>
    <message>
        <source>Germany</source>
        <translation type="obsolete">Deutschland</translation>
    </message>
    <message>
        <source>Denmark</source>
        <translation type="obsolete">Dänemark</translation>
    </message>
    <message>
        <source>Algeria</source>
        <translation type="obsolete">Algerien</translation>
    </message>
    <message>
        <source>Spain</source>
        <translation type="obsolete">Spanien</translation>
    </message>
    <message>
        <source>Egypt</source>
        <translation type="obsolete">Ägypten</translation>
    </message>
    <message>
        <source>Finland</source>
        <translation type="obsolete">Finnland</translation>
    </message>
    <message>
        <source>France</source>
        <translation type="obsolete">Frankreich</translation>
    </message>
    <message>
        <source>United Kingdom</source>
        <translation type="obsolete">Vereinigtes Königreich</translation>
    </message>
    <message>
        <source>Greece</source>
        <translation type="obsolete">Griechenland</translation>
    </message>
    <message>
        <source>Georgia</source>
        <translation type="obsolete">Georgien</translation>
    </message>
    <message>
        <source>Hungary</source>
        <translation type="obsolete">Ungarn</translation>
    </message>
    <message>
        <source>Croatia</source>
        <translation type="obsolete">Kroatien</translation>
    </message>
    <message>
        <source>Italy</source>
        <translation type="obsolete">Italien</translation>
    </message>
    <message>
        <source>India</source>
        <translation type="obsolete">Indien</translation>
    </message>
    <message>
        <source>Israel</source>
        <translation type="obsolete">Israel</translation>
    </message>
    <message>
        <source>Ireland</source>
        <translation type="obsolete">Irland</translation>
    </message>
    <message>
        <source>Iceland</source>
        <translation type="obsolete">Island</translation>
    </message>
    <message>
        <source>Indonesia</source>
        <translation type="obsolete">Indonesien</translation>
    </message>
    <message>
        <source>South Korea</source>
        <translation type="obsolete">Südkorea</translation>
    </message>
    <message>
        <source>Luxembourg</source>
        <translation type="obsolete">Luxemburg</translation>
    </message>
    <message>
        <source>Serbia</source>
        <translation type="obsolete">Serbien</translation>
    </message>
    <message>
        <source>Morocco</source>
        <translation type="obsolete">Marokko</translation>
    </message>
    <message>
        <source>Netherlands</source>
        <translation type="obsolete">Niederlande</translation>
    </message>
    <message>
        <source>Norway</source>
        <translation type="obsolete">Norwegen</translation>
    </message>
    <message>
        <source>New Zealand</source>
        <translation type="obsolete">Neu Seeland</translation>
    </message>
    <message>
        <source>Portugal</source>
        <translation type="obsolete">Portugal</translation>
    </message>
    <message>
        <source>Poland</source>
        <translation type="obsolete">Polen</translation>
    </message>
    <message>
        <source>Philippines</source>
        <translation type="obsolete">Philippinen</translation>
    </message>
    <message>
        <source>Russia</source>
        <translation type="obsolete">Russland</translation>
    </message>
    <message>
        <source>Romania</source>
        <translation type="obsolete">Romänien</translation>
    </message>
    <message>
        <source>France (Reunion Island)</source>
        <translation type="obsolete">Frankreich (Reunion)</translation>
    </message>
    <message>
        <source>Saudi Arabia</source>
        <translation type="obsolete">Saudi Arabien</translation>
    </message>
    <message>
        <source>Sweden</source>
        <translation type="obsolete">Schweden</translation>
    </message>
    <message>
        <source>Slovakia</source>
        <translation type="obsolete">Slovakei</translation>
    </message>
    <message>
        <source>Singapore</source>
        <translation type="obsolete">Singapur</translation>
    </message>
    <message>
        <source>Slovenia</source>
        <translation type="obsolete">Slovenien</translation>
    </message>
    <message>
        <source>Turkey</source>
        <translation type="obsolete">Türkei</translation>
    </message>
    <message>
        <source>South Africa</source>
        <translation type="obsolete">Südafrika</translation>
    </message>
</context>
<context>
    <name>HeadlessLoader</name>
    <message>
        <location filename="../headlessloader.h" line="54"/>
        <source>Information</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../headlessloader.h" line="55"/>
        <source>To control qBittorrent, access the Web UI at http://localhost:%1</source>
        <translation>Um qBittorrent zu steuern benutzen Sie bitte das Webinterface unter http://localhost:%1</translation>
    </message>
    <message>
        <location filename="../headlessloader.h" line="56"/>
        <source>The Web UI administrator user name is: %1</source>
        <translation>Benutzername des Webinterface-Administrators: %1</translation>
    </message>
    <message>
        <location filename="../headlessloader.h" line="59"/>
        <source>The Web UI administrator password is still the default one: %1</source>
        <translation>Das Passwort des Webinterface-Administrators ist immer noch die Standardeinstellung: %1</translation>
    </message>
    <message>
        <location filename="../headlessloader.h" line="60"/>
        <source>This is a security risk, please consider changing your password from program preferences.</source>
        <translation>Dies ist eine Sicherheitslücke, bitte ändern Sie das Passwort über die Programmvoreinstellungen.</translation>
    </message>
</context>
<context>
    <name>HttpConnection</name>
    <message>
        <location filename="../webui/httpconnection.cpp" line="150"/>
        <source>Your IP address has been banned after too many failed authentication attempts.</source>
        <translation>Ihre IP Adresse wurde nach zu vielen fehlerhaften Authentisierungversuchen gebannt.</translation>
    </message>
    <message>
        <location filename="../webui/httpconnection.cpp" line="345"/>
        <source>D: %1/s - T: %2</source>
        <comment>Download speed: x KiB/s - Transferred: x MiB</comment>
        <translatorcomment>How are we supposed to translate this? Do you want the initial letter of a translation of the hint you gave in the developer comments? Are there going to be any tooltips that will help the user understand the abbreviation?</translatorcomment>
        <translation></translation>
    </message>
    <message>
        <location filename="../webui/httpconnection.cpp" line="346"/>
        <source>U: %1/s - T: %2</source>
        <comment>Upload speed: x KiB/s - Transferred: x MiB</comment>
        <translatorcomment>see comment on D: %1/s - T: %2</translatorcomment>
        <translation></translation>
    </message>
</context>
<context>
    <name>HttpServer</name>
    <message>
        <location filename="../webui/httpserver.cpp" line="120"/>
        <source>File</source>
        <translation>Datei</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="121"/>
        <source>Edit</source>
        <translation>Bearbeiten</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="122"/>
        <source>Help</source>
        <translation>Hilfe</translation>
    </message>
    <message>
        <source>Delete from HD</source>
        <translation type="obsolete">Von der Festplatte löschen</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="123"/>
        <source>Download Torrents from their URL or Magnet link</source>
        <translation>Lade Torrents von URL oder Magnet-Link</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="124"/>
        <source>Only one link per line</source>
        <translation>Nur ein Link pro Zeile</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="125"/>
        <source>Download local torrent</source>
        <translation>Lade lokalen Torrent</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="126"/>
        <source>Torrent files were correctly added to download list.</source>
        <translation>Torrents wurden der Download-Liste erfolgreich hinzugefügt.</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="127"/>
        <source>Point to torrent file</source>
        <translation>Zeige auf Torrent Datei</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="128"/>
        <source>Download</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="129"/>
        <source>Are you sure you want to delete the selected torrents from the transfer list and hard disk?</source>
        <translation>Sind Sie sicher, daß Sie die ausgewählten Torrents von der Transfer-Liste und der Festplatte entfernen möchten?</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="130"/>
        <source>Download rate limit must be greater than 0 or disabled.</source>
        <translation>Begrenzung der Downloadrate muss größer als 0 sein oder deaktiviert werden.</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="131"/>
        <source>Upload rate limit must be greater than 0 or disabled.</source>
        <translation>Begrenzung der Uploadrate muss größer als 0 sein oder deaktiviert werden.</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="132"/>
        <source>Maximum number of connections limit must be greater than 0 or disabled.</source>
        <translation>Maximale Anzahl der Verbindungen muss größer als 0 sein oder deaktiviert werden.</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="133"/>
        <source>Maximum number of connections per torrent limit must be greater than 0 or disabled.</source>
        <translation>Maximale Anzahl der Verbindungen pro Torrent muss größer als 0 sein oder deaktiviert werden.</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="134"/>
        <source>Maximum number of upload slots per torrent limit must be greater than 0 or disabled.</source>
        <translation>Maximale Anzahle der Upload-Slots muss größer als 0 sein oder deaktiviert werden.</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="135"/>
        <source>Unable to save program preferences, qBittorrent is probably unreachable.</source>
        <translation>Konnte Programmeinstellungen nicht speichern, qBittorrent ist vermutlich nicht erreichbar.</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="136"/>
        <source>Language</source>
        <translation>Sprache</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="137"/>
        <source>Downloaded</source>
        <comment>Is the file downloaded or not?</comment>
        <translation>Runtergeladen</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="138"/>
        <source>The port used for incoming connections must be greater than 1024 and less than 65535.</source>
        <translation>Der Port für eingehende Verbindungen muss grösser als 1024 und kleiner als 65535 sein.</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="139"/>
        <source>The port used for the Web UI must be greater than 1024 and less than 65535.</source>
        <translation>Der Port für das Webinterface muss grösser als 1024 und kleiner als 65535 sein.</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="140"/>
        <source>The Web UI username must be at least 3 characters long.</source>
        <translation>Der Benutzername für das Webinterface muss mindestens 3 Zeichen lang sein.</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="141"/>
        <source>The Web UI password must be at least 3 characters long.</source>
        <translation>Das Passwort für das Webinterface muss mindestens 3 Zeichen lang sein.</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="142"/>
        <source>Save</source>
        <translation>Speichern</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="143"/>
        <source>qBittorrent client is not reachable</source>
        <translation>qBittorrent-Client ist nicht erreichbar</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="144"/>
        <source>HTTP Server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="145"/>
        <source>The following parameters are supported:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="146"/>
        <source>Torrent path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="147"/>
        <source>Torrent name</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LegalNotice</name>
    <message>
        <location filename="../main.cpp" line="93"/>
        <source>Legal Notice</source>
        <translation>Rechtshinweis</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="94"/>
        <location filename="../main.cpp" line="105"/>
        <source>qBittorrent is a file sharing program. When you run a torrent, its data will be made available to others by means of upload. Any content you share is your sole responsibility.

No further notices will be issued.</source>
        <translation>qBittorrent ist ein Filesharing Programm. Sobald ein Torrent bei Ihnen läuft, stellen Sie den Inhalt auch anderen zur Verfügung. Selbstverständlich geschieht das Teilen jeglicher Inhalte auf Ihre eigene Verantwortung.

Wahrscheinlich haben wir Ihnen hiermit nichts Neues erzählt und werden Sie auch nicht wieder darauf hinweisen.</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="95"/>
        <source>Press %1 key to accept and continue...</source>
        <translation>Zum bestätigen und fortfahren bitte %1-Taste drücken...</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="106"/>
        <source>Legal notice</source>
        <translation>Rechtshinweis</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="107"/>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="108"/>
        <source>I Agree</source>
        <translation>Ich stimme zu</translation>
    </message>
</context>
<context>
    <name>LineEdit</name>
    <message>
        <location filename="../lineedit/src/lineedit.cpp" line="30"/>
        <source>Clear the text</source>
        <translation>Text löschen</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="37"/>
        <source>&amp;Edit</source>
        <translation>&amp;Bearbeiten</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="50"/>
        <source>&amp;Help</source>
        <translation>&amp;Hilfe</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="60"/>
        <source>&amp;Tools</source>
        <translation>&amp;Werkzeuge</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="79"/>
        <source>&amp;File</source>
        <translation>&amp;Datei</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="88"/>
        <source>&amp;View</source>
        <translation>&amp;Ansicht</translation>
    </message>
    <message>
        <source>&amp;Add File...</source>
        <translation type="obsolete">&amp;Datei hinzufügen...</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation type="obsolete">Beenden</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="148"/>
        <source>&amp;Options...</source>
        <translation>&amp;Optionen...</translation>
    </message>
    <message>
        <source>Add &amp;URL...</source>
        <translation type="obsolete">&amp;URL hinzufügen...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="187"/>
        <source>Torrent &amp;creator</source>
        <translation>Torrent &amp;Erschaffer</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="197"/>
        <source>Set upload limit...</source>
        <translation>Upload Limit setzen...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="202"/>
        <source>Set download limit...</source>
        <translation>Download Limit setzen...</translation>
    </message>
    <message>
        <source>Shutdown qBittorrent when downloads complete</source>
        <translation type="obsolete">qBittorent beenden wenn Downloads vollständig sind</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="153"/>
        <source>&amp;About</source>
        <translation>&amp;Über</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="163"/>
        <source>&amp;Pause</source>
        <translation>&amp;Anhalten</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="168"/>
        <source>&amp;Delete</source>
        <translation>&amp;Löschen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="319"/>
        <source>P&amp;ause All</source>
        <translation>A&amp;lle anhalten</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="158"/>
        <source>&amp;Resume</source>
        <translation>&amp;Fortsetzen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="135"/>
        <source>&amp;Add torrent file...</source>
        <translation>Torrent-Datei &amp;hinzufügen...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="140"/>
        <location filename="../mainwindow.ui" line="143"/>
        <source>Exit</source>
        <translation>Beenden</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="314"/>
        <source>R&amp;esume All</source>
        <translation>Alle forts&amp;etzen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="177"/>
        <source>Visit &amp;Website</source>
        <translation>&amp;Website aufrufen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="64"/>
        <source>Auto-Shutdown on downloads completion</source>
        <translation>Automatisches herunterfahren wenn Dowloads vollständig sind</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="182"/>
        <source>Add &amp;link to torrent...</source>
        <translation>&amp;Link zu Torrent hinzufügen...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="192"/>
        <source>Report a &amp;bug</source>
        <translation>&amp;Bug melden</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="207"/>
        <source>&amp;Documentation</source>
        <translation>&amp;Dokumentation</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="212"/>
        <source>Set global download limit...</source>
        <translation>Globales Downlaod Limit setzen...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="217"/>
        <source>Set global upload limit...</source>
        <translation>Globals Upload Limit setzen...</translation>
    </message>
    <message>
        <source>&amp;Log viewer...</source>
        <translation type="obsolete">&amp;Log Betrachter...</translation>
    </message>
    <message>
        <source>Log viewer</source>
        <translation type="obsolete">Log Betrachter</translation>
    </message>
    <message>
        <source>Shutdown computer when downloads complete</source>
        <translation type="obsolete">Computer herunterfahren wenn Dowloads vollständig sind</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="287"/>
        <location filename="../mainwindow.ui" line="290"/>
        <source>Lock qBittorrent</source>
        <translation>qBittorrent sperren</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="293"/>
        <source>Ctrl+L</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="298"/>
        <source>Import existing torrent...</source>
        <translation>Existierendes Torrent importieren...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="301"/>
        <source>Import torrent...</source>
        <translation>Torrent importieren...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="306"/>
        <source>Donate money</source>
        <translation>Spenden</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="309"/>
        <source>If you like qBittorrent, please donate!</source>
        <translation>Bitte spenden Sie wenn Ihnen qBittorrent gefällt!</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="327"/>
        <source>Execution &amp;Log</source>
        <translation>Ausführungs-&amp;Log</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="330"/>
        <location filename="../mainwindow.cpp" line="1327"/>
        <source>Execution Log</source>
        <translation>Ausführungs-Log</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="338"/>
        <source>Exit qBittorrent</source>
        <translation>Beende qBittorrent</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="346"/>
        <source>Suspend system</source>
        <translation>System anhalten</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="354"/>
        <source>Shutdown system</source>
        <translation>System herunterfahren</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="362"/>
        <source>Disabled</source>
        <translation>Deaktiviert</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="241"/>
        <location filename="../mainwindow.ui" line="244"/>
        <source>Alternative speed limits</source>
        <translation>Alternative Geschwindigkeitsbegrenzung</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="274"/>
        <source>&amp;RSS reader</source>
        <translation>&amp;RSS Reader</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="282"/>
        <source>Search &amp;engine</source>
        <translation>Such&amp;maschine</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="252"/>
        <source>Top &amp;tool bar</source>
        <translation>Obere Werk&amp;zeugleiste</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="255"/>
        <source>Display top tool bar</source>
        <translation>Zeige obere Werkzeugleiste</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="263"/>
        <source>&amp;Speed in title bar</source>
        <translation>&amp;Geschwindigkeit in der Titelleiste</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="266"/>
        <source>Show transfer speed in title bar</source>
        <translation>Übertragungsgeschwindigkeit in der Titelleiste anzeigen</translation>
    </message>
    <message>
        <source>Preview file</source>
        <translation type="obsolete">Vorschau Datei</translation>
    </message>
    <message>
        <source>Clear log</source>
        <translation type="obsolete">Log löschen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="222"/>
        <source>Decrease priority</source>
        <translation>Verringere Priorität</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="230"/>
        <source>Increase priority</source>
        <translation>Erhöhe Prorität</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="103"/>
        <location filename="../mainwindow.cpp" line="1251"/>
        <source>qBittorrent %1</source>
        <comment>e.g: qBittorrent v0.x</comment>
        <translation>qBittorrent %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="140"/>
        <source>Set the password...</source>
        <translation>Passwort setzen...</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="174"/>
        <source>Transfers</source>
        <translation>Übertragungen</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="287"/>
        <source>Torrent file association</source>
        <translation>Assoziation zur Torrent Datei</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="288"/>
        <source>qBittorrent is not the default application to open torrent files or Magnet links.
Do you want to associate qBittorrent to torrent files and Magnet links?</source>
        <translation>qBittorrent ist nicht die Standardapplikation um Torrent Dateien oder Magnet Links zu öffnen.
Möchten Sie Torrent Dateien und Magnet Links immer mit qBittorent öffnen?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="381"/>
        <location filename="../mainwindow.cpp" line="401"/>
        <location filename="../mainwindow.cpp" line="651"/>
        <source>UI lock password</source>
        <translation>Passwort um das User Interface zu sperren</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="381"/>
        <location filename="../mainwindow.cpp" line="401"/>
        <location filename="../mainwindow.cpp" line="651"/>
        <source>Please type the UI lock password:</source>
        <translation>Bitte geben Sie das Passwort für das User Interface ein:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="385"/>
        <source>The password should contain at least 3 characters</source>
        <translation>Das Passwort sollte aus mindestens drei Zeichen bestehen</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="391"/>
        <source>Password update</source>
        <translation>Passwort aktualisieren</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="391"/>
        <source>The UI lock password has been successfully updated</source>
        <translation>Das Passwort zum sperren des User Interface wurde erfolgreich aktualisiert</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="417"/>
        <source>RSS</source>
        <translation>RSS</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="432"/>
        <source>Search</source>
        <translation>Suche</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="442"/>
        <source>Transfers (%1)</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="513"/>
        <source>Download completion</source>
        <translation>Download beendigen</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="513"/>
        <source>%1 has finished downloading.</source>
        <comment>e.g: xxx.avi has finished downloading.</comment>
        <translation>%1 wurde heruntergeladen.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="519"/>
        <source>I/O Error</source>
        <comment>i.e: Input/Output Error</comment>
        <translation>I/O Fehler</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="519"/>
        <source>An I/O error occured for torrent %1.
 Reason: %2</source>
        <comment>e.g: An error occured for torrent xxx.avi.
 Reason: disk is full.</comment>
        <translation>Im Torrent %1 ist einI/O Fehler aufgetreten. Ursache: %2</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="526"/>
        <source>Alt+1</source>
        <comment>shortcut to switch to first tab</comment>
        <translation>Alt+1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="528"/>
        <source>Alt+2</source>
        <comment>shortcut to switch to third tab</comment>
        <translation>Alt+2</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="530"/>
        <source>Ctrl+F</source>
        <comment>shortcut to switch to search tab</comment>
        <translation>Strg+F</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="532"/>
        <source>Alt+3</source>
        <comment>shortcut to switch to fourth tab</comment>
        <translation>Alt+3</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="572"/>
        <source>Recursive download confirmation</source>
        <translation>Rekursiven Download bestätigen</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="572"/>
        <source>The torrent %1 contains torrent files, do you want to proceed with their download?</source>
        <translation>Der Torrent %1 enthält weitere Torrent Dateien, möchten Sie diese herunterladen?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="573"/>
        <location filename="../mainwindow.cpp" line="744"/>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="574"/>
        <location filename="../mainwindow.cpp" line="743"/>
        <source>No</source>
        <translation>Nein</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="575"/>
        <source>Never</source>
        <translation>Niemals</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="589"/>
        <source>Url download error</source>
        <translation>Fehler beim Laden der URL</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="589"/>
        <source>Couldn&apos;t download file at url: %1, reason: %2.</source>
        <translation>Konnte Datei von URL: %1 nicht laden, Begründung: %2.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="600"/>
        <source>Global Upload Speed Limit</source>
        <translation>Globale Begrenzung der Uploadgeschwindigkeit</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="619"/>
        <source>Global Download Speed Limit</source>
        <translation>Globale Begrenzung der Downloadgeschwindigkeit</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="385"/>
        <location filename="../mainwindow.cpp" line="664"/>
        <source>Invalid password</source>
        <translation>Ungültiges Passwort</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="664"/>
        <source>The password is invalid</source>
        <translation>Das Passwort ist ungültig</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="740"/>
        <source>Exiting qBittorrent</source>
        <translation>Beende qBittorrent</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="741"/>
        <source>Some files are currently transferring.
Are you sure you want to quit qBittorrent?</source>
        <translation>Zur Zeit werden Dateien übertragen.
Sind Sie sicher, daß sie qBittorrent beenden möchten?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="745"/>
        <source>Always</source>
        <translation>Immer</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="903"/>
        <source>Open Torrent Files</source>
        <translation>Öffne Torrent-Dateien</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="904"/>
        <source>Torrent Files</source>
        <translation>Torrent-Dateien</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="983"/>
        <source>Options were saved successfully.</source>
        <translation>Einstellungen wurden erfolgreich gespeichert.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1092"/>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1095"/>
        <location filename="../mainwindow.cpp" line="1102"/>
        <source>DL speed: %1 KiB/s</source>
        <comment>e.g: Download speed: 10 KiB/s</comment>
        <translation>Downloadgeschwindigkeit: %1 KB/s</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1098"/>
        <location filename="../mainwindow.cpp" line="1104"/>
        <source>UP speed: %1 KiB/s</source>
        <comment>e.g: Upload speed: 10 KiB/s</comment>
        <translation>Uploadgeschwindigkeit: %1 KiB/s</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1109"/>
        <source>qBittorrent %1 (Down: %2/s, Up: %3/s)</source>
        <comment>%1 is qBittorrent version</comment>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1289"/>
        <source>A newer version is available</source>
        <translation>Eine neuere Version ist erhältlich</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1290"/>
        <source>A newer version of qBittorrent is available on Sourceforge.
Would you like to update qBittorrent to version %1?</source>
        <translation>Eine neuere Version von qBittorrent ist auf Sourceforge erhätlich. Möchten Sie qBittorent auf die Version %1 aktualisieren?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1305"/>
        <source>Impossible to update qBittorrent</source>
        <translation>Aktuialisierung von qBittorrent nicht möglich</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1305"/>
        <source>qBittorrent failed to update, reason: %1</source>
        <translation>qBittorrent konnte nicht aktualisiert werden, Begründung: %1</translation>
    </message>
</context>
<context>
    <name>PeerAdditionDlg</name>
    <message>
        <location filename="../properties/peeraddition.h" line="94"/>
        <source>Invalid IP</source>
        <translation>Ungültige IP</translation>
    </message>
    <message>
        <location filename="../properties/peeraddition.h" line="95"/>
        <source>The IP you provided is invalid.</source>
        <translation>Die angegebene IP ist ungültig.</translation>
    </message>
</context>
<context>
    <name>PeerListDelegate</name>
    <message>
        <location filename="../properties/peerlistdelegate.h" line="64"/>
        <source>/s</source>
        <comment>/second (i.e. per second)</comment>
        <translation>/s</translation>
    </message>
</context>
<context>
    <name>PeerListWidget</name>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="61"/>
        <source>IP</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="62"/>
        <source>Connection</source>
        <translation type="unfinished">Verbindung</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="63"/>
        <source>Client</source>
        <comment>i.e.: Client application</comment>
        <translation></translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="64"/>
        <source>Progress</source>
        <comment>i.e: % downloaded</comment>
        <translation>Fortschritt</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="65"/>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>DL-Rate</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="66"/>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>UL-Rate</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="67"/>
        <source>Downloaded</source>
        <comment>i.e: total data downloaded</comment>
        <translation>Runtergeladen</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="68"/>
        <source>Uploaded</source>
        <comment>i.e: total data uploaded</comment>
        <translation>Hochgeladen</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="139"/>
        <source>Add a new peer...</source>
        <translation>Füge einen neuen Peer hinzu...</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="148"/>
        <source>Copy IP</source>
        <translation>IP kopieren</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="150"/>
        <source>Limit download rate...</source>
        <translation>Downloadrate begrenzen...</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="151"/>
        <source>Limit upload rate...</source>
        <translation>Uploadrate begrenzen...</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="153"/>
        <source>Ban peer permanently</source>
        <translation>Peer dauerhaft bannen</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="164"/>
        <location filename="../properties/peerlistwidget.cpp" line="166"/>
        <source>Peer addition</source>
        <translation>Peer hinzufügen</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="164"/>
        <source>The peer was added to this torrent.</source>
        <translation>Der Peer wurde diesem Torrent hinzugefügt.</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="166"/>
        <source>The peer could not be added to this torrent.</source>
        <translation>Der Peer konnte diesem Torrent nicht hinzugefügt werden.</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="196"/>
        <source>Are you sure? -- qBittorrent</source>
        <translation>Sind Sie sicher? -- qBittorrent</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="196"/>
        <source>Are you sure you want to ban permanently the selected peers?</source>
        <translation>Sind Sie sicher, daß Sie die ausgewählten Peers dauferhaft bannen möchten?</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="197"/>
        <source>&amp;Yes</source>
        <translation>&amp;Ja</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="197"/>
        <source>&amp;No</source>
        <translation>&amp;Nein</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="202"/>
        <source>Manually banning peer %1...</source>
        <translation>Peer %1 von Hand bannen...</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="221"/>
        <source>Upload rate limiting</source>
        <translation>Begrenzung der Uploadrate</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="249"/>
        <source>Download rate limiting</source>
        <translation>Begrenzung der Downloadrate</translation>
    </message>
</context>
<context>
    <name>Preferences</name>
    <message>
        <location filename="../preferences/options.ui" line="93"/>
        <source>Downloads</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="104"/>
        <source>Connection</source>
        <translation>Verbindung</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="134"/>
        <source>Web UI</source>
        <translation>Webinterface</translation>
    </message>
    <message>
        <source>Language:</source>
        <translation type="obsolete">Sprache:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="219"/>
        <source>(Requires restart)</source>
        <translation>(Neustart benötigt)</translation>
    </message>
    <message>
        <source>Visual style:</source>
        <translation type="obsolete">Visueller Stil:</translation>
    </message>
    <message>
        <source>Transfer list</source>
        <translation type="obsolete">Transferliste</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="253"/>
        <source>Use alternating row colors</source>
        <extracomment>In transfer list, one every two rows will have grey background.</extracomment>
        <translation>Abwechselnde Reihenfarben verwenden</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="412"/>
        <source>Tray icon style:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="420"/>
        <source>Normal</source>
        <translation type="unfinished">Normal</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="425"/>
        <source>Monochrome (Dark theme)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="430"/>
        <source>Monochrome (Light theme)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File system</source>
        <translation type="obsolete">Datei System</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="762"/>
        <source>Copy .torrent files to:</source>
        <translation>.torrent Datei kopieren nach:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="891"/>
        <source>This server requires a secure connection (SSL)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="918"/>
        <source>The following parameters are supported:
&lt;ul&gt;
&lt;li&gt;%f: Torrent path&lt;/li&gt;
&lt;li&gt;%n: Torrent name&lt;/li&gt;
&lt;/ul&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="960"/>
        <source>Listening Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1025"/>
        <source>Connections Limits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1145"/>
        <source>Proxy Server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1241"/>
        <source>Otherwise, the proxy server is only used for tracker connections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1244"/>
        <source>Use proxy for peer connections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1402"/>
        <source>Global Rate Limits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1520"/>
        <source>Apply rate limit to uTP connections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1527"/>
        <source>Apply rate limit to transport overhead</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1540"/>
        <source>Alternative Global Rate Limits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1646"/>
        <source>Schedule the use of alternative rate limits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1909"/>
        <source>Enable Local Peer Discovery to find more peers</source>
        <translation>Lokale Peer Auffindung aktivieren um mehr peers zu finden</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1921"/>
        <source>Encryption mode:</source>
        <translation>Verschlüsselungsmodus:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1929"/>
        <source>Prefer encryption</source>
        <translation>Verschlüsselung bevorzugen</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1934"/>
        <source>Require encryption</source>
        <translation>Verschlüsselung verlangen</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1939"/>
        <source>Disable encryption</source>
        <translation>Verschlüsselng deaktiviere</translation>
    </message>
    <message>
        <source>Torrent queueing</source>
        <translation type="obsolete">Torrent Warteschlangen</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1980"/>
        <source>Maximum active downloads:</source>
        <translation>Maximal aktive Downloads:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2000"/>
        <source>Maximum active uploads:</source>
        <translation>Maximal aktive Uploads:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2020"/>
        <source>Maximum active torrents:</source>
        <translation>Maximal aktive Torrents:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="504"/>
        <source>When adding a torrent</source>
        <translation>Sobald ein Torrent hinzugefügt wird</translation>
    </message>
    <message>
        <source>Visual Appearance</source>
        <translation type="obsolete">Visuelles Erscheinungsbild</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="269"/>
        <source>Action on double-click</source>
        <translation>Aktion bei Doppelklick</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="284"/>
        <source>Downloading torrents:</source>
        <translation>Lade Torrents:</translation>
    </message>
    <message>
        <source>Start / Stop</source>
        <translation type="obsolete">Start / Stop</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="306"/>
        <location filename="../preferences/options.ui" line="332"/>
        <source>Open destination folder</source>
        <translation>Zielverzeichnis öffnen</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="319"/>
        <source>Completed torrents:</source>
        <translation>Abgeschlossene Torrents:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="351"/>
        <source>Desktop</source>
        <translation>Screibtisch</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="357"/>
        <source>Show splash screen on start up</source>
        <translation>Splash Screen beim Start zeigen</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="367"/>
        <source>Start qBittorrent minimized</source>
        <translation>qBittorrent minimiert starten</translation>
    </message>
    <message>
        <source>Show qBittorrent icon in notification area</source>
        <translation type="obsolete">qBittorrent Icon im Benachrichtigungsbereich zeigen</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="393"/>
        <source>Minimize qBittorrent to notification area</source>
        <translation>qBittorrent in den Benachrichtigungsbereich minimieren</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="403"/>
        <source>Close qBittorrent to notification area</source>
        <comment>i.e: The systray tray icon will still be visible when closing the main window.</comment>
        <translation>qBittorrent in den Benachrichtigungsbereich schliessen</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="513"/>
        <source>Display torrent content and some options</source>
        <translation>Zeige Inhalt des Torrent und einige Optionen</translation>
    </message>
    <message>
        <source>Listening port</source>
        <translation type="obsolete">Port auf dem gelauscht wird</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="968"/>
        <source>Port used for incoming connections:</source>
        <translation>Port für eingehende Verbindungen:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="988"/>
        <source>Random</source>
        <translation>Zufällig</translation>
    </message>
    <message>
        <source>Enable UPnP port mapping</source>
        <translation type="obsolete">UPnP Port Mapping aktivieren</translation>
    </message>
    <message>
        <source>Enable NAT-PMP port mapping</source>
        <translation type="obsolete">NAP-PMP Port Mapping aktivieren</translation>
    </message>
    <message>
        <source>Connections limit</source>
        <translation type="obsolete">Verbindungsbeschränkung</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1031"/>
        <source>Global maximum number of connections:</source>
        <translation>Global maximale Anzahl der Verbindungen:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1057"/>
        <source>Maximum number of connections per torrent:</source>
        <translation>Maximale Anzahl der Verbindungen pro Torrent:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1080"/>
        <source>Maximum number of upload slots per torrent:</source>
        <translation>Maximale Anzahl Upload-Slots pro Torrent:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1420"/>
        <location filename="../preferences/options.ui" line="1575"/>
        <source>Upload:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1456"/>
        <location filename="../preferences/options.ui" line="1602"/>
        <source>Download:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1449"/>
        <location filename="../preferences/options.ui" line="1482"/>
        <location filename="../preferences/options.ui" line="1595"/>
        <location filename="../preferences/options.ui" line="1622"/>
        <source>KiB/s</source>
        <translation></translation>
    </message>
    <message>
        <source>Bittorrent features</source>
        <translation type="obsolete">Bittorrent Funktionen</translation>
    </message>
    <message>
        <source>Enable DHT network (decentralized)</source>
        <translation type="obsolete">DHT Netzwerk aktivieren (dezentralisiert)</translation>
    </message>
    <message>
        <source>Use a different port for DHT and Bittorrent</source>
        <translation type="obsolete">Unterschiedliche Ports für DHT und Bittorrent verwenden</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1852"/>
        <source>DHT port:</source>
        <translation>DHT Port:</translation>
    </message>
    <message utf8="true">
        <location filename="../preferences/options.ui" line="1893"/>
        <source>Exchange peers with compatible Bittorrent clients (µTorrent, Vuze, ...)</source>
        <translation>Peers mit kompatiblen Bittorrent Clients austauchen (µTorrent, Vuze, ...)</translation>
    </message>
    <message>
        <source>Enable Peer Exchange / PeX (requires restart)</source>
        <translation type="obsolete">Peer Exchange / PeX aktivieren (erfordert Neustart)</translation>
    </message>
    <message>
        <source>Enable Local Peer Discovery</source>
        <translation type="obsolete">Lokale Peer Auffindung aktivieren</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation type="obsolete">Aktiviert</translation>
    </message>
    <message>
        <source>Forced</source>
        <translation type="obsolete">Erzwungen</translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation type="obsolete">Deaktiviert</translation>
    </message>
    <message>
        <source>HTTP Communications (trackers, Web seeds, search engine)</source>
        <translation type="obsolete">HTTP Kommunikation (Tracker, Web-Seeds, Suchmaschine)</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1187"/>
        <source>Host:</source>
        <translation></translation>
    </message>
    <message>
        <source>Peer Communications</source>
        <translation type="obsolete">Peer Kommunikation</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1166"/>
        <source>SOCKS4</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1153"/>
        <source>Type:</source>
        <translation>Typ:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="20"/>
        <location filename="../preferences/options.ui" line="1504"/>
        <source>Options</source>
        <translation>Optionen</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="79"/>
        <location filename="../preferences/options.ui" line="82"/>
        <source>Behavior</source>
        <translation>Verhalten</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="115"/>
        <source>Speed</source>
        <translation>Geschwindigkeit</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="145"/>
        <source>Advanced</source>
        <translation>Fortgeschritten</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="190"/>
        <source>User Interface Language:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="247"/>
        <source>Transfer List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="311"/>
        <location filename="../preferences/options.ui" line="337"/>
        <source>No action</source>
        <translation>Keine Aktion</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="659"/>
        <source>Append .!qB extension to incomplete files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="729"/>
        <source>Remove folder</source>
        <translation>Verzeichnis entfernen</translation>
    </message>
    <message>
        <source>Global speed limits</source>
        <translation type="obsolete">Globale Geschwindigkeitsbegrenzung</translation>
    </message>
    <message>
        <source>Alternative global speed limits</source>
        <translation type="obsolete">Alternative globale Geschwindigkeitsbegrenzung</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1687"/>
        <source>to</source>
        <extracomment>time1 to time2</extracomment>
        <translation>bis</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="523"/>
        <source>Do not start the download automatically</source>
        <comment>The torrent will be added to download list in pause state</comment>
        <translation>Download nicht automatisch starten</translation>
    </message>
    <message>
        <source>User Interface</source>
        <translation type="obsolete">Benutzerschnittstelle</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="123"/>
        <source>BitTorrent</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="182"/>
        <source>Language</source>
        <translation>Sprache</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="301"/>
        <location filename="../preferences/options.ui" line="327"/>
        <source>Start / Stop Torrent</source>
        <translation></translation>
    </message>
    <message>
        <source>Use monochrome system tray icon (requires restart)</source>
        <translation type="obsolete">Monochrome Systemtray-Icons verwenden (Neustart benötigt)</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="374"/>
        <source>Ask for program exit confirmation</source>
        <translation>Beenden bestätigen</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="384"/>
        <source>Show qBittorrent in notification area</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="446"/>
        <source>Power Management</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="452"/>
        <source>Inhibit system sleep when torrents are active</source>
        <translation>Das System davon abhalten in den Schlafmodus zu gehen, wenn noch Torrents aktiv sind</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="539"/>
        <source>Hard Disk</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="548"/>
        <source>Save files to location:</source>
        <translation>Datei an diesem Ort speichern:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="596"/>
        <source>Append the label of the torrent to the save path</source>
        <translation>Label des Torrents an den Speicherpfad anhängen</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="606"/>
        <source>Pre-allocate disk space for all files</source>
        <translation>Allen Dateien Speicherplatz im vorhinein zuweisen</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="613"/>
        <source>Keep incomplete torrents in:</source>
        <translation>Unvollständige Torrents speichern in:</translation>
    </message>
    <message>
        <source>Append .!qB extension to incomplete files&apos; names</source>
        <translation type="obsolete">Die Dateienung .!qb an unvollständige Dateinamen anhängen</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="666"/>
        <source>Automatically add torrents from:</source>
        <translation>Dateien mit der Endung .torrent aus diesem Verzeichnis automatisch hinzufügen:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="719"/>
        <source>Add folder...</source>
        <translation>Verzeichnis hinzufügen...</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="818"/>
        <source>Email notification upon download completion</source>
        <translation>Email Benachrichtigung wenn Download vollständig ist</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="832"/>
        <source>Destination email:</source>
        <translation>Zieladresse:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="842"/>
        <source>SMTP server:</source>
        <translation>SMTP Server:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="903"/>
        <source>Run an external program on torrent completion</source>
        <translation>Externes Programm ausführen wenn Torrent vollständig ist</translation>
    </message>
    <message>
        <source>Use %f to pass the torrent path in parameters</source>
        <translation type="obsolete">Verwenden Sie %f um den Torrentpfad als Parameter zu übergeben</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1010"/>
        <source>Use UPnP / NAT-PMP port forwarding from my router</source>
        <translation>UPnP / NAT-PMP Port Wieterleitung meines Routers verwenden</translation>
    </message>
    <message>
        <source>Proxy server</source>
        <translation type="obsolete">Proxyserver</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1316"/>
        <source>IP Filtering</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1357"/>
        <source>Reload the filter</source>
        <translation>Filter neu laden</translation>
    </message>
    <message>
        <source>Schedule the use of alternative speed limits</source>
        <translation type="obsolete">Benutzung von alternativen Geschwindigkeitsbegrenzungen einteilen</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1663"/>
        <source>from</source>
        <extracomment>from (time1 to time2)</extracomment>
        <translation>von</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1731"/>
        <source>When:</source>
        <translation>Wann:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1739"/>
        <source>Every day</source>
        <translation>Jeden Tag</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1744"/>
        <source>Week days</source>
        <translation>Wochentage</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1749"/>
        <source>Week ends</source>
        <translation>Wochenenden</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1814"/>
        <source>Privacy</source>
        <translation>Privatsphäre</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1820"/>
        <source>Enable DHT (decentralized network) to find more peers</source>
        <translation>DHT (dezentralisiertes Netzwerk) aktivieren um mehr Peers zu finden</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1832"/>
        <source>Use a different port for DHT and BitTorrent</source>
        <translation>Unterschiedliche Ports für DHT und BitTorrent verwenden</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1896"/>
        <source>Enable Peer Exchange (PeX) to find more peers</source>
        <translation>Peer Exchange (PeX) aktivieren um mehr Peers zu finden</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1906"/>
        <source>Look for peers on your local network</source>
        <translation>Nach Peers im lokalen Netzwek suchen</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1965"/>
        <source>Torrent Queueing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2082"/>
        <source>Share Ratio Limiting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2239"/>
        <source>Use UPnP / NAT-PMP to forward the port from my router</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2249"/>
        <source>Use HTTPS instead of HTTP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2292"/>
        <source>Import SSL Certificate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2345"/>
        <source>Import SSL Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2280"/>
        <source>Certificate:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2333"/>
        <source>Key:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2367"/>
        <source>&lt;a href=http://httpd.apache.org/docs/2.1/ssl/ssl_faq.html#aboutcerts&gt;Information about certificates&lt;/a&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2412"/>
        <source>Bypass authentication for localhost</source>
        <translation>Authentifizierung für localhost umgehen</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2436"/>
        <source>Update my dynamic domain name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2448"/>
        <source>Service:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2471"/>
        <source>Register</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2480"/>
        <source>Domain name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Protocol encryption:</source>
        <translation type="obsolete">Protokoll-Verschlüsselung:</translation>
    </message>
    <message>
        <source>Share ratio limiting</source>
        <translation type="obsolete">Shareverhältnis Begrenzung</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2093"/>
        <source>Seed torrents until their ratio reaches</source>
        <translation>Torrents seeden bis diese Verhältnis erreicht wurde</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2125"/>
        <source>then</source>
        <translation>dann</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2136"/>
        <source>Pause them</source>
        <translation>Anhalten</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2141"/>
        <source>Remove them</source>
        <translation>Entfernen</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1161"/>
        <source>(None)</source>
        <translation>(Keine)</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1176"/>
        <source>HTTP</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1213"/>
        <location filename="../preferences/options.ui" line="2204"/>
        <source>Port:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="852"/>
        <location filename="../preferences/options.ui" line="1254"/>
        <location filename="../preferences/options.ui" line="2380"/>
        <source>Authentication</source>
        <translation>Authentifizierung</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="864"/>
        <location filename="../preferences/options.ui" line="1268"/>
        <location filename="../preferences/options.ui" line="2419"/>
        <location filename="../preferences/options.ui" line="2494"/>
        <source>Username:</source>
        <translation>Benutzername:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="874"/>
        <location filename="../preferences/options.ui" line="1288"/>
        <location filename="../preferences/options.ui" line="2426"/>
        <location filename="../preferences/options.ui" line="2508"/>
        <source>Password:</source>
        <translation>Passwort:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1510"/>
        <source>Enable bandwidth management (uTP)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2190"/>
        <source>Enable Web User Interface (Remote control)</source>
        <translation>Webuser-Interface einschalten (Fernbedienung)</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1171"/>
        <source>SOCKS5</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1328"/>
        <source>Filter path (.dat, .p2p, .p2b):</source>
        <translation>Pfad zur Filterdatei (.dat, .p2p, p2b):</translation>
    </message>
</context>
<context>
    <name>PreviewSelect</name>
    <message>
        <location filename="../previewselect.cpp" line="48"/>
        <source>Name</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../previewselect.cpp" line="49"/>
        <source>Size</source>
        <translation>Größe</translation>
    </message>
    <message>
        <location filename="../previewselect.cpp" line="50"/>
        <source>Progress</source>
        <translation>Fortschritt</translation>
    </message>
    <message>
        <location filename="../previewselect.cpp" line="75"/>
        <location filename="../previewselect.cpp" line="110"/>
        <location filename="../previewselect.cpp" line="116"/>
        <source>Preview impossible</source>
        <translation>Vorschau nicht möglich</translation>
    </message>
    <message>
        <location filename="../previewselect.cpp" line="75"/>
        <location filename="../previewselect.cpp" line="110"/>
        <location filename="../previewselect.cpp" line="116"/>
        <source>Sorry, we can&apos;t preview this file</source>
        <translation>Bedauere, es kann keine Vorschau für diese Datei erstellen werden</translation>
    </message>
</context>
<context>
    <name>ProgramUpdater</name>
    <message>
        <source>Could not create the file %1</source>
        <translation type="obsolete">Die Datei %1 konnte nicht erstellt werden</translation>
    </message>
    <message>
        <source>Failed to download the update at %1</source>
        <comment>%1 is an URL</comment>
        <translation type="obsolete">Dowload des Update von %1 fehlgeschlagen</translation>
    </message>
</context>
<context>
    <name>PropListDelegate</name>
    <message>
        <location filename="../properties/proplistdelegate.h" line="116"/>
        <location filename="../properties/proplistdelegate.h" line="171"/>
        <source>Normal</source>
        <comment>Normal (priority)</comment>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../properties/proplistdelegate.h" line="110"/>
        <location filename="../properties/proplistdelegate.h" line="172"/>
        <source>High</source>
        <comment>High (priority)</comment>
        <translation>Hoch</translation>
    </message>
    <message>
        <location filename="../properties/proplistdelegate.h" line="104"/>
        <source>Mixed</source>
        <comment>Mixed (priorities</comment>
        <translation>Gemischt</translation>
    </message>
    <message>
        <location filename="../properties/proplistdelegate.h" line="107"/>
        <source>Not downloaded</source>
        <translation>Nicht heruntergeladen</translation>
    </message>
    <message>
        <location filename="../properties/proplistdelegate.h" line="113"/>
        <location filename="../properties/proplistdelegate.h" line="173"/>
        <source>Maximum</source>
        <comment>Maximum (priority)</comment>
        <translation>Maximum</translation>
    </message>
</context>
<context>
    <name>PropTabBar</name>
    <message>
        <location filename="../properties/proptabbar.cpp" line="55"/>
        <source>General</source>
        <translation>Allgemein</translation>
    </message>
    <message>
        <location filename="../properties/proptabbar.cpp" line="62"/>
        <source>Trackers</source>
        <translation>Tracker</translation>
    </message>
    <message>
        <location filename="../properties/proptabbar.cpp" line="68"/>
        <source>Peers</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../properties/proptabbar.cpp" line="74"/>
        <source>HTTP Sources</source>
        <translation>HTTP Quellen</translation>
    </message>
    <message>
        <location filename="../properties/proptabbar.cpp" line="80"/>
        <source>Content</source>
        <translation>Inhalt</translation>
    </message>
    <message>
        <source>Files</source>
        <translation type="obsolete">Dateien</translation>
    </message>
</context>
<context>
    <name>PropertiesWidget</name>
    <message>
        <location filename="../properties/propertieswidget.ui" line="351"/>
        <source>Save path:</source>
        <translation>Speicher-Pfad:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="459"/>
        <source>Torrent hash:</source>
        <translation>Torrent Prüfsumme:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="545"/>
        <source>Comment:</source>
        <translation>Kommentar:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="211"/>
        <source>Share ratio:</source>
        <translation>Share Verhältnis:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="82"/>
        <location filename="../properties/propertieswidget.ui" line="228"/>
        <source>Downloaded:</source>
        <translation>Runtergeladen:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="136"/>
        <source>Availability:</source>
        <translation>Erreichbarkeit:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="171"/>
        <source>Transfer</source>
        <translation>Übertragungen</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="177"/>
        <source>Uploaded:</source>
        <translation>Hochgeladen:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="279"/>
        <source>Wasted:</source>
        <translation>Verworfen:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="296"/>
        <source>Time active:</source>
        <extracomment>Time (duration) the torrent is active (not paused)</extracomment>
        <translation>Aktiv seit:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="502"/>
        <source>Pieces size:</source>
        <translation>Größe der Teile:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="774"/>
        <source>Torrent content:</source>
        <translation>Inhalt des Torrent:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="827"/>
        <source>Select All</source>
        <translation>Alle Auswählen</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="834"/>
        <source>Select None</source>
        <translation>Keine Auswählen</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="882"/>
        <location filename="../properties/propertieswidget.ui" line="885"/>
        <source>Do not download</source>
        <translation>Nicht herunterladen</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="194"/>
        <source>UP limit:</source>
        <translation>UL-Limit:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="245"/>
        <source>DL limit:</source>
        <translation>DL-Limit:</translation>
    </message>
    <message>
        <source>Time elapsed:</source>
        <translation type="obsolete">Zeitverlauf:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="262"/>
        <source>Connections:</source>
        <translation>Verbindungen:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="313"/>
        <source>Reannounce in:</source>
        <translation>Bekanngeben in:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="339"/>
        <source>Information</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="413"/>
        <source>Created on:</source>
        <translation>Erstellt am:</translation>
    </message>
    <message>
        <source>General</source>
        <translation type="obsolete">Allgemein</translation>
    </message>
    <message>
        <source>Trackers</source>
        <translation type="obsolete">Tracker</translation>
    </message>
    <message>
        <source>URL seeds</source>
        <translation type="obsolete">URL Seeds</translation>
    </message>
    <message>
        <source>Files</source>
        <translation type="obsolete">Dateien</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="476"/>
        <source>Priority</source>
        <translation>Priorität</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="867"/>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="877"/>
        <source>Maximum</source>
        <translation>Maximum</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="872"/>
        <source>High</source>
        <translation>Hoch</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="329"/>
        <location filename="../properties/propertieswidget.cpp" line="330"/>
        <source>this session</source>
        <translation>diese Sitzung</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="334"/>
        <location filename="../properties/propertieswidget.cpp" line="338"/>
        <source>/s</source>
        <comment>/second (i.e. per second)</comment>
        <translation>/s</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="341"/>
        <source>Seeded for %1</source>
        <comment>e.g. Seeded for 3m10s</comment>
        <translation>Geseeded seit %1</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="345"/>
        <source>%1 max</source>
        <comment>e.g. 10 max</comment>
        <translation></translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="435"/>
        <location filename="../properties/propertieswidget.cpp" line="457"/>
        <source>I/O Error</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="435"/>
        <source>This file does not exist yet.</source>
        <translation>Diese Datei existiert noch nicht.</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="457"/>
        <source>This folder does not exist yet.</source>
        <translation>Dieses Verzeichnis existiert noch nicht.</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="467"/>
        <source>Rename...</source>
        <translation>Umbenennen...</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="518"/>
        <source>Rename the file</source>
        <translation>Datei umbenennen</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="519"/>
        <source>New name:</source>
        <translation>Neuer Name:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="523"/>
        <location filename="../properties/propertieswidget.cpp" line="555"/>
        <source>The file could not be renamed</source>
        <translation>Die Datei konnte nicht umbenannt werden</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="524"/>
        <source>This file name contains forbidden characters, please choose a different one.</source>
        <translation>Der Dateiname enthält ungültige Zeichen, bitte einen anderen wählen.</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="556"/>
        <location filename="../properties/propertieswidget.cpp" line="594"/>
        <source>This name is already in use in this folder. Please use a different name.</source>
        <translation>Der Dateiname wird in diesem Verzeichnis bereits verwendet. Bitte anderen wählen.</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="593"/>
        <source>The folder could not be renamed</source>
        <translation>Das Verzeichnis konnte nicht umbenannt werden</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="632"/>
        <source>New url seed</source>
        <comment>New HTTP source</comment>
        <translation>Neuer URL Seed</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="633"/>
        <source>New url seed:</source>
        <translation>Neuer URL Seed:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="638"/>
        <source>qBittorrent</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="639"/>
        <source>This url seed is already in the list.</source>
        <translation>Dieser URL Seed befindet sich bereits in der Liste.</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="681"/>
        <location filename="../properties/propertieswidget.cpp" line="684"/>
        <source>Choose save path</source>
        <translation>Wählen Sie den Speicher-Pfad</translation>
    </message>
    <message>
        <source>Save path creation error</source>
        <translation type="obsolete">Fehler beim Erstellen des Speicher-Pfades</translation>
    </message>
    <message>
        <source>Could not create the save path</source>
        <translation type="obsolete">Speicher-Pfad konnte nicht erstellt werden</translation>
    </message>
</context>
<context>
    <name>QBtSession</name>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="226"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="232"/>
        <source>%1 reached the maximum ratio you set.</source>
        <translation>%1 hat das gesetzte maximale Verhältnis erreicht.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="227"/>
        <source>Removing torrent %1...</source>
        <translation>Entferne Torrent %1...</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="233"/>
        <source>Pausing torrent %1...</source>
        <translation>Torrent %1 anhalten...</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="287"/>
        <source>qBittorrent is bound to port: TCP/%1</source>
        <comment>e.g: qBittorrent is bound to port: 6881</comment>
        <translation>qBittorrent lauscht auf Port: TCP/%1</translation>
    </message>
    <message>
        <source>UPnP support [ON]</source>
        <translation type="obsolete">UPNP Unterstützung [EIN]</translation>
    </message>
    <message>
        <source>UPnP support [OFF]</source>
        <translation type="obsolete">UPnP Unterstützung [AUS]</translation>
    </message>
    <message>
        <source>NAT-PMP support [ON]</source>
        <translation type="obsolete">NAT-PMP Unterstützung [EIN]</translation>
    </message>
    <message>
        <source>NAT-PMP support [OFF]</source>
        <translation type="obsolete">NAT-PMP Unterstützung [AUS]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="384"/>
        <source>HTTP user agent is %1</source>
        <translation>HTTP Benutzerschnittstelle ist %1</translation>
    </message>
    <message>
        <source>Using a disk cache size of %1 MiB</source>
        <translation type="obsolete">Verwende eine Plattencachegröße von %1 MiB</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="494"/>
        <source>DHT support [ON], port: UDP/%1</source>
        <translation>DHT Unterstützung [EIN], Port: UDP/%1</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="496"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="500"/>
        <source>DHT support [OFF]</source>
        <translation>DHT Unterstützung [AUS]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="504"/>
        <source>PeX support [ON]</source>
        <translation>PeX Unterstützung [EIN]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="506"/>
        <source>PeX support [OFF]</source>
        <translation>PeX Unterstützung [AUS]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="509"/>
        <source>Restart is required to toggle PeX support</source>
        <translation>Neustart erforderlich um PeX Unterstützung umzuschalten</translation>
    </message>
    <message>
        <source>Local Peer Discovery [ON]</source>
        <translation type="obsolete">Lokale Peers finden [EIN]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="517"/>
        <source>Local Peer Discovery support [OFF]</source>
        <translation>Lokale Peers finden [AUS]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="529"/>
        <source>Encryption support [ON]</source>
        <translation>Verschlüsselung [EIN]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="534"/>
        <source>Encryption support [FORCED]</source>
        <translation>Verschlüsselung [Erzwungen]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="539"/>
        <source>Encryption support [OFF]</source>
        <translation>Verschlüsselung [AUS]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="600"/>
        <source>Embedded Tracker [ON]</source>
        <translation>Eingebetter Tracker [EIN]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="602"/>
        <source>Failed to start the embedded tracker!</source>
        <translation>Starten des eingebetteten Trackers fehlgeschlagen!</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="605"/>
        <source>Embedded Tracker [OFF]</source>
        <translation>Eingebetter Tracker [AUS]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="659"/>
        <source>The Web UI is listening on port %1</source>
        <translation>Das Webinterface lauscht auf Port %1</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="661"/>
        <source>Web User Interface Error - Unable to bind Web UI to port %1</source>
        <translation>Fehler im Webinterface - Webinterface konnte nicht an Port %1 gebunden werden</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="796"/>
        <source>&apos;%1&apos; was removed from transfer list and hard disk.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>&apos;%1&apos; wurde von der Transferliste und von der Festplatte entfernt.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="798"/>
        <source>&apos;%1&apos; was removed from transfer list.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>&apos;%1&apos; wurde von der Transferliste entfernt.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="880"/>
        <source>&apos;%1&apos; is not a valid magnet URI.</source>
        <translation>&apos;%1&apos; ist keine gültige Magnet URI.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="896"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1018"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1023"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1025"/>
        <source>&apos;%1&apos; is already in download list.</source>
        <comment>e.g: &apos;xxx.avi&apos; is already in download list.</comment>
        <translation>&apos;%1&apos; befindet sich bereits in der Downloadliste.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1169"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1177"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1182"/>
        <source>&apos;%1&apos; resumed. (fast resume)</source>
        <comment>&apos;/home/y/xxx.torrent&apos; was resumed. (fast resume)</comment>
        <translation>&apos;%1&apos; fortgesetzt. (Schnelles Fortsetzen)</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="952"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1171"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1179"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1184"/>
        <source>&apos;%1&apos; added to download list.</source>
        <comment>&apos;/home/y/xxx.torrent&apos; was added to download list.</comment>
        <translation>&apos;%1&apos; der Downloadliste hinzugefügt.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="375"/>
        <source>UPnP / NAT-PMP support [ON]</source>
        <translation>UPnP / NAT-PMP Unterstützung [EIN]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="378"/>
        <source>UPnP / NAT-PMP support [OFF]</source>
        <translation>UPnP / NAT-PMP Unterstützung [AUS]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="440"/>
        <source>Reporting IP address %1 to trackers...</source>
        <translation>IP Adresse %1 dem Tracker melden...</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="514"/>
        <source>Local Peer Discovery support [ON]</source>
        <translation>Lokale Peers finden [EIN]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="987"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="994"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="996"/>
        <source>Unable to decode torrent file: &apos;%1&apos;</source>
        <comment>e.g: Unable to decode torrent file: &apos;/home/y/xxx.torrent&apos;</comment>
        <translation>Konnte Torrentdatei nicht dekodieren: &apos;%1&apos;</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1000"/>
        <source>This file is either corrupted or this isn&apos;t a torrent.</source>
        <translation>Diese Datei ist entweder fehlerhaft oder kein Torrent.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1040"/>
        <source>Error: The torrent %1 does not contain any file.</source>
        <translation>Fehler: Der Torret %1 enthält keine Dateien.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1328"/>
        <source>Note: new trackers were added to the existing torrent.</source>
        <translation>Bemerkung: Dem Torrent wurden neue Tracker hinzugefügt.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1354"/>
        <source>Note: new URL seeds were added to the existing torrent.</source>
        <translation>Bemerkung: Dem Torrent wurden neue URL-Seeds hinzugefügt.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1710"/>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;was blocked due to your IP filter&lt;/i&gt;</source>
        <comment>x.y.z.w was blocked</comment>
        <translation>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;wurde aufgrund Ihrer IP Filter geblockt&lt;/i&gt;</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1712"/>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;was banned due to corrupt pieces&lt;/i&gt;</source>
        <comment>x.y.z.w was banned</comment>
        <translation>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;wurde aufgrund von beschädigten Teilen gebannt&lt;/i&gt;</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1890"/>
        <source>The network interface defined is invalid: %1</source>
        <translation>Das angegeben Netzwerkinterface ist ungültig: %1</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1891"/>
        <source>Trying any other network interface available instead.</source>
        <translation>Versuche stattdessen ein anderes verfügbares Netzwerkinterface.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1914"/>
        <source>Listening on IP address %1 on network interface %2...</source>
        <translation>Lausche unter der IP Adresse %1 auf Netzwerkinterface %2...</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1917"/>
        <source>Failed to listen on network interface %1</source>
        <translation>An Netzwerkinterface %1 lauschen fehlgeschlagen</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2113"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2115"/>
        <source>Recursive download of file %1 embedded in torrent %2</source>
        <comment>Recursive download of test.torrent embedded in torrent test2</comment>
        <translation>Rekursiver Download von Datei %1, eingebettet in Torrent %2</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2210"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2212"/>
        <source>Unable to decode %1 torrent file.</source>
        <translation>Konnte Torrentdatei %1 nicht dekodieren.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2260"/>
        <source>The computer will now go to sleep mode unless you cancel within the next 15 seconds...</source>
        <translation>Der Computer wird in 15 Sekunden in den Schlafmodus wechseln...</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2262"/>
        <source>The computer will now be switched off unless you cancel within the next 15 seconds...</source>
        <translation>Der Computer wird in 15 Sekunden ausgeschaltet...</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2264"/>
        <source>qBittorrent will now exit unless you cancel within the next 15 seconds...</source>
        <translation>qBittorrent wird in 15 Sekunden beendet...</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2871"/>
        <source>Successfuly parsed the provided IP filter: %1 rules were applied.</source>
        <comment>%1 is a number</comment>
        <translation>IP-Filter erfolgreich geparsed: %1 Regeln wurden angewandt.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2877"/>
        <source>Error: Failed to parse the provided IP filter.</source>
        <translation>Fehler: IP-Filter konnte nicht geparsed werden.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2160"/>
        <source>Torrent name: %1</source>
        <translation>Name des Torrent: %1</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2161"/>
        <source>Torrent size: %1</source>
        <translation>Größe des Torrent: %1</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2162"/>
        <source>Save path: %1</source>
        <translation>Speicherpfad: %1</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2163"/>
        <source>The torrent was downloaded in %1.</source>
        <comment>The torrent was downloaded in 1 hour and 20 seconds</comment>
        <translation>Der Torrent wurde in %1 heruntergeladen.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2164"/>
        <source>Thank you for using qBittorrent.</source>
        <translation>Danke, daß Sie qBittorrent benutzen.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2167"/>
        <source>[qBittorrent] %1 has finished downloading</source>
        <translation>[qBittorrent] %1 vollständig heruntergeladen</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2427"/>
        <source>An I/O error occured, &apos;%1&apos; paused.</source>
        <translation>Ein I/O Fehler ist aufgetreten, &apos;%1&apos; angehalten.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2428"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2558"/>
        <source>Reason: %1</source>
        <translation>Begründung: %1</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2517"/>
        <source>UPnP/NAT-PMP: Port mapping failure, message: %1</source>
        <translation>UPnP/NAT-PMP: Portmappingfehler, Fehlermeldung: %1</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2522"/>
        <source>UPnP/NAT-PMP: Port mapping successful, message: %1</source>
        <translation>UPnP/NAT-PMP: Portmapping erfolgreich, Meldung: %1</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2553"/>
        <source>File sizes mismatch for torrent %1, pausing it.</source>
        <translation>Dateigrößen des Torrent %1 stimmen nicht überein, wird angehalten.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2557"/>
        <source>Fast resume data was rejected for torrent %1, checking again...</source>
        <translation>Fast-Resume des Torrent %1 wurde zurückgewiesen, prüfe erneut...</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2563"/>
        <source>Url seed lookup failed for url: %1, message: %2</source>
        <translation>URL Seed Lookup für die URL &apos;%1&apos; ist fehlgeschlagen, Begründung: %2</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2692"/>
        <source>Downloading &apos;%1&apos;, please wait...</source>
        <comment>e.g: Downloading &apos;xxx.torrent&apos;, please wait...</comment>
        <translation>Lade &apos;%1&apos;, bitte warten...</translation>
    </message>
</context>
<context>
    <name>RSS</name>
    <message>
        <location filename="../rss/rss.ui" line="17"/>
        <source>Search</source>
        <translation>Suche</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="25"/>
        <source>New subscription</source>
        <translation>Neues Abonnement</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="35"/>
        <location filename="../rss/rss.ui" line="183"/>
        <location filename="../rss/rss.ui" line="186"/>
        <source>Mark items read</source>
        <translation>Markiere Einträge als gelesen</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="54"/>
        <source>Update all</source>
        <translation>Aktualisiere alle</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="83"/>
        <source>RSS Downloader...</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="90"/>
        <source>Settings...</source>
        <translation>Einstellungen...</translation>
    </message>
    <message>
        <source>Feed URL</source>
        <translation type="obsolete">Feed-URL</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="154"/>
        <source>Rename...</source>
        <translation>Umbenennen...</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="162"/>
        <location filename="../rss/rss.ui" line="165"/>
        <source>Update</source>
        <translation>Aktualisieren</translation>
    </message>
    <message>
        <source>RSS feed downloader...</source>
        <translation type="obsolete">RSS-Feed-Downloader...</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="206"/>
        <source>New folder...</source>
        <translation>Neuer Ordner...</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="211"/>
        <source>Manage cookies...</source>
        <translation>Cookies verwalten...</translation>
    </message>
    <message>
        <source>RSS feeds</source>
        <translation type="obsolete">RSS-Feeds</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="112"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Torrents:&lt;/span&gt; &lt;span style=&quot; font-style:italic;&quot;&gt;(double-click to download)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Torrents:&lt;/span&gt; &lt;span style=&quot; font-style:italic;&quot;&gt;(Doppelklick zum downloaden)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Article title</source>
        <translation type="obsolete">Artikeltitel</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="170"/>
        <source>New subscription...</source>
        <translation>Neues Abonnement...</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="175"/>
        <location filename="../rss/rss.ui" line="178"/>
        <source>Update all feeds</source>
        <translation>Aktualisiere alle Feeds</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="146"/>
        <location filename="../rss/rss.ui" line="149"/>
        <source>Delete</source>
        <translation>Löschen</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="157"/>
        <source>Rename</source>
        <translation>Umbenennen</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="191"/>
        <source>Download torrent</source>
        <translation>Lade Torrent</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="196"/>
        <source>Open news URL</source>
        <translation>Öffne News-URL</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="201"/>
        <source>Copy feed URL</source>
        <translation>Kopiere Feed-URL</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="51"/>
        <source>Refresh RSS streams</source>
        <translation>Aktualisiere RSS Streams</translation>
    </message>
</context>
<context>
    <name>RSSImp</name>
    <message>
        <location filename="../rss/rss_imp.cpp" line="203"/>
        <source>Please type a rss stream url</source>
        <translation>Bitte eine RSS Stream Adresse eingeben</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="203"/>
        <source>Stream URL:</source>
        <translation>Stream URL:</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="237"/>
        <location filename="../rss/rss_imp.cpp" line="241"/>
        <source>Are you sure? -- qBittorrent</source>
        <translation>Sind Sie sicher? -- qBittorrent</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="238"/>
        <location filename="../rss/rss_imp.cpp" line="242"/>
        <source>&amp;Yes</source>
        <translation>&amp;Ja</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="238"/>
        <location filename="../rss/rss_imp.cpp" line="242"/>
        <source>&amp;No</source>
        <translation>&amp;Nein</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="149"/>
        <source>Please choose a folder name</source>
        <translation>Bitte wählen Sie einen Verzeichnisnamen</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="149"/>
        <source>Folder name:</source>
        <translation>Verzeichnisname:</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="149"/>
        <source>New folder</source>
        <translation>Neues Verzeichnis</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="170"/>
        <source>Overwrite attempt</source>
        <translation>Versuche zu überschreiben</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="171"/>
        <source>You cannot overwrite %1 item.</source>
        <comment>You cannot overwrite myFolder item.</comment>
        <translation>Eintrag %1 kann nicht überschrieben werden.</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="208"/>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="209"/>
        <source>This rss feed is already in the list.</source>
        <translation>Dieser RSS-Feed ist bereits in der Liste.</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="237"/>
        <source>Are you sure you want to delete these elements from the list?</source>
        <translation>Sind Sie sicher, daß Sie diese Elemente von der Liste entfernen möchten?</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="241"/>
        <source>Are you sure you want to delete this element from the list?</source>
        <translation>Sind Sie sicher, daß Sie dieses Element von der Liste entfernen möchten?</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="351"/>
        <source>Please choose a new name for this RSS feed</source>
        <translation>Bitte wählen Sie einen neuen Namen für diesen RSS-Feed</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="351"/>
        <source>New feed name:</source>
        <translation>Neuer Feed-Name:</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="355"/>
        <source>Name already in use</source>
        <translation>Name wird bereits verwendet</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="355"/>
        <source>This name is already used by another item, please choose another one.</source>
        <translation>Dieser Name wird bereits von einem anderen Eintrag verwendet, bitte wählen Sie einen anderen Namen.</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="508"/>
        <source>Date: </source>
        <translation> Datum:</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="511"/>
        <source>Author: </source>
        <translation> Autor:</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="554"/>
        <source>Unread</source>
        <translation>Ungelesen</translation>
    </message>
</context>
<context>
    <name>RssArticle</name>
    <message>
        <source>No description available</source>
        <translation type="obsolete">Keine Beschreibung vorhanden</translation>
    </message>
</context>
<context>
    <name>RssFeed</name>
    <message>
        <location filename="../rss/rssfeed.cpp" line="292"/>
        <source>Automatically downloading %1 torrent from %2 RSS feed...</source>
        <translation>Lade Torrent %1 automatisch von RSS-Feed %2...</translation>
    </message>
</context>
<context>
    <name>RssItem</name>
    <message>
        <source>No description available</source>
        <translation type="obsolete">Keine Beschreibung vorhanden</translation>
    </message>
</context>
<context>
    <name>RssSettings</name>
    <message>
        <source>RSS Reader Settings</source>
        <translation type="obsolete">RSS Reader Einstellungen</translation>
    </message>
    <message>
        <source>RSS feeds refresh interval:</source>
        <translation type="obsolete">Aktualisierungsintervall für RSS Feeds:</translation>
    </message>
    <message>
        <source>minutes</source>
        <translation type="obsolete">Minuten</translation>
    </message>
    <message>
        <source>Maximum number of articles per feed:</source>
        <translation type="obsolete">Maximale Anzahl Artikel pro Feed:</translation>
    </message>
</context>
<context>
    <name>RssSettingsDlg</name>
    <message>
        <location filename="../rss/rsssettingsdlg.ui" line="14"/>
        <source>RSS Reader Settings</source>
        <translation>Einstellungen für RSS Reader</translation>
    </message>
    <message>
        <location filename="../rss/rsssettingsdlg.ui" line="47"/>
        <source>RSS feeds refresh interval:</source>
        <translation>Aktualisierungsintervall für RSS Feeds:</translation>
    </message>
    <message>
        <location filename="../rss/rsssettingsdlg.ui" line="70"/>
        <source>minutes</source>
        <translation>Minuten</translation>
    </message>
    <message>
        <location filename="../rss/rsssettingsdlg.ui" line="77"/>
        <source>Maximum number of articles per feed:</source>
        <translation>Maximale Anzahl der Artikel pro Feed:</translation>
    </message>
</context>
<context>
    <name>RssStream</name>
    <message>
        <source>Automatically downloading %1 torrent from %2 RSS feed...</source>
        <translation type="obsolete">Automatisches laden des Torrent %1 von RSS-Feed %2...</translation>
    </message>
</context>
<context>
    <name>ScanFoldersModel</name>
    <message>
        <location filename="../scannedfoldersmodel.cpp" line="103"/>
        <source>Watched Folder</source>
        <translation>Beobachtetes Verzeichnis</translation>
    </message>
    <message>
        <location filename="../scannedfoldersmodel.cpp" line="104"/>
        <source>Download here</source>
        <translation>Hier herunterladen</translation>
    </message>
</context>
<context>
    <name>SearchCategories</name>
    <message>
        <location filename="../searchengine/supportedengines.h" line="51"/>
        <source>All categories</source>
        <translation>Alle Kategorien</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="52"/>
        <source>Movies</source>
        <translation>Filme</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="53"/>
        <source>TV shows</source>
        <translation>Fernsehsendungen</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="54"/>
        <source>Music</source>
        <translation>Musik</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="55"/>
        <source>Games</source>
        <translation>Spiele</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="56"/>
        <source>Anime</source>
        <translation>Anime</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="57"/>
        <source>Software</source>
        <translation>Software</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="58"/>
        <source>Pictures</source>
        <translation>Bilder</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="59"/>
        <source>Books</source>
        <translation>Bücher</translation>
    </message>
</context>
<context>
    <name>SearchEngine</name>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="332"/>
        <source>Empty search pattern</source>
        <translation>Leere Suchanfrage</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="332"/>
        <source>Please type a search pattern first</source>
        <translation>Bitte geben Sie zuerst eine Suchanfrage ein</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="370"/>
        <location filename="../searchengine/searchengine.cpp" line="466"/>
        <source>Results</source>
        <translation>Ergebnisse</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="445"/>
        <source>Searching...</source>
        <translation>Suche...</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="213"/>
        <source>Cut</source>
        <translation>Ausschneiden</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="214"/>
        <source>Copy</source>
        <translation>Kopieren</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="215"/>
        <source>Paste</source>
        <translation>Einfügen</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="216"/>
        <source>Clear field</source>
        <translation>Feld leeren</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="217"/>
        <source>Clear completion history</source>
        <translation>Vervollständigungshistorie löschen</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="236"/>
        <source>Confirmation</source>
        <translation>Bestätigen</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="236"/>
        <source>Are you sure you want to clear the history?</source>
        <translation>Möchten Sie die Historie wirklich leeren?</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="290"/>
        <location filename="../searchengine/searchengine.cpp" line="320"/>
        <location filename="../searchengine/searchengine.cpp" line="321"/>
        <source>Search</source>
        <translation>Suche</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="301"/>
        <source>Missing Python Interpreter</source>
        <translation>Fehlender Python Interpreter</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="302"/>
        <source>Python 2.x is required to use the search engine but it does not seem to be installed.
Do you want to install it now?</source>
        <translation>Python 2.x wird benötigt um die Suchmaschine zu benutzen aber es scheint nicht installiert zu sein. Möchten Sie es jetzt installieren?</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="585"/>
        <source>Search Engine</source>
        <translation>Suchmaschine</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="585"/>
        <location filename="../searchengine/searchengine.cpp" line="600"/>
        <source>Search has finished</source>
        <translation>Suche abgeschlossen</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="591"/>
        <source>An error occured during search...</source>
        <translation>Während der Suche ist ein Fehler aufgetreten ...</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="589"/>
        <location filename="../searchengine/searchengine.cpp" line="595"/>
        <source>Search aborted</source>
        <translation>Suche abgebrochen</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="178"/>
        <source>Download error</source>
        <translation>Downloadfehler</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="178"/>
        <source>Python setup could not be downloaded, reason: %1.
Please install it manually.</source>
        <translation>Python Einrichtung konnte nicht heruntergeladen werden, Begründung: %1. Bitte installieren Sie manuell.</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="598"/>
        <source>Search returned no results</source>
        <translation>Suche lieferte keine Ergebnisse</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="605"/>
        <source>Results</source>
        <comment>i.e: Search results</comment>
        <translation>Ergebnisse</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="641"/>
        <location filename="../searchengine/searchengine.cpp" line="647"/>
        <source>Unknown</source>
        <translation>Unbekannt</translation>
    </message>
</context>
<context>
    <name>SearchTab</name>
    <message>
        <location filename="../searchengine/searchtab.cpp" line="55"/>
        <source>Name</source>
        <comment>i.e: file name</comment>
        <translation>Dateiname</translation>
    </message>
    <message>
        <location filename="../searchengine/searchtab.cpp" line="56"/>
        <source>Size</source>
        <comment>i.e: file size</comment>
        <translation>Dateigrösse</translation>
    </message>
    <message>
        <location filename="../searchengine/searchtab.cpp" line="57"/>
        <source>Seeders</source>
        <comment>i.e: Number of full sources</comment>
        <translation>Seeder</translation>
    </message>
    <message>
        <location filename="../searchengine/searchtab.cpp" line="58"/>
        <source>Leechers</source>
        <comment>i.e: Number of partial sources</comment>
        <translation>Leecher</translation>
    </message>
    <message>
        <location filename="../searchengine/searchtab.cpp" line="59"/>
        <source>Search engine</source>
        <translation>Suchmaschine</translation>
    </message>
</context>
<context>
    <name>ShutdownConfirmDlg</name>
    <message>
        <location filename="../qtlibtorrent/shutdownconfirm.h" line="44"/>
        <source>Shutdown confirmation</source>
        <translation>Herunterfahren bestätigen</translation>
    </message>
</context>
<context>
    <name>SpeedLimitDialog</name>
    <message>
        <location filename="../speedlimitdlg.h" line="84"/>
        <source>KiB/s</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>StatusBar</name>
    <message>
        <location filename="../statusbar.h" line="67"/>
        <location filename="../statusbar.h" line="180"/>
        <source>Connection status:</source>
        <translation>Verbindungs-Status:</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="67"/>
        <location filename="../statusbar.h" line="180"/>
        <source>No direct connections. This may indicate network configuration problems.</source>
        <translation>Keine direkten Verbindungen. Möglicherweise gibt es Probleme mit Ihrer Netzwerkkonfiguration.</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="95"/>
        <location filename="../statusbar.h" line="187"/>
        <source>DHT: %1 nodes</source>
        <translation>DHT: %1 Nodes</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="150"/>
        <source>qBittorrent needs to be restarted</source>
        <translation>qBittorrent benötigt Neustart</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="160"/>
        <source>qBittorrent was just updated and needs to be restarted for the changes to be effective.</source>
        <translation>qBittorrent wurde soeben aktualisiert. Änderungen werden erst nach einem Neustart effektiv.</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="172"/>
        <location filename="../statusbar.h" line="177"/>
        <source>Connection Status:</source>
        <translation>Verbindungs-Status:</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="172"/>
        <source>Offline. This usually means that qBittorrent failed to listen on the selected port for incoming connections.</source>
        <translation>Offline. In den meisten Fällen bedeutet das, dass qBittorrent nicht auf dem angegebenen Port für eingehende Verbindungen lauschen kann.</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="177"/>
        <source>Online</source>
        <translation>Online</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="193"/>
        <location filename="../statusbar.h" line="194"/>
        <source>%1/s</source>
        <comment>Per second</comment>
        <translation>%1/s</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="204"/>
        <source>Click to switch to alternative speed limits</source>
        <translation>Klicken um zu den alternative Geschwindigkeitsbegrenzungen zu wechseln</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="200"/>
        <source>Click to switch to regular speed limits</source>
        <translation>Klick um zu den regulären Geschwindigkeitsbegrenzungen zu wechseln</translation>
    </message>
    <message>
        <source>Click to disable alternative speed limits</source>
        <translation type="obsolete">Klicken um alternative Geschwindigkeitsbegrenzungen zu deaktivieren</translation>
    </message>
    <message>
        <source>Click to enable alternative speed limits</source>
        <translation type="obsolete">Klicken um alternative Geschwindigkeitsbegrenzungen zu aktivieren</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="220"/>
        <source>Global Download Speed Limit</source>
        <translation>Begrenzung der globalen DL-Rate</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="245"/>
        <source>Global Upload Speed Limit</source>
        <translation>Begrenzung der globalen UL-Rate</translation>
    </message>
</context>
<context>
    <name>TorrentCreatorDlg</name>
    <message>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="73"/>
        <source>Select a folder to add to the torrent</source>
        <translation>Wählen Sie einen Ordner um ihn dem Torrent hinzuzufügen</translation>
    </message>
    <message>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="89"/>
        <source>Select a file to add to the torrent</source>
        <translation>Wählen Sie einen Datei um sie dem Torrent hinzuzufügen</translation>
    </message>
    <message>
        <source>Please type an announce URL</source>
        <translation type="obsolete">Bitte Announce URL eingeben</translation>
    </message>
    <message>
        <source>Announce URL:</source>
        <comment>Tracker URL</comment>
        <translation type="obsolete">Announce URL:</translation>
    </message>
    <message>
        <source>Please type a web seed url</source>
        <translation type="obsolete">Bitte Web Seed URL eingeben</translation>
    </message>
    <message>
        <source>Web seed URL:</source>
        <translation type="obsolete">Web Seed URL:</translation>
    </message>
    <message>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="112"/>
        <source>No input path set</source>
        <translation>Kein Eingabepfad gesetzt</translation>
    </message>
    <message>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="112"/>
        <source>Please type an input path first</source>
        <translation>Bitte geben Sie zuerst einen Eingabepfad an</translation>
    </message>
    <message>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="122"/>
        <source>Select destination torrent file</source>
        <translation>Torrent Datei als Ziel auswählen</translation>
    </message>
    <message>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="122"/>
        <source>Torrent Files</source>
        <translation>Torrent Dateien</translation>
    </message>
    <message>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="149"/>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="165"/>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="180"/>
        <source>Torrent creation</source>
        <translation>Erstellung des Torrent</translation>
    </message>
    <message>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="149"/>
        <source>Torrent creation was unsuccessful, reason: %1</source>
        <translation>Erstellung des Torrent war nicht erfolgreich. Begründung: %1</translation>
    </message>
    <message>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="165"/>
        <source>Created torrent file is invalid. It won&apos;t be added to download list.</source>
        <translation>Die erstellte Torrentdatei ist ungültig. Sie wird nicht der Donwloadliste hinzugefügt.</translation>
    </message>
    <message>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="180"/>
        <source>Torrent was created successfully:</source>
        <translation>Torrent erfolgreich erstellt:</translation>
    </message>
</context>
<context>
    <name>TorrentFilesModel</name>
    <message>
        <location filename="../torrentfilesmodel.h" line="343"/>
        <source>Name</source>
        <translation>Name</translation>
    </message>
    <message>
        <location filename="../torrentfilesmodel.h" line="343"/>
        <source>Size</source>
        <translation>Größe</translation>
    </message>
    <message>
        <location filename="../torrentfilesmodel.h" line="343"/>
        <source>Progress</source>
        <translation>Fortschritt</translation>
    </message>
    <message>
        <location filename="../torrentfilesmodel.h" line="343"/>
        <source>Priority</source>
        <translation>Priorität</translation>
    </message>
</context>
<context>
    <name>TorrentImportDlg</name>
    <message>
        <location filename="../torrentimportdlg.ui" line="14"/>
        <source>Torrent Import</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.ui" line="38"/>
        <source>This assistant will help you share with qBittorrent a torrent that you have already downloaded.</source>
        <translation>Dieser Assistent wird Ihnen helfen einen Torrent, den Sie bereits heruntergeladen haben über qBittorrent zu verteilen.</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.ui" line="50"/>
        <source>Torrent file to import:</source>
        <translation>Zu importierende Torrent Datei:</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.ui" line="66"/>
        <location filename="../torrentimportdlg.ui" line="94"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.ui" line="75"/>
        <source>Content location:</source>
        <translation>Speicherstelle des Inhalts:</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.ui" line="106"/>
        <source>Skip the data checking stage and start seeding immediately</source>
        <translation>Uberprüfung der Daten überspringen und sofort mit dem seeden beginnen</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.ui" line="116"/>
        <source>Import</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.cpp" line="70"/>
        <source>Torrent file to import</source>
        <translation>Zu importierende Torrent Datei</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.cpp" line="70"/>
        <source>Torrent files (*.torrent)</source>
        <translation>Torrent Dateien (*.torrent)</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.cpp" line="95"/>
        <source>%1 Files</source>
        <comment>%1 is a file extension (e.g. PDF)</comment>
        <translation>%1-Dateien</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.cpp" line="97"/>
        <source>Please provide the location of %1</source>
        <comment>%1 is a file name</comment>
        <translation>Bitte geben Sie die Speicherstelle von %1 an</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.cpp" line="134"/>
        <source>Please point to the location of the torrent: %1</source>
        <translation>Bitte geben Sie die Speicherstelle des Torrent an: %1</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.cpp" line="242"/>
        <source>Invalid torrent file</source>
        <translation type="unfinished">Ungültige Torrent Datei</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.cpp" line="242"/>
        <source>This is not a valid torrent file.</source>
        <translation type="unfinished">Dies ist keine gültige Torrrent Datei.</translation>
    </message>
</context>
<context>
    <name>TorrentModel</name>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="239"/>
        <source>Name</source>
        <comment>i.e: torrent name</comment>
        <translation></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="241"/>
        <source>Size</source>
        <comment>i.e: torrent size</comment>
        <translation>Größe</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="242"/>
        <source>Done</source>
        <comment>% Done</comment>
        <translation>Fertig</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="243"/>
        <source>Status</source>
        <comment>Torrent status (e.g. downloading, seeding, paused)</comment>
        <translation>Status</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="244"/>
        <source>Seeds</source>
        <comment>i.e. full sources (often untranslated)</comment>
        <translation></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="245"/>
        <source>Peers</source>
        <comment>i.e. partial sources (often untranslated)</comment>
        <translation></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="246"/>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Downloadgeschwindigkeit</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="247"/>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Uploadgeschwindigkeit</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="248"/>
        <source>Ratio</source>
        <comment>Share ratio</comment>
        <translation>Verhältnis</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="249"/>
        <source>ETA</source>
        <comment>i.e: Estimated Time of Arrival / Time left</comment>
        <translation>voraussichtliche Dauer</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="250"/>
        <source>Label</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="251"/>
        <source>Added On</source>
        <comment>Torrent was added to transfer list on 01/01/2010 08:00</comment>
        <translation>Hinzugefügt am</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="252"/>
        <source>Completed On</source>
        <comment>Torrent was completed on 01/01/2010 08:00</comment>
        <translation>Abgeschlossen am</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="253"/>
        <source>Tracker</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="254"/>
        <source>Down Limit</source>
        <comment>i.e: Download limit</comment>
        <translation>Downloadbegrenzung</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="255"/>
        <source>Up Limit</source>
        <comment>i.e: Upload limit</comment>
        <translation>Uploadbegrenzung</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="256"/>
        <source>Amount downloaded</source>
        <comment>Amount of data downloaded (e.g. in MB)</comment>
        <translation>Heruntergeladen</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="257"/>
        <source>Amount left</source>
        <comment>Amount of data left to download (e.g. in MB)</comment>
        <translation>Verbleibend</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="258"/>
        <source>Time Active</source>
        <comment>Time (duration) the torrent is active (not paused)</comment>
        <translation>Aktiv seit</translation>
    </message>
</context>
<context>
    <name>TrackerList</name>
    <message>
        <location filename="../properties/trackerlist.cpp" line="61"/>
        <source>URL</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="62"/>
        <source>Status</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="63"/>
        <source>Peers</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="64"/>
        <source>Message</source>
        <translation>Meldung</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="66"/>
        <source>[DHT]</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="69"/>
        <source>[PeX]</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="72"/>
        <source>[LSD]</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="209"/>
        <location filename="../properties/trackerlist.cpp" line="219"/>
        <location filename="../properties/trackerlist.cpp" line="225"/>
        <location filename="../properties/trackerlist.cpp" line="256"/>
        <location filename="../properties/trackerlist.cpp" line="274"/>
        <source>Working</source>
        <translation>Funktioniert</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="211"/>
        <location filename="../properties/trackerlist.cpp" line="221"/>
        <location filename="../properties/trackerlist.cpp" line="227"/>
        <source>Disabled</source>
        <translation>Deaktiviert</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="215"/>
        <source>This torrent is private</source>
        <translation>Dieser Torrent ist privat</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="260"/>
        <source>Updating...</source>
        <translation>Aktualisiere...</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="264"/>
        <location filename="../properties/trackerlist.cpp" line="278"/>
        <source>Not working</source>
        <translation>Funktioniert nicht</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="267"/>
        <location filename="../properties/trackerlist.cpp" line="281"/>
        <source>Not contacted yet</source>
        <translation>Noch nicht kontakiert</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="349"/>
        <source>Add a new tracker...</source>
        <translation>Neuen Tracker hinzufügen...</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="352"/>
        <source>Remove tracker</source>
        <translation>Tracker entfernen</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="355"/>
        <source>Force reannounce</source>
        <translation>Bekanntgebung forcieren</translation>
    </message>
</context>
<context>
    <name>TrackersAdditionDlg</name>
    <message>
        <location filename="../properties/trackersadditiondlg.ui" line="14"/>
        <source>Trackers addition dialog</source>
        <translation>Dialog zum Hinzufügen eines Trackers</translation>
    </message>
    <message>
        <location filename="../properties/trackersadditiondlg.ui" line="20"/>
        <source>List of trackers to add (one per line):</source>
        <translation>Liste der hinzuzufügenden Tracker (einer pro Zeile):</translation>
    </message>
    <message utf8="true">
        <location filename="../properties/trackersadditiondlg.ui" line="44"/>
        <source>µTorrent compatible list URL:</source>
        <translation>µTorrent kompatible Listen URL:</translation>
    </message>
    <message>
        <location filename="../properties/trackersadditiondlg.h" line="81"/>
        <source>I/O Error</source>
        <translation>I/O Fehler</translation>
    </message>
    <message>
        <location filename="../properties/trackersadditiondlg.h" line="81"/>
        <source>Error while trying to open the downloaded file.</source>
        <translation>Beim Versuch die heruntergeladenen datei zu öffnen ist ein Fehler aufgetreten.</translation>
    </message>
    <message>
        <location filename="../properties/trackersadditiondlg.h" line="123"/>
        <source>No change</source>
        <translation>Keine Veränderung</translation>
    </message>
    <message>
        <location filename="../properties/trackersadditiondlg.h" line="123"/>
        <source>No additional trackers were found.</source>
        <translation>Es wurden keine zusätzlichen Tracker gefunden.</translation>
    </message>
    <message>
        <location filename="../properties/trackersadditiondlg.h" line="132"/>
        <source>Download error</source>
        <translation>Downloadfehler</translation>
    </message>
    <message>
        <location filename="../properties/trackersadditiondlg.h" line="132"/>
        <source>The trackers list could not be downloaded, reason: %1</source>
        <translation>Die Trackerliste konnte nicht geladen werden. Begründung: %1</translation>
    </message>
</context>
<context>
    <name>TransferListDelegate</name>
    <message>
        <location filename="../transferlistdelegate.h" line="94"/>
        <source>Downloading</source>
        <translation>Lade</translation>
    </message>
    <message>
        <location filename="../transferlistdelegate.h" line="98"/>
        <source>Paused</source>
        <translation>Angehalten</translation>
    </message>
    <message>
        <location filename="../transferlistdelegate.h" line="102"/>
        <source>Queued</source>
        <comment>i.e. torrent is queued</comment>
        <translation>Eingereiht</translation>
    </message>
    <message>
        <location filename="../transferlistdelegate.h" line="106"/>
        <source>Seeding</source>
        <comment>Torrent is complete and in upload-only mode</comment>
        <translation>Seede</translation>
    </message>
    <message>
        <location filename="../transferlistdelegate.h" line="109"/>
        <source>Stalled</source>
        <comment>Torrent is waiting for download to begin</comment>
        <translation>Angehalten</translation>
    </message>
    <message>
        <location filename="../transferlistdelegate.h" line="113"/>
        <source>Checking</source>
        <comment>Torrent local data is being checked</comment>
        <translation>Überprüfe</translation>
    </message>
    <message>
        <location filename="../transferlistdelegate.h" line="127"/>
        <source>/s</source>
        <comment>/second (.i.e per second)</comment>
        <translation></translation>
    </message>
    <message>
        <location filename="../transferlistdelegate.h" line="136"/>
        <source>KiB/s</source>
        <comment>KiB/second (.i.e per second)</comment>
        <translation></translation>
    </message>
    <message>
        <location filename="../transferlistdelegate.h" line="146"/>
        <source>Seeded for %1</source>
        <comment>e.g. Seeded for 3m10s</comment>
        <translation>Geseeded seit %1</translation>
    </message>
</context>
<context>
    <name>TransferListFiltersWidget</name>
    <message>
        <location filename="../transferlistfilterswidget.h" line="205"/>
        <location filename="../transferlistfilterswidget.h" line="287"/>
        <source>All</source>
        <translation>Alle</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="208"/>
        <location filename="../transferlistfilterswidget.h" line="288"/>
        <source>Downloading</source>
        <translation>Lade</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="211"/>
        <location filename="../transferlistfilterswidget.h" line="289"/>
        <source>Completed</source>
        <translation>Vollständig</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="214"/>
        <location filename="../transferlistfilterswidget.h" line="290"/>
        <source>Paused</source>
        <translation>Angehalten</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="217"/>
        <location filename="../transferlistfilterswidget.h" line="291"/>
        <source>Active</source>
        <translation>Aktiv</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="220"/>
        <location filename="../transferlistfilterswidget.h" line="292"/>
        <source>Inactive</source>
        <translation>Inaktiv</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="234"/>
        <location filename="../transferlistfilterswidget.h" line="469"/>
        <source>All labels</source>
        <translation>Alle Label</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="237"/>
        <location filename="../transferlistfilterswidget.h" line="470"/>
        <source>Unlabeled</source>
        <translation>Ohne Label</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="319"/>
        <source>Remove label</source>
        <translation>Label entfernen</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="320"/>
        <source>Add label...</source>
        <translation>Label hinzufügen...</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="322"/>
        <source>Resume torrents</source>
        <translation>Torrent fortsetzen</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="323"/>
        <source>Pause torrents</source>
        <translation>Torrent anhalten</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="324"/>
        <source>Delete torrents</source>
        <translation>Torrent löschen</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="350"/>
        <source>New Label</source>
        <translation>Neues Label</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="350"/>
        <source>Label:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="355"/>
        <source>Invalid label name</source>
        <translation>Ungültiger Labelname</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="355"/>
        <source>Please don&apos;t use any special characters in the label name.</source>
        <translation>Bitte keine Sonderzeichen im Labelname verwenden.</translation>
    </message>
</context>
<context>
    <name>TransferListWidget</name>
    <message>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation type="obsolete">DL-Rate</translation>
    </message>
    <message>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation type="obsolete">UL-Rate</translation>
    </message>
    <message>
        <source>ETA</source>
        <comment>i.e: Estimated Time of Arrival / Time left</comment>
        <translation type="obsolete">voraussichtliche Dauer</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="524"/>
        <source>Column visibility</source>
        <translation>Sichtbarkeit der Spalten</translation>
    </message>
    <message>
        <source>Name</source>
        <comment>i.e: torrent name</comment>
        <translation type="obsolete">Name</translation>
    </message>
    <message>
        <source>Size</source>
        <comment>i.e: torrent size</comment>
        <translation type="obsolete">Größe</translation>
    </message>
    <message>
        <source>Done</source>
        <comment>% Done</comment>
        <translation type="obsolete">Fertig</translation>
    </message>
    <message>
        <source>Status</source>
        <comment>Torrent status (e.g. downloading, seeding, paused)</comment>
        <translation type="obsolete">Status</translation>
    </message>
    <message>
        <source>Ratio</source>
        <comment>Share ratio</comment>
        <translation type="obsolete">Verhältnis</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="766"/>
        <source>Label</source>
        <translation></translation>
    </message>
    <message>
        <source>Added On</source>
        <comment>Torrent was added to transfer list on 01/01/2010 08:00</comment>
        <translation type="obsolete">Hinzugefügt am</translation>
    </message>
    <message>
        <source>Completed On</source>
        <comment>Torrent was completed on 01/01/2010 08:00</comment>
        <translation type="obsolete">Vervollständigt am</translation>
    </message>
    <message>
        <source>Down Limit</source>
        <comment>i.e: Download limit</comment>
        <translation type="obsolete">Download Begrenzung</translation>
    </message>
    <message>
        <source>Up Limit</source>
        <comment>i.e: Upload limit</comment>
        <translation type="obsolete">Upload Begrenzung</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="227"/>
        <source>Choose save path</source>
        <translation>Speicherort auswählen</translation>
    </message>
    <message>
        <source>Save path creation error</source>
        <translation type="obsolete">Fehler beim erstellen des Speicherortes</translation>
    </message>
    <message>
        <source>Could not create the save path</source>
        <translation type="obsolete">Speicherort konnte nicht erstellt werden</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="449"/>
        <source>Torrent Download Speed Limiting</source>
        <translation>Begrenzung der Torrent-DL-Rate</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="482"/>
        <source>Torrent Upload Speed Limiting</source>
        <translation>Begrenzung der Torrent-UL-Rate</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="589"/>
        <source>New Label</source>
        <translation>Neues Label</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="589"/>
        <source>Label:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="594"/>
        <source>Invalid label name</source>
        <translation>Ungültiger Labelname</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="594"/>
        <source>Please don&apos;t use any special characters in the label name.</source>
        <translation>Bitte keine Sonderzeichen im Labelname verwenden.</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="610"/>
        <source>Rename</source>
        <translation>Umbenennen</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="610"/>
        <source>New name:</source>
        <translation>Neuer Name:</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="644"/>
        <source>Resume</source>
        <comment>Resume/start the torrent</comment>
        <translation>Fortsetzen</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="646"/>
        <source>Pause</source>
        <comment>Pause the torrent</comment>
        <translation>Anhalten</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="648"/>
        <source>Delete</source>
        <comment>Delete the torrent</comment>
        <translation>Löschen</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="650"/>
        <source>Preview file...</source>
        <translation>Datei vorschauen...</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="652"/>
        <source>Limit share ratio...</source>
        <translation>Shareverhältnis begrenzen...</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="654"/>
        <source>Limit upload rate...</source>
        <translation>Uploadrate begrenzen...</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="656"/>
        <source>Limit download rate...</source>
        <translation>Downlaodrate begrenzen...</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="811"/>
        <source>Priority</source>
        <translation>Priorität</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="658"/>
        <source>Open destination folder</source>
        <translation>Zielverzeichniss öffnen</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="660"/>
        <source>Move up</source>
        <comment>i.e. move up in the queue</comment>
        <translation>Nach oben bewegen</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="662"/>
        <source>Move down</source>
        <comment>i.e. Move down in the queue</comment>
        <translation>Nach unten bewegen</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="664"/>
        <source>Move to top</source>
        <comment>i.e. Move to top of the queue</comment>
        <translation>An den Anfang</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="666"/>
        <source>Move to bottom</source>
        <comment>i.e. Move to bottom of the queue</comment>
        <translation>An das Ende</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="668"/>
        <source>Set location...</source>
        <translation>Ort setzen...</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="670"/>
        <source>Force recheck</source>
        <translation>Erzwinge erneute Überprüfung</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="672"/>
        <source>Copy magnet link</source>
        <translation>Kopiere Magnet-Link</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="675"/>
        <source>Super seeding mode</source>
        <translation>Super-Seeding-Modus</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="679"/>
        <source>Rename...</source>
        <translation>Umbenennen...</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="681"/>
        <source>Download in sequential order</source>
        <translation>Der Reihe nach downloaden</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="684"/>
        <source>Download first and last piece first</source>
        <translation>Erste und letzte Teile zuerst laden</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="767"/>
        <source>New...</source>
        <comment>New label...</comment>
        <translation>Neu...</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="768"/>
        <source>Reset</source>
        <comment>Reset label</comment>
        <translation>Zurücksetzen</translation>
    </message>
</context>
<context>
    <name>UpDownRatioDlg</name>
    <message>
        <location filename="../updownratiodlg.ui" line="14"/>
        <source>Torrent Upload/Download Ratio Limiting</source>
        <translation>Begrenzung des Torrent Upload/Download Verhältnisses</translation>
    </message>
    <message>
        <location filename="../updownratiodlg.ui" line="20"/>
        <source>Use global ratio limit</source>
        <translation>Globale Begrenzung für das Verhältnis verwenden</translation>
    </message>
    <message>
        <location filename="../updownratiodlg.ui" line="23"/>
        <location filename="../updownratiodlg.ui" line="33"/>
        <location filename="../updownratiodlg.ui" line="45"/>
        <source>buttonGroup</source>
        <translation>Schaltegruppe</translation>
    </message>
    <message>
        <location filename="../updownratiodlg.ui" line="30"/>
        <source>Set no ratio limit</source>
        <translation>Keine Begrenzung für das Verhältnis verwenden</translation>
    </message>
    <message>
        <location filename="../updownratiodlg.ui" line="42"/>
        <source>Set ratio limit to</source>
        <translation>Begrenzung für das Verhältnis setzen</translation>
    </message>
</context>
<context>
    <name>UsageDisplay</name>
    <message>
        <location filename="../main.cpp" line="73"/>
        <source>Usage:</source>
        <translation>Verwendung:</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="74"/>
        <source>displays program version</source>
        <translation>zeigt die Programmversion</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="76"/>
        <source>disable splash screen</source>
        <translation>deaktiviere Splash Screen</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="78"/>
        <source>displays this help message</source>
        <translation>zeigt diese Hilfsausgabe</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="79"/>
        <source>changes the webui port (current: %1)</source>
        <translation>verändert den Webinterface Port (momentan: %1)</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="80"/>
        <source>[files or urls]: downloads the torrents passed by the user (optional)</source>
        <translation>[Dateien oder URLs]: lädt vom Benutzer übergebene Torrents (optional)</translation>
    </message>
</context>
<context>
    <name>about</name>
    <message>
        <location filename="../about_imp.h" line="51"/>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <location filename="../about_imp.h" line="61"/>
        <source>I would like to thank the following people who volunteered to translate qBittorrent:</source>
        <translation>Ich möchte folgenden freiwilligen Übersetzern danken:</translation>
    </message>
    <message>
        <location filename="../about_imp.h" line="93"/>
        <source>Please contact me if you would like to translate qBittorrent into your own language.</source>
        <translation>Bitte kontaktieren Sie mich, falls Sie qBittorrent in Ihre Sprache übersetzen wollen.</translation>
    </message>
</context>
<context>
    <name>addPeerDialog</name>
    <message>
        <location filename="../properties/peer.ui" line="20"/>
        <source>Peer addition</source>
        <translation>Hinzufügen eines Peers</translation>
    </message>
    <message>
        <location filename="../properties/peer.ui" line="36"/>
        <source>IP</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../properties/peer.ui" line="59"/>
        <source>Port</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>addTorrentDialog</name>
    <message>
        <location filename="../torrentadditiondlg.ui" line="14"/>
        <source>Torrent addition dialog</source>
        <translation>Dialog zum Hinzufügen eines Torrent</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="42"/>
        <source>Save path:</source>
        <translation>Speicher-Pfad:</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="62"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="73"/>
        <source>Torrent size:</source>
        <translation>Torrent-Größe:</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="80"/>
        <location filename="../torrentadditiondlg.ui" line="101"/>
        <source>Unknown</source>
        <translation>Unbekannt</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="94"/>
        <source>Free disk space:</source>
        <translation>Freier Festplattenspeicher:</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="132"/>
        <source>Label:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="184"/>
        <source>Torrent content:</source>
        <translation>Torrent Inhalt:</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="237"/>
        <source>Select All</source>
        <translation>Alle Auswählen</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="244"/>
        <source>Select None</source>
        <translation>Keine Auswählen</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="266"/>
        <source>Download in sequential order (slower but good for previewing)</source>
        <translation>Der Reihe nach laden (langsamer, aber besser zum Vorschauen)</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="273"/>
        <source>Skip file checking and start seeding immediately</source>
        <translation>Überspringe das Überprüfen der Datei und direkt mit dem Seeden beginnen</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="352"/>
        <location filename="../torrentadditiondlg.ui" line="355"/>
        <source>Do not download</source>
        <translation>Nicht herunterladen</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="280"/>
        <source>Add to download list in paused state</source>
        <translation>Der Download Liste im Pause-Modus hinzufügen</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="308"/>
        <source>Add</source>
        <translation>Hinzufügen</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="315"/>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="337"/>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="342"/>
        <source>High</source>
        <translation>Hoch</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="347"/>
        <source>Maximum</source>
        <translation>Maximum</translation>
    </message>
</context>
<context>
    <name>authentication</name>
    <message>
        <location filename="../login.ui" line="16"/>
        <location filename="../login.ui" line="66"/>
        <source>Tracker authentication</source>
        <translation>Tracker Authentifizierung</translation>
    </message>
    <message>
        <location filename="../login.ui" line="94"/>
        <source>Tracker:</source>
        <translation>Tracker:</translation>
    </message>
    <message>
        <location filename="../login.ui" line="127"/>
        <source>Login</source>
        <translation>Login</translation>
    </message>
    <message>
        <location filename="../login.ui" line="147"/>
        <source>Username:</source>
        <translation>Benutzername:</translation>
    </message>
    <message>
        <location filename="../login.ui" line="176"/>
        <source>Password:</source>
        <translation>Kennwort:</translation>
    </message>
    <message>
        <location filename="../login.ui" line="219"/>
        <source>Log in</source>
        <translation>Einloggen</translation>
    </message>
    <message>
        <location filename="../login.ui" line="226"/>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
</context>
<context>
    <name>confirmDeletionDlg</name>
    <message>
        <location filename="../confirmdeletiondlg.ui" line="20"/>
        <source>Deletion confirmation - qBittorrent</source>
        <translation>Löschen bestätigen - qBittorrent</translation>
    </message>
    <message>
        <location filename="../confirmdeletiondlg.ui" line="47"/>
        <source>Are you sure you want to delete the selected torrents from the transfer list?</source>
        <translation>Sind Sie sicher, daß Sie die ausgewählten Torrents von der Transfer-Liste entfernen möchten?</translation>
    </message>
    <message>
        <location filename="../confirmdeletiondlg.ui" line="67"/>
        <source>Remember choice</source>
        <translation>Entscheidung merken</translation>
    </message>
    <message>
        <location filename="../confirmdeletiondlg.ui" line="94"/>
        <source>Also delete the files on the hard disk</source>
        <translation>Datei auch von der Festplatte löschen</translation>
    </message>
</context>
<context>
    <name>createTorrentDialog</name>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="291"/>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="14"/>
        <source>Torrent Creation Tool</source>
        <translation>Torrenterstellungs Werkzeug</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="43"/>
        <source>Torrent file creation</source>
        <translation>Torrent-Datei Erstellung</translation>
    </message>
    <message>
        <source>Announce urls (trackers):</source>
        <translation type="obsolete">Announce URLs (Tracker):</translation>
    </message>
    <message>
        <source>Comment (optional):</source>
        <translation type="obsolete">Kommentar (optional):</translation>
    </message>
    <message>
        <source>Web seeds urls (optional):</source>
        <translation type="obsolete">Web Seeds URLs (optional):</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="53"/>
        <source>File or folder to add to the torrent:</source>
        <translation>Datei oder Ordner die dem Torrent hinzugefügt werden:</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="65"/>
        <source>Add file</source>
        <translation>Datei hinzufügen</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="72"/>
        <source>Add folder</source>
        <translation>Verzeichnis hinzufügen</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="83"/>
        <source>Tracker URLs:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="93"/>
        <source>Web seeds urls:</source>
        <translation>Web Seeds URLs:</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="103"/>
        <source>Comment:</source>
        <translation>Kommentar:</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="150"/>
        <source>Piece size:</source>
        <translation>Größe der Stücke:</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="167"/>
        <source>32 KiB</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="172"/>
        <source>64 KiB</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="177"/>
        <source>128 KiB</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="182"/>
        <source>256 KiB</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="187"/>
        <source>512 KiB</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="192"/>
        <source>1 MiB</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="197"/>
        <source>2 MiB</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="202"/>
        <source>4 MiB</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="210"/>
        <source>Auto</source>
        <translation>Automatisch</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="235"/>
        <source>Private (won&apos;t be distributed on DHT network if enabled)</source>
        <translation>Privat (wird nicht an das DHT Netzwerk verteilt)</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="242"/>
        <source>Start seeding after creation</source>
        <translation>Beginne Seeding nach Erstellung</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="284"/>
        <source>Create and save...</source>
        <translation>Erstellen und speichern...</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="249"/>
        <source>Progress:</source>
        <translation>Fortschritt:</translation>
    </message>
</context>
<context>
    <name>createtorrent</name>
    <message>
        <source>Select destination torrent file</source>
        <translation type="obsolete">Ziel-Torrent Datei auswählen</translation>
    </message>
    <message>
        <source>Torrent Files</source>
        <translation type="obsolete">Torrent Dateien</translation>
    </message>
    <message>
        <source>No input path set</source>
        <translation type="obsolete">Kein Eingangs-Pfad gesetzt</translation>
    </message>
    <message>
        <source>Please type an input path first</source>
        <translation type="obsolete">Bitte geben Sie zuerst einen Eingangspfad an</translation>
    </message>
    <message>
        <source>Torrent creation</source>
        <translation type="obsolete">Torrent Erstellung</translation>
    </message>
    <message>
        <source>Torrent was created successfully:</source>
        <translation type="obsolete">Torrent erfolgreich erstellt:</translation>
    </message>
    <message>
        <source>Select a folder to add to the torrent</source>
        <translation type="obsolete">Ordner wählen um ihn dem Torrent hinzuzufügen</translation>
    </message>
    <message>
        <source>Please type an announce URL</source>
        <translation type="obsolete">Bitte Announce URL eingeben</translation>
    </message>
    <message>
        <source>Torrent creation was unsuccessful, reason: %1</source>
        <translation type="obsolete">Torrent Erstellung nicht erfolgreich, Grund: %1</translation>
    </message>
    <message>
        <source>Announce URL:</source>
        <comment>Tracker URL</comment>
        <translation type="obsolete">Announce URL:</translation>
    </message>
    <message>
        <source>Please type a web seed url</source>
        <translation type="obsolete">Bitte Web Seed URL eingeben</translation>
    </message>
    <message>
        <source>Web seed URL:</source>
        <translation type="obsolete">Web Seed URL:</translation>
    </message>
    <message>
        <source>Select a file to add to the torrent</source>
        <translation type="obsolete">Datei wählen um sie dem Torrent hinzuzufügen</translation>
    </message>
    <message>
        <source>Created torrent file is invalid. It won&apos;t be added to download list.</source>
        <translation type="obsolete">Die erstellte Torrent-Datei ist ungültig. Sie wird nicht der Donwload-Liste hinzugefügt.</translation>
    </message>
</context>
<context>
    <name>downloadFromURL</name>
    <message>
        <source>Download Torrents from URLs</source>
        <translation type="obsolete">Torrents von URLs laden</translation>
    </message>
    <message>
        <source>Only one URL per line</source>
        <translation type="obsolete">Nur eine URL pro Zeile</translation>
    </message>
    <message>
        <location filename="../downloadfromurldlg.ui" line="45"/>
        <source>Add torrent links</source>
        <translation>Torrent-Links hinzufügen</translation>
    </message>
    <message>
        <location filename="../downloadfromurldlg.ui" line="78"/>
        <source>Both HTTP and Magnet links are supported</source>
        <translation>HTTP und Magnet-Links werden unterstützt</translation>
    </message>
    <message>
        <location filename="../downloadfromurldlg.ui" line="106"/>
        <source>Download</source>
        <translation>Lade</translation>
    </message>
    <message>
        <location filename="../downloadfromurldlg.ui" line="113"/>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <location filename="../downloadfromurldlg.ui" line="14"/>
        <source>Download from urls</source>
        <translation>Von URLs laden</translation>
    </message>
    <message>
        <location filename="../downloadfromurldlg.h" line="78"/>
        <source>No URL entered</source>
        <translation>Keine URL eingegeben</translation>
    </message>
    <message>
        <location filename="../downloadfromurldlg.h" line="78"/>
        <source>Please type at least one URL.</source>
        <translation>Bitte geben Sie mindestens eine URL an.</translation>
    </message>
</context>
<context>
    <name>downloadThread</name>
    <message>
        <source>I/O Error</source>
        <translation type="obsolete">I/O Fehler</translation>
    </message>
    <message>
        <source>The remote host name was not found (invalid hostname)</source>
        <translation type="obsolete">Der entfernte Hostname konnte nicht gefunden werden (ungültiger Hostname)</translation>
    </message>
    <message>
        <source>The operation was canceled</source>
        <translation type="obsolete">Die Operation wurde abgebrochen</translation>
    </message>
    <message>
        <source>The remote server closed the connection prematurely, before the entire reply was received and processed</source>
        <translation type="obsolete">Der entfernte Server hat die Verbindung beendet bevor die gesamte Antwort empfangen und verarbeitet werden konnte</translation>
    </message>
    <message>
        <source>The connection to the remote server timed out</source>
        <translation type="obsolete">Zeitüberschreitung bei der Verbindung mit dem entfernten Server</translation>
    </message>
    <message>
        <source>SSL/TLS handshake failed</source>
        <translation type="obsolete">SSL/TLS Handshake fehlgeschlagen</translation>
    </message>
    <message>
        <source>The remote server refused the connection</source>
        <translation type="obsolete">Der entfernte Server hat die Verbindung verweigert</translation>
    </message>
    <message>
        <source>The connection to the proxy server was refused</source>
        <translation type="obsolete">Die Verbindung zum Proxy-Server wurde verweigert</translation>
    </message>
    <message>
        <source>The proxy server closed the connection prematurely</source>
        <translation type="obsolete">Der Proxy-Server hat die Verbindung vorzeitig beendet</translation>
    </message>
    <message>
        <source>The proxy host name was not found</source>
        <translation type="obsolete">Der Proxy-Hostname wurde nicht gefunden</translation>
    </message>
    <message>
        <source>The connection to the proxy timed out or the proxy did not reply in time to the request sent</source>
        <translation type="obsolete">Zeitüberschreitung beim Verbindungsaufbau mit dem Proxy oder der Proxy hat nicht in angemessener Zeit auf Anfrage reagiert</translation>
    </message>
    <message>
        <source>The proxy requires authentication in order to honour the request but did not accept any credentials offered</source>
        <translation type="obsolete">Der Proxy benötigt Authentifizierung um die Anfrage zu bearbeiten und hat keine der angebotenen Zugangsdaten akzeptiert</translation>
    </message>
    <message>
        <source>The access to the remote content was denied (401)</source>
        <translation type="obsolete">Der Zugriff auf den entfernten Inhalt wurde verweigert (401)</translation>
    </message>
    <message>
        <source>The operation requested on the remote content is not permitted</source>
        <translation type="obsolete">Die angeforderte Operation auf den entfernten Inhalt ist nicht erlaubt</translation>
    </message>
    <message>
        <source>The remote content was not found at the server (404)</source>
        <translation type="obsolete">Der entfernte Inhalte wurde auf dem Server nicht gefunden (404)</translation>
    </message>
    <message>
        <source>The remote server requires authentication to serve the content but the credentials provided were not accepted</source>
        <translation type="obsolete">Der entfernte Server benötigt Authentifizierung um den Inhalt auszuliefern, aber die angebotenen Zugangsdaten wurden nicht akzeptiert</translation>
    </message>
    <message>
        <source>The Network Access API cannot honor the request because the protocol is not known</source>
        <translation type="obsolete">Die Network-Access-API konnte die Anfrage nicht bearbeiten, unbekanntes Protokoll</translation>
    </message>
    <message>
        <source>The requested operation is invalid for this protocol</source>
        <translation type="obsolete">Die angeforderte Operation ist ungütlig für dieses Protokoll</translation>
    </message>
    <message>
        <source>An unknown network-related error was detected</source>
        <translation type="obsolete">Ein unbekannter Netzwerk-Fehler ist aufgetreten</translation>
    </message>
    <message>
        <source>An unknown proxy-related error was detected</source>
        <translation type="obsolete">Ein unbekannter Proxy-Fehler ist aufgetreten</translation>
    </message>
    <message>
        <source>An unknown error related to the remote content was detected</source>
        <translation type="obsolete">Unbekannter Fehler in Verbindung mit dem entfernten Inhalt ist aufgetreten</translation>
    </message>
    <message>
        <source>A breakdown in protocol was detected</source>
        <translation type="obsolete">Eine Störung im Protokoll ist aufgetreten</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation type="obsolete">Unbekannter Fehler</translation>
    </message>
</context>
<context>
    <name>engineSelect</name>
    <message>
        <location filename="../searchengine/engineselect.ui" line="17"/>
        <source>Search plugins</source>
        <translation>Suchplugins</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="30"/>
        <source>Installed search engines:</source>
        <translation>Installierte Suchmaschinen:</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="50"/>
        <source>Name</source>
        <translation>Name</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="55"/>
        <source>Url</source>
        <translation>URL</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="60"/>
        <location filename="../searchengine/engineselect.ui" line="119"/>
        <source>Enabled</source>
        <translation>Aktiviert</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="78"/>
        <source>You can get new search engine plugins here: &lt;a href=&quot;http://plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</source>
        <translation>Sie können neue Suchmaschinen Plugins hier herunterladen: &lt;a href=&quot;http:plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="93"/>
        <source>Install a new one</source>
        <translation>Intalliere ein neue</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="100"/>
        <source>Check for updates</source>
        <translation>Auf Updates prüfen</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="107"/>
        <source>Close</source>
        <translation>Schließen</translation>
    </message>
    <message>
        <source>Enable</source>
        <translation type="obsolete">Aktivieren</translation>
    </message>
    <message>
        <source>Disable</source>
        <translation type="obsolete">Deaktivieren</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="124"/>
        <source>Uninstall</source>
        <translation>Deinstallieren</translation>
    </message>
</context>
<context>
    <name>engineSelectDlg</name>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="174"/>
        <source>Uninstall warning</source>
        <translation>Deinstallations Warnung</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="174"/>
        <source>Some plugins could not be uninstalled because they are included in qBittorrent.
 Only the ones you added yourself can be uninstalled.
However, those plugins were disabled.</source>
        <translation>Einige Plugins konnten nicht deinstalliert werden, da sie ein fester Bestandteil von qBitttorrent sind.
 Nur Plugins, die sie selber installiert haben können wieder entfernt werden.
Die Plugins wurden jedoch deaktiviert.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="176"/>
        <source>Uninstall success</source>
        <translation>Deinstallation erfolgreich</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="340"/>
        <source>Select search plugins</source>
        <translation>Wähle Suchplugin</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="341"/>
        <source>qBittorrent search plugins</source>
        <translation>qBittorrent Suchplugins</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="237"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="262"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="267"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="276"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="279"/>
        <source>Search plugin install</source>
        <translation>Suchplugin installieren</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="117"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="188"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="299"/>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="120"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="154"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="191"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="302"/>
        <source>No</source>
        <translation>Nein</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="237"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="262"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="267"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="276"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="279"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="393"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="426"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="447"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="454"/>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="237"/>
        <source>A more recent version of %1 search engine plugin is already installed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>Eine neuere Version des Suchmaschinen Plugins %1 ist bereits installiert.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="393"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="426"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="447"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="454"/>
        <source>Search plugin update</source>
        <translation>Such-Plugin update</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="426"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="447"/>
        <source>Sorry, update server is temporarily unavailable.</source>
        <translation>Update Server vorübergehend nicht erreichbar.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="393"/>
        <source>All your plugins are already up to date.</source>
        <translation>Alle Plugins sind auf dem neuesten Stand.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="176"/>
        <source>All selected plugins were uninstalled successfully</source>
        <translation>Alle ausgewählten Plugins wurden erfolgreich deinstalliert</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="262"/>
        <source>%1 search engine plugin could not be updated, keeping old version.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>%1 Suchmaschinen Plugin konnte nich aktualisiert werden, behalte alte Version.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="267"/>
        <source>%1 search engine plugin could not be installed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>%1 Suchmaschinen Plugin konnte nicht installiert werden.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="276"/>
        <source>%1 search engine plugin was successfully updated.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>%1 Suchmaschinen Plugin wurder erfolgreich geupdated.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="279"/>
        <source>%1 search engine plugin was successfully installed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>%1 Suchmaschinen Plugin wurde erfolgreich installiert.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="454"/>
        <source>Sorry, %1 search plugin install failed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>Installation des Suchmaschinen Plugins %1 fehlgeschlagen.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="329"/>
        <source>New search engine plugin URL</source>
        <translation>Neue Suchmaschinen Plugin URL</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="330"/>
        <source>URL:</source>
        <translation>URL:</translation>
    </message>
</context>
<context>
    <name>misc</name>
    <message>
        <location filename="../misc.cpp" line="85"/>
        <source>B</source>
        <comment>bytes</comment>
        <translation>B</translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="86"/>
        <source>KiB</source>
        <comment>kibibytes (1024 bytes)</comment>
        <translation>KB</translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="87"/>
        <source>MiB</source>
        <comment>mebibytes (1024 kibibytes)</comment>
        <translation>MB</translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="88"/>
        <source>GiB</source>
        <comment>gibibytes (1024 mibibytes)</comment>
        <translation>GB</translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="89"/>
        <source>TiB</source>
        <comment>tebibytes (1024 gibibytes)</comment>
        <translation>TB</translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="755"/>
        <source>%1h %2m</source>
        <comment>e.g: 3hours 5minutes</comment>
        <translation></translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="760"/>
        <source>%1d %2h</source>
        <comment>e.g: 2days 10hours</comment>
        <translation>%1t %2h</translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="695"/>
        <location filename="../misc.cpp" line="700"/>
        <location filename="../misc.cpp" line="704"/>
        <location filename="../misc.cpp" line="707"/>
        <location filename="../misc.cpp" line="712"/>
        <location filename="../misc.cpp" line="715"/>
        <source>Unknown</source>
        <translation>Unbekannt</translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="583"/>
        <source>Unknown</source>
        <comment>Unknown (size)</comment>
        <translation>Unbekannt</translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="307"/>
        <source>qBittorrent will shutdown the computer now because all downloads are complete.</source>
        <translation>qBittorrent wird den Computer jetzt herunterfahren, da alle Downloads vollständig sind.</translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="746"/>
        <source>&lt; 1m</source>
        <comment>&lt; 1 minute</comment>
        <translation>&lt; 1 Minute</translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="750"/>
        <source>%1m</source>
        <comment>e.g: 10minutes</comment>
        <translation>%1 Min</translation>
    </message>
</context>
<context>
    <name>options_imp</name>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1090"/>
        <location filename="../preferences/options_imp.cpp" line="1092"/>
        <location filename="../preferences/options_imp.cpp" line="1107"/>
        <location filename="../preferences/options_imp.cpp" line="1109"/>
        <source>Choose a save directory</source>
        <translation>Verzeichnis zum Speichern auswählen</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1012"/>
        <source>Add directory to scan</source>
        <translation>Verzeichnis zum Scannen hinzufügen</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1018"/>
        <source>Folder is already being watched.</source>
        <translation>Verzeichnis wird bereits beobachtet.</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1021"/>
        <source>Folder does not exist.</source>
        <translation>Verzeichnis existiert nicht.</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1024"/>
        <source>Folder is not readable.</source>
        <translation>Verzeichnis kann nicht gelesen werden.</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1032"/>
        <source>Failure</source>
        <translation>Fehler</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1032"/>
        <source>Failed to add Scan Folder &apos;%1&apos;: %2</source>
        <translation>Konnte Scan-Verzeichnis &apos;%1&apos; nicht hinzufügen: %2</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1055"/>
        <location filename="../preferences/options_imp.cpp" line="1057"/>
        <source>Choose export directory</source>
        <translation>Export-Verzeichnis wählen</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1072"/>
        <location filename="../preferences/options_imp.cpp" line="1074"/>
        <source>Choose an ip filter file</source>
        <translation>IP-Filter-Datei wählen</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1072"/>
        <location filename="../preferences/options_imp.cpp" line="1074"/>
        <source>Filters</source>
        <translation>Filter</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1152"/>
        <source>SSL Certificate (*.crt *.pem)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1163"/>
        <source>SSL Key (*.key *.pem)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1194"/>
        <source>Parsing error</source>
        <translation>Fehler beim parsen</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1194"/>
        <source>Failed to parse the provided IP filter</source>
        <translation>Fehler beim parsen der IP-Filter</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1196"/>
        <source>Successfully refreshed</source>
        <translation>Erfolgreich aktualisiert</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1263"/>
        <source>Invalid key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1263"/>
        <source>This is not a valid SSL key.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1278"/>
        <source>Invalid certificate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1278"/>
        <source>This is not a valid SSL certificate.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Succesfully refreshed</source>
        <translation type="obsolete">Erfolgreich aktualisiert</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1196"/>
        <source>Successfuly parsed the provided IP filter: %1 rules were applied.</source>
        <comment>%1 is a number</comment>
        <translation>IP-Filter erfolgreich geparsed: %1 Regeln wurden angewandt.</translation>
    </message>
</context>
<context>
    <name>pluginSourceDlg</name>
    <message>
        <location filename="../searchengine/pluginsource.ui" line="13"/>
        <source>Plugin source</source>
        <translation>Plugin Quelle</translation>
    </message>
    <message>
        <location filename="../searchengine/pluginsource.ui" line="26"/>
        <source>Search plugin source:</source>
        <translation>Such Plugin Quelle:</translation>
    </message>
    <message>
        <location filename="../searchengine/pluginsource.ui" line="35"/>
        <source>Local file</source>
        <translation>Lokale Datei</translation>
    </message>
    <message>
        <location filename="../searchengine/pluginsource.ui" line="42"/>
        <source>Web link</source>
        <translation>Web Link</translation>
    </message>
</context>
<context>
    <name>preview</name>
    <message>
        <location filename="../preview.ui" line="16"/>
        <source>Preview selection</source>
        <translation>Vorschau Auswahl</translation>
    </message>
    <message>
        <location filename="../preview.ui" line="51"/>
        <source>File preview</source>
        <translation>Datei vorschauen</translation>
    </message>
    <message>
        <location filename="../preview.ui" line="67"/>
        <source>The following files support previewing, &lt;br&gt;please select one of them:</source>
        <translation>Die folgenden Dateien unterstützen Vorschau, &lt;br&gt;bitte wählen Sie eine:</translation>
    </message>
    <message>
        <location filename="../preview.ui" line="101"/>
        <source>Preview</source>
        <translation>Vorschau</translation>
    </message>
    <message>
        <location filename="../preview.ui" line="108"/>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
</context>
<context>
    <name>previewSelect</name>
    <message>
        <source>Preview impossible</source>
        <translation type="obsolete">Vorschau unmöglich</translation>
    </message>
    <message>
        <source>Sorry, we can&apos;t preview this file</source>
        <translation type="obsolete">Bedauere, wir können keine Vorschau für diese Datei erstellen</translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="obsolete">Name</translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="obsolete">Größe</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation type="obsolete">Fortschritt</translation>
    </message>
</context>
<context>
    <name>search_engine</name>
    <message>
        <location filename="../searchengine/search.ui" line="14"/>
        <location filename="../searchengine/search.ui" line="44"/>
        <source>Search</source>
        <translation>Suche</translation>
    </message>
    <message>
        <location filename="../searchengine/search.ui" line="67"/>
        <source>Status:</source>
        <translation>Status:</translation>
    </message>
    <message>
        <location filename="../searchengine/search.ui" line="91"/>
        <source>Stopped</source>
        <translation>Angehalten</translation>
    </message>
    <message>
        <location filename="../searchengine/search.ui" line="135"/>
        <source>Download</source>
        <translation>Lade</translation>
    </message>
    <message>
        <location filename="../searchengine/search.ui" line="145"/>
        <source>Go to description page</source>
        <translation>Zur Beschreibungsseite wechseln</translation>
    </message>
    <message>
        <location filename="../searchengine/search.ui" line="165"/>
        <source>Search engines...</source>
        <translation>Suchmaschinen...</translation>
    </message>
</context>
<context>
    <name>torrentAdditionDialog</name>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="241"/>
        <location filename="../torrentadditiondlg.cpp" line="244"/>
        <source>Unable to decode torrent file:</source>
        <translation>Torrent Datei kann nicht dekodiert werden:</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="516"/>
        <location filename="../torrentadditiondlg.cpp" line="531"/>
        <location filename="../torrentadditiondlg.cpp" line="533"/>
        <source>Choose save path</source>
        <translation>Wählen Sie den Speicher-Pfad</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="199"/>
        <source>Unable to decode magnet link:</source>
        <translation>Magnet-Link konnte nicht dekodiert werden:</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="205"/>
        <source>Magnet Link</source>
        <translation>Magnet-Link</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="337"/>
        <source>Rename...</source>
        <translation>Umbenennen...</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="381"/>
        <source>Rename the file</source>
        <translation>Datei umbenennen</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="382"/>
        <source>New name:</source>
        <translation>Neuer Name:</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="386"/>
        <location filename="../torrentadditiondlg.cpp" line="416"/>
        <source>The file could not be renamed</source>
        <translation>Die Datei konnte nicht umbenannt werden</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="387"/>
        <source>This file name contains forbidden characters, please choose a different one.</source>
        <translation>Der Dateiname enthält ungültige Zeichen, bitte einen anderen wählen.</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="417"/>
        <location filename="../torrentadditiondlg.cpp" line="451"/>
        <source>This name is already in use in this folder. Please use a different name.</source>
        <translation>Der Dateiname wird in diesem Verzeichnis bereits verwendet. Bitte anderen wählen.</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="450"/>
        <source>The folder could not be renamed</source>
        <translation>Das Verzeichnis konnte nicht umbenannt werden</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="498"/>
        <source>(%1 left after torrent download)</source>
        <comment>e.g. (100MiB left after torrent download)</comment>
        <translation>(%1 übrig nachdem der Torrent geladen wurde)</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="501"/>
        <source>(%1 more are required to download)</source>
        <comment>e.g. (100MiB more are required to download)</comment>
        <translation>(%1 mehr benötigt u die Datei downloaden zu können)</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="586"/>
        <source>Empty save path</source>
        <translation>Leerer Speicher-Pfad</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="586"/>
        <source>Please enter a save path</source>
        <translation>Bitte geben Sie einen Speicher-Pfad ein</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="665"/>
        <source>Save path creation error</source>
        <translation>Fehler beim erstellen des Speicher-Pfades</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="665"/>
        <source>Could not create the save path</source>
        <translation>Speicher-Pfad konnte nicht erstellt werden</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="607"/>
        <source>Invalid label name</source>
        <translation>Ungültiger Labelname</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="607"/>
        <source>Please don&apos;t use any special characters in the label name.</source>
        <translation>Bitte keine Sonderzeichen im Labelname verwenden.</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="650"/>
        <source>Seeding mode error</source>
        <translation>Seeding-Modus-Fehler</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="650"/>
        <source>You chose to skip file checking. However, local files do not seem to exist in the current destionation folder. Please disable this feature or update the save path.</source>
        <translation>Sie haben sich entschlossen das Überprüfen der Dateien zu überspringen. Lokale Dateien scheinen jedoch im aktuellen Zielverzeichnis nicht zu existieren. Bitte deaktivieren Sie diese Eigenschaft oder aktualisieren Sie den Speicherpfad.</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="657"/>
        <source>Invalid file selection</source>
        <translation>Ungültige Datei Auswahl</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="657"/>
        <source>You must select at least one file in the torrent</source>
        <translation>Sie müssen mindestens eine Datei aus dem Torrent selektieren </translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="341"/>
        <source>Priority</source>
        <translation>Priorität</translation>
    </message>
</context>
</TS>
