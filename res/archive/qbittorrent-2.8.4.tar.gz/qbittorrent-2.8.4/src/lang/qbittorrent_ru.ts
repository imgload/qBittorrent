<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="ru">
<context>
    <name>AboutDlg</name>
    <message>
        <source>About qBittorrent</source>
        <translation>О qBittorrent</translation>
    </message>
    <message>
        <source>About</source>
        <translation>О программе</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Автор</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation>Имя:</translation>
    </message>
    <message>
        <source>Country:</source>
        <translation>Страна:</translation>
    </message>
    <message>
        <source>E-mail:</source>
        <translation>Электронная почта:</translation>
    </message>
    <message>
        <source>Christophe Dumez</source>
        <translation>Кристоф Дюме (Christophe Dumez)</translation>
    </message>
    <message>
        <source>France</source>
        <translation>Франция</translation>
    </message>
    <message>
        <source>Translation</source>
        <translation>Перевод</translation>
    </message>
    <message>
        <source>License</source>
        <translation>Лицензия</translation>
    </message>
    <message>
        <source>&lt;h3&gt;&lt;b&gt;qBittorrent&lt;/b&gt;&lt;/h3&gt;</source>
        <translation>&lt;h3&gt;&lt;b&gt;qBittorrent&lt;/b&gt;&lt;/h3&gt;</translation>
    </message>
    <message>
        <source>chris@qbittorrent.org</source>
        <translation>chris@qbittorrent.org</translation>
    </message>
    <message>
        <source>Thanks to</source>
        <translation>Благодарности</translation>
    </message>
    <message utf8="true">
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;A Bittorrent client programmed in C++, based on Qt4 toolkit &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;and libtorrent-rasterbar. &lt;br /&gt;&lt;br /&gt;Copyright ©2006-2010 Christophe Dumez&lt;br /&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Home Page:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://www.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;http://www.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Forum:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://forum.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;http://forum.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;IRC:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; #qbittorrent on Freenode&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;Bittorrent клиент, написанный на C++ с использованием библиотеки Qt4 &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;и libtorrent-rasterbar. &lt;br /&gt;&lt;br /&gt;Copyright ©2006-2010 Christophe Dumez&lt;br /&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Домашняя страница:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://www.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;http://www.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Форум:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://forum.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;http://forum.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;IRC:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; #qbittorrent на Freenode&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message utf8="true">
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;An advanced BitTorrent client programmed in C++, based on Qt4 toolkit and libtorrent-rasterbar. &lt;br /&gt;&lt;br /&gt;Copyright ©2006-2011 Christophe Dumez&lt;br /&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Home Page:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://www.qbittorrent.org&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans&apos;; text-decoration: underline; color:#0057ae;&quot;&gt;http://www.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Bug Tracker:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://bugs.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;http://bugs.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Forum:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://forum.qbittorrent.org&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans&apos;; text-decoration: underline; color:#0057ae;&quot;&gt;http://forum.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;IRC:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; #qbittorrent on Freenode&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;Продвинутый BitTorrent клиент, написанный на C++ с использованием библиотек Qt4 и libtorrent-rasterbar. &lt;br /&gt;&lt;br /&gt;Copyright ©2006-2011 Christophe Dumez&lt;br /&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Домашняя страница:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://www.qbittorrent.org&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans&apos;; text-decoration: underline; color:#0057ae;&quot;&gt;http://www.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Bug Tracker:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://bugs.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;http://bugs.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Форум:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://forum.qbittorrent.org&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans&apos;; text-decoration: underline; color:#0057ae;&quot;&gt;http://forum.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;IRC:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; #qbittorrent на Freenode&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
</context>
<context>
    <name>AdvancedSettings</name>
    <message>
        <source>Property</source>
        <translation type="obsolete">Свойство</translation>
    </message>
    <message>
        <source>Value</source>
        <translation type="obsolete">Значение</translation>
    </message>
    <message>
        <source>Ignore transfer limits on local network</source>
        <translation>Игнорировать лимиты в локальной сети</translation>
    </message>
    <message>
        <source>Include TCP/IP overhead in transfer limits</source>
        <translation type="obsolete">Включать TCP/IP заголовки в лимит передачи</translation>
    </message>
    <message>
        <source>Disk write cache size</source>
        <translation>Дисковый кеш записи</translation>
    </message>
    <message>
        <source> MiB</source>
        <translation>МиБ</translation>
    </message>
    <message>
        <source>Outgoing ports (Min) [0: Disabled]</source>
        <translation>Исходящие порты (Мин) [0: Отключено]</translation>
    </message>
    <message>
        <source>Outgoing ports (Max) [0: Disabled]</source>
        <translation>Исходящие порты (Макс) [0: Отключено]</translation>
    </message>
    <message>
        <source>Recheck torrents on completion</source>
        <translation>Перепроверить торрент по окончании</translation>
    </message>
    <message>
        <source>Transfer list refresh interval</source>
        <translation>Интеравал обновления списка торрентов</translation>
    </message>
    <message>
        <source> ms</source>
        <comment> milliseconds</comment>
        <translation>мс</translation>
    </message>
    <message>
        <source>Resolve peer countries (GeoIP)</source>
        <translation>Определить страну пира (GeoIP)</translation>
    </message>
    <message>
        <source>Resolve peer host names</source>
        <translation>Определить имя хоста пира</translation>
    </message>
    <message>
        <source>Maximum number of half-open connections [0: Disabled]</source>
        <translation>Максимальное количество полуоткрытых соединений [0:Отключено]</translation>
    </message>
    <message>
        <source>Strict super seeding</source>
        <translation>Режим супер раздачи</translation>
    </message>
    <message>
        <source>Network Interface (requires restart)</source>
        <translation>Сетевой интерфейс (Требует перезагрузки)</translation>
    </message>
    <message>
        <source>Any interface</source>
        <comment>i.e. Any network interface</comment>
        <translation>Любой интерфейс</translation>
    </message>
    <message>
        <source>Display program notification baloons</source>
        <translation type="obsolete">Показывать всплывающие сообщения в  системном лотке</translation>
    </message>
    <message>
        <source>Display program notification balloons</source>
        <translation type="obsolete">Показывать всплывающие сообщения в  системном лотке</translation>
    </message>
    <message>
        <source>Enable embedded tracker</source>
        <translation>Включить встроенный трекер</translation>
    </message>
    <message>
        <source>Embedded tracker port</source>
        <translation>Порт встроенного трекера</translation>
    </message>
    <message>
        <source>Check for software updates</source>
        <translation>Проверить обновления</translation>
    </message>
    <message>
        <source>Use system icon theme</source>
        <translation>Использовать системные иконки</translation>
    </message>
    <message>
        <source>IP Address to report to trackers (requires restart)</source>
        <translation>IP адрес для сообщения трекерам (требуется перезапуск)</translation>
    </message>
    <message>
        <source>Display program on-screen notifications</source>
        <translation>Показывать экранные сообщения</translation>
    </message>
    <message>
        <source>Confirm torrent deletion</source>
        <translation>Подтверждать удаление торрента</translation>
    </message>
    <message>
        <source>Setting</source>
        <translation>Параметр</translation>
    </message>
    <message>
        <source>Value</source>
        <comment>Value set for this setting</comment>
        <translation>Значение</translation>
    </message>
    <message>
        <source>Exchange trackers with other peers</source>
        <translation>Обмениваться трекерами с другими пирами</translation>
    </message>
</context>
<context>
    <name>AutomatedRssDownloader</name>
    <message>
        <source>Automated RSS Downloader</source>
        <translation>Автоматический загрузчик RSS</translation>
    </message>
    <message>
        <source>Enable the automated RSS downloader</source>
        <translation>Включить автоматический загрузчик RSS</translation>
    </message>
    <message>
        <source>Download rules</source>
        <translation>Правила загрузки</translation>
    </message>
    <message>
        <source>Rule definition</source>
        <translation>Описание правил</translation>
    </message>
    <message>
        <source>Must contain:</source>
        <translation>Должно содержать:</translation>
    </message>
    <message>
        <source>Must not contain:</source>
        <translation>Не должно содержать:</translation>
    </message>
    <message>
        <source>Save torrent to:</source>
        <translation type="obsolete">Сохранить торрент в:</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Assign label:</source>
        <translation>Присвоить метку:</translation>
    </message>
    <message>
        <source>Apply rule to feeds:</source>
        <translation>Применить правило к каналу:</translation>
    </message>
    <message>
        <source>Matching RSS articles</source>
        <translation>Совпадающие RSS заголовки</translation>
    </message>
    <message>
        <source>Save to a different directory</source>
        <translation>Сохранить в другую папку</translation>
    </message>
    <message>
        <source>Save to:</source>
        <translation>Сохранить в:</translation>
    </message>
    <message>
        <source>Import...</source>
        <translation>Импорт...</translation>
    </message>
    <message>
        <source>Export...</source>
        <translation>Экспорт...</translation>
    </message>
    <message>
        <source>New rule name</source>
        <translation>Новое имя правила</translation>
    </message>
    <message>
        <source>Please type the name of the new download rule.</source>
        <translation>Введите имя нового правила скачивания.</translation>
    </message>
    <message>
        <source>Rule name conflict</source>
        <translation>Конфликт имени правила</translation>
    </message>
    <message>
        <source>A rule with this name already exists, please choose another name.</source>
        <translation>Правило с таким именем уже существует. Пожалуйста, выберите другое имя.</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the download rule named %1?</source>
        <translation>Вы уверены, что хотите удалить правило загрузки %1?</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the selected download rules?</source>
        <translation>Вы уверены, что хотите удалить выбранные правила загрузки?</translation>
    </message>
    <message>
        <source>Rule deletion confirmation</source>
        <translation>Подтверждение удаления правила</translation>
    </message>
    <message>
        <source>Destination directory</source>
        <translation>Папка назначения</translation>
    </message>
    <message>
        <source>Invalid action</source>
        <translation>Неверное действие</translation>
    </message>
    <message>
        <source>The list is empty, there is nothing to export.</source>
        <translation>Список пуст. Нечего экспортировать.</translation>
    </message>
    <message>
        <source>Where would you like to save the list?</source>
        <translation>Куда вы хотите соранить список?</translation>
    </message>
    <message>
        <source>Rules list (*.rssrules)</source>
        <translation>Списки правил (*.rssrules)</translation>
    </message>
    <message>
        <source>I/O Error</source>
        <translation>Ошибка ввода/вывода</translation>
    </message>
    <message>
        <source>Failed to create the destination file</source>
        <translation>Не удалось создать целевой файл</translation>
    </message>
    <message>
        <source>Please point to the RSS download rules file</source>
        <translation>Укажите файл с правилами загрузки RSS</translation>
    </message>
    <message>
        <source>Rules list (*.rssrules *.filters)</source>
        <translation>Списки правил (*.rssrules *.filters)</translation>
    </message>
    <message>
        <source>Import Error</source>
        <translation>Ошибка импорта</translation>
    </message>
    <message>
        <source>Failed to import the selected rules file</source>
        <translation>Ошибка импортирования выбранного файла правил</translation>
    </message>
    <message>
        <source>Add new rule...</source>
        <translation>Добавить правило...</translation>
    </message>
    <message>
        <source>Delete rule</source>
        <translation>Удалить правило</translation>
    </message>
    <message>
        <source>Rename rule...</source>
        <translation>Переименовать правило...</translation>
    </message>
    <message>
        <source>Delete selected rules</source>
        <translation>Удалить выбранные правила</translation>
    </message>
    <message>
        <source>Rule renaming</source>
        <translation>Переименование правила</translation>
    </message>
    <message>
        <source>Please type the new rule name</source>
        <translation>Введите новое имя правила</translation>
    </message>
    <message>
        <source>Use regular expressions</source>
        <translation>Использовать регулярные выражения</translation>
    </message>
    <message>
        <source>Regex mode: use Perl-like regular expressions</source>
        <translation>Режим Regex: использовать регулярные выражения в стиле Perl</translation>
    </message>
    <message>
        <source>Wildcard mode: you can use&lt;ul&gt;&lt;li&gt;? to match any single character&lt;/li&gt;&lt;li&gt;* to match zero or more of any characters&lt;/li&gt;&lt;li&gt;Whitespaces count as AND operators&lt;/li&gt;&lt;/ul&gt;</source>
        <translation>Режим Wildcard: можно использовать&lt;ul&gt;&lt;li&gt;? для замещения любого одного символа&lt;/li&gt;&lt;li&gt;* для замещения нуля и более любых символов&lt;/li&gt;&lt;li&gt;Пробелы действуют как операторы AND&lt;/li&gt;&lt;/ul&gt;</translation>
    </message>
    <message>
        <source>Wildcard mode: you can use&lt;ul&gt;&lt;li&gt;? to match any single character&lt;/li&gt;&lt;li&gt;* to match zero or more of any characters&lt;/li&gt;&lt;li&gt;| is used as OR operator&lt;/li&gt;&lt;/ul&gt;</source>
        <translation>Режим Wildcard: можно использовать&lt;ul&gt;&lt;li&gt;? для замещения любого одного символа&lt;/li&gt;&lt;li&gt;* для замещения нуля и более любых символов&lt;/li&gt;&lt;li&gt;| используется как оператор OR&lt;/li&gt;&lt;/ul&gt;</translation>
    </message>
</context>
<context>
    <name>Bittorrent</name>
    <message>
        <source>%1 reached the maximum ratio you set.</source>
        <translation type="obsolete">%1 достиг установленного вами максимального соотношения.</translation>
    </message>
    <message>
        <source>qBittorrent is bound to port: TCP/%1</source>
        <comment>e.g: qBittorrent is bound to port: 6881</comment>
        <translation type="obsolete">qBittorrent привязан к порту: TCP/%1</translation>
    </message>
    <message>
        <source>UPnP support [ON]</source>
        <translation type="obsolete">Поддержка UPnP [Вкл]</translation>
    </message>
    <message>
        <source>UPnP support [OFF]</source>
        <translation type="obsolete">Поддержка UPnP [Выкл]</translation>
    </message>
    <message>
        <source>NAT-PMP support [ON]</source>
        <translation type="obsolete">Поддержка NAT-PMP [Вкл]</translation>
    </message>
    <message>
        <source>NAT-PMP support [OFF]</source>
        <translation type="obsolete">Поддержка NAT-PMP [Выкл]</translation>
    </message>
    <message>
        <source>DHT support [ON], port: UDP/%1</source>
        <translation type="obsolete">Поддержка DHT [Вкл.], порт: UDP/%1</translation>
    </message>
    <message>
        <source>DHT support [OFF]</source>
        <translation type="obsolete">Поддержка DHT [Выкл]</translation>
    </message>
    <message>
        <source>PeX support [ON]</source>
        <translation type="obsolete">Поддержка PeX [Вкл]</translation>
    </message>
    <message>
        <source>Local Peer Discovery [ON]</source>
        <translation type="obsolete">Обнаружение локальных пиров [Вкл]</translation>
    </message>
    <message>
        <source>Local Peer Discovery support [OFF]</source>
        <translation type="obsolete">Обнаружение локальных пиров [Выкл]</translation>
    </message>
    <message>
        <source>Encryption support [ON]</source>
        <translation type="obsolete">Поддержка шифрования [Вкл]</translation>
    </message>
    <message>
        <source>Encryption support [FORCED]</source>
        <translation type="obsolete">Поддержка шифрования [Принудительно]</translation>
    </message>
    <message>
        <source>Encryption support [OFF]</source>
        <translation type="obsolete">Поддержка шифрования [Выкл]</translation>
    </message>
    <message>
        <source>Web User Interface Error - Unable to bind Web UI to port %1</source>
        <translation type="obsolete">Ошибка WEb интерфейса - Не могу привязаться к порту %1</translation>
    </message>
    <message>
        <source>&apos;%1&apos; was removed from transfer list and hard disk.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation type="obsolete">&apos;%1&apos; был удален из списка передач и с жесткого диска.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; was removed from transfer list.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation type="obsolete">&apos;%1&apos; был удален из списка передач.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is not a valid magnet URI.</source>
        <translation type="obsolete">&apos;%1&apos; не является magnet URI.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is already in download list.</source>
        <comment>e.g: &apos;xxx.avi&apos; is already in download list.</comment>
        <translation type="obsolete">&apos;%1&apos; уже присутствует в списке закачек.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; added to download list.</source>
        <comment>&apos;/home/y/xxx.torrent&apos; was added to download list.</comment>
        <translation type="obsolete">&apos;%1&apos; добавлен в список закачек.</translation>
    </message>
    <message>
        <source>Unable to decode torrent file: &apos;%1&apos;</source>
        <comment>e.g: Unable to decode torrent file: &apos;/home/y/xxx.torrent&apos;</comment>
        <translation type="obsolete">Не удалось декодировать torrent файл: &apos;%1&apos;</translation>
    </message>
    <message>
        <source>This file is either corrupted or this isn&apos;t a torrent.</source>
        <translation type="obsolete">Этот файл либо поврежден, либо не torrent типа.</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;was blocked due to your IP filter&lt;/i&gt;</source>
        <comment>x.y.z.w was blocked</comment>
        <translation type="obsolete">&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;был заблокирован в соответствии с вашим IP фильтром&lt;/i&gt;</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;was banned due to corrupt pieces&lt;/i&gt;</source>
        <comment>x.y.z.w was banned</comment>
        <translation type="obsolete">&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;был заблокирован из-за поврежденных кусочков&lt;/i&gt;</translation>
    </message>
    <message>
        <source>Recursive download of file %1 embedded in torrent %2</source>
        <comment>Recursive download of test.torrent embedded in torrent test2</comment>
        <translation type="obsolete">Рекурсивная загрузка файла %1 встроенного в торрент %2</translation>
    </message>
    <message>
        <source>Unable to decode %1 torrent file.</source>
        <translation type="obsolete">Не удалось декодировать %1 torrent файл.</translation>
    </message>
    <message>
        <source>UPnP/NAT-PMP: Port mapping failure, message: %1</source>
        <translation type="obsolete">Распределение портов UPnP/NAT-PMP не удалось с сообщением: %1</translation>
    </message>
    <message>
        <source>UPnP/NAT-PMP: Port mapping successful, message: %1</source>
        <translation type="obsolete">Распределение портов UPnP/NAT-PMP прошло успешно: %1</translation>
    </message>
    <message>
        <source>Fast resume data was rejected for torrent %1, checking again...</source>
        <translation type="obsolete">Быстрое восстановление данных для torrentа %1 было невозможно, проверка заново...</translation>
    </message>
    <message>
        <source>Url seed lookup failed for url: %1, message: %2</source>
        <translation type="obsolete">Поиск раздающего Url не удался: %1, сообщение: %2</translation>
    </message>
    <message>
        <source>Downloading &apos;%1&apos;, please wait...</source>
        <comment>e.g: Downloading &apos;xxx.torrent&apos;, please wait...</comment>
        <translation type="obsolete">Скачивание &apos;%1&apos;, подождите...</translation>
    </message>
    <message>
        <source>Using a disk cache size of %1 MiB</source>
        <translation type="obsolete">Используется дисковый кеш размером %1 МиБ</translation>
    </message>
    <message>
        <source>PeX support [OFF]</source>
        <translation type="obsolete">Поддержка PeX [Выкл]</translation>
    </message>
    <message>
        <source>Restart is required to toggle PeX support</source>
        <translation type="obsolete">Необходимо перезапустить qBittorrent для включения настройки PeX</translation>
    </message>
    <message>
        <source>The Web UI is listening on port %1</source>
        <translation type="obsolete">Web интерфейс прослушивает пор %1</translation>
    </message>
    <message>
        <source>HTTP user agent is %1</source>
        <translation type="obsolete">Браузер %1</translation>
    </message>
    <message>
        <source>Reason: %1</source>
        <translation type="obsolete">Причина: %1</translation>
    </message>
    <message>
        <source>Note: new trackers were added to the existing torrent.</source>
        <translation type="obsolete">Примечание: новые трекеры были добавлены к существующему торренту.</translation>
    </message>
    <message>
        <source>Note: new URL seeds were added to the existing torrent.</source>
        <translation type="obsolete">Примечание: новые URL сидов были добавлены к существующему торренту.</translation>
    </message>
    <message>
        <source>An I/O error occured, &apos;%1&apos; paused.</source>
        <translation type="obsolete">Ошибка Ввода/Вывода: &apos;%1&apos; приостановлен.</translation>
    </message>
    <message>
        <source>Removing torrent %1...</source>
        <translation type="obsolete">Удаление торрента %1...</translation>
    </message>
    <message>
        <source>Pausing torrent %1...</source>
        <translation type="obsolete">Приостановка торрента %1...</translation>
    </message>
    <message>
        <source>Error: The torrent %1 does not contain any file.</source>
        <translation type="obsolete">Ошибка: Торрент %1 не содержит никаких файлов.</translation>
    </message>
    <message>
        <source>File sizes mismatch for torrent %1, pausing it.</source>
        <translation type="obsolete">Несовпадение размеров файлов для торрента %1, приостанавливаю его.</translation>
    </message>
    <message>
        <source>Torrent name: %1</source>
        <translation type="obsolete">Имя торрента: %1</translation>
    </message>
    <message>
        <source>Torrent size: %1</source>
        <translation type="obsolete">Размер торрента: %1</translation>
    </message>
    <message>
        <source>Save path: %1</source>
        <translation type="obsolete">Путь для сохранения: %1</translation>
    </message>
    <message>
        <source>The torrent was downloaded in %1.</source>
        <comment>The torrent was downloaded in 1 hour and 20 seconds</comment>
        <translation type="obsolete">Торрент был скачен за %1.</translation>
    </message>
    <message>
        <source>Thank you for using qBittorrent.</source>
        <translation type="obsolete">Спасибо за использование qBittorrent.</translation>
    </message>
    <message>
        <source>[qBittorrent] %1 has finished downloading</source>
        <translation type="obsolete">[qBittorrent] скачивание %1 завершено</translation>
    </message>
</context>
<context>
    <name>ConsoleDlg</name>
    <message>
        <source>General</source>
        <translation type="obsolete">Общие</translation>
    </message>
    <message>
        <source>Blocked IPs</source>
        <translation type="obsolete">Заблокированные IP</translation>
    </message>
    <message>
        <source>qBittorrent log viewer</source>
        <translation type="obsolete">Просмотрщик журнала qBittorrent</translation>
    </message>
</context>
<context>
    <name>CookiesDlg</name>
    <message>
        <source>Cookies management</source>
        <translation>Управление Cookies</translation>
    </message>
    <message>
        <source>Key</source>
        <extracomment>As in Key/Value pair</extracomment>
        <translation>Ключ</translation>
    </message>
    <message>
        <source>Value</source>
        <extracomment>As in Key/Value pair</extracomment>
        <translation>Значение</translation>
    </message>
    <message>
        <source>Common keys for cookies are : &apos;%1&apos;, &apos;%2&apos;.
You should get this information from your Web browser preferences.</source>
        <translatorcomment>&apos;из настроек&apos; - в firefox 3.6.4</translatorcomment>
        <translation>Частые ключи для cookies это : &apos;%1&apos;, &apos;%2&apos;.
Вам следует взять эту информацию из настроек вашего веб-браузера.</translation>
    </message>
</context>
<context>
    <name>DNSUpdater</name>
    <message>
        <source>Your dynamic DNS was successfuly updated.</source>
        <translation>Ваш динамический DNS адрес был успешно обновлён.</translation>
    </message>
    <message>
        <source>Dynamic DNS error: The service is temporarily unavailable, it will be retried in 30 minutes.</source>
        <translation>Ошибка Dynamic DNS: Служба временно не доступна. Попробую соединиться через 30 минут.</translation>
    </message>
    <message>
        <source>Dynamic DNS error: hostname supplied does not exist under specified account.</source>
        <translation>Ошибка Dynamic DNS:предоставленное  имя хоста не существует в указанной учётной записи.</translation>
    </message>
    <message>
        <source>Dynamic DNS error: Invalid username/password.</source>
        <translation>Ошибка Dynamic DNS: Неверное имя пользователя/пароль.</translation>
    </message>
    <message>
        <source>Dynamic DNS error: qBittorrent was blacklisted by the service, please report a bug at http://bugs.qbittorrent.org.</source>
        <translation>Ошибка Dynamic DNS: qBittorrent внесён службой в чёрный список. Пожалуйста, сообщите об ошибке на  http://bugs.qbittorrent.org.</translation>
    </message>
    <message>
        <source>Dynamic DNS error: %1 was returned by the service, please report a bug at http://bugs.qbittorrent.org.</source>
        <translation>Ошибка Dynamic DNS: %1 было возвращено службой. Пожалуйста, сообщите об ошибке на  http://bugs.qbittorrent.org.</translation>
    </message>
    <message>
        <source>Dynamic DNS error: Your username was blocked due to abuse.</source>
        <translation>Ошибка Dynamic DNS: Ваше имя пользователя было блокировано из-за злоупотребления.</translation>
    </message>
    <message>
        <source>Dynamic DNS error: supplied domain name is invalid.</source>
        <translation>Ошибка Dynamic DNS: предоставленное доменное имя неверное.</translation>
    </message>
    <message>
        <source>Dynamic DNS error: supplied username is too short.</source>
        <translation>Ошибка Dynamic DNS: предоставленное имя пользователя слишком короткое.</translation>
    </message>
    <message>
        <source>Dynamic DNS error: supplied password is too short.</source>
        <translation>Ошибка Dynamic DNS: предоставленный пароль слишком короткий.</translation>
    </message>
</context>
<context>
    <name>DownloadThread</name>
    <message>
        <source>I/O Error</source>
        <translation>Ошибка ввода/вывода</translation>
    </message>
    <message>
        <source>The remote host name was not found (invalid hostname)</source>
        <translation>Удаленный хост не был найден (неправильное имя хоста)</translation>
    </message>
    <message>
        <source>The operation was canceled</source>
        <translation>Операция была отменена</translation>
    </message>
    <message>
        <source>The remote server closed the connection prematurely, before the entire reply was received and processed</source>
        <translation>Удаленный сервер закрыл соединение, прежде чем весь ответ был принят и обработан</translation>
    </message>
    <message>
        <source>The connection to the remote server timed out</source>
        <translation>Время соединения с удаленным сервером вышло</translation>
    </message>
    <message>
        <source>SSL/TLS handshake failed</source>
        <translation>Соединение SSL/TLS не удалось</translation>
    </message>
    <message>
        <source>The remote server refused the connection</source>
        <translation>Удаленный сервер отклонил соединение</translation>
    </message>
    <message>
        <source>The connection to the proxy server was refused</source>
        <translation>Прокси-сервер отклонил соединение</translation>
    </message>
    <message>
        <source>The proxy server closed the connection prematurely</source>
        <translation>Прокси-сервер преждевременно закрыл соединение</translation>
    </message>
    <message>
        <source>The proxy host name was not found</source>
        <translation>Имя прокси-сервера не было найдено</translation>
    </message>
    <message>
        <source>The connection to the proxy timed out or the proxy did not reply in time to the request sent</source>
        <translation>Подключение к прокси-серверу истекло или прокси-сервер не ответил на запрос</translation>
    </message>
    <message>
        <source>The proxy requires authentication in order to honour the request but did not accept any credentials offered</source>
        <translation>Прокси-сервер требует аутентификации, но не принял указанные учетные данные</translation>
    </message>
    <message>
        <source>The access to the remote content was denied (401)</source>
        <translation>В доступе к данным было отказано (401)</translation>
    </message>
    <message>
        <source>The operation requested on the remote content is not permitted</source>
        <translation>В данной операции над данными отказано</translation>
    </message>
    <message>
        <source>The remote content was not found at the server (404)</source>
        <translation>Данные не были найдены на сервере (404)</translation>
    </message>
    <message>
        <source>The remote server requires authentication to serve the content but the credentials provided were not accepted</source>
        <translation>Удаленный сервер требует аутентификацию для отдачи данных, но указанные учетные данные не были приняты</translation>
    </message>
    <message>
        <source>The Network Access API cannot honor the request because the protocol is not known</source>
        <translation>API сетевого доступа не может выполнить запрос, потому что протокол не известен</translation>
    </message>
    <message>
        <source>The requested operation is invalid for this protocol</source>
        <translation>Запрошенная операция не поддерживается данным протоколом</translation>
    </message>
    <message>
        <source>An unknown network-related error was detected</source>
        <translation>Неизвестная сетевая ошибка</translation>
    </message>
    <message>
        <source>An unknown proxy-related error was detected</source>
        <translation>Неизвестная ошибка прокси-сервера</translation>
    </message>
    <message>
        <source>An unknown error related to the remote content was detected</source>
        <translation>Неизвестная ошибка данных</translation>
    </message>
    <message>
        <source>A breakdown in protocol was detected</source>
        <translation>Ошибка в протоколе</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Неизвестная ошибка</translation>
    </message>
</context>
<context>
    <name>EventManager</name>
    <message>
        <source>%1/s</source>
        <comment>e.g. 120 KiB/s</comment>
        <translation>%1/с</translation>
    </message>
    <message>
        <source>Working</source>
        <translation>Работает</translation>
    </message>
    <message>
        <source>Updating...</source>
        <translation>Обновляется...</translation>
    </message>
    <message>
        <source>Not working</source>
        <translation>Не работает</translation>
    </message>
    <message>
        <source>Not contacted yet</source>
        <translation>Не соединился</translation>
    </message>
    <message>
        <source>this session</source>
        <translation>эта сессия</translation>
    </message>
    <message>
        <source>/s</source>
        <comment>/second (i.e. per second)</comment>
        <translation>/с</translation>
    </message>
    <message>
        <source>Seeded for %1</source>
        <comment>e.g. Seeded for 3m10s</comment>
        <translation>Раздается %1</translation>
    </message>
    <message>
        <source>%1 max</source>
        <comment>e.g. 10 max</comment>
        <translation>%1 макс</translation>
    </message>
</context>
<context>
    <name>ExecutionLog</name>
    <message>
        <source>Form</source>
        <translation type="obsolete">Форма</translation>
    </message>
    <message>
        <source>General</source>
        <translation>Общие</translation>
    </message>
    <message>
        <source>Blocked IPs</source>
        <translation>Заблокированные IP</translation>
    </message>
</context>
<context>
    <name>FeedDownloader</name>
    <message>
        <source>RSS Feed downloader</source>
        <translatorcomment>dont understand perfectly what is this &apos;downloader&apos;</translatorcomment>
        <translation type="obsolete">Загрузка RSS канала</translation>
    </message>
    <message>
        <source>RSS feed:</source>
        <translation type="obsolete">RSS канал:</translation>
    </message>
    <message>
        <source>Feed name</source>
        <translation type="obsolete">Имя канала</translation>
    </message>
    <message>
        <source>Automatically download torrents from this feed</source>
        <translation type="obsolete">Автоматически загружать торренты с этого канала</translation>
    </message>
    <message>
        <source>Download filters</source>
        <translation type="obsolete">Фильтр загрузок</translation>
    </message>
    <message>
        <source>Filters:</source>
        <translation type="obsolete">Фильтры:</translation>
    </message>
    <message>
        <source>Filter settings</source>
        <translation type="obsolete">Настройки фильтра</translation>
    </message>
    <message>
        <source>Matches:</source>
        <translation type="obsolete">Совпадения:</translation>
    </message>
    <message>
        <source>Does not match:</source>
        <translation type="obsolete">Не совпадают:</translation>
    </message>
    <message>
        <source>Destination folder:</source>
        <translation type="obsolete">Папка назначения:</translation>
    </message>
    <message>
        <source>...</source>
        <translation type="obsolete">...</translation>
    </message>
    <message>
        <source>Filter testing</source>
        <translation type="obsolete">Тестирование фильтра</translation>
    </message>
    <message>
        <source>Torrent title:</source>
        <translation type="obsolete">Заголовок торрента:</translation>
    </message>
    <message>
        <source>Result:</source>
        <translation type="obsolete">Результат:</translation>
    </message>
    <message>
        <source>Test</source>
        <translation type="obsolete">Тест</translation>
    </message>
    <message>
        <source>Import...</source>
        <translation type="obsolete">Импорт...</translation>
    </message>
    <message>
        <source>Export...</source>
        <translation type="obsolete">Экспорт...</translation>
    </message>
    <message>
        <source>Rename filter</source>
        <translation type="obsolete">Переименовать фильтр</translation>
    </message>
    <message>
        <source>Remove filter</source>
        <translation type="obsolete">Удалить фильтр</translation>
    </message>
    <message>
        <source>Add filter</source>
        <translation type="obsolete">Добавить фильтр</translation>
    </message>
</context>
<context>
    <name>FeedDownloaderDlg</name>
    <message>
        <source>New filter</source>
        <translation type="obsolete">Новый фильтр</translation>
    </message>
    <message>
        <source>Please choose a name for this filter</source>
        <translation type="obsolete">Пожалуйста, выберите имя для этого фильтра</translation>
    </message>
    <message>
        <source>Filter name:</source>
        <translation type="obsolete">имя фильтра:</translation>
    </message>
    <message>
        <source>Invalid filter name</source>
        <translation type="obsolete">Неправильное имя фильтра</translation>
    </message>
    <message>
        <source>The filter name cannot be left empty.</source>
        <translation type="obsolete">Имя фильтра не может быть пустым.</translation>
    </message>
    <message>
        <source>This filter name is already in use.</source>
        <translation type="obsolete">Это имя фильтра уже используется.</translation>
    </message>
    <message>
        <source>Filter testing error</source>
        <translation type="obsolete">Ошибка тестирования фильтра</translation>
    </message>
    <message>
        <source>Please specify a test torrent name.</source>
        <translation type="obsolete">Пожалуйста, укажите имя тестового торрента.</translation>
    </message>
    <message>
        <source>matches</source>
        <translation type="obsolete">совпадения</translation>
    </message>
    <message>
        <source>does not match</source>
        <translation type="obsolete">не совпадают</translation>
    </message>
    <message>
        <source>Select file to import</source>
        <translation type="obsolete">Выберите файл для импорта</translation>
    </message>
    <message>
        <source>Filters Files</source>
        <translation type="obsolete">Файлы фильтров</translation>
    </message>
    <message>
        <source>Import successful</source>
        <translation type="obsolete">Импорт завершен</translation>
    </message>
    <message>
        <source>Filters import was successful.</source>
        <translation type="obsolete">Импорт фильтров завершен.</translation>
    </message>
    <message>
        <source>Import failure</source>
        <translation type="obsolete">Ошибка при импорте</translation>
    </message>
    <message>
        <source>Filters could not be imported due to an I/O error.</source>
        <translation type="obsolete">Фильтры не импортированы из-за ошибки ввода/вывода.</translation>
    </message>
    <message>
        <source>Select destination file</source>
        <translation type="obsolete">Выберите файл назначения</translation>
    </message>
    <message>
        <source>Export successful</source>
        <translation type="obsolete">Экспорт завершен</translation>
    </message>
    <message>
        <source>Filters export was successful.</source>
        <translation type="obsolete">Экспорт фильтров завершен.</translation>
    </message>
    <message>
        <source>Export failure</source>
        <translation type="obsolete">Ошибка при экспорте</translation>
    </message>
    <message>
        <source>Filters could not be exported due to an I/O error.</source>
        <translation type="obsolete">Фильтры не экспортированы из-за ошибки ввода/вывода.</translation>
    </message>
    <message>
        <source>Choose save path</source>
        <translation type="obsolete">Выберите путь сохранения</translation>
    </message>
</context>
<context>
    <name>FeedList</name>
    <message>
        <source>Unread</source>
        <translation type="obsolete">Не прочитано</translation>
    </message>
</context>
<context>
    <name>FeedListWidget</name>
    <message>
        <source>RSS feeds</source>
        <translation>RSS каналы</translation>
    </message>
    <message>
        <source>Unread</source>
        <translation>Не прочитано</translation>
    </message>
</context>
<context>
    <name>GUI</name>
    <message>
        <source>qBittorrent</source>
        <translation type="obsolete">qBittorrent</translation>
    </message>
    <message>
        <source>Open Torrent Files</source>
        <translation type="obsolete">Открыть файлы Torrent</translation>
    </message>
    <message>
        <source>Torrent Files</source>
        <translation type="obsolete">Файлы Torrent</translation>
    </message>
    <message>
        <source>Transfers</source>
        <translation type="obsolete">Передачи</translation>
    </message>
    <message>
        <source>qBittorrent %1</source>
        <comment>e.g: qBittorrent v0.x</comment>
        <translation type="obsolete">qBittorrent %1</translation>
    </message>
    <message>
        <source>DL speed: %1 KiB/s</source>
        <comment>e.g: Download speed: 10 KiB/s</comment>
        <translation type="obsolete">Скорость скач.: %1 KiB/с</translation>
    </message>
    <message>
        <source>UP speed: %1 KiB/s</source>
        <comment>e.g: Upload speed: 10 KiB/s</comment>
        <translation type="obsolete">Отдача: %1 KiB/с</translation>
    </message>
    <message>
        <source>%1 has finished downloading.</source>
        <comment>e.g: xxx.avi has finished downloading.</comment>
        <translation type="obsolete">скачивание %1 завершено.</translation>
    </message>
    <message>
        <source>I/O Error</source>
        <comment>i.e: Input/Output Error</comment>
        <translation type="obsolete">Ошибка ввода/вывода</translation>
    </message>
    <message>
        <source>Search</source>
        <translation type="obsolete">Поиск</translation>
    </message>
    <message>
        <source>RSS</source>
        <translation type="obsolete">RSS</translation>
    </message>
    <message>
        <source>An I/O error occured for torrent %1.
 Reason: %2</source>
        <comment>e.g: An error occured for torrent xxx.avi.
 Reason: disk is full.</comment>
        <translation type="obsolete">Произошла ошибка ввода/вывода для торрента %1.
Причина: %2</translation>
    </message>
    <message>
        <source>Alt+1</source>
        <comment>shortcut to switch to first tab</comment>
        <translation type="obsolete">Alt+1</translation>
    </message>
    <message>
        <source>Url download error</source>
        <translation type="obsolete">Ошибка при скачивании URL</translation>
    </message>
    <message>
        <source>Couldn&apos;t download file at url: %1, reason: %2.</source>
        <translation type="obsolete">Невозможно скачать файл по URL: %1, причина: %2.</translation>
    </message>
    <message>
        <source>Ctrl+F</source>
        <comment>shortcut to switch to search tab</comment>
        <translation type="obsolete">Ctrl+F</translation>
    </message>
    <message>
        <source>Options were saved successfully.</source>
        <translation type="obsolete">Настройки были успешно сохранены.</translation>
    </message>
    <message>
        <source>Some files are currently transferring.
Are you sure you want to quit qBittorrent?</source>
        <translation type="obsolete">Есть активные торренты. Вы уверены что хотите выйти из qBittorrent?</translation>
    </message>
    <message>
        <source>Alt+2</source>
        <comment>shortcut to switch to third tab</comment>
        <translation type="obsolete">Alt+2</translation>
    </message>
    <message>
        <source>Alt+3</source>
        <comment>shortcut to switch to fourth tab</comment>
        <translation type="obsolete">Alt+3</translation>
    </message>
    <message>
        <source>Global Upload Speed Limit</source>
        <translation type="obsolete">Глобальное ограничение скорости раздачи</translation>
    </message>
    <message>
        <source>Global Download Speed Limit</source>
        <translation type="obsolete">Глобальное ограничение скорости закачки</translation>
    </message>
    <message>
        <source>qBittorrent %1 (Down: %2/s, Up: %3/s)</source>
        <comment>%1 is qBittorrent version</comment>
        <translation type="obsolete">qBittorrent %1 (Скач: %2/с, Отд: %3/с)</translation>
    </message>
    <message>
        <source>Recursive download confirmation</source>
        <translation type="obsolete">Подтверждение рекурсивной загрузки</translation>
    </message>
    <message>
        <source>The torrent %1 contains torrent files, do you want to proceed with their download?</source>
        <translatorcomment>Коряво как-то получилось &gt;_&lt; // нормально.</translatorcomment>
        <translation type="obsolete">Торрент %1 содержит торрент-файлы, хотите ли вы приступить к их загрузке?</translation>
    </message>
    <message>
        <source>Transfers (%1)</source>
        <translation type="obsolete">Передачи (%1)</translation>
    </message>
    <message>
        <source>Torrent file association</source>
        <translatorcomment>Из systemsettings (KDE 4.4.5)</translatorcomment>
        <translation type="obsolete">Привязки торрент-файлов</translation>
    </message>
    <message>
        <source>qBittorrent is not the default application to open torrent files or Magnet links.
Do you want to associate qBittorrent to torrent files and Magnet links?</source>
        <translatorcomment>Может лучше наоборот, ссылки с файлами к qBittorrent привязывать?</translatorcomment>
        <translation type="obsolete">qBittorrent сейчас не является приложением по умолчанию для открытия торрент-файлов или Magnet-ссылок.
Хотите ли вы открывать торрент-файлы и Magnet-ссылки с помощью qBittorrent?</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation type="obsolete">Да</translation>
    </message>
    <message>
        <source>No</source>
        <translation type="obsolete">Нет</translation>
    </message>
    <message>
        <source>Never</source>
        <translation type="obsolete">Никогда</translation>
    </message>
    <message>
        <source>Always</source>
        <translation type="obsolete">Всегда</translation>
    </message>
    <message>
        <source>Exiting qBittorrent</source>
        <translatorcomment>Или Завершаю работу будет правильнее?</translatorcomment>
        <translation type="obsolete">Завершение работы qBittorrent</translation>
    </message>
    <message>
        <source>Set the password...</source>
        <translation type="obsolete">Установить пароль...</translation>
    </message>
    <message>
        <source>Password update</source>
        <translation type="obsolete">Обновить пароль</translation>
    </message>
    <message>
        <source>The UI lock password has been successfully updated</source>
        <translation type="obsolete">Пароль блокировки интерфейса был успешно обновлен</translation>
    </message>
    <message>
        <source>UI lock password</source>
        <translation type="obsolete">Пароль блокировки интерфейса</translation>
    </message>
    <message>
        <source>Please type the UI lock password:</source>
        <translation type="obsolete">Пожалуйста, введите пароль блокировки интерфейса:</translation>
    </message>
    <message>
        <source>Invalid password</source>
        <translation type="obsolete">Не верный пароль</translation>
    </message>
    <message>
        <source>The password is invalid</source>
        <translation type="obsolete">Этот пароль не верен</translation>
    </message>
    <message>
        <source>A newer version is available</source>
        <translation type="obsolete">Новая версия доступна</translation>
    </message>
    <message>
        <source>A newer version of qBittorrent is available on Sourceforge.
Would you like to update qBittorrent to version %1?</source>
        <translation type="obsolete">Новая версия qBittorrent доступна на Sourceforge.
Хотите обновить qBittorrent до версии %1?</translation>
    </message>
    <message>
        <source>Impossible to update qBittorrent</source>
        <translation type="obsolete">Невозможно обновить qBittorrent</translation>
    </message>
    <message>
        <source>qBittorrent failed to update, reason: %1</source>
        <translation type="obsolete">qBitttorrent не может быть обновлен. Причина: %1</translation>
    </message>
</context>
<context>
    <name>GeoIP</name>
    <message>
        <source>Australia</source>
        <translation type="obsolete">Австралия</translation>
    </message>
    <message>
        <source>Argentina</source>
        <translation type="obsolete">Аргентина</translation>
    </message>
    <message>
        <source>Austria</source>
        <translation type="obsolete">Австрия</translation>
    </message>
    <message>
        <source>United Arab Emirates</source>
        <translation type="obsolete">Объединенные Арабские Эмираты</translation>
    </message>
    <message>
        <source>Brazil</source>
        <translation type="obsolete">Бразилия</translation>
    </message>
    <message>
        <source>Bulgaria</source>
        <translation type="obsolete">Болгария</translation>
    </message>
    <message>
        <source>Belarus</source>
        <translation type="obsolete">Беларусь</translation>
    </message>
    <message>
        <source>Belgium</source>
        <translation type="obsolete">Бельгия</translation>
    </message>
    <message>
        <source>Bosnia</source>
        <translation type="obsolete">Босния</translation>
    </message>
    <message>
        <source>Canada</source>
        <translation type="obsolete">Канада</translation>
    </message>
    <message>
        <source>Czech Republic</source>
        <translatorcomment>http://translate.google.com/#en|ru|Czech%20Republic</translatorcomment>
        <translation type="obsolete">Чешская Республика</translation>
    </message>
    <message>
        <source>China</source>
        <translation type="obsolete">Китай</translation>
    </message>
    <message>
        <source>Costa Rica</source>
        <translation type="obsolete">Коста Рика</translation>
    </message>
    <message>
        <source>Switzerland</source>
        <translation type="obsolete">Швейцария</translation>
    </message>
    <message>
        <source>Germany</source>
        <translation type="obsolete">Германия</translation>
    </message>
    <message>
        <source>Denmark</source>
        <translatorcomment>http://translate.google.com/#en|ru|Denmark</translatorcomment>
        <translation type="obsolete">Дания</translation>
    </message>
    <message>
        <source>Algeria</source>
        <translatorcomment>http://translate.google.com/#en|ru|Algeria</translatorcomment>
        <translation type="obsolete">Алжир</translation>
    </message>
    <message>
        <source>Spain</source>
        <translation type="obsolete">Испания</translation>
    </message>
    <message>
        <source>Egypt</source>
        <translation type="obsolete">Египет</translation>
    </message>
    <message>
        <source>Finland</source>
        <translation type="obsolete">Финляндия</translation>
    </message>
    <message>
        <source>France</source>
        <translation type="obsolete">Франция</translation>
    </message>
    <message>
        <source>United Kingdom</source>
        <translatorcomment>http://translate.google.com/#en|ru|United%20Kingdom</translatorcomment>
        <translation type="obsolete">Великобритания</translation>
    </message>
    <message>
        <source>Greece</source>
        <translation type="obsolete">Греция</translation>
    </message>
    <message>
        <source>Georgia</source>
        <translation type="obsolete">Грузия</translation>
    </message>
    <message>
        <source>Hungary</source>
        <translation type="obsolete">Венгрия</translation>
    </message>
    <message>
        <source>Croatia</source>
        <translatorcomment>http://translate.google.com/#en|ru|Croatia</translatorcomment>
        <translation type="obsolete">Хорватия</translation>
    </message>
    <message>
        <source>Italy</source>
        <translation type="obsolete">Италия</translation>
    </message>
    <message>
        <source>India</source>
        <translation type="obsolete">Индия</translation>
    </message>
    <message>
        <source>Israel</source>
        <translation type="obsolete">Израиль</translation>
    </message>
    <message>
        <source>Ireland</source>
        <translation type="obsolete">Ирландия</translation>
    </message>
    <message>
        <source>Iceland</source>
        <translation type="obsolete">Исландия</translation>
    </message>
    <message>
        <source>Indonesia</source>
        <translation type="obsolete">Индонезия</translation>
    </message>
    <message>
        <source>Japan</source>
        <translatorcomment>^_^</translatorcomment>
        <translation type="obsolete">Япония</translation>
    </message>
    <message>
        <source>South Korea</source>
        <translation type="obsolete">Южная Корея</translation>
    </message>
    <message>
        <source>Luxembourg</source>
        <translatorcomment>http://translate.google.com/#en|ru|Luxembourg</translatorcomment>
        <translation type="obsolete">Люксембург</translation>
    </message>
    <message>
        <source>Malaysia</source>
        <translation type="obsolete">Малазия</translation>
    </message>
    <message>
        <source>Mexico</source>
        <translatorcomment>http://translate.google.com/#en|ru|Mexico</translatorcomment>
        <translation type="obsolete">Мексика</translation>
    </message>
    <message>
        <source>Serbia</source>
        <translation type="obsolete">Сербия</translation>
    </message>
    <message>
        <source>Morocco</source>
        <translatorcomment>http://translate.google.com/#en|ru|Morocco</translatorcomment>
        <translation type="obsolete">Марокко</translation>
    </message>
    <message>
        <source>Netherlands</source>
        <translation type="obsolete">Нидерланды</translation>
    </message>
    <message>
        <source>Norway</source>
        <translation type="obsolete">Норвегия</translation>
    </message>
    <message>
        <source>New Zealand</source>
        <translation type="obsolete">Новая Зеландия</translation>
    </message>
    <message>
        <source>Portugal</source>
        <translation type="obsolete">Португалия</translation>
    </message>
    <message>
        <source>Poland</source>
        <translation type="obsolete">Польша</translation>
    </message>
    <message>
        <source>Pakistan</source>
        <translation type="obsolete">Пакистан</translation>
    </message>
    <message>
        <source>Philippines</source>
        <translation type="obsolete">Филиппины</translation>
    </message>
    <message>
        <source>Russia</source>
        <translation type="obsolete">Россия</translation>
    </message>
    <message>
        <source>Romania</source>
        <translatorcomment>http://translate.google.com/#en|ru|Romania</translatorcomment>
        <translation type="obsolete">Румыния</translation>
    </message>
    <message>
        <source>France (Reunion Island)</source>
        <translatorcomment>http://translate.google.com/#en|ru|France%20%28Reunion%20Island%29</translatorcomment>
        <translation type="obsolete">Франция (остров Реюньон)</translation>
    </message>
    <message>
        <source>Sweden</source>
        <translation type="obsolete">Швеция</translation>
    </message>
    <message>
        <source>Slovakia</source>
        <translation type="obsolete">Словакия</translation>
    </message>
    <message>
        <source>Singapore</source>
        <translation type="obsolete">Сингапур</translation>
    </message>
    <message>
        <source>Slovenia</source>
        <translation type="obsolete">Словения</translation>
    </message>
    <message>
        <source>Taiwan</source>
        <translation type="obsolete">Тайвань</translation>
    </message>
    <message>
        <source>Turkey</source>
        <translation type="obsolete">Турция</translation>
    </message>
    <message>
        <source>Thailand</source>
        <translation type="obsolete">Таиланд</translation>
    </message>
    <message>
        <source>USA</source>
        <translatorcomment>http://translate.google.com/#en|ru|USA</translatorcomment>
        <translation type="obsolete">США</translation>
    </message>
    <message>
        <source>Ukraine</source>
        <translation type="obsolete">Украина</translation>
    </message>
    <message>
        <source>South Africa</source>
        <translation type="obsolete">Южная Африка</translation>
    </message>
    <message>
        <source>Saudi Arabia</source>
        <translation type="obsolete">Саудовская Аравия</translation>
    </message>
</context>
<context>
    <name>HeadlessLoader</name>
    <message>
        <source>Information</source>
        <translation>Информация</translation>
    </message>
    <message>
        <source>To control qBittorrent, access the Web UI at http://localhost:%1</source>
        <translation>Чтобы управлять qBittorrent откройте браузер по адресу http://localhost:%1</translation>
    </message>
    <message>
        <source>The Web UI administrator user name is: %1</source>
        <translation>Администратор Web интерфейса: %1</translation>
    </message>
    <message>
        <source>The Web UI administrator password is still the default one: %1</source>
        <translation>Пароль администратора Web интерфейса все еще пароль по умолчанию: %1</translation>
    </message>
    <message>
        <source>This is a security risk, please consider changing your password from program preferences.</source>
        <translation>Риск безопасности, пожалуйста, смените ваш пароль в настройках программы.</translation>
    </message>
</context>
<context>
    <name>HttpConnection</name>
    <message>
        <source>Your IP address has been banned after too many failed authentication attempts.</source>
        <translation>Ваш IP адрес был заблокирован после слишком многих недачных попыток аутентификации.</translation>
    </message>
    <message>
        <source>D: %1/s - T: %2</source>
        <comment>Download speed: x KiB/s - Transferred: x MiB</comment>
        <translation>Скач: %1/с - Перед: %2</translation>
    </message>
    <message>
        <source>U: %1/s - T: %2</source>
        <comment>Upload speed: x KiB/s - Transferred: x MiB</comment>
        <translation>Отдача: %1/с - Перед: %2</translation>
    </message>
</context>
<context>
    <name>HttpServer</name>
    <message>
        <source>File</source>
        <translation>Файл</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Изменить</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Помощь</translation>
    </message>
    <message>
        <source>Delete from HD</source>
        <translation type="obsolete">Удалить с жесткого диска</translation>
    </message>
    <message>
        <source>Download Torrents from their URL or Magnet link</source>
        <translation>Скачативать торренты с их URL и Magnet ссылок</translation>
    </message>
    <message>
        <source>Only one link per line</source>
        <translation>Толко одна ссылка в строке</translation>
    </message>
    <message>
        <source>Download</source>
        <translation>Скачать</translation>
    </message>
    <message>
        <source>Download local torrent</source>
        <translation>Скачать локальный торрент</translation>
    </message>
    <message>
        <source>Torrent files were correctly added to download list.</source>
        <translation>Торренты были добавлены в список скачивания.</translation>
    </message>
    <message>
        <source>Point to torrent file</source>
        <translation>Укажите торрент файл</translation>
    </message>
    <message>
        <source>Are you sure you want to delete the selected torrents from the transfer list and hard disk?</source>
        <translation>Вы уверены что хотите удалить выделенные торренты из списка и с жесткого диска?</translation>
    </message>
    <message>
        <source>Download rate limit must be greater than 0 or disabled.</source>
        <translation>Ограничение соотношения скачивания должно быть больше 0 или отключено.</translation>
    </message>
    <message>
        <source>Upload rate limit must be greater than 0 or disabled.</source>
        <translation>Ограничение соотношения раздачи должно быть больше 0 или отключено.</translation>
    </message>
    <message>
        <source>Maximum number of connections limit must be greater than 0 or disabled.</source>
        <translation>Максимальное число соединений должно быть больше 0 или отключено.</translation>
    </message>
    <message>
        <source>Maximum number of connections per torrent limit must be greater than 0 or disabled.</source>
        <translation>Максимальное число соединений на торрент должно быть больше 0 или отключено.</translation>
    </message>
    <message>
        <source>Maximum number of upload slots per torrent limit must be greater than 0 or disabled.</source>
        <translation>Максимальное число слотов раздачи на торрент должно быть больше 0 или отключено.</translation>
    </message>
    <message>
        <source>Unable to save program preferences, qBittorrent is probably unreachable.</source>
        <translation>Не возможно сохранить настройки, qBittorrent возможно недоступен.</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Язык</translation>
    </message>
    <message>
        <source>The port used for incoming connections must be greater than 1024 and less than 65535.</source>
        <translation>Порт для входящих соединений должен быть больше чем 1024 и меньше 65535.</translation>
    </message>
    <message>
        <source>The port used for the Web UI must be greater than 1024 and less than 65535.</source>
        <translation>Порт для Web интерфейса должен быть больше 1024 и меньше 65535.</translation>
    </message>
    <message>
        <source>The Web UI username must be at least 3 characters long.</source>
        <translation>Имя пользователя Web интерфейса должно быть длинее 3 символов.</translation>
    </message>
    <message>
        <source>The Web UI password must be at least 3 characters long.</source>
        <translation>Пароль Web интерфейса должен быть длинее 3 символов.</translation>
    </message>
    <message>
        <source>Downloaded</source>
        <comment>Is the file downloaded or not?</comment>
        <translation>Скачано</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Сохранить</translation>
    </message>
    <message>
        <source>qBittorrent client is not reachable</source>
        <translation>клиент qBittorrent недоступен</translation>
    </message>
    <message>
        <source>HTTP Server</source>
        <translation>HTTP сервер</translation>
    </message>
    <message>
        <source>Torrent path</source>
        <translation>Путь торрента</translation>
    </message>
    <message>
        <source>Torrent name</source>
        <translation>Имя торрента</translation>
    </message>
    <message>
        <source>The following parameters are supported:</source>
        <translation>Поддерживаются следующие параметры:</translation>
    </message>
</context>
<context>
    <name>LegalNotice</name>
    <message>
        <source>Legal Notice</source>
        <translation>Официальное уведомление</translation>
    </message>
    <message>
        <source>Legal notice</source>
        <translation>Официальное уведомление</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <source>I Agree</source>
        <translation>Я согласен</translation>
    </message>
    <message>
        <source>qBittorrent is a file sharing program. When you run a torrent, its data will be made available to others by means of upload. Any content you share is your sole responsibility.

No further notices will be issued.</source>
        <translation>qBittorrent - программа для обмена файлами. Когда вы запускаете торрент, данные становятся доступными другим участникам обмена для отдачи. Конечно, любые данные которые вы отдаете на обмен только ваша ответственность.

Больше это уведомление не будет показано.</translation>
    </message>
    <message>
        <source>Press %1 key to accept and continue...</source>
        <translation>Нажмите %1 чтобы принять и продолжить...</translation>
    </message>
</context>
<context>
    <name>LineEdit</name>
    <message>
        <source>Clear the text</source>
        <translation>Очистить текст</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>&amp;Edit</source>
        <translation>&amp;Изменить</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Файл</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Помощь</translation>
    </message>
    <message>
        <source>Preview file</source>
        <translatorcomment>Имхо правильнее чем файл предпросмотра</translatorcomment>
        <translation type="obsolete">Предпросмотр файла</translation>
    </message>
    <message>
        <source>Clear log</source>
        <translation type="obsolete">Очистить лог</translation>
    </message>
    <message>
        <source>Decrease priority</source>
        <translation>Понизить приоритет</translation>
    </message>
    <message>
        <source>Increase priority</source>
        <translation>Повысить приоритет</translation>
    </message>
    <message>
        <source>&amp;Tools</source>
        <translation>Инс&amp;трументы</translation>
    </message>
    <message>
        <source>&amp;View</source>
        <translation>&amp;Вид</translation>
    </message>
    <message>
        <source>&amp;Add File...</source>
        <translation type="obsolete">&amp;Добавить файл...</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation type="obsolete">В&amp;ыход</translation>
    </message>
    <message>
        <source>&amp;Options...</source>
        <translation>&amp;Настройки...</translation>
    </message>
    <message>
        <source>Add &amp;URL...</source>
        <translation type="obsolete">Добавить &amp;URL...</translation>
    </message>
    <message>
        <source>Torrent &amp;creator</source>
        <translatorcomment>Создатель такой создатель... Но ничего лучше придумать не могу, в голову приходят только &apos;создавалка&apos; и &apos;создавайка&apos; (создавайка мне торрент! ^_^)</translatorcomment>
        <translation>Мастер &amp;создания Torrent-а</translation>
    </message>
    <message>
        <source>Set upload limit...</source>
        <translation>Установить ограничение раздачи...</translation>
    </message>
    <message>
        <source>Set download limit...</source>
        <translatorcomment>Исходя из следущего</translatorcomment>
        <translation>Установить ограничение закачки...</translation>
    </message>
    <message>
        <source>Set global download limit...</source>
        <translation>Установить глобальное ограничение закачки...</translation>
    </message>
    <message>
        <source>Set global upload limit...</source>
        <translation>Установить глобальное ограничение раздачи...</translation>
    </message>
    <message>
        <source>&amp;Log viewer...</source>
        <translation type="obsolete">&amp;Просмотрщик лога...</translation>
    </message>
    <message>
        <source>Top &amp;tool bar</source>
        <translatorcomment>Ну не понятно лично мне что это за панель... А тулбар - с детства знакомо.</translatorcomment>
        <translation>Панель &amp;инструментов</translation>
    </message>
    <message>
        <source>Display top tool bar</source>
        <translation>Показать верхнюю панель</translation>
    </message>
    <message>
        <source>&amp;Speed in title bar</source>
        <translation>&amp;Скорость в заголовке</translation>
    </message>
    <message>
        <source>Show transfer speed in title bar</source>
        <translatorcomment>Имхо &apos;заголовок окна&apos; понятнее чем &apos;полоса заголовка&apos;. Хотя она ещё и в кнопке на панели задач отображается...</translatorcomment>
        <translation>Отображать текущую скорость в заголовке окна</translation>
    </message>
    <message>
        <source>Alternative speed limits</source>
        <translation>Альтернативные лимиты скорости</translation>
    </message>
    <message>
        <source>&amp;About</source>
        <translatorcomment>Посмотрел в Firefox - там не обезличенное &apos;О программе&apos; а более тёплое &apos;О Mozilla Firefox&apos;. Или может лучше как в Kate - &apos;О программе Kate&apos;?</translatorcomment>
        <translation>&amp;О qBittorrent</translation>
    </message>
    <message>
        <source>&amp;Pause</source>
        <translation>&amp;Приостановить</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>&amp;Удалить</translation>
    </message>
    <message>
        <source>P&amp;ause All</source>
        <translation>П&amp;риостановить Все</translation>
    </message>
    <message>
        <source>Visit &amp;Website</source>
        <translation>Посетить &amp;веб-сайт</translation>
    </message>
    <message>
        <source>Report a &amp;bug</source>
        <translation>Сообщить о&amp;б ошибке</translation>
    </message>
    <message>
        <source>&amp;Documentation</source>
        <translation>&amp;Документация</translation>
    </message>
    <message>
        <source>&amp;RSS reader</source>
        <translatorcomment>Корявенько... Но имхо &apos;просмотрщик&apos; - это viewer // читалка как-то криво тоже. но лучше не придумал пока</translatorcomment>
        <translation>&amp;RSS читалка</translation>
    </message>
    <message>
        <source>Search &amp;engine</source>
        <translatorcomment>Исходя из следущего (хотя я лично целиком и полностью за &apos;Поисковый движок&apos;)</translatorcomment>
        <translation>По&amp;исковик</translation>
    </message>
    <message>
        <source>Log viewer</source>
        <translation type="obsolete">Просмотрщик лога</translation>
    </message>
    <message>
        <source>Lock qBittorrent</source>
        <translation>Заблокировать qBittorrent</translation>
    </message>
    <message>
        <source>Ctrl+L</source>
        <translation></translation>
    </message>
    <message>
        <source>Shutdown computer when downloads complete</source>
        <translation type="obsolete">Выключить компьютер когда закачки будут завершены</translation>
    </message>
    <message>
        <source>&amp;Resume</source>
        <translation>&amp;Возобновить</translation>
    </message>
    <message>
        <source>R&amp;esume All</source>
        <translation>Воз&amp;обновить все</translation>
    </message>
    <message>
        <source>Shutdown qBittorrent when downloads complete</source>
        <translation type="obsolete">Выключить qBittorrent когда загрузки будут завершены</translation>
    </message>
    <message>
        <source>Exit</source>
        <translation>Выход</translation>
    </message>
    <message>
        <source>Import torrent...</source>
        <translation>Импортировать торрент...</translation>
    </message>
    <message>
        <source>Donate money</source>
        <translatorcomment>so silly</translatorcomment>
        <translation>Пожертвовать деньги</translation>
    </message>
    <message>
        <source>If you like qBittorrent, please donate!</source>
        <translation>Если вам нравится qBittorrent, пожалуйста - пожертвуйте!</translation>
    </message>
    <message>
        <source>qBittorrent %1</source>
        <comment>e.g: qBittorrent v0.x</comment>
        <translation>qBittorrent %1</translation>
    </message>
    <message>
        <source>Set the password...</source>
        <translation>Установить пароль...</translation>
    </message>
    <message>
        <source>Transfers</source>
        <translation>Передачи</translation>
    </message>
    <message>
        <source>Torrent file association</source>
        <translation>Привязки торрент-файлов</translation>
    </message>
    <message>
        <source>qBittorrent is not the default application to open torrent files or Magnet links.
Do you want to associate qBittorrent to torrent files and Magnet links?</source>
        <translation>qBittorrent сейчас не является приложением по умолчанию для открытия торрент-файлов или Magnet-ссылок.
Хотите ли вы открывать торрент-файлы и Magnet-ссылки с помощью qBittorrent?</translation>
    </message>
    <message>
        <source>UI lock password</source>
        <translation>Пароль блокировки интерфейса</translation>
    </message>
    <message>
        <source>Please type the UI lock password:</source>
        <translation>Пожалуйста, введите пароль блокировки интерфейса:</translation>
    </message>
    <message>
        <source>Password update</source>
        <translation>Обновить пароль</translation>
    </message>
    <message>
        <source>The UI lock password has been successfully updated</source>
        <translation>Пароль блокировки интерфейса был успешно обновлен</translation>
    </message>
    <message>
        <source>RSS</source>
        <translation>RSS</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Поиск</translation>
    </message>
    <message>
        <source>Transfers (%1)</source>
        <translation>Передачи (%1)</translation>
    </message>
    <message>
        <source>Download completion</source>
        <translation>Завершение загрузок</translation>
    </message>
    <message>
        <source>%1 has finished downloading.</source>
        <comment>e.g: xxx.avi has finished downloading.</comment>
        <translation>скачивание %1 завершено.</translation>
    </message>
    <message>
        <source>I/O Error</source>
        <comment>i.e: Input/Output Error</comment>
        <translation>Ошибка ввода/вывода</translation>
    </message>
    <message>
        <source>An I/O error occured for torrent %1.
 Reason: %2</source>
        <comment>e.g: An error occured for torrent xxx.avi.
 Reason: disk is full.</comment>
        <translation>Произошла ошибка ввода/вывода для торрента %1.
Причина: %2</translation>
    </message>
    <message>
        <source>Alt+1</source>
        <comment>shortcut to switch to first tab</comment>
        <translation>Alt+1</translation>
    </message>
    <message>
        <source>Alt+2</source>
        <comment>shortcut to switch to third tab</comment>
        <translation>Alt+2</translation>
    </message>
    <message>
        <source>Ctrl+F</source>
        <comment>shortcut to switch to search tab</comment>
        <translation>Ctrl+F</translation>
    </message>
    <message>
        <source>Alt+3</source>
        <comment>shortcut to switch to fourth tab</comment>
        <translation>Alt+3</translation>
    </message>
    <message>
        <source>Recursive download confirmation</source>
        <translation>Подтверждение рекурсивной загрузки</translation>
    </message>
    <message>
        <source>The torrent %1 contains torrent files, do you want to proceed with their download?</source>
        <translation>Торрент %1 содержит торрент-файлы, хотите ли вы приступить к их загрузке?</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Да</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Нет</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Никогда</translation>
    </message>
    <message>
        <source>Url download error</source>
        <translation>Ошибка при скачивании URL</translation>
    </message>
    <message>
        <source>Couldn&apos;t download file at url: %1, reason: %2.</source>
        <translation>Невозможно скачать файл по URL: %1, причина: %2.</translation>
    </message>
    <message>
        <source>Global Upload Speed Limit</source>
        <translation>Глобальное ограничение скорости раздачи</translation>
    </message>
    <message>
        <source>Global Download Speed Limit</source>
        <translation>Глобальное ограничение скорости закачки</translation>
    </message>
    <message>
        <source>Invalid password</source>
        <translation>Неверный пароль</translation>
    </message>
    <message>
        <source>The password is invalid</source>
        <translation>Этот пароль не верен</translation>
    </message>
    <message>
        <source>Exiting qBittorrent</source>
        <translation>Завершение работы qBittorrent</translation>
    </message>
    <message>
        <source>Some files are currently transferring.
Are you sure you want to quit qBittorrent?</source>
        <translation>Есть активные торренты. Вы уверены что хотите выйти из qBittorrent?</translation>
    </message>
    <message>
        <source>Always</source>
        <translation>Всегда</translation>
    </message>
    <message>
        <source>Open Torrent Files</source>
        <translation>Открыть файлы Torrent</translation>
    </message>
    <message>
        <source>Torrent Files</source>
        <translation>Файлы Torrent</translation>
    </message>
    <message>
        <source>Options were saved successfully.</source>
        <translation>Настройки были успешно сохранены.</translation>
    </message>
    <message>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <source>DL speed: %1 KiB/s</source>
        <comment>e.g: Download speed: 10 KiB/s</comment>
        <translation>Скач.: %1 КиБ/с</translation>
    </message>
    <message>
        <source>UP speed: %1 KiB/s</source>
        <comment>e.g: Upload speed: 10 KiB/s</comment>
        <translation>Отдача.: %1 КиБ/с</translation>
    </message>
    <message>
        <source>qBittorrent %1 (Down: %2/s, Up: %3/s)</source>
        <comment>%1 is qBittorrent version</comment>
        <translation>qBittorrent %1 (Скач: %2/с, Отд: %3/с)</translation>
    </message>
    <message>
        <source>A newer version is available</source>
        <translation>Доступна новая версия</translation>
    </message>
    <message>
        <source>A newer version of qBittorrent is available on Sourceforge.
Would you like to update qBittorrent to version %1?</source>
        <translation>Новая версия qBittorrent доступна на Sourceforge.
Хотите обновить qBittorrent до версии %1?</translation>
    </message>
    <message>
        <source>Impossible to update qBittorrent</source>
        <translation>Невозможно обновить qBittorrent</translation>
    </message>
    <message>
        <source>qBittorrent failed to update, reason: %1</source>
        <translation>qBitttorrent не может быть обновлен. Причина: %1</translation>
    </message>
    <message>
        <source>&amp;Add torrent file...</source>
        <translation>&amp;Добавить торрент файл...</translation>
    </message>
    <message>
        <source>Add &amp;link to torrent...</source>
        <translation>Добавит &amp;ссылку к торренту...</translation>
    </message>
    <message>
        <source>Import existing torrent...</source>
        <translation>Импортировать существующий торрент...</translation>
    </message>
    <message>
        <source>Execution &amp;Log</source>
        <translation>&amp;Лог выполнения</translation>
    </message>
    <message>
        <source>Execution Log</source>
        <translation>Лог выполнения</translation>
    </message>
    <message>
        <source>Auto-Shutdown on downloads completion</source>
        <translation>Выключение по завершении загрузок</translation>
    </message>
    <message>
        <source>Exit qBittorrent</source>
        <translation>Выйти из qBittorrent</translation>
    </message>
    <message>
        <source>Suspend system</source>
        <translation>Перейти в спящий режим</translation>
    </message>
    <message>
        <source>Shutdown system</source>
        <translation>Выключить компьютер</translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Выключено</translation>
    </message>
    <message>
        <source>The password should contain at least 3 characters</source>
        <translation>Пароль должен содержать минимум 3 символа</translation>
    </message>
</context>
<context>
    <name>PeerAdditionDlg</name>
    <message>
        <source>Invalid IP</source>
        <translation>Неверный IP</translation>
    </message>
    <message>
        <source>The IP you provided is invalid.</source>
        <translation>IP который вы указали неправилен.</translation>
    </message>
</context>
<context>
    <name>PeerListDelegate</name>
    <message>
        <source>/s</source>
        <comment>/second (i.e. per second)</comment>
        <translation>/с</translation>
    </message>
</context>
<context>
    <name>PeerListWidget</name>
    <message>
        <source>IP</source>
        <translation>IP</translation>
    </message>
    <message>
        <source>Client</source>
        <comment>i.e.: Client application</comment>
        <translation>Клиент</translation>
    </message>
    <message>
        <source>Progress</source>
        <comment>i.e: % downloaded</comment>
        <translation>Прогресс</translation>
    </message>
    <message>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Скорость скачивания</translation>
    </message>
    <message>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Скорость отдачи</translation>
    </message>
    <message>
        <source>Downloaded</source>
        <comment>i.e: total data downloaded</comment>
        <translation>Скачано</translation>
    </message>
    <message>
        <source>Uploaded</source>
        <comment>i.e: total data uploaded</comment>
        <translation>Отдано</translation>
    </message>
    <message>
        <source>Ban peer permanently</source>
        <translation>Заблокировать пир навсегда</translation>
    </message>
    <message>
        <source>Peer addition</source>
        <translation>Добавление пира</translation>
    </message>
    <message>
        <source>The peer was added to this torrent.</source>
        <translation>Пир был добавлен к этому torrent.</translation>
    </message>
    <message>
        <source>The peer could not be added to this torrent.</source>
        <translation>Пир не может быть добавлен к этому torrent.</translation>
    </message>
    <message>
        <source>Are you sure? -- qBittorrent</source>
        <translation>Вы уверены? -- qBittorrent</translation>
    </message>
    <message>
        <source>Are you sure you want to ban permanently the selected peers?</source>
        <translation>Вы уверены что хотите навсегда заблокировать выделенные пиры?</translation>
    </message>
    <message>
        <source>&amp;Yes</source>
        <translation>&amp;Да</translation>
    </message>
    <message>
        <source>&amp;No</source>
        <translation>&amp;Нет</translation>
    </message>
    <message>
        <source>Manually banning peer %1...</source>
        <translation>Заблокировать пир %1 вручную...</translation>
    </message>
    <message>
        <source>Upload rate limiting</source>
        <translation>Ограничение соотношения отдачи</translation>
    </message>
    <message>
        <source>Download rate limiting</source>
        <translation>Ограничение соотношения скачивания</translation>
    </message>
    <message>
        <source>Add a new peer...</source>
        <translatorcomment>Исходя из предыдущего. Хотя мне больше нравится &apos;Добавить пира&apos;, пиры - они ведь живые...</translatorcomment>
        <translation>Добавить новый пир...</translation>
    </message>
    <message>
        <source>Limit download rate...</source>
        <translatorcomment>Хоть в предыдущем и &apos;сотношение скачивания&apos;, но мимо _этого_ я пройти просто не могу! Ratio - соотношение, Rate - скорость!</translatorcomment>
        <translation>Ограничение скорости скачивания...</translation>
    </message>
    <message>
        <source>Limit upload rate...</source>
        <translatorcomment>Хоть в предыдущем и &apos;сотношение раздачи&apos;, но мимо _этого_ я пройти просто не могу! Ratio - соотношение, Rate - скорость!</translatorcomment>
        <translation>Ограничение скорости раздачи...</translation>
    </message>
    <message>
        <source>Copy IP</source>
        <translation>Копировать IP</translation>
    </message>
    <message>
        <source>Connection</source>
        <translation>Соединение</translation>
    </message>
</context>
<context>
    <name>Preferences</name>
    <message>
        <source>UI</source>
        <extracomment>User Interface</extracomment>
        <translation type="obsolete">Интерфейс</translation>
    </message>
    <message>
        <source>Downloads</source>
        <translatorcomment>Имхо &apos;закачка&apos; - это upload</translatorcomment>
        <translation>Загрузки</translation>
    </message>
    <message>
        <source>Connection</source>
        <translation>Соединение</translation>
    </message>
    <message>
        <source>Bittorrent</source>
        <translation type="obsolete">Bittorrent</translation>
    </message>
    <message>
        <source>Proxy</source>
        <translation type="obsolete">Прокси</translation>
    </message>
    <message>
        <source>Web UI</source>
        <translation>Web интерфейс</translation>
    </message>
    <message>
        <source>Language:</source>
        <translation type="obsolete">Язык:</translation>
    </message>
    <message>
        <source>(Requires restart)</source>
        <translation>(Требует перезагрузки)</translation>
    </message>
    <message>
        <source>Visual style:</source>
        <translation type="obsolete">Визуальный стиль:</translation>
    </message>
    <message>
        <source>Transfer list</source>
        <translation type="obsolete">Список передач</translation>
    </message>
    <message>
        <source>Use alternating row colors</source>
        <extracomment>In transfer list, one every two rows will have grey background.</extracomment>
        <translation>Использовать альтернативные цвета строк</translation>
    </message>
    <message>
        <source>File system</source>
        <translation type="obsolete">Файловая система</translation>
    </message>
    <message>
        <source>Torrent queueing</source>
        <translation type="obsolete">Очереди Torrent</translation>
    </message>
    <message>
        <source>Maximum active downloads:</source>
        <translation>Максимальное число активных закачек:</translation>
    </message>
    <message>
        <source>Maximum active uploads:</source>
        <translation>Максимальное число активных раздач:</translation>
    </message>
    <message>
        <source>Maximum active torrents:</source>
        <translation>Максимальное число активных torrent:</translation>
    </message>
    <message>
        <source>When adding a torrent</source>
        <translation>При добавлении торента</translation>
    </message>
    <message>
        <source>Display torrent content and some options</source>
        <translation>Отображать содержимое torrentа и некоторые настройки</translation>
    </message>
    <message>
        <source>Listening port</source>
        <translation type="obsolete">Прослушивание порта</translation>
    </message>
    <message>
        <source>Port used for incoming connections:</source>
        <translation>Порт, используемый для входящих соединений:</translation>
    </message>
    <message>
        <source>Random</source>
        <translation>Случайно</translation>
    </message>
    <message>
        <source>Enable UPnP port mapping</source>
        <translation type="obsolete">Включить распределение портов UPnP</translation>
    </message>
    <message>
        <source>Enable NAT-PMP port mapping</source>
        <translation type="obsolete">Включить распределение портов NAT-PMP</translation>
    </message>
    <message>
        <source>Connections limit</source>
        <translation type="obsolete">Ограничение соединений</translation>
    </message>
    <message>
        <source>Global maximum number of connections:</source>
        <translation>Общее ограничение на число соединений:</translation>
    </message>
    <message>
        <source>Maximum number of connections per torrent:</source>
        <translation>Максимальное число соединений на torrent:</translation>
    </message>
    <message>
        <source>Maximum number of upload slots per torrent:</source>
        <translation>Максимальное количество слотов отдачи на torrent:</translation>
    </message>
    <message>
        <source>Upload:</source>
        <translation>Отдача:</translation>
    </message>
    <message>
        <source>Download:</source>
        <translation>Загрузка:</translation>
    </message>
    <message>
        <source>KiB/s</source>
        <translation>КиБ/с</translation>
    </message>
    <message>
        <source>Bittorrent features</source>
        <translation type="obsolete">Возможности Bittorrent</translation>
    </message>
    <message>
        <source>Enable DHT network (decentralized)</source>
        <translation type="obsolete">Включить DHT сеть (децентрализованную)</translation>
    </message>
    <message>
        <source>Use a different port for DHT and Bittorrent</source>
        <translation type="obsolete">Использовать разные порты для DHT и Bittorrent</translation>
    </message>
    <message>
        <source>DHT port:</source>
        <translation>Порт DHT:</translation>
    </message>
    <message>
        <source>Enable Peer Exchange / PeX (requires restart)</source>
        <translation type="obsolete">Включить Обмен пирами / (PeX) (требует перезагрузки)</translation>
    </message>
    <message>
        <source>Enable Local Peer Discovery</source>
        <translation type="obsolete">Включить обнаружение локальных пиров</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation type="obsolete">Включено</translation>
    </message>
    <message>
        <source>Forced</source>
        <translation type="obsolete">Принудительно</translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation type="obsolete">Выключено</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation>Тип:</translation>
    </message>
    <message>
        <source>(None)</source>
        <translation>(нет)</translation>
    </message>
    <message>
        <source>HTTP</source>
        <translation>HTTP</translation>
    </message>
    <message>
        <source>Port:</source>
        <translation>Порт:</translation>
    </message>
    <message>
        <source>Authentication</source>
        <translation>Аутентификация</translation>
    </message>
    <message>
        <source>Username:</source>
        <translation>Имя пользователя:</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation>Пароль:</translation>
    </message>
    <message>
        <source>SOCKS5</source>
        <translation>Сервер SOCKS5</translation>
    </message>
    <message>
        <source>HTTP Server</source>
        <translation type="obsolete">HTTP сервер</translation>
    </message>
    <message>
        <source>Filter path (.dat, .p2p, .p2b):</source>
        <translation>Путь к фильтрам (.dat, .p2p, .p2b):</translation>
    </message>
    <message>
        <source>HTTP Communications (trackers, Web seeds, search engine)</source>
        <translatorcomment>Ну не звучит тут &apos;Связи&apos;. Никак не звучит.</translatorcomment>
        <translation type="obsolete">HTTP соединения (трекеры, раздающие Web, поисковые движки)</translation>
    </message>
    <message>
        <source>Host:</source>
        <translation>Хост:</translation>
    </message>
    <message>
        <source>Peer Communications</source>
        <translation type="obsolete">Связи с пирами</translation>
    </message>
    <message>
        <source>SOCKS4</source>
        <translation>Сервер SOCKS4</translation>
    </message>
    <message>
        <source>Speed</source>
        <translation>Скорость</translation>
    </message>
    <message>
        <source>Global speed limits</source>
        <translation type="obsolete">Глобальные лимиты скорости</translation>
    </message>
    <message>
        <source>Alternative global speed limits</source>
        <translation type="obsolete">Альтернативные лимиты скорости</translation>
    </message>
    <message>
        <source>to</source>
        <extracomment>time1 to time2</extracomment>
        <translation>до</translation>
    </message>
    <message>
        <source>Every day</source>
        <translation>Каждый день</translation>
    </message>
    <message>
        <source>Week days</source>
        <translation>Каждый будний день</translation>
    </message>
    <message>
        <source>Week ends</source>
        <translation>Каждый выходной</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translatorcomment>Никак не звучит тут &apos;расширенные&apos;...</translatorcomment>
        <translation>Продвинутые</translation>
    </message>
    <message>
        <source>Copy .torrent files to:</source>
        <translation>Скопировать торрент файл в:</translation>
    </message>
    <message>
        <source>Remove folder</source>
        <translation>Удалить папку</translation>
    </message>
    <message>
        <source>No action</source>
        <translation>Нет действия</translation>
    </message>
    <message>
        <source>Options</source>
        <translatorcomment>Как в Firefox</translatorcomment>
        <translation>Настройки</translation>
    </message>
    <message>
        <source>Visual Appearance</source>
        <translation type="obsolete">Визуальное Поведение</translation>
    </message>
    <message>
        <source>Action on double-click</source>
        <translation>Действие по двойному щелчку</translation>
    </message>
    <message>
        <source>Downloading torrents:</source>
        <translatorcomment>Или они &apos;Загружающиеся&apos;? Или (как в предыдущем) &apos;Скачиваемые&apos;? // думаю стоит привести download upload к загрузки раздачи а скачивание к самим торентфайликам</translatorcomment>
        <translation>Загружаемые торренты:</translation>
    </message>
    <message>
        <source>Start / Stop</source>
        <translation type="obsolete">Начать/Остановить</translation>
    </message>
    <message>
        <source>Open destination folder</source>
        <translation>Открыть папку назначения</translation>
    </message>
    <message>
        <source>Completed torrents:</source>
        <translation>Завершенные торренты:</translation>
    </message>
    <message>
        <source>Desktop</source>
        <translatorcomment>Где? o_O  // у тех кто с венды пришел и без него жить не могут :D</translatorcomment>
        <translation>Рабочий стол</translation>
    </message>
    <message>
        <source>Show splash screen on start up</source>
        <translation>Показать заставку при загрузке</translation>
    </message>
    <message>
        <source>Start qBittorrent minimized</source>
        <translation>Запускать qBittorrent свернутым</translation>
    </message>
    <message>
        <source>Show qBittorrent icon in notification area</source>
        <translatorcomment>А может лучше &apos;в трее&apos;?</translatorcomment>
        <translation type="obsolete">Показывать значок qBittorrent в области уведомлений</translation>
    </message>
    <message>
        <source>Minimize qBittorrent to notification area</source>
        <translatorcomment>А может лучше &apos;в трей&apos;? // не думаю, в том же KDE это именно уведомлений. А трей суть калька</translatorcomment>
        <translation>Сворачивать qBittorrent в область уведомлений</translation>
    </message>
    <message>
        <source>Close qBittorrent to notification area</source>
        <comment>i.e: The systray tray icon will still be visible when closing the main window.</comment>
        <translatorcomment>Коряво, коряво...</translatorcomment>
        <translation>Закрывать qBittorrent в облать уведомлений</translation>
    </message>
    <message>
        <source>Do not start the download automatically</source>
        <comment>The torrent will be added to download list in pause state</comment>
        <translation>Не начинать загрузку автоматически</translation>
    </message>
    <message>
        <source>Save files to location:</source>
        <translatorcomment>А надо ли &apos;расположение&apos;? И имхо &apos;по умолчанию&apos; здесь будет очень к месту.</translatorcomment>
        <translation>Сохранять файлы по умолчанию в:</translation>
    </message>
    <message>
        <source>Append the label of the torrent to the save path</source>
        <translation>Добавить метку торрента к пути сохранения</translation>
    </message>
    <message>
        <source>Pre-allocate disk space for all files</source>
        <translatorcomment>Или &apos;Предварительно резервировать&apos; будет правильнее?</translatorcomment>
        <translation>Предварительно зарезервировать место для всех файлов</translation>
    </message>
    <message>
        <source>Keep incomplete torrents in:</source>
        <translation>Хранить незавершенные торренты в:</translation>
    </message>
    <message>
        <source>Append .!qB extension to incomplete files&apos; names</source>
        <translation type="obsolete">Добавить расширение .!qB к незаконченым файлам</translation>
    </message>
    <message>
        <source>Automatically add torrents from:</source>
        <translation>Автоматически добавлять торренты из:</translation>
    </message>
    <message>
        <source>Add folder...</source>
        <translation>Добавить папку...</translation>
    </message>
    <message>
        <source>IP Filtering</source>
        <translation>Фильтрация по IP</translation>
    </message>
    <message>
        <source>Schedule the use of alternative speed limits</source>
        <translatorcomment>Или &apos;для использования&apos;?</translatorcomment>
        <translation type="obsolete">Расписание использования альтернативных лимитов скорости</translation>
    </message>
    <message>
        <source>from</source>
        <extracomment>from (time1 to time2)</extracomment>
        <translation>С</translation>
    </message>
    <message>
        <source>When:</source>
        <translation>Когда:</translation>
    </message>
    <message>
        <source>Look for peers on your local network</source>
        <translation>Искать пиры в вашей локальной сети</translation>
    </message>
    <message>
        <source>Protocol encryption:</source>
        <translatorcomment>Или &apos;Протокол шифрования&apos;?</translatorcomment>
        <translation type="obsolete">Шифрование протокола:</translation>
    </message>
    <message>
        <source>Enable Web User Interface (Remote control)</source>
        <translation>Включить Web интерфейс (Удалённое управление)</translation>
    </message>
    <message>
        <source>Share ratio limiting</source>
        <translation type="obsolete">Ограничение коэффициента раздачи</translation>
    </message>
    <message>
        <source>Seed torrents until their ratio reaches</source>
        <translatorcomment>Или тут лучше &apos;соотношение&apos;? Или &apos;рейтинг&apos;?</translatorcomment>
        <translation>Раздавать торренты пока их соотношение загрузка/раздача не достигнет</translation>
    </message>
    <message>
        <source>then</source>
        <translatorcomment>Имхо так красивее звучит...</translatorcomment>
        <translation>а затем</translation>
    </message>
    <message>
        <source>Pause them</source>
        <translation>Приостановить их</translation>
    </message>
    <message>
        <source>Remove them</source>
        <translation>Удалить их</translation>
    </message>
    <message utf8="true">
        <source>Exchange peers with compatible Bittorrent clients (µTorrent, Vuze, ...)</source>
        <translation>Обмен пирами с совместиыми клиентами Bittorrent (µTorrent, Vuze, ...)</translation>
    </message>
    <message>
        <source>Email notification upon download completion</source>
        <translation>Сообщать об окончании загрузки по Email</translation>
    </message>
    <message>
        <source>Destination email:</source>
        <translation>Email для сообщения:</translation>
    </message>
    <message>
        <source>SMTP server:</source>
        <translation>SMTP сервер:</translation>
    </message>
    <message>
        <source>Run an external program on torrent completion</source>
        <translation>Запустить внешнюю программу по окончании загрузки торрента</translation>
    </message>
    <message>
        <source>Use %f to pass the torrent path in parameters</source>
        <translation type="obsolete">Использовать %f для передачи пути к торренту в параметрах</translation>
    </message>
    <message>
        <source>Proxy server</source>
        <translation type="obsolete">Прокси сервер</translation>
    </message>
    <message>
        <source>BitTorrent</source>
        <translation>BitTorrent</translation>
    </message>
    <message>
        <source>Start / Stop Torrent</source>
        <translation>Запустить / Остановить Торрент</translation>
    </message>
    <message>
        <source>Use UPnP / NAT-PMP port forwarding from my router</source>
        <translation>Использовать UPnP / NAT-PMP из моего роутера</translation>
    </message>
    <message>
        <source>Privacy</source>
        <translation>Приватность</translation>
    </message>
    <message>
        <source>Enable DHT (decentralized network) to find more peers</source>
        <translation>Включить DHT сеть (децентрализованную), чтобы найти больше пиров</translation>
    </message>
    <message>
        <source>Use a different port for DHT and BitTorrent</source>
        <translation>Использовать разные порты для DHT и Bittorrent</translation>
    </message>
    <message>
        <source>Enable Peer Exchange (PeX) to find more peers</source>
        <translation>Включить Обмен пирами (PeX), чтобы найти больше пиров</translation>
    </message>
    <message>
        <source>Enable Local Peer Discovery to find more peers</source>
        <translation>Включить обнаружение локальных пиров, чтобы найти больше пиров</translation>
    </message>
    <message>
        <source>Encryption mode:</source>
        <translation>Режим шифрования:</translation>
    </message>
    <message>
        <source>Prefer encryption</source>
        <translation>Предпочитать шифрование</translation>
    </message>
    <message>
        <source>Require encryption</source>
        <translation>Требовать шифрование</translation>
    </message>
    <message>
        <source>Disable encryption</source>
        <translation>Отключить шифрование</translation>
    </message>
    <message>
        <source>User Interface</source>
        <translation type="obsolete">Пользовательский интерфейс</translation>
    </message>
    <message>
        <source>Reload the filter</source>
        <translation>Перезагрузить фильтр</translation>
    </message>
    <message>
        <source>Prevent system from suspend</source>
        <translation type="obsolete">Предотвращать переход в спящий режим</translation>
    </message>
    <message>
        <source>Behavior</source>
        <translation>Поведение</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Язык</translation>
    </message>
    <message>
        <source>Power Management</source>
        <translation>Управление питанием</translation>
    </message>
    <message>
        <source>Inhibit system sleep when torrents are active</source>
        <translation>Запретить спящий режим, когда есть активные торренты</translation>
    </message>
    <message>
        <source>Bypass authentication for localhost</source>
        <translation>Пропускать аутентификацию для localhost</translation>
    </message>
    <message>
        <source>Ask for program exit confirmation</source>
        <translation>Запрашивать подтверждение завершения программы</translation>
    </message>
    <message>
        <source>Use monochrome system tray icon (requires restart)</source>
        <translation type="obsolete">Использовать монохромную иконку в трее (требуется перезапуск)</translation>
    </message>
    <message>
        <source>The following parameters are supported:
&lt;ul&gt;
&lt;li&gt;%f: Torrent path&lt;/li&gt;
&lt;li&gt;%n: Torrent name&lt;/li&gt;
&lt;/ul&gt;</source>
        <translation>Поддерживаются следующие параметры:
&lt;ul&gt;
&lt;li&gt;%f: Путь торрента&lt;/li&gt;
&lt;li&gt;%n: Имя торрента&lt;/li&gt;
&lt;/ul&gt;</translation>
    </message>
    <message>
        <source>Tray icon style:</source>
        <translation>Стиль иконки в трее:</translation>
    </message>
    <message>
        <source>Normal</source>
        <translation>Обычная</translation>
    </message>
    <message>
        <source>Monochrome (Dark theme)</source>
        <translation>Монохромная (Тёмная тема)</translation>
    </message>
    <message>
        <source>Monochrome (Light theme)</source>
        <translation>Монохромная (Светлая тема)</translation>
    </message>
    <message>
        <source>This server requires a secure connection (SSL)</source>
        <translation>Этот сервер требует защищённое соединение (SSL)</translation>
    </message>
    <message>
        <source>User Interface Language:</source>
        <translation>Язык пользовательского интерфейса:</translation>
    </message>
    <message>
        <source>Transfer List</source>
        <translation>Список передач</translation>
    </message>
    <message>
        <source>Show qBittorrent in notification area</source>
        <translation>Показывать qBittorrent в области уведомлений</translation>
    </message>
    <message>
        <source>Hard Disk</source>
        <translation>Жёсткий диск</translation>
    </message>
    <message>
        <source>Listening Port</source>
        <translation>Прослушиваемый порт</translation>
    </message>
    <message>
        <source>Connections Limits</source>
        <translation>Ограничения соединений</translation>
    </message>
    <message>
        <source>Proxy Server</source>
        <translation>Прокси сервер</translation>
    </message>
    <message>
        <source>Global Speed Limits</source>
        <translation type="obsolete">Глобальные ограничения скорости</translation>
    </message>
    <message>
        <source>Alternative Global Speed Limits</source>
        <translation type="obsolete">Альтернативные ограничения скорости</translation>
    </message>
    <message>
        <source>Torrent Queueing</source>
        <translation>Очерёдность торрентов</translation>
    </message>
    <message>
        <source>Share Ratio Limiting</source>
        <translation>Ограничение коэффициента раздачи</translation>
    </message>
    <message>
        <source>Use UPnP / NAT-PMP to forward the port from my router</source>
        <translation>Использовать UPnP / NAT-PMP для перенаправления порта через мой маршрутизатор</translation>
    </message>
    <message>
        <source>Update my dynamic domain name</source>
        <translation>Обновлять моё динамическое доменное имя</translation>
    </message>
    <message>
        <source>Service:</source>
        <translation>Служба:</translation>
    </message>
    <message>
        <source>Register</source>
        <translation>Регистрация</translation>
    </message>
    <message>
        <source>Domain name:</source>
        <translation>Доменное имя:</translation>
    </message>
    <message>
        <source>Global Rate Limits</source>
        <translation>Глобальные ограничения скорости</translation>
    </message>
    <message>
        <source>Apply rate limit to uTP connections</source>
        <translation>Применять ограничение скорости к uTP соединениям</translation>
    </message>
    <message>
        <source>Apply rate limit to transport overhead</source>
        <translation>Применять ограничение скорости к накладным расходам передачи</translation>
    </message>
    <message>
        <source>Alternative Global Rate Limits</source>
        <translation>Альтернативные ограничения скорости</translation>
    </message>
    <message>
        <source>Schedule the use of alternative rate limits</source>
        <translation>Запланировать использование альтернативных ограничений скорости</translation>
    </message>
    <message>
        <source>Enable bandwidth management (uTP)</source>
        <translation>Включить управление полосой пропускания (uTP)</translation>
    </message>
    <message>
        <source>Otherwise, the proxy server is only used for tracker connections</source>
        <translation>Иначе прокси сервер используется только для соединения с трекерами</translation>
    </message>
    <message>
        <source>Use proxy for peer connections</source>
        <translation>Использовать прокси для соединения с пирами</translation>
    </message>
    <message>
        <source>Append .!qB extension to incomplete files</source>
        <translation>Добавить расширение .!qB к незаконченным файлам</translation>
    </message>
    <message>
        <source>Use HTTPS instead of HTTP</source>
        <translation>Использовать HTTPS вместо HTTP</translation>
    </message>
    <message>
        <source>Import SSL Certificate</source>
        <translation>Импортировать сертификат SSL</translation>
    </message>
    <message>
        <source>Import SSL Key</source>
        <translation>Импортировать ключ SSL</translation>
    </message>
    <message>
        <source>Certificate:</source>
        <translation>Сертификат:</translation>
    </message>
    <message>
        <source>Key:</source>
        <translation>Ключ:</translation>
    </message>
    <message>
        <source>&lt;a href=http://httpd.apache.org/docs/2.1/ssl/ssl_faq.html#aboutcerts&gt;Information about certificates&lt;/a&gt;</source>
        <translation>&lt;a href=http://httpd.apache.org/docs/2.1/ssl/ssl_faq.html#aboutcerts&gt;Информация о сертификатах&lt;/a&gt;</translation>
    </message>
</context>
<context>
    <name>PreviewSelect</name>
    <message>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Размер</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation>Прогресс</translation>
    </message>
    <message>
        <source>Preview impossible</source>
        <translation>Предпросмотр невозможен</translation>
    </message>
    <message>
        <source>Sorry, we can&apos;t preview this file</source>
        <translation>Извините, предпросмотр этого файла невозможен</translation>
    </message>
</context>
<context>
    <name>ProgramUpdater</name>
    <message>
        <source>Could not create the file %1</source>
        <translation type="obsolete">Невозможно создать файл %1</translation>
    </message>
    <message>
        <source>Failed to download the update at %1</source>
        <comment>%1 is an URL</comment>
        <translation type="obsolete">Не удалось скачать обновление с %1</translation>
    </message>
</context>
<context>
    <name>PropListDelegate</name>
    <message>
        <source>Normal</source>
        <comment>Normal (priority)</comment>
        <translation>Обычный</translation>
    </message>
    <message>
        <source>High</source>
        <comment>High (priority)</comment>
        <translation>Высокий</translation>
    </message>
    <message>
        <source>Maximum</source>
        <comment>Maximum (priority)</comment>
        <translation>Максимальный</translation>
    </message>
    <message>
        <source>Not downloaded</source>
        <translation>Не загружать</translation>
    </message>
    <message>
        <source>Mixed</source>
        <comment>Mixed (priorities</comment>
        <translation>Смешанные</translation>
    </message>
</context>
<context>
    <name>PropTabBar</name>
    <message>
        <source>General</source>
        <translation>Общие</translation>
    </message>
    <message>
        <source>Trackers</source>
        <translation>Трэкеры</translation>
    </message>
    <message>
        <source>Peers</source>
        <translation>Пиры</translation>
    </message>
    <message>
        <source>URL Seeds</source>
        <translation type="obsolete">URL раздающих</translation>
    </message>
    <message>
        <source>Files</source>
        <translation type="obsolete">Файлы</translation>
    </message>
    <message>
        <source>HTTP Sources</source>
        <translation>Источники HTTP</translation>
    </message>
    <message>
        <source>Content</source>
        <translation>Содержание</translation>
    </message>
</context>
<context>
    <name>PropertiesWidget</name>
    <message>
        <source>Save path:</source>
        <translation>Путь сохранения:</translation>
    </message>
    <message>
        <source>Torrent hash:</source>
        <translation>Хэш torrentа:</translation>
    </message>
    <message>
        <source>Comment:</source>
        <translation>Комментарий:</translation>
    </message>
    <message>
        <source>Share ratio:</source>
        <translation>Соотношение раздачи:</translation>
    </message>
    <message>
        <source>General</source>
        <translation type="obsolete">Общие</translation>
    </message>
    <message>
        <source>Trackers</source>
        <translation type="obsolete">Трэкеры</translation>
    </message>
    <message>
        <source>URL seeds</source>
        <translation type="obsolete">URL раздающих</translation>
    </message>
    <message>
        <source>Files</source>
        <translation type="obsolete">Файлы</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Приоритет</translation>
    </message>
    <message>
        <source>New url seed</source>
        <comment>New HTTP source</comment>
        <translation>Новый URL раздачи</translation>
    </message>
    <message>
        <source>New url seed:</source>
        <translation>URL нового раздающего:</translation>
    </message>
    <message>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <source>This url seed is already in the list.</source>
        <translation>Этот URL раздающего уже в списке.</translation>
    </message>
    <message>
        <source>Choose save path</source>
        <translation>Выберите путь сохранения</translation>
    </message>
    <message>
        <source>Save path creation error</source>
        <translation type="obsolete">Ошибка создания пути сохранения</translation>
    </message>
    <message>
        <source>Could not create the save path</source>
        <translation type="obsolete">Невозможно создать путь сохранения</translation>
    </message>
    <message>
        <source>Downloaded:</source>
        <translation>Скачано:</translation>
    </message>
    <message>
        <source>Transfer</source>
        <translation>Передано</translation>
    </message>
    <message>
        <source>Uploaded:</source>
        <translation>Отдано:</translation>
    </message>
    <message>
        <source>Wasted:</source>
        <translation>Потрачено:</translation>
    </message>
    <message>
        <source>UP limit:</source>
        <translation>Отд. огр:</translation>
    </message>
    <message>
        <source>DL limit:</source>
        <translation>Загр. огр:</translation>
    </message>
    <message>
        <source>Time elapsed:</source>
        <translation type="obsolete">Времени прошло:</translation>
    </message>
    <message>
        <source>Connections:</source>
        <translation>Соединения:</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Информация</translation>
    </message>
    <message>
        <source>Created on:</source>
        <translation>Создан на:</translation>
    </message>
    <message>
        <source>Peers</source>
        <translation type="obsolete">Пиры</translation>
    </message>
    <message>
        <source>Normal</source>
        <translation>Обычный</translation>
    </message>
    <message>
        <source>Maximum</source>
        <translation>Максимальный</translation>
    </message>
    <message>
        <source>High</source>
        <translation>Высокий</translation>
    </message>
    <message>
        <source>this session</source>
        <translation>эта сессия</translation>
    </message>
    <message>
        <source>%1 max</source>
        <comment>e.g. 10 max</comment>
        <translation>%1 макс</translation>
    </message>
    <message>
        <source>Availability:</source>
        <translation>Доступность:</translation>
    </message>
    <message>
        <source>/s</source>
        <comment>/second (i.e. per second)</comment>
        <translation>/с</translation>
    </message>
    <message>
        <source>Seeded for %1</source>
        <comment>e.g. Seeded for 3m10s</comment>
        <translation>Раздается %1</translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation>Переименовать...</translation>
    </message>
    <message>
        <source>New name:</source>
        <translation>Новое имя:</translation>
    </message>
    <message>
        <source>The file could not be renamed</source>
        <translation>Файл не может быть переименован</translation>
    </message>
    <message>
        <source>This name is already in use in this folder. Please use a different name.</source>
        <translation>Файл с таким именем уже существует в этой папке. Используйте другое имя.</translation>
    </message>
    <message>
        <source>The folder could not be renamed</source>
        <translation>Папка не может быть переименована</translation>
    </message>
    <message>
        <source>Rename the file</source>
        <translation>Переименовать файл</translation>
    </message>
    <message>
        <source>This file name contains forbidden characters, please choose a different one.</source>
        <translation>Имя файла содержит недопустимые символы. Пожалуйста, выберите другое.</translation>
    </message>
    <message>
        <source>I/O Error</source>
        <translation>Ошибка ввода/вывода</translation>
    </message>
    <message>
        <source>This file does not exist yet.</source>
        <translation>Этот файл пока не существует.</translation>
    </message>
    <message>
        <source>This folder does not exist yet.</source>
        <translation>Эта папка пока не существует.</translation>
    </message>
    <message>
        <source>Reannounce in:</source>
        <translation>Переанонсировать через:</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Выбрать все</translation>
    </message>
    <message>
        <source>Select None</source>
        <translation>Выбрать ничего</translation>
    </message>
    <message>
        <source>Do not download</source>
        <translation>Не загружать</translation>
    </message>
    <message>
        <source>Pieces size:</source>
        <translation>Размер кусочков:</translation>
    </message>
    <message>
        <source>Time active:</source>
        <extracomment>Time (duration) the torrent is active (not paused)</extracomment>
        <translation>Время активности:</translation>
    </message>
    <message>
        <source>Torrent content:</source>
        <translation>Содержимое торрента:</translation>
    </message>
</context>
<context>
    <name>QBtSession</name>
    <message>
        <source>%1 reached the maximum ratio you set.</source>
        <translation>%1 достиг установленного вами максимального соотношения.</translation>
    </message>
    <message>
        <source>Removing torrent %1...</source>
        <translation>Удаление торрента %1...</translation>
    </message>
    <message>
        <source>Pausing torrent %1...</source>
        <translation>Приостановка торрента %1...</translation>
    </message>
    <message>
        <source>qBittorrent is bound to port: TCP/%1</source>
        <comment>e.g: qBittorrent is bound to port: 6881</comment>
        <translation>qBittorrent привязан к порту: TCP/%1</translation>
    </message>
    <message>
        <source>UPnP support [ON]</source>
        <translation type="obsolete">Поддержка UPnP [Вкл]</translation>
    </message>
    <message>
        <source>UPnP support [OFF]</source>
        <translation type="obsolete">Поддержка UPnP [Выкл]</translation>
    </message>
    <message>
        <source>NAT-PMP support [ON]</source>
        <translation type="obsolete">Поддержка NAT-PMP [Вкл]</translation>
    </message>
    <message>
        <source>NAT-PMP support [OFF]</source>
        <translation type="obsolete">Поддержка NAT-PMP [Выкл]</translation>
    </message>
    <message>
        <source>HTTP user agent is %1</source>
        <translation>Браузер %1</translation>
    </message>
    <message>
        <source>Using a disk cache size of %1 MiB</source>
        <translation type="obsolete">Используется дисковый кеш размером %1 МиБ</translation>
    </message>
    <message>
        <source>DHT support [ON], port: UDP/%1</source>
        <translation>Поддержка DHT [Вкл.], порт: UDP/%1</translation>
    </message>
    <message>
        <source>DHT support [OFF]</source>
        <translation>Поддержка DHT [Выкл]</translation>
    </message>
    <message>
        <source>PeX support [ON]</source>
        <translation>Поддержка PeX [Вкл]</translation>
    </message>
    <message>
        <source>PeX support [OFF]</source>
        <translation>Поддержка PeX [Выкл]</translation>
    </message>
    <message>
        <source>Restart is required to toggle PeX support</source>
        <translation>Необходимо перезапустить qBittorrent для включения настройки PeX</translation>
    </message>
    <message>
        <source>Local Peer Discovery [ON]</source>
        <translation type="obsolete">Обнаружение локальных пиров [Вкл]</translation>
    </message>
    <message>
        <source>Local Peer Discovery support [OFF]</source>
        <translation>Обнаружение локальных пиров [Выкл]</translation>
    </message>
    <message>
        <source>Encryption support [ON]</source>
        <translation>Поддержка шифрования [Вкл]</translation>
    </message>
    <message>
        <source>Encryption support [FORCED]</source>
        <translation>Поддержка шифрования [Принудительно]</translation>
    </message>
    <message>
        <source>Encryption support [OFF]</source>
        <translation>Поддержка шифрования [Выкл]</translation>
    </message>
    <message>
        <source>Embedded Tracker [ON]</source>
        <translation>Встроенный трекер [Вкл]</translation>
    </message>
    <message>
        <source>Failed to start the embedded tracker!</source>
        <translation>Не удалось запустить встроенный трекер!</translation>
    </message>
    <message>
        <source>Embedded Tracker [OFF]</source>
        <translation>Встроенный трекер [Выкл]</translation>
    </message>
    <message>
        <source>The Web UI is listening on port %1</source>
        <translation>Web интерфейс прослушивает порт %1</translation>
    </message>
    <message>
        <source>Web User Interface Error - Unable to bind Web UI to port %1</source>
        <translation>Ошибка Web интерфейса - Не могу привязаться к порту %1</translation>
    </message>
    <message>
        <source>&apos;%1&apos; was removed from transfer list and hard disk.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>&apos;%1&apos; был удален из списка передач и с жесткого диска.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; was removed from transfer list.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>&apos;%1&apos; был удален из списка передач.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is not a valid magnet URI.</source>
        <translation>&apos;%1&apos; не является magnet URI.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is already in download list.</source>
        <comment>e.g: &apos;xxx.avi&apos; is already in download list.</comment>
        <translation>&apos;%1&apos; уже присутствует в списке закачек.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; resumed. (fast resume)</source>
        <comment>&apos;/home/y/xxx.torrent&apos; was resumed. (fast resume)</comment>
        <translation>%1 возобновлен. (быстрое возобновление)</translation>
    </message>
    <message>
        <source>&apos;%1&apos; added to download list.</source>
        <comment>&apos;/home/y/xxx.torrent&apos; was added to download list.</comment>
        <translation>&apos;%1&apos; добавлен в список закачек.</translation>
    </message>
    <message>
        <source>Unable to decode torrent file: &apos;%1&apos;</source>
        <comment>e.g: Unable to decode torrent file: &apos;/home/y/xxx.torrent&apos;</comment>
        <translation>Не удалось декодировать torrent файл: &apos;%1&apos;</translation>
    </message>
    <message>
        <source>This file is either corrupted or this isn&apos;t a torrent.</source>
        <translation>Этот файл либо поврежден, либо это не торрент-файл.</translation>
    </message>
    <message>
        <source>Error: The torrent %1 does not contain any file.</source>
        <translation>Ошибка: Торрент %1 не содержит никаких файлов.</translation>
    </message>
    <message>
        <source>Note: new trackers were added to the existing torrent.</source>
        <translation>Примечание: новые трекеры были добавлены к существующему торренту.</translation>
    </message>
    <message>
        <source>Note: new URL seeds were added to the existing torrent.</source>
        <translation>Примечание: новые URL сидов были добавлены к существующему торренту.</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;was blocked due to your IP filter&lt;/i&gt;</source>
        <comment>x.y.z.w was blocked</comment>
        <translation>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;был заблокирован в соответствии с вашим IP фильтром&lt;/i&gt;</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;was banned due to corrupt pieces&lt;/i&gt;</source>
        <comment>x.y.z.w was banned</comment>
        <translation>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;был заблокирован из-за поврежденных кусочков&lt;/i&gt;</translation>
    </message>
    <message>
        <source>Recursive download of file %1 embedded in torrent %2</source>
        <comment>Recursive download of test.torrent embedded in torrent test2</comment>
        <translation>Рекурсивная загрузка файла %1 встроенна в торрент %2</translation>
    </message>
    <message>
        <source>Unable to decode %1 torrent file.</source>
        <translation>Не удалось декодировать %1 torrent файл.</translation>
    </message>
    <message>
        <source>Torrent name: %1</source>
        <translation>Имя торрента: %1</translation>
    </message>
    <message>
        <source>Torrent size: %1</source>
        <translation>Размер торрента: %1</translation>
    </message>
    <message>
        <source>Save path: %1</source>
        <translation>Путь для сохранения: %1</translation>
    </message>
    <message>
        <source>The torrent was downloaded in %1.</source>
        <comment>The torrent was downloaded in 1 hour and 20 seconds</comment>
        <translation>Торрент был скачен за %1.</translation>
    </message>
    <message>
        <source>Thank you for using qBittorrent.</source>
        <translation>Спасибо за использование qBittorrent.</translation>
    </message>
    <message>
        <source>[qBittorrent] %1 has finished downloading</source>
        <translation>[qBittorrent] скачивание %1 завершено</translation>
    </message>
    <message>
        <source>An I/O error occured, &apos;%1&apos; paused.</source>
        <translation>Ошибка Ввода/Вывода: &apos;%1&apos; приостановлен.</translation>
    </message>
    <message>
        <source>Reason: %1</source>
        <translation>Причина: %1</translation>
    </message>
    <message>
        <source>UPnP/NAT-PMP: Port mapping failure, message: %1</source>
        <translation>Распределение портов UPnP/NAT-PMP не удалось с сообщением: %1</translation>
    </message>
    <message>
        <source>UPnP/NAT-PMP: Port mapping successful, message: %1</source>
        <translation>Распределение портов UPnP/NAT-PMP прошло успешно: %1</translation>
    </message>
    <message>
        <source>File sizes mismatch for torrent %1, pausing it.</source>
        <translation>Несовпадение размеров файлов для торрента %1, приостанавливаю его.</translation>
    </message>
    <message>
        <source>Fast resume data was rejected for torrent %1, checking again...</source>
        <translation>Быстрое восстановление данных для torrentа %1 было невозможно, проверка заново...</translation>
    </message>
    <message>
        <source>Url seed lookup failed for url: %1, message: %2</source>
        <translation>Поиск раздающего Url не удался: %1, сообщение: %2</translation>
    </message>
    <message>
        <source>Downloading &apos;%1&apos;, please wait...</source>
        <comment>e.g: Downloading &apos;xxx.torrent&apos;, please wait...</comment>
        <translation>Скачивание &apos;%1&apos;, подождите...</translation>
    </message>
    <message>
        <source>The network interface defined is invalid: %1</source>
        <translation>Указанный сетевой интерфейс ошибочен: %1</translation>
    </message>
    <message>
        <source>Trying any other network interface available instead.</source>
        <translation>Пробуем другой достпуный сетевой интерфейс.</translation>
    </message>
    <message>
        <source>Listening on IP address %1 on network interface %2...</source>
        <translation>Слушаем на IP адресе %1 на сетевом интерфейсе %2...</translation>
    </message>
    <message>
        <source>Failed to listen on network interface %1</source>
        <translation>Не возможно слушать сетевой интерфейс %1</translation>
    </message>
    <message>
        <source>UPnP / NAT-PMP support [ON]</source>
        <translation>Поддержка UPnP / NAT-PMP [Вкл]</translation>
    </message>
    <message>
        <source>UPnP / NAT-PMP support [OFF]</source>
        <translation>Поддержка UPnP / NAT-PMP [Выкл]</translation>
    </message>
    <message>
        <source>Local Peer Discovery support [ON]</source>
        <translation>Обнаружение локальных пиров [Вкл]</translation>
    </message>
    <message>
        <source>Successfuly parsed the provided IP filter: %1 rules were applied.</source>
        <comment>%1 is a number</comment>
        <translation>Успешно прочитан фильтр IP: %1 правил применено.</translation>
    </message>
    <message>
        <source>Error: Failed to parse the provided IP filter.</source>
        <translation>Ошибка: Не возможно разобрать фильтр IP.</translation>
    </message>
    <message>
        <source>Reporting IP address %1 to trackers...</source>
        <translation>Сообщаю IP адрес %1 трекерам...</translation>
    </message>
    <message>
        <source>The computer will now go to sleep mode unless you cancel within the next 15 seconds...</source>
        <translation>Сейчас компьютер перейдёт в спящий режим, если вы не отмените это в течение следующих 15 секунд...</translation>
    </message>
    <message>
        <source>The computer will now be switched off unless you cancel within the next 15 seconds...</source>
        <translation>Сейчас компьютер будет отключён, если вы не отмените это в течение следующих 15 секунд...</translation>
    </message>
    <message>
        <source>qBittorrent will now exit unless you cancel within the next 15 seconds...</source>
        <translation>Сейчас qBittorrent будет завершен, если вы не отмените это в течение следующих 15 секунд...</translation>
    </message>
</context>
<context>
    <name>RSS</name>
    <message>
        <source>Search</source>
        <translation>Поиск</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <source>Rename</source>
        <translation>Переименовать</translation>
    </message>
    <message>
        <source>Refresh RSS streams</source>
        <translation>Обновить RSS потоки</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Torrents:&lt;/span&gt; &lt;span style=&quot; font-style:italic;&quot;&gt;(double-click to download)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Торренты:&lt;/span&gt; &lt;span style=&quot; font-style:italic;&quot;&gt;(дважды щелкните для загрузки)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Download torrent</source>
        <translation>Скачать торрент</translation>
    </message>
    <message>
        <source>Open news URL</source>
        <translation>Открыть новый URL</translation>
    </message>
    <message>
        <source>Copy feed URL</source>
        <translation>Скопировать URL канала</translation>
    </message>
    <message>
        <source>New subscription</source>
        <translation>Новая подписка</translation>
    </message>
    <message>
        <source>Mark items read</source>
        <translation>Отметить элементы как прочитанные</translation>
    </message>
    <message>
        <source>Update all</source>
        <translation>Обновить все</translation>
    </message>
    <message>
        <source>Update all feeds</source>
        <translation>Обновить все каналы</translation>
    </message>
    <message>
        <source>RSS feeds</source>
        <translation type="obsolete">RSS каналы</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Обновить</translation>
    </message>
    <message>
        <source>Feed URL</source>
        <translation type="obsolete">URL канала</translation>
    </message>
    <message>
        <source>Article title</source>
        <translation type="obsolete">Заголовок статьи</translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation>Переименовать...</translation>
    </message>
    <message>
        <source>New subscription...</source>
        <translation>Новая подписка...</translation>
    </message>
    <message>
        <source>RSS feed downloader...</source>
        <translation type="obsolete">Загрузка RSS канала...</translation>
    </message>
    <message>
        <source>New folder...</source>
        <translation>Новая папка...</translation>
    </message>
    <message>
        <source>Manage cookies...</source>
        <translatorcomment>Или &apos;Управлять&apos;?</translatorcomment>
        <translation>Управление cookies...</translation>
    </message>
    <message>
        <source>Settings...</source>
        <translation>Настройки...</translation>
    </message>
    <message>
        <source>RSS Downloader...</source>
        <translation>Загрузчик RSS...</translation>
    </message>
</context>
<context>
    <name>RSSImp</name>
    <message>
        <source>Please type a rss stream url</source>
        <translation>Введите URL RSS потока</translation>
    </message>
    <message>
        <source>Stream URL:</source>
        <translation>URL потока:</translation>
    </message>
    <message>
        <source>Are you sure? -- qBittorrent</source>
        <translation>Вы уверены? -- qBittorrent</translation>
    </message>
    <message>
        <source>&amp;Yes</source>
        <translation>&amp;Да</translation>
    </message>
    <message>
        <source>&amp;No</source>
        <translation>&amp;Нет</translation>
    </message>
    <message>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <source>This rss feed is already in the list.</source>
        <translation>Этот RSS канал уже в списке.</translation>
    </message>
    <message>
        <source>Date: </source>
        <translation>Дата:</translation>
    </message>
    <message>
        <source>Author: </source>
        <translation>Автор:</translation>
    </message>
    <message>
        <source>Please choose a folder name</source>
        <translation>Выберите имя папки</translation>
    </message>
    <message>
        <source>Folder name:</source>
        <translation>Имя папки:</translation>
    </message>
    <message>
        <source>New folder</source>
        <translation>Новая папка</translation>
    </message>
    <message>
        <source>Are you sure you want to delete these elements from the list?</source>
        <translation>Вы уверены что хотите удалить эти элементы из списка?</translation>
    </message>
    <message>
        <source>Are you sure you want to delete this element from the list?</source>
        <translation>Вы уверены что хотите удалить этот элемент из списка?</translation>
    </message>
    <message>
        <source>Please choose a new name for this RSS feed</source>
        <translation>Укажите новое имя для этого RSS канала</translation>
    </message>
    <message>
        <source>New feed name:</source>
        <translation>Новое имя канала:</translation>
    </message>
    <message>
        <source>Name already in use</source>
        <translation>Имя уже используется</translation>
    </message>
    <message>
        <source>This name is already used by another item, please choose another one.</source>
        <translation>Это имя уже используется. Выберите другое.</translation>
    </message>
    <message>
        <source>Overwrite attempt</source>
        <translation>Подтверждение перезаписи</translation>
    </message>
    <message>
        <source>You cannot overwrite %1 item.</source>
        <comment>You cannot overwrite myFolder item.</comment>
        <translation>Вы не можете перезаписать %1.</translation>
    </message>
    <message>
        <source>Unread</source>
        <translation>Не прочитано</translation>
    </message>
</context>
<context>
    <name>RssArticle</name>
    <message>
        <source>No description available</source>
        <translation type="obsolete">Описание недоступно</translation>
    </message>
</context>
<context>
    <name>RssFeed</name>
    <message>
        <source>Automatically downloading %1 torrent from %2 RSS feed...</source>
        <translation>Автоматически загрузить %1 торрент с %2 RSS канала...</translation>
    </message>
</context>
<context>
    <name>RssItem</name>
    <message>
        <source>No description available</source>
        <translation type="obsolete">Описание недоступно</translation>
    </message>
</context>
<context>
    <name>RssSettings</name>
    <message>
        <source>RSS Reader Settings</source>
        <translatorcomment>И опять читалка...</translatorcomment>
        <translation type="obsolete">Настройки читалки RSS</translation>
    </message>
    <message>
        <source>RSS feeds refresh interval:</source>
        <translation type="obsolete">Интервал обновления RSS каналов:</translation>
    </message>
    <message>
        <source>minutes</source>
        <translation type="obsolete">минут</translation>
    </message>
    <message>
        <source>Maximum number of articles per feed:</source>
        <translation type="obsolete">Максимальное число статей на канал:</translation>
    </message>
</context>
<context>
    <name>RssSettingsDlg</name>
    <message>
        <source>RSS Reader Settings</source>
        <translation>Настройки читалки RSS</translation>
    </message>
    <message>
        <source>RSS feeds refresh interval:</source>
        <translation>Интервал обновления RSS каналов:</translation>
    </message>
    <message>
        <source>minutes</source>
        <translation>минут</translation>
    </message>
    <message>
        <source>Maximum number of articles per feed:</source>
        <translation>Максимальное число статей на канал:</translation>
    </message>
</context>
<context>
    <name>RssStream</name>
    <message>
        <source>Automatically downloading %1 torrent from %2 RSS feed...</source>
        <translation type="obsolete">Автоматически загрузить %1 торрент с %2 RSS канала...</translation>
    </message>
</context>
<context>
    <name>ScanFoldersModel</name>
    <message>
        <source>Watched Folder</source>
        <translation>Отслеживаемые папки</translation>
    </message>
    <message>
        <source>Download here</source>
        <translation>Скачивать сюда</translation>
    </message>
</context>
<context>
    <name>SearchCategories</name>
    <message>
        <source>All categories</source>
        <translation>Все категории</translation>
    </message>
    <message>
        <source>Movies</source>
        <translation>Фильмы</translation>
    </message>
    <message>
        <source>TV shows</source>
        <translation>ТВ-шоу</translation>
    </message>
    <message>
        <source>Music</source>
        <translation>Музыка</translation>
    </message>
    <message>
        <source>Games</source>
        <translation>Игры</translation>
    </message>
    <message>
        <source>Anime</source>
        <translation>Аниме</translation>
    </message>
    <message>
        <source>Software</source>
        <translation>Программы</translation>
    </message>
    <message>
        <source>Pictures</source>
        <translation>Изображения</translation>
    </message>
    <message>
        <source>Books</source>
        <translation>Книги</translation>
    </message>
</context>
<context>
    <name>SearchEngine</name>
    <message>
        <source>Empty search pattern</source>
        <translation>Очистить шаблон поиска</translation>
    </message>
    <message>
        <source>Please type a search pattern first</source>
        <translation>Пожалуйста, наберите сначала шаблон поиска</translation>
    </message>
    <message>
        <source>Results</source>
        <translation>Результаты</translation>
    </message>
    <message>
        <source>Searching...</source>
        <translation>Поиск...</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation>Вырезать</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Копировать</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation>Вставить</translation>
    </message>
    <message>
        <source>Clear field</source>
        <translation>Очистить поле</translation>
    </message>
    <message>
        <source>Clear completion history</source>
        <translation>Очистить историю</translation>
    </message>
    <message>
        <source>Search Engine</source>
        <translation>Поисковый движок</translation>
    </message>
    <message>
        <source>Search has finished</source>
        <translation>Поиск завершен</translation>
    </message>
    <message>
        <source>An error occured during search...</source>
        <translation>Во время поиска произошла ошибка...</translation>
    </message>
    <message>
        <source>Search aborted</source>
        <translation>Поиск прерван</translation>
    </message>
    <message>
        <source>Search returned no results</source>
        <translation>Поиск не дал результатов</translation>
    </message>
    <message>
        <source>Results</source>
        <comment>i.e: Search results</comment>
        <translation>Результаты</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Неизвестно</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Поиск</translation>
    </message>
    <message>
        <source>Download error</source>
        <translation>Ошибка при скачивании</translation>
    </message>
    <message>
        <source>Python setup could not be downloaded, reason: %1.
Please install it manually.</source>
        <translatorcomment>А вот нефиг ставить вручную! Ставить надо из репозитория. Думаю тут лучше будет &apos;самостоятельно&apos;...</translatorcomment>
        <translation>Установщик Python не может быть загружен по причине: %1.
Пожалуйста, установите его вручную.</translation>
    </message>
    <message>
        <source>Missing Python Interpreter</source>
        <translation>Отсутствует интерпретатор Python</translation>
    </message>
    <message>
        <source>Python 2.x is required to use the search engine but it does not seem to be installed.
Do you want to install it now?</source>
        <translation>Python 2.x требуется для использования поисковиков, но не похоже что он установлен.
Хотите ли Вы установить его сечас?</translation>
    </message>
    <message>
        <source>Confirmation</source>
        <translation>Подтверждение</translation>
    </message>
    <message>
        <source>Are you sure you want to clear the history?</source>
        <translatorcomment>Или &apos;журнал&apos;?</translatorcomment>
        <translation>Вы уверены, что хотите очистить историю?</translation>
    </message>
</context>
<context>
    <name>SearchTab</name>
    <message>
        <source>Name</source>
        <comment>i.e: file name</comment>
        <translation>Имя</translation>
    </message>
    <message>
        <source>Size</source>
        <comment>i.e: file size</comment>
        <translation>Размер</translation>
    </message>
    <message>
        <source>Seeders</source>
        <comment>i.e: Number of full sources</comment>
        <translation>Раздающие</translation>
    </message>
    <message>
        <source>Leechers</source>
        <comment>i.e: Number of partial sources</comment>
        <translation>Скачивающие</translation>
    </message>
    <message>
        <source>Search engine</source>
        <translation>Поисковый движок</translation>
    </message>
</context>
<context>
    <name>ShutdownConfirmDlg</name>
    <message>
        <source>Shutdown confirmation</source>
        <translation>Подтверждение выключения</translation>
    </message>
</context>
<context>
    <name>SpeedLimitDialog</name>
    <message>
        <source>KiB/s</source>
        <translation>КиБ/с</translation>
    </message>
</context>
<context>
    <name>StatusBar</name>
    <message>
        <source>Connection status:</source>
        <translation>Состояние связи:</translation>
    </message>
    <message>
        <source>No direct connections. This may indicate network configuration problems.</source>
        <translation>Нет прямых соединений. Причиной этого могут быть проблемы в настройке сети.</translation>
    </message>
    <message>
        <source>DHT: %1 nodes</source>
        <translation>DHT: %1 узлов</translation>
    </message>
    <message>
        <source>Connection Status:</source>
        <translation>Состояние связи:</translation>
    </message>
    <message>
        <source>Online</source>
        <translation>В сети</translation>
    </message>
    <message>
        <source>Global Download Speed Limit</source>
        <translation>Глобальное ограничение скорости закачки</translation>
    </message>
    <message>
        <source>Global Upload Speed Limit</source>
        <translation>Глобальное ограничение скорости раздачи</translation>
    </message>
    <message>
        <source>D: %1/s - T: %2</source>
        <comment>Download speed: x KiB/s - Transferred: x MiB</comment>
        <translation type="obsolete">Скач: %1/с - Перед: %2</translation>
    </message>
    <message>
        <source>U: %1/s - T: %2</source>
        <comment>Upload speed: x KiB/s - Transferred: x MiB</comment>
        <translation type="obsolete">Отдача: %1/с - Перед: %2</translation>
    </message>
    <message>
        <source>D: %1 B/s - T: %2</source>
        <comment>Download speed: x B/s - Transferred: x MiB</comment>
        <translation type="obsolete">Скач: %1Б/с - Перед: %2</translation>
    </message>
    <message>
        <source>U: %1 B/s - T: %2</source>
        <comment>Upload speed: x B/s - Transferred: x MiB</comment>
        <translation type="obsolete">Отдача: %1Б/с - Перед: %2</translation>
    </message>
    <message>
        <source>Offline. This usually means that qBittorrent failed to listen on the selected port for incoming connections.</source>
        <translation>Отключен. Обычно это означает, что qBittorrent не может прослушивать выбранный порт для входящих соединений.</translation>
    </message>
    <message>
        <source>Click to disable alternative speed limits</source>
        <translation type="obsolete">Нажмите для отключения альтернативных лимитов скорости</translation>
    </message>
    <message>
        <source>Click to enable alternative speed limits</source>
        <translation type="obsolete">Нажмите для включения альтернативных лимитов скорости</translation>
    </message>
    <message>
        <source>qBittorrent needs to be restarted</source>
        <translation>qBittorrent надо перезапустить</translation>
    </message>
    <message>
        <source>qBittorrent was just updated and needs to be restarted for the changes to be effective.</source>
        <translation>qBittorrent был обновлен и нуждается в перезапуске, чтобы изменение вступили в силу.</translation>
    </message>
    <message>
        <source>Click to switch to alternative speed limits</source>
        <translation>Нажмите для переключения к альтернативным лимитам скорости</translation>
    </message>
    <message>
        <source>Click to switch to regular speed limits</source>
        <translation>Нажмите для переключения к обычным лимитам скорости</translation>
    </message>
    <message>
        <source>%1/s</source>
        <comment>Per second</comment>
        <translation>%1/с</translation>
    </message>
</context>
<context>
    <name>TorrentCreatorDlg</name>
    <message>
        <source>Select a folder to add to the torrent</source>
        <translation>Выберите папку для добавления в torrent</translation>
    </message>
    <message>
        <source>Select a file to add to the torrent</source>
        <translation>Выберите файл для добавления в torrent</translation>
    </message>
    <message>
        <source>Please type an announce URL</source>
        <translation type="obsolete">Введите ссылку анонсирования</translation>
    </message>
    <message>
        <source>Announce URL:</source>
        <comment>Tracker URL</comment>
        <translation type="obsolete">Анонсирующий URL:</translation>
    </message>
    <message>
        <source>Please type a web seed url</source>
        <translation type="obsolete">Введите URL веб раздачи</translation>
    </message>
    <message>
        <source>Web seed URL:</source>
        <translation type="obsolete">URL веб раздачи:</translation>
    </message>
    <message>
        <source>No input path set</source>
        <translation>Не установлен входной путь</translation>
    </message>
    <message>
        <source>Please type an input path first</source>
        <translation>Пожалуйста, сначала введите путь источника</translation>
    </message>
    <message>
        <source>Select destination torrent file</source>
        <translation>Выберите torrent файл назначения</translation>
    </message>
    <message>
        <source>Torrent Files</source>
        <translation>Файлы Torrent</translation>
    </message>
    <message>
        <source>Torrent creation</source>
        <translation>Создание Torrent-а</translation>
    </message>
    <message>
        <source>Torrent creation was unsuccessful, reason: %1</source>
        <translation>Создание torrent-а не завершено, причина: %1</translation>
    </message>
    <message>
        <source>Created torrent file is invalid. It won&apos;t be added to download list.</source>
        <translation>Созданный torrent файл испорчен. Он не будет добавлен в список закачек.</translation>
    </message>
    <message>
        <source>Torrent was created successfully:</source>
        <translation>Torrent успешно создан:</translation>
    </message>
</context>
<context>
    <name>TorrentFilesModel</name>
    <message>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Размер</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation>Прогресс</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Приоритет</translation>
    </message>
</context>
<context>
    <name>TorrentImportDlg</name>
    <message>
        <source>Torrent Import</source>
        <translation>Импортировать торрент</translation>
    </message>
    <message>
        <source>This assistant will help you share with qBittorrent a torrent that you have already downloaded.</source>
        <translatorcomment>dont understand phrase</translatorcomment>
        <translation>Помошник поможет вам настроить раздачу торрента, который вы уже скачали.</translation>
    </message>
    <message>
        <source>Torrent file to import:</source>
        <translation>Имя файла торрента для импорта:</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Content location:</source>
        <translation>Размещение содержимого:</translation>
    </message>
    <message>
        <source>Skip the data checking stage and start seeding immediately</source>
        <translation>Пропустить проверку данных и начать раздачу немедленно</translation>
    </message>
    <message>
        <source>Import</source>
        <translation>Импорт</translation>
    </message>
    <message>
        <source>Torrent file to import</source>
        <translation>Торрент файл для импорта</translation>
    </message>
    <message>
        <source>Torrent files (*.torrent)</source>
        <translation>Торрент файлы (*.torrent)</translation>
    </message>
    <message>
        <source>%1 Files</source>
        <comment>%1 is a file extension (e.g. PDF)</comment>
        <translation>%1 файлы</translation>
    </message>
    <message>
        <source>Please provide the location of %1</source>
        <comment>%1 is a file name</comment>
        <translation>Укажите размещение %1</translation>
    </message>
    <message>
        <source>Please point to the location of the torrent: %1</source>
        <translation>Укажите расположение торрент файла: %1</translation>
    </message>
    <message>
        <source>Invalid torrent file</source>
        <translation>Неправильный торрент файл</translation>
    </message>
    <message>
        <source>This is not a valid torrent file.</source>
        <translation>Это не правильный торрент файл.</translation>
    </message>
</context>
<context>
    <name>TorrentModel</name>
    <message>
        <source>Name</source>
        <comment>i.e: torrent name</comment>
        <translation>Имя</translation>
    </message>
    <message>
        <source>Size</source>
        <comment>i.e: torrent size</comment>
        <translation>Размер</translation>
    </message>
    <message>
        <source>Done</source>
        <comment>% Done</comment>
        <translation>Завершено</translation>
    </message>
    <message>
        <source>Status</source>
        <comment>Torrent status (e.g. downloading, seeding, paused)</comment>
        <translation>Статус</translation>
    </message>
    <message>
        <source>Seeds</source>
        <comment>i.e. full sources (often untranslated)</comment>
        <translation>Источники</translation>
    </message>
    <message>
        <source>Peers</source>
        <comment>i.e. partial sources (often untranslated)</comment>
        <translation>Пиры</translation>
    </message>
    <message>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Скорость скач</translation>
    </message>
    <message>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Скорость отдачи</translation>
    </message>
    <message>
        <source>Ratio</source>
        <comment>Share ratio</comment>
        <translation>Соотношение</translation>
    </message>
    <message>
        <source>ETA</source>
        <comment>i.e: Estimated Time of Arrival / Time left</comment>
        <translation>Ост. времени</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Метка</translation>
    </message>
    <message>
        <source>Added On</source>
        <comment>Torrent was added to transfer list on 01/01/2010 08:00</comment>
        <translation>Добавлен</translation>
    </message>
    <message>
        <source>Completed On</source>
        <comment>Torrent was completed on 01/01/2010 08:00</comment>
        <translation>Закончен</translation>
    </message>
    <message>
        <source>Tracker</source>
        <translation>Трэкер</translation>
    </message>
    <message>
        <source>Down Limit</source>
        <comment>i.e: Download limit</comment>
        <translation>Лимит Загр</translation>
    </message>
    <message>
        <source>Up Limit</source>
        <comment>i.e: Upload limit</comment>
        <translation>Лимит Отд</translation>
    </message>
    <message>
        <source>Amount downloaded</source>
        <comment>Amount of data downloaded (e.g. in MB)</comment>
        <translation>Загружено</translation>
    </message>
    <message>
        <source>Amount left</source>
        <comment>Amount of data left to download (e.g. in MB)</comment>
        <translation>Осталось</translation>
    </message>
    <message>
        <source>Time Active</source>
        <comment>Time (duration) the torrent is active (not paused)</comment>
        <translation>Время активности</translation>
    </message>
</context>
<context>
    <name>TrackerList</name>
    <message>
        <source>URL</source>
        <translation>Ссылка</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Статус</translation>
    </message>
    <message>
        <source>Peers</source>
        <translation>Пиры</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Сообщение</translation>
    </message>
    <message>
        <source>[DHT]</source>
        <translation></translation>
    </message>
    <message>
        <source>[PeX]</source>
        <translation></translation>
    </message>
    <message>
        <source>[LSD]</source>
        <translation></translation>
    </message>
    <message>
        <source>Working</source>
        <translation>Работает</translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Выключено</translation>
    </message>
    <message>
        <source>This torrent is private</source>
        <translation>Это приватный торрент</translation>
    </message>
    <message>
        <source>Updating...</source>
        <translation>Обновляется...</translation>
    </message>
    <message>
        <source>Not working</source>
        <translation>Не работает</translation>
    </message>
    <message>
        <source>Not contacted yet</source>
        <translation>Не соединился</translation>
    </message>
    <message>
        <source>Add a new tracker...</source>
        <translation>Добавить новый трекер...</translation>
    </message>
    <message>
        <source>Remove tracker</source>
        <translation>Удалить трекер</translation>
    </message>
    <message>
        <source>Force reannounce</source>
        <translatorcomment>Коряво &gt;_&lt;</translatorcomment>
        <translation>Переанонсировать принудительно</translation>
    </message>
</context>
<context>
    <name>TrackersAdditionDlg</name>
    <message>
        <source>Trackers addition dialog</source>
        <translation>Диалог добавления трекеров</translation>
    </message>
    <message>
        <source>List of trackers to add (one per line):</source>
        <translation>Список трекеров для добавления (один трекер на строку):</translation>
    </message>
    <message utf8="true">
        <source>µTorrent compatible list URL:</source>
        <translation>URL списка совместимого с µTorrent:</translation>
    </message>
    <message>
        <source>I/O Error</source>
        <translation>Ошибка ввода/вывода</translation>
    </message>
    <message>
        <source>Error while trying to open the downloaded file.</source>
        <translation>Ошибка при открытии скачанного файла.</translation>
    </message>
    <message>
        <source>No change</source>
        <translation>Без изменений</translation>
    </message>
    <message>
        <source>No additional trackers were found.</source>
        <translation>Дополнительных трекеров не найдено.</translation>
    </message>
    <message>
        <source>Download error</source>
        <translation>Ошибка при скачивании</translation>
    </message>
    <message>
        <source>The trackers list could not be downloaded, reason: %1</source>
        <translation>Список трекеров не может быть скачан. Причина: %1</translation>
    </message>
</context>
<context>
    <name>TransferListDelegate</name>
    <message>
        <source>Downloading</source>
        <translation>Скачивание</translation>
    </message>
    <message>
        <source>Paused</source>
        <translation>Пауза</translation>
    </message>
    <message>
        <source>Queued</source>
        <comment>i.e. torrent is queued</comment>
        <translation>В очереди</translation>
    </message>
    <message>
        <source>Seeding</source>
        <comment>Torrent is complete and in upload-only mode</comment>
        <translation>Раздача</translation>
    </message>
    <message>
        <source>Stalled</source>
        <comment>Torrent is waiting for download to begin</comment>
        <translation>Простаивает</translation>
    </message>
    <message>
        <source>Checking</source>
        <comment>Torrent local data is being checked</comment>
        <translation>Проверка</translation>
    </message>
    <message>
        <source>/s</source>
        <comment>/second (.i.e per second)</comment>
        <translation>/с</translation>
    </message>
    <message>
        <source>KiB/s</source>
        <comment>KiB/second (.i.e per second)</comment>
        <translation>КиБ/с</translation>
    </message>
    <message>
        <source>Seeded for %1</source>
        <comment>e.g. Seeded for 3m10s</comment>
        <translation>Раздается %1</translation>
    </message>
</context>
<context>
    <name>TransferListFiltersWidget</name>
    <message>
        <source>All</source>
        <translation>Все</translation>
    </message>
    <message>
        <source>Downloading</source>
        <translation>Скачивание</translation>
    </message>
    <message>
        <source>Completed</source>
        <translation>Завершено</translation>
    </message>
    <message>
        <source>Active</source>
        <translation>Активные</translation>
    </message>
    <message>
        <source>Inactive</source>
        <translation>Не активные</translation>
    </message>
    <message>
        <source>All labels</source>
        <translation>Все метки</translation>
    </message>
    <message>
        <source>Unlabeled</source>
        <translation>Без метки</translation>
    </message>
    <message>
        <source>Remove label</source>
        <translation>Удалить метку</translation>
    </message>
    <message>
        <source>New Label</source>
        <translation>Новая метка</translation>
    </message>
    <message>
        <source>Label:</source>
        <translation>Метка:</translation>
    </message>
    <message>
        <source>Invalid label name</source>
        <translation>Неправильное имя метки</translation>
    </message>
    <message>
        <source>Please don&apos;t use any special characters in the label name.</source>
        <translation>Пожалуйста, не используйте специальные символы в имени метки.</translation>
    </message>
    <message>
        <source>Paused</source>
        <translation>Пауза</translation>
    </message>
    <message>
        <source>Add label...</source>
        <translation>Добавить метку...</translation>
    </message>
    <message>
        <source>Resume torrents</source>
        <translation>Возобновить торренты</translation>
    </message>
    <message>
        <source>Pause torrents</source>
        <translation>Приостановить торренты</translation>
    </message>
    <message>
        <source>Delete torrents</source>
        <translation>Удалить торренты</translation>
    </message>
</context>
<context>
    <name>TransferListWidget</name>
    <message>
        <source>ETA</source>
        <comment>i.e: Estimated Time of Arrival / Time left</comment>
        <translation type="obsolete">Ост. времени</translation>
    </message>
    <message>
        <source>Column visibility</source>
        <translation>Отображение колонок</translation>
    </message>
    <message>
        <source>Open destination folder</source>
        <translation>Открыть папку назначения</translation>
    </message>
    <message>
        <source>Force recheck</source>
        <translation>Проверить принудительно</translation>
    </message>
    <message>
        <source>Copy magnet link</source>
        <translation>Скопировать ссылку magnet</translation>
    </message>
    <message>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation type="obsolete">Скорость скач</translation>
    </message>
    <message>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation type="obsolete">Скорость отдачи</translation>
    </message>
    <message>
        <source>Name</source>
        <comment>i.e: torrent name</comment>
        <translation type="obsolete">Имя</translation>
    </message>
    <message>
        <source>Size</source>
        <comment>i.e: torrent size</comment>
        <translation type="obsolete">Размер</translation>
    </message>
    <message>
        <source>Done</source>
        <comment>% Done</comment>
        <translation type="obsolete">Завершено</translation>
    </message>
    <message>
        <source>Status</source>
        <comment>Torrent status (e.g. downloading, seeding, paused)</comment>
        <translation type="obsolete">Статус</translation>
    </message>
    <message>
        <source>Seeds</source>
        <comment>i.e. full sources (often untranslated)</comment>
        <translation type="obsolete">Источники</translation>
    </message>
    <message>
        <source>Peers</source>
        <comment>i.e. partial sources (often untranslated)</comment>
        <translation type="obsolete">Пиры</translation>
    </message>
    <message>
        <source>Ratio</source>
        <comment>Share ratio</comment>
        <translation type="obsolete">Соотношение</translation>
    </message>
    <message>
        <source>Torrent Download Speed Limiting</source>
        <translation>Ограничение скорости скачивания торрента</translation>
    </message>
    <message>
        <source>Torrent Upload Speed Limiting</source>
        <translation>Ограничение скорости раздачи торрента</translation>
    </message>
    <message>
        <source>Super seeding mode</source>
        <translation>Режим супер раздачи</translation>
    </message>
    <message>
        <source>Download in sequential order</source>
        <translation>Скачивать последовательно</translation>
    </message>
    <message>
        <source>Download first and last piece first</source>
        <translation>Скачивать первый и последний кусок сначала</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Метка</translation>
    </message>
    <message>
        <source>New Label</source>
        <translation>Новая метка</translation>
    </message>
    <message>
        <source>Label:</source>
        <translation>Метка:</translation>
    </message>
    <message>
        <source>New...</source>
        <comment>New label...</comment>
        <translation>Новая...</translation>
    </message>
    <message>
        <source>Reset</source>
        <comment>Reset label</comment>
        <translation>Восстановить метку</translation>
    </message>
    <message>
        <source>Rename</source>
        <translation>Переименовать</translation>
    </message>
    <message>
        <source>New name:</source>
        <translation>Новое имя:</translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation>Переименовать...</translation>
    </message>
    <message>
        <source>Invalid label name</source>
        <translation>Неправильное имя метки</translation>
    </message>
    <message>
        <source>Please don&apos;t use any special characters in the label name.</source>
        <translation>Пожалуйста, не используйте специальные символы в имени метки.</translation>
    </message>
    <message>
        <source>Added On</source>
        <comment>Torrent was added to transfer list on 01/01/2010 08:00</comment>
        <translation type="obsolete">Добавлен</translation>
    </message>
    <message>
        <source>Completed On</source>
        <comment>Torrent was completed on 01/01/2010 08:00</comment>
        <translation type="obsolete">Закончен</translation>
    </message>
    <message>
        <source>Down Limit</source>
        <comment>i.e: Download limit</comment>
        <translation type="obsolete">Лимит Загр</translation>
    </message>
    <message>
        <source>Up Limit</source>
        <comment>i.e: Upload limit</comment>
        <translation type="obsolete">Лимит Отд</translation>
    </message>
    <message>
        <source>Choose save path</source>
        <translation>Выберите путь сохранения</translation>
    </message>
    <message>
        <source>Save path creation error</source>
        <translation type="obsolete">Ошибка создания пути сохранения</translation>
    </message>
    <message>
        <source>Could not create the save path</source>
        <translation type="obsolete">Невозможно создать путь сохранения</translation>
    </message>
    <message>
        <source>Set location...</source>
        <translatorcomment>Блин, до чего же коряво! Может лучше &apos;Переместить файлы&apos;?</translatorcomment>
        <translation>Установить размещение...</translation>
    </message>
    <message>
        <source>Preview file...</source>
        <translation>Предпросмотр файла...</translation>
    </message>
    <message>
        <source>Limit upload rate...</source>
        <translation>Ограничение скорости раздачи...</translation>
    </message>
    <message>
        <source>Limit download rate...</source>
        <translation>Ограничение скорости скачивания...</translation>
    </message>
    <message>
        <source>Move up</source>
        <comment>i.e. move up in the queue</comment>
        <translation>Вверх</translation>
    </message>
    <message>
        <source>Move down</source>
        <comment>i.e. Move down in the queue</comment>
        <translation>Вниз</translation>
    </message>
    <message>
        <source>Move to top</source>
        <comment>i.e. Move to top of the queue</comment>
        <translation>На самый верх</translation>
    </message>
    <message>
        <source>Move to bottom</source>
        <comment>i.e. Move to bottom of the queue</comment>
        <translation>На самый низ</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Приоритет</translation>
    </message>
    <message>
        <source>Resume</source>
        <comment>Resume/start the torrent</comment>
        <translation>Возобновить</translation>
    </message>
    <message>
        <source>Pause</source>
        <comment>Pause the torrent</comment>
        <translation>Приостановить</translation>
    </message>
    <message>
        <source>Delete</source>
        <comment>Delete the torrent</comment>
        <translation>Удалить</translation>
    </message>
    <message>
        <source>Tracker</source>
        <translation type="obsolete">Трэкер</translation>
    </message>
    <message>
        <source>Limit share ratio...</source>
        <translation>Ограничить коэффициент раздачи...</translation>
    </message>
</context>
<context>
    <name>UpDownRatioDlg</name>
    <message>
        <source>Torrent Upload/Download Ratio Limiting</source>
        <translation>Ограничение коэффициента скачивания/раздачи торрента</translation>
    </message>
    <message>
        <source>Use global ratio limit</source>
        <translation>Использовать глобальное ограничение коэффициента</translation>
    </message>
    <message>
        <source>buttonGroup</source>
        <translatorcomment>Do you really need to translate it?</translatorcomment>
        <translation>buttonGroup</translation>
    </message>
    <message>
        <source>Set no ratio limit</source>
        <translation>Убрать ограничение коэффициента</translation>
    </message>
    <message>
        <source>Set ratio limit to</source>
        <translation>Установить ограничение коэффициента</translation>
    </message>
</context>
<context>
    <name>UsageDisplay</name>
    <message>
        <source>Usage:</source>
        <translation>Использование:</translation>
    </message>
    <message>
        <source>displays program version</source>
        <translation>показать версию программы</translation>
    </message>
    <message>
        <source>disable splash screen</source>
        <translation>показать заставку при загрузке</translation>
    </message>
    <message>
        <source>displays this help message</source>
        <translation>показать эту справку</translation>
    </message>
    <message>
        <source>changes the webui port (current: %1)</source>
        <translation>Изменить порт Web интерфейса (сейчас: %1)</translation>
    </message>
    <message>
        <source>[files or urls]: downloads the torrents passed by the user (optional)</source>
        <translation>[файлы или ссылки]: скачать торренты указанные пользователем (опционально)</translation>
    </message>
</context>
<context>
    <name>about</name>
    <message>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <source>I would like to thank the following people who volunteered to translate qBittorrent:</source>
        <translation>Я хочу поблагодарить следующих людей, кто вызвался перевести qBittorrent:</translation>
    </message>
    <message>
        <source>Please contact me if you would like to translate qBittorrent into your own language.</source>
        <translation>Пожалуйста, свяжитесь со мной, если хотите перевести qBittorrent на свой язык.</translation>
    </message>
</context>
<context>
    <name>addPeerDialog</name>
    <message>
        <source>Peer addition</source>
        <translation>Добавление пира</translation>
    </message>
    <message>
        <source>IP</source>
        <translation>IP</translation>
    </message>
    <message>
        <source>Port</source>
        <translation>Порт</translation>
    </message>
</context>
<context>
    <name>addTorrentDialog</name>
    <message>
        <source>Torrent addition dialog</source>
        <translation>Окно добавления torrent-а</translation>
    </message>
    <message>
        <source>Save path:</source>
        <translation>Путь сохранения:</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Torrent content:</source>
        <translation>Содержимое torrent-а:</translation>
    </message>
    <message>
        <source>Add to download list in paused state</source>
        <translation>Добавить в список закачек в приостановленном состоянии</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>Добавить</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <source>Normal</source>
        <translation>Обычный</translation>
    </message>
    <message>
        <source>High</source>
        <translation>Высокий</translation>
    </message>
    <message>
        <source>Maximum</source>
        <translation>Максимальный</translation>
    </message>
    <message>
        <source>Torrent size:</source>
        <translation>Размер торрента:</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Неизвестно</translation>
    </message>
    <message>
        <source>Free disk space:</source>
        <translation>Свободное место на диске:</translation>
    </message>
    <message>
        <source>Download in sequential order (slower but good for previewing)</source>
        <translation>Загружать последовательно (медленнее но удобнее для предпросмотра)</translation>
    </message>
    <message>
        <source>Skip file checking and start seeding immediately</source>
        <translation>Пропустить проверку файла и начать раздачу немедленно</translation>
    </message>
    <message>
        <source>Label:</source>
        <translation>Метка:</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Выбрать все</translation>
    </message>
    <message>
        <source>Select None</source>
        <translation>Выбрать ничего</translation>
    </message>
    <message>
        <source>Do not download</source>
        <translation>Не загружать</translation>
    </message>
</context>
<context>
    <name>authentication</name>
    <message>
        <source>Tracker authentication</source>
        <translation>Аутентификация Трэкера</translation>
    </message>
    <message>
        <source>Tracker:</source>
        <translation>Трэкер:</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Логин</translation>
    </message>
    <message>
        <source>Username:</source>
        <translation>Имя пользователя:</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation>Пароль:</translation>
    </message>
    <message>
        <source>Log in</source>
        <translation>Вход</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
</context>
<context>
    <name>confirmDeletionDlg</name>
    <message>
        <source>Deletion confirmation - qBittorrent</source>
        <translation>Подтверждение удаления - qBittorrent</translation>
    </message>
    <message>
        <source>Are you sure you want to delete the selected torrents from the transfer list?</source>
        <translation>Вы уверены что хотите удалить выделенные торренты из списка передач?</translation>
    </message>
    <message>
        <source>Remember choice</source>
        <translation>Запомнить выбор</translation>
    </message>
    <message>
        <source>Also delete the files on the hard disk</source>
        <translation>Также удалить файлы и с жесткого диска</translation>
    </message>
</context>
<context>
    <name>createTorrentDialog</name>
    <message>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <source>Torrent Creation Tool</source>
        <translation>Инструмент для создания Torrent-ов</translation>
    </message>
    <message>
        <source>Torrent file creation</source>
        <translation>Создание Torrent файла</translation>
    </message>
    <message>
        <source>Announce urls (trackers):</source>
        <translation type="obsolete">Аносирующие ссылки (трэкеров):</translation>
    </message>
    <message>
        <source>Comment (optional):</source>
        <translation type="obsolete">Комментарий (необязателен):</translation>
    </message>
    <message>
        <source>Web seeds urls (optional):</source>
        <translation type="obsolete">Ссылки на веб раздачи (необязательно):</translation>
    </message>
    <message>
        <source>File or folder to add to the torrent:</source>
        <translation>Файл или папка для добавления в torrent:</translation>
    </message>
    <message>
        <source>Piece size:</source>
        <translation>Размер кусочка:</translation>
    </message>
    <message>
        <source>32 KiB</source>
        <translation>32 КиБ</translation>
    </message>
    <message>
        <source>64 KiB</source>
        <translation>64 КиБ</translation>
    </message>
    <message>
        <source>128 KiB</source>
        <translation>128 КиБ</translation>
    </message>
    <message>
        <source>256 KiB</source>
        <translation>256 КиБ</translation>
    </message>
    <message>
        <source>512 KiB</source>
        <translation>512 КиБ</translation>
    </message>
    <message>
        <source>1 MiB</source>
        <translation>1 МиБ</translation>
    </message>
    <message>
        <source>2 MiB</source>
        <translation>2 МиБ</translation>
    </message>
    <message>
        <source>4 MiB</source>
        <translation>4 МиБ</translation>
    </message>
    <message>
        <source>Private (won&apos;t be distributed on DHT network if enabled)</source>
        <translation>Закрытый (не будет передаваться через безтрекерную сеть / DHT при включении)</translation>
    </message>
    <message>
        <source>Start seeding after creation</source>
        <translation>Начать раздавать после создания</translation>
    </message>
    <message>
        <source>Create and save...</source>
        <translation>Создать и сохранить...</translation>
    </message>
    <message>
        <source>Progress:</source>
        <translation>Прогресс:</translation>
    </message>
    <message>
        <source>Add file</source>
        <translation>Добавить файл</translation>
    </message>
    <message>
        <source>Add folder</source>
        <translation>Добавить папку</translation>
    </message>
    <message>
        <source>Tracker URLs:</source>
        <translation>URL-ы трекера:</translation>
    </message>
    <message>
        <source>Web seeds urls:</source>
        <translation>URL веб раздачи:</translation>
    </message>
    <message>
        <source>Comment:</source>
        <translation>Комментарий:</translation>
    </message>
    <message>
        <source>Auto</source>
        <translation>Авто</translation>
    </message>
</context>
<context>
    <name>createtorrent</name>
    <message>
        <source>Select destination torrent file</source>
        <translation type="obsolete">Выберите torrent файл назначения</translation>
    </message>
    <message>
        <source>Torrent Files</source>
        <translation type="obsolete">Файлы Torrent</translation>
    </message>
    <message>
        <source>No input path set</source>
        <translation type="obsolete">Не установлен входной путь</translation>
    </message>
    <message>
        <source>Please type an input path first</source>
        <translation type="obsolete">Пожалуйста, сначала введите путь назначения</translation>
    </message>
    <message>
        <source>Torrent creation</source>
        <translation type="obsolete">Создание Torrent-а</translation>
    </message>
    <message>
        <source>Torrent was created successfully:</source>
        <translation type="obsolete">Torrent успешно создан:</translation>
    </message>
    <message>
        <source>Select a folder to add to the torrent</source>
        <translation type="obsolete">Выберите папку для добавления torrent-а</translation>
    </message>
    <message>
        <source>Please type an announce URL</source>
        <translation type="obsolete">Введите ссылку анонсирования</translation>
    </message>
    <message>
        <source>Torrent creation was unsuccessful, reason: %1</source>
        <translation type="obsolete">Создание torrent-а не завершено, причина: %1</translation>
    </message>
    <message>
        <source>Announce URL:</source>
        <comment>Tracker URL</comment>
        <translation type="obsolete">Анонсирующий URL:</translation>
    </message>
    <message>
        <source>Please type a web seed url</source>
        <translation type="obsolete">Введите URL веб раздачи</translation>
    </message>
    <message>
        <source>Web seed URL:</source>
        <translation type="obsolete">URL веб раздачи:</translation>
    </message>
    <message>
        <source>Select a file to add to the torrent</source>
        <translation type="obsolete">Выберите файл для добавления в torrent</translation>
    </message>
    <message>
        <source>Created torrent file is invalid. It won&apos;t be added to download list.</source>
        <translation type="obsolete">Созданный torrent файл испорчен. Он не будет добавлен в список закачек.</translation>
    </message>
</context>
<context>
    <name>downloadFromURL</name>
    <message>
        <source>Download Torrents from URLs</source>
        <translation type="obsolete">Скачать торрент из URL</translation>
    </message>
    <message>
        <source>Only one URL per line</source>
        <translation type="obsolete">Только один URL в строке</translation>
    </message>
    <message>
        <source>Download</source>
        <translation>Закачать</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <source>Download from urls</source>
        <translation>Загрузить Torrent(ы) из URL(s)</translation>
    </message>
    <message>
        <source>No URL entered</source>
        <translation>URL не введен</translation>
    </message>
    <message>
        <source>Please type at least one URL.</source>
        <translation>Пожалуйста введите минимум один URL.</translation>
    </message>
    <message>
        <source>Add torrent links</source>
        <translation>Добавить ссылки торрент</translation>
    </message>
    <message>
        <source>Both HTTP and Magnet links are supported</source>
        <translation>Поддреживаются HTTP и Magnet ссылки</translation>
    </message>
</context>
<context>
    <name>downloadThread</name>
    <message>
        <source>I/O Error</source>
        <translation type="obsolete">Ошибка ввода/вывода</translation>
    </message>
    <message>
        <source>The remote host name was not found (invalid hostname)</source>
        <translation type="obsolete">Имя удалённого хоста не было найдено (неправильное имя хоста)</translation>
    </message>
    <message>
        <source>The operation was canceled</source>
        <translation type="obsolete">Операция была отменена</translation>
    </message>
    <message>
        <source>The remote server closed the connection prematurely, before the entire reply was received and processed</source>
        <translation type="obsolete">Удаленный сервер преждевременно закрыл соединение, прежде чем весь ответ был принят и обработан</translation>
    </message>
    <message>
        <source>The connection to the remote server timed out</source>
        <translation type="obsolete">Время соединения с удаленным сервером вышло</translation>
    </message>
    <message>
        <source>SSL/TLS handshake failed</source>
        <translation type="obsolete">Соединение SSL/TLS не удалось</translation>
    </message>
    <message>
        <source>The remote server refused the connection</source>
        <translation type="obsolete">Удаленный сервер отклонил соединение</translation>
    </message>
    <message>
        <source>The connection to the proxy server was refused</source>
        <translation type="obsolete">Соединение с прокси-сервером отклонено</translation>
    </message>
    <message>
        <source>The proxy server closed the connection prematurely</source>
        <translation type="obsolete">Прокси-сервер преждевременно закрыл соединение</translation>
    </message>
    <message>
        <source>The proxy host name was not found</source>
        <translation type="obsolete">Имя прокси-сервера не было найдено</translation>
    </message>
    <message>
        <source>The connection to the proxy timed out or the proxy did not reply in time to the request sent</source>
        <translation type="obsolete">Подключение к прокси-серверу истекло или прокси-сервер не ответил на запрос</translation>
    </message>
    <message>
        <source>The proxy requires authentication in order to honour the request but did not accept any credentials offered</source>
        <translation type="obsolete">Прокси-сервер требует аутентификации, но не принял указанные учетные данные</translation>
    </message>
    <message>
        <source>The access to the remote content was denied (401)</source>
        <translation type="obsolete">В доступе к данным было отказано (401)</translation>
    </message>
    <message>
        <source>The operation requested on the remote content is not permitted</source>
        <translation type="obsolete">Запрошенная операция над данными запрещена</translation>
    </message>
    <message>
        <source>The remote content was not found at the server (404)</source>
        <translation type="obsolete">Данные не были найдены на сервере (404)</translation>
    </message>
    <message>
        <source>The remote server requires authentication to serve the content but the credentials provided were not accepted</source>
        <translation type="obsolete">Удаленный сервер требует аутентификацию для отдачи данных, но указанные учетные данные не были приняты</translation>
    </message>
    <message>
        <source>The Network Access API cannot honor the request because the protocol is not known</source>
        <translation type="obsolete">API сетевого доступа не может выполнить запрос, потому что протокол не известен</translation>
    </message>
    <message>
        <source>The requested operation is invalid for this protocol</source>
        <translation type="obsolete">Запрошенная операция не поддерживается данным протоколом</translation>
    </message>
    <message>
        <source>An unknown network-related error was detected</source>
        <translation type="obsolete">Неизвестная сетевая ошибка</translation>
    </message>
    <message>
        <source>An unknown proxy-related error was detected</source>
        <translation type="obsolete">Неизвестная ошибка прокси-сервера</translation>
    </message>
    <message>
        <source>An unknown error related to the remote content was detected</source>
        <translation type="obsolete">Неизвестная ошибка данных</translation>
    </message>
    <message>
        <source>A breakdown in protocol was detected</source>
        <translation type="obsolete">Ошибка в протоколе</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation type="obsolete">Неизвестная ошибка</translation>
    </message>
</context>
<context>
    <name>engineSelect</name>
    <message>
        <source>Search plugins</source>
        <translation>Плагины поиска</translation>
    </message>
    <message>
        <source>Installed search engines:</source>
        <translation>Установленные плагины поиска:</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <source>Url</source>
        <translation>Ссылка</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Включено</translation>
    </message>
    <message>
        <source>Install a new one</source>
        <translation>Установить новый</translation>
    </message>
    <message>
        <source>Check for updates</source>
        <translation>Проверить обновления</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Закрыть</translation>
    </message>
    <message>
        <source>Enable</source>
        <translation type="obsolete">Включить</translation>
    </message>
    <message>
        <source>Disable</source>
        <translation type="obsolete">Отключить</translation>
    </message>
    <message>
        <source>Uninstall</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <source>You can get new search engine plugins here: &lt;a href=&quot;http://plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</source>
        <translation>Вы можете получить новые плагины поиска здесь: &lt;a href=&quot;http://plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</translation>
    </message>
</context>
<context>
    <name>engineSelectDlg</name>
    <message>
        <source>Uninstall warning</source>
        <translation>Предупреждение об удалении</translation>
    </message>
    <message>
        <source>Some plugins could not be uninstalled because they are included in qBittorrent.
 Only the ones you added yourself can be uninstalled.
However, those plugins were disabled.</source>
        <translation>Некоторые плагины не могут быть удалены, так как включены в qBittorrent.
Удалены могут быть лишь те, что вы установили сами.
Но все равно, эти плагины будут отключены.</translation>
    </message>
    <message>
        <source>Uninstall success</source>
        <translation>Удаление произведено</translation>
    </message>
    <message>
        <source>Select search plugins</source>
        <translation>Выбрать поисковые движки</translation>
    </message>
    <message>
        <source>qBittorrent search plugins</source>
        <translation>Плагин поиска qBittorrent</translation>
    </message>
    <message>
        <source>Search plugin install</source>
        <translation>Установка поискового плагина</translation>
    </message>
    <message>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <source>A more recent version of %1 search engine plugin is already installed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>Самая последняя версия поискового движка %1 уже установлена.</translation>
    </message>
    <message>
        <source>Search plugin update</source>
        <translation>Обновление поисковых плагинов</translation>
    </message>
    <message>
        <source>Sorry, update server is temporarily unavailable.</source>
        <translation>Извините, сервер обновлений временно недоступен.</translation>
    </message>
    <message>
        <source>All your plugins are already up to date.</source>
        <translation>Все ваши плагины имеют последние версии.</translation>
    </message>
    <message>
        <source>%1 search engine plugin could not be updated, keeping old version.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>Плагин поискового движка %1 не может быть обновлен, осталась старая версия.</translation>
    </message>
    <message>
        <source>%1 search engine plugin could not be installed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>Плагин поискового движка %1 не может быть установлен.</translation>
    </message>
    <message>
        <source>All selected plugins were uninstalled successfully</source>
        <translation>Все выбранные плагины были успешно удалены</translation>
    </message>
    <message>
        <source>%1 search engine plugin was successfully updated.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>Плагин поискового движка %1 был успешно обновлен.</translation>
    </message>
    <message>
        <source>%1 search engine plugin was successfully installed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>Плагин поискового движка %1 был успешно установлен.</translation>
    </message>
    <message>
        <source>Sorry, %1 search plugin install failed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>Извините, установка поискового плагина %1 не удалась.</translation>
    </message>
    <message>
        <source>New search engine plugin URL</source>
        <translation>URL нового плагина поискового движка</translation>
    </message>
    <message>
        <source>URL:</source>
        <translation> URL:</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Да</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Нет</translation>
    </message>
</context>
<context>
    <name>misc</name>
    <message>
        <source>B</source>
        <comment>bytes</comment>
        <translation>Б</translation>
    </message>
    <message>
        <source>KiB</source>
        <comment>kibibytes (1024 bytes)</comment>
        <translation>КиБ</translation>
    </message>
    <message>
        <source>MiB</source>
        <comment>mebibytes (1024 kibibytes)</comment>
        <translation>МиБ</translation>
    </message>
    <message>
        <source>GiB</source>
        <comment>gibibytes (1024 mibibytes)</comment>
        <translation>ГиБ</translation>
    </message>
    <message>
        <source>TiB</source>
        <comment>tebibytes (1024 gibibytes)</comment>
        <translation>ТиБ</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Неизвестно</translation>
    </message>
    <message>
        <source>Unknown</source>
        <comment>Unknown (size)</comment>
        <translation>Неизвестно</translation>
    </message>
    <message>
        <source>&lt; 1m</source>
        <comment>&lt; 1 minute</comment>
        <translation>&lt; 1м</translation>
    </message>
    <message>
        <source>%1m</source>
        <comment>e.g: 10minutes</comment>
        <translation>%1м</translation>
    </message>
    <message>
        <source>%1h %2m</source>
        <comment>e.g: 3hours 5minutes</comment>
        <translation>%1ч%2м</translation>
    </message>
    <message>
        <source>%1d %2h</source>
        <comment>e.g: 2days 10hours</comment>
        <translation>%1д%2ч</translation>
    </message>
    <message>
        <source>qBittorrent will shutdown the computer now because all downloads are complete.</source>
        <translation>qBittorent сейчас выключит компьютер, потому что все загрузки завершены.</translation>
    </message>
</context>
<context>
    <name>options_imp</name>
    <message>
        <source>Choose a save directory</source>
        <translation>Выберите путь сохранения</translation>
    </message>
    <message>
        <source>Choose an ip filter file</source>
        <translation>Укажите файл ip фильтра</translation>
    </message>
    <message>
        <source>Filters</source>
        <translation>Фильтры</translation>
    </message>
    <message>
        <source>Choose export directory</source>
        <translation>Выберите папку для экспорта</translation>
    </message>
    <message>
        <source>Add directory to scan</source>
        <translation>Добавить папку для сканирования</translation>
    </message>
    <message>
        <source>Folder is already being watched.</source>
        <translation>Папка уже отслеживается.</translation>
    </message>
    <message>
        <source>Folder does not exist.</source>
        <translation>Папка не существует.</translation>
    </message>
    <message>
        <source>Folder is not readable.</source>
        <translation>Папка не доступна для чтения.</translation>
    </message>
    <message>
        <source>Failure</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <source>Failed to add Scan Folder &apos;%1&apos;: %2</source>
        <translation>Не удалось добавить папку для сканирования &apos;%1&apos;: %2</translation>
    </message>
    <message>
        <source>Parsing error</source>
        <translation>Ошибка разбора</translation>
    </message>
    <message>
        <source>Failed to parse the provided IP filter</source>
        <translation>Не возможно разобрать данный фильтр IP</translation>
    </message>
    <message>
        <source>Succesfully refreshed</source>
        <translation type="obsolete">Успешно обновлен</translation>
    </message>
    <message>
        <source>Successfuly parsed the provided IP filter: %1 rules were applied.</source>
        <comment>%1 is a number</comment>
        <translation>Успешно прочитан данный фильтр IP: %1 правил применено.</translation>
    </message>
    <message>
        <source>Successfully refreshed</source>
        <translation>Успешно обновлён</translation>
    </message>
    <message>
        <source>SSL Certificate (*.crt *.pem)</source>
        <translation>SSL сертификат (*.crt *.pem)</translation>
    </message>
    <message>
        <source>SSL Key (*.key *.pem)</source>
        <translation>SSL ключ (*.key *.pem)</translation>
    </message>
    <message>
        <source>Invalid key</source>
        <translation>Недействительный ключ</translation>
    </message>
    <message>
        <source>This is not a valid SSL key.</source>
        <translation>Это не действительный SSL ключ.</translation>
    </message>
    <message>
        <source>Invalid certificate</source>
        <translation>Недействительный сертификат</translation>
    </message>
    <message>
        <source>This is not a valid SSL certificate.</source>
        <translation>Это не действительный SSL сертификат.</translation>
    </message>
</context>
<context>
    <name>pluginSourceDlg</name>
    <message>
        <source>Plugin source</source>
        <translation>Код плагина</translation>
    </message>
    <message>
        <source>Search plugin source:</source>
        <translation>Код поискового плагина:</translation>
    </message>
    <message>
        <source>Local file</source>
        <translation>Локальный файл</translation>
    </message>
    <message>
        <source>Web link</source>
        <translation>Веб ссылка</translation>
    </message>
</context>
<context>
    <name>preview</name>
    <message>
        <source>Preview selection</source>
        <translation>Выбор предпросмотра</translation>
    </message>
    <message>
        <source>File preview</source>
        <translation>Предпросмотр файла</translation>
    </message>
    <message>
        <source>The following files support previewing, &lt;br&gt;please select one of them:</source>
        <translation>Следующие файлы поддерживают предпросмотр, &lt;br&gt;выберите один из них:</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Предпросмотр</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
</context>
<context>
    <name>previewSelect</name>
    <message>
        <source>Preview impossible</source>
        <translation type="obsolete">Предпросмотр невозможен</translation>
    </message>
    <message>
        <source>Sorry, we can&apos;t preview this file</source>
        <translation type="obsolete">Извините, предпросмотр этого файла невозможен</translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="obsolete">Имя</translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="obsolete">Размер</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation type="obsolete">Состояние</translation>
    </message>
</context>
<context>
    <name>search_engine</name>
    <message>
        <source>Search</source>
        <translation>Поиск</translation>
    </message>
    <message>
        <source>Status:</source>
        <translation>Состояние:</translation>
    </message>
    <message>
        <source>Stopped</source>
        <translation>Остановлено</translation>
    </message>
    <message>
        <source>Download</source>
        <translation>Скачать</translation>
    </message>
    <message>
        <source>Search engines...</source>
        <translation>Поисковые движки...</translation>
    </message>
    <message>
        <source>Go to description page</source>
        <translation>Перейти на страницу описания</translation>
    </message>
</context>
<context>
    <name>torrentAdditionDialog</name>
    <message>
        <source>Unable to decode torrent file:</source>
        <translation>Невозможно декодировать torrent файл:</translation>
    </message>
    <message>
        <source>Choose save path</source>
        <translation>Выберите путь сохранения</translation>
    </message>
    <message>
        <source>Empty save path</source>
        <translation>Очистить путь сохранения</translation>
    </message>
    <message>
        <source>Please enter a save path</source>
        <translation>Пожалуйста, введите путь сохранения</translation>
    </message>
    <message>
        <source>Save path creation error</source>
        <translation>Ошибка создания пути сохранения</translation>
    </message>
    <message>
        <source>Could not create the save path</source>
        <translation>Невозможно создать путь сохранения</translation>
    </message>
    <message>
        <source>Invalid file selection</source>
        <translation>Неправильное выделение файлов</translation>
    </message>
    <message>
        <source>You must select at least one file in the torrent</source>
        <translation>Вы должны выбрать по меньшей мере один файл в torrentе</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Приоритет</translation>
    </message>
    <message>
        <source>(%1 left after torrent download)</source>
        <comment>e.g. (100MiB left after torrent download)</comment>
        <translation>(%1 останется после загрузки торрента)</translation>
    </message>
    <message>
        <source>(%1 more are required to download)</source>
        <comment>e.g. (100MiB more are required to download)</comment>
        <translation>(на %1 больше нужно для загрузки)</translation>
    </message>
    <message>
        <source>Seeding mode error</source>
        <translation>Ошибка режима раздачи</translation>
    </message>
    <message>
        <source>You chose to skip file checking. However, local files do not seem to exist in the current destionation folder. Please disable this feature or update the save path.</source>
        <translation>Вы выбрали пропустить проверку файла. Однако локальные файлы судя по всему не существует в указанной директории. Пожалуйста, отключите это возможность или измените путь сохранения.</translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation>Переименовать...</translation>
    </message>
    <message>
        <source>New name:</source>
        <translation>Новое имя:</translation>
    </message>
    <message>
        <source>The file could not be renamed</source>
        <translation>Файл не может быть переименован</translation>
    </message>
    <message>
        <source>This name is already in use in this folder. Please use a different name.</source>
        <translation>Файл с таким именем уже существует в этой папке. Используйте другое имя.</translation>
    </message>
    <message>
        <source>The folder could not be renamed</source>
        <translation>Папка не может быть переименована</translation>
    </message>
    <message>
        <source>Rename the file</source>
        <translation>Переименовать файл</translation>
    </message>
    <message>
        <source>Unable to decode magnet link:</source>
        <translation>Невозможно декодировать ссылку magnet:</translation>
    </message>
    <message>
        <source>Magnet Link</source>
        <translation>Ссылка magnet</translation>
    </message>
    <message>
        <source>Invalid label name</source>
        <translation>Неправильное имя метки</translation>
    </message>
    <message>
        <source>Please don&apos;t use any special characters in the label name.</source>
        <translation>Пожалуйста, не используйте специальные символы в имени метки.</translation>
    </message>
    <message>
        <source>This file name contains forbidden characters, please choose a different one.</source>
        <translation>Имя файла содержит недопустимые символы. Пожалуйста, выберите другое.</translation>
    </message>
</context>
</TS>
