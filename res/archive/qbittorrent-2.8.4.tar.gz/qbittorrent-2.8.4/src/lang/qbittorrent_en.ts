<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>AboutDlg</name>
    <message>
        <location filename="../about.ui" line="21"/>
        <source>About qBittorrent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../about.ui" line="83"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../about.ui" line="105"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;An advanced BitTorrent client programmed in C++, based on Qt4 toolkit and libtorrent-rasterbar. &lt;br /&gt;&lt;br /&gt;Copyright ©2006-2011 Christophe Dumez&lt;br /&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Home Page:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://www.qbittorrent.org&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans&apos;; text-decoration: underline; color:#0057ae;&quot;&gt;http://www.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Bug Tracker:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://bugs.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;http://bugs.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Forum:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://forum.qbittorrent.org&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans&apos;; text-decoration: underline; color:#0057ae;&quot;&gt;http://forum.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;IRC:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; #qbittorrent on Freenode&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../about.ui" line="134"/>
        <source>Author</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../about.ui" line="157"/>
        <source>Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../about.ui" line="195"/>
        <source>Country:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../about.ui" line="220"/>
        <source>E-mail:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../about.ui" line="164"/>
        <source>Christophe Dumez</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../about.ui" line="202"/>
        <source>France</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../about.ui" line="264"/>
        <source>Translation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../about.ui" line="281"/>
        <source>License</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../about.ui" line="54"/>
        <source>&lt;h3&gt;&lt;b&gt;qBittorrent&lt;/b&gt;&lt;/h3&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../about.ui" line="227"/>
        <source>chris@qbittorrent.org</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../about.ui" line="251"/>
        <source>Thanks to</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AdvancedSettings</name>
    <message>
        <location filename="../preferences/advancedsettings.h" line="160"/>
        <source>Disk write cache size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="159"/>
        <source> MiB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="165"/>
        <source>Outgoing ports (Min) [0: Disabled]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="170"/>
        <source>Outgoing ports (Max) [0: Disabled]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="176"/>
        <source>Recheck torrents on completion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="182"/>
        <source>Transfer list refresh interval</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="181"/>
        <source> ms</source>
        <comment> milliseconds</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="50"/>
        <source>Setting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="50"/>
        <source>Value</source>
        <comment>Value set for this setting</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="185"/>
        <source>Resolve peer countries (GeoIP)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="188"/>
        <source>Resolve peer host names</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="193"/>
        <source>Maximum number of half-open connections [0: Disabled]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="200"/>
        <source>Strict super seeding</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="212"/>
        <source>Network Interface (requires restart)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="240"/>
        <source>Exchange trackers with other peers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="202"/>
        <source>Any interface</source>
        <comment>i.e. Any network interface</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="215"/>
        <source>IP Address to report to trackers (requires restart)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="218"/>
        <source>Display program on-screen notifications</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="221"/>
        <source>Enable embedded tracker</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="226"/>
        <source>Embedded tracker port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="229"/>
        <source>Check for software updates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="233"/>
        <source>Use system icon theme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="237"/>
        <source>Confirm torrent deletion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="173"/>
        <source>Ignore transfer limits on local network</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AutomatedRssDownloader</name>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="14"/>
        <source>Automated RSS Downloader</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="26"/>
        <source>Enable the automated RSS downloader</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="48"/>
        <source>Download rules</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="123"/>
        <source>Rule definition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="138"/>
        <source>Must contain:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="180"/>
        <source>Must not contain:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="129"/>
        <source>Use regular expressions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="355"/>
        <source>Import...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="362"/>
        <source>Export...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="286"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="233"/>
        <source>Assign label:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="252"/>
        <source>Save to a different directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="264"/>
        <source>Save to:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="308"/>
        <source>Apply rule to feeds:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="330"/>
        <source>Matching RSS articles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="304"/>
        <source>New rule name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="304"/>
        <source>Please type the name of the new download rule.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="308"/>
        <location filename="../rss/automatedrssdownloader.cpp" line="423"/>
        <source>Rule name conflict</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="308"/>
        <location filename="../rss/automatedrssdownloader.cpp" line="423"/>
        <source>A rule with this name already exists, please choose another name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="326"/>
        <source>Are you sure you want to remove the download rule named %1?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="328"/>
        <source>Are you sure you want to remove the selected download rules?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="329"/>
        <source>Rule deletion confirmation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="345"/>
        <source>Destination directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="353"/>
        <source>Invalid action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="353"/>
        <source>The list is empty, there is nothing to export.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="357"/>
        <source>Where would you like to save the list?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="357"/>
        <source>Rules list (*.rssrules)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="362"/>
        <source>I/O Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="362"/>
        <source>Failed to create the destination file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="370"/>
        <source>Please point to the RSS download rules file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="370"/>
        <source>Rules list (*.rssrules *.filters)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="374"/>
        <source>Import Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="374"/>
        <source>Failed to import the selected rules file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="385"/>
        <source>Add new rule...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="391"/>
        <source>Delete rule</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="393"/>
        <source>Rename rule...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="395"/>
        <source>Delete selected rules</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="419"/>
        <source>Rule renaming</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="419"/>
        <source>Please type the new rule name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="521"/>
        <source>Regex mode: use Perl-like regular expressions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="525"/>
        <source>Wildcard mode: you can use&lt;ul&gt;&lt;li&gt;? to match any single character&lt;/li&gt;&lt;li&gt;* to match zero or more of any characters&lt;/li&gt;&lt;li&gt;Whitespaces count as AND operators&lt;/li&gt;&lt;/ul&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="527"/>
        <source>Wildcard mode: you can use&lt;ul&gt;&lt;li&gt;? to match any single character&lt;/li&gt;&lt;li&gt;* to match zero or more of any characters&lt;/li&gt;&lt;li&gt;| is used as OR operator&lt;/li&gt;&lt;/ul&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CookiesDlg</name>
    <message>
        <location filename="../rss/cookiesdlg.ui" line="14"/>
        <source>Cookies management</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/cookiesdlg.ui" line="36"/>
        <source>Key</source>
        <extracomment>As in Key/Value pair</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/cookiesdlg.ui" line="41"/>
        <source>Value</source>
        <extracomment>As in Key/Value pair</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/cookiesdlg.cpp" line="48"/>
        <source>Common keys for cookies are : &apos;%1&apos;, &apos;%2&apos;.
You should get this information from your Web browser preferences.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DNSUpdater</name>
    <message>
        <location filename="../dnsupdater.cpp" line="178"/>
        <source>Your dynamic DNS was successfuly updated.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dnsupdater.cpp" line="182"/>
        <source>Dynamic DNS error: The service is temporarily unavailable, it will be retried in 30 minutes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dnsupdater.cpp" line="192"/>
        <source>Dynamic DNS error: hostname supplied does not exist under specified account.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dnsupdater.cpp" line="198"/>
        <source>Dynamic DNS error: Invalid username/password.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dnsupdater.cpp" line="203"/>
        <source>Dynamic DNS error: qBittorrent was blacklisted by the service, please report a bug at http://bugs.qbittorrent.org.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dnsupdater.cpp" line="209"/>
        <source>Dynamic DNS error: %1 was returned by the service, please report a bug at http://bugs.qbittorrent.org.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dnsupdater.cpp" line="215"/>
        <source>Dynamic DNS error: Your username was blocked due to abuse.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dnsupdater.cpp" line="236"/>
        <source>Dynamic DNS error: supplied domain name is invalid.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dnsupdater.cpp" line="248"/>
        <source>Dynamic DNS error: supplied username is too short.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dnsupdater.cpp" line="260"/>
        <source>Dynamic DNS error: supplied password is too short.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DownloadThread</name>
    <message>
        <location filename="../downloadthread.cpp" line="98"/>
        <location filename="../downloadthread.cpp" line="102"/>
        <source>I/O Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="209"/>
        <source>The remote host name was not found (invalid hostname)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="211"/>
        <source>The operation was canceled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="213"/>
        <source>The remote server closed the connection prematurely, before the entire reply was received and processed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="215"/>
        <source>The connection to the remote server timed out</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="217"/>
        <source>SSL/TLS handshake failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="219"/>
        <source>The remote server refused the connection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="221"/>
        <source>The connection to the proxy server was refused</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="223"/>
        <source>The proxy server closed the connection prematurely</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="225"/>
        <source>The proxy host name was not found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="227"/>
        <source>The connection to the proxy timed out or the proxy did not reply in time to the request sent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="229"/>
        <source>The proxy requires authentication in order to honour the request but did not accept any credentials offered</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="231"/>
        <source>The access to the remote content was denied (401)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="233"/>
        <source>The operation requested on the remote content is not permitted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="235"/>
        <source>The remote content was not found at the server (404)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="237"/>
        <source>The remote server requires authentication to serve the content but the credentials provided were not accepted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="239"/>
        <source>The Network Access API cannot honor the request because the protocol is not known</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="241"/>
        <source>The requested operation is invalid for this protocol</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="243"/>
        <source>An unknown network-related error was detected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="245"/>
        <source>An unknown proxy-related error was detected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="247"/>
        <source>An unknown error related to the remote content was detected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="249"/>
        <source>A breakdown in protocol was detected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="251"/>
        <source>Unknown error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EventManager</name>
    <message>
        <location filename="../webui/eventmanager.cpp" line="73"/>
        <location filename="../webui/eventmanager.cpp" line="87"/>
        <source>Working</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/eventmanager.cpp" line="76"/>
        <source>Updating...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/eventmanager.cpp" line="79"/>
        <location filename="../webui/eventmanager.cpp" line="90"/>
        <source>Not working</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/eventmanager.cpp" line="81"/>
        <location filename="../webui/eventmanager.cpp" line="92"/>
        <source>Not contacted yet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/eventmanager.cpp" line="405"/>
        <location filename="../webui/eventmanager.cpp" line="406"/>
        <source>this session</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/eventmanager.cpp" line="410"/>
        <location filename="../webui/eventmanager.cpp" line="414"/>
        <source>/s</source>
        <comment>/second (i.e. per second)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/eventmanager.cpp" line="417"/>
        <source>Seeded for %1</source>
        <comment>e.g. Seeded for 3m10s</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/eventmanager.cpp" line="420"/>
        <source>%1 max</source>
        <comment>e.g. 10 max</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/eventmanager.cpp" line="499"/>
        <location filename="../webui/eventmanager.cpp" line="508"/>
        <source>%1/s</source>
        <comment>e.g. 120 KiB/s</comment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ExecutionLog</name>
    <message>
        <location filename="../executionlog.ui" line="27"/>
        <source>General</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../executionlog.ui" line="41"/>
        <source>Blocked IPs</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FeedListWidget</name>
    <message>
        <location filename="../rss/feedlistwidget.cpp" line="41"/>
        <source>RSS feeds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/feedlistwidget.cpp" line="43"/>
        <source>Unread</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HeadlessLoader</name>
    <message>
        <location filename="../headlessloader.h" line="54"/>
        <source>Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../headlessloader.h" line="55"/>
        <source>To control qBittorrent, access the Web UI at http://localhost:%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../headlessloader.h" line="56"/>
        <source>The Web UI administrator user name is: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../headlessloader.h" line="59"/>
        <source>The Web UI administrator password is still the default one: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../headlessloader.h" line="60"/>
        <source>This is a security risk, please consider changing your password from program preferences.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HttpConnection</name>
    <message>
        <location filename="../webui/httpconnection.cpp" line="150"/>
        <source>Your IP address has been banned after too many failed authentication attempts.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/httpconnection.cpp" line="345"/>
        <source>D: %1/s - T: %2</source>
        <comment>Download speed: x KiB/s - Transferred: x MiB</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/httpconnection.cpp" line="346"/>
        <source>U: %1/s - T: %2</source>
        <comment>Upload speed: x KiB/s - Transferred: x MiB</comment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HttpServer</name>
    <message>
        <location filename="../webui/httpserver.cpp" line="120"/>
        <source>File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="121"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="122"/>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="123"/>
        <source>Download Torrents from their URL or Magnet link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="124"/>
        <source>Only one link per line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="125"/>
        <source>Download local torrent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="126"/>
        <source>Torrent files were correctly added to download list.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="127"/>
        <source>Point to torrent file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="128"/>
        <source>Download</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="129"/>
        <source>Are you sure you want to delete the selected torrents from the transfer list and hard disk?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="130"/>
        <source>Download rate limit must be greater than 0 or disabled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="131"/>
        <source>Upload rate limit must be greater than 0 or disabled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="132"/>
        <source>Maximum number of connections limit must be greater than 0 or disabled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="133"/>
        <source>Maximum number of connections per torrent limit must be greater than 0 or disabled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="134"/>
        <source>Maximum number of upload slots per torrent limit must be greater than 0 or disabled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="135"/>
        <source>Unable to save program preferences, qBittorrent is probably unreachable.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="136"/>
        <source>Language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="137"/>
        <source>Downloaded</source>
        <comment>Is the file downloaded or not?</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="138"/>
        <source>The port used for incoming connections must be greater than 1024 and less than 65535.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="139"/>
        <source>The port used for the Web UI must be greater than 1024 and less than 65535.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="140"/>
        <source>The Web UI username must be at least 3 characters long.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="141"/>
        <source>The Web UI password must be at least 3 characters long.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="142"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="143"/>
        <source>qBittorrent client is not reachable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="144"/>
        <source>HTTP Server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="145"/>
        <source>The following parameters are supported:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="146"/>
        <source>Torrent path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="147"/>
        <source>Torrent name</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LegalNotice</name>
    <message>
        <location filename="../main.cpp" line="93"/>
        <source>Legal Notice</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.cpp" line="94"/>
        <location filename="../main.cpp" line="105"/>
        <source>qBittorrent is a file sharing program. When you run a torrent, its data will be made available to others by means of upload. Any content you share is your sole responsibility.

No further notices will be issued.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.cpp" line="95"/>
        <source>Press %1 key to accept and continue...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.cpp" line="106"/>
        <source>Legal notice</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.cpp" line="107"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.cpp" line="108"/>
        <source>I Agree</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LineEdit</name>
    <message>
        <location filename="../lineedit/src/lineedit.cpp" line="30"/>
        <source>Clear the text</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="37"/>
        <source>&amp;Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="60"/>
        <source>&amp;Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="79"/>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="50"/>
        <source>&amp;Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="88"/>
        <source>&amp;View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="148"/>
        <source>&amp;Options...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="158"/>
        <source>&amp;Resume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="314"/>
        <source>R&amp;esume All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="187"/>
        <source>Torrent &amp;creator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="241"/>
        <location filename="../mainwindow.ui" line="244"/>
        <source>Alternative speed limits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="252"/>
        <source>Top &amp;tool bar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="255"/>
        <source>Display top tool bar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="263"/>
        <source>&amp;Speed in title bar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="266"/>
        <source>Show transfer speed in title bar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="153"/>
        <source>&amp;About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="135"/>
        <source>&amp;Add torrent file...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="140"/>
        <location filename="../mainwindow.ui" line="143"/>
        <source>Exit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="163"/>
        <source>&amp;Pause</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="168"/>
        <source>&amp;Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="319"/>
        <source>P&amp;ause All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="177"/>
        <source>Visit &amp;Website</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="64"/>
        <source>Auto-Shutdown on downloads completion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="182"/>
        <source>Add &amp;link to torrent...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="192"/>
        <source>Report a &amp;bug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="197"/>
        <source>Set upload limit...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="202"/>
        <source>Set download limit...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="207"/>
        <source>&amp;Documentation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="212"/>
        <source>Set global download limit...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="217"/>
        <source>Set global upload limit...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="274"/>
        <source>&amp;RSS reader</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="282"/>
        <source>Search &amp;engine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="338"/>
        <source>Exit qBittorrent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="346"/>
        <source>Suspend system</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="354"/>
        <source>Shutdown system</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="362"/>
        <source>Disabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="287"/>
        <location filename="../mainwindow.ui" line="290"/>
        <source>Lock qBittorrent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="293"/>
        <source>Ctrl+L</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="298"/>
        <source>Import existing torrent...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="301"/>
        <source>Import torrent...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="306"/>
        <source>Donate money</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="309"/>
        <source>If you like qBittorrent, please donate!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="327"/>
        <source>Execution &amp;Log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="330"/>
        <location filename="../mainwindow.cpp" line="1327"/>
        <source>Execution Log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="222"/>
        <source>Decrease priority</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="230"/>
        <source>Increase priority</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="103"/>
        <location filename="../mainwindow.cpp" line="1251"/>
        <source>qBittorrent %1</source>
        <comment>e.g: qBittorrent v0.x</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="140"/>
        <source>Set the password...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="174"/>
        <source>Transfers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="287"/>
        <source>Torrent file association</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="288"/>
        <source>qBittorrent is not the default application to open torrent files or Magnet links.
Do you want to associate qBittorrent to torrent files and Magnet links?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="381"/>
        <location filename="../mainwindow.cpp" line="401"/>
        <location filename="../mainwindow.cpp" line="651"/>
        <source>UI lock password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="381"/>
        <location filename="../mainwindow.cpp" line="401"/>
        <location filename="../mainwindow.cpp" line="651"/>
        <source>Please type the UI lock password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="385"/>
        <source>The password should contain at least 3 characters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="391"/>
        <source>Password update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="391"/>
        <source>The UI lock password has been successfully updated</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="417"/>
        <source>RSS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="432"/>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="442"/>
        <source>Transfers (%1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="513"/>
        <source>Download completion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="513"/>
        <source>%1 has finished downloading.</source>
        <comment>e.g: xxx.avi has finished downloading.</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="519"/>
        <source>I/O Error</source>
        <comment>i.e: Input/Output Error</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="519"/>
        <source>An I/O error occured for torrent %1.
 Reason: %2</source>
        <comment>e.g: An error occured for torrent xxx.avi.
 Reason: disk is full.</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="526"/>
        <source>Alt+1</source>
        <comment>shortcut to switch to first tab</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="528"/>
        <source>Alt+2</source>
        <comment>shortcut to switch to third tab</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="530"/>
        <source>Ctrl+F</source>
        <comment>shortcut to switch to search tab</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="532"/>
        <source>Alt+3</source>
        <comment>shortcut to switch to fourth tab</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="572"/>
        <source>Recursive download confirmation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="572"/>
        <source>The torrent %1 contains torrent files, do you want to proceed with their download?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="573"/>
        <location filename="../mainwindow.cpp" line="744"/>
        <source>Yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="574"/>
        <location filename="../mainwindow.cpp" line="743"/>
        <source>No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="575"/>
        <source>Never</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="589"/>
        <source>Url download error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="589"/>
        <source>Couldn&apos;t download file at url: %1, reason: %2.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="600"/>
        <source>Global Upload Speed Limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="619"/>
        <source>Global Download Speed Limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="385"/>
        <location filename="../mainwindow.cpp" line="664"/>
        <source>Invalid password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="664"/>
        <source>The password is invalid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="740"/>
        <source>Exiting qBittorrent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="741"/>
        <source>Some files are currently transferring.
Are you sure you want to quit qBittorrent?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="745"/>
        <source>Always</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="903"/>
        <source>Open Torrent Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="904"/>
        <source>Torrent Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="983"/>
        <source>Options were saved successfully.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1092"/>
        <source>qBittorrent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1095"/>
        <location filename="../mainwindow.cpp" line="1102"/>
        <source>DL speed: %1 KiB/s</source>
        <comment>e.g: Download speed: 10 KiB/s</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1098"/>
        <location filename="../mainwindow.cpp" line="1104"/>
        <source>UP speed: %1 KiB/s</source>
        <comment>e.g: Upload speed: 10 KiB/s</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1109"/>
        <source>qBittorrent %1 (Down: %2/s, Up: %3/s)</source>
        <comment>%1 is qBittorrent version</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1289"/>
        <source>A newer version is available</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1290"/>
        <source>A newer version of qBittorrent is available on Sourceforge.
Would you like to update qBittorrent to version %1?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1305"/>
        <source>Impossible to update qBittorrent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1305"/>
        <source>qBittorrent failed to update, reason: %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PeerAdditionDlg</name>
    <message>
        <location filename="../properties/peeraddition.h" line="94"/>
        <source>Invalid IP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/peeraddition.h" line="95"/>
        <source>The IP you provided is invalid.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PeerListDelegate</name>
    <message>
        <location filename="../properties/peerlistdelegate.h" line="64"/>
        <source>/s</source>
        <comment>/second (i.e. per second)</comment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PeerListWidget</name>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="61"/>
        <source>IP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="62"/>
        <source>Connection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="63"/>
        <source>Client</source>
        <comment>i.e.: Client application</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="64"/>
        <source>Progress</source>
        <comment>i.e: % downloaded</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="65"/>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="66"/>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="67"/>
        <source>Downloaded</source>
        <comment>i.e: total data downloaded</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="68"/>
        <source>Uploaded</source>
        <comment>i.e: total data uploaded</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="139"/>
        <source>Add a new peer...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="148"/>
        <source>Copy IP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="150"/>
        <source>Limit download rate...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="151"/>
        <source>Limit upload rate...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="153"/>
        <source>Ban peer permanently</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="164"/>
        <location filename="../properties/peerlistwidget.cpp" line="166"/>
        <source>Peer addition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="164"/>
        <source>The peer was added to this torrent.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="166"/>
        <source>The peer could not be added to this torrent.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="196"/>
        <source>Are you sure? -- qBittorrent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="196"/>
        <source>Are you sure you want to ban permanently the selected peers?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="197"/>
        <source>&amp;Yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="197"/>
        <source>&amp;No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="202"/>
        <source>Manually banning peer %1...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="221"/>
        <source>Upload rate limiting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="249"/>
        <source>Download rate limiting</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Preferences</name>
    <message>
        <location filename="../preferences/options.ui" line="93"/>
        <source>Downloads</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="104"/>
        <source>Connection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="115"/>
        <source>Speed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="134"/>
        <source>Web UI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="145"/>
        <source>Advanced</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="219"/>
        <source>(Requires restart)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="253"/>
        <source>Use alternating row colors</source>
        <extracomment>In transfer list, one every two rows will have grey background.</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="301"/>
        <location filename="../preferences/options.ui" line="327"/>
        <source>Start / Stop Torrent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="311"/>
        <location filename="../preferences/options.ui" line="337"/>
        <source>No action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="659"/>
        <source>Append .!qB extension to incomplete files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="762"/>
        <source>Copy .torrent files to:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="918"/>
        <source>The following parameters are supported:
&lt;ul&gt;
&lt;li&gt;%f: Torrent path&lt;/li&gt;
&lt;li&gt;%n: Torrent name&lt;/li&gt;
&lt;/ul&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1025"/>
        <source>Connections Limits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1145"/>
        <source>Proxy Server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1402"/>
        <source>Global Rate Limits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1520"/>
        <source>Apply rate limit to uTP connections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1527"/>
        <source>Apply rate limit to transport overhead</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1540"/>
        <source>Alternative Global Rate Limits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1646"/>
        <source>Schedule the use of alternative rate limits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1909"/>
        <source>Enable Local Peer Discovery to find more peers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1921"/>
        <source>Encryption mode:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1929"/>
        <source>Prefer encryption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1934"/>
        <source>Require encryption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1939"/>
        <source>Disable encryption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1980"/>
        <source>Maximum active downloads:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2000"/>
        <source>Maximum active uploads:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2020"/>
        <source>Maximum active torrents:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="504"/>
        <source>When adding a torrent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="79"/>
        <location filename="../preferences/options.ui" line="82"/>
        <source>Behavior</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="182"/>
        <source>Language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="513"/>
        <source>Display torrent content and some options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="968"/>
        <source>Port used for incoming connections:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="988"/>
        <source>Random</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1031"/>
        <source>Global maximum number of connections:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1057"/>
        <source>Maximum number of connections per torrent:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1080"/>
        <source>Maximum number of upload slots per torrent:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1420"/>
        <location filename="../preferences/options.ui" line="1575"/>
        <source>Upload:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1456"/>
        <location filename="../preferences/options.ui" line="1602"/>
        <source>Download:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1449"/>
        <location filename="../preferences/options.ui" line="1482"/>
        <location filename="../preferences/options.ui" line="1595"/>
        <location filename="../preferences/options.ui" line="1622"/>
        <source>KiB/s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="729"/>
        <source>Remove folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1687"/>
        <source>to</source>
        <extracomment>time1 to time2</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1739"/>
        <source>Every day</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1744"/>
        <source>Week days</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1749"/>
        <source>Week ends</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1852"/>
        <source>DHT port:</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../preferences/options.ui" line="1893"/>
        <source>Exchange peers with compatible Bittorrent clients (µTorrent, Vuze, ...)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1187"/>
        <source>Host:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1166"/>
        <source>SOCKS4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1153"/>
        <source>Type:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="20"/>
        <location filename="../preferences/options.ui" line="1504"/>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="269"/>
        <source>Action on double-click</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="284"/>
        <source>Downloading torrents:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="306"/>
        <location filename="../preferences/options.ui" line="332"/>
        <source>Open destination folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="319"/>
        <source>Completed torrents:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="351"/>
        <source>Desktop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="357"/>
        <source>Show splash screen on start up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="367"/>
        <source>Start qBittorrent minimized</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="393"/>
        <source>Minimize qBittorrent to notification area</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="403"/>
        <source>Close qBittorrent to notification area</source>
        <comment>i.e: The systray tray icon will still be visible when closing the main window.</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="412"/>
        <source>Tray icon style:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="420"/>
        <source>Normal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="425"/>
        <source>Monochrome (Dark theme)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="430"/>
        <source>Monochrome (Light theme)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="374"/>
        <source>Ask for program exit confirmation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="190"/>
        <source>User Interface Language:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="247"/>
        <source>Transfer List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="384"/>
        <source>Show qBittorrent in notification area</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="446"/>
        <source>Power Management</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="452"/>
        <source>Inhibit system sleep when torrents are active</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="523"/>
        <source>Do not start the download automatically</source>
        <comment>The torrent will be added to download list in pause state</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="539"/>
        <source>Hard Disk</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="548"/>
        <source>Save files to location:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="596"/>
        <source>Append the label of the torrent to the save path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="606"/>
        <source>Pre-allocate disk space for all files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="613"/>
        <source>Keep incomplete torrents in:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="666"/>
        <source>Automatically add torrents from:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="719"/>
        <source>Add folder...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="818"/>
        <source>Email notification upon download completion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="832"/>
        <source>Destination email:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="842"/>
        <source>SMTP server:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="891"/>
        <source>This server requires a secure connection (SSL)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="903"/>
        <source>Run an external program on torrent completion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="960"/>
        <source>Listening Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1010"/>
        <source>Use UPnP / NAT-PMP port forwarding from my router</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1241"/>
        <source>Otherwise, the proxy server is only used for tracker connections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1244"/>
        <source>Use proxy for peer connections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1316"/>
        <source>IP Filtering</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1357"/>
        <source>Reload the filter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1510"/>
        <source>Enable bandwidth management (uTP)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1663"/>
        <source>from</source>
        <extracomment>from (time1 to time2)</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1731"/>
        <source>When:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1814"/>
        <source>Privacy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1820"/>
        <source>Enable DHT (decentralized network) to find more peers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1832"/>
        <source>Use a different port for DHT and BitTorrent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1896"/>
        <source>Enable Peer Exchange (PeX) to find more peers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1906"/>
        <source>Look for peers on your local network</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2093"/>
        <source>Seed torrents until their ratio reaches</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2125"/>
        <source>then</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2136"/>
        <source>Pause them</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2141"/>
        <source>Remove them</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2239"/>
        <source>Use UPnP / NAT-PMP to forward the port from my router</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2249"/>
        <source>Use HTTPS instead of HTTP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2292"/>
        <source>Import SSL Certificate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2345"/>
        <source>Import SSL Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2280"/>
        <source>Certificate:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2333"/>
        <source>Key:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2367"/>
        <source>&lt;a href=http://httpd.apache.org/docs/2.1/ssl/ssl_faq.html#aboutcerts&gt;Information about certificates&lt;/a&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2412"/>
        <source>Bypass authentication for localhost</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2436"/>
        <source>Update my dynamic domain name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2448"/>
        <source>Service:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2471"/>
        <source>Register</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2480"/>
        <source>Domain name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1161"/>
        <source>(None)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="123"/>
        <source>BitTorrent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1176"/>
        <source>HTTP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1213"/>
        <location filename="../preferences/options.ui" line="2204"/>
        <source>Port:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="852"/>
        <location filename="../preferences/options.ui" line="1254"/>
        <location filename="../preferences/options.ui" line="2380"/>
        <source>Authentication</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="864"/>
        <location filename="../preferences/options.ui" line="1268"/>
        <location filename="../preferences/options.ui" line="2419"/>
        <location filename="../preferences/options.ui" line="2494"/>
        <source>Username:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="874"/>
        <location filename="../preferences/options.ui" line="1288"/>
        <location filename="../preferences/options.ui" line="2426"/>
        <location filename="../preferences/options.ui" line="2508"/>
        <source>Password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1965"/>
        <source>Torrent Queueing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2082"/>
        <source>Share Ratio Limiting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2190"/>
        <source>Enable Web User Interface (Remote control)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1171"/>
        <source>SOCKS5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1328"/>
        <source>Filter path (.dat, .p2p, .p2b):</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PreviewSelect</name>
    <message>
        <location filename="../previewselect.cpp" line="48"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../previewselect.cpp" line="49"/>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../previewselect.cpp" line="50"/>
        <source>Progress</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../previewselect.cpp" line="75"/>
        <location filename="../previewselect.cpp" line="110"/>
        <location filename="../previewselect.cpp" line="116"/>
        <source>Preview impossible</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../previewselect.cpp" line="75"/>
        <location filename="../previewselect.cpp" line="110"/>
        <location filename="../previewselect.cpp" line="116"/>
        <source>Sorry, we can&apos;t preview this file</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PropListDelegate</name>
    <message>
        <location filename="../properties/proplistdelegate.h" line="107"/>
        <source>Not downloaded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/proplistdelegate.h" line="116"/>
        <location filename="../properties/proplistdelegate.h" line="171"/>
        <source>Normal</source>
        <comment>Normal (priority)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/proplistdelegate.h" line="110"/>
        <location filename="../properties/proplistdelegate.h" line="172"/>
        <source>High</source>
        <comment>High (priority)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/proplistdelegate.h" line="104"/>
        <source>Mixed</source>
        <comment>Mixed (priorities</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/proplistdelegate.h" line="113"/>
        <location filename="../properties/proplistdelegate.h" line="173"/>
        <source>Maximum</source>
        <comment>Maximum (priority)</comment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PropTabBar</name>
    <message>
        <location filename="../properties/proptabbar.cpp" line="55"/>
        <source>General</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/proptabbar.cpp" line="62"/>
        <source>Trackers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/proptabbar.cpp" line="68"/>
        <source>Peers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/proptabbar.cpp" line="74"/>
        <source>HTTP Sources</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/proptabbar.cpp" line="80"/>
        <source>Content</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PropertiesWidget</name>
    <message>
        <location filename="../properties/propertieswidget.ui" line="351"/>
        <source>Save path:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="459"/>
        <source>Torrent hash:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="211"/>
        <source>Share ratio:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="82"/>
        <location filename="../properties/propertieswidget.ui" line="228"/>
        <source>Downloaded:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="136"/>
        <source>Availability:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="171"/>
        <source>Transfer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="177"/>
        <source>Uploaded:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="279"/>
        <source>Wasted:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="194"/>
        <source>UP limit:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="245"/>
        <source>DL limit:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="262"/>
        <source>Connections:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="296"/>
        <source>Time active:</source>
        <extracomment>Time (duration) the torrent is active (not paused)</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="313"/>
        <source>Reannounce in:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="339"/>
        <source>Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="413"/>
        <source>Created on:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="502"/>
        <source>Pieces size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="545"/>
        <source>Comment:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="774"/>
        <source>Torrent content:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="827"/>
        <source>Select All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="834"/>
        <source>Select None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="867"/>
        <source>Normal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="872"/>
        <source>High</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="877"/>
        <source>Maximum</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="882"/>
        <location filename="../properties/propertieswidget.ui" line="885"/>
        <source>Do not download</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="329"/>
        <location filename="../properties/propertieswidget.cpp" line="330"/>
        <source>this session</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="334"/>
        <location filename="../properties/propertieswidget.cpp" line="338"/>
        <source>/s</source>
        <comment>/second (i.e. per second)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="341"/>
        <source>Seeded for %1</source>
        <comment>e.g. Seeded for 3m10s</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="345"/>
        <source>%1 max</source>
        <comment>e.g. 10 max</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="435"/>
        <location filename="../properties/propertieswidget.cpp" line="457"/>
        <source>I/O Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="435"/>
        <source>This file does not exist yet.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="457"/>
        <source>This folder does not exist yet.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="467"/>
        <source>Rename...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="476"/>
        <source>Priority</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="518"/>
        <source>Rename the file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="519"/>
        <source>New name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="523"/>
        <location filename="../properties/propertieswidget.cpp" line="555"/>
        <source>The file could not be renamed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="524"/>
        <source>This file name contains forbidden characters, please choose a different one.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="556"/>
        <location filename="../properties/propertieswidget.cpp" line="594"/>
        <source>This name is already in use in this folder. Please use a different name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="593"/>
        <source>The folder could not be renamed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="632"/>
        <source>New url seed</source>
        <comment>New HTTP source</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="633"/>
        <source>New url seed:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="638"/>
        <source>qBittorrent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="639"/>
        <source>This url seed is already in the list.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="681"/>
        <location filename="../properties/propertieswidget.cpp" line="684"/>
        <source>Choose save path</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QBtSession</name>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="226"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="232"/>
        <source>%1 reached the maximum ratio you set.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="227"/>
        <source>Removing torrent %1...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="233"/>
        <source>Pausing torrent %1...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="287"/>
        <source>qBittorrent is bound to port: TCP/%1</source>
        <comment>e.g: qBittorrent is bound to port: 6881</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="384"/>
        <source>HTTP user agent is %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="440"/>
        <source>Reporting IP address %1 to trackers...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="494"/>
        <source>DHT support [ON], port: UDP/%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="496"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="500"/>
        <source>DHT support [OFF]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="504"/>
        <source>PeX support [ON]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="506"/>
        <source>PeX support [OFF]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="509"/>
        <source>Restart is required to toggle PeX support</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="517"/>
        <source>Local Peer Discovery support [OFF]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="529"/>
        <source>Encryption support [ON]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="534"/>
        <source>Encryption support [FORCED]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="539"/>
        <source>Encryption support [OFF]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="600"/>
        <source>Embedded Tracker [ON]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="602"/>
        <source>Failed to start the embedded tracker!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="605"/>
        <source>Embedded Tracker [OFF]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="659"/>
        <source>The Web UI is listening on port %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="661"/>
        <source>Web User Interface Error - Unable to bind Web UI to port %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="796"/>
        <source>&apos;%1&apos; was removed from transfer list and hard disk.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="798"/>
        <source>&apos;%1&apos; was removed from transfer list.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="880"/>
        <source>&apos;%1&apos; is not a valid magnet URI.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="896"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1018"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1023"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1025"/>
        <source>&apos;%1&apos; is already in download list.</source>
        <comment>e.g: &apos;xxx.avi&apos; is already in download list.</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1169"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1177"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1182"/>
        <source>&apos;%1&apos; resumed. (fast resume)</source>
        <comment>&apos;/home/y/xxx.torrent&apos; was resumed. (fast resume)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2260"/>
        <source>The computer will now go to sleep mode unless you cancel within the next 15 seconds...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2262"/>
        <source>The computer will now be switched off unless you cancel within the next 15 seconds...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2264"/>
        <source>qBittorrent will now exit unless you cancel within the next 15 seconds...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2871"/>
        <source>Successfuly parsed the provided IP filter: %1 rules were applied.</source>
        <comment>%1 is a number</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2877"/>
        <source>Error: Failed to parse the provided IP filter.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="952"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1171"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1179"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1184"/>
        <source>&apos;%1&apos; added to download list.</source>
        <comment>&apos;/home/y/xxx.torrent&apos; was added to download list.</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="375"/>
        <source>UPnP / NAT-PMP support [ON]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="378"/>
        <source>UPnP / NAT-PMP support [OFF]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="514"/>
        <source>Local Peer Discovery support [ON]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="987"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="994"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="996"/>
        <source>Unable to decode torrent file: &apos;%1&apos;</source>
        <comment>e.g: Unable to decode torrent file: &apos;/home/y/xxx.torrent&apos;</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1000"/>
        <source>This file is either corrupted or this isn&apos;t a torrent.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1040"/>
        <source>Error: The torrent %1 does not contain any file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1328"/>
        <source>Note: new trackers were added to the existing torrent.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1354"/>
        <source>Note: new URL seeds were added to the existing torrent.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1710"/>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;was blocked due to your IP filter&lt;/i&gt;</source>
        <comment>x.y.z.w was blocked</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1712"/>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;was banned due to corrupt pieces&lt;/i&gt;</source>
        <comment>x.y.z.w was banned</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1890"/>
        <source>The network interface defined is invalid: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1891"/>
        <source>Trying any other network interface available instead.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1914"/>
        <source>Listening on IP address %1 on network interface %2...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1917"/>
        <source>Failed to listen on network interface %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2113"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2115"/>
        <source>Recursive download of file %1 embedded in torrent %2</source>
        <comment>Recursive download of test.torrent embedded in torrent test2</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2210"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2212"/>
        <source>Unable to decode %1 torrent file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2160"/>
        <source>Torrent name: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2161"/>
        <source>Torrent size: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2162"/>
        <source>Save path: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2163"/>
        <source>The torrent was downloaded in %1.</source>
        <comment>The torrent was downloaded in 1 hour and 20 seconds</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2164"/>
        <source>Thank you for using qBittorrent.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2167"/>
        <source>[qBittorrent] %1 has finished downloading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2427"/>
        <source>An I/O error occured, &apos;%1&apos; paused.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2428"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2558"/>
        <source>Reason: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2517"/>
        <source>UPnP/NAT-PMP: Port mapping failure, message: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2522"/>
        <source>UPnP/NAT-PMP: Port mapping successful, message: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2553"/>
        <source>File sizes mismatch for torrent %1, pausing it.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2557"/>
        <source>Fast resume data was rejected for torrent %1, checking again...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2563"/>
        <source>Url seed lookup failed for url: %1, message: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2692"/>
        <source>Downloading &apos;%1&apos;, please wait...</source>
        <comment>e.g: Downloading &apos;xxx.torrent&apos;, please wait...</comment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RSS</name>
    <message>
        <location filename="../rss/rss.ui" line="17"/>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="25"/>
        <source>New subscription</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="35"/>
        <location filename="../rss/rss.ui" line="183"/>
        <location filename="../rss/rss.ui" line="186"/>
        <source>Mark items read</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="54"/>
        <source>Update all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="83"/>
        <source>RSS Downloader...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="90"/>
        <source>Settings...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="112"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Torrents:&lt;/span&gt; &lt;span style=&quot; font-style:italic;&quot;&gt;(double-click to download)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="146"/>
        <location filename="../rss/rss.ui" line="149"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="154"/>
        <source>Rename...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="157"/>
        <source>Rename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="162"/>
        <location filename="../rss/rss.ui" line="165"/>
        <source>Update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="170"/>
        <source>New subscription...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="175"/>
        <location filename="../rss/rss.ui" line="178"/>
        <source>Update all feeds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="191"/>
        <source>Download torrent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="196"/>
        <source>Open news URL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="201"/>
        <source>Copy feed URL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="206"/>
        <source>New folder...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="211"/>
        <source>Manage cookies...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="51"/>
        <source>Refresh RSS streams</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RSSImp</name>
    <message>
        <location filename="../rss/rss_imp.cpp" line="203"/>
        <source>Please type a rss stream url</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="203"/>
        <source>Stream URL:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="237"/>
        <location filename="../rss/rss_imp.cpp" line="241"/>
        <source>Are you sure? -- qBittorrent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="238"/>
        <location filename="../rss/rss_imp.cpp" line="242"/>
        <source>&amp;Yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="238"/>
        <location filename="../rss/rss_imp.cpp" line="242"/>
        <source>&amp;No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="149"/>
        <source>Please choose a folder name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="149"/>
        <source>Folder name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="149"/>
        <source>New folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="170"/>
        <source>Overwrite attempt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="171"/>
        <source>You cannot overwrite %1 item.</source>
        <comment>You cannot overwrite myFolder item.</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="208"/>
        <source>qBittorrent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="209"/>
        <source>This rss feed is already in the list.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="237"/>
        <source>Are you sure you want to delete these elements from the list?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="241"/>
        <source>Are you sure you want to delete this element from the list?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="351"/>
        <source>Please choose a new name for this RSS feed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="351"/>
        <source>New feed name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="355"/>
        <source>Name already in use</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="355"/>
        <source>This name is already used by another item, please choose another one.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="508"/>
        <source>Date: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="511"/>
        <source>Author: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="554"/>
        <source>Unread</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RssFeed</name>
    <message>
        <location filename="../rss/rssfeed.cpp" line="292"/>
        <source>Automatically downloading %1 torrent from %2 RSS feed...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RssSettingsDlg</name>
    <message>
        <location filename="../rss/rsssettingsdlg.ui" line="14"/>
        <source>RSS Reader Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/rsssettingsdlg.ui" line="47"/>
        <source>RSS feeds refresh interval:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/rsssettingsdlg.ui" line="70"/>
        <source>minutes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rss/rsssettingsdlg.ui" line="77"/>
        <source>Maximum number of articles per feed:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScanFoldersModel</name>
    <message>
        <location filename="../scannedfoldersmodel.cpp" line="103"/>
        <source>Watched Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scannedfoldersmodel.cpp" line="104"/>
        <source>Download here</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SearchCategories</name>
    <message>
        <location filename="../searchengine/supportedengines.h" line="51"/>
        <source>All categories</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="52"/>
        <source>Movies</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="53"/>
        <source>TV shows</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="54"/>
        <source>Music</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="55"/>
        <source>Games</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="56"/>
        <source>Anime</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="57"/>
        <source>Software</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="58"/>
        <source>Pictures</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="59"/>
        <source>Books</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SearchEngine</name>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="213"/>
        <source>Cut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="214"/>
        <source>Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="215"/>
        <source>Paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="216"/>
        <source>Clear field</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="217"/>
        <source>Clear completion history</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="236"/>
        <source>Confirmation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="236"/>
        <source>Are you sure you want to clear the history?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="290"/>
        <location filename="../searchengine/searchengine.cpp" line="320"/>
        <location filename="../searchengine/searchengine.cpp" line="321"/>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="301"/>
        <source>Missing Python Interpreter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="302"/>
        <source>Python 2.x is required to use the search engine but it does not seem to be installed.
Do you want to install it now?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="332"/>
        <source>Empty search pattern</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="332"/>
        <source>Please type a search pattern first</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="370"/>
        <location filename="../searchengine/searchengine.cpp" line="466"/>
        <source>Results</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="445"/>
        <source>Searching...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="585"/>
        <source>Search Engine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="585"/>
        <location filename="../searchengine/searchengine.cpp" line="600"/>
        <source>Search has finished</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="591"/>
        <source>An error occured during search...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="589"/>
        <location filename="../searchengine/searchengine.cpp" line="595"/>
        <source>Search aborted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="178"/>
        <source>Download error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="178"/>
        <source>Python setup could not be downloaded, reason: %1.
Please install it manually.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="598"/>
        <source>Search returned no results</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="605"/>
        <source>Results</source>
        <comment>i.e: Search results</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="641"/>
        <location filename="../searchengine/searchengine.cpp" line="647"/>
        <source>Unknown</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SearchTab</name>
    <message>
        <location filename="../searchengine/searchtab.cpp" line="55"/>
        <source>Name</source>
        <comment>i.e: file name</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/searchtab.cpp" line="56"/>
        <source>Size</source>
        <comment>i.e: file size</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/searchtab.cpp" line="57"/>
        <source>Seeders</source>
        <comment>i.e: Number of full sources</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/searchtab.cpp" line="58"/>
        <source>Leechers</source>
        <comment>i.e: Number of partial sources</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/searchtab.cpp" line="59"/>
        <source>Search engine</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ShutdownConfirmDlg</name>
    <message>
        <location filename="../qtlibtorrent/shutdownconfirm.h" line="44"/>
        <source>Shutdown confirmation</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SpeedLimitDialog</name>
    <message>
        <location filename="../speedlimitdlg.h" line="84"/>
        <source>KiB/s</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>StatusBar</name>
    <message>
        <location filename="../statusbar.h" line="67"/>
        <location filename="../statusbar.h" line="180"/>
        <source>Connection status:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="67"/>
        <location filename="../statusbar.h" line="180"/>
        <source>No direct connections. This may indicate network configuration problems.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="95"/>
        <location filename="../statusbar.h" line="187"/>
        <source>DHT: %1 nodes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="150"/>
        <source>qBittorrent needs to be restarted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="160"/>
        <source>qBittorrent was just updated and needs to be restarted for the changes to be effective.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="172"/>
        <location filename="../statusbar.h" line="177"/>
        <source>Connection Status:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="172"/>
        <source>Offline. This usually means that qBittorrent failed to listen on the selected port for incoming connections.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="177"/>
        <source>Online</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="193"/>
        <location filename="../statusbar.h" line="194"/>
        <source>%1/s</source>
        <comment>Per second</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="204"/>
        <source>Click to switch to alternative speed limits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="200"/>
        <source>Click to switch to regular speed limits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="220"/>
        <source>Global Download Speed Limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="245"/>
        <source>Global Upload Speed Limit</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TorrentCreatorDlg</name>
    <message>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="73"/>
        <source>Select a folder to add to the torrent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="89"/>
        <source>Select a file to add to the torrent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="112"/>
        <source>No input path set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="112"/>
        <source>Please type an input path first</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="122"/>
        <source>Select destination torrent file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="122"/>
        <source>Torrent Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="149"/>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="165"/>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="180"/>
        <source>Torrent creation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="149"/>
        <source>Torrent creation was unsuccessful, reason: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="165"/>
        <source>Created torrent file is invalid. It won&apos;t be added to download list.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="180"/>
        <source>Torrent was created successfully:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TorrentFilesModel</name>
    <message>
        <location filename="../torrentfilesmodel.h" line="343"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentfilesmodel.h" line="343"/>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentfilesmodel.h" line="343"/>
        <source>Progress</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentfilesmodel.h" line="343"/>
        <source>Priority</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TorrentImportDlg</name>
    <message>
        <location filename="../torrentimportdlg.ui" line="14"/>
        <source>Torrent Import</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.ui" line="38"/>
        <source>This assistant will help you share with qBittorrent a torrent that you have already downloaded.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.ui" line="50"/>
        <source>Torrent file to import:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.ui" line="66"/>
        <location filename="../torrentimportdlg.ui" line="94"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.ui" line="75"/>
        <source>Content location:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.ui" line="106"/>
        <source>Skip the data checking stage and start seeding immediately</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.ui" line="116"/>
        <source>Import</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.cpp" line="70"/>
        <source>Torrent file to import</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.cpp" line="70"/>
        <source>Torrent files (*.torrent)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.cpp" line="95"/>
        <source>%1 Files</source>
        <comment>%1 is a file extension (e.g. PDF)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.cpp" line="97"/>
        <source>Please provide the location of %1</source>
        <comment>%1 is a file name</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.cpp" line="134"/>
        <source>Please point to the location of the torrent: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.cpp" line="242"/>
        <source>Invalid torrent file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.cpp" line="242"/>
        <source>This is not a valid torrent file.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TorrentModel</name>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="239"/>
        <source>Name</source>
        <comment>i.e: torrent name</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="241"/>
        <source>Size</source>
        <comment>i.e: torrent size</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="242"/>
        <source>Done</source>
        <comment>% Done</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="243"/>
        <source>Status</source>
        <comment>Torrent status (e.g. downloading, seeding, paused)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="244"/>
        <source>Seeds</source>
        <comment>i.e. full sources (often untranslated)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="245"/>
        <source>Peers</source>
        <comment>i.e. partial sources (often untranslated)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="246"/>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="247"/>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="248"/>
        <source>Ratio</source>
        <comment>Share ratio</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="249"/>
        <source>ETA</source>
        <comment>i.e: Estimated Time of Arrival / Time left</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="250"/>
        <source>Label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="251"/>
        <source>Added On</source>
        <comment>Torrent was added to transfer list on 01/01/2010 08:00</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="252"/>
        <source>Completed On</source>
        <comment>Torrent was completed on 01/01/2010 08:00</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="253"/>
        <source>Tracker</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="254"/>
        <source>Down Limit</source>
        <comment>i.e: Download limit</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="255"/>
        <source>Up Limit</source>
        <comment>i.e: Upload limit</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="256"/>
        <source>Amount downloaded</source>
        <comment>Amount of data downloaded (e.g. in MB)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="257"/>
        <source>Amount left</source>
        <comment>Amount of data left to download (e.g. in MB)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="258"/>
        <source>Time Active</source>
        <comment>Time (duration) the torrent is active (not paused)</comment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TrackerList</name>
    <message>
        <location filename="../properties/trackerlist.cpp" line="61"/>
        <source>URL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="62"/>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="63"/>
        <source>Peers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="64"/>
        <source>Message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="66"/>
        <source>[DHT]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="69"/>
        <source>[PeX]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="72"/>
        <source>[LSD]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="209"/>
        <location filename="../properties/trackerlist.cpp" line="219"/>
        <location filename="../properties/trackerlist.cpp" line="225"/>
        <location filename="../properties/trackerlist.cpp" line="256"/>
        <location filename="../properties/trackerlist.cpp" line="274"/>
        <source>Working</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="211"/>
        <location filename="../properties/trackerlist.cpp" line="221"/>
        <location filename="../properties/trackerlist.cpp" line="227"/>
        <source>Disabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="215"/>
        <source>This torrent is private</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="260"/>
        <source>Updating...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="264"/>
        <location filename="../properties/trackerlist.cpp" line="278"/>
        <source>Not working</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="267"/>
        <location filename="../properties/trackerlist.cpp" line="281"/>
        <source>Not contacted yet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="349"/>
        <source>Add a new tracker...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="352"/>
        <source>Remove tracker</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="355"/>
        <source>Force reannounce</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TrackersAdditionDlg</name>
    <message>
        <location filename="../properties/trackersadditiondlg.ui" line="14"/>
        <source>Trackers addition dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/trackersadditiondlg.ui" line="20"/>
        <source>List of trackers to add (one per line):</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../properties/trackersadditiondlg.ui" line="44"/>
        <source>µTorrent compatible list URL:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/trackersadditiondlg.h" line="81"/>
        <source>I/O Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/trackersadditiondlg.h" line="81"/>
        <source>Error while trying to open the downloaded file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/trackersadditiondlg.h" line="123"/>
        <source>No change</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/trackersadditiondlg.h" line="123"/>
        <source>No additional trackers were found.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/trackersadditiondlg.h" line="132"/>
        <source>Download error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/trackersadditiondlg.h" line="132"/>
        <source>The trackers list could not be downloaded, reason: %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TransferListDelegate</name>
    <message>
        <location filename="../transferlistdelegate.h" line="94"/>
        <source>Downloading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transferlistdelegate.h" line="98"/>
        <source>Paused</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transferlistdelegate.h" line="102"/>
        <source>Queued</source>
        <comment>i.e. torrent is queued</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transferlistdelegate.h" line="106"/>
        <source>Seeding</source>
        <comment>Torrent is complete and in upload-only mode</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transferlistdelegate.h" line="109"/>
        <source>Stalled</source>
        <comment>Torrent is waiting for download to begin</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transferlistdelegate.h" line="113"/>
        <source>Checking</source>
        <comment>Torrent local data is being checked</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transferlistdelegate.h" line="127"/>
        <source>/s</source>
        <comment>/second (.i.e per second)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transferlistdelegate.h" line="136"/>
        <source>KiB/s</source>
        <comment>KiB/second (.i.e per second)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transferlistdelegate.h" line="146"/>
        <source>Seeded for %1</source>
        <comment>e.g. Seeded for 3m10s</comment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TransferListFiltersWidget</name>
    <message>
        <location filename="../transferlistfilterswidget.h" line="205"/>
        <location filename="../transferlistfilterswidget.h" line="287"/>
        <source>All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="208"/>
        <location filename="../transferlistfilterswidget.h" line="288"/>
        <source>Downloading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="211"/>
        <location filename="../transferlistfilterswidget.h" line="289"/>
        <source>Completed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="214"/>
        <location filename="../transferlistfilterswidget.h" line="290"/>
        <source>Paused</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="217"/>
        <location filename="../transferlistfilterswidget.h" line="291"/>
        <source>Active</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="220"/>
        <location filename="../transferlistfilterswidget.h" line="292"/>
        <source>Inactive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="234"/>
        <location filename="../transferlistfilterswidget.h" line="469"/>
        <source>All labels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="237"/>
        <location filename="../transferlistfilterswidget.h" line="470"/>
        <source>Unlabeled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="319"/>
        <source>Remove label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="320"/>
        <source>Add label...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="322"/>
        <source>Resume torrents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="323"/>
        <source>Pause torrents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="324"/>
        <source>Delete torrents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="350"/>
        <source>New Label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="350"/>
        <source>Label:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="355"/>
        <source>Invalid label name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="355"/>
        <source>Please don&apos;t use any special characters in the label name.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TransferListWidget</name>
    <message>
        <location filename="../transferlistwidget.cpp" line="524"/>
        <source>Column visibility</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="766"/>
        <source>Label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="227"/>
        <source>Choose save path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="449"/>
        <source>Torrent Download Speed Limiting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="482"/>
        <source>Torrent Upload Speed Limiting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="589"/>
        <source>New Label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="589"/>
        <source>Label:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="594"/>
        <source>Invalid label name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="594"/>
        <source>Please don&apos;t use any special characters in the label name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="610"/>
        <source>Rename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="610"/>
        <source>New name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="644"/>
        <source>Resume</source>
        <comment>Resume/start the torrent</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="646"/>
        <source>Pause</source>
        <comment>Pause the torrent</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="648"/>
        <source>Delete</source>
        <comment>Delete the torrent</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="650"/>
        <source>Preview file...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="652"/>
        <source>Limit share ratio...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="654"/>
        <source>Limit upload rate...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="656"/>
        <source>Limit download rate...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="658"/>
        <source>Open destination folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="660"/>
        <source>Move up</source>
        <comment>i.e. move up in the queue</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="662"/>
        <source>Move down</source>
        <comment>i.e. Move down in the queue</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="664"/>
        <source>Move to top</source>
        <comment>i.e. Move to top of the queue</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="666"/>
        <source>Move to bottom</source>
        <comment>i.e. Move to bottom of the queue</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="668"/>
        <source>Set location...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="811"/>
        <source>Priority</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="670"/>
        <source>Force recheck</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="672"/>
        <source>Copy magnet link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="675"/>
        <source>Super seeding mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="679"/>
        <source>Rename...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="681"/>
        <source>Download in sequential order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="684"/>
        <source>Download first and last piece first</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="767"/>
        <source>New...</source>
        <comment>New label...</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="768"/>
        <source>Reset</source>
        <comment>Reset label</comment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UpDownRatioDlg</name>
    <message>
        <location filename="../updownratiodlg.ui" line="14"/>
        <source>Torrent Upload/Download Ratio Limiting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../updownratiodlg.ui" line="20"/>
        <source>Use global ratio limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../updownratiodlg.ui" line="23"/>
        <location filename="../updownratiodlg.ui" line="33"/>
        <location filename="../updownratiodlg.ui" line="45"/>
        <source>buttonGroup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../updownratiodlg.ui" line="30"/>
        <source>Set no ratio limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../updownratiodlg.ui" line="42"/>
        <source>Set ratio limit to</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UsageDisplay</name>
    <message>
        <location filename="../main.cpp" line="73"/>
        <source>Usage:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.cpp" line="74"/>
        <source>displays program version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.cpp" line="76"/>
        <source>disable splash screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.cpp" line="78"/>
        <source>displays this help message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.cpp" line="79"/>
        <source>changes the webui port (current: %1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.cpp" line="80"/>
        <source>[files or urls]: downloads the torrents passed by the user (optional)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>about</name>
    <message>
        <location filename="../about_imp.h" line="51"/>
        <source>qBittorrent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../about_imp.h" line="61"/>
        <source>I would like to thank the following people who volunteered to translate qBittorrent:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../about_imp.h" line="93"/>
        <source>Please contact me if you would like to translate qBittorrent into your own language.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>addPeerDialog</name>
    <message>
        <location filename="../properties/peer.ui" line="20"/>
        <source>Peer addition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/peer.ui" line="36"/>
        <source>IP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../properties/peer.ui" line="59"/>
        <source>Port</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>addTorrentDialog</name>
    <message>
        <location filename="../torrentadditiondlg.ui" line="14"/>
        <source>Torrent addition dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="42"/>
        <source>Save path:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="62"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="73"/>
        <source>Torrent size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="80"/>
        <location filename="../torrentadditiondlg.ui" line="101"/>
        <source>Unknown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="94"/>
        <source>Free disk space:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="132"/>
        <source>Label:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="184"/>
        <source>Torrent content:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="237"/>
        <source>Select All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="244"/>
        <source>Select None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="266"/>
        <source>Download in sequential order (slower but good for previewing)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="273"/>
        <source>Skip file checking and start seeding immediately</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="280"/>
        <source>Add to download list in paused state</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="308"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="315"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="337"/>
        <source>Normal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="342"/>
        <source>High</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="347"/>
        <source>Maximum</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="352"/>
        <location filename="../torrentadditiondlg.ui" line="355"/>
        <source>Do not download</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>authentication</name>
    <message>
        <location filename="../login.ui" line="16"/>
        <location filename="../login.ui" line="66"/>
        <source>Tracker authentication</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../login.ui" line="94"/>
        <source>Tracker:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../login.ui" line="127"/>
        <source>Login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../login.ui" line="147"/>
        <source>Username:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../login.ui" line="176"/>
        <source>Password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../login.ui" line="219"/>
        <source>Log in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../login.ui" line="226"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>confirmDeletionDlg</name>
    <message>
        <location filename="../confirmdeletiondlg.ui" line="20"/>
        <source>Deletion confirmation - qBittorrent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../confirmdeletiondlg.ui" line="47"/>
        <source>Are you sure you want to delete the selected torrents from the transfer list?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../confirmdeletiondlg.ui" line="67"/>
        <source>Remember choice</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../confirmdeletiondlg.ui" line="94"/>
        <source>Also delete the files on the hard disk</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>createTorrentDialog</name>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="291"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="14"/>
        <source>Torrent Creation Tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="43"/>
        <source>Torrent file creation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="65"/>
        <source>Add file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="72"/>
        <source>Add folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="53"/>
        <source>File or folder to add to the torrent:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="83"/>
        <source>Tracker URLs:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="93"/>
        <source>Web seeds urls:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="103"/>
        <source>Comment:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="150"/>
        <source>Piece size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="167"/>
        <source>32 KiB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="172"/>
        <source>64 KiB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="177"/>
        <source>128 KiB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="182"/>
        <source>256 KiB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="187"/>
        <source>512 KiB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="192"/>
        <source>1 MiB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="197"/>
        <source>2 MiB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="202"/>
        <source>4 MiB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="210"/>
        <source>Auto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="235"/>
        <source>Private (won&apos;t be distributed on DHT network if enabled)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="242"/>
        <source>Start seeding after creation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="284"/>
        <source>Create and save...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="249"/>
        <source>Progress:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>downloadFromURL</name>
    <message>
        <location filename="../downloadfromurldlg.ui" line="45"/>
        <source>Add torrent links</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../downloadfromurldlg.ui" line="78"/>
        <source>Both HTTP and Magnet links are supported</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../downloadfromurldlg.ui" line="106"/>
        <source>Download</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../downloadfromurldlg.ui" line="113"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../downloadfromurldlg.ui" line="14"/>
        <source>Download from urls</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../downloadfromurldlg.h" line="78"/>
        <source>No URL entered</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../downloadfromurldlg.h" line="78"/>
        <source>Please type at least one URL.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>engineSelect</name>
    <message>
        <location filename="../searchengine/engineselect.ui" line="17"/>
        <source>Search plugins</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="30"/>
        <source>Installed search engines:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="50"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="55"/>
        <source>Url</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="60"/>
        <location filename="../searchengine/engineselect.ui" line="119"/>
        <source>Enabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="78"/>
        <source>You can get new search engine plugins here: &lt;a href=&quot;http://plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="93"/>
        <source>Install a new one</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="100"/>
        <source>Check for updates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="107"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="124"/>
        <source>Uninstall</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>engineSelectDlg</name>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="174"/>
        <source>Uninstall warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="174"/>
        <source>Some plugins could not be uninstalled because they are included in qBittorrent.
 Only the ones you added yourself can be uninstalled.
However, those plugins were disabled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="176"/>
        <source>Uninstall success</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="340"/>
        <source>Select search plugins</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="341"/>
        <source>qBittorrent search plugins</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="237"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="262"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="267"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="276"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="279"/>
        <source>Search plugin install</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="117"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="188"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="299"/>
        <source>Yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="120"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="154"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="191"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="302"/>
        <source>No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="237"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="262"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="267"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="276"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="279"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="393"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="426"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="447"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="454"/>
        <source>qBittorrent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="237"/>
        <source>A more recent version of %1 search engine plugin is already installed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="393"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="426"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="447"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="454"/>
        <source>Search plugin update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="426"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="447"/>
        <source>Sorry, update server is temporarily unavailable.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="393"/>
        <source>All your plugins are already up to date.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="262"/>
        <source>%1 search engine plugin could not be updated, keeping old version.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="267"/>
        <source>%1 search engine plugin could not be installed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="176"/>
        <source>All selected plugins were uninstalled successfully</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="276"/>
        <source>%1 search engine plugin was successfully updated.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="279"/>
        <source>%1 search engine plugin was successfully installed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="454"/>
        <source>Sorry, %1 search plugin install failed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="329"/>
        <source>New search engine plugin URL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="330"/>
        <source>URL:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>misc</name>
    <message>
        <location filename="../misc.cpp" line="85"/>
        <source>B</source>
        <comment>bytes</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="86"/>
        <source>KiB</source>
        <comment>kibibytes (1024 bytes)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="87"/>
        <source>MiB</source>
        <comment>mebibytes (1024 kibibytes)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="88"/>
        <source>GiB</source>
        <comment>gibibytes (1024 mibibytes)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="89"/>
        <source>TiB</source>
        <comment>tebibytes (1024 gibibytes)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="755"/>
        <source>%1h %2m</source>
        <comment>e.g: 3hours 5minutes</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="760"/>
        <source>%1d %2h</source>
        <comment>e.g: 2days 10hours</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="583"/>
        <source>Unknown</source>
        <comment>Unknown (size)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="307"/>
        <source>qBittorrent will shutdown the computer now because all downloads are complete.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="695"/>
        <location filename="../misc.cpp" line="700"/>
        <location filename="../misc.cpp" line="704"/>
        <location filename="../misc.cpp" line="707"/>
        <location filename="../misc.cpp" line="712"/>
        <location filename="../misc.cpp" line="715"/>
        <source>Unknown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="746"/>
        <source>&lt; 1m</source>
        <comment>&lt; 1 minute</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="750"/>
        <source>%1m</source>
        <comment>e.g: 10minutes</comment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>options_imp</name>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1055"/>
        <location filename="../preferences/options_imp.cpp" line="1057"/>
        <source>Choose export directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1090"/>
        <location filename="../preferences/options_imp.cpp" line="1092"/>
        <location filename="../preferences/options_imp.cpp" line="1107"/>
        <location filename="../preferences/options_imp.cpp" line="1109"/>
        <source>Choose a save directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1072"/>
        <location filename="../preferences/options_imp.cpp" line="1074"/>
        <source>Choose an ip filter file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1012"/>
        <source>Add directory to scan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1018"/>
        <source>Folder is already being watched.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1021"/>
        <source>Folder does not exist.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1024"/>
        <source>Folder is not readable.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1032"/>
        <source>Failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1032"/>
        <source>Failed to add Scan Folder &apos;%1&apos;: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1072"/>
        <location filename="../preferences/options_imp.cpp" line="1074"/>
        <source>Filters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1152"/>
        <source>SSL Certificate (*.crt *.pem)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1163"/>
        <source>SSL Key (*.key *.pem)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1194"/>
        <source>Parsing error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1194"/>
        <source>Failed to parse the provided IP filter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1196"/>
        <source>Successfully refreshed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1196"/>
        <source>Successfuly parsed the provided IP filter: %1 rules were applied.</source>
        <comment>%1 is a number</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1263"/>
        <source>Invalid key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1263"/>
        <source>This is not a valid SSL key.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1278"/>
        <source>Invalid certificate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1278"/>
        <source>This is not a valid SSL certificate.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>pluginSourceDlg</name>
    <message>
        <location filename="../searchengine/pluginsource.ui" line="13"/>
        <source>Plugin source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/pluginsource.ui" line="26"/>
        <source>Search plugin source:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/pluginsource.ui" line="35"/>
        <source>Local file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/pluginsource.ui" line="42"/>
        <source>Web link</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>preview</name>
    <message>
        <location filename="../preview.ui" line="16"/>
        <source>Preview selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preview.ui" line="51"/>
        <source>File preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preview.ui" line="67"/>
        <source>The following files support previewing, &lt;br&gt;please select one of them:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preview.ui" line="101"/>
        <source>Preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preview.ui" line="108"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>search_engine</name>
    <message>
        <location filename="../searchengine/search.ui" line="14"/>
        <location filename="../searchengine/search.ui" line="44"/>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/search.ui" line="67"/>
        <source>Status:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/search.ui" line="91"/>
        <source>Stopped</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/search.ui" line="135"/>
        <source>Download</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/search.ui" line="145"/>
        <source>Go to description page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/search.ui" line="165"/>
        <source>Search engines...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>torrentAdditionDialog</name>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="199"/>
        <source>Unable to decode magnet link:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="205"/>
        <source>Magnet Link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="241"/>
        <location filename="../torrentadditiondlg.cpp" line="244"/>
        <source>Unable to decode torrent file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="337"/>
        <source>Rename...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="341"/>
        <source>Priority</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="381"/>
        <source>Rename the file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="382"/>
        <source>New name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="386"/>
        <location filename="../torrentadditiondlg.cpp" line="416"/>
        <source>The file could not be renamed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="387"/>
        <source>This file name contains forbidden characters, please choose a different one.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="417"/>
        <location filename="../torrentadditiondlg.cpp" line="451"/>
        <source>This name is already in use in this folder. Please use a different name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="450"/>
        <source>The folder could not be renamed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="498"/>
        <source>(%1 left after torrent download)</source>
        <comment>e.g. (100MiB left after torrent download)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="501"/>
        <source>(%1 more are required to download)</source>
        <comment>e.g. (100MiB more are required to download)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="516"/>
        <location filename="../torrentadditiondlg.cpp" line="531"/>
        <location filename="../torrentadditiondlg.cpp" line="533"/>
        <source>Choose save path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="586"/>
        <source>Empty save path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="586"/>
        <source>Please enter a save path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="665"/>
        <source>Save path creation error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="665"/>
        <source>Could not create the save path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="607"/>
        <source>Invalid label name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="607"/>
        <source>Please don&apos;t use any special characters in the label name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="650"/>
        <source>Seeding mode error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="650"/>
        <source>You chose to skip file checking. However, local files do not seem to exist in the current destionation folder. Please disable this feature or update the save path.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="657"/>
        <source>Invalid file selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="657"/>
        <source>You must select at least one file in the torrent</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
