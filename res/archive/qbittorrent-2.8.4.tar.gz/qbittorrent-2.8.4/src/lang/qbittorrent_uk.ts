<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="uk_UA">
<context>
    <name>AboutDlg</name>
    <message>
        <source>About qBittorrent</source>
        <translation>Про qBittorrent</translation>
    </message>
    <message>
        <source>About</source>
        <translation>Про програму</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Автор</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation>Ім&apos;я:</translation>
    </message>
    <message>
        <source>Country:</source>
        <translation>Країна:</translation>
    </message>
    <message>
        <source>E-mail:</source>
        <translation>E-mail:</translation>
    </message>
    <message>
        <source>Christophe Dumez</source>
        <translation>Крістоф Думез</translation>
    </message>
    <message>
        <source>France</source>
        <translation>Франція</translation>
    </message>
    <message>
        <source>Translation</source>
        <translation>Переклад</translation>
    </message>
    <message>
        <source>License</source>
        <translation>Ліцензія</translation>
    </message>
    <message>
        <source>&lt;h3&gt;&lt;b&gt;qBittorrent&lt;/b&gt;&lt;/h3&gt;</source>
        <translation>&lt;h3&gt;&lt;b&gt;qBittorrent&lt;/b&gt;&lt;/h3&gt;</translation>
    </message>
    <message>
        <source>chris@qbittorrent.org</source>
        <translation>chris@qbittorrent.org</translation>
    </message>
    <message>
        <source>Thanks to</source>
        <translation>Подяки</translation>
    </message>
    <message utf8="true">
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;A Bittorrent client programmed in C++, based on Qt4 toolkit &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;and libtorrent-rasterbar. &lt;br /&gt;&lt;br /&gt;Copyright ©2006-2010 Christophe Dumez&lt;br /&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Home Page:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://www.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;http://www.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Forum:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://forum.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;http://forum.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;IRC:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; #qbittorrent on Freenode&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;Bittorrent-клієнт, написаний на C++, на базі Qt4 &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;та libtorrent-rasterbar. &lt;br /&gt;&lt;br /&gt;Захищено авторським правом ©2006-2009 Крістоф Думез&lt;br /&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Домашня сторінка:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://www.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;http://www.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Форум:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://forum.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;http://forum.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;IRC:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; #qbittorrent на Freenode&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message utf8="true">
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;An advanced BitTorrent client programmed in C++, based on Qt4 toolkit and libtorrent-rasterbar. &lt;br /&gt;&lt;br /&gt;Copyright ©2006-2011 Christophe Dumez&lt;br /&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Home Page:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://www.qbittorrent.org&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans&apos;; text-decoration: underline; color:#0057ae;&quot;&gt;http://www.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Bug Tracker:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://bugs.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;http://bugs.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Forum:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://forum.qbittorrent.org&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans&apos;; text-decoration: underline; color:#0057ae;&quot;&gt;http://forum.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;IRC:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; #qbittorrent on Freenode&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AdvancedSettings</name>
    <message>
        <source>Property</source>
        <translation type="obsolete">Властивість</translation>
    </message>
    <message>
        <source>Value</source>
        <translation type="obsolete">Значення</translation>
    </message>
    <message>
        <source>Disk write cache size</source>
        <translation>Розмір дискового кешу</translation>
    </message>
    <message>
        <source> MiB</source>
        <translation> МіБ</translation>
    </message>
    <message>
        <source>Outgoing ports (Min) [0: Disabled]</source>
        <translation>Вихідні порти (мін.) [0: Вимкнено]</translation>
    </message>
    <message>
        <source>Outgoing ports (Max) [0: Disabled]</source>
        <translation>Вихідні порти (макс.) [0: Вимкнено]</translation>
    </message>
    <message>
        <source>Ignore transfer limits on local network</source>
        <translation>Ігнорувати ліміти швидкості для локальної мережі</translation>
    </message>
    <message>
        <source>Include TCP/IP overhead in transfer limits</source>
        <translation type="obsolete">Включати заголовки протоколу в ліміти швидкості</translation>
    </message>
    <message>
        <source>Recheck torrents on completion</source>
        <translation>Перепровіряти торренти після завантаження</translation>
    </message>
    <message>
        <source>Transfer list refresh interval</source>
        <translation>Інтервал оновлення списку завантажень</translation>
    </message>
    <message>
        <source> ms</source>
        <comment> milliseconds</comment>
        <translation>мс</translation>
    </message>
    <message>
        <source>Resolve peer countries (GeoIP)</source>
        <translation>Дізнаватись країну сервера (GeoIP)</translation>
    </message>
    <message>
        <source>Resolve peer host names</source>
        <translation>Дізнаватись адресу сервера</translation>
    </message>
    <message>
        <source>Maximum number of half-open connections [0: Disabled]</source>
        <translation>Максимальна кількість напіввідкритих з&apos;єднань [0: Вимкнено]</translation>
    </message>
    <message>
        <source>Strict super seeding</source>
        <translation>Строге супер-сідування</translation>
    </message>
    <message>
        <source>Network Interface (requires restart)</source>
        <translation>Мережевий Інтерфейс (потребує перезапуску)</translation>
    </message>
    <message>
        <source>Any interface</source>
        <comment>i.e. Any network interface</comment>
        <translation>Будь-який інтерфейс</translation>
    </message>
    <message>
        <source>Display program notification baloons</source>
        <translation type="obsolete">Відображати сповіщення програми</translation>
    </message>
    <message>
        <source>Display program notification balloons</source>
        <translation type="obsolete">Відображати сповіщення програми</translation>
    </message>
    <message>
        <source>Enable embedded tracker</source>
        <translation>Увімкнути вбудований трекер</translation>
    </message>
    <message>
        <source>Embedded tracker port</source>
        <translation>Порт вбудованого трекера</translation>
    </message>
    <message>
        <source>Check for software updates</source>
        <translation>Перевірити оновлення програмного забезпечення</translation>
    </message>
    <message>
        <source>Use system icon theme</source>
        <translation>Використовувати системну тему іконок</translation>
    </message>
    <message>
        <source>Confirm torrent deletion</source>
        <translation>Підтвердити видалення торрента</translation>
    </message>
    <message>
        <source>IP Address to report to trackers (requires restart)</source>
        <translation>IP адреса, що повідомляється трекерам (потребує перезапуску)</translation>
    </message>
    <message>
        <source>Display program on-screen notifications</source>
        <translation type="unfinished">Відображати сповіщення програми на екрані</translation>
    </message>
    <message>
        <source>Setting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Value</source>
        <comment>Value set for this setting</comment>
        <translation type="unfinished">Значення</translation>
    </message>
    <message>
        <source>Exchange trackers with other peers</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AutomatedRssDownloader</name>
    <message>
        <source>Automated RSS Downloader</source>
        <translation>Автоматичний завантажувач RSS</translation>
    </message>
    <message>
        <source>Enable the automated RSS downloader</source>
        <translation>Увімкнути автоматичний завантажувач RSS</translation>
    </message>
    <message>
        <source>Download rules</source>
        <translation>Правила завантаження</translation>
    </message>
    <message>
        <source>Rule definition</source>
        <translation>Означення правила</translation>
    </message>
    <message>
        <source>Must contain:</source>
        <translation>Повинно містити:</translation>
    </message>
    <message>
        <source>Must not contain:</source>
        <translation>Не може містити:</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Assign label:</source>
        <translation>Призначити мітку:</translation>
    </message>
    <message>
        <source>Apply rule to feeds:</source>
        <translation>Застосувати правило до подач:</translation>
    </message>
    <message>
        <source>Matching RSS articles</source>
        <translation>Підходящі RSS-статті</translation>
    </message>
    <message>
        <source>Save to a different directory</source>
        <translation>Зберегти в іншу папку</translation>
    </message>
    <message>
        <source>Save to:</source>
        <translation>Зберегти у:</translation>
    </message>
    <message>
        <source>Import...</source>
        <translation>Імпорт...</translation>
    </message>
    <message>
        <source>Export...</source>
        <translation>Експорт...</translation>
    </message>
    <message>
        <source>New rule name</source>
        <translation>Нова назва правила</translation>
    </message>
    <message>
        <source>Please type the name of the new download rule.</source>
        <translation>Будь ласка, введіть назву нового правила завантаження.</translation>
    </message>
    <message>
        <source>Rule name conflict</source>
        <translation>Конфлікт назв правил</translation>
    </message>
    <message>
        <source>A rule with this name already exists, please choose another name.</source>
        <translation>Правило з цією назвою вже існує, будь ласка, оберіть іншу назву.</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the download rule named %1?</source>
        <translation>Ви випевнені, що хочете видалити правило &quot;%1&quot;?</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the selected download rules?</source>
        <translation>Ви дійсно хочете видалити вибрані правила завантаження?</translation>
    </message>
    <message>
        <source>Rule deletion confirmation</source>
        <translation>Підтвердження видалення правила</translation>
    </message>
    <message>
        <source>Destination directory</source>
        <translation>Папка призначення</translation>
    </message>
    <message>
        <source>Invalid action</source>
        <translation>Неправильна дія</translation>
    </message>
    <message>
        <source>The list is empty, there is nothing to export.</source>
        <translation>Список пустий, нічого експортувати.</translation>
    </message>
    <message>
        <source>Where would you like to save the list?</source>
        <translation>Де б ви хотіли зберегти список?</translation>
    </message>
    <message>
        <source>Rules list (*.rssrules)</source>
        <translation>Список правил (*.rssrules)</translation>
    </message>
    <message>
        <source>I/O Error</source>
        <translation>Помилка вводу/виводу</translation>
    </message>
    <message>
        <source>Failed to create the destination file</source>
        <translation>Не вдалося створити папку призначення</translation>
    </message>
    <message>
        <source>Please point to the RSS download rules file</source>
        <translation>Будь ласка, вкажіть файл правил завантаження RSS</translation>
    </message>
    <message>
        <source>Rules list (*.rssrules *.filters)</source>
        <translation>Список правил (*.rssrules *.filters)</translation>
    </message>
    <message>
        <source>Import Error</source>
        <translation>Помилка імпорту</translation>
    </message>
    <message>
        <source>Failed to import the selected rules file</source>
        <translation>Не вдалось імпортувати вибраний файл правил</translation>
    </message>
    <message>
        <source>Add new rule...</source>
        <translation>Додати нове правило...</translation>
    </message>
    <message>
        <source>Delete rule</source>
        <translation>Видалити правило</translation>
    </message>
    <message>
        <source>Rename rule...</source>
        <translation>Перейменувати правило...</translation>
    </message>
    <message>
        <source>Delete selected rules</source>
        <translation>Видалити позначені правила</translation>
    </message>
    <message>
        <source>Rule renaming</source>
        <translation>Перейменування правила</translation>
    </message>
    <message>
        <source>Please type the new rule name</source>
        <translation>Будь ласка, введіть нову назву правила</translation>
    </message>
    <message>
        <source>Use regular expressions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Regex mode: use Perl-like regular expressions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Wildcard mode: you can use&lt;ul&gt;&lt;li&gt;? to match any single character&lt;/li&gt;&lt;li&gt;* to match zero or more of any characters&lt;/li&gt;&lt;li&gt;Whitespaces count as AND operators&lt;/li&gt;&lt;/ul&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Wildcard mode: you can use&lt;ul&gt;&lt;li&gt;? to match any single character&lt;/li&gt;&lt;li&gt;* to match zero or more of any characters&lt;/li&gt;&lt;li&gt;| is used as OR operator&lt;/li&gt;&lt;/ul&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Bittorrent</name>
    <message>
        <source>%1 reached the maximum ratio you set.</source>
        <translation type="obsolete">%1 досяг максимального коефіцієнта, налаштованого вами.</translation>
    </message>
    <message>
        <source>qBittorrent is bound to port: TCP/%1</source>
        <comment>e.g: qBittorrent is bound to port: 6881</comment>
        <translation type="obsolete">qBittorrent використовує порт: %1</translation>
    </message>
    <message>
        <source>UPnP support [ON]</source>
        <translation type="obsolete">Підтримка UNnP [Увімкнено]</translation>
    </message>
    <message>
        <source>UPnP support [OFF]</source>
        <translation type="obsolete">Підтримка UPnP [Вимкнено]</translation>
    </message>
    <message>
        <source>NAT-PMP support [ON]</source>
        <translation type="obsolete">Підтримка NAT-PMP [Увімкнено]</translation>
    </message>
    <message>
        <source>NAT-PMP support [OFF]</source>
        <translation type="obsolete">Підтримка NAT-PMP [Вимкнено]</translation>
    </message>
    <message>
        <source>DHT support [ON], port: UDP/%1</source>
        <translation type="obsolete">Підтримка DHT [Увімкнено], порт: UDP/%1</translation>
    </message>
    <message>
        <source>DHT support [OFF]</source>
        <translation type="obsolete">Підтримка DHT [Вимкнено]</translation>
    </message>
    <message>
        <source>PeX support [ON]</source>
        <translation type="obsolete">Підтримка PeX [Увімкнено]</translation>
    </message>
    <message>
        <source>Local Peer Discovery [ON]</source>
        <translation type="obsolete">Пошук Локальних Пірів [Увімкнено]</translation>
    </message>
    <message>
        <source>Local Peer Discovery support [OFF]</source>
        <translation type="obsolete">Пошук Локальних Пірів [Вимкнено]</translation>
    </message>
    <message>
        <source>Encryption support [ON]</source>
        <translation type="obsolete">Підтримка шифрування [Увімкнено]</translation>
    </message>
    <message>
        <source>Encryption support [FORCED]</source>
        <translation type="obsolete">Підтримка шифрування [Примусова]</translation>
    </message>
    <message>
        <source>Encryption support [OFF]</source>
        <translation type="obsolete">Підтримка шифрування [Вимкнено]</translation>
    </message>
    <message>
        <source>Web User Interface Error - Unable to bind Web UI to port %1</source>
        <translation type="obsolete">Помилка Веб-інтерфейсу - Не можу приєднати Веб-інтерфейс до порту %1</translation>
    </message>
    <message>
        <source>&apos;%1&apos; was removed from transfer list and hard disk.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation type="obsolete">&apos;%1&apos; було видалено із списку завантажень і жорсткого диску.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; was removed from transfer list.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation type="obsolete">&apos;%1&apos; було видалено із списку завантажень.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is not a valid magnet URI.</source>
        <translation type="obsolete">&apos;%1&apos; не є правильним магнітним посиланням.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is already in download list.</source>
        <comment>e.g: &apos;xxx.avi&apos; is already in download list.</comment>
        <translation type="obsolete">&apos;%1&apos; вже є у списку завантажень.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; resumed. (fast resume)</source>
        <comment>&apos;/home/y/xxx.torrent&apos; was resumed. (fast resume)</comment>
        <translation type="obsolete">&apos;%1&apos; відновлено. (швидке відновлення)</translation>
    </message>
    <message>
        <source>&apos;%1&apos; added to download list.</source>
        <comment>&apos;/home/y/xxx.torrent&apos; was added to download list.</comment>
        <translation type="obsolete">&apos;%1&apos; додано до списку завантажень.</translation>
    </message>
    <message>
        <source>Unable to decode torrent file: &apos;%1&apos;</source>
        <comment>e.g: Unable to decode torrent file: &apos;/home/y/xxx.torrent&apos;</comment>
        <translation type="obsolete">Не вдалося розкодувати торрент-файл: &apos;%1&apos;</translation>
    </message>
    <message>
        <source>This file is either corrupted or this isn&apos;t a torrent.</source>
        <translation type="obsolete">Цей файл або пошкоджений, або не є торрент-файлом.</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;was blocked due to your IP filter&lt;/i&gt;</source>
        <comment>x.y.z.w was blocked</comment>
        <translation type="obsolete">&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;було заблоковано згідно з вашим IP-фільтром&lt;/i&gt;</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;was banned due to corrupt pieces&lt;/i&gt;</source>
        <comment>x.y.z.w was banned</comment>
        <translation type="obsolete">&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;було заблоковано через пошкоджені частини&lt;/i&gt;</translation>
    </message>
    <message>
        <source>Recursive download of file %1 embedded in torrent %2</source>
        <comment>Recursive download of test.torrent embedded in torrent test2</comment>
        <translation type="obsolete">Рекурсивне завантаження файлу %1 в торренті %2</translation>
    </message>
    <message>
        <source>Unable to decode %1 torrent file.</source>
        <translation type="obsolete">Не можу розкодувати %1 торрент-файл.</translation>
    </message>
    <message>
        <source>UPnP/NAT-PMP: Port mapping failure, message: %1</source>
        <translation type="obsolete">UPnP/NAT-PMP: Не можу приєднати порт, повідомлення: %1</translation>
    </message>
    <message>
        <source>UPnP/NAT-PMP: Port mapping successful, message: %1</source>
        <translation type="obsolete">UPnP/NAT-PMP: Успішне приєднання порта, повідомлення: %1</translation>
    </message>
    <message>
        <source>Fast resume data was rejected for torrent %1, checking again...</source>
        <translation type="obsolete">Було відмовлено у швидкому відновленні данних для torrent&apos;у %1, перевіряю знову...</translation>
    </message>
    <message>
        <source>Url seed lookup failed for url: %1, message: %2</source>
        <translation type="obsolete">Пошук url роздачі невдалий для url: %1, повідомлення: %2</translation>
    </message>
    <message>
        <source>Downloading &apos;%1&apos;, please wait...</source>
        <comment>e.g: Downloading &apos;xxx.torrent&apos;, please wait...</comment>
        <translation type="obsolete">Завантажую &apos;%1&apos;, зачекайте...</translation>
    </message>
    <message>
        <source>Using a disk cache size of %1 MiB</source>
        <translation type="obsolete">Використовую дисковий кеш розміром %1 MiB</translation>
    </message>
    <message>
        <source>PeX support [OFF]</source>
        <translation type="obsolete">Підтримка PeX [Вимкнено]</translation>
    </message>
    <message>
        <source>Restart is required to toggle PeX support</source>
        <translation type="obsolete">Щоб перемкнути підтримку PeX, потрібно перезавантажити програму</translation>
    </message>
    <message>
        <source>The Web UI is listening on port %1</source>
        <translation type="obsolete">Веб-інтерфейс приєднано до порту %1</translation>
    </message>
    <message>
        <source>HTTP user agent is %1</source>
        <translation type="obsolete">Браузер користувача: %1</translation>
    </message>
    <message>
        <source>Reason: %1</source>
        <translation type="obsolete">Причина: %1</translation>
    </message>
    <message>
        <source>Note: new trackers were added to the existing torrent.</source>
        <translation type="obsolete">Нові трекери було додано до існуючого торрента.</translation>
    </message>
    <message>
        <source>Note: new URL seeds were added to the existing torrent.</source>
        <translation type="obsolete">Нові URL-сіди було додано до існуючого торрента.</translation>
    </message>
    <message>
        <source>An I/O error occured, &apos;%1&apos; paused.</source>
        <translation type="obsolete">Сталася помилка вводу/виводу, &apos;%1&apos; зупинено.</translation>
    </message>
    <message>
        <source>Removing torrent %1...</source>
        <translation type="obsolete">Видаляю торрент %1...</translation>
    </message>
    <message>
        <source>Pausing torrent %1...</source>
        <translation type="obsolete">Зупиняю торрент %1...</translation>
    </message>
    <message>
        <source>Error: The torrent %1 does not contain any file.</source>
        <translation type="obsolete">Помилка: Торрент %1 не містить жодного файла.</translation>
    </message>
    <message>
        <source>File sizes mismatch for torrent %1, pausing it.</source>
        <translation type="obsolete">Розміри файлів не збігаються для торрента %1, зупиняю його.</translation>
    </message>
    <message>
        <source>Torrent name: %1</source>
        <translation type="obsolete">Назва торрента: %1</translation>
    </message>
    <message>
        <source>Torrent size: %1</source>
        <translation type="obsolete">Розмір торрента: %1</translation>
    </message>
    <message>
        <source>Save path: %1</source>
        <translation type="obsolete">Шлях збереження: %1</translation>
    </message>
    <message>
        <source>The torrent was downloaded in %1.</source>
        <comment>The torrent was downloaded in 1 hour and 20 seconds</comment>
        <translation type="obsolete">Торрент було завантажено за %1.</translation>
    </message>
    <message>
        <source>Thank you for using qBittorrent.</source>
        <translation type="obsolete">Дякуємо, що ви користуєтесь qBittorrent.</translation>
    </message>
    <message>
        <source>[qBittorrent] %1 has finished downloading</source>
        <translation type="obsolete">[qBittorrent] Завантаження &quot;%1&quot; завершено</translation>
    </message>
</context>
<context>
    <name>ConsoleDlg</name>
    <message>
        <source>General</source>
        <translation type="obsolete">Загальні</translation>
    </message>
    <message>
        <source>Blocked IPs</source>
        <translation type="obsolete">Заблоковані IP</translation>
    </message>
    <message>
        <source>qBittorrent log viewer</source>
        <translation type="obsolete">Журнал подій qBittorrent</translation>
    </message>
</context>
<context>
    <name>CookiesDlg</name>
    <message>
        <source>Cookies management</source>
        <translation>Керування Cookies</translation>
    </message>
    <message>
        <source>Key</source>
        <extracomment>As in Key/Value pair</extracomment>
        <translation>Ключ</translation>
    </message>
    <message>
        <source>Value</source>
        <extracomment>As in Key/Value pair</extracomment>
        <translation>Значення</translation>
    </message>
    <message>
        <source>Common keys for cookies are : &apos;%1&apos;, &apos;%2&apos;.
You should get this information from your Web browser preferences.</source>
        <translation>Звичайні ключі для cookies: &apos;%1&apos;, &apos;%2&apos;.
Цю інформацію можна отримати з налаштувань веб-браузера.</translation>
    </message>
</context>
<context>
    <name>DNSUpdater</name>
    <message>
        <source>Your dynamic DNS was successfuly updated.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dynamic DNS error: The service is temporarily unavailable, it will be retried in 30 minutes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dynamic DNS error: hostname supplied does not exist under specified account.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dynamic DNS error: Invalid username/password.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dynamic DNS error: qBittorrent was blacklisted by the service, please report a bug at http://bugs.qbittorrent.org.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dynamic DNS error: %1 was returned by the service, please report a bug at http://bugs.qbittorrent.org.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dynamic DNS error: Your username was blocked due to abuse.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dynamic DNS error: supplied domain name is invalid.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dynamic DNS error: supplied username is too short.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dynamic DNS error: supplied password is too short.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DownloadThread</name>
    <message>
        <source>I/O Error</source>
        <translation>Помилка вводу/виводу</translation>
    </message>
    <message>
        <source>The remote host name was not found (invalid hostname)</source>
        <translation>Віддалений сервер не знайдено (неправильна адреса)</translation>
    </message>
    <message>
        <source>The operation was canceled</source>
        <translation>Операцію скасовано</translation>
    </message>
    <message>
        <source>The remote server closed the connection prematurely, before the entire reply was received and processed</source>
        <translation>Віддалений сервер закрив з&apos;єднання зарано, перед тим, як було отримано і оброблено відповідь</translation>
    </message>
    <message>
        <source>The connection to the remote server timed out</source>
        <translation>Вичерпано час на з&apos;єднання з віддаленим сервером</translation>
    </message>
    <message>
        <source>SSL/TLS handshake failed</source>
        <translation>Помилка SSL/TLS</translation>
    </message>
    <message>
        <source>The remote server refused the connection</source>
        <translation>Віддалений сервер відмовив у з&apos;єднанні</translation>
    </message>
    <message>
        <source>The connection to the proxy server was refused</source>
        <translation>Відмовлено у з&apos;єднанні з проксі-сервером</translation>
    </message>
    <message>
        <source>The proxy server closed the connection prematurely</source>
        <translation>Проксі-сервер закрив з&apos;єднання</translation>
    </message>
    <message>
        <source>The proxy host name was not found</source>
        <translation>Не знайдено проксі-сервер</translation>
    </message>
    <message>
        <source>The connection to the proxy timed out or the proxy did not reply in time to the request sent</source>
        <translation>Вичерпано час на з&apos;єднання з проксі</translation>
    </message>
    <message>
        <source>The proxy requires authentication in order to honour the request but did not accept any credentials offered</source>
        <translation>Проксі потребує автентифікації, але не прийняв автентифікаційних даних</translation>
    </message>
    <message>
        <source>The access to the remote content was denied (401)</source>
        <translation>Відмовлено у доступі до віддалених даних (401)</translation>
    </message>
    <message>
        <source>The operation requested on the remote content is not permitted</source>
        <translation>Операція щодо віддаленого контенту не дозволена</translation>
    </message>
    <message>
        <source>The remote content was not found at the server (404)</source>
        <translation>Віддалені дані не знайдено на сервері (404)</translation>
    </message>
    <message>
        <source>The remote server requires authentication to serve the content but the credentials provided were not accepted</source>
        <translation>Віддалений сервер потребує автентифікації, але не прийняв автентифікаційних даних</translation>
    </message>
    <message>
        <source>The Network Access API cannot honor the request because the protocol is not known</source>
        <translation>Невідомий протокол</translation>
    </message>
    <message>
        <source>The requested operation is invalid for this protocol</source>
        <translation>Операція неправильна для цього протоколу</translation>
    </message>
    <message>
        <source>An unknown network-related error was detected</source>
        <translation>Невідома помилка, пов&apos;язана з мережею</translation>
    </message>
    <message>
        <source>An unknown proxy-related error was detected</source>
        <translation>Невідома помилка, пов&apos;язана з проксі</translation>
    </message>
    <message>
        <source>An unknown error related to the remote content was detected</source>
        <translation>Невідома помилка, пов&apos;язана з віддаленим контентом</translation>
    </message>
    <message>
        <source>A breakdown in protocol was detected</source>
        <translation>Поломка в протоколі</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Невідома помилка</translation>
    </message>
</context>
<context>
    <name>EventManager</name>
    <message>
        <source>%1/s</source>
        <comment>e.g. 120 KiB/s</comment>
        <translation>%1/с</translation>
    </message>
    <message>
        <source>Working</source>
        <translation>Працюю</translation>
    </message>
    <message>
        <source>Updating...</source>
        <translation>Оновлюю...</translation>
    </message>
    <message>
        <source>Not working</source>
        <translation>Не працюю</translation>
    </message>
    <message>
        <source>Not contacted yet</source>
        <translation>Ще не було зв&apos;язку з трекером</translation>
    </message>
    <message>
        <source>this session</source>
        <translation>Поточна сесія</translation>
    </message>
    <message>
        <source>/s</source>
        <comment>/second (i.e. per second)</comment>
        <translation>/с</translation>
    </message>
    <message>
        <source>Seeded for %1</source>
        <comment>e.g. Seeded for 3m10s</comment>
        <translation>Роздавав %1</translation>
    </message>
    <message>
        <source>%1 max</source>
        <comment>e.g. 10 max</comment>
        <translation>максимально %1</translation>
    </message>
</context>
<context>
    <name>ExecutionLog</name>
    <message>
        <source>Form</source>
        <translation type="obsolete">Форма</translation>
    </message>
    <message>
        <source>General</source>
        <translation>Загальні</translation>
    </message>
    <message>
        <source>Blocked IPs</source>
        <translation>Заблоковані IP</translation>
    </message>
</context>
<context>
    <name>FeedDownloader</name>
    <message>
        <source>RSS Feed downloader</source>
        <translation type="obsolete">Завантажувач подач RSS</translation>
    </message>
    <message>
        <source>RSS feed:</source>
        <translation type="obsolete">RSS-подача:</translation>
    </message>
    <message>
        <source>Feed name</source>
        <translation type="obsolete">Назва подачі</translation>
    </message>
    <message>
        <source>Automatically download torrents from this feed</source>
        <translation type="obsolete">Автоматично завантажувати торренти з цієї подачі</translation>
    </message>
    <message>
        <source>Download filters</source>
        <translation type="obsolete">Фільтри завантажень</translation>
    </message>
    <message>
        <source>Filters:</source>
        <translation type="obsolete">Фільтри:</translation>
    </message>
    <message>
        <source>Filter settings</source>
        <translation type="obsolete">Налаштування фільтрів</translation>
    </message>
    <message>
        <source>Matches:</source>
        <translation type="obsolete">Результати:</translation>
    </message>
    <message>
        <source>Does not match:</source>
        <translation type="obsolete">Не підходить:</translation>
    </message>
    <message>
        <source>Destination folder:</source>
        <translation type="obsolete">Папка призначення:</translation>
    </message>
    <message>
        <source>...</source>
        <translation type="obsolete">...</translation>
    </message>
    <message>
        <source>Filter testing</source>
        <translation type="obsolete">Тестування фільтру</translation>
    </message>
    <message>
        <source>Torrent title:</source>
        <translation type="obsolete">Заголовок торренту:</translation>
    </message>
    <message>
        <source>Result:</source>
        <translation type="obsolete">Результат:</translation>
    </message>
    <message>
        <source>Test</source>
        <translation type="obsolete">Тест</translation>
    </message>
    <message>
        <source>Import...</source>
        <translation type="obsolete">Імпорт...</translation>
    </message>
    <message>
        <source>Export...</source>
        <translation type="obsolete">Експорт...</translation>
    </message>
    <message>
        <source>Rename filter</source>
        <translation type="obsolete">Перейменувати фільтр</translation>
    </message>
    <message>
        <source>Remove filter</source>
        <translation type="obsolete">Видалити фільтр</translation>
    </message>
    <message>
        <source>Add filter</source>
        <translation type="obsolete">Додати фільтр</translation>
    </message>
</context>
<context>
    <name>FeedDownloaderDlg</name>
    <message>
        <source>New filter</source>
        <translation type="obsolete">Новий фільтр</translation>
    </message>
    <message>
        <source>Please choose a name for this filter</source>
        <translation type="obsolete">Будь ласка, виберіть назву для цього фільтру</translation>
    </message>
    <message>
        <source>Filter name:</source>
        <translation type="obsolete">Назва фільтру:</translation>
    </message>
    <message>
        <source>Invalid filter name</source>
        <translation type="obsolete">Неправильна назва фільтру</translation>
    </message>
    <message>
        <source>The filter name cannot be left empty.</source>
        <translation type="obsolete">Назва фільтру не може бути порожньою.</translation>
    </message>
    <message>
        <source>This filter name is already in use.</source>
        <translation type="obsolete">Ця назва вже використана.</translation>
    </message>
    <message>
        <source>Filter testing error</source>
        <translation type="obsolete">Помилка тестування фільтру</translation>
    </message>
    <message>
        <source>Please specify a test torrent name.</source>
        <translation type="obsolete">Будь ласка, вкажіть ім&apos;я торренту.</translation>
    </message>
    <message>
        <source>matches</source>
        <translation type="obsolete">результати</translation>
    </message>
    <message>
        <source>does not match</source>
        <translation type="obsolete">не підходить</translation>
    </message>
    <message>
        <source>Select file to import</source>
        <translation type="obsolete">Виберіть файл для імпорту</translation>
    </message>
    <message>
        <source>Filters Files</source>
        <translation type="obsolete">Файли фільтрів</translation>
    </message>
    <message>
        <source>Import successful</source>
        <translation type="obsolete">Успішно імпортовано</translation>
    </message>
    <message>
        <source>Filters import was successful.</source>
        <translation type="obsolete">Імпорт фільтрів успішний.</translation>
    </message>
    <message>
        <source>Import failure</source>
        <translation type="obsolete">Невдалий імпорт</translation>
    </message>
    <message>
        <source>Filters could not be imported due to an I/O error.</source>
        <translation type="obsolete">Фільтри не були імпортовані через помилку вводу/виводу.</translation>
    </message>
    <message>
        <source>Select destination file</source>
        <translation type="obsolete">Виберіть цільовий файл</translation>
    </message>
    <message>
        <source>Export successful</source>
        <translation type="obsolete">Успішно експортовано</translation>
    </message>
    <message>
        <source>Filters export was successful.</source>
        <translation type="obsolete">Експорт фільтрів успішний.</translation>
    </message>
    <message>
        <source>Export failure</source>
        <translation type="obsolete">Невдалий експорт</translation>
    </message>
    <message>
        <source>Filters could not be exported due to an I/O error.</source>
        <translation type="obsolete">Фільтри не були експортовані через помилку вводу/виводу.</translation>
    </message>
    <message>
        <source>Choose save path</source>
        <translation type="obsolete">Виберіть шлях збереження</translation>
    </message>
</context>
<context>
    <name>FeedList</name>
    <message>
        <source>Unread</source>
        <translation type="obsolete">Непрочитані</translation>
    </message>
</context>
<context>
    <name>FeedListWidget</name>
    <message>
        <source>RSS feeds</source>
        <translation>RSS-подачі</translation>
    </message>
    <message>
        <source>Unread</source>
        <translation>Непрочитані</translation>
    </message>
</context>
<context>
    <name>GUI</name>
    <message>
        <source>Open Torrent Files</source>
        <translation type="obsolete">Відкрити Torrent-файли</translation>
    </message>
    <message>
        <source>Torrent Files</source>
        <translation type="obsolete">Torrent-файли</translation>
    </message>
    <message>
        <source>qBittorrent</source>
        <translation type="obsolete">qBittorrent</translation>
    </message>
    <message>
        <source>Transfers</source>
        <translation type="obsolete">Завантаження</translation>
    </message>
    <message>
        <source>qBittorrent %1</source>
        <comment>e.g: qBittorrent v0.x</comment>
        <translation type="obsolete">qBittorrent %1</translation>
    </message>
    <message>
        <source>DL speed: %1 KiB/s</source>
        <comment>e.g: Download speed: 10 KiB/s</comment>
        <translation type="obsolete">Швидкість прийому: %1 КіБ/с</translation>
    </message>
    <message>
        <source>UP speed: %1 KiB/s</source>
        <comment>e.g: Upload speed: 10 KiB/s</comment>
        <translation type="obsolete">Швидкість віддачі: %1 КіБ/с</translation>
    </message>
    <message>
        <source>%1 has finished downloading.</source>
        <comment>e.g: xxx.avi has finished downloading.</comment>
        <translation type="obsolete">Завантаження &apos;%1&apos; закінчилось.</translation>
    </message>
    <message>
        <source>I/O Error</source>
        <comment>i.e: Input/Output Error</comment>
        <translation type="obsolete">Помилка вводу/виводу</translation>
    </message>
    <message>
        <source>Search</source>
        <translation type="obsolete">Пошук</translation>
    </message>
    <message>
        <source>RSS</source>
        <translation type="obsolete">RSS</translation>
    </message>
    <message>
        <source>An I/O error occured for torrent %1.
 Reason: %2</source>
        <comment>e.g: An error occured for torrent xxx.avi.
 Reason: disk is full.</comment>
        <translation type="obsolete">Сталася помилка вводу/виводу для торрента %1. Причина: %2</translation>
    </message>
    <message>
        <source>Alt+1</source>
        <comment>shortcut to switch to first tab</comment>
        <translation type="obsolete">Alt+1</translation>
    </message>
    <message>
        <source>Url download error</source>
        <translation type="obsolete">Помилка завантаження url</translation>
    </message>
    <message>
        <source>Couldn&apos;t download file at url: %1, reason: %2.</source>
        <translation type="obsolete">Не вдалося завантажити файл з URL: %1, причина: %2.</translation>
    </message>
    <message>
        <source>Options were saved successfully.</source>
        <translation type="obsolete">Налаштування були успішно збережені.</translation>
    </message>
    <message>
        <source>Download completion</source>
        <translation type="obsolete">Завантажено</translation>
    </message>
    <message>
        <source>Some files are currently transferring.
Are you sure you want to quit qBittorrent?</source>
        <translation type="obsolete">Не всі завантаження завершені. Ви впевнені, що хочете вийти?</translation>
    </message>
    <message>
        <source>Alt+2</source>
        <comment>shortcut to switch to third tab</comment>
        <translation type="obsolete">Alt+2</translation>
    </message>
    <message>
        <source>Alt+3</source>
        <comment>shortcut to switch to fourth tab</comment>
        <translation type="obsolete">Alt+3</translation>
    </message>
    <message>
        <source>Global Upload Speed Limit</source>
        <translation type="obsolete">Глобальний ліміт вивантаження</translation>
    </message>
    <message>
        <source>Global Download Speed Limit</source>
        <translation type="obsolete">Глобальний ліміт завантаження</translation>
    </message>
    <message>
        <source>qBittorrent %1 (Down: %2/s, Up: %3/s)</source>
        <comment>%1 is qBittorrent version</comment>
        <translation type="obsolete">qBittorrent %1 (Зав.: %2/с, Вив.: %3/с)</translation>
    </message>
    <message>
        <source>Recursive download confirmation</source>
        <translation type="obsolete">Підтвердження рекурсивного завантаження</translation>
    </message>
    <message>
        <source>The torrent %1 contains torrent files, do you want to proceed with their download?</source>
        <translation type="obsolete">Торрент %1 містить інші торренти. Завантажувати і їх?</translation>
    </message>
    <message>
        <source>Torrent file association</source>
        <translation type="obsolete">Відкривання torrent-файлів</translation>
    </message>
    <message>
        <source>qBittorrent is not the default application to open torrent files or Magnet links.
Do you want to associate qBittorrent to torrent files and Magnet links?</source>
        <translation type="obsolete">qBittorrent не є програмою за замовчуванням для відкривання торрентів та Магнітних посилань.
Встановити qBittorrent як програму для відкривання torrent-файлів та Магнітних посилань?</translation>
    </message>
    <message>
        <source>Transfers (%1)</source>
        <translation type="obsolete">Завантаження (%1)</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation type="obsolete">Так</translation>
    </message>
    <message>
        <source>No</source>
        <translation type="obsolete">Ні</translation>
    </message>
    <message>
        <source>Never</source>
        <translation type="obsolete">Ніколи</translation>
    </message>
    <message>
        <source>Always</source>
        <translation type="obsolete">Завжди</translation>
    </message>
    <message>
        <source>Exiting qBittorrent</source>
        <translation type="obsolete">Вихід із qBittorrent</translation>
    </message>
    <message>
        <source>Set the password...</source>
        <translation type="obsolete">Встановити пароль...</translation>
    </message>
    <message>
        <source>Password update</source>
        <translation type="obsolete">Оновити пароль</translation>
    </message>
    <message>
        <source>The UI lock password has been successfully updated</source>
        <translation type="obsolete">Пароль блокування інтерфейсу був успішно оновлений</translation>
    </message>
    <message>
        <source>UI lock password</source>
        <translation type="obsolete">
</translation>
    </message>
    <message>
        <source>Please type the UI lock password:</source>
        <translation type="obsolete">Будь ласка, введіть пароль блокування інтерфейсу:</translation>
    </message>
    <message>
        <source>Invalid password</source>
        <translation type="obsolete">Неправильний пароль</translation>
    </message>
    <message>
        <source>The password is invalid</source>
        <translation type="obsolete">Пароль неправильний</translation>
    </message>
    <message>
        <source>A newer version is available</source>
        <translation type="obsolete">Доступна новіше версія</translation>
    </message>
    <message>
        <source>A newer version of qBittorrent is available on Sourceforge.
Would you like to update qBittorrent to version %1?</source>
        <translation type="obsolete">Нова версія qBittorrent доступна на SourceForge.
Чи хочете ви оновити qBittorrent до версії %1?</translation>
    </message>
    <message>
        <source>Impossible to update qBittorrent</source>
        <translation type="obsolete">Неможливо оновити qBittorrent</translation>
    </message>
    <message>
        <source>qBittorrent failed to update, reason: %1</source>
        <translation type="obsolete">qBittorrent не вдалося оновити. Причина: %1</translation>
    </message>
</context>
<context>
    <name>GeoIP</name>
    <message>
        <source>Australia</source>
        <translation type="obsolete">Австралія</translation>
    </message>
    <message>
        <source>Argentina</source>
        <translation type="obsolete">Аргентина</translation>
    </message>
    <message>
        <source>Austria</source>
        <translation type="obsolete">Австрія</translation>
    </message>
    <message>
        <source>United Arab Emirates</source>
        <translation type="obsolete">Об&apos;єднані Арабські Емірати</translation>
    </message>
    <message>
        <source>Brazil</source>
        <translation type="obsolete">Бразилія</translation>
    </message>
    <message>
        <source>Bulgaria</source>
        <translation type="obsolete">Болгарія</translation>
    </message>
    <message>
        <source>Belarus</source>
        <translation type="obsolete">Білорусь</translation>
    </message>
    <message>
        <source>Belgium</source>
        <translation type="obsolete">Бельгія</translation>
    </message>
    <message>
        <source>Bosnia</source>
        <translation type="obsolete">Боснія</translation>
    </message>
    <message>
        <source>Canada</source>
        <translation type="obsolete">Канада</translation>
    </message>
    <message>
        <source>Czech Republic</source>
        <translation type="obsolete">Чехія</translation>
    </message>
    <message>
        <source>China</source>
        <translation type="obsolete">Китай</translation>
    </message>
    <message>
        <source>Costa Rica</source>
        <translation type="obsolete">Коста Ріка</translation>
    </message>
    <message>
        <source>Switzerland</source>
        <translation type="obsolete">Швейцарія</translation>
    </message>
    <message>
        <source>Germany</source>
        <translation type="obsolete">Німеччина</translation>
    </message>
    <message>
        <source>Denmark</source>
        <translation type="obsolete">Данія</translation>
    </message>
    <message>
        <source>Algeria</source>
        <translation type="obsolete">Алжир</translation>
    </message>
    <message>
        <source>Spain</source>
        <translation type="obsolete">Іспанія</translation>
    </message>
    <message>
        <source>Egypt</source>
        <translation type="obsolete">Єгипет</translation>
    </message>
    <message>
        <source>Finland</source>
        <translation type="obsolete">Фінляндія</translation>
    </message>
    <message>
        <source>France</source>
        <translation type="obsolete">Франція</translation>
    </message>
    <message>
        <source>Greece</source>
        <translation type="obsolete">Греція</translation>
    </message>
    <message>
        <source>Georgia</source>
        <translation type="obsolete">Грузія</translation>
    </message>
    <message>
        <source>Hungary</source>
        <translation type="obsolete">Угорщина</translation>
    </message>
    <message>
        <source>Croatia</source>
        <translation type="obsolete">Хорватія</translation>
    </message>
    <message>
        <source>Italy</source>
        <translation type="obsolete">Італія</translation>
    </message>
    <message>
        <source>India</source>
        <translation type="obsolete">Індія</translation>
    </message>
    <message>
        <source>Israel</source>
        <translation type="obsolete">Ізраїль</translation>
    </message>
    <message>
        <source>Ireland</source>
        <translation type="obsolete">Ірландія</translation>
    </message>
    <message>
        <source>Iceland</source>
        <translation type="obsolete">Ісландія</translation>
    </message>
    <message>
        <source>Indonesia</source>
        <translation type="obsolete">Індонезія</translation>
    </message>
    <message>
        <source>Japan</source>
        <translation type="obsolete">Японія</translation>
    </message>
    <message>
        <source>South Korea</source>
        <translation type="obsolete">Південна Корея</translation>
    </message>
    <message>
        <source>Luxembourg</source>
        <translation type="obsolete">Люксембург</translation>
    </message>
    <message>
        <source>Malaysia</source>
        <translation type="obsolete">Малайзія</translation>
    </message>
    <message>
        <source>Mexico</source>
        <translation type="obsolete">Мексика</translation>
    </message>
    <message>
        <source>Serbia</source>
        <translation type="obsolete">Сербія</translation>
    </message>
    <message>
        <source>Morocco</source>
        <translation type="obsolete">Марокко</translation>
    </message>
    <message>
        <source>Netherlands</source>
        <translation type="obsolete">Нідерланди</translation>
    </message>
    <message>
        <source>Norway</source>
        <translation type="obsolete">Норвегія</translation>
    </message>
    <message>
        <source>New Zealand</source>
        <translation type="obsolete">Нова Зеландія</translation>
    </message>
    <message>
        <source>Portugal</source>
        <translation type="obsolete">Португалія</translation>
    </message>
    <message>
        <source>Poland</source>
        <translation type="obsolete">Польща</translation>
    </message>
    <message>
        <source>Pakistan</source>
        <translation type="obsolete">Пакистан</translation>
    </message>
    <message>
        <source>Philippines</source>
        <translation type="obsolete">Філіппіни</translation>
    </message>
    <message>
        <source>Russia</source>
        <translation type="obsolete">Росія</translation>
    </message>
    <message>
        <source>Romania</source>
        <translation type="obsolete">Румунія</translation>
    </message>
    <message>
        <source>France (Reunion Island)</source>
        <translation type="obsolete">Франція (острів Реюньйон)</translation>
    </message>
    <message>
        <source>Sweden</source>
        <translation type="obsolete">Швеція</translation>
    </message>
    <message>
        <source>Slovakia</source>
        <translation type="obsolete">Словаччина</translation>
    </message>
    <message>
        <source>Singapore</source>
        <translation type="obsolete">Сінгапур</translation>
    </message>
    <message>
        <source>Slovenia</source>
        <translation type="obsolete">Словенія</translation>
    </message>
    <message>
        <source>Taiwan</source>
        <translation type="obsolete">Тайвань</translation>
    </message>
    <message>
        <source>Turkey</source>
        <translation type="obsolete">Туреччина</translation>
    </message>
    <message>
        <source>Thailand</source>
        <translation type="obsolete">Таїланд</translation>
    </message>
    <message>
        <source>USA</source>
        <translation type="obsolete">США</translation>
    </message>
    <message>
        <source>Ukraine</source>
        <translation type="obsolete">Україна</translation>
    </message>
    <message>
        <source>South Africa</source>
        <translation type="obsolete">Південна Африка</translation>
    </message>
    <message>
        <source>Saudi Arabia</source>
        <translation type="obsolete">Саудівська Аравія</translation>
    </message>
</context>
<context>
    <name>HeadlessLoader</name>
    <message>
        <source>Information</source>
        <translation>Інформація</translation>
    </message>
    <message>
        <source>To control qBittorrent, access the Web UI at http://localhost:%1</source>
        <translation>Щоб керувати qBittorrent&apos;ом, перейдіть за адресою http://localhost:%1</translation>
    </message>
    <message>
        <source>The Web UI administrator user name is: %1</source>
        <translation>Ім&apos;я користувача-адміністратора в Веб-інтерфейсі: %1</translation>
    </message>
    <message>
        <source>The Web UI administrator password is still the default one: %1</source>
        <translation>Пароль адміністратора в Веб-інтерфейсі все ще стандартний: %1</translation>
    </message>
    <message>
        <source>This is a security risk, please consider changing your password from program preferences.</source>
        <translation>Це ризик безпеки, будь ласка, встановіть пароль в налаштуваннях програми.</translation>
    </message>
</context>
<context>
    <name>HttpConnection</name>
    <message>
        <source>Your IP address has been banned after too many failed authentication attempts.</source>
        <translation>Вашу IP-адресу було заблоковано, через те, що було здійснено забагато спроб автентифікації.</translation>
    </message>
    <message>
        <source>D: %1/s - T: %2</source>
        <comment>Download speed: x KiB/s - Transferred: x MiB</comment>
        <translation>Зав.: %1/с (%2)</translation>
    </message>
    <message>
        <source>U: %1/s - T: %2</source>
        <comment>Upload speed: x KiB/s - Transferred: x MiB</comment>
        <translation>Вив.: %1/с (%2)</translation>
    </message>
</context>
<context>
    <name>HttpServer</name>
    <message>
        <source>File</source>
        <translation>Файл</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Редагувати</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Допомога</translation>
    </message>
    <message>
        <source>Delete from HD</source>
        <translation type="obsolete">Видалити з жорсткого диска</translation>
    </message>
    <message>
        <source>Download Torrents from their URL or Magnet link</source>
        <translation>Завантажити торренти з іх URL або Магнітного посилання</translation>
    </message>
    <message>
        <source>Only one link per line</source>
        <translation>Одне посилання на рядок</translation>
    </message>
    <message>
        <source>Download</source>
        <translation>Завантажити</translation>
    </message>
    <message>
        <source>Download local torrent</source>
        <translation>Завантажити локальний торрент</translation>
    </message>
    <message>
        <source>Torrent files were correctly added to download list.</source>
        <translation>Торрент-файли були успішно додані до списку завантажень.</translation>
    </message>
    <message>
        <source>Point to torrent file</source>
        <translation>Вказати торрент-файл</translation>
    </message>
    <message>
        <source>Are you sure you want to delete the selected torrents from the transfer list and hard disk?</source>
        <translation>Ви впевнені, що хочете видалити вибрані торренти зі списку завантажень і жорсткого диска?</translation>
    </message>
    <message>
        <source>Download rate limit must be greater than 0 or disabled.</source>
        <translation>Ліміт швидкості завантаження повинен бути більшим від 0 або відсутнім.</translation>
    </message>
    <message>
        <source>Upload rate limit must be greater than 0 or disabled.</source>
        <translation>Ліміт швидкості вивантаження повинен бути більшим від 0 або відсутнім.</translation>
    </message>
    <message>
        <source>Maximum number of connections limit must be greater than 0 or disabled.</source>
        <translation>Максимальна кількість з&apos;єднань повинна бути більша за 0 або відсутня.</translation>
    </message>
    <message>
        <source>Maximum number of connections per torrent limit must be greater than 0 or disabled.</source>
        <translation>Максимальна кількість з&apos;єднань на торрент повинна бути більша за 0 або відсутня.</translation>
    </message>
    <message>
        <source>Maximum number of upload slots per torrent limit must be greater than 0 or disabled.</source>
        <translation>Максимальна кількість з&apos;єднань для вивантаження на торрент повинна бути більша за 0 або відсутня.</translation>
    </message>
    <message>
        <source>Unable to save program preferences, qBittorrent is probably unreachable.</source>
        <translation>Не вдалося зберегти налаштування програми.</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Мова</translation>
    </message>
    <message>
        <source>The port used for incoming connections must be greater than 1024 and less than 65535.</source>
        <translation>Порт, який використовується для вхідних підключень, повинен бути між 1024 і 65535.</translation>
    </message>
    <message>
        <source>The port used for the Web UI must be greater than 1024 and less than 65535.</source>
        <translation>Порт, який використовується для Веб-інтерфейсу повинен бути між 1024 і 65535.</translation>
    </message>
    <message>
        <source>The Web UI username must be at least 3 characters long.</source>
        <translation>Ім&apos;я користувача Веб-інтерфейсу повинне містити хоча б 3 символи.</translation>
    </message>
    <message>
        <source>The Web UI password must be at least 3 characters long.</source>
        <translation>Пароль від Веб-інтерфейсу повинен містити хоча б 3 символи.</translation>
    </message>
    <message>
        <source>Downloaded</source>
        <comment>Is the file downloaded or not?</comment>
        <translation>Завантажено</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Зберегти</translation>
    </message>
    <message>
        <source>qBittorrent client is not reachable</source>
        <translation>Клієнт qBittorrent недосяжний</translation>
    </message>
    <message>
        <source>HTTP Server</source>
        <translation type="unfinished">HTTP сервер</translation>
    </message>
    <message>
        <source>Torrent path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Torrent name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The following parameters are supported:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LegalNotice</name>
    <message>
        <source>Legal Notice</source>
        <translation>Примітка</translation>
    </message>
    <message>
        <source>Legal notice</source>
        <translation>Примітка</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Скасувати</translation>
    </message>
    <message>
        <source>I Agree</source>
        <translation>Я погоджуюсь</translation>
    </message>
    <message>
        <source>qBittorrent is a file sharing program. When you run a torrent, its data will be made available to others by means of upload. Any content you share is your sole responsibility.

No further notices will be issued.</source>
        <translation>qBittorrent - це програма для роздачі файлів. Коли ви запускаєте торрент, його дані будуть доступні іншим через вивантаження. Всі дані, які ви роздаєте, на вашій відповідальності

Ця замітка більше не з&apos;являтиметься.</translation>
    </message>
    <message>
        <source>Press %1 key to accept and continue...</source>
        <translation>Натисніть %1, щоб погодитись і продовжити...</translation>
    </message>
</context>
<context>
    <name>LineEdit</name>
    <message>
        <source>Clear the text</source>
        <translation>Очистити текст</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>&amp;Edit</source>
        <translation>&amp;Редагувати</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Файл</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Допомога</translation>
    </message>
    <message>
        <source>Preview file</source>
        <translation type="obsolete">Файл перегляду</translation>
    </message>
    <message>
        <source>Clear log</source>
        <translation type="obsolete">Очистити лог</translation>
    </message>
    <message>
        <source>Decrease priority</source>
        <translation>Зменшити приорітет</translation>
    </message>
    <message>
        <source>Increase priority</source>
        <translation>Збільшити приорітет</translation>
    </message>
    <message>
        <source>&amp;Tools</source>
        <translation>&amp;Інструменти</translation>
    </message>
    <message>
        <source>&amp;View</source>
        <translation>&amp;Показати</translation>
    </message>
    <message>
        <source>&amp;Add File...</source>
        <translation type="obsolete">&amp;Додати файл...</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation type="obsolete">Ви&amp;хід</translation>
    </message>
    <message>
        <source>&amp;Options...</source>
        <translation>&amp;Налаштування...</translation>
    </message>
    <message>
        <source>Add &amp;URL...</source>
        <translation type="obsolete">Д&amp;одати URL...</translation>
    </message>
    <message>
        <source>Torrent &amp;creator</source>
        <translation>Створювач &amp;торрентів</translation>
    </message>
    <message>
        <source>Set upload limit...</source>
        <translation>Встановити ліміт вивантаження...</translation>
    </message>
    <message>
        <source>Set download limit...</source>
        <translation>Встановити ліміт завантаження...</translation>
    </message>
    <message>
        <source>Set global download limit...</source>
        <translation>Встановити глобальний ліміт завантаження...</translation>
    </message>
    <message>
        <source>Set global upload limit...</source>
        <translation>Встановити глобальний ліміт вивантаження...</translation>
    </message>
    <message>
        <source>&amp;Log viewer...</source>
        <translation type="obsolete">Показати &amp;журнал подій...</translation>
    </message>
    <message>
        <source>Top &amp;tool bar</source>
        <translation>&amp;Верхня панель</translation>
    </message>
    <message>
        <source>Display top tool bar</source>
        <translation>Показувати верхню панель</translation>
    </message>
    <message>
        <source>&amp;Speed in title bar</source>
        <translation>&amp;Швидкість у заголовку</translation>
    </message>
    <message>
        <source>Show transfer speed in title bar</source>
        <translation>Показувати швидкість завантаження і вивантаження у заголовку</translation>
    </message>
    <message>
        <source>Alternative speed limits</source>
        <translation>Альтернативні обмеження швидкості</translation>
    </message>
    <message>
        <source>&amp;About</source>
        <translation>&amp;Про програму</translation>
    </message>
    <message>
        <source>&amp;Pause</source>
        <translation>При&amp;зупинити</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>&amp;Видалити</translation>
    </message>
    <message>
        <source>P&amp;ause All</source>
        <translation>З&amp;упинити всі</translation>
    </message>
    <message>
        <source>Visit &amp;Website</source>
        <translation>Відвідати веб&amp;сайт</translation>
    </message>
    <message>
        <source>Report a &amp;bug</source>
        <translation>Повідомити про &amp;помилку</translation>
    </message>
    <message>
        <source>&amp;Documentation</source>
        <translation>&amp;Документація</translation>
    </message>
    <message>
        <source>&amp;RSS reader</source>
        <translation>&amp;Читач RSS</translation>
    </message>
    <message>
        <source>Search &amp;engine</source>
        <translation>По&amp;шуковик</translation>
    </message>
    <message>
        <source>Log viewer</source>
        <translation type="obsolete">Журнал подій</translation>
    </message>
    <message>
        <source>Lock qBittorrent</source>
        <translation>Заблокувати qBittorrent</translation>
    </message>
    <message>
        <source>Ctrl+L</source>
        <translation>Ctrl+L</translation>
    </message>
    <message>
        <source>Shutdown computer when downloads complete</source>
        <translation type="obsolete">Вимкнути комп&apos;ютер, коли завершаться завантаження</translation>
    </message>
    <message>
        <source>&amp;Resume</source>
        <translation>&amp;Продовжити</translation>
    </message>
    <message>
        <source>R&amp;esume All</source>
        <translation>П&amp;родовжити всі</translation>
    </message>
    <message>
        <source>Shutdown qBittorrent when downloads complete</source>
        <translation type="obsolete">Вимкнути qBittorrent після завершення завантажень</translation>
    </message>
    <message>
        <source>Exit</source>
        <translation>Вийти</translation>
    </message>
    <message>
        <source>Import torrent...</source>
        <translation>Імпортувати торрент...</translation>
    </message>
    <message>
        <source>Donate money</source>
        <translation>Пожертвувати гроші</translation>
    </message>
    <message>
        <source>If you like qBittorrent, please donate!</source>
        <translation>Якщо вам подобається qBittorrent, будь ласка, пожертвуйте кошти!</translation>
    </message>
    <message>
        <source>qBittorrent %1</source>
        <comment>e.g: qBittorrent v0.x</comment>
        <translation>qBittorrent %1</translation>
    </message>
    <message>
        <source>Set the password...</source>
        <translation>Встановити пароль...</translation>
    </message>
    <message>
        <source>Transfers</source>
        <translation>Завантаження</translation>
    </message>
    <message>
        <source>Torrent file association</source>
        <translation>Асоціації torrent-файлів</translation>
    </message>
    <message>
        <source>qBittorrent is not the default application to open torrent files or Magnet links.
Do you want to associate qBittorrent to torrent files and Magnet links?</source>
        <translation>qBittorrent не є програмою за замовчуванням для відкривання торрентів.
Встановити qBittorrent як програму для відкривання torrent-файлів та Магнітних посилань?</translation>
    </message>
    <message>
        <source>UI lock password</source>
        <translation>Пароль блокування інтерфейсу</translation>
    </message>
    <message>
        <source>Please type the UI lock password:</source>
        <translation>Будь ласка, введіть пароль блокування інтерфейсу:</translation>
    </message>
    <message>
        <source>Password update</source>
        <translation>Оновити пароль</translation>
    </message>
    <message>
        <source>The UI lock password has been successfully updated</source>
        <translation>Пароль блокування інтерфейсу був успішно оновлений</translation>
    </message>
    <message>
        <source>RSS</source>
        <translation>RSS</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Пошук</translation>
    </message>
    <message>
        <source>Transfers (%1)</source>
        <translation>Завантаження (%1)</translation>
    </message>
    <message>
        <source>Download completion</source>
        <translation>Завантажено</translation>
    </message>
    <message>
        <source>%1 has finished downloading.</source>
        <comment>e.g: xxx.avi has finished downloading.</comment>
        <translation>Завантаження &apos;%1&apos; закінчилось.</translation>
    </message>
    <message>
        <source>I/O Error</source>
        <comment>i.e: Input/Output Error</comment>
        <translation>Помилка вводу/виводу</translation>
    </message>
    <message>
        <source>An I/O error occured for torrent %1.
 Reason: %2</source>
        <comment>e.g: An error occured for torrent xxx.avi.
 Reason: disk is full.</comment>
        <translation>Сталася помилка вводу/виводу для торрента %1.
Причина: %2</translation>
    </message>
    <message>
        <source>Alt+1</source>
        <comment>shortcut to switch to first tab</comment>
        <translation>Alt+1</translation>
    </message>
    <message>
        <source>Alt+2</source>
        <comment>shortcut to switch to third tab</comment>
        <translation>Alt+2</translation>
    </message>
    <message>
        <source>Ctrl+F</source>
        <comment>shortcut to switch to search tab</comment>
        <translation>Ctrl+F</translation>
    </message>
    <message>
        <source>Alt+3</source>
        <comment>shortcut to switch to fourth tab</comment>
        <translation>Alt+3</translation>
    </message>
    <message>
        <source>Recursive download confirmation</source>
        <translation>Підтвердження рекурсивного завантаження</translation>
    </message>
    <message>
        <source>The torrent %1 contains torrent files, do you want to proceed with their download?</source>
        <translation>Торрент %1 містить інші торренти. Завантажувати і їх?</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Так</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Ні</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Ніколи</translation>
    </message>
    <message>
        <source>Url download error</source>
        <translation>Помилка завантаження URL</translation>
    </message>
    <message>
        <source>Couldn&apos;t download file at url: %1, reason: %2.</source>
        <translation>Не вдалося завантажити файл з URL: %1, причина: %2.</translation>
    </message>
    <message>
        <source>Global Upload Speed Limit</source>
        <translation>Глобальний ліміт вивантаження</translation>
    </message>
    <message>
        <source>Global Download Speed Limit</source>
        <translation>Глобальний ліміт завантаження</translation>
    </message>
    <message>
        <source>Invalid password</source>
        <translation>Неправильний пароль</translation>
    </message>
    <message>
        <source>The password is invalid</source>
        <translation>Пароль неправильний</translation>
    </message>
    <message>
        <source>Exiting qBittorrent</source>
        <translation>Вихід із qBittorrent</translation>
    </message>
    <message>
        <source>Some files are currently transferring.
Are you sure you want to quit qBittorrent?</source>
        <translation>Не всі завантаження завершені.
Ви впевнені, що хочете вийти з програми?</translation>
    </message>
    <message>
        <source>Always</source>
        <translation>Завжди</translation>
    </message>
    <message>
        <source>Open Torrent Files</source>
        <translation>Відкрити torrent-файли</translation>
    </message>
    <message>
        <source>Torrent Files</source>
        <translation>Torrent-файли</translation>
    </message>
    <message>
        <source>Options were saved successfully.</source>
        <translation>Налаштування були успішно збережені.</translation>
    </message>
    <message>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <source>DL speed: %1 KiB/s</source>
        <comment>e.g: Download speed: 10 KiB/s</comment>
        <translation>Швидкість прийому: %1 КіБ/с</translation>
    </message>
    <message>
        <source>UP speed: %1 KiB/s</source>
        <comment>e.g: Upload speed: 10 KiB/s</comment>
        <translation>Швидкість віддачі: %1 КіБ/с</translation>
    </message>
    <message>
        <source>qBittorrent %1 (Down: %2/s, Up: %3/s)</source>
        <comment>%1 is qBittorrent version</comment>
        <translation>qBittorrent %1 (Зав.: %2/с, Вив.: %3/с)</translation>
    </message>
    <message>
        <source>A newer version is available</source>
        <translation>Доступна новіша версія</translation>
    </message>
    <message>
        <source>A newer version of qBittorrent is available on Sourceforge.
Would you like to update qBittorrent to version %1?</source>
        <translation>Нова версія qBittorrent доступна на SourceForge.
Чи хочете ви оновити qBittorrent до версії %1?</translation>
    </message>
    <message>
        <source>Impossible to update qBittorrent</source>
        <translation>Неможливо оновити qBittorrent</translation>
    </message>
    <message>
        <source>qBittorrent failed to update, reason: %1</source>
        <translation>qBittorrent не вдалося оновити. Причина: %1</translation>
    </message>
    <message>
        <source>&amp;Add torrent file...</source>
        <translation>&amp;Додати торрент-файл...</translation>
    </message>
    <message>
        <source>Add &amp;link to torrent...</source>
        <translation>Додати &amp;посилання на торрент...</translation>
    </message>
    <message>
        <source>Import existing torrent...</source>
        <translation>Імпортувати існуючий торрент...</translation>
    </message>
    <message>
        <source>Execution &amp;Log</source>
        <translation>&amp;Журнал виконання</translation>
    </message>
    <message>
        <source>Execution Log</source>
        <translation>Журнал виконання</translation>
    </message>
    <message>
        <source>Auto-Shutdown on downloads completion</source>
        <translation>Автоматичне вимкнення після завершення завантажень</translation>
    </message>
    <message>
        <source>Exit qBittorrent</source>
        <translation>Вийти із qBittorrent</translation>
    </message>
    <message>
        <source>Suspend system</source>
        <translation>Призупинити систему</translation>
    </message>
    <message>
        <source>Shutdown system</source>
        <translation>Вимкнути систему</translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Вимкнено</translation>
    </message>
    <message>
        <source>The password should contain at least 3 characters</source>
        <translation>Пароль повинен містити щонайменше 3 символи</translation>
    </message>
</context>
<context>
    <name>PeerAdditionDlg</name>
    <message>
        <source>Invalid IP</source>
        <translation>Неправильна IP</translation>
    </message>
    <message>
        <source>The IP you provided is invalid.</source>
        <translation>Вказана IP-адреса неправильна.</translation>
    </message>
</context>
<context>
    <name>PeerListDelegate</name>
    <message>
        <source>/s</source>
        <comment>/second (i.e. per second)</comment>
        <translation>/с</translation>
    </message>
</context>
<context>
    <name>PeerListWidget</name>
    <message>
        <source>IP</source>
        <translation>IP</translation>
    </message>
    <message>
        <source>Client</source>
        <comment>i.e.: Client application</comment>
        <translation>Клієнт</translation>
    </message>
    <message>
        <source>Progress</source>
        <comment>i.e: % downloaded</comment>
        <translation>Прогрес</translation>
    </message>
    <message>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Шв. завант.</translation>
    </message>
    <message>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Шв. вивант.</translation>
    </message>
    <message>
        <source>Downloaded</source>
        <comment>i.e: total data downloaded</comment>
        <translation>Завантажено</translation>
    </message>
    <message>
        <source>Uploaded</source>
        <comment>i.e: total data uploaded</comment>
        <translation>Вивантажено</translation>
    </message>
    <message>
        <source>Ban peer permanently</source>
        <translation>Заблокувати піра</translation>
    </message>
    <message>
        <source>Peer addition</source>
        <translation>Додавання піра</translation>
    </message>
    <message>
        <source>The peer was added to this torrent.</source>
        <translation>Піра додано до цього торрента.</translation>
    </message>
    <message>
        <source>The peer could not be added to this torrent.</source>
        <translation>Не вдалося додати піра до цього торрента.</translation>
    </message>
    <message>
        <source>Are you sure? -- qBittorrent</source>
        <translation>Ви впевнені? -- qBittorrent</translation>
    </message>
    <message>
        <source>Are you sure you want to ban permanently the selected peers?</source>
        <translation>Ви впевнені, що хочете назовсім заблокувати вибраних пірів?</translation>
    </message>
    <message>
        <source>&amp;Yes</source>
        <translation>&amp;Так</translation>
    </message>
    <message>
        <source>&amp;No</source>
        <translation>&amp;Ні</translation>
    </message>
    <message>
        <source>Manually banning peer %1...</source>
        <translation>Заблоковано піра %1...</translation>
    </message>
    <message>
        <source>Upload rate limiting</source>
        <translation>Обмеження швидкості вивантаження</translation>
    </message>
    <message>
        <source>Download rate limiting</source>
        <translation>Обмеження швидкості завантаження</translation>
    </message>
    <message>
        <source>Add a new peer...</source>
        <translation>Додати нового піра...</translation>
    </message>
    <message>
        <source>Limit download rate...</source>
        <translation>Обмежити швидкість завантаження...</translation>
    </message>
    <message>
        <source>Limit upload rate...</source>
        <translation>Обмежити швидкість вивантаження...</translation>
    </message>
    <message>
        <source>Copy IP</source>
        <translation>Копіювати IP-адресу</translation>
    </message>
    <message>
        <source>Connection</source>
        <translation type="unfinished">З&apos;єднання</translation>
    </message>
</context>
<context>
    <name>Preferences</name>
    <message>
        <source>UI</source>
        <extracomment>User Interface</extracomment>
        <translation type="obsolete">Інтерфейс</translation>
    </message>
    <message>
        <source>Downloads</source>
        <translation>Завантаження</translation>
    </message>
    <message>
        <source>Connection</source>
        <translation>З&apos;єднання</translation>
    </message>
    <message>
        <source>Bittorrent</source>
        <translation type="obsolete">Bittorrent</translation>
    </message>
    <message>
        <source>Proxy</source>
        <translation type="obsolete">Проксі</translation>
    </message>
    <message>
        <source>Web UI</source>
        <translation>Веб-інтерфейс</translation>
    </message>
    <message>
        <source>Language:</source>
        <translation type="obsolete">Мова:</translation>
    </message>
    <message>
        <source>(Requires restart)</source>
        <translation>(Потребує перезавантаження програми)</translation>
    </message>
    <message>
        <source>Visual style:</source>
        <translation type="obsolete">Візуальний стиль:</translation>
    </message>
    <message>
        <source>Transfer list</source>
        <translation type="obsolete">Список завантажень</translation>
    </message>
    <message>
        <source>Use alternating row colors</source>
        <extracomment>In transfer list, one every two rows will have grey background.</extracomment>
        <translation>Кожен другий рядок виділений кольором</translation>
    </message>
    <message>
        <source>File system</source>
        <translation type="obsolete">Файлова система</translation>
    </message>
    <message>
        <source>Torrent queueing</source>
        <translation type="obsolete">Черга торрентів</translation>
    </message>
    <message>
        <source>Maximum active downloads:</source>
        <translation>Макс. активних завантажень:</translation>
    </message>
    <message>
        <source>Maximum active uploads:</source>
        <translation>Макс. активних вивантажень:</translation>
    </message>
    <message>
        <source>Maximum active torrents:</source>
        <translation>Макс. активних торрентів:</translation>
    </message>
    <message>
        <source>When adding a torrent</source>
        <translation>При додаванні торрента</translation>
    </message>
    <message>
        <source>Display torrent content and some options</source>
        <translation>Відображати вміст торрента і деякі налаштування</translation>
    </message>
    <message>
        <source>Listening port</source>
        <translation type="obsolete">Порт</translation>
    </message>
    <message>
        <source>Port used for incoming connections:</source>
        <translation>Порт для вхідних з&apos;єднань:</translation>
    </message>
    <message>
        <source>Random</source>
        <translation>Випадковий</translation>
    </message>
    <message>
        <source>Enable UPnP port mapping</source>
        <translation type="obsolete">Увімкнути UPnP</translation>
    </message>
    <message>
        <source>Enable NAT-PMP port mapping</source>
        <translation type="obsolete">Увімкнути NAT-PMP</translation>
    </message>
    <message>
        <source>Connections limit</source>
        <translation type="obsolete">Ліміт з&apos;єднань</translation>
    </message>
    <message>
        <source>Global maximum number of connections:</source>
        <translation>Максимальна кількість з&apos;єднань:</translation>
    </message>
    <message>
        <source>Maximum number of connections per torrent:</source>
        <translation>Максимальна кількість з&apos;єднань на торрент:</translation>
    </message>
    <message>
        <source>Maximum number of upload slots per torrent:</source>
        <translation>Макс. з&apos;єднань для вивантаження на торрент:</translation>
    </message>
    <message>
        <source>Upload:</source>
        <translation>Вивантаження:</translation>
    </message>
    <message>
        <source>Download:</source>
        <translation>Завантаження:</translation>
    </message>
    <message>
        <source>KiB/s</source>
        <translation>КіБ/с</translation>
    </message>
    <message>
        <source>Bittorrent features</source>
        <translation type="obsolete">Можливості Bittorrent</translation>
    </message>
    <message>
        <source>Enable DHT network (decentralized)</source>
        <translation type="obsolete">Увімкнути мережу DHT (децентралізована)</translation>
    </message>
    <message>
        <source>Use a different port for DHT and Bittorrent</source>
        <translation type="obsolete">Використовувати різні порти для DHT та Bittorrent</translation>
    </message>
    <message>
        <source>DHT port:</source>
        <translation>Порт DHT:</translation>
    </message>
    <message>
        <source>Enable Peer Exchange / PeX (requires restart)</source>
        <translation type="obsolete">Увімкнути обмін пірами/PeX (потребує перезавантаження)</translation>
    </message>
    <message>
        <source>Enable Local Peer Discovery</source>
        <translation type="obsolete">Увімкнути локальний пошук пірів</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation type="obsolete">Увімкнено</translation>
    </message>
    <message>
        <source>Forced</source>
        <translation type="obsolete">Примусове</translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation type="obsolete">Вимкнено</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation>Тип:</translation>
    </message>
    <message>
        <source>(None)</source>
        <translation>(Немає)</translation>
    </message>
    <message>
        <source>HTTP</source>
        <translation>HTTP</translation>
    </message>
    <message>
        <source>Port:</source>
        <translation>Порт:</translation>
    </message>
    <message>
        <source>Authentication</source>
        <translation>Автентифікація</translation>
    </message>
    <message>
        <source>Username:</source>
        <translation>Ім&apos;я користувача:</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation>Пароль:</translation>
    </message>
    <message>
        <source>SOCKS5</source>
        <translation>SOCKS5</translation>
    </message>
    <message>
        <source>HTTP Server</source>
        <translation type="obsolete">HTTP сервер</translation>
    </message>
    <message>
        <source>Filter path (.dat, .p2p, .p2b):</source>
        <translation>Шлях до фільтра (.dat, .p2p, .p2b):</translation>
    </message>
    <message>
        <source>HTTP Communications (trackers, Web seeds, search engine)</source>
        <translation type="obsolete">HTTP-спілкування (трекери, веб-сіди, пошуковики)</translation>
    </message>
    <message>
        <source>Host:</source>
        <translation>Сервер:</translation>
    </message>
    <message>
        <source>Peer Communications</source>
        <translation type="obsolete">Спілкування пірів</translation>
    </message>
    <message>
        <source>SOCKS4</source>
        <translation>SOCKS4</translation>
    </message>
    <message>
        <source>Speed</source>
        <translation>Швидкість</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Додатково</translation>
    </message>
    <message>
        <source>Copy .torrent files to:</source>
        <translation>Копіювати torrent-файли до:</translation>
    </message>
    <message>
        <source>Global speed limits</source>
        <translation type="obsolete">Глобальні обмеження швидкості</translation>
    </message>
    <message>
        <source>Alternative global speed limits</source>
        <translation type="obsolete">Альтернативні глобальні обмеження швидкості</translation>
    </message>
    <message>
        <source>to</source>
        <extracomment>time1 to time2</extracomment>
        <translation>-</translation>
    </message>
    <message>
        <source>Every day</source>
        <translation>Щодня</translation>
    </message>
    <message>
        <source>Week days</source>
        <translation>Дні тижня</translation>
    </message>
    <message>
        <source>Week ends</source>
        <translation>Вихідні</translation>
    </message>
    <message>
        <source>Remove folder</source>
        <translation>Вилучити папку</translation>
    </message>
    <message>
        <source>No action</source>
        <translation>Без дії</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>Налаштування</translation>
    </message>
    <message>
        <source>Visual Appearance</source>
        <translation type="obsolete">Вигляд</translation>
    </message>
    <message>
        <source>Action on double-click</source>
        <translation>Дія при подвійному клацанні</translation>
    </message>
    <message>
        <source>Downloading torrents:</source>
        <translation>Завантажую торренти:</translation>
    </message>
    <message>
        <source>Start / Stop</source>
        <translation type="obsolete">Почати / Зупинити</translation>
    </message>
    <message>
        <source>Open destination folder</source>
        <translation>Відкрити папку призначення</translation>
    </message>
    <message>
        <source>Completed torrents:</source>
        <translation>Завершені торренти:</translation>
    </message>
    <message>
        <source>Desktop</source>
        <translation>Робочий стіл</translation>
    </message>
    <message>
        <source>Show splash screen on start up</source>
        <translation>Показувати логотип при завантаженні програми</translation>
    </message>
    <message>
        <source>Start qBittorrent minimized</source>
        <translation>Запускати qBittorrent згорнутим</translation>
    </message>
    <message>
        <source>Show qBittorrent icon in notification area</source>
        <translation type="obsolete">Показувати qBittorrent у зоні сповіщень</translation>
    </message>
    <message>
        <source>Minimize qBittorrent to notification area</source>
        <translation>Згортати qBittorrent у зону сповіщень</translation>
    </message>
    <message>
        <source>Close qBittorrent to notification area</source>
        <comment>i.e: The systray tray icon will still be visible when closing the main window.</comment>
        <translation>Закривати qBittorrent у зону сповіщень</translation>
    </message>
    <message>
        <source>Do not start the download automatically</source>
        <comment>The torrent will be added to download list in pause state</comment>
        <translation>Не починати заантаження автоматично</translation>
    </message>
    <message>
        <source>Save files to location:</source>
        <translation>Зберігати файли до:</translation>
    </message>
    <message>
        <source>Append the label of the torrent to the save path</source>
        <translation>Додавати мітку торрента до шляху збереження</translation>
    </message>
    <message>
        <source>Pre-allocate disk space for all files</source>
        <translation>Попередньо виділяти місце для всіх файлів</translation>
    </message>
    <message>
        <source>Keep incomplete torrents in:</source>
        <translation>Тримати незавершені торренти у:</translation>
    </message>
    <message>
        <source>Append .!qB extension to incomplete files&apos; names</source>
        <translation type="obsolete">Додавати розширення .!qB до незавершених файлів</translation>
    </message>
    <message>
        <source>Automatically add torrents from:</source>
        <translation>Автоматично додавати торренти із:</translation>
    </message>
    <message>
        <source>Add folder...</source>
        <translation>Додати папку...</translation>
    </message>
    <message>
        <source>IP Filtering</source>
        <translation>IP-фільтр</translation>
    </message>
    <message>
        <source>Schedule the use of alternative speed limits</source>
        <translation type="obsolete">Розклад використання альтернативних обмежень швидкості</translation>
    </message>
    <message>
        <source>from</source>
        <extracomment>from (time1 to time2)</extracomment>
        <translation>з</translation>
    </message>
    <message>
        <source>When:</source>
        <translation>Коли:</translation>
    </message>
    <message>
        <source>Look for peers on your local network</source>
        <translation>Шукати пірів у локальній мережі</translation>
    </message>
    <message>
        <source>Protocol encryption:</source>
        <translation type="obsolete">Шифрування протоколу:</translation>
    </message>
    <message>
        <source>Enable Web User Interface (Remote control)</source>
        <translation>Увімкнути Веб-інтерфейс (дистанційне керування)</translation>
    </message>
    <message>
        <source>Share ratio limiting</source>
        <translation type="obsolete">Обмеження коефіцієнта роздачі</translation>
    </message>
    <message>
        <source>Seed torrents until their ratio reaches</source>
        <translation>Сідувати торренти, доки їх коефіцієнт не досягне</translation>
    </message>
    <message>
        <source>then</source>
        <translation>тоді</translation>
    </message>
    <message>
        <source>Pause them</source>
        <translation>Призупинити їх</translation>
    </message>
    <message>
        <source>Remove them</source>
        <translation>Видалити їх</translation>
    </message>
    <message utf8="true">
        <source>Exchange peers with compatible Bittorrent clients (µTorrent, Vuze, ...)</source>
        <translation>Обмін пірами із сумісними Bittorrent-клієнтами (µTorrent, Vuze, ...)</translation>
    </message>
    <message>
        <source>Email notification upon download completion</source>
        <translation>Сповіщення через e-mail при завершенні завантажень</translation>
    </message>
    <message>
        <source>Destination email:</source>
        <translation>E-mail призначення:</translation>
    </message>
    <message>
        <source>SMTP server:</source>
        <translation>SMTP сервер:</translation>
    </message>
    <message>
        <source>Run an external program on torrent completion</source>
        <translation>Запустити зовнішню програму при завершенні торрента</translation>
    </message>
    <message>
        <source>Use %f to pass the torrent path in parameters</source>
        <translation type="obsolete">Використовуйте %f, щоб передати шлях торрента як параметр</translation>
    </message>
    <message>
        <source>Proxy server</source>
        <translation type="obsolete">Проксі сервер</translation>
    </message>
    <message>
        <source>BitTorrent</source>
        <translation>BitTorrent</translation>
    </message>
    <message>
        <source>Start / Stop Torrent</source>
        <translation>Почати / зупинити торрент</translation>
    </message>
    <message>
        <source>Use UPnP / NAT-PMP port forwarding from my router</source>
        <translation>Використовувати UPnP / NAT-PMP з мого роутера</translation>
    </message>
    <message>
        <source>Privacy</source>
        <translation>Конфіденційність</translation>
    </message>
    <message>
        <source>Enable DHT (decentralized network) to find more peers</source>
        <translation>Увімкнути DHT (децентралізовану мережу, щоб знаходити більше пірів</translation>
    </message>
    <message>
        <source>Use a different port for DHT and BitTorrent</source>
        <translation>Використовувати різні порти для DHT та BitTorrent</translation>
    </message>
    <message>
        <source>Enable Peer Exchange (PeX) to find more peers</source>
        <translation>Увімкнути обмін пірами (PeX), щоб знаходити більше пірів</translation>
    </message>
    <message>
        <source>Enable Local Peer Discovery to find more peers</source>
        <translation>Увімкнути локальний пошук пірів, щоб знаходити більше пірів</translation>
    </message>
    <message>
        <source>Encryption mode:</source>
        <translation>Режим шифрування:</translation>
    </message>
    <message>
        <source>Prefer encryption</source>
        <translation>Надавати перевагу шифруванню</translation>
    </message>
    <message>
        <source>Require encryption</source>
        <translation>Вимагати шифрування</translation>
    </message>
    <message>
        <source>Disable encryption</source>
        <translation>Вимкнути шифрування</translation>
    </message>
    <message>
        <source>User Interface</source>
        <translation type="obsolete">Інтерфейс користувача</translation>
    </message>
    <message>
        <source>Reload the filter</source>
        <translation>Перезавантажити фільтр</translation>
    </message>
    <message>
        <source>Behavior</source>
        <translation>Поведінка</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Мова</translation>
    </message>
    <message>
        <source>Power Management</source>
        <translation>Керування енергоспоживанням</translation>
    </message>
    <message>
        <source>Inhibit system sleep when torrents are active</source>
        <translation>Не дозволяти призупинення системи, коли є активні торренти</translation>
    </message>
    <message>
        <source>Bypass authentication for localhost</source>
        <translation>Обходити автентифікацію для localhost</translation>
    </message>
    <message>
        <source>Ask for program exit confirmation</source>
        <translation>Вимагати підверрдження виходу з програми</translation>
    </message>
    <message>
        <source>Use monochrome system tray icon (requires restart)</source>
        <translation type="obsolete">Використовувати монохромний логотип системного лотка (вимагає перезапуску)</translation>
    </message>
    <message>
        <source>The following parameters are supported:
&lt;ul&gt;
&lt;li&gt;%f: Torrent path&lt;/li&gt;
&lt;li&gt;%n: Torrent name&lt;/li&gt;
&lt;/ul&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tray icon style:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Normal</source>
        <translation type="unfinished">Нормальний</translation>
    </message>
    <message>
        <source>Monochrome (Dark theme)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Monochrome (Light theme)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This server requires a secure connection (SSL)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User Interface Language:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Transfer List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show qBittorrent in notification area</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hard Disk</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Listening Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Connections Limits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Proxy Server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Torrent Queueing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Share Ratio Limiting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use UPnP / NAT-PMP to forward the port from my router</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Update my dynamic domain name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Service:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Register</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Domain name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Global Rate Limits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Apply rate limit to uTP connections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Apply rate limit to transport overhead</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alternative Global Rate Limits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Schedule the use of alternative rate limits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable bandwidth management (uTP)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Otherwise, the proxy server is only used for tracker connections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use proxy for peer connections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Append .!qB extension to incomplete files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use HTTPS instead of HTTP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Import SSL Certificate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Import SSL Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Certificate:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Key:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;a href=http://httpd.apache.org/docs/2.1/ssl/ssl_faq.html#aboutcerts&gt;Information about certificates&lt;/a&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PreviewSelect</name>
    <message>
        <source>Name</source>
        <translation>Назва</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Розмір</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation>Прогрес</translation>
    </message>
    <message>
        <source>Preview impossible</source>
        <translation>Перегляд неможливий</translation>
    </message>
    <message>
        <source>Sorry, we can&apos;t preview this file</source>
        <translation>Пробачте, неможливо переглянути цей файл</translation>
    </message>
</context>
<context>
    <name>ProgramUpdater</name>
    <message>
        <source>Could not create the file %1</source>
        <translation type="obsolete">Не вдалося створити файл %1</translation>
    </message>
    <message>
        <source>Failed to download the update at %1</source>
        <comment>%1 is an URL</comment>
        <translation type="obsolete">Не вдалося завантажити оновлення із %1</translation>
    </message>
</context>
<context>
    <name>PropListDelegate</name>
    <message>
        <source>Normal</source>
        <comment>Normal (priority)</comment>
        <translation>Нормальний</translation>
    </message>
    <message>
        <source>High</source>
        <comment>High (priority)</comment>
        <translation>Високий</translation>
    </message>
    <message>
        <source>Maximum</source>
        <comment>Maximum (priority)</comment>
        <translation>Максимальний</translation>
    </message>
    <message>
        <source>Not downloaded</source>
        <translation>Не завантажується</translation>
    </message>
    <message>
        <source>Mixed</source>
        <comment>Mixed (priorities</comment>
        <translation>Змішані</translation>
    </message>
</context>
<context>
    <name>PropTabBar</name>
    <message>
        <source>General</source>
        <translation>Загальні</translation>
    </message>
    <message>
        <source>Trackers</source>
        <translation>Трекери</translation>
    </message>
    <message>
        <source>Peers</source>
        <translation>Піри</translation>
    </message>
    <message>
        <source>URL Seeds</source>
        <translation type="obsolete">URL-сіди</translation>
    </message>
    <message>
        <source>Files</source>
        <translation type="obsolete">Файли</translation>
    </message>
    <message>
        <source>HTTP Sources</source>
        <translation>Джерела HTTP</translation>
    </message>
    <message>
        <source>Content</source>
        <translation>Вміст</translation>
    </message>
</context>
<context>
    <name>PropertiesWidget</name>
    <message>
        <source>Save path:</source>
        <translation>Шлях збереження:</translation>
    </message>
    <message>
        <source>Torrent hash:</source>
        <translation>Хеш:</translation>
    </message>
    <message>
        <source>Comment:</source>
        <translation>Коментар:</translation>
    </message>
    <message>
        <source>Share ratio:</source>
        <translation>Коефіцієнт роздачі:</translation>
    </message>
    <message>
        <source>General</source>
        <translation type="obsolete">Загальні</translation>
    </message>
    <message>
        <source>Trackers</source>
        <translation type="obsolete">Трекери</translation>
    </message>
    <message>
        <source>URL seeds</source>
        <translation type="obsolete">URL-сіди</translation>
    </message>
    <message>
        <source>Files</source>
        <translation type="obsolete">Файли</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Пріоритет</translation>
    </message>
    <message>
        <source>New url seed</source>
        <comment>New HTTP source</comment>
        <translation>Нова URL-роздача</translation>
    </message>
    <message>
        <source>New url seed:</source>
        <translation>Нова URL-роздача:</translation>
    </message>
    <message>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <source>This url seed is already in the list.</source>
        <translation>Ця URL-роздача вже є в списку.</translation>
    </message>
    <message>
        <source>Choose save path</source>
        <translation>Виберіть шлях збереження</translation>
    </message>
    <message>
        <source>Save path creation error</source>
        <translation type="obsolete">Помилка при створенні шляху збереження</translation>
    </message>
    <message>
        <source>Could not create the save path</source>
        <translation type="obsolete">Не вдалося створити шлях збереження</translation>
    </message>
    <message>
        <source>Downloaded:</source>
        <translation>Завантажено:</translation>
    </message>
    <message>
        <source>Transfer</source>
        <translation>Передача</translation>
    </message>
    <message>
        <source>Uploaded:</source>
        <translation>Вивантажено:</translation>
    </message>
    <message>
        <source>Wasted:</source>
        <translation>Змарновано:</translation>
    </message>
    <message>
        <source>UP limit:</source>
        <translation>Ліміт вив.:</translation>
    </message>
    <message>
        <source>DL limit:</source>
        <translation>Ліміт зав.:</translation>
    </message>
    <message>
        <source>Time elapsed:</source>
        <translation type="obsolete">Минуло часу:</translation>
    </message>
    <message>
        <source>Connections:</source>
        <translation>З&apos;єднання:</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Інформація</translation>
    </message>
    <message>
        <source>Created on:</source>
        <translation>Створено:</translation>
    </message>
    <message>
        <source>Peers</source>
        <translation type="obsolete">Піри</translation>
    </message>
    <message>
        <source>Maximum</source>
        <translation>Максимальний</translation>
    </message>
    <message>
        <source>High</source>
        <translation>Високий</translation>
    </message>
    <message>
        <source>this session</source>
        <translation>цієї сесії</translation>
    </message>
    <message>
        <source>%1 max</source>
        <comment>e.g. 10 max</comment>
        <translation>макс. %1</translation>
    </message>
    <message>
        <source>Availability:</source>
        <translation>Доступно:</translation>
    </message>
    <message>
        <source>/s</source>
        <comment>/second (i.e. per second)</comment>
        <translation>/с</translation>
    </message>
    <message>
        <source>Seeded for %1</source>
        <comment>e.g. Seeded for 3m10s</comment>
        <translation>Роздавав %1</translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation>Перейменувати...</translation>
    </message>
    <message>
        <source>New name:</source>
        <translation>Нова назва:</translation>
    </message>
    <message>
        <source>The file could not be renamed</source>
        <translation>Файл не вдалося перейменувати</translation>
    </message>
    <message>
        <source>This name is already in use in this folder. Please use a different name.</source>
        <translation>Це ім&apos;я вже використовується в цій папці. Будь ласка, виберіть інше ім&apos;я.</translation>
    </message>
    <message>
        <source>The folder could not be renamed</source>
        <translation>Не вдалося перейменувати цю папку</translation>
    </message>
    <message>
        <source>Rename the file</source>
        <translation>Перейменувати файл</translation>
    </message>
    <message>
        <source>This file name contains forbidden characters, please choose a different one.</source>
        <translation>Це ім&apos;я файла містить заборонені символи. Будь ласка, виберіть інше.</translation>
    </message>
    <message>
        <source>I/O Error</source>
        <translation>Помилка вводу/виводу</translation>
    </message>
    <message>
        <source>This file does not exist yet.</source>
        <translation>Цей файл ще не існує.</translation>
    </message>
    <message>
        <source>This folder does not exist yet.</source>
        <translation>Ця папка ще не існує.</translation>
    </message>
    <message>
        <source>Normal</source>
        <translation>Нормальний</translation>
    </message>
    <message>
        <source>Reannounce in:</source>
        <translation>Переанонсувати в:</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Вибрати все</translation>
    </message>
    <message>
        <source>Select None</source>
        <translation>Зняти виділення</translation>
    </message>
    <message>
        <source>Do not download</source>
        <translation>Не завантажувати</translation>
    </message>
    <message>
        <source>Pieces size:</source>
        <translation>Розмір частин:</translation>
    </message>
    <message>
        <source>Time active:</source>
        <extracomment>Time (duration) the torrent is active (not paused)</extracomment>
        <translation>Активний протягом:</translation>
    </message>
    <message>
        <source>Torrent content:</source>
        <translation>Вміст торренту:</translation>
    </message>
</context>
<context>
    <name>QBtSession</name>
    <message>
        <source>%1 reached the maximum ratio you set.</source>
        <translation>%1 досяг максимального коефіцієнта, налаштованого вами.</translation>
    </message>
    <message>
        <source>Removing torrent %1...</source>
        <translation>Видаляю торрент %1...</translation>
    </message>
    <message>
        <source>Pausing torrent %1...</source>
        <translation>Зупиняю торрент %1...</translation>
    </message>
    <message>
        <source>qBittorrent is bound to port: TCP/%1</source>
        <comment>e.g: qBittorrent is bound to port: 6881</comment>
        <translation>qBittorrent використовує порт: %1</translation>
    </message>
    <message>
        <source>UPnP support [ON]</source>
        <translation type="obsolete">Підтримка UNnP [Увімкнено]</translation>
    </message>
    <message>
        <source>UPnP support [OFF]</source>
        <translation type="obsolete">Підтримка UPnP [Вимкнено]</translation>
    </message>
    <message>
        <source>NAT-PMP support [ON]</source>
        <translation type="obsolete">Підтримка NAT-PMP [Увімкнено]</translation>
    </message>
    <message>
        <source>NAT-PMP support [OFF]</source>
        <translation type="obsolete">Підтримка NAT-PMP [Вимкнено]</translation>
    </message>
    <message>
        <source>HTTP user agent is %1</source>
        <translation>Браузер користувача: %1</translation>
    </message>
    <message>
        <source>Using a disk cache size of %1 MiB</source>
        <translation type="obsolete">Використовую дисковий кеш розміром %1 MiB</translation>
    </message>
    <message>
        <source>DHT support [ON], port: UDP/%1</source>
        <translation>Підтримка DHT [Увімкнено], порт: UDP/%1</translation>
    </message>
    <message>
        <source>DHT support [OFF]</source>
        <translation>Підтримка DHT [Вимкнено]</translation>
    </message>
    <message>
        <source>PeX support [ON]</source>
        <translation>Підтримка PeX [Увімкнено]</translation>
    </message>
    <message>
        <source>PeX support [OFF]</source>
        <translation>Підтримка PeX [Вимкнено]</translation>
    </message>
    <message>
        <source>Restart is required to toggle PeX support</source>
        <translation>Щоб перемкнути підтримку PeX, потрібно перезавантажити програму</translation>
    </message>
    <message>
        <source>Local Peer Discovery [ON]</source>
        <translation type="obsolete">Пошук Локальних Пірів [Увімкнено]</translation>
    </message>
    <message>
        <source>Local Peer Discovery support [OFF]</source>
        <translation>Пошук Локальних Пірів [Вимкнено]</translation>
    </message>
    <message>
        <source>Encryption support [ON]</source>
        <translation>Підтримка шифрування [Увімкнено]</translation>
    </message>
    <message>
        <source>Encryption support [FORCED]</source>
        <translation>Підтримка шифрування [Примусова]</translation>
    </message>
    <message>
        <source>Encryption support [OFF]</source>
        <translation>Підтримка шифрування [Вимкнено]</translation>
    </message>
    <message>
        <source>Embedded Tracker [ON]</source>
        <translation>Вбудований трекер [увімкнено]</translation>
    </message>
    <message>
        <source>Failed to start the embedded tracker!</source>
        <translation>Не вдалося запустити вбудований трекер!</translation>
    </message>
    <message>
        <source>Embedded Tracker [OFF]</source>
        <translation>Вбудований трекер [вимкнено]</translation>
    </message>
    <message>
        <source>The Web UI is listening on port %1</source>
        <translation>Веб-інтерфейс приєднано до порту %1</translation>
    </message>
    <message>
        <source>Web User Interface Error - Unable to bind Web UI to port %1</source>
        <translation>Помилка Веб-інтерфейсу - Не можу приєднати Веб-інтерфейс до порту %1</translation>
    </message>
    <message>
        <source>&apos;%1&apos; was removed from transfer list and hard disk.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>&apos;%1&apos; було видалено із списку завантажень і жорсткого диску.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; was removed from transfer list.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>&apos;%1&apos; було видалено із списку завантажень.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is not a valid magnet URI.</source>
        <translation>&apos;%1&apos; не є правильним магнітним посиланням.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is already in download list.</source>
        <comment>e.g: &apos;xxx.avi&apos; is already in download list.</comment>
        <translation>&apos;%1&apos; вже є у списку завантажень.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; resumed. (fast resume)</source>
        <comment>&apos;/home/y/xxx.torrent&apos; was resumed. (fast resume)</comment>
        <translation>&apos;%1&apos; продовжено. (швидке відновлення)</translation>
    </message>
    <message>
        <source>&apos;%1&apos; added to download list.</source>
        <comment>&apos;/home/y/xxx.torrent&apos; was added to download list.</comment>
        <translation>&apos;%1&apos; додано до списку завантажень.</translation>
    </message>
    <message>
        <source>Unable to decode torrent file: &apos;%1&apos;</source>
        <comment>e.g: Unable to decode torrent file: &apos;/home/y/xxx.torrent&apos;</comment>
        <translation>Не вдалося розкодувати торрент-файл: &apos;%1&apos;</translation>
    </message>
    <message>
        <source>This file is either corrupted or this isn&apos;t a torrent.</source>
        <translation>Цей файл або пошкоджений, або не є торрент-файлом.</translation>
    </message>
    <message>
        <source>Error: The torrent %1 does not contain any file.</source>
        <translation>Помилка: Торрент %1 не містить жодного файла.</translation>
    </message>
    <message>
        <source>Note: new trackers were added to the existing torrent.</source>
        <translation>Нові трекери було додано до існуючого торрента.</translation>
    </message>
    <message>
        <source>Note: new URL seeds were added to the existing torrent.</source>
        <translation>Нові URL-сіди було додано до існуючого торрента.</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;was blocked due to your IP filter&lt;/i&gt;</source>
        <comment>x.y.z.w was blocked</comment>
        <translation>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;було заблоковано згідно з вашим IP-фільтром&lt;/i&gt;</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;was banned due to corrupt pieces&lt;/i&gt;</source>
        <comment>x.y.z.w was banned</comment>
        <translation>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;було заблоковано через пошкоджені частини&lt;/i&gt;</translation>
    </message>
    <message>
        <source>Recursive download of file %1 embedded in torrent %2</source>
        <comment>Recursive download of test.torrent embedded in torrent test2</comment>
        <translation>Рекурсивне завантаження файлу %1 в торренті %2</translation>
    </message>
    <message>
        <source>Unable to decode %1 torrent file.</source>
        <translation>Не можу розкодувати %1 торрент-файл.</translation>
    </message>
    <message>
        <source>Torrent name: %1</source>
        <translation>Назва торрента: %1</translation>
    </message>
    <message>
        <source>Torrent size: %1</source>
        <translation>Розмір торрента: %1</translation>
    </message>
    <message>
        <source>Save path: %1</source>
        <translation>Шлях збереження: %1</translation>
    </message>
    <message>
        <source>The torrent was downloaded in %1.</source>
        <comment>The torrent was downloaded in 1 hour and 20 seconds</comment>
        <translation>Торрент було завантажено за %1.</translation>
    </message>
    <message>
        <source>Thank you for using qBittorrent.</source>
        <translation>Дякуємо, що ви користуєтесь qBittorrent.</translation>
    </message>
    <message>
        <source>[qBittorrent] %1 has finished downloading</source>
        <translation>[qBittorrent] Завантаження &quot;%1&quot; завершено</translation>
    </message>
    <message>
        <source>An I/O error occured, &apos;%1&apos; paused.</source>
        <translation>Сталася помилка вводу/виводу, &apos;%1&apos; зупинено.</translation>
    </message>
    <message>
        <source>Reason: %1</source>
        <translation>Причина: %1</translation>
    </message>
    <message>
        <source>UPnP/NAT-PMP: Port mapping failure, message: %1</source>
        <translation>UPnP/NAT-PMP: Не можу приєднати порт, повідомлення: %1</translation>
    </message>
    <message>
        <source>UPnP/NAT-PMP: Port mapping successful, message: %1</source>
        <translation>UPnP/NAT-PMP: Успішне приєднання порта, повідомлення: %1</translation>
    </message>
    <message>
        <source>File sizes mismatch for torrent %1, pausing it.</source>
        <translation>Розміри файлів не збігаються для торрента %1, зупиняю його.</translation>
    </message>
    <message>
        <source>Fast resume data was rejected for torrent %1, checking again...</source>
        <translation>Було відмовлено у швидкому відновленні данних для torrent&apos;у %1, перевіряю знову...</translation>
    </message>
    <message>
        <source>Url seed lookup failed for url: %1, message: %2</source>
        <translation>Пошук url роздачі невдалий для url: %1, повідомлення: %2</translation>
    </message>
    <message>
        <source>Downloading &apos;%1&apos;, please wait...</source>
        <comment>e.g: Downloading &apos;xxx.torrent&apos;, please wait...</comment>
        <translation>Завантажую &apos;%1&apos;, зачекайте...</translation>
    </message>
    <message>
        <source>The network interface defined is invalid: %1</source>
        <translation>Зазначений мережевий інтерфейс неправильний: %1</translation>
    </message>
    <message>
        <source>Trying any other network interface available instead.</source>
        <translation>Пробую на інших доступних мережевих інтерфейсах.</translation>
    </message>
    <message>
        <source>Listening on IP address %1 on network interface %2...</source>
        <translation>Чекаю підключень на IP %1 та мережевому інтерфейсі %2...</translation>
    </message>
    <message>
        <source>Failed to listen on network interface %1</source>
        <translation>Не вдалося запуститись не мережевому інтерфейсі %1</translation>
    </message>
    <message>
        <source>UPnP / NAT-PMP support [ON]</source>
        <translation>Підтримка UPnP / NAT-PMP [Увімкнено]</translation>
    </message>
    <message>
        <source>UPnP / NAT-PMP support [OFF]</source>
        <translation>Підтримка UPnP / NAT-PMP [Вимкнено]</translation>
    </message>
    <message>
        <source>Local Peer Discovery support [ON]</source>
        <translation>Підтримка локального пошуку пірів [Увімкнено]</translation>
    </message>
    <message>
        <source>Successfuly parsed the provided IP filter: %1 rules were applied.</source>
        <comment>%1 is a number</comment>
        <translation>Успішно розібрано даний фільтр IP: було застосовано %1 правил.</translation>
    </message>
    <message>
        <source>Error: Failed to parse the provided IP filter.</source>
        <translation>Помилка: Не вдалося розібрати даний фільтр IP.</translation>
    </message>
    <message>
        <source>Reporting IP address %1 to trackers...</source>
        <translation>Повідомляю IP адресу %1 трекерам...</translation>
    </message>
    <message>
        <source>The computer will now go to sleep mode unless you cancel within the next 15 seconds...</source>
        <translation>Зараз комп&apos;ютер перемкнеться в режим сну, якщо ви не відміните це протягом наступних 15 секунд...</translation>
    </message>
    <message>
        <source>The computer will now be switched off unless you cancel within the next 15 seconds...</source>
        <translation>Зараз комп&apos;ютер вимкнеться, якщо ви не відміните це протягом наступних 15 секунд...</translation>
    </message>
    <message>
        <source>qBittorrent will now exit unless you cancel within the next 15 seconds...</source>
        <translation>Програма qBittorrent зараз закриється, якщо ви не відміните це протягом наступних 15 секунд...</translation>
    </message>
</context>
<context>
    <name>RSS</name>
    <message>
        <source>Search</source>
        <translation>Пошук</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Видалити</translation>
    </message>
    <message>
        <source>Rename</source>
        <translation>Перейменувати</translation>
    </message>
    <message>
        <source>Refresh RSS streams</source>
        <translation>Обновити потоки RSS</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Torrents:&lt;/span&gt; &lt;span style=&quot; font-style:italic;&quot;&gt;(double-click to download)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Торренти:&lt;/span&gt; &lt;span style=&quot; font-style:italic;&quot;&gt;(двічі клацніть, щоб завантажити)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Download torrent</source>
        <translation>Завантажити торрент</translation>
    </message>
    <message>
        <source>Open news URL</source>
        <translation>Відкрити URL новини</translation>
    </message>
    <message>
        <source>Copy feed URL</source>
        <translation>Копіювати URL подачі</translation>
    </message>
    <message>
        <source>New subscription</source>
        <translation>Нова підписка</translation>
    </message>
    <message>
        <source>Mark items read</source>
        <translation>Позначити як прочитане</translation>
    </message>
    <message>
        <source>Update all</source>
        <translation>Оновити всі</translation>
    </message>
    <message>
        <source>Update all feeds</source>
        <translation>Оновити всі подачі</translation>
    </message>
    <message>
        <source>RSS feeds</source>
        <translation type="obsolete">RSS-подачі</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Оновити</translation>
    </message>
    <message>
        <source>Feed URL</source>
        <translation type="obsolete">URL подачі</translation>
    </message>
    <message>
        <source>Article title</source>
        <translation type="obsolete">Заголовок</translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation>Перейменувати...</translation>
    </message>
    <message>
        <source>New subscription...</source>
        <translation>Нова підписка...</translation>
    </message>
    <message>
        <source>RSS feed downloader...</source>
        <translation type="obsolete">Завантажувач RSS-подач...</translation>
    </message>
    <message>
        <source>New folder...</source>
        <translation>Нова папка...</translation>
    </message>
    <message>
        <source>Manage cookies...</source>
        <translation>Керування Cookies...</translation>
    </message>
    <message>
        <source>Settings...</source>
        <translation>Налаштування...</translation>
    </message>
    <message>
        <source>RSS Downloader...</source>
        <translation>Завантажувач RSS...</translation>
    </message>
</context>
<context>
    <name>RSSImp</name>
    <message>
        <source>Please type a rss stream url</source>
        <translation>Будь-ласка, введіть url потоку rss</translation>
    </message>
    <message>
        <source>Stream URL:</source>
        <translation>URL потоку:</translation>
    </message>
    <message>
        <source>Are you sure? -- qBittorrent</source>
        <translation>Ви впевнені? -- qBittorrent</translation>
    </message>
    <message>
        <source>&amp;Yes</source>
        <translation>&amp;Так</translation>
    </message>
    <message>
        <source>&amp;No</source>
        <translation>&amp;Ні</translation>
    </message>
    <message>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <source>This rss feed is already in the list.</source>
        <translation>Цей rss-стрічка вже є в списку.</translation>
    </message>
    <message>
        <source>Date: </source>
        <translation>Дата:</translation>
    </message>
    <message>
        <source>Author: </source>
        <translation>Автор:</translation>
    </message>
    <message>
        <source>Please choose a folder name</source>
        <translation>Будь ласка, виберіть назву папки</translation>
    </message>
    <message>
        <source>Folder name:</source>
        <translation>Назва папки:</translation>
    </message>
    <message>
        <source>New folder</source>
        <translation>Нова папка</translation>
    </message>
    <message>
        <source>Are you sure you want to delete these elements from the list?</source>
        <translation>Ви впевнені, що хочете видалити ці елементи зі списку?</translation>
    </message>
    <message>
        <source>Are you sure you want to delete this element from the list?</source>
        <translation>Ви впевнені, що хочете видалити цей елемент зі списку?</translation>
    </message>
    <message>
        <source>Please choose a new name for this RSS feed</source>
        <translation>Будь ласка, виберіть нове ім&apos;я для цієї RSS-подачі</translation>
    </message>
    <message>
        <source>New feed name:</source>
        <translation>Нове ім&apos;я подачі:</translation>
    </message>
    <message>
        <source>Name already in use</source>
        <translation>Ім&apos;я вже використовується</translation>
    </message>
    <message>
        <source>This name is already used by another item, please choose another one.</source>
        <translation>Це ім&apos;я вже використовується. Будь ласка, виберіть інше ім&apos;я.</translation>
    </message>
    <message>
        <source>Overwrite attempt</source>
        <translation>Спроба перезапису</translation>
    </message>
    <message>
        <source>You cannot overwrite %1 item.</source>
        <comment>You cannot overwrite myFolder item.</comment>
        <translation>Ви не можете замінити &quot;%1&quot;.</translation>
    </message>
    <message>
        <source>Unread</source>
        <translation>Непрочитані</translation>
    </message>
</context>
<context>
    <name>RssArticle</name>
    <message>
        <source>No description available</source>
        <translation type="obsolete">Опис відсутній</translation>
    </message>
</context>
<context>
    <name>RssFeed</name>
    <message>
        <source>Automatically downloading %1 torrent from %2 RSS feed...</source>
        <translation>Автоматично завантажую торрент %1 з RSS-подачі %2...</translation>
    </message>
</context>
<context>
    <name>RssItem</name>
    <message>
        <source>No description available</source>
        <translation type="obsolete">Опис відсутній</translation>
    </message>
</context>
<context>
    <name>RssSettings</name>
    <message>
        <source>RSS Reader Settings</source>
        <translation type="obsolete">Налаштування Читача RSS</translation>
    </message>
    <message>
        <source>RSS feeds refresh interval:</source>
        <translation type="obsolete">Інтервал оновлення RSS-подач:</translation>
    </message>
    <message>
        <source>minutes</source>
        <translation type="obsolete">хвилин</translation>
    </message>
    <message>
        <source>Maximum number of articles per feed:</source>
        <translation type="obsolete">Максимальна кількість новин в подачі:</translation>
    </message>
</context>
<context>
    <name>RssSettingsDlg</name>
    <message>
        <source>RSS Reader Settings</source>
        <translation>Налаштування Читача RSS</translation>
    </message>
    <message>
        <source>RSS feeds refresh interval:</source>
        <translation>Інтервал оновлення RSS-подач:</translation>
    </message>
    <message>
        <source>minutes</source>
        <translation>хвилин</translation>
    </message>
    <message>
        <source>Maximum number of articles per feed:</source>
        <translation>Максимальна кількість новин в подачі:</translation>
    </message>
</context>
<context>
    <name>RssStream</name>
    <message>
        <source>Automatically downloading %1 torrent from %2 RSS feed...</source>
        <translation type="obsolete">Автоматично завантажую торрент %1 з RSS-подачі %2...</translation>
    </message>
</context>
<context>
    <name>ScanFoldersModel</name>
    <message>
        <source>Watched Folder</source>
        <translation>Папка спостерігання</translation>
    </message>
    <message>
        <source>Download here</source>
        <translation>Завантажувати сюди</translation>
    </message>
</context>
<context>
    <name>SearchCategories</name>
    <message>
        <source>All categories</source>
        <translation>Всі категорії</translation>
    </message>
    <message>
        <source>Movies</source>
        <translation>Фільми</translation>
    </message>
    <message>
        <source>TV shows</source>
        <translation>Телешоу</translation>
    </message>
    <message>
        <source>Music</source>
        <translation>Музика</translation>
    </message>
    <message>
        <source>Games</source>
        <translation>Ігри</translation>
    </message>
    <message>
        <source>Anime</source>
        <translation>Аніме</translation>
    </message>
    <message>
        <source>Software</source>
        <translation>Програми</translation>
    </message>
    <message>
        <source>Pictures</source>
        <translation>Зображення</translation>
    </message>
    <message>
        <source>Books</source>
        <translation>Книги</translation>
    </message>
</context>
<context>
    <name>SearchEngine</name>
    <message>
        <source>Empty search pattern</source>
        <translation>Пустий шаблон пошуку</translation>
    </message>
    <message>
        <source>Please type a search pattern first</source>
        <translation>Будь ласка, спочатку введіть шаблон пошуку</translation>
    </message>
    <message>
        <source>Results</source>
        <translation>Результати</translation>
    </message>
    <message>
        <source>Searching...</source>
        <translation>Шукаю...</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation>Вирізати</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Копіювати</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation>Вставити</translation>
    </message>
    <message>
        <source>Clear field</source>
        <translation>Очистити поле</translation>
    </message>
    <message>
        <source>Clear completion history</source>
        <translation>Очистити історію автозавершення</translation>
    </message>
    <message>
        <source>Search Engine</source>
        <translation>Пошуковик</translation>
    </message>
    <message>
        <source>Search has finished</source>
        <translation>Пошук закінчено</translation>
    </message>
    <message>
        <source>An error occured during search...</source>
        <translation>Під час пошуку сталася помилка...</translation>
    </message>
    <message>
        <source>Search aborted</source>
        <translation>Пошук скасовано</translation>
    </message>
    <message>
        <source>Search returned no results</source>
        <translation>Пошук не дав результів</translation>
    </message>
    <message>
        <source>Results</source>
        <comment>i.e: Search results</comment>
        <translation>Результати</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Невідомо</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Пошук</translation>
    </message>
    <message>
        <source>Download error</source>
        <translation>Помилка завантаження</translation>
    </message>
    <message>
        <source>Python setup could not be downloaded, reason: %1.
Please install it manually.</source>
        <translation>Не вдалося завантажити програму інсталяції Python. Причина: %1.
Будь ласка, встановіть Python самостійно.</translation>
    </message>
    <message>
        <source>Missing Python Interpreter</source>
        <translation>Не вистачає інтерпретатора Python</translation>
    </message>
    <message>
        <source>Python 2.x is required to use the search engine but it does not seem to be installed.
Do you want to install it now?</source>
        <translation>Для використання Пошуковика потрібен Python 2.x, але, здається, він не встановлений.
Встановити його зараз?</translation>
    </message>
    <message>
        <source>Confirmation</source>
        <translation>Підтвердження</translation>
    </message>
    <message>
        <source>Are you sure you want to clear the history?</source>
        <translation>Ви впевнені, що хочете очистити історію?</translation>
    </message>
</context>
<context>
    <name>SearchTab</name>
    <message>
        <source>Name</source>
        <comment>i.e: file name</comment>
        <translation>Ім&apos;я</translation>
    </message>
    <message>
        <source>Size</source>
        <comment>i.e: file size</comment>
        <translation>Розмір</translation>
    </message>
    <message>
        <source>Seeders</source>
        <comment>i.e: Number of full sources</comment>
        <translation>Сідери</translation>
    </message>
    <message>
        <source>Leechers</source>
        <comment>i.e: Number of partial sources</comment>
        <translation>Лічери</translation>
    </message>
    <message>
        <source>Search engine</source>
        <translation>Пошуковик</translation>
    </message>
</context>
<context>
    <name>ShutdownConfirmDlg</name>
    <message>
        <source>Shutdown confirmation</source>
        <translation>Підтвердження вимкнення</translation>
    </message>
</context>
<context>
    <name>SpeedLimitDialog</name>
    <message>
        <source>KiB/s</source>
        <translation>КіБ/с</translation>
    </message>
</context>
<context>
    <name>StatusBar</name>
    <message>
        <source>Connection status:</source>
        <translation>Статус з&apos;єднання:</translation>
    </message>
    <message>
        <source>No direct connections. This may indicate network configuration problems.</source>
        <translation>Немає прямих з&apos;єднань. Це може означати, що є проблеми з мережею.</translation>
    </message>
    <message>
        <source>DHT: %1 nodes</source>
        <translation>DHT: %1</translation>
    </message>
    <message>
        <source>Connection Status:</source>
        <translation>Статус з&apos;єднання:</translation>
    </message>
    <message>
        <source>Online</source>
        <translation>В мережі</translation>
    </message>
    <message>
        <source>Global Download Speed Limit</source>
        <translation>Глобальний ліміт завантаження</translation>
    </message>
    <message>
        <source>Global Upload Speed Limit</source>
        <translation>Глобальний ліміт вивантаження</translation>
    </message>
    <message>
        <source>D: %1/s - T: %2</source>
        <comment>Download speed: x KiB/s - Transferred: x MiB</comment>
        <translation type="obsolete">Зав.: %1/с (%2)</translation>
    </message>
    <message>
        <source>U: %1/s - T: %2</source>
        <comment>Upload speed: x KiB/s - Transferred: x MiB</comment>
        <translation type="obsolete">Вив.: %1/с (%2)</translation>
    </message>
    <message>
        <source>D: %1 B/s - T: %2</source>
        <comment>Download speed: x B/s - Transferred: x MiB</comment>
        <translation type="obsolete">Зав.: %1 Б/с (%2)</translation>
    </message>
    <message>
        <source>U: %1 B/s - T: %2</source>
        <comment>Upload speed: x B/s - Transferred: x MiB</comment>
        <translation type="obsolete">Вив.: %1 Б/с (%2)</translation>
    </message>
    <message>
        <source>Offline. This usually means that qBittorrent failed to listen on the selected port for incoming connections.</source>
        <translation>Не в мережі. Зазвичай це означає, що qBittorrent не зміг приєднатись до вибраного порту і очікувати вхідні з&apos;єднання.</translation>
    </message>
    <message>
        <source>Click to disable alternative speed limits</source>
        <translation type="obsolete">Клацніть, щоб вимкнути альтернативні обмеження швидкості</translation>
    </message>
    <message>
        <source>Click to enable alternative speed limits</source>
        <translation type="obsolete">Клацніть, щоб увімкнути альтернативні обмеження швидкості</translation>
    </message>
    <message>
        <source>qBittorrent needs to be restarted</source>
        <translation>Потрібно перезапустити qBittorrent</translation>
    </message>
    <message>
        <source>qBittorrent was just updated and needs to be restarted for the changes to be effective.</source>
        <translation>qBittorrent було щойно оновлено, і тепер потрібно його перезапустити, щоб застосувати зміни.</translation>
    </message>
    <message>
        <source>Click to switch to alternative speed limits</source>
        <translation>Клацніть, щоб перемкнутись на альтернативні обмеження швидкості</translation>
    </message>
    <message>
        <source>Click to switch to regular speed limits</source>
        <translation>Клацніть, щоб перемкнутись на звичайні обмеження швидкості</translation>
    </message>
    <message>
        <source>%1/s</source>
        <comment>Per second</comment>
        <translation>%1/с</translation>
    </message>
</context>
<context>
    <name>TorrentCreatorDlg</name>
    <message>
        <source>Select a folder to add to the torrent</source>
        <translation>Виберіть папку для додавання в torrent</translation>
    </message>
    <message>
        <source>Select a file to add to the torrent</source>
        <translation>Виберіть файл для додавання в торрент</translation>
    </message>
    <message>
        <source>Please type an announce URL</source>
        <translation type="obsolete">Будь ласка, введіть URL анонсу</translation>
    </message>
    <message>
        <source>Announce URL:</source>
        <comment>Tracker URL</comment>
        <translation type="obsolete">URL анонсу:</translation>
    </message>
    <message>
        <source>Please type a web seed url</source>
        <translation type="obsolete">Будь ласка, введіть URL web-роздачі</translation>
    </message>
    <message>
        <source>Web seed URL:</source>
        <translation type="obsolete">URL web-роздачі:</translation>
    </message>
    <message>
        <source>No input path set</source>
        <translation>Не задано вхідний шлях</translation>
    </message>
    <message>
        <source>Please type an input path first</source>
        <translation>Будь ласка, спочатку введіть вхідний шлях</translation>
    </message>
    <message>
        <source>Select destination torrent file</source>
        <translation>Виберіть цільовий torrent-файл</translation>
    </message>
    <message>
        <source>Torrent Files</source>
        <translation>Торрент-файли</translation>
    </message>
    <message>
        <source>Torrent creation</source>
        <translation>Створення торренту</translation>
    </message>
    <message>
        <source>Torrent creation was unsuccessful, reason: %1</source>
        <translation>Створення torrent&apos;у було невдалим, причина: %1</translation>
    </message>
    <message>
        <source>Created torrent file is invalid. It won&apos;t be added to download list.</source>
        <translation>Створений торрент-файл неправильний. Його не буде додано до списку завантажень.</translation>
    </message>
    <message>
        <source>Torrent was created successfully:</source>
        <translation>Торрент було успішно створено:</translation>
    </message>
</context>
<context>
    <name>TorrentFilesModel</name>
    <message>
        <source>Name</source>
        <translation>Ім&apos;я</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Розмір</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation>Прогрес</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Пріоритет</translation>
    </message>
</context>
<context>
    <name>TorrentImportDlg</name>
    <message>
        <source>Torrent Import</source>
        <translation>Імпорт торрента</translation>
    </message>
    <message>
        <source>This assistant will help you share with qBittorrent a torrent that you have already downloaded.</source>
        <translation>Цей майстер допоможе вам поділитись з qBittorrent торрентом, який ви вже завантажили.</translation>
    </message>
    <message>
        <source>Torrent file to import:</source>
        <translation>Торрент-файл, що імпортується:</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Content location:</source>
        <translation>Розташування вмісту:</translation>
    </message>
    <message>
        <source>Skip the data checking stage and start seeding immediately</source>
        <translation>Пропустити перевірку даних та почати сідування негайно</translation>
    </message>
    <message>
        <source>Import</source>
        <translation>Імпорт</translation>
    </message>
    <message>
        <source>Torrent file to import</source>
        <translation>Торрент-файл, що імпортується</translation>
    </message>
    <message>
        <source>Torrent files (*.torrent)</source>
        <translation>Torrent-файли (*.torrent)</translation>
    </message>
    <message>
        <source>%1 Files</source>
        <comment>%1 is a file extension (e.g. PDF)</comment>
        <translation>Файли %1</translation>
    </message>
    <message>
        <source>Please provide the location of %1</source>
        <comment>%1 is a file name</comment>
        <translation>Будь ласка, вкажіть розташування %1</translation>
    </message>
    <message>
        <source>Please point to the location of the torrent: %1</source>
        <translation>Будь ласка, вкажіть на розташування торрента: %1</translation>
    </message>
    <message>
        <source>Invalid torrent file</source>
        <translation type="unfinished">Неправильний torrent-файл</translation>
    </message>
    <message>
        <source>This is not a valid torrent file.</source>
        <translation type="unfinished">Цей файл не є правильним torrent-файлом.</translation>
    </message>
</context>
<context>
    <name>TorrentModel</name>
    <message>
        <source>Name</source>
        <comment>i.e: torrent name</comment>
        <translation>Назва</translation>
    </message>
    <message>
        <source>Size</source>
        <comment>i.e: torrent size</comment>
        <translation>Розмір</translation>
    </message>
    <message>
        <source>Done</source>
        <comment>% Done</comment>
        <translation>Зроблено</translation>
    </message>
    <message>
        <source>Status</source>
        <comment>Torrent status (e.g. downloading, seeding, paused)</comment>
        <translation>Статус</translation>
    </message>
    <message>
        <source>Seeds</source>
        <comment>i.e. full sources (often untranslated)</comment>
        <translation>Сіди</translation>
    </message>
    <message>
        <source>Peers</source>
        <comment>i.e. partial sources (often untranslated)</comment>
        <translation>Піри</translation>
    </message>
    <message>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Шв. завант.</translation>
    </message>
    <message>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Шв. вивант.</translation>
    </message>
    <message>
        <source>Ratio</source>
        <comment>Share ratio</comment>
        <translation>Коефіцієнт</translation>
    </message>
    <message>
        <source>ETA</source>
        <comment>i.e: Estimated Time of Arrival / Time left</comment>
        <translation>Залишилось</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Мітка</translation>
    </message>
    <message>
        <source>Added On</source>
        <comment>Torrent was added to transfer list on 01/01/2010 08:00</comment>
        <translation>Додано</translation>
    </message>
    <message>
        <source>Completed On</source>
        <comment>Torrent was completed on 01/01/2010 08:00</comment>
        <translation>Завершено</translation>
    </message>
    <message>
        <source>Tracker</source>
        <translation>Трекер</translation>
    </message>
    <message>
        <source>Down Limit</source>
        <comment>i.e: Download limit</comment>
        <translation>Ліміт завант.</translation>
    </message>
    <message>
        <source>Up Limit</source>
        <comment>i.e: Upload limit</comment>
        <translation>Ліміт вивант.</translation>
    </message>
    <message>
        <source>Amount downloaded</source>
        <comment>Amount of data downloaded (e.g. in MB)</comment>
        <translation>Завантажено</translation>
    </message>
    <message>
        <source>Amount left</source>
        <comment>Amount of data left to download (e.g. in MB)</comment>
        <translation>Залишилось</translation>
    </message>
    <message>
        <source>Time Active</source>
        <comment>Time (duration) the torrent is active (not paused)</comment>
        <translation>Активний протягом</translation>
    </message>
</context>
<context>
    <name>TrackerList</name>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Статус</translation>
    </message>
    <message>
        <source>Peers</source>
        <translation>Піри</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Повідомлення</translation>
    </message>
    <message>
        <source>[DHT]</source>
        <translation>[DHT]</translation>
    </message>
    <message>
        <source>Working</source>
        <translation>Працюю</translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Вимкнено</translation>
    </message>
    <message>
        <source>This torrent is private</source>
        <translation>Цей торрент приватний</translation>
    </message>
    <message>
        <source>Updating...</source>
        <translation>Оновлюю...</translation>
    </message>
    <message>
        <source>Not working</source>
        <translation>Не працює</translation>
    </message>
    <message>
        <source>Not contacted yet</source>
        <translation>Ще не зв&apos;язувався</translation>
    </message>
    <message>
        <source>[PeX]</source>
        <translation>[PeX]</translation>
    </message>
    <message>
        <source>[LSD]</source>
        <translation>[LSD]</translation>
    </message>
    <message>
        <source>Add a new tracker...</source>
        <translation>Додати новий трекер...</translation>
    </message>
    <message>
        <source>Remove tracker</source>
        <translation>Видалити трекер</translation>
    </message>
    <message>
        <source>Force reannounce</source>
        <translation>Примусово переанонсувати</translation>
    </message>
</context>
<context>
    <name>TrackersAdditionDlg</name>
    <message>
        <source>Trackers addition dialog</source>
        <translation>Додавання трекеру</translation>
    </message>
    <message>
        <source>List of trackers to add (one per line):</source>
        <translation>Список трекерів, які ви хочете додати (один на рядок):</translation>
    </message>
    <message utf8="true">
        <source>µTorrent compatible list URL:</source>
        <translation>URL списку, сумісного з µTorrent:</translation>
    </message>
    <message>
        <source>I/O Error</source>
        <translation>Помилка вводу/виводу</translation>
    </message>
    <message>
        <source>Error while trying to open the downloaded file.</source>
        <translation>Не вдалося відкрити завантажений файл.</translation>
    </message>
    <message>
        <source>No change</source>
        <translation>Без змін</translation>
    </message>
    <message>
        <source>No additional trackers were found.</source>
        <translation>Не знайдено додаткових трекерів.</translation>
    </message>
    <message>
        <source>Download error</source>
        <translation>Помилка завантаження</translation>
    </message>
    <message>
        <source>The trackers list could not be downloaded, reason: %1</source>
        <translation>Не вдалося завантажити список трекерів, причина: %1</translation>
    </message>
</context>
<context>
    <name>TransferListDelegate</name>
    <message>
        <source>Downloading</source>
        <translation>Завантажую</translation>
    </message>
    <message>
        <source>Paused</source>
        <translation>Зупинено</translation>
    </message>
    <message>
        <source>Queued</source>
        <comment>i.e. torrent is queued</comment>
        <translation>В черзі</translation>
    </message>
    <message>
        <source>Seeding</source>
        <comment>Torrent is complete and in upload-only mode</comment>
        <translation>Роздаю</translation>
    </message>
    <message>
        <source>Stalled</source>
        <comment>Torrent is waiting for download to begin</comment>
        <translation>Заглохло</translation>
    </message>
    <message>
        <source>Checking</source>
        <comment>Torrent local data is being checked</comment>
        <translation>Перевіряю</translation>
    </message>
    <message>
        <source>/s</source>
        <comment>/second (.i.e per second)</comment>
        <translation>/с</translation>
    </message>
    <message>
        <source>KiB/s</source>
        <comment>KiB/second (.i.e per second)</comment>
        <translation>КіБ/с</translation>
    </message>
    <message>
        <source>Seeded for %1</source>
        <comment>e.g. Seeded for 3m10s</comment>
        <translation>Роздавав %1</translation>
    </message>
</context>
<context>
    <name>TransferListFiltersWidget</name>
    <message>
        <source>All</source>
        <translation>Всі</translation>
    </message>
    <message>
        <source>Downloading</source>
        <translation>Завантажую</translation>
    </message>
    <message>
        <source>Completed</source>
        <translation>Завершені</translation>
    </message>
    <message>
        <source>Active</source>
        <translation>Активні</translation>
    </message>
    <message>
        <source>Inactive</source>
        <translation>Неактивні</translation>
    </message>
    <message>
        <source>All labels</source>
        <translation>Всі мітки</translation>
    </message>
    <message>
        <source>Unlabeled</source>
        <translation>Без мітки</translation>
    </message>
    <message>
        <source>Remove label</source>
        <translation>Видалити мітку</translation>
    </message>
    <message>
        <source>New Label</source>
        <translation>Нова мітка</translation>
    </message>
    <message>
        <source>Label:</source>
        <translation>Мітка:</translation>
    </message>
    <message>
        <source>Invalid label name</source>
        <translation>Неправильна назва мітки</translation>
    </message>
    <message>
        <source>Please don&apos;t use any special characters in the label name.</source>
        <translation>Будь ласка, не використовуйте спеціальні символи в назві мітки.</translation>
    </message>
    <message>
        <source>Paused</source>
        <translation>Зупинено</translation>
    </message>
    <message>
        <source>Add label...</source>
        <translation>Додати мітку...</translation>
    </message>
    <message>
        <source>Resume torrents</source>
        <translation>Відновити завантаження</translation>
    </message>
    <message>
        <source>Pause torrents</source>
        <translation>Призупинити завантаження</translation>
    </message>
    <message>
        <source>Delete torrents</source>
        <translation>Видалити торренти</translation>
    </message>
</context>
<context>
    <name>TransferListWidget</name>
    <message>
        <source>ETA</source>
        <comment>i.e: Estimated Time of Arrival / Time left</comment>
        <translation type="obsolete">Залишилось</translation>
    </message>
    <message>
        <source>Column visibility</source>
        <translation>Видимість колонок</translation>
    </message>
    <message>
        <source>Open destination folder</source>
        <translation>Відкрити папку призначення</translation>
    </message>
    <message>
        <source>Force recheck</source>
        <translation>Примусова перевірка</translation>
    </message>
    <message>
        <source>Copy magnet link</source>
        <translation>Копіювати Магнітне посилання</translation>
    </message>
    <message>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation type="obsolete">Шв. завантаження</translation>
    </message>
    <message>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation type="obsolete">Шв. вивантаження</translation>
    </message>
    <message>
        <source>Name</source>
        <comment>i.e: torrent name</comment>
        <translation type="obsolete">Назва</translation>
    </message>
    <message>
        <source>Size</source>
        <comment>i.e: torrent size</comment>
        <translation type="obsolete">Розмір</translation>
    </message>
    <message>
        <source>Done</source>
        <comment>% Done</comment>
        <translation type="obsolete">Зроблено</translation>
    </message>
    <message>
        <source>Status</source>
        <comment>Torrent status (e.g. downloading, seeding, paused)</comment>
        <translation type="obsolete">Статус</translation>
    </message>
    <message>
        <source>Seeds</source>
        <comment>i.e. full sources (often untranslated)</comment>
        <translation type="obsolete">Сіди</translation>
    </message>
    <message>
        <source>Peers</source>
        <comment>i.e. partial sources (often untranslated)</comment>
        <translation type="obsolete">Піри</translation>
    </message>
    <message>
        <source>Ratio</source>
        <comment>Share ratio</comment>
        <translation type="obsolete">Коефіцієнт</translation>
    </message>
    <message>
        <source>Torrent Download Speed Limiting</source>
        <translation>Обмеження швидкості завантаження торрента</translation>
    </message>
    <message>
        <source>Torrent Upload Speed Limiting</source>
        <translation>Обмеження швидкості вивантаження торрента</translation>
    </message>
    <message>
        <source>Super seeding mode</source>
        <translation>Режим супер-сідування</translation>
    </message>
    <message>
        <source>Download in sequential order</source>
        <translation>Завантажувати послідовно</translation>
    </message>
    <message>
        <source>Download first and last piece first</source>
        <translation>Спочатку завантажувати першу і останню частину</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Мітка</translation>
    </message>
    <message>
        <source>New Label</source>
        <translation>Нова мітка</translation>
    </message>
    <message>
        <source>Label:</source>
        <translation>Мітка:</translation>
    </message>
    <message>
        <source>New...</source>
        <comment>New label...</comment>
        <translation>Нова...</translation>
    </message>
    <message>
        <source>Reset</source>
        <comment>Reset label</comment>
        <translation>Забрати мітку</translation>
    </message>
    <message>
        <source>Rename</source>
        <translation>Перейменувати</translation>
    </message>
    <message>
        <source>New name:</source>
        <translation>Нове ім&apos;я:</translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation>Перейменувати...</translation>
    </message>
    <message>
        <source>Invalid label name</source>
        <translation>Неправильне ім&apos;я мітки</translation>
    </message>
    <message>
        <source>Please don&apos;t use any special characters in the label name.</source>
        <translation>Будь ласка, не використовуйте спеціальних символів в назві мітки.</translation>
    </message>
    <message>
        <source>Added On</source>
        <comment>Torrent was added to transfer list on 01/01/2010 08:00</comment>
        <translation type="obsolete">Додано</translation>
    </message>
    <message>
        <source>Completed On</source>
        <comment>Torrent was completed on 01/01/2010 08:00</comment>
        <translation type="obsolete">Завершено</translation>
    </message>
    <message>
        <source>Down Limit</source>
        <comment>i.e: Download limit</comment>
        <translation type="obsolete">Ліміт завантаження</translation>
    </message>
    <message>
        <source>Up Limit</source>
        <comment>i.e: Upload limit</comment>
        <translation type="obsolete">Ліміт вивантаження</translation>
    </message>
    <message>
        <source>Choose save path</source>
        <translation>Виберіть шлях збереження</translation>
    </message>
    <message>
        <source>Save path creation error</source>
        <translation type="obsolete">Помилка при створенні шляху збереження</translation>
    </message>
    <message>
        <source>Could not create the save path</source>
        <translation type="obsolete">Не вдалося створити шлях збереження</translation>
    </message>
    <message>
        <source>Set location...</source>
        <translation>Встановити місце...</translation>
    </message>
    <message>
        <source>Preview file...</source>
        <translation>Переглянути файл...</translation>
    </message>
    <message>
        <source>Limit upload rate...</source>
        <translation>Обмежити швидкість вивантаження...</translation>
    </message>
    <message>
        <source>Limit download rate...</source>
        <translation>Обмежити швидкість завантаження...</translation>
    </message>
    <message>
        <source>Move up</source>
        <comment>i.e. move up in the queue</comment>
        <translation>Посунути вгору</translation>
    </message>
    <message>
        <source>Move down</source>
        <comment>i.e. Move down in the queue</comment>
        <translation>Посунути вниз</translation>
    </message>
    <message>
        <source>Move to top</source>
        <comment>i.e. Move to top of the queue</comment>
        <translation>Розмістити зверху</translation>
    </message>
    <message>
        <source>Move to bottom</source>
        <comment>i.e. Move to bottom of the queue</comment>
        <translation>Розмістити знизу</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Пріоритет</translation>
    </message>
    <message>
        <source>Resume</source>
        <comment>Resume/start the torrent</comment>
        <translation>Продовжити</translation>
    </message>
    <message>
        <source>Pause</source>
        <comment>Pause the torrent</comment>
        <translation>Призупинити</translation>
    </message>
    <message>
        <source>Delete</source>
        <comment>Delete the torrent</comment>
        <translation>Видалити</translation>
    </message>
    <message>
        <source>Limit share ratio...</source>
        <translation>Обмежити коефіцієнт роздачі...</translation>
    </message>
</context>
<context>
    <name>UpDownRatioDlg</name>
    <message>
        <source>Torrent Upload/Download Ratio Limiting</source>
        <translation>Обмеження коефіцієнта &quot;вивантаження/завантаження&quot; торрента</translation>
    </message>
    <message>
        <source>Use global ratio limit</source>
        <translation>Використовувати глобальні обмеження</translation>
    </message>
    <message>
        <source>buttonGroup</source>
        <translation></translation>
    </message>
    <message>
        <source>Set no ratio limit</source>
        <translation>Не використовувати обмеження коефіцієнта</translation>
    </message>
    <message>
        <source>Set ratio limit to</source>
        <translation>Встановити обмеження коефіцієнта на</translation>
    </message>
</context>
<context>
    <name>UsageDisplay</name>
    <message>
        <source>Usage:</source>
        <translation>Використання:</translation>
    </message>
    <message>
        <source>displays program version</source>
        <translation>показує версію програми</translation>
    </message>
    <message>
        <source>disable splash screen</source>
        <translation>вимкнути початкову заставку</translation>
    </message>
    <message>
        <source>displays this help message</source>
        <translation>показує це повідомлення</translation>
    </message>
    <message>
        <source>changes the webui port (current: %1)</source>
        <translation>змінює порт Веб-інтерфейсу (поточний: %1)</translation>
    </message>
    <message>
        <source>[files or urls]: downloads the torrents passed by the user (optional)</source>
        <translation>[файли або URL&apos;и]: завантажує торренти, вказані користувачем (необов&apos;язково)</translation>
    </message>
</context>
<context>
    <name>about</name>
    <message>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <source>I would like to thank the following people who volunteered to translate qBittorrent:</source>
        <translation>Я хотів би подякувати наступним людям, які переклали qBittorrent на власні мови:</translation>
    </message>
    <message>
        <source>Please contact me if you would like to translate qBittorrent into your own language.</source>
        <translation>Будь-ласка зв&apos;яжітся зі мною, якщо ви бажаєте перекласти qBittorrent на вашу мову.</translation>
    </message>
</context>
<context>
    <name>addPeerDialog</name>
    <message>
        <source>Peer addition</source>
        <translation>Додавання піра</translation>
    </message>
    <message>
        <source>IP</source>
        <translation>IP</translation>
    </message>
    <message>
        <source>Port</source>
        <translation>Порт</translation>
    </message>
</context>
<context>
    <name>addTorrentDialog</name>
    <message>
        <source>Torrent addition dialog</source>
        <translation>Діалог додавання торренту</translation>
    </message>
    <message>
        <source>Save path:</source>
        <translation>Шлях збереження:</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Torrent content:</source>
        <translation>Вміст торренту:</translation>
    </message>
    <message>
        <source>Add to download list in paused state</source>
        <translation>Додати до списку завантажень у призупиненому стані</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>Додати</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Відміна</translation>
    </message>
    <message>
        <source>Normal</source>
        <translation>Нормальний</translation>
    </message>
    <message>
        <source>High</source>
        <translation>Високий</translation>
    </message>
    <message>
        <source>Maximum</source>
        <translation>Максимальний</translation>
    </message>
    <message>
        <source>Torrent size:</source>
        <translation>Розмір торрента:</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Невідомо</translation>
    </message>
    <message>
        <source>Free disk space:</source>
        <translation>Вільне місце на диску:</translation>
    </message>
    <message>
        <source>Download in sequential order (slower but good for previewing)</source>
        <translation>Завантажувати по порядку (повільніше, але краще для перегляду)</translation>
    </message>
    <message>
        <source>Skip file checking and start seeding immediately</source>
        <translation>Пропустити перевірку файлів і почати сідування негайно</translation>
    </message>
    <message>
        <source>Label:</source>
        <translation>Мітка:</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Вибрати все</translation>
    </message>
    <message>
        <source>Select None</source>
        <translation>Зняти виділення</translation>
    </message>
    <message>
        <source>Do not download</source>
        <translation>Не завантажувати</translation>
    </message>
</context>
<context>
    <name>authentication</name>
    <message>
        <source>Tracker authentication</source>
        <translation>Аутентификация на трекере</translation>
    </message>
    <message>
        <source>Tracker:</source>
        <translation>Трекер:</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Логін</translation>
    </message>
    <message>
        <source>Username:</source>
        <translation>Ім&apos;я користувача:</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation>Пароль:</translation>
    </message>
    <message>
        <source>Log in</source>
        <translation>Увійти</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Відміна</translation>
    </message>
</context>
<context>
    <name>confirmDeletionDlg</name>
    <message>
        <source>Deletion confirmation - qBittorrent</source>
        <translation>Підтвердження видалення - qBittorrent</translation>
    </message>
    <message>
        <source>Are you sure you want to delete the selected torrents from the transfer list?</source>
        <translation>Ви впевнені, що хочете видалити вибрані торренти зі списку завантажень?</translation>
    </message>
    <message>
        <source>Remember choice</source>
        <translation>Запам&apos;ятати вибір</translation>
    </message>
    <message>
        <source>Also delete the files on the hard disk</source>
        <translation>Також видалити файли на жорсткому диску</translation>
    </message>
</context>
<context>
    <name>createTorrentDialog</name>
    <message>
        <source>Cancel</source>
        <translation>Відміна</translation>
    </message>
    <message>
        <source>Torrent Creation Tool</source>
        <translation>Інструмент для створення Torrent&apos;ів</translation>
    </message>
    <message>
        <source>Torrent file creation</source>
        <translation>Створення torrent-файлу</translation>
    </message>
    <message>
        <source>Announce urls (trackers):</source>
        <translation type="obsolete">urls анонсу (трекери):</translation>
    </message>
    <message>
        <source>Comment (optional):</source>
        <translation type="obsolete">Коментарій (необов&apos;язково):</translation>
    </message>
    <message>
        <source>Web seeds urls (optional):</source>
        <translation type="obsolete">Urls web-роздачі (необов&apos;язково):</translation>
    </message>
    <message>
        <source>File or folder to add to the torrent:</source>
        <translation>Файл або папка для додавання в торрент:</translation>
    </message>
    <message>
        <source>Piece size:</source>
        <translation>Розмір частини:</translation>
    </message>
    <message>
        <source>32 KiB</source>
        <translation>32 КіБ</translation>
    </message>
    <message>
        <source>64 KiB</source>
        <translation>64 КіБ</translation>
    </message>
    <message>
        <source>128 KiB</source>
        <translation>128 КіБ</translation>
    </message>
    <message>
        <source>256 KiB</source>
        <translation>256 КіБ</translation>
    </message>
    <message>
        <source>512 KiB</source>
        <translation>512 КіБ</translation>
    </message>
    <message>
        <source>1 MiB</source>
        <translation>1 МіБ</translation>
    </message>
    <message>
        <source>2 MiB</source>
        <translation>2 МіБ</translation>
    </message>
    <message>
        <source>4 MiB</source>
        <translation>4 МіБ</translation>
    </message>
    <message>
        <source>Private (won&apos;t be distributed on DHT network if enabled)</source>
        <translation>Приватно (не буде передаватись через мережу DHT, якщо увімкнено)</translation>
    </message>
    <message>
        <source>Start seeding after creation</source>
        <translation>Почати роздачу одразу після створення</translation>
    </message>
    <message>
        <source>Create and save...</source>
        <translation>Створити і зберегти...</translation>
    </message>
    <message>
        <source>Progress:</source>
        <translation>Прогрес:</translation>
    </message>
    <message>
        <source>Add file</source>
        <translation>Додати файл</translation>
    </message>
    <message>
        <source>Add folder</source>
        <translation>Додати папку</translation>
    </message>
    <message>
        <source>Tracker URLs:</source>
        <translation>URL трекерів:</translation>
    </message>
    <message>
        <source>Web seeds urls:</source>
        <translation>URL веб-сідів:</translation>
    </message>
    <message>
        <source>Comment:</source>
        <translation>Коментар:</translation>
    </message>
    <message>
        <source>Auto</source>
        <translation>Автоматично</translation>
    </message>
</context>
<context>
    <name>createtorrent</name>
    <message>
        <source>Select destination torrent file</source>
        <translation type="obsolete">Виберіть цільовий torrent-файл</translation>
    </message>
    <message>
        <source>Torrent Files</source>
        <translation type="obsolete">Torrent файли</translation>
    </message>
    <message>
        <source>No input path set</source>
        <translation type="obsolete">Не задано вхідний шлях</translation>
    </message>
    <message>
        <source>Please type an input path first</source>
        <translation type="obsolete">Будь ласка, спочатку введіть вхідний шлях</translation>
    </message>
    <message>
        <source>Torrent creation</source>
        <translation type="obsolete">Створення торренту</translation>
    </message>
    <message>
        <source>Torrent was created successfully:</source>
        <translation type="obsolete">Торрент було успішно створено:</translation>
    </message>
    <message>
        <source>Select a folder to add to the torrent</source>
        <translation type="obsolete">Виберіть папку для додавання в torrent</translation>
    </message>
    <message>
        <source>Please type an announce URL</source>
        <translation type="obsolete">Будь ласка, введіть URL анонсу</translation>
    </message>
    <message>
        <source>Torrent creation was unsuccessful, reason: %1</source>
        <translation type="obsolete">Створення torrent&apos;у було невдалим, причина: %1</translation>
    </message>
    <message>
        <source>Announce URL:</source>
        <comment>Tracker URL</comment>
        <translation type="obsolete">URL анонсу:</translation>
    </message>
    <message>
        <source>Please type a web seed url</source>
        <translation type="obsolete">Будь ласка, введіть URL web-роздачі</translation>
    </message>
    <message>
        <source>Web seed URL:</source>
        <translation type="obsolete">URL web-роздачі:</translation>
    </message>
    <message>
        <source>Select a file to add to the torrent</source>
        <translation type="obsolete">Виберіть файл для додавання в торрент</translation>
    </message>
    <message>
        <source>Created torrent file is invalid. It won&apos;t be added to download list.</source>
        <translation type="obsolete">Створений торрент-файл неправильний. Він не буде доданий до списку завантажень.</translation>
    </message>
</context>
<context>
    <name>downloadFromURL</name>
    <message>
        <source>Download Torrents from URLs</source>
        <translation type="obsolete">Завантажити торренти з URL-ів</translation>
    </message>
    <message>
        <source>Only one URL per line</source>
        <translation type="obsolete">Лише один URL на лінію</translation>
    </message>
    <message>
        <source>Download</source>
        <translation>Завантажити</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Відміна</translation>
    </message>
    <message>
        <source>Download from urls</source>
        <translation>Завантажити з URL&apos;ів</translation>
    </message>
    <message>
        <source>No URL entered</source>
        <translation>Не введено URL</translation>
    </message>
    <message>
        <source>Please type at least one URL.</source>
        <translation>Будь ласка, введіть хоча б один URL.</translation>
    </message>
    <message>
        <source>Add torrent links</source>
        <translation>Додати посилання на торрент</translation>
    </message>
    <message>
        <source>Both HTTP and Magnet links are supported</source>
        <translation>І HTTP, і магнітні посилання підтримуються</translation>
    </message>
</context>
<context>
    <name>downloadThread</name>
    <message>
        <source>I/O Error</source>
        <translation type="obsolete">Помилка вводу/виводу</translation>
    </message>
    <message>
        <source>The remote host name was not found (invalid hostname)</source>
        <translation type="obsolete">Віддалений сервер не знайдено (неправильна адреса)</translation>
    </message>
    <message>
        <source>The operation was canceled</source>
        <translation type="obsolete">Операцію скасовано</translation>
    </message>
    <message>
        <source>The remote server closed the connection prematurely, before the entire reply was received and processed</source>
        <translation type="obsolete">Віддалений сервер закрив з&apos;єднання зарано, перед тим, як було отримано і оброблено відповідь</translation>
    </message>
    <message>
        <source>The connection to the remote server timed out</source>
        <translation type="obsolete">Вичерпано час на з&apos;єднання з віддаленим сервером</translation>
    </message>
    <message>
        <source>SSL/TLS handshake failed</source>
        <translation type="obsolete">Помилка SSL/TLS</translation>
    </message>
    <message>
        <source>The remote server refused the connection</source>
        <translation type="obsolete">Віддалений сервер відмовив у з&apos;єднанні</translation>
    </message>
    <message>
        <source>The connection to the proxy server was refused</source>
        <translation type="obsolete">Відмовлено у з&apos;єднанні з проксі-сервером</translation>
    </message>
    <message>
        <source>The proxy server closed the connection prematurely</source>
        <translation type="obsolete">Проксі-сервер закрив з&apos;єднання</translation>
    </message>
    <message>
        <source>The proxy host name was not found</source>
        <translation type="obsolete">Не знайдено проксі-сервер</translation>
    </message>
    <message>
        <source>The connection to the proxy timed out or the proxy did not reply in time to the request sent</source>
        <translation type="obsolete">Вичерпано час на з&apos;єднання з проксі</translation>
    </message>
    <message>
        <source>The proxy requires authentication in order to honour the request but did not accept any credentials offered</source>
        <translation type="obsolete">Проксі потребує автентифікації, але не прийняв автентифікаційних даних</translation>
    </message>
    <message>
        <source>The access to the remote content was denied (401)</source>
        <translation type="obsolete">Відмовлено у доступі до віддалених даних (401)</translation>
    </message>
    <message>
        <source>The operation requested on the remote content is not permitted</source>
        <translation type="obsolete">Операція щодо віддаленого контенту не дозволена</translation>
    </message>
    <message>
        <source>The remote content was not found at the server (404)</source>
        <translation type="obsolete">Віддалені дані не знайдено на сервері (404)</translation>
    </message>
    <message>
        <source>The remote server requires authentication to serve the content but the credentials provided were not accepted</source>
        <translation type="obsolete">Віддалений сервер потребує автентифікації, але не прийняв автентифікаційних даних</translation>
    </message>
    <message>
        <source>The Network Access API cannot honor the request because the protocol is not known</source>
        <translation type="obsolete">Невідомий протокол</translation>
    </message>
    <message>
        <source>The requested operation is invalid for this protocol</source>
        <translation type="obsolete">Операція неправильна для цього протоколу</translation>
    </message>
    <message>
        <source>An unknown network-related error was detected</source>
        <translation type="obsolete">Невідома помилка, пов&apos;язана з мережею</translation>
    </message>
    <message>
        <source>An unknown proxy-related error was detected</source>
        <translation type="obsolete">Невідома помилка, пов&apos;язана з проксі</translation>
    </message>
    <message>
        <source>An unknown error related to the remote content was detected</source>
        <translation type="obsolete">Невідома помилка, пов&apos;язана з віддаленим контентом</translation>
    </message>
    <message>
        <source>A breakdown in protocol was detected</source>
        <translation type="obsolete">Поломка в протоколі</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation type="obsolete">Невідома помилка</translation>
    </message>
</context>
<context>
    <name>engineSelect</name>
    <message>
        <source>Search plugins</source>
        <translation>Пошукові плагіни</translation>
    </message>
    <message>
        <source>Installed search engines:</source>
        <translation>Встановлені пошуковики:</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Ім&apos;я</translation>
    </message>
    <message>
        <source>Url</source>
        <translation>Url</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Увімкнено</translation>
    </message>
    <message>
        <source>Install a new one</source>
        <translation>Встановити новий</translation>
    </message>
    <message>
        <source>Check for updates</source>
        <translation>Перевірити оновлення</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Закрити</translation>
    </message>
    <message>
        <source>Enable</source>
        <translation type="obsolete">Дозволити</translation>
    </message>
    <message>
        <source>Disable</source>
        <translation type="obsolete">Заборонити</translation>
    </message>
    <message>
        <source>Uninstall</source>
        <translation>Видалити</translation>
    </message>
    <message>
        <source>You can get new search engine plugins here: &lt;a href=&quot;http://plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</source>
        <translation>Ви можете отримати нові пошукові плагіни тут: &lt;a href=&quot;http://plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</translation>
    </message>
</context>
<context>
    <name>engineSelectDlg</name>
    <message>
        <source>Uninstall warning</source>
        <translation>Попередження про видалення</translation>
    </message>
    <message>
        <source>Some plugins could not be uninstalled because they are included in qBittorrent.
 Only the ones you added yourself can be uninstalled.
However, those plugins were disabled.</source>
        <translation>Деякі плагіни не можуть бути видалені, тому що вони є частиною qBittorrent.
Можна видалити лише ті плагіни, які ви встановили власноруч.
Тим не менше, ці плагіни вимкнено.</translation>
    </message>
    <message>
        <source>Uninstall success</source>
        <translation>Видалення успішне</translation>
    </message>
    <message>
        <source>Select search plugins</source>
        <translation>Вибрати пошукові плагіни</translation>
    </message>
    <message>
        <source>qBittorrent search plugins</source>
        <translation>Пошукові плагіни qBittorrent</translation>
    </message>
    <message>
        <source>Search plugin install</source>
        <translation>Встановити пошуковий плагін</translation>
    </message>
    <message>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <source>A more recent version of %1 search engine plugin is already installed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>Новіша версія пошукового плагіну %1 вже є встановлена.</translation>
    </message>
    <message>
        <source>Search plugin update</source>
        <translation>Оновити пошуковий плагін</translation>
    </message>
    <message>
        <source>Sorry, update server is temporarily unavailable.</source>
        <translation>Пробачте, сервер оновлень тимчасово недоступний.</translation>
    </message>
    <message>
        <source>All your plugins are already up to date.</source>
        <translation>Всі ваші плагіни мають останню версію.</translation>
    </message>
    <message>
        <source>%1 search engine plugin could not be updated, keeping old version.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>Пошуковий плагін %1 не вдалося оновити, залишено стару версію.</translation>
    </message>
    <message>
        <source>%1 search engine plugin could not be installed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>Не вдалося встановити пошуковий плагін %1.</translation>
    </message>
    <message>
        <source>All selected plugins were uninstalled successfully</source>
        <translation>Всі вибрані пошукові плагіни було успішно видалено</translation>
    </message>
    <message>
        <source>%1 search engine plugin was successfully updated.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>Пошуковий плагін %1 було успішно оновлено.</translation>
    </message>
    <message>
        <source>%1 search engine plugin was successfully installed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>Пошуковий плагін %1 було успішно встановлено.</translation>
    </message>
    <message>
        <source>Sorry, %1 search plugin install failed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>Вибачте, встановлення пошукового плагіну %1 невдале.</translation>
    </message>
    <message>
        <source>New search engine plugin URL</source>
        <translation>Новий URL пошукового плагіну</translation>
    </message>
    <message>
        <source>URL:</source>
        <translation>URL:</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Так</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Ні</translation>
    </message>
</context>
<context>
    <name>misc</name>
    <message>
        <source>B</source>
        <comment>bytes</comment>
        <translation>Б</translation>
    </message>
    <message>
        <source>KiB</source>
        <comment>kibibytes (1024 bytes)</comment>
        <translation>КіБ</translation>
    </message>
    <message>
        <source>MiB</source>
        <comment>mebibytes (1024 kibibytes)</comment>
        <translation>МіБ</translation>
    </message>
    <message>
        <source>GiB</source>
        <comment>gibibytes (1024 mibibytes)</comment>
        <translation>ГіБ</translation>
    </message>
    <message>
        <source>TiB</source>
        <comment>tebibytes (1024 gibibytes)</comment>
        <translation>ТіБ</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Невідомо</translation>
    </message>
    <message>
        <source>Unknown</source>
        <comment>Unknown (size)</comment>
        <translation>Невідомо</translation>
    </message>
    <message>
        <source>&lt; 1m</source>
        <comment>&lt; 1 minute</comment>
        <translation>&lt; 1хв</translation>
    </message>
    <message>
        <source>%1m</source>
        <comment>e.g: 10minutes</comment>
        <translation>%1хв</translation>
    </message>
    <message>
        <source>%1h %2m</source>
        <comment>e.g: 3hours 5minutes</comment>
        <translation>%1г %2хв</translation>
    </message>
    <message>
        <source>%1d %2h</source>
        <comment>e.g: 2days 10hours</comment>
        <translation>%1д %2г</translation>
    </message>
    <message>
        <source>qBittorrent will shutdown the computer now because all downloads are complete.</source>
        <translation>Зараз qBittorrent вимкне комп&apos;ютер, бо всі завантаження завершено.</translation>
    </message>
</context>
<context>
    <name>options_imp</name>
    <message>
        <source>Choose a save directory</source>
        <translation>Виберіть директорію для збереження</translation>
    </message>
    <message>
        <source>Choose an ip filter file</source>
        <translation>Виберіть файл IP-фільтру</translation>
    </message>
    <message>
        <source>Filters</source>
        <translation>Фільтри</translation>
    </message>
    <message>
        <source>Choose export directory</source>
        <translation>Виберіть папку для експорту</translation>
    </message>
    <message>
        <source>Add directory to scan</source>
        <translation></translation>
    </message>
    <message>
        <source>Folder is already being watched.</source>
        <translation>За папкою вже ведеться стеження.</translation>
    </message>
    <message>
        <source>Folder does not exist.</source>
        <translation>Папка не існує.</translation>
    </message>
    <message>
        <source>Folder is not readable.</source>
        <translation>Папку неможливо прочитати.</translation>
    </message>
    <message>
        <source>Failure</source>
        <translation>Провал</translation>
    </message>
    <message>
        <source>Failed to add Scan Folder &apos;%1&apos;: %2</source>
        <translation>Не вдалося просканувати папку &apos;%1&apos;: %2</translation>
    </message>
    <message>
        <source>Parsing error</source>
        <translation>Помилка розбору</translation>
    </message>
    <message>
        <source>Failed to parse the provided IP filter</source>
        <translation>Не вдалося розібрати даний фільтр IP</translation>
    </message>
    <message>
        <source>Succesfully refreshed</source>
        <translation type="obsolete">Успішно оновлено</translation>
    </message>
    <message>
        <source>Successfuly parsed the provided IP filter: %1 rules were applied.</source>
        <comment>%1 is a number</comment>
        <translation>Успішно розібрано даний фільтр IP: було застосовано %1 правил.</translation>
    </message>
    <message>
        <source>Successfully refreshed</source>
        <translation>Успішно оновлено</translation>
    </message>
    <message>
        <source>Invalid key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This is not a valid SSL key.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid certificate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This is not a valid SSL certificate.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SSL Certificate (*.crt *.pem)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SSL Key (*.key *.pem)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>pluginSourceDlg</name>
    <message>
        <source>Plugin source</source>
        <translation>Джерело плагіну</translation>
    </message>
    <message>
        <source>Search plugin source:</source>
        <translation>Джерело пошукового плагіну:</translation>
    </message>
    <message>
        <source>Local file</source>
        <translation>Локальний файл</translation>
    </message>
    <message>
        <source>Web link</source>
        <translation>Веб-посилання</translation>
    </message>
</context>
<context>
    <name>preview</name>
    <message>
        <source>Preview selection</source>
        <translation>Вибір перегляду</translation>
    </message>
    <message>
        <source>File preview</source>
        <translation>Перегляд файлу</translation>
    </message>
    <message>
        <source>The following files support previewing, &lt;br&gt;please select one of them:</source>
        <translation>Наступні файли підтримують перегляд, &lt;br&gt;будь-ласка, виберіть один з них:</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Перегляд</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Відміна</translation>
    </message>
</context>
<context>
    <name>previewSelect</name>
    <message>
        <source>Preview impossible</source>
        <translation type="obsolete">Перегляд неможливий</translation>
    </message>
    <message>
        <source>Sorry, we can&apos;t preview this file</source>
        <translation type="obsolete">Пробачте, неможливо переглянути цей файл</translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="obsolete">Ім&apos;я</translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="obsolete">Розмір</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation type="obsolete">Прогрес</translation>
    </message>
</context>
<context>
    <name>search_engine</name>
    <message>
        <source>Search</source>
        <translation>Пошук</translation>
    </message>
    <message>
        <source>Status:</source>
        <translation>Статус:</translation>
    </message>
    <message>
        <source>Stopped</source>
        <translation>Зупинено</translation>
    </message>
    <message>
        <source>Download</source>
        <translation>Завантажити</translation>
    </message>
    <message>
        <source>Search engines...</source>
        <translation>Пошуковики...</translation>
    </message>
    <message>
        <source>Go to description page</source>
        <translation>Іти до сторінки опису</translation>
    </message>
</context>
<context>
    <name>torrentAdditionDialog</name>
    <message>
        <source>Unable to decode torrent file:</source>
        <translation>Не вдалося розкодувати torrent-файл:</translation>
    </message>
    <message>
        <source>Choose save path</source>
        <translation>Виберіть шлях збереження</translation>
    </message>
    <message>
        <source>Empty save path</source>
        <translation>Пустий шлях збереження</translation>
    </message>
    <message>
        <source>Please enter a save path</source>
        <translation>Будь-ласка, введіть шлях збереження</translation>
    </message>
    <message>
        <source>Save path creation error</source>
        <translation>Помилка при створенні шляху збереження</translation>
    </message>
    <message>
        <source>Could not create the save path</source>
        <translation>Не вдалося створити шлях збереження</translation>
    </message>
    <message>
        <source>Invalid file selection</source>
        <translation>Неправильно вибрано файл</translation>
    </message>
    <message>
        <source>You must select at least one file in the torrent</source>
        <translation>Ви повинні вибрати хоча б один файл в торренті</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Пріоритет</translation>
    </message>
    <message>
        <source>(%1 left after torrent download)</source>
        <comment>e.g. (100MiB left after torrent download)</comment>
        <translation>(%1 залишиться після завантаження)</translation>
    </message>
    <message>
        <source>(%1 more are required to download)</source>
        <comment>e.g. (100MiB more are required to download)</comment>
        <translation>(потрібно ще %1 вільного місця)</translation>
    </message>
    <message>
        <source>Seeding mode error</source>
        <translation>Помилка режиму сідування</translation>
    </message>
    <message>
        <source>You chose to skip file checking. However, local files do not seem to exist in the current destionation folder. Please disable this feature or update the save path.</source>
        <translation>Ви вирішили пропустити перевірку файлів. Але, здається, локальні файли не існують в заданій папці. Будь ласка, вимкніть цю можливіть або змініть шлях збереження.</translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation>Перейменувати...</translation>
    </message>
    <message>
        <source>New name:</source>
        <translation>Нове ім&apos;я:</translation>
    </message>
    <message>
        <source>The file could not be renamed</source>
        <translation>Файл не вдалося перейменувати</translation>
    </message>
    <message>
        <source>This name is already in use in this folder. Please use a different name.</source>
        <translation>Це ім&apos;я вже використовується в цій папці. Виберіть інше ім&apos;я.</translation>
    </message>
    <message>
        <source>The folder could not be renamed</source>
        <translation>Папку не вдалося перейменувати</translation>
    </message>
    <message>
        <source>Rename the file</source>
        <translation>Перейменувати файл</translation>
    </message>
    <message>
        <source>Unable to decode magnet link:</source>
        <translation>Не вдалося розкодувати магнітне посилання:</translation>
    </message>
    <message>
        <source>Magnet Link</source>
        <translation>Магнітне посилання</translation>
    </message>
    <message>
        <source>Invalid label name</source>
        <translation>Неправильна назва мітки</translation>
    </message>
    <message>
        <source>Please don&apos;t use any special characters in the label name.</source>
        <translation>Будь ласка, не використовуйте спеціальних символів в назві мітки.</translation>
    </message>
    <message>
        <source>This file name contains forbidden characters, please choose a different one.</source>
        <translation>Це ім&apos;я файла містить заборонені символи. Будь ласка, виберіть інше.</translation>
    </message>
</context>
</TS>
