<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="hr_HR" sourcelanguage="en">
<context>
    <name>AboutDlg</name>
    <message>
        <source>About qBittorrent</source>
        <translation>O programu qBittorrent</translation>
    </message>
    <message>
        <source>About</source>
        <translation>O</translation>
    </message>
    <message utf8="true">
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;A Bittorrent client programmed in C++, based on Qt4 toolkit &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;and libtorrent-rasterbar. &lt;br /&gt;&lt;br /&gt;Copyright ©2006-2009 Christophe Dumez&lt;br /&gt;&lt;br /&gt;&lt;span style=&quot; text-decoration: underline;&quot;&gt;Home Page:&lt;/span&gt; &lt;a href=&quot;http://www.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;http://www.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;br /&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Bittorrent klijent pisan u programskom jeziku C++, baziran na Qt4 toolkitu &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;i libtorrent-rasterbaru. &lt;br /&gt;&lt;br /&gt;Copyright ©2006-2009 Christophe Dumez&lt;br /&gt;&lt;br /&gt;&lt;span style=&quot; text-decoration: underline;&quot;&gt;Web stranica:&lt;/span&gt; &lt;a href=&quot;http://www.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;http://www.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;br /&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation>Ime:</translation>
    </message>
    <message>
        <source>Country:</source>
        <translation>Država:</translation>
    </message>
    <message>
        <source>E-mail:</source>
        <translation>E-pošta:</translation>
    </message>
    <message>
        <source>Home page:</source>
        <translation type="obsolete">Stranica:</translation>
    </message>
    <message>
        <source>Christophe Dumez</source>
        <translation>Christophe Dumez</translation>
    </message>
    <message>
        <source>France</source>
        <translation>Francuska</translation>
    </message>
    <message>
        <source>Translation</source>
        <translation>Prijevod</translation>
    </message>
    <message>
        <source>License</source>
        <translation>Licenca</translation>
    </message>
    <message>
        <source>&lt;h3&gt;&lt;b&gt;qBittorrent&lt;/b&gt;&lt;/h3&gt;</source>
        <translation>&lt;h3&gt;&lt;b&gt;qBittorrent&lt;/b&gt;&lt;/h3&gt;</translation>
    </message>
    <message>
        <source>chris@qbittorrent.org</source>
        <translation>chris@qbittorrent.org</translation>
    </message>
    <message>
        <source>http://www.dchris.eu</source>
        <translation type="obsolete">http://www.dchris.eu</translation>
    </message>
    <message>
        <source>Birthday:</source>
        <translation type="obsolete">Rođendan:</translation>
    </message>
    <message>
        <source>Occupation:</source>
        <translation type="obsolete">Zanimanje:</translation>
    </message>
    <message>
        <source>03/05/1985</source>
        <translation type="obsolete">03. svibnja 1985</translation>
    </message>
    <message>
        <source>Student in computer science</source>
        <translation type="obsolete">Sudent računalnih znanosti</translation>
    </message>
    <message>
        <source>Thanks to</source>
        <translation>Zahvale</translation>
    </message>
    <message utf8="true">
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;A Bittorrent client programmed in C++, based on Qt4 toolkit &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;and libtorrent-rasterbar. &lt;br /&gt;&lt;br /&gt;Copyright ©2006-2010 Christophe Dumez&lt;br /&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Home Page:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://www.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;http://www.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Forum:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://forum.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;http://forum.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;IRC:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; #qbittorrent on Freenode&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;Bittorrent klijent pisan u C++, baziran na Qt4 programskom alatu &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;i libtorrent-rasterbaru. &lt;br /&gt;&lt;br /&gt;Copyright ©2006-2010 Christophe Dumez&lt;br /&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Službena stranica:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://www.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;http://qbittorrent.sourceforge.net/&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Forum:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://forum.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;http://qbforums.shiki.hu/&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;IRC:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; #qbittorrent on Freenode&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message utf8="true">
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;An advanced BitTorrent client programmed in C++, based on Qt4 toolkit and libtorrent-rasterbar. &lt;br /&gt;&lt;br /&gt;Copyright ©2006-2011 Christophe Dumez&lt;br /&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Home Page:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://www.qbittorrent.org&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans&apos;; text-decoration: underline; color:#0057ae;&quot;&gt;http://www.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Bug Tracker:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://bugs.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;http://bugs.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Forum:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://forum.qbittorrent.org&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans&apos;; text-decoration: underline; color:#0057ae;&quot;&gt;http://forum.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;IRC:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; #qbittorrent on Freenode&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;Napredni BitTorrent klijent pisan u C++-u, baziran na Qt4 programskom alatu i libtorrent-rasterbaru. &lt;br /&gt;&lt;br /&gt;Copyright ©2006-2011 Christophe Dumez&lt;br /&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Home Page:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://www.qbittorrent.org&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans&apos;; text-decoration: underline; color:#0057ae;&quot;&gt;http://www.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Prijava greški:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://bugs.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;http://bugs.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Forum:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://forum.qbittorrent.org&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans&apos;; text-decoration: underline; color:#0057ae;&quot;&gt;http://forum.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;IRC:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; #qbittorrent na Freenode-u&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
</context>
<context>
    <name>AdvancedSettings</name>
    <message>
        <source>Property</source>
        <translation type="obsolete">Svojstvo</translation>
    </message>
    <message>
        <source>Value</source>
        <translation type="obsolete">Vrijednost</translation>
    </message>
    <message>
        <source>Disk write cache size</source>
        <translation>Veličina privremene memorije pisanja diska</translation>
    </message>
    <message>
        <source> MiB</source>
        <translation>MiB</translation>
    </message>
    <message>
        <source>Outgoing ports (Min) [0: Disabled]</source>
        <translation>Izlazni portovi (Min.) [0: Onemogućeni]</translation>
    </message>
    <message>
        <source>Outgoing ports (Max) [0: Disabled]</source>
        <translation>Izlazni portovi (Maks.) [0: Omogućeni]</translation>
    </message>
    <message>
        <source>Recheck torrents on completion</source>
        <translation>Ponovno provjeri torrente pri dopunjavanju</translation>
    </message>
    <message>
        <source>Transfer list refresh interval</source>
        <translation>Interval osvježavanja popisa transfera</translation>
    </message>
    <message>
        <source> ms</source>
        <comment> milliseconds</comment>
        <translation> ms</translation>
    </message>
    <message>
        <source>Resolve peer countries (GeoIP)</source>
        <translation>Razrješi države peerova (GeoIP)</translation>
    </message>
    <message>
        <source>Resolve peer host names</source>
        <translation>Razrješi imena peer hostova</translation>
    </message>
    <message>
        <source>Ignore transfer limits on local network</source>
        <translation>Zanemari limite transfera na lokalnoj mreži</translation>
    </message>
    <message>
        <source>Include TCP/IP overhead in transfer limits</source>
        <translation type="obsolete">Uključi TCP/IP dodatak u limitima transfera</translation>
    </message>
    <message>
        <source>Maximum number of half-open connections [0: Disabled]</source>
        <translation>Najveći broj poluotvorenih veza [0: Disabled]</translation>
    </message>
    <message>
        <source>Strict super seeding</source>
        <translation>Strogo superseedanje</translation>
    </message>
    <message>
        <source>Network Interface (requires restart)</source>
        <translation>Mrežno sučelje (zahtjeva ponovno pokretanje)</translation>
    </message>
    <message>
        <source>Any interface</source>
        <comment>i.e. Any network interface</comment>
        <translation>Bilo koje sučelje</translation>
    </message>
    <message>
        <source>Display program notification baloons</source>
        <translation type="obsolete">Prikazuj balončiće.obavijesti</translation>
    </message>
    <message>
        <source>Display program notification balloons</source>
        <translation type="obsolete">Prikaži obavjesne balončiće</translation>
    </message>
    <message>
        <source>Enable embedded tracker</source>
        <translation>Omogući ugrađeni tracker</translation>
    </message>
    <message>
        <source>Embedded tracker port</source>
        <translation>Port ugrađenog trackera</translation>
    </message>
    <message>
        <source>Check for software updates</source>
        <translation>Provjeri softverska ažuriranja</translation>
    </message>
    <message>
        <source>Use system icon theme</source>
        <translation>Koristi teme ikona sustava</translation>
    </message>
    <message>
        <source>Confirm torrent deletion</source>
        <translation>Potvrdite brisanje torrenta</translation>
    </message>
    <message>
        <source>IP Address to report to trackers (requires restart)</source>
        <translation>IP adresa za prijaviti trackerima (potrebno ponovno pokretanje)</translation>
    </message>
    <message>
        <source>Display program on-screen notifications</source>
        <translation>Prikazuj obavijesti.na ekranu</translation>
    </message>
    <message>
        <source>Setting</source>
        <translation>Postavka</translation>
    </message>
    <message>
        <source>Value</source>
        <comment>Value set for this setting</comment>
        <translation>Vrijednost</translation>
    </message>
    <message>
        <source>Exchange trackers with other peers</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AutomatedRssDownloader</name>
    <message>
        <source>Automated RSS Downloader</source>
        <translation>Automatizirani RSS Preuzimatelj</translation>
    </message>
    <message>
        <source>Enable the automated RSS downloader</source>
        <translation>Omogući automatiziranog RSS preuzimatelja</translation>
    </message>
    <message>
        <source>Download rules</source>
        <translation>Preuzmi pravila</translation>
    </message>
    <message>
        <source>Rule definition</source>
        <translation>Definicija pravila</translation>
    </message>
    <message>
        <source>Must contain:</source>
        <translation>Mora sadržavati:</translation>
    </message>
    <message>
        <source>Must not contain:</source>
        <translation>Ne mora sadržavati:</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Assign label:</source>
        <translation>Dodijeli oznaku:</translation>
    </message>
    <message>
        <source>Apply rule to feeds:</source>
        <translation>Primijeni pravilo na kanal:</translation>
    </message>
    <message>
        <source>Matching RSS articles</source>
        <translation>Poklapanje RSS članaka</translation>
    </message>
    <message>
        <source>Save to a different directory</source>
        <translation>Spremi u drugi direktorij</translation>
    </message>
    <message>
        <source>Save to:</source>
        <translation>Spremi u:</translation>
    </message>
    <message>
        <source>Import...</source>
        <translation>Uvezi ...</translation>
    </message>
    <message>
        <source>Export...</source>
        <translation>Izvezi ...</translation>
    </message>
    <message>
        <source>New rule name</source>
        <translation>Ime novog pravila</translation>
    </message>
    <message>
        <source>Please type the name of the new download rule.</source>
        <translation>Upišite ime novog pravila preuzimanja.</translation>
    </message>
    <message>
        <source>Rule name conflict</source>
        <translation>Konflikt imena pravila</translation>
    </message>
    <message>
        <source>A rule with this name already exists, please choose another name.</source>
        <translation>Pravilo s tim imenom već postoji. Izaberite drugo ime.</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the download rule named %1?</source>
        <translation>Jeste li sigurni da želite ukloniti pravilo preuzimanja pod pod imenom %1?</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the selected download rules?</source>
        <translation>Jeste li sigurni da želite ukloniti odabrana pravila preuzimanja?</translation>
    </message>
    <message>
        <source>Rule deletion confirmation</source>
        <translation>Pravilo potvrđivanja brisanja</translation>
    </message>
    <message>
        <source>Destination directory</source>
        <translation>Odredišni direktorij</translation>
    </message>
    <message>
        <source>Invalid action</source>
        <translation>Neispravna radnja</translation>
    </message>
    <message>
        <source>The list is empty, there is nothing to export.</source>
        <translation>Popis je prazan. Nema se što izvesti.</translation>
    </message>
    <message>
        <source>Where would you like to save the list?</source>
        <translation>Gdje želite spremiti popis?</translation>
    </message>
    <message>
        <source>Rules list (*.rssrules)</source>
        <translation>Popis pravila (*.rssrules)</translation>
    </message>
    <message>
        <source>I/O Error</source>
        <translation>I/O greška</translation>
    </message>
    <message>
        <source>Failed to create the destination file</source>
        <translation>Nije uspjelo kreiranje odredišne datoteke</translation>
    </message>
    <message>
        <source>Please point to the RSS download rules file</source>
        <translation>Istaknite RSS datoteku pravila preuzimanja</translation>
    </message>
    <message>
        <source>Rules list (*.rssrules *.filters)</source>
        <translation>Popis pravila (*.rssrules *.filters)</translation>
    </message>
    <message>
        <source>Import Error</source>
        <translation>Greška prilikom uvoza</translation>
    </message>
    <message>
        <source>Failed to import the selected rules file</source>
        <translation>Nije uspio uvoz datoteke s odabranim pravilima</translation>
    </message>
    <message>
        <source>Add new rule...</source>
        <translation>Dodaj novo pravilo</translation>
    </message>
    <message>
        <source>Delete rule</source>
        <translation>Izbriši pravilo</translation>
    </message>
    <message>
        <source>Rename rule...</source>
        <translation>Preimenuj pravilo ...</translation>
    </message>
    <message>
        <source>Delete selected rules</source>
        <translation>Izbriši odabrana pravila</translation>
    </message>
    <message>
        <source>Rule renaming</source>
        <translation>Preimenovanje pravila</translation>
    </message>
    <message>
        <source>Please type the new rule name</source>
        <translation>Upišite ime novog pravila</translation>
    </message>
    <message>
        <source>Use regular expressions</source>
        <translation>Koristi uobičajene izraze</translation>
    </message>
    <message>
        <source>Regex mode: use Perl-like regular expressions</source>
        <translation>Regex mode: koristi Pearl-u slične uobičajene izraze</translation>
    </message>
    <message>
        <source>Wildcard mode: you can use&lt;ul&gt;&lt;li&gt;? to match any single character&lt;/li&gt;&lt;li&gt;* to match zero or more of any characters&lt;/li&gt;&lt;li&gt;Whitespaces count as AND operators&lt;/li&gt;&lt;/ul&gt;</source>
        <translation>Wildcard mode: možete koristiti&lt;ul&gt;&lt;li&gt;? za podudaranje s bilo kojim pojedinim znakom&lt;/li&gt;&lt;li&gt;* za podudaranje s nula ili više drugih znakova&lt;/li&gt;&lt;li&gt;Prazna mjesta se računaju kao AND operatori&lt;/li&gt;&lt;/ul&gt;</translation>
    </message>
    <message>
        <source>Wildcard mode: you can use&lt;ul&gt;&lt;li&gt;? to match any single character&lt;/li&gt;&lt;li&gt;* to match zero or more of any characters&lt;/li&gt;&lt;li&gt;| is used as OR operator&lt;/li&gt;&lt;/ul&gt;</source>
        <translation>Wildcard mode: možete koristiti&lt;ul&gt;&lt;li&gt;? za podudaranje s bilo kojim pojedinim znakom&lt;/li&gt;&lt;li&gt;* za podudaranje s nula ili više drugih znakova&lt;/li&gt;&lt;li&gt;| se koristi kao OR operator&lt;/li&gt;&lt;/ul&gt;</translation>
    </message>
</context>
<context>
    <name>Bittorrent</name>
    <message>
        <source>%1 reached the maximum ratio you set.</source>
        <translation type="obsolete">%1 dostigao je najveći zadani omjer.</translation>
    </message>
    <message>
        <source>qBittorrent is bound to port: TCP/%1</source>
        <comment>e.g: qBittorrent is bound to port: 6881</comment>
        <translation type="obsolete">qBittorrent je povezan s portom: TCP/%1</translation>
    </message>
    <message>
        <source>UPnP support [ON]</source>
        <translation type="obsolete">Podrška za UPnP [UKLJUČENA]</translation>
    </message>
    <message>
        <source>UPnP support [OFF]</source>
        <translation type="obsolete">Podrška za UPnP [ISKLJUČENA]</translation>
    </message>
    <message>
        <source>NAT-PMP support [ON]</source>
        <translation type="obsolete">Podrška za NAT-PMP [UKLJUČENA]</translation>
    </message>
    <message>
        <source>NAT-PMP support [OFF]</source>
        <translation type="obsolete">Podrška za NAT-PMP [ISKLJUČENA]</translation>
    </message>
    <message>
        <source>HTTP user agent is %1</source>
        <translation type="obsolete">Agent HTTP korisnika je %1</translation>
    </message>
    <message>
        <source>Using a disk cache size of %1 MiB</source>
        <translation type="obsolete">Korištenje privremene memorije diska od %1 MiB</translation>
    </message>
    <message>
        <source>DHT support [ON], port: UDP/%1</source>
        <translation type="obsolete">Podrška za DHT [UKLJUČENA], port: UDP/%1</translation>
    </message>
    <message>
        <source>DHT support [OFF]</source>
        <translation type="obsolete">Podrška za DHT [ISKLJUČENA]</translation>
    </message>
    <message>
        <source>PeX support [ON]</source>
        <translation type="obsolete">Podrška za PeX [UKLJUČENA]</translation>
    </message>
    <message>
        <source>PeX support [OFF]</source>
        <translation type="obsolete">Podrška za PeX [ISKLJUČENA]</translation>
    </message>
    <message>
        <source>Restart is required to toggle PeX support</source>
        <translation type="obsolete">Potrebno je ponovno pokretanje za uključivanje/isključivanje podrške za PeX</translation>
    </message>
    <message>
        <source>Local Peer Discovery [ON]</source>
        <translation type="obsolete">Otkrivanje lokalnih peerova [UKLJUČENO]</translation>
    </message>
    <message>
        <source>Local Peer Discovery support [OFF]</source>
        <translation type="obsolete">Podrška za otkrivanje lokalnih peerova [ISKLJUČENA]</translation>
    </message>
    <message>
        <source>Encryption support [ON]</source>
        <translation type="obsolete">Podrška za kriptiranje [UKLJUČENA]</translation>
    </message>
    <message>
        <source>Encryption support [FORCED]</source>
        <translation type="obsolete">Podrška za kriptiranje [PRISILNA]</translation>
    </message>
    <message>
        <source>Encryption support [OFF]</source>
        <translation type="obsolete">Podrška za kriptiranje [ISKLJUČENA]</translation>
    </message>
    <message>
        <source>The Web UI is listening on port %1</source>
        <translation type="obsolete">Web sučelje osluškuje na portu %1</translation>
    </message>
    <message>
        <source>Web User Interface Error - Unable to bind Web UI to port %1</source>
        <translation type="obsolete">Greška web korisničkog sučelja - Nije moguće povezati web korisničko sučelje s portom %1</translation>
    </message>
    <message>
        <source>&apos;%1&apos; was removed from transfer list and hard disk.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation type="obsolete">&apos;%1&apos; je uklonjena s popisa transfera i čvrstog diska.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; was removed from transfer list.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation type="obsolete">&apos;%1&apos; je uklonjena s popisa transfera.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is not a valid magnet URI.</source>
        <translation type="obsolete">&apos;%1&apos; nije valjani magnet URI.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is already in download list.</source>
        <comment>e.g: &apos;xxx.avi&apos; is already in download list.</comment>
        <translation type="obsolete">&apos;%1&apos; je već na popisu preuzimanja.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; resumed. (fast resume)</source>
        <comment>&apos;/home/y/xxx.torrent&apos; was resumed. (fast resume)</comment>
        <translation type="obsolete">&apos;%1&apos; počinje iznova. (brzo)</translation>
    </message>
    <message>
        <source>&apos;%1&apos; added to download list.</source>
        <comment>&apos;/home/y/xxx.torrent&apos; was added to download list.</comment>
        <translation type="obsolete">&apos;%1&apos; je dodan popisu preuzimanja.</translation>
    </message>
    <message>
        <source>Unable to decode torrent file: &apos;%1&apos;</source>
        <comment>e.g: Unable to decode torrent file: &apos;/home/y/xxx.torrent&apos;</comment>
        <translation type="obsolete">Nije moguće dekodirati torrent datoteku: &apos;%1&apos;</translation>
    </message>
    <message>
        <source>This file is either corrupted or this isn&apos;t a torrent.</source>
        <translation type="obsolete">Ta datoteka je i dalje neispravna ili nije torrent.</translation>
    </message>
    <message>
        <source>Note: new trackers were added to the existing torrent.</source>
        <translation type="obsolete">Opaska: novi trackeri su dodani postojećem torrentu.</translation>
    </message>
    <message>
        <source>Note: new URL seeds were added to the existing torrent.</source>
        <translation type="obsolete">Opaska: novi URL seedovi dodani su postojećem torrentu.</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;was blocked due to your IP filter&lt;/i&gt;</source>
        <comment>x.y.z.w was blocked</comment>
        <translation type="obsolete">&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;blokirano s obzirom na IP filter&lt;/i&gt;</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;was banned due to corrupt pieces&lt;/i&gt;</source>
        <comment>x.y.z.w was banned</comment>
        <translation type="obsolete">&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;zabranjeno zbog neispravnih dijelova&lt;/i&gt;</translation>
    </message>
    <message>
        <source>Recursive download of file %1 embedded in torrent %2</source>
        <comment>Recursive download of test.torrent embedded in torrent test2</comment>
        <translation type="obsolete">Rekurzivno preuzimanje datoteke %1 ugrađeno u torrent %2</translation>
    </message>
    <message>
        <source>Unable to decode %1 torrent file.</source>
        <translation type="obsolete">Nije moguće dekodirati %1 torrent datoteku.</translation>
    </message>
    <message>
        <source>UPnP/NAT-PMP: Port mapping failure, message: %1</source>
        <translation type="obsolete">UPnP/NAT-PMP: Mapiranje porta nije uspjelo, poruka: %1</translation>
    </message>
    <message>
        <source>UPnP/NAT-PMP: Port mapping successful, message: %1</source>
        <translation type="obsolete">UPnP/NAT-PMP: Mapiranje porta je uspjelo, poruka: %1</translation>
    </message>
    <message>
        <source>Fast resume data was rejected for torrent %1, checking again...</source>
        <translation type="obsolete">Brzi ponovni početak je odbijen za torrent %1, ponovna provjera ...</translation>
    </message>
    <message>
        <source>Reason: %1</source>
        <translation type="obsolete">Razlog: %1</translation>
    </message>
    <message>
        <source>Url seed lookup failed for url: %1, message: %2</source>
        <translation type="obsolete">Traženje URL seeda nije uspjelo za URL: %1, poruka: %2</translation>
    </message>
    <message>
        <source>Downloading &apos;%1&apos;, please wait...</source>
        <comment>e.g: Downloading &apos;xxx.torrent&apos;, please wait...</comment>
        <translation type="obsolete">Preuzimanje &apos;%1&apos;, pričekajte ...</translation>
    </message>
    <message>
        <source>An I/O error occured, &apos;%1&apos; paused.</source>
        <translation type="obsolete">Dogodila se I/O greška. &apos;%1&apos; pauziran.</translation>
    </message>
    <message>
        <source>Removing torrent %1...</source>
        <translation type="obsolete">Uklanjanje torrenta %1 ...</translation>
    </message>
    <message>
        <source>Pausing torrent %1...</source>
        <translation type="obsolete">Pauziranje torrenta %1 ...</translation>
    </message>
    <message>
        <source>Error: The torrent %1 does not contain any file.</source>
        <translation type="obsolete">Greška: Torrent %1 ne sadrži nikakve datoteke.</translation>
    </message>
    <message>
        <source>File sizes mismatch for torrent %1, pausing it.</source>
        <translation type="obsolete">Veličine datoteka se ne slažu za torrent %1, tako da će biti pauziran.</translation>
    </message>
    <message>
        <source>Torrent name: %1</source>
        <translation type="obsolete">Ime torrenta: %1</translation>
    </message>
    <message>
        <source>Torrent size: %1</source>
        <translation type="obsolete">Veličina torrenta: %1</translation>
    </message>
    <message>
        <source>Save path: %1</source>
        <translation type="obsolete">Putanja spremanja: %1</translation>
    </message>
    <message>
        <source>The torrent was downloaded in %1.</source>
        <comment>The torrent was downloaded in 1 hour and 20 seconds</comment>
        <translation type="obsolete">Torrent je preuzet u %1.</translation>
    </message>
    <message>
        <source>Thank you for using qBittorrent.</source>
        <translation type="obsolete">Hvala vam što ste koristili qBittorrent.</translation>
    </message>
    <message>
        <source>[qBittorrent] %1 has finished downloading</source>
        <translation type="obsolete">[qBittorrent] %1 je preuzet</translation>
    </message>
</context>
<context>
    <name>ConsoleDlg</name>
    <message>
        <source>qBittorrent console</source>
        <translation type="obsolete">qBittorrent konzola</translation>
    </message>
    <message>
        <source>General</source>
        <translation type="obsolete">Općenito</translation>
    </message>
    <message>
        <source>Blocked IPs</source>
        <translation type="obsolete">Blokirani IP-ovi</translation>
    </message>
    <message>
        <source>qBittorrent log viewer</source>
        <translation type="obsolete">qBittorrentov preglednik dnevnika</translation>
    </message>
</context>
<context>
    <name>CookiesDlg</name>
    <message>
        <source>Cookies management</source>
        <translation>Upravljanje kolačićima</translation>
    </message>
    <message>
        <source>Key</source>
        <extracomment>As in Key/Value pair</extracomment>
        <translation>Ključ</translation>
    </message>
    <message>
        <source>Value</source>
        <extracomment>As in Key/Value pair</extracomment>
        <translation>Vrijednost</translation>
    </message>
    <message>
        <source>Common keys for cookies are : &apos;%1&apos;, &apos;%2&apos;.
You should get this information from your Web browser preferences.</source>
        <translation>Javni ključevi za kolačiće su: &apos;%1&apos;, &apos;%2&apos;.
Ovu informaciju trebate pribaviti iz postavki vašeg web preglednika.</translation>
    </message>
</context>
<context>
    <name>DNSUpdater</name>
    <message>
        <source>Your dynamic DNS was successfuly updated.</source>
        <translation>Vaš dinamički DNS je uspješno ažuriran.</translation>
    </message>
    <message>
        <source>Dynamic DNS error: The service is temporarily unavailable, it will be retried in 30 minutes.</source>
        <translation>Greška dinamičkog DNS-a: Servis je trenutno nedostupan. Novi pokušaj za 30 minuta.</translation>
    </message>
    <message>
        <source>Dynamic DNS error: hostname supplied does not exist under specified account.</source>
        <translation>Greška dinamičkog DNS-a: Dano ime računala ne postoji pod navedenim računom.</translation>
    </message>
    <message>
        <source>Dynamic DNS error: Invalid username/password.</source>
        <translation>Greška dinamičkog DNS-a: Neispravno korisničko ime ili lozinka.</translation>
    </message>
    <message>
        <source>Dynamic DNS error: qBittorrent was blacklisted by the service, please report a bug at http://bugs.qbittorrent.org.</source>
        <translation>Greška dinamičkog DNS-a: Servis je qBittorrent stavio na crnu listu. Prijavite grešku na http://bugs.qbittorrent.org.</translation>
    </message>
    <message>
        <source>Dynamic DNS error: %1 was returned by the service, please report a bug at http://bugs.qbittorrent.org.</source>
        <translation>Greška dinamičkog DNS-a: Servis je vratio %1. Prijavite grešku na http://bugs.qbittorrent.org.</translation>
    </message>
    <message>
        <source>Dynamic DNS error: Your username was blocked due to abuse.</source>
        <translation>Greška dinamičkog DNS-a: Vaše korisničko ime je blokirano zbog zloupotrebe.</translation>
    </message>
    <message>
        <source>Dynamic DNS error: supplied domain name is invalid.</source>
        <translation>Greška dinamičkog DNS-a: Dano ime domene nije ispravno.</translation>
    </message>
    <message>
        <source>Dynamic DNS error: supplied username is too short.</source>
        <translation>Greška dinamičkog DNS-a: Dano korisničko ime je prekratko.</translation>
    </message>
    <message>
        <source>Dynamic DNS error: supplied password is too short.</source>
        <translation>Greška dinamičkog DNS-a: Dana lozinka je prekratka.</translation>
    </message>
</context>
<context>
    <name>DownloadThread</name>
    <message>
        <source>I/O Error</source>
        <translation>I/O greška</translation>
    </message>
    <message>
        <source>The remote host name was not found (invalid hostname)</source>
        <translation>Ime udaljenog računala nije nađeno (neispravno ime računala)</translation>
    </message>
    <message>
        <source>The operation was canceled</source>
        <translation>Operacija je otkazana</translation>
    </message>
    <message>
        <source>The remote server closed the connection prematurely, before the entire reply was received and processed</source>
        <translation>Udaljeni poslužitelj je prerano prekinuo spajanje, prije nego je primljen i obrađen cijeli odgovor</translation>
    </message>
    <message>
        <source>The connection to the remote server timed out</source>
        <translation>Spajanje s udaljenim poslužiteljem je isteklo</translation>
    </message>
    <message>
        <source>SSL/TLS handshake failed</source>
        <translation>SSL/TLS usklađivanje nije uspjelo</translation>
    </message>
    <message>
        <source>The remote server refused the connection</source>
        <translation>Udaljeni poslužitelj odbija spajanje</translation>
    </message>
    <message>
        <source>The connection to the proxy server was refused</source>
        <translation>Spajanje s proxy poslužiteljem je odbijeno</translation>
    </message>
    <message>
        <source>The proxy server closed the connection prematurely</source>
        <translation>Proxy server je prerano prekinuo spajanje</translation>
    </message>
    <message>
        <source>The proxy host name was not found</source>
        <translation>Ime proxy računala nije nađeno</translation>
    </message>
    <message>
        <source>The connection to the proxy timed out or the proxy did not reply in time to the request sent</source>
        <translation>Spajanje prema proxyju je isteklo ili proxy nije na vrijeme odgovorio na poslani zahtjev</translation>
    </message>
    <message>
        <source>The proxy requires authentication in order to honour the request but did not accept any credentials offered</source>
        <translation>Proxy zahtjeva autentifikaciju kako bi prihvatio zahtjev, ali nije prihvatio ponuđene vjerodajnice</translation>
    </message>
    <message>
        <source>The access to the remote content was denied (401)</source>
        <translation>Pristup udaljenom sadržaju je odbijen (401)</translation>
    </message>
    <message>
        <source>The operation requested on the remote content is not permitted</source>
        <translation>Tražena operacija nad udaljenim sadržajem nije dopuštena</translation>
    </message>
    <message>
        <source>The remote content was not found at the server (404)</source>
        <translation>Udaljeni sadržaj nije nađen na poslužitelju (404)</translation>
    </message>
    <message>
        <source>The remote server requires authentication to serve the content but the credentials provided were not accepted</source>
        <translation>Udaljeni poslužitelj zahtjeva autentifikaciju kako bi dostavio sadržaj, ali pružene vjerodajnice nisu prihvaćene</translation>
    </message>
    <message>
        <source>The Network Access API cannot honor the request because the protocol is not known</source>
        <translation>Network Access API ne može prihvatiti zahtjev jer protokol nije poznat</translation>
    </message>
    <message>
        <source>The requested operation is invalid for this protocol</source>
        <translation>Tražena operacija je neispravna za ovaj protokol</translation>
    </message>
    <message>
        <source>An unknown network-related error was detected</source>
        <translation>Otkrivena je nepoznata greška vezana za mrežu</translation>
    </message>
    <message>
        <source>An unknown proxy-related error was detected</source>
        <translation>Otkrivena je nepoznata greška vezana za proxy</translation>
    </message>
    <message>
        <source>An unknown error related to the remote content was detected</source>
        <translation>Otkrivena je nepoznata greška vezana za udaljeni sadržaj </translation>
    </message>
    <message>
        <source>A breakdown in protocol was detected</source>
        <translation>Otkriven je kvar u protokolu</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Nepoznata greška</translation>
    </message>
</context>
<context>
    <name>EventManager</name>
    <message>
        <source>Working</source>
        <translation>Radi</translation>
    </message>
    <message>
        <source>Updating...</source>
        <translation>Ažuriranje ...</translation>
    </message>
    <message>
        <source>Not working</source>
        <translation>Ne radi</translation>
    </message>
    <message>
        <source>Not contacted yet</source>
        <translation>Nije još kontaktirano</translation>
    </message>
    <message>
        <source>this session</source>
        <translation>ova sesija</translation>
    </message>
    <message>
        <source>/s</source>
        <comment>/second (i.e. per second)</comment>
        <translation>/s</translation>
    </message>
    <message>
        <source>Seeded for %1</source>
        <comment>e.g. Seeded for 3m10s</comment>
        <translation>Seedano za %1</translation>
    </message>
    <message>
        <source>%1 max</source>
        <comment>e.g. 10 max</comment>
        <translation>%1 najviše</translation>
    </message>
    <message>
        <source>%1/s</source>
        <comment>e.g. 120 KiB/s</comment>
        <translation>%1/s</translation>
    </message>
</context>
<context>
    <name>ExecutionLog</name>
    <message>
        <source>Form</source>
        <translation type="obsolete">Oblik</translation>
    </message>
    <message>
        <source>General</source>
        <translation>Općenito</translation>
    </message>
    <message>
        <source>Blocked IPs</source>
        <translation>Blokirani IP-ovi</translation>
    </message>
</context>
<context>
    <name>FeedDownloader</name>
    <message>
        <source>RSS Feed downloader</source>
        <translation type="obsolete">Preuzimatelj RSS kanala</translation>
    </message>
    <message>
        <source>RSS feed:</source>
        <translation type="obsolete">RSS kanal:</translation>
    </message>
    <message>
        <source>Feed name</source>
        <translation type="obsolete">Ime kanala</translation>
    </message>
    <message>
        <source>Automatically download torrents from this feed</source>
        <translation type="obsolete">Automatski preuzmi torrente s tog kanala</translation>
    </message>
    <message>
        <source>Download filters</source>
        <translation type="obsolete">Filteri preuzimanja</translation>
    </message>
    <message>
        <source>Filters:</source>
        <translation type="obsolete">Filteri:</translation>
    </message>
    <message>
        <source>Filter settings</source>
        <translation type="obsolete">Postavke filtera</translation>
    </message>
    <message>
        <source>Matches:</source>
        <translation type="obsolete">Podudarnosti:</translation>
    </message>
    <message>
        <source>Does not match:</source>
        <translation type="obsolete">Ne podudaraju se:</translation>
    </message>
    <message>
        <source>Destination folder:</source>
        <translation type="obsolete">Odredišna mapa:</translation>
    </message>
    <message>
        <source>...</source>
        <translation type="obsolete">...</translation>
    </message>
    <message>
        <source>Filter testing</source>
        <translation type="obsolete">Provjeravanje filtera</translation>
    </message>
    <message>
        <source>Torrent title:</source>
        <translation type="obsolete">Naslov torrenta:</translation>
    </message>
    <message>
        <source>Result:</source>
        <translation type="obsolete">Rezultat:</translation>
    </message>
    <message>
        <source>Test</source>
        <translation type="obsolete">Provjeri</translation>
    </message>
    <message>
        <source>Import...</source>
        <translation type="obsolete">Uvezi ...</translation>
    </message>
    <message>
        <source>Export...</source>
        <translation type="obsolete">Izvezi ...</translation>
    </message>
    <message>
        <source>Rename filter</source>
        <translation type="obsolete">Preimenuj filter</translation>
    </message>
    <message>
        <source>Remove filter</source>
        <translation type="obsolete">Ukloni filter</translation>
    </message>
    <message>
        <source>Add filter</source>
        <translation type="obsolete">Dodaj filter</translation>
    </message>
</context>
<context>
    <name>FeedDownloaderDlg</name>
    <message>
        <source>New filter</source>
        <translation type="obsolete">Novi filter</translation>
    </message>
    <message>
        <source>Please choose a name for this filter</source>
        <translation type="obsolete">Izaberite ime za taj filter</translation>
    </message>
    <message>
        <source>Filter name:</source>
        <translation type="obsolete">Ime filtera:</translation>
    </message>
    <message>
        <source>Invalid filter name</source>
        <translation type="obsolete">Neispravno ime filtera</translation>
    </message>
    <message>
        <source>The filter name cannot be left empty.</source>
        <translation type="obsolete">Ime filtera mora biti zadano.</translation>
    </message>
    <message>
        <source>This filter name is already in use.</source>
        <translation type="obsolete">To se ime filtera već koristi.</translation>
    </message>
    <message>
        <source>Choose save path</source>
        <translation type="obsolete">Izaberite putanju spremanja</translation>
    </message>
    <message>
        <source>Filter testing error</source>
        <translation type="obsolete">Greška prilikom provjere filtera</translation>
    </message>
    <message>
        <source>Please specify a test torrent name.</source>
        <translation type="obsolete">Odredite ime testnog torrenta.</translation>
    </message>
    <message>
        <source>matches</source>
        <translation type="obsolete">podudarnosti</translation>
    </message>
    <message>
        <source>does not match</source>
        <translation type="obsolete">ne podudaraju se</translation>
    </message>
    <message>
        <source>Select file to import</source>
        <translation type="obsolete">Odaberite datoteku za uvoz</translation>
    </message>
    <message>
        <source>Filters Files</source>
        <translation type="obsolete">Datoteke filtera</translation>
    </message>
    <message>
        <source>Import successful</source>
        <translation type="obsolete">Uvoz je uspio</translation>
    </message>
    <message>
        <source>Filters import was successful.</source>
        <translation type="obsolete">Uvoz filtera je uspio.</translation>
    </message>
    <message>
        <source>Import failure</source>
        <translation type="obsolete">Uvoz nije uspio</translation>
    </message>
    <message>
        <source>Filters could not be imported due to an I/O error.</source>
        <translation type="obsolete">Filteri ne mogu biti uvezeni zbog I/O greške.</translation>
    </message>
    <message>
        <source>Select destination file</source>
        <translation type="obsolete">Odaberite odredišnu datoteku</translation>
    </message>
    <message>
        <source>Export successful</source>
        <translation type="obsolete">Izvoz je uspio</translation>
    </message>
    <message>
        <source>Filters export was successful.</source>
        <translation type="obsolete">Izvoz filtera je uspio.</translation>
    </message>
    <message>
        <source>Export failure</source>
        <translation type="obsolete">Izvoz nije uspio</translation>
    </message>
    <message>
        <source>Filters could not be exported due to an I/O error.</source>
        <translation type="obsolete">Filteri ne mogu biti izvezeni zbog I/O greške.</translation>
    </message>
</context>
<context>
    <name>FeedList</name>
    <message>
        <source>Unread</source>
        <translation type="obsolete">Nepročitano</translation>
    </message>
</context>
<context>
    <name>FeedListWidget</name>
    <message>
        <source>RSS feeds</source>
        <translation>RSS kanali</translation>
    </message>
    <message>
        <source>Unread</source>
        <translation>Nepročitano</translation>
    </message>
</context>
<context>
    <name>GUI</name>
    <message>
        <source>Open Torrent Files</source>
        <translation type="obsolete">Otvori torrent datoteke</translation>
    </message>
    <message>
        <source>&amp;Yes</source>
        <translation type="obsolete">&amp;Da</translation>
    </message>
    <message>
        <source>&amp;No</source>
        <translation type="obsolete">&amp;Ne</translation>
    </message>
    <message>
        <source>Torrent Files</source>
        <translation type="obsolete">Torrent datoteke</translation>
    </message>
    <message>
        <source>qBittorrent %1</source>
        <comment>e.g: qBittorrent v0.x</comment>
        <translation type="obsolete">qBittorrent %1</translation>
    </message>
    <message>
        <source>qBittorrent</source>
        <translation type="obsolete">qBittorrent</translation>
    </message>
    <message>
        <source>qBittorrent %1</source>
        <comment>e.g: qBittorrent vx.x</comment>
        <translation type="obsolete">qBittorrent %1</translation>
    </message>
    <message>
        <source>DL speed: %1 KiB/s</source>
        <comment>e.g: Download speed: 10 KiB/s</comment>
        <translation type="obsolete">Brzina preuzimanja: %1 KiB/s</translation>
    </message>
    <message>
        <source>UP speed: %1 KiB/s</source>
        <comment>e.g: Upload speed: 10 KiB/s</comment>
        <translation type="obsolete">Brzina slanja: %1 KiB/s</translation>
    </message>
    <message>
        <source>Are you sure you want to quit?</source>
        <translation type="obsolete">Jeste li sigurni da želite završiti?</translation>
    </message>
    <message>
        <source>%1 has finished downloading.</source>
        <comment>e.g: xxx.avi has finished downloading.</comment>
        <translation type="obsolete">Datoteka %1 je preuzeta.</translation>
    </message>
    <message>
        <source>I/O Error</source>
        <comment>i.e: Input/Output Error</comment>
        <translation type="obsolete">I/O greška</translation>
    </message>
    <message>
        <source>An error occured (full disk?), &apos;%1&apos; paused.</source>
        <comment>e.g: An error occured (full disk?), &apos;xxx.avi&apos; paused.</comment>
        <translation type="obsolete">Dogodila se greška (pun disk?), &apos;%1&apos; zaustavljeno.</translation>
    </message>
    <message>
        <source>Search</source>
        <translation type="obsolete">Traži</translation>
    </message>
    <message>
        <source>RSS</source>
        <translation type="obsolete">RSS</translation>
    </message>
    <message>
        <source>Alt+1</source>
        <comment>shortcut to switch to first tab</comment>
        <translation type="obsolete">Alt+1</translation>
    </message>
    <message>
        <source>Url download error</source>
        <translation type="obsolete">Greška prilikom preuzimanja</translation>
    </message>
    <message>
        <source>Couldn&apos;t download file at url: %1, reason: %2.</source>
        <translation type="obsolete">Nije moguće preuzeti datoteku sa: %1, razlog: %2.</translation>
    </message>
    <message>
        <source>An I/O error occured for torrent %1.
 Reason: %2</source>
        <comment>e.g: An error occured for torrent xxx.avi.
 Reason: disk is full.</comment>
        <translation type="obsolete">Dogodila se I/O greška za torrent %1
Razlog: %2</translation>
    </message>
    <message>
        <source>Transfers</source>
        <translation type="obsolete">Transferi</translation>
    </message>
    <message>
        <source>Download completion</source>
        <translation type="obsolete">Preuzimanje završeno</translation>
    </message>
    <message>
        <source>Alt+2</source>
        <comment>shortcut to switch to third tab</comment>
        <translation type="obsolete">Alt+2</translation>
    </message>
    <message>
        <source>Ctrl+F</source>
        <comment>shortcut to switch to search tab</comment>
        <translation type="obsolete">Ctrl+F</translation>
    </message>
    <message>
        <source>Alt+3</source>
        <comment>shortcut to switch to fourth tab</comment>
        <translation type="obsolete">Alt+3</translation>
    </message>
    <message>
        <source>Global Upload Speed Limit</source>
        <translation type="obsolete">Globalni limit brzine slanja</translation>
    </message>
    <message>
        <source>Global Download Speed Limit</source>
        <translation type="obsolete">Globalni limit brzine preuzimanja</translation>
    </message>
    <message>
        <source>Some files are currently transferring.
Are you sure you want to quit qBittorrent?</source>
        <translation type="obsolete">Neke datoteke još se prenose.
Jeste li sigurni da želite zatvoriti qBittorrent?</translation>
    </message>
    <message>
        <source>qBittorrent %1 (Down: %2/s, Up: %3/s)</source>
        <comment>%1 is qBittorrent version</comment>
        <translation type="obsolete">qBittorrent %1 (Preuzimanje: %2/s, Slanje: %3/s)</translation>
    </message>
    <message>
        <source>Use normal speed limits</source>
        <translation type="obsolete">Koristi uobičajene limite brzine</translation>
    </message>
    <message>
        <source>Use alternative speed limits</source>
        <translation type="obsolete">Koristi alternativnen limite brzine</translation>
    </message>
    <message>
        <source>Options were saved successfully.</source>
        <translation type="obsolete">Opcije su uspješno spremljene.</translation>
    </message>
    <message>
        <source>Recursive download confirmation</source>
        <translation type="obsolete">Potvrda rekurzivnog preuzimanja</translation>
    </message>
    <message>
        <source>The torrent %1 contains torrent files, do you want to proceed with their download?</source>
        <translation type="obsolete">Torrent %1 sadrži torrent datoteke. Želite li nastaviti s preuzimanjem?</translation>
    </message>
    <message>
        <source>Torrent file association</source>
        <translation type="obsolete">Pridruživanje torrent datoteka</translation>
    </message>
    <message>
        <source>qBittorrent is not the default application to open torrent files or Magnet links.
Do you want to associate qBittorrent to torrent files and Magnet links?</source>
        <translation type="obsolete">qBittorrent nije zadana aplikacija za otvaranje torrent datoteka ili Magnet linkova.
Želite li pridružiti qBittorrent torrent datotekama i Magnet linkovima?</translation>
    </message>
    <message>
        <source>Transfers (%1)</source>
        <translation type="obsolete">Transferi (%1)</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation type="obsolete">Da</translation>
    </message>
    <message>
        <source>No</source>
        <translation type="obsolete">Ne</translation>
    </message>
    <message>
        <source>Never</source>
        <translation type="obsolete">Nikad</translation>
    </message>
    <message>
        <source>Always</source>
        <translation type="obsolete">Uvijek</translation>
    </message>
    <message>
        <source>Exiting qBittorrent</source>
        <translation type="obsolete">Izlaz iz qBittorrenta</translation>
    </message>
    <message>
        <source>Set the password...</source>
        <translation type="obsolete">Postavi lozinku ...</translation>
    </message>
    <message>
        <source>Password update</source>
        <translation type="obsolete">Ažuriranje lozinke</translation>
    </message>
    <message>
        <source>The UI lock password has been successfully updated</source>
        <translation type="obsolete">Lozinka zaključavanja sučelja je uspješno ažurirana</translation>
    </message>
    <message>
        <source>UI lock password</source>
        <translation type="obsolete">Lozinka zaključavanja sučelja</translation>
    </message>
    <message>
        <source>Please type the UI lock password:</source>
        <translation type="obsolete">Upišite  lozinku zaključavanja sučelja:</translation>
    </message>
    <message>
        <source>Invalid password</source>
        <translation type="obsolete">Neispravna lozinka</translation>
    </message>
    <message>
        <source>The password is invalid</source>
        <translation type="obsolete">Lozinka nije ispravna</translation>
    </message>
    <message>
        <source>A newer version is available</source>
        <translation type="obsolete">Dostupna je novija verzija</translation>
    </message>
    <message>
        <source>A newer version of qBittorrent is available on Sourceforge.
Would you like to update qBittorrent to version %1?</source>
        <translation type="obsolete">Na Sourceforge dostupna je novija verzija qBittorrenta.
Želite li ažurirati qBittorrent na verziju %1?</translation>
    </message>
    <message>
        <source>Impossible to update qBittorrent</source>
        <translation type="obsolete">Nije moguće ažurirati qBittorrent</translation>
    </message>
    <message>
        <source>qBittorrent failed to update, reason: %1</source>
        <translation type="obsolete">Ažuriranje qBittorrenta nije uspjelo. Razlog: %1</translation>
    </message>
</context>
<context>
    <name>GeoIP</name>
    <message>
        <source>Australia</source>
        <translation type="obsolete">Australija</translation>
    </message>
    <message>
        <source>Argentina</source>
        <translation type="obsolete">Argentina</translation>
    </message>
    <message>
        <source>Austria</source>
        <translation type="obsolete">Austrija</translation>
    </message>
    <message>
        <source>United Arab Emirates</source>
        <translation type="obsolete">Ujedinjeni Arapski Emirati</translation>
    </message>
    <message>
        <source>Brazil</source>
        <translation type="obsolete">Brazil</translation>
    </message>
    <message>
        <source>Bulgaria</source>
        <translation type="obsolete">Bugarska</translation>
    </message>
    <message>
        <source>Belarus</source>
        <translation type="obsolete">Bjelorusija</translation>
    </message>
    <message>
        <source>Belgium</source>
        <translation type="obsolete">Belgija</translation>
    </message>
    <message>
        <source>Bosnia</source>
        <translation type="obsolete">Bosna i Hercegovina</translation>
    </message>
    <message>
        <source>Canada</source>
        <translation type="obsolete">Kanada</translation>
    </message>
    <message>
        <source>Czech Republic</source>
        <translation type="obsolete">Češka</translation>
    </message>
    <message>
        <source>China</source>
        <translation type="obsolete">Kina</translation>
    </message>
    <message>
        <source>Costa Rica</source>
        <translation type="obsolete">Kostarika</translation>
    </message>
    <message>
        <source>Switzerland</source>
        <translation type="obsolete">Švicarska</translation>
    </message>
    <message>
        <source>Germany</source>
        <translation type="obsolete">Njemačka</translation>
    </message>
    <message>
        <source>Denmark</source>
        <translation type="obsolete">Danska
</translation>
    </message>
    <message>
        <source>Algeria</source>
        <translation type="obsolete">Alžir</translation>
    </message>
    <message>
        <source>Spain</source>
        <translation type="obsolete">Španjolska</translation>
    </message>
    <message>
        <source>Egypt</source>
        <translation type="obsolete">Egipat</translation>
    </message>
    <message>
        <source>Finland</source>
        <translation type="obsolete">Finska</translation>
    </message>
    <message>
        <source>France</source>
        <translation type="obsolete">Francuska</translation>
    </message>
    <message>
        <source>United Kingdom</source>
        <translation type="obsolete">Ujedinjeno Kraljevstvo</translation>
    </message>
    <message>
        <source>Greece</source>
        <translation type="obsolete">Grčka</translation>
    </message>
    <message>
        <source>Georgia</source>
        <translation type="obsolete">Gruzija</translation>
    </message>
    <message>
        <source>Hungary</source>
        <translation type="obsolete">Mađarska</translation>
    </message>
    <message>
        <source>Croatia</source>
        <translation type="obsolete">Hrvatska</translation>
    </message>
    <message>
        <source>Italy</source>
        <translation type="obsolete">Italija</translation>
    </message>
    <message>
        <source>India</source>
        <translation type="obsolete">Indija</translation>
    </message>
    <message>
        <source>Israel</source>
        <translation type="obsolete">Izrael</translation>
    </message>
    <message>
        <source>Ireland</source>
        <translation type="obsolete">Irska</translation>
    </message>
    <message>
        <source>Iceland</source>
        <translation type="obsolete">Island</translation>
    </message>
    <message>
        <source>Indonesia</source>
        <translation type="obsolete">Indonezija</translation>
    </message>
    <message>
        <source>Japan</source>
        <translation type="obsolete">Japan</translation>
    </message>
    <message>
        <source>South Korea</source>
        <translation type="obsolete">Južna Koreja</translation>
    </message>
    <message>
        <source>Luxembourg</source>
        <translation type="obsolete">Luksemburg</translation>
    </message>
    <message>
        <source>Malaysia</source>
        <translation type="obsolete">Malezija</translation>
    </message>
    <message>
        <source>Mexico</source>
        <translation type="obsolete">Meksiko</translation>
    </message>
    <message>
        <source>Serbia</source>
        <translation type="obsolete">Srbija</translation>
    </message>
    <message>
        <source>Morocco</source>
        <translation type="obsolete">Maroko</translation>
    </message>
    <message>
        <source>Netherlands</source>
        <translation type="obsolete">Nizozemska</translation>
    </message>
    <message>
        <source>Norway</source>
        <translation type="obsolete">Norveška</translation>
    </message>
    <message>
        <source>New Zealand</source>
        <translation type="obsolete">Novi Zeland</translation>
    </message>
    <message>
        <source>Portugal</source>
        <translation type="obsolete">Portugal</translation>
    </message>
    <message>
        <source>Poland</source>
        <translation type="obsolete">Poljska</translation>
    </message>
    <message>
        <source>Pakistan</source>
        <translation type="obsolete">Pakistan</translation>
    </message>
    <message>
        <source>Philippines</source>
        <translation type="obsolete">Filipini</translation>
    </message>
    <message>
        <source>Russia</source>
        <translation type="obsolete">Rusija</translation>
    </message>
    <message>
        <source>Romania</source>
        <translation type="obsolete">Rumunjska</translation>
    </message>
    <message>
        <source>France (Reunion Island)</source>
        <translation type="obsolete">Francuska (otok Reunion)</translation>
    </message>
    <message>
        <source>Sweden</source>
        <translation type="obsolete">Švedska</translation>
    </message>
    <message>
        <source>Slovakia</source>
        <translation type="obsolete">Slovačka</translation>
    </message>
    <message>
        <source>Singapore</source>
        <translation type="obsolete">Singapur</translation>
    </message>
    <message>
        <source>Slovenia</source>
        <translation type="obsolete">Slovenija</translation>
    </message>
    <message>
        <source>Taiwan</source>
        <translation type="obsolete">Tajvan</translation>
    </message>
    <message>
        <source>Turkey</source>
        <translation type="obsolete">Turska</translation>
    </message>
    <message>
        <source>Thailand</source>
        <translation type="obsolete">Tajland</translation>
    </message>
    <message>
        <source>USA</source>
        <translation type="obsolete">SAD</translation>
    </message>
    <message>
        <source>Ukraine</source>
        <translation type="obsolete">Ukrajina</translation>
    </message>
    <message>
        <source>South Africa</source>
        <translation type="obsolete">Južna Afrika</translation>
    </message>
    <message>
        <source>Saudi Arabia</source>
        <translation type="obsolete">Saudijska Arabija</translation>
    </message>
</context>
<context>
    <name>HeadlessLoader</name>
    <message>
        <source>Information</source>
        <translation>Informacija</translation>
    </message>
    <message>
        <source>To control qBittorrent, access the Web UI at http://localhost:%1</source>
        <translation>kako bi kontrolirali qBittorrent, pristupite web sučelju na http://localhost:%1</translation>
    </message>
    <message>
        <source>The Web UI administrator user name is: %1</source>
        <translation>Administratorsko korisničko ime na web sučelju je: %1</translation>
    </message>
    <message>
        <source>The Web UI administrator password is still the default one: %1</source>
        <translation>Adminstratorska lozinka web sučelja ostaje zadana: %1</translation>
    </message>
    <message>
        <source>This is a security risk, please consider changing your password from program preferences.</source>
        <translation>To je sigurnosni rizik. Uzmite u obzir promjenu lozinke u postavkama programa.</translation>
    </message>
</context>
<context>
    <name>HttpConnection</name>
    <message>
        <source>Your IP address has been banned after too many failed authentication attempts.</source>
        <translation>Vaša IP adresa je zabranjena nakon previše neuspjelih pokušaja ovjere.</translation>
    </message>
    <message>
        <source>D: %1/s - T: %2</source>
        <comment>Download speed: x KiB/s - Transferred: x MiB</comment>
        <translation>Preuzimanje: %1/s - Preuzeto: %2</translation>
    </message>
    <message>
        <source>U: %1/s - T: %2</source>
        <comment>Upload speed: x KiB/s - Transferred: x MiB</comment>
        <translation>Slanje: %1/s - Poslano: %2</translation>
    </message>
</context>
<context>
    <name>HttpServer</name>
    <message>
        <source>File</source>
        <translation>Datoteka</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Uredi</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Pomoć</translation>
    </message>
    <message>
        <source>Delete from HD</source>
        <translation type="obsolete">Izbriši sa čvrstog diska</translation>
    </message>
    <message>
        <source>Download Torrents from their URL or Magnet link</source>
        <translation>Preuzmi torrente s njihovih URL-ova ili Magnet linka</translation>
    </message>
    <message>
        <source>Only one link per line</source>
        <translation>Samo jedan link po liniji</translation>
    </message>
    <message>
        <source>Download local torrent</source>
        <translation>Preuzmi lokalni torent</translation>
    </message>
    <message>
        <source>Torrent files were correctly added to download list.</source>
        <translation>Torrent datoteke su ispravno dodane popisu preuzimanja.</translation>
    </message>
    <message>
        <source>Point to torrent file</source>
        <translation>Istakni torrent datoteku</translation>
    </message>
    <message>
        <source>Download</source>
        <translation>Preuzmi</translation>
    </message>
    <message>
        <source>Are you sure you want to delete the selected torrents from the transfer list and hard disk?</source>
        <translation>Jeste li sigurni da želite izbrisati odabrane torrente s popisa transfera i čvrstog diska?</translation>
    </message>
    <message>
        <source>Download rate limit must be greater than 0 or disabled.</source>
        <translation>Limit brzine preuzimanja mora biti veći od 0 ili onemogućen.</translation>
    </message>
    <message>
        <source>Upload rate limit must be greater than 0 or disabled.</source>
        <translation>Limit brzine slanja mora biti veći od 0 ili onemogućen.</translation>
    </message>
    <message>
        <source>Maximum number of connections limit must be greater than 0 or disabled.</source>
        <translation>Limit najvećeg broja spajanja mora biti veći od 0 ili onemogućen.</translation>
    </message>
    <message>
        <source>Maximum number of connections per torrent limit must be greater than 0 or disabled.</source>
        <translation>Limit najvećeg broja spajanja po torrentu mora biti veći od 0 ili onemogućen.</translation>
    </message>
    <message>
        <source>Maximum number of upload slots per torrent limit must be greater than 0 or disabled.</source>
        <translation>Limit najvećeg broja priključnica po torrentu mora biti veći od 0 ili onemogućen.</translation>
    </message>
    <message>
        <source>Unable to save program preferences, qBittorrent is probably unreachable.</source>
        <translation>Nije moguće spremiti postavke programa. qBittorrent je vjerojatno nedostupan.</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Jezik</translation>
    </message>
    <message>
        <source>Downloaded</source>
        <comment>Is the file downloaded or not?</comment>
        <translation>Preuzeto</translation>
    </message>
    <message>
        <source>The port used for incoming connections must be greater than 1024 and less than 65535.</source>
        <translation>Port korišten za dolazne veze mora biti veći od 1024 i manji od 65535.</translation>
    </message>
    <message>
        <source>The port used for the Web UI must be greater than 1024 and less than 65535.</source>
        <translation>Port korišten za web sučelje mora biti veći od 1024 i manji od 65535.</translation>
    </message>
    <message>
        <source>The Web UI username must be at least 3 characters long.</source>
        <translation>Korisničko ime web sučelja mora imati najmanje 3 znaka.</translation>
    </message>
    <message>
        <source>The Web UI password must be at least 3 characters long.</source>
        <translation>Lozinka web sučelja mora imati najmanje 3 znaka.</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Spremi</translation>
    </message>
    <message>
        <source>qBittorrent client is not reachable</source>
        <translation>qBittorrent klijent nije dostupan</translation>
    </message>
    <message>
        <source>HTTP Server</source>
        <translation>HTTP poslužitelj</translation>
    </message>
    <message>
        <source>Torrent path</source>
        <translation>Putanja torrenta</translation>
    </message>
    <message>
        <source>Torrent name</source>
        <translation>Ime torrenta</translation>
    </message>
    <message>
        <source>The following parameters are supported:</source>
        <translation>Podržani su sljedeći parametri:</translation>
    </message>
</context>
<context>
    <name>LegalNotice</name>
    <message>
        <source>Legal Notice</source>
        <translation>Pravna napomena</translation>
    </message>
    <message>
        <source>qBittorrent is a file sharing program. When you run a torrent, its data will be made available to others by means of upload. Any content you share is your sole responsibility.

No further notices will be issued.</source>
        <translation>qBittorrent je program za dijeljenje datoteka. Kada pokrenete torrent, njegovi podaci bit će rapoloživi drugima. To znači da će drugi moći preuzimati datoteke i s vašeg računala. Za bilo koji sadržaj koji dijelite isključivo ste vi odgovorni.

Neće biti daljnjih napomena.</translation>
    </message>
    <message>
        <source>Press %1 key to accept and continue...</source>
        <translation>Pritisnite %1 tipku za prihvaćanje i nastavak ...</translation>
    </message>
    <message>
        <source>Legal notice</source>
        <translation>Napomena</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Odustani</translation>
    </message>
    <message>
        <source>I Agree</source>
        <translation>Slažem se</translation>
    </message>
</context>
<context>
    <name>LineEdit</name>
    <message>
        <source>Clear the text</source>
        <translation>Izbriši tekst</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>&amp;Edit</source>
        <translation>Ur&amp;edi</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Datoteka</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Pomoć</translation>
    </message>
    <message>
        <source>Exit</source>
        <translation>Izlaz</translation>
    </message>
    <message>
        <source>Preferences</source>
        <translation type="obsolete">Postavke</translation>
    </message>
    <message>
        <source>About</source>
        <translation type="obsolete">O</translation>
    </message>
    <message>
        <source>Start</source>
        <translation type="obsolete">Kreni</translation>
    </message>
    <message>
        <source>Pause</source>
        <translation type="obsolete">Stani</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="obsolete">Izbriši</translation>
    </message>
    <message>
        <source>Pause All</source>
        <translation type="obsolete">Zaustavi sve</translation>
    </message>
    <message>
        <source>Start All</source>
        <translation type="obsolete">Počni sve</translation>
    </message>
    <message>
        <source>Visit Website</source>
        <translation type="obsolete">Posjeti web mjesto</translation>
    </message>
    <message>
        <source>Download from URL</source>
        <translation type="obsolete">Preuzmi s URL-a</translation>
    </message>
    <message>
        <source>Create torrent</source>
        <translation type="obsolete">Kreiraj torrent</translation>
    </message>
    <message>
        <source>Preview file</source>
        <translation type="obsolete">Pregledaj datoteku</translation>
    </message>
    <message>
        <source>Clear log</source>
        <translation type="obsolete">Izbriši zapis</translation>
    </message>
    <message>
        <source>Log Window</source>
        <translation type="obsolete">Prozor zapisa</translation>
    </message>
    <message>
        <source>Use alternative speed limits</source>
        <translation type="obsolete">Koristi alternativne limite brzine</translation>
    </message>
    <message>
        <source>Report a bug</source>
        <translation type="obsolete">Prijavi grešku</translation>
    </message>
    <message>
        <source>Set upload limit</source>
        <translation type="obsolete">Podesi limit slanja</translation>
    </message>
    <message>
        <source>Set download limit</source>
        <translation type="obsolete">Podesi limit preuzimanja</translation>
    </message>
    <message>
        <source>Documentation</source>
        <translation type="obsolete">Dokumentacija</translation>
    </message>
    <message>
        <source>Set global download limit</source>
        <translation type="obsolete">Podesi globalni limit preuzimanja</translation>
    </message>
    <message>
        <source>Set global upload limit</source>
        <translation type="obsolete">Podesi globalni limit slanja</translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="obsolete">Mogućnosti</translation>
    </message>
    <message>
        <source>Open torrent</source>
        <translation type="obsolete">Otvori torrent</translation>
    </message>
    <message>
        <source>Decrease priority</source>
        <translation>Smanji prioritet</translation>
    </message>
    <message>
        <source>Increase priority</source>
        <translation>Povećaj prioritet</translation>
    </message>
    <message>
        <source>Console</source>
        <translation type="obsolete">Konzola</translation>
    </message>
    <message>
        <source>&amp;Tools</source>
        <translation>Ala&amp;ti</translation>
    </message>
    <message>
        <source>&amp;View</source>
        <translation>Po&amp;gled</translation>
    </message>
    <message>
        <source>&amp;Add File...</source>
        <translation type="obsolete">Dod&amp;aj datoteku ...</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation type="obsolete">I&amp;zlaz</translation>
    </message>
    <message>
        <source>&amp;Options...</source>
        <translation>&amp;Opcije ...</translation>
    </message>
    <message>
        <source>Add &amp;URL...</source>
        <translation type="obsolete">Dodaj &amp;URL ...</translation>
    </message>
    <message>
        <source>Torrent &amp;creator</source>
        <translation>&amp;Kreator torrenta</translation>
    </message>
    <message>
        <source>Set upload limit...</source>
        <translation>Podesi limit slanja ...</translation>
    </message>
    <message>
        <source>Set download limit...</source>
        <translation>Podesi limit preuzimanja ...</translation>
    </message>
    <message>
        <source>Set global download limit...</source>
        <translation>Podesi globalni limit preuzimanja ...</translation>
    </message>
    <message>
        <source>Set global upload limit...</source>
        <translation>Podesi globalni limit slanja ...</translation>
    </message>
    <message>
        <source>&amp;Log viewer...</source>
        <translation type="obsolete">Preg&amp;lednik zapisa</translation>
    </message>
    <message>
        <source>Top &amp;tool bar</source>
        <translation>Gornja ala&amp;tna traka</translation>
    </message>
    <message>
        <source>Display top tool bar</source>
        <translation>Prikaži gornju alatnu traku</translation>
    </message>
    <message>
        <source>&amp;Speed in title bar</source>
        <translation>Brzina u na&amp;slovnoj traci</translation>
    </message>
    <message>
        <source>Show transfer speed in title bar</source>
        <translation>Pokaži brzinu transfera u naslovnoj traci</translation>
    </message>
    <message>
        <source>Alternative speed limits</source>
        <translation>Alternativni limiti brzine</translation>
    </message>
    <message>
        <source>Search engine</source>
        <translation type="obsolete">Tražilica</translation>
    </message>
    <message>
        <source>&amp;About</source>
        <translation>&amp;O</translation>
    </message>
    <message>
        <source>&amp;Start</source>
        <translation type="obsolete">Za&amp;počni</translation>
    </message>
    <message>
        <source>&amp;Pause</source>
        <translation>&amp;Pauziraj</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>Iz&amp;briši</translation>
    </message>
    <message>
        <source>P&amp;ause All</source>
        <translation>P&amp;auziraj sve</translation>
    </message>
    <message>
        <source>S&amp;tart All</source>
        <translation type="obsolete">Započni &amp;sve</translation>
    </message>
    <message>
        <source>Visit &amp;Website</source>
        <translation>Posjeti &amp;web stranicu</translation>
    </message>
    <message>
        <source>Report a &amp;bug</source>
        <translation>Prijavi g&amp;rešku</translation>
    </message>
    <message>
        <source>&amp;Documentation</source>
        <translation>&amp;Dokumentacija</translation>
    </message>
    <message>
        <source>&amp;RSS reader</source>
        <translation>&amp;RSS čitač</translation>
    </message>
    <message>
        <source>Search &amp;engine</source>
        <translation>&amp;Tražilica</translation>
    </message>
    <message>
        <source>Log viewer</source>
        <translation type="obsolete">Preglednik zapisa</translation>
    </message>
    <message>
        <source>Lock qBittorrent</source>
        <translation>Zaključaj qBittorrent</translation>
    </message>
    <message>
        <source>Ctrl+L</source>
        <translation>Ctrl+L</translation>
    </message>
    <message>
        <source>Shutdown computer when downloads complete</source>
        <translation type="obsolete">Isključi računalo kada preuzimanja završe</translation>
    </message>
    <message>
        <source>&amp;Resume</source>
        <translation>Nastavi</translation>
    </message>
    <message>
        <source>R&amp;esume All</source>
        <translation>Nastavi sve</translation>
    </message>
    <message>
        <source>Shutdown qBittorrent when downloads complete</source>
        <translation type="obsolete">Ugasi qBittorrent kada je preuzimanje gotovo</translation>
    </message>
    <message>
        <source>Import torrent...</source>
        <translation>Uvezi torrent</translation>
    </message>
    <message>
        <source>Donate money</source>
        <translation>Donirajte novac</translation>
    </message>
    <message>
        <source>If you like qBittorrent, please donate!</source>
        <translation>Ako vam se sviđa qBittorrent donirajte!</translation>
    </message>
    <message>
        <source>qBittorrent %1</source>
        <comment>e.g: qBittorrent v0.x</comment>
        <translation>qBittorrent %1</translation>
    </message>
    <message>
        <source>Set the password...</source>
        <translation>Postavi lozinku ...</translation>
    </message>
    <message>
        <source>Transfers</source>
        <translation>Transferi</translation>
    </message>
    <message>
        <source>Torrent file association</source>
        <translation>Pridruživanje torrent datoteka</translation>
    </message>
    <message>
        <source>qBittorrent is not the default application to open torrent files or Magnet links.
Do you want to associate qBittorrent to torrent files and Magnet links?</source>
        <translation>qBittorrent nije zadana aplikacija za otvaranje torrent datoteka ili Magnet linkova.
Želite li pridružiti qBittorrent torrent datotekama i Magnet linkovima?</translation>
    </message>
    <message>
        <source>UI lock password</source>
        <translation>Lozinka zaključavanja sučelja</translation>
    </message>
    <message>
        <source>Please type the UI lock password:</source>
        <translation>Upišite  lozinku zaključavanja sučelja:</translation>
    </message>
    <message>
        <source>Password update</source>
        <translation>Ažuriranje lozinke</translation>
    </message>
    <message>
        <source>The UI lock password has been successfully updated</source>
        <translation>Lozinka zaključavanja sučelja je uspješno ažurirana</translation>
    </message>
    <message>
        <source>RSS</source>
        <translation>RSS</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Traži</translation>
    </message>
    <message>
        <source>Transfers (%1)</source>
        <translation>Transferi (%1)</translation>
    </message>
    <message>
        <source>Download completion</source>
        <translation>Preuzimanje završeno</translation>
    </message>
    <message>
        <source>%1 has finished downloading.</source>
        <comment>e.g: xxx.avi has finished downloading.</comment>
        <translation>Datoteka %1 je preuzeta.</translation>
    </message>
    <message>
        <source>I/O Error</source>
        <comment>i.e: Input/Output Error</comment>
        <translation>I/O greška</translation>
    </message>
    <message>
        <source>An I/O error occured for torrent %1.
 Reason: %2</source>
        <comment>e.g: An error occured for torrent xxx.avi.
 Reason: disk is full.</comment>
        <translation>Dogodila se I/O greška za torrent %1
Razlog: %2</translation>
    </message>
    <message>
        <source>Alt+1</source>
        <comment>shortcut to switch to first tab</comment>
        <translation>Alt+1</translation>
    </message>
    <message>
        <source>Alt+2</source>
        <comment>shortcut to switch to third tab</comment>
        <translation>Alt+2</translation>
    </message>
    <message>
        <source>Ctrl+F</source>
        <comment>shortcut to switch to search tab</comment>
        <translation>Ctrl+F</translation>
    </message>
    <message>
        <source>Alt+3</source>
        <comment>shortcut to switch to fourth tab</comment>
        <translation>Alt+3</translation>
    </message>
    <message>
        <source>Recursive download confirmation</source>
        <translation>Potvrda rekurzivnog preuzimanja</translation>
    </message>
    <message>
        <source>The torrent %1 contains torrent files, do you want to proceed with their download?</source>
        <translation>Torrent %1 sadrži torrent datoteke. Želite li nastaviti s preuzimanjem?</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Da</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Ne</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Nikad</translation>
    </message>
    <message>
        <source>Url download error</source>
        <translation>Greška prilikom preuzimanja</translation>
    </message>
    <message>
        <source>Couldn&apos;t download file at url: %1, reason: %2.</source>
        <translation>Nije moguće preuzeti datoteku sa: %1, razlog: %2.</translation>
    </message>
    <message>
        <source>Global Upload Speed Limit</source>
        <translation>Globalni limit brzine slanja</translation>
    </message>
    <message>
        <source>Global Download Speed Limit</source>
        <translation>Globalni limit brzine preuzimanja</translation>
    </message>
    <message>
        <source>Invalid password</source>
        <translation>Neispravna lozinka</translation>
    </message>
    <message>
        <source>The password is invalid</source>
        <translation>Lozinka nije ispravna</translation>
    </message>
    <message>
        <source>Exiting qBittorrent</source>
        <translation>Izlaz iz qBittorrenta</translation>
    </message>
    <message>
        <source>Some files are currently transferring.
Are you sure you want to quit qBittorrent?</source>
        <translation>Neke datoteke još se prenose.
Jeste li sigurni da želite zatvoriti qBittorrent?</translation>
    </message>
    <message>
        <source>Always</source>
        <translation>Uvijek</translation>
    </message>
    <message>
        <source>Open Torrent Files</source>
        <translation>Otvori torrent datoteke</translation>
    </message>
    <message>
        <source>Torrent Files</source>
        <translation>Torrent datoteke</translation>
    </message>
    <message>
        <source>Options were saved successfully.</source>
        <translation>Opcije su uspješno spremljene.</translation>
    </message>
    <message>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <source>DL speed: %1 KiB/s</source>
        <comment>e.g: Download speed: 10 KiB/s</comment>
        <translation>Brzina preuzimanja: %1 KiB/s</translation>
    </message>
    <message>
        <source>UP speed: %1 KiB/s</source>
        <comment>e.g: Upload speed: 10 KiB/s</comment>
        <translation>Brzina slanja: %1 KiB/s</translation>
    </message>
    <message>
        <source>qBittorrent %1 (Down: %2/s, Up: %3/s)</source>
        <comment>%1 is qBittorrent version</comment>
        <translation>qBittorrent %1 (Preuzimanje: %2/s, Slanje: %3/s)</translation>
    </message>
    <message>
        <source>A newer version is available</source>
        <translation>Dostupna je novija verzija</translation>
    </message>
    <message>
        <source>A newer version of qBittorrent is available on Sourceforge.
Would you like to update qBittorrent to version %1?</source>
        <translation>Na Sourceforge-u dostupna je novija verzija qBittorrenta.
Želite li ažurirati qBittorrent na verziju %1?</translation>
    </message>
    <message>
        <source>Impossible to update qBittorrent</source>
        <translation>Nije moguće ažurirati qBittorrent</translation>
    </message>
    <message>
        <source>qBittorrent failed to update, reason: %1</source>
        <translation>Ažuriranje qBittorrenta nije uspjelo. Razlog: %1</translation>
    </message>
    <message>
        <source>&amp;Add torrent file...</source>
        <translation>Dod&amp;aj torrent datoteku ...</translation>
    </message>
    <message>
        <source>Add &amp;link to torrent...</source>
        <translation>Dodaj &amp;link torrentu ...</translation>
    </message>
    <message>
        <source>Import existing torrent...</source>
        <translation>Uvezi postojeći torrent ...</translation>
    </message>
    <message>
        <source>Execution &amp;Log</source>
        <translation>Dnevnik izvršavanja</translation>
    </message>
    <message>
        <source>Execution Log</source>
        <translation>Dnevnik izvršavanja</translation>
    </message>
    <message>
        <source>Auto-Shutdown on downloads completion</source>
        <translation>Akcije nakon što preuzimanja završe</translation>
    </message>
    <message>
        <source>Exit qBittorrent</source>
        <translation>Izlaz iz qBittorrenta</translation>
    </message>
    <message>
        <source>Suspend system</source>
        <translation>Suspendiranje računala</translation>
    </message>
    <message>
        <source>Shutdown system</source>
        <translation>Isključivanje računala</translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Onemogućeno</translation>
    </message>
    <message>
        <source>The password should contain at least 3 characters</source>
        <translation>Lozinka mora imati najmanje 3 znaka</translation>
    </message>
</context>
<context>
    <name>PeerAdditionDlg</name>
    <message>
        <source>Invalid IP</source>
        <translation>Neispravan IP</translation>
    </message>
    <message>
        <source>The IP you provided is invalid.</source>
        <translation>IP koji ste pribavili nije ispravan.</translation>
    </message>
</context>
<context>
    <name>PeerListDelegate</name>
    <message>
        <source>/s</source>
        <comment>/second (i.e. per second)</comment>
        <translation>/s</translation>
    </message>
</context>
<context>
    <name>PeerListWidget</name>
    <message>
        <source>IP</source>
        <translation>IP</translation>
    </message>
    <message>
        <source>Client</source>
        <comment>i.e.: Client application</comment>
        <translation>Klijent</translation>
    </message>
    <message>
        <source>Progress</source>
        <comment>i.e: % downloaded</comment>
        <translation>Napredak</translation>
    </message>
    <message>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Brzina preuzimanja</translation>
    </message>
    <message>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Brzina slanja</translation>
    </message>
    <message>
        <source>Downloaded</source>
        <comment>i.e: total data downloaded</comment>
        <translation>Preuzeto</translation>
    </message>
    <message>
        <source>Uploaded</source>
        <comment>i.e: total data uploaded</comment>
        <translation>Poslano</translation>
    </message>
    <message>
        <source>Add a new peer</source>
        <translation type="obsolete">Dodaj novi peer</translation>
    </message>
    <message>
        <source>Limit upload rate</source>
        <translation type="obsolete">Limitiraj brzinu slanja</translation>
    </message>
    <message>
        <source>Limit download rate</source>
        <translation type="obsolete">Limitiraj brzinu slanja</translation>
    </message>
    <message>
        <source>Ban peer permanently</source>
        <translation>Trajno isključi peer</translation>
    </message>
    <message>
        <source>Peer addition</source>
        <translation>Dodavanje peerova</translation>
    </message>
    <message>
        <source>The peer was added to this torrent.</source>
        <translation>Peer je dodan ovom torrentu.</translation>
    </message>
    <message>
        <source>The peer could not be added to this torrent.</source>
        <translation>Peer ne može biti dodan ovom torrentu.</translation>
    </message>
    <message>
        <source>Are you sure? -- qBittorrent</source>
        <translation>Jeste li sigurni? -- qBittorrent</translation>
    </message>
    <message>
        <source>Are you sure you want to ban permanently the selected peers?</source>
        <translation>Jeste li sigurni da želite trajno isključiti odabrane peerove?</translation>
    </message>
    <message>
        <source>&amp;Yes</source>
        <translation>&amp;Da</translation>
    </message>
    <message>
        <source>&amp;No</source>
        <translation>&amp;Ne</translation>
    </message>
    <message>
        <source>Manually banning peer %1...</source>
        <translation>Ručno isključivanje peera %1 ...</translation>
    </message>
    <message>
        <source>Upload rate limiting</source>
        <translation>Limitiranje brzine slanja</translation>
    </message>
    <message>
        <source>Download rate limiting</source>
        <translation>Limitiranje brzine preuzimanja</translation>
    </message>
    <message>
        <source>Add a new peer...</source>
        <translation>Dodaj novi peer ...</translation>
    </message>
    <message>
        <source>Limit download rate...</source>
        <translation>Limitiraj brzinu preuzimanja ...</translation>
    </message>
    <message>
        <source>Limit upload rate...</source>
        <translation>Limitiraj brzinu slanja ...</translation>
    </message>
    <message>
        <source>Copy IP</source>
        <translation>Kopiraj IP</translation>
    </message>
    <message>
        <source>Connection</source>
        <translation>Spajanje</translation>
    </message>
</context>
<context>
    <name>Preferences</name>
    <message>
        <source>Preferences</source>
        <translation type="obsolete">Postavke</translation>
    </message>
    <message>
        <source>UI</source>
        <extracomment>User Interface</extracomment>
        <translation type="obsolete">Korisničko sučelje </translation>
    </message>
    <message>
        <source>Downloads</source>
        <translation>Preuzimanja</translation>
    </message>
    <message>
        <source>Connection</source>
        <translation>Spajanja</translation>
    </message>
    <message>
        <source>Speed</source>
        <translation>Brzina</translation>
    </message>
    <message>
        <source>Bittorrent</source>
        <translation type="obsolete">Bittorrent</translation>
    </message>
    <message>
        <source>Proxy</source>
        <translation type="obsolete">Proxy</translation>
    </message>
    <message>
        <source>IP Filter</source>
        <translation type="obsolete">IP Filter</translation>
    </message>
    <message>
        <source>Web UI</source>
        <translation>Web sučelje</translation>
    </message>
    <message>
        <source>RSS</source>
        <translation type="obsolete">RSS</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Napredno</translation>
    </message>
    <message>
        <source>User interface</source>
        <translation type="obsolete">Korisničko sučelje</translation>
    </message>
    <message>
        <source>Language:</source>
        <translation type="obsolete">Jezik:</translation>
    </message>
    <message>
        <source>(Requires restart)</source>
        <translation>(Zahtjeva ponovno pokretanje)</translation>
    </message>
    <message>
        <source>Visual style:</source>
        <translation type="obsolete">Stil:</translation>
    </message>
    <message>
        <source>Ask for confirmation on exit when download list is not empty</source>
        <translation type="obsolete">Traži potvrdu na izlasku kada popis preuzimanja nije prazan</translation>
    </message>
    <message>
        <source>Display top toolbar</source>
        <translation type="obsolete">Prikaži alatnu traku na vrhu</translation>
    </message>
    <message>
        <source>Disable splash screen</source>
        <translation type="obsolete">Onemogući najavni prozor</translation>
    </message>
    <message>
        <source>Display current speed in title bar</source>
        <translation type="obsolete">Prikaži trenutnu brzinu u naslovnoj traci</translation>
    </message>
    <message>
        <source>Transfer list</source>
        <translation type="obsolete">Popis transfera</translation>
    </message>
    <message>
        <source>Use alternating row colors</source>
        <extracomment>In transfer list, one every two rows will have grey background.</extracomment>
        <translation>Koristi obojene naizmjenične redove</translation>
    </message>
    <message>
        <source>Action on double click:</source>
        <comment>Action executed when doucle-clicking on an item in transfer (download/upload) list</comment>
        <translation type="obsolete">Radnja na dvostruki klik:</translation>
    </message>
    <message>
        <source>Downloading:</source>
        <translation type="obsolete">Preuzimanje:</translation>
    </message>
    <message>
        <source>Start/Stop</source>
        <translation type="obsolete">Kreni/Stani</translation>
    </message>
    <message>
        <source>Open folder</source>
        <translation type="obsolete">Otvori mapu</translation>
    </message>
    <message>
        <source>Completed:</source>
        <translation type="obsolete">Završeno:</translation>
    </message>
    <message>
        <source>System tray icon</source>
        <translation type="obsolete">Ikona na sistemskoj traci</translation>
    </message>
    <message>
        <source>Disable system tray icon</source>
        <translation type="obsolete">Onemogući ikonu na  sistemskoj traci</translation>
    </message>
    <message>
        <source>Close to tray</source>
        <comment>i.e: The systray tray icon will still be visible when closing the main window.</comment>
        <translation type="obsolete">Ikona će biti vidljiva na sistemskoj traci kada se zatvori glavni prozor</translation>
    </message>
    <message>
        <source>Minimize to tray</source>
        <translation type="obsolete">Ikona će biti vidljiva na sistemskoj traci kada se spusti glavni prozor</translation>
    </message>
    <message>
        <source>Start minimized</source>
        <translation type="obsolete">Počni spušteno</translation>
    </message>
    <message>
        <source>Show notification balloons in tray</source>
        <translation type="obsolete">Pokazuj obavijestne balončiće na sistemskoj traci</translation>
    </message>
    <message>
        <source>File system</source>
        <translation type="obsolete">Datotečni sustav</translation>
    </message>
    <message>
        <source>QGroupBox::title {
font-weight: normal;
margin-left: -3px;
}
QGroupBox {
  border-width: 0;
}</source>
        <translation type="obsolete">QGroupBox::title {
font-weight: normal;
margin-left: -3px;
}
QGroupBox {
(sp)(sp)border-width: 0;
}</translation>
    </message>
    <message>
        <source>Destination Folder:</source>
        <translation type="obsolete">Odredišna mapa:</translation>
    </message>
    <message>
        <source>Append the torrent&apos;s label</source>
        <translation type="obsolete">Pridodaj torrentovu oznaku</translation>
    </message>
    <message>
        <source>Use a different folder for incomplete downloads:</source>
        <translation type="obsolete">Koristi drugu mapu za nezavršena preuzimanja:</translation>
    </message>
    <message>
        <source>QLineEdit {
  margin-left: 23px;
}</source>
        <translation type="obsolete">QLineEdit {
  margin-left: 23px;
}</translation>
    </message>
    <message>
        <source>Automatically load .torrent files from:</source>
        <translation type="obsolete">Automatski učitaj .torrent datoteke iz:</translation>
    </message>
    <message>
        <source>Copy .torrent files to:</source>
        <translation>Kopiraj .torrent datoteke u:</translation>
    </message>
    <message>
        <source>Append .!qB extension to incomplete files</source>
        <translation>Pridodaj .!qB proširenje nedovršenim datotekama</translation>
    </message>
    <message>
        <source>Pre-allocate all files</source>
        <translation type="obsolete">Pre-dodijeli svim datotekama</translation>
    </message>
    <message>
        <source>Torrent queueing</source>
        <translation type="obsolete">Red čekanja torrenta</translation>
    </message>
    <message>
        <source>Enable queueing system</source>
        <translation type="obsolete">Omogući sustav reda čekanja</translation>
    </message>
    <message>
        <source>Maximum active downloads:</source>
        <translation>Najviše aktivnih preuzimanja:</translation>
    </message>
    <message>
        <source>Maximum active uploads:</source>
        <translation>Najviše aktivnih slanja:</translation>
    </message>
    <message>
        <source>Maximum active torrents:</source>
        <translation>Najviše aktivnih torrenta:</translation>
    </message>
    <message>
        <source>When adding a torrent</source>
        <translation>Kada dodajete torrent</translation>
    </message>
    <message>
        <source>Display torrent content and some options</source>
        <translation>Prikaži sadržaj torrenta i neke opcije</translation>
    </message>
    <message>
        <source>Do not start download automatically</source>
        <comment>The torrent will be added to download list in pause state</comment>
        <translation type="obsolete">Ne počinji preuzimanje automatski</translation>
    </message>
    <message>
        <source>Listening port</source>
        <translation type="obsolete">Osluškivanje porta</translation>
    </message>
    <message>
        <source>Port used for incoming connections:</source>
        <translation>Port korišten za dolazna spajanja:</translation>
    </message>
    <message>
        <source>Random</source>
        <translation>Nasumično</translation>
    </message>
    <message>
        <source>Enable UPnP port mapping</source>
        <translation type="obsolete">Omogući UPnP mapiranje porta</translation>
    </message>
    <message>
        <source>Enable NAT-PMP port mapping</source>
        <translation type="obsolete">Omogući NAT-PMP mapiranje porta</translation>
    </message>
    <message>
        <source>Connections limit</source>
        <translation type="obsolete">Limit spajanja</translation>
    </message>
    <message>
        <source>Global maximum number of connections:</source>
        <translation>Globalni najveći broj spajanja:</translation>
    </message>
    <message>
        <source>Maximum number of connections per torrent:</source>
        <translation>Najveći broj spajanja po torrentu:</translation>
    </message>
    <message>
        <source>Maximum number of upload slots per torrent:</source>
        <translation>Najveći broj priključnica slanja po torrentu:</translation>
    </message>
    <message>
        <source>Upload:</source>
        <translation>Slanje:</translation>
    </message>
    <message>
        <source>Download:</source>
        <translation>Preuzimanje:</translation>
    </message>
    <message>
        <source>KiB/s</source>
        <translation>KiB/s</translation>
    </message>
    <message>
        <source>Global speed limits</source>
        <translation type="obsolete">Globalni limiti brzine</translation>
    </message>
    <message>
        <source>Alternative global speed limits</source>
        <translation type="obsolete">Alternativni globalni limiti brzine</translation>
    </message>
    <message>
        <source>Scheduled times:</source>
        <translation type="obsolete">Planirano razdoblje:</translation>
    </message>
    <message>
        <source>to</source>
        <extracomment>time1 to time2</extracomment>
        <translation>do</translation>
    </message>
    <message>
        <source>On days:</source>
        <translation type="obsolete">Koje dane:</translation>
    </message>
    <message>
        <source>Every day</source>
        <translation>Svaki dan</translation>
    </message>
    <message>
        <source>Week days</source>
        <translation>Radni dani</translation>
    </message>
    <message>
        <source>Week ends</source>
        <translation>Dani vikenda</translation>
    </message>
    <message>
        <source>Bittorrent features</source>
        <translation type="obsolete">Bittorrent značajke</translation>
    </message>
    <message>
        <source>Enable DHT network (decentralized)</source>
        <translation type="obsolete">Omogući DHT mrežu (decentralizirano)</translation>
    </message>
    <message>
        <source>Use a different port for DHT and Bittorrent</source>
        <translation type="obsolete">Koristi drugi port za DHT i Bittorrent</translation>
    </message>
    <message>
        <source>DHT port:</source>
        <translation>DHT port:</translation>
    </message>
    <message>
        <source>Enable Peer Exchange / PeX (requires restart)</source>
        <translation type="obsolete">Omogući razmjenu peerova/PeX (zahtjeva ponovno pokretanje)</translation>
    </message>
    <message>
        <source>Enable Local Peer Discovery</source>
        <translation type="obsolete">Omogući lokalno otkrivanje peerova</translation>
    </message>
    <message>
        <source>Encryption:</source>
        <translation type="obsolete">Šifriranje:</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation type="obsolete">Omogućeno</translation>
    </message>
    <message>
        <source>Forced</source>
        <translation type="obsolete">Prisilno</translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation type="obsolete">Onemogućeno</translation>
    </message>
    <message>
        <source>KTorrent</source>
        <translation type="obsolete">KTorrent</translation>
    </message>
    <message>
        <source>Reset to latest software version</source>
        <translation type="obsolete">Vrati na posljednju verziju softvera</translation>
    </message>
    <message>
        <source>Share ratio settings</source>
        <translation type="obsolete">Postavke omjera djeljenja</translation>
    </message>
    <message>
        <source>Desired ratio:</source>
        <translation type="obsolete">Željeni omjer:</translation>
    </message>
    <message>
        <source>Remove finished torrents when their ratio reaches:</source>
        <translation type="obsolete">Ukloni završene torrente kada njihov omjer dosegne:</translation>
    </message>
    <message>
        <source>HTTP Communications (trackers, Web seeds, search engine)</source>
        <translation type="obsolete">HTTP komunikacije (trackeri, web seedovi, tražilice)</translation>
    </message>
    <message>
        <source>Host:</source>
        <translation>Host:</translation>
    </message>
    <message>
        <source>Peer Communications</source>
        <translation type="obsolete">Peer komunikacije</translation>
    </message>
    <message>
        <source>SOCKS4</source>
        <translation>SOCKS4</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation>Vrsta:</translation>
    </message>
    <message>
        <source>Client whitelisting workaround</source>
        <translation type="obsolete">Klijent dopušta zaobilaženje</translation>
    </message>
    <message>
        <source>Identify as:</source>
        <translation type="obsolete">Identificiraj kao:</translation>
    </message>
    <message>
        <source>qBittorrent</source>
        <translation type="obsolete">qBittorrent</translation>
    </message>
    <message>
        <source>Vuze</source>
        <translation type="obsolete">Vuze</translation>
    </message>
    <message utf8="true">
        <source>µTorrent</source>
        <translation type="obsolete">µTorrent</translation>
    </message>
    <message>
        <source>Version:</source>
        <translation type="obsolete">Verzija:</translation>
    </message>
    <message>
        <source>Build:</source>
        <extracomment>Software Build nulmber:</extracomment>
        <translation type="obsolete">Izgrađena:</translation>
    </message>
    <message>
        <source>(None)</source>
        <translation>(Nijedno)</translation>
    </message>
    <message>
        <source>HTTP</source>
        <translation>HTTP</translation>
    </message>
    <message>
        <source>Port:</source>
        <translation>Port:</translation>
    </message>
    <message>
        <source>Authentication</source>
        <translation>Ovjera</translation>
    </message>
    <message>
        <source>Username:</source>
        <translation>Korisničko ime:</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation>Lozinka:</translation>
    </message>
    <message>
        <source>SOCKS5</source>
        <translation>SOCKS5</translation>
    </message>
    <message>
        <source>Filter Settings</source>
        <translation type="obsolete">Postavke filtera</translation>
    </message>
    <message>
        <source>Activate IP Filtering</source>
        <translation type="obsolete">Aktiviraj IP filtriranje</translation>
    </message>
    <message>
        <source>Filter path (.dat, .p2p, .p2b):</source>
        <translation>Putanja filtera (.dat, .p2p, .p2b):</translation>
    </message>
    <message>
        <source>Enable Web User Interface</source>
        <translation type="obsolete">Omogući web sučelje</translation>
    </message>
    <message>
        <source>HTTP Server</source>
        <translation type="obsolete">HTTP poslužitelj</translation>
    </message>
    <message>
        <source>Enable RSS support</source>
        <translation type="obsolete">Omogući podršku za RSS </translation>
    </message>
    <message>
        <source>RSS settings</source>
        <translation type="obsolete">RSS postavke</translation>
    </message>
    <message>
        <source>RSS feeds refresh interval:</source>
        <translation type="obsolete">Interval osvježavanja RSS kanala:</translation>
    </message>
    <message>
        <source>minutes</source>
        <translation type="obsolete">minute</translation>
    </message>
    <message>
        <source>Maximum number of articles per feed:</source>
        <translation type="obsolete">Najveći broj članaka po kanalu:</translation>
    </message>
    <message>
        <source>Check Folders for .torrent Files:</source>
        <translation type="obsolete">Provjeri mape za .torrent datoteke:</translation>
    </message>
    <message>
        <source>Add folder ...</source>
        <translation type="obsolete">Dodaj mapu ...</translation>
    </message>
    <message>
        <source>Remove folder</source>
        <translation>Ukloni mapu</translation>
    </message>
    <message>
        <source>No action</source>
        <translation>Nema radnji</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>Opcije</translation>
    </message>
    <message>
        <source>Visual Appearance</source>
        <translation type="obsolete">Izgled</translation>
    </message>
    <message>
        <source>Action on double-click</source>
        <translation>Radnja na dvostruki klik</translation>
    </message>
    <message>
        <source>Downloading torrents:</source>
        <translation>Preuzimanje torrenta:</translation>
    </message>
    <message>
        <source>Start / Stop</source>
        <translation type="obsolete">Započni/Zaustavi</translation>
    </message>
    <message>
        <source>Open destination folder</source>
        <translation>Otvori odredišnu mapu</translation>
    </message>
    <message>
        <source>Completed torrents:</source>
        <translation>Završeni torrenti:</translation>
    </message>
    <message>
        <source>Desktop</source>
        <translation>Radna površina</translation>
    </message>
    <message>
        <source>Show splash screen on start up</source>
        <translation>Prikaži najavni ekran kod pokretanja</translation>
    </message>
    <message>
        <source>Start qBittorrent minimized</source>
        <translation>Pokreni qBittorrent minimiziranog</translation>
    </message>
    <message>
        <source>Show qBittorrent icon in notification area</source>
        <translation type="obsolete">Prikaži ikonu qBittorrenta u prostoru obavijesti</translation>
    </message>
    <message>
        <source>Minimize qBittorrent to notification area</source>
        <translation>Minimiziraj qBittorrent u prostor obavijesti</translation>
    </message>
    <message>
        <source>Close qBittorrent to notification area</source>
        <comment>i.e: The systray tray icon will still be visible when closing the main window.</comment>
        <translation>Zatvori qBittorrent u prostor obavijesti</translation>
    </message>
    <message>
        <source>Do not start the download automatically</source>
        <comment>The torrent will be added to download list in pause state</comment>
        <translation>Ne započinji preuzimanje automatski</translation>
    </message>
    <message>
        <source>Save files to location:</source>
        <translation>Spremi datoteke ovdje:</translation>
    </message>
    <message>
        <source>Append the label of the torrent to the save path</source>
        <translation>Pridodaj oznaku torrenta u putanju spremanja</translation>
    </message>
    <message>
        <source>Pre-allocate disk space for all files</source>
        <translation>Pridodijeli prostor na disku svim datotekama</translation>
    </message>
    <message>
        <source>Keep incomplete torrents in:</source>
        <translation>Drži nedovršene torrente u:</translation>
    </message>
    <message>
        <source>Append .!qB extension to incomplete files&apos; names</source>
        <translation type="obsolete">Pridodaj .!qB proširenje imenima nedovršenih datoteka</translation>
    </message>
    <message>
        <source>Automatically add torrents from:</source>
        <translation>Automatski dodaj torrente iz:</translation>
    </message>
    <message>
        <source>Add folder...</source>
        <translation>Dodaj mapu ...</translation>
    </message>
    <message>
        <source>IP Filtering</source>
        <translation>IP filtriranje</translation>
    </message>
    <message>
        <source>Schedule the use of alternative speed limits</source>
        <translation type="obsolete">Planiraj korištenje alternativnih limita brzine</translation>
    </message>
    <message>
        <source>from</source>
        <extracomment>from (time1 to time2)</extracomment>
        <translation>iz</translation>
    </message>
    <message>
        <source>When:</source>
        <translation>Kada:</translation>
    </message>
    <message>
        <source>Look for peers on your local network</source>
        <translation>Potraži peerove u vašoj lokalnoj mreži</translation>
    </message>
    <message>
        <source>Protocol encryption:</source>
        <translation type="obsolete">Protokol kriptiranja:</translation>
    </message>
    <message>
        <source>Enable Web User Interface (Remote control)</source>
        <translation>Omogući web korisničko sučelje (Udaljeno upravljanje)</translation>
    </message>
    <message>
        <source>Share ratio limiting</source>
        <translation type="obsolete">Limitiranje omjera djeljenja</translation>
    </message>
    <message>
        <source>Seed torrents until their ratio reaches</source>
        <translation>Seedaj torrente dok njihov omjer ne dosegne</translation>
    </message>
    <message>
        <source>then</source>
        <translation>tada</translation>
    </message>
    <message>
        <source>Pause them</source>
        <translation>Pauziraji ih</translation>
    </message>
    <message>
        <source>Remove them</source>
        <translation>Ukloni ih</translation>
    </message>
    <message utf8="true">
        <source>Exchange peers with compatible Bittorrent clients (µTorrent, Vuze, ...)</source>
        <translation>Razmjeni peerove s kompatibilnim Bittorrent klijentima (µTorrent, Vuze, ...)</translation>
    </message>
    <message>
        <source>Email notification upon download completion</source>
        <translation>Obavijesti e-poštom prilikom završetka preuzimanja</translation>
    </message>
    <message>
        <source>Destination email:</source>
        <translation>Odredišna adresa e-pošte:</translation>
    </message>
    <message>
        <source>SMTP server:</source>
        <translation>SMPT poslužitelj:</translation>
    </message>
    <message>
        <source>Run an external program on torrent completion</source>
        <translation>Pokreni eksterni program kod završavanja torrenta</translation>
    </message>
    <message>
        <source>Use %f to pass the torrent path in parameters</source>
        <translation type="obsolete">Koristi %f kako bi se prošlo putanjom torrenta u parametrima</translation>
    </message>
    <message>
        <source>Proxy server</source>
        <translation type="obsolete">Proxy poslužitelj</translation>
    </message>
    <message>
        <source>BitTorrent</source>
        <translation>Bittorrent</translation>
    </message>
    <message>
        <source>Start / Stop Torrent</source>
        <translation>Započni / Zaustavi torrent</translation>
    </message>
    <message>
        <source>Use UPnP / NAT-PMP port forwarding from my router</source>
        <translation>Koristi UPnP / NAT-PMP port prosljeđivanje  s mojeg routera</translation>
    </message>
    <message>
        <source>Privacy</source>
        <translation>Privatnost</translation>
    </message>
    <message>
        <source>Enable DHT (decentralized network) to find more peers</source>
        <translation>Omogući DHT (decentralizirana mreža) kako bi se našlo još peerova</translation>
    </message>
    <message>
        <source>Use a different port for DHT and BitTorrent</source>
        <translation>Koristi drugi port za DHT i Bittorrent</translation>
    </message>
    <message>
        <source>Enable Peer Exchange (PeX) to find more peers</source>
        <translation>Omogući razmjenu peerova (PeX) kako bi se našlo još peerova</translation>
    </message>
    <message>
        <source>Enable Local Peer Discovery to find more peers</source>
        <translation>Omogući lokalno otkrivanje peerova</translation>
    </message>
    <message>
        <source>Encryption mode:</source>
        <translation>Način kriptiranja:</translation>
    </message>
    <message>
        <source>Prefer encryption</source>
        <translation>Preferiraj kriptiranje</translation>
    </message>
    <message>
        <source>Require encryption</source>
        <translation>Zahtjevaj kriptiranje</translation>
    </message>
    <message>
        <source>Disable encryption</source>
        <translation>Onemogući kriptiranje</translation>
    </message>
    <message>
        <source>User Interface</source>
        <translation type="obsolete">Korisničko sučelje</translation>
    </message>
    <message>
        <source>Reload the filter</source>
        <translation>Ponovno učitaj filter</translation>
    </message>
    <message>
        <source>Behavior</source>
        <translation>Ponašanje</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Jezik</translation>
    </message>
    <message>
        <source>Power Management</source>
        <translation>Upravljanje energijom</translation>
    </message>
    <message>
        <source>Inhibit system sleep when torrents are active</source>
        <translation>Spriječi stanje mirovanja kada su torrenti aktivni</translation>
    </message>
    <message>
        <source>Bypass authentication for localhost</source>
        <translation>Zaobiđi autentifikaciju za localhosta</translation>
    </message>
    <message>
        <source>Ask for program exit confirmation</source>
        <translation>Traži potvrdu za zatvaranje programa</translation>
    </message>
    <message>
        <source>Use monochrome system tray icon (requires restart)</source>
        <translation type="obsolete">Koristi jednobojnu ikonu u prostor obavijesti (potrebno ponovno pokretanje)</translation>
    </message>
    <message>
        <source>The following parameters are supported:
&lt;ul&gt;
&lt;li&gt;%f: Torrent path&lt;/li&gt;
&lt;li&gt;%n: Torrent name&lt;/li&gt;
&lt;/ul&gt;</source>
        <translation>Podržani su sljedeći parametri:
&lt;ul&gt;
&lt;li&gt;%f: Putanja torrenta&lt;/li&gt;
&lt;li&gt;%n: Ime torrenta&lt;/li&gt;
&lt;/ul&gt;</translation>
    </message>
    <message>
        <source>Tray icon style:</source>
        <translation>Stil ikone na sistemskoj traci:</translation>
    </message>
    <message>
        <source>Normal</source>
        <translation>Uobičajeno</translation>
    </message>
    <message>
        <source>Monochrome (Dark theme)</source>
        <translation>Monochrome (Tamna tema)</translation>
    </message>
    <message>
        <source>Monochrome (Light theme)</source>
        <translation>Monochrome (Svijetla tema)</translation>
    </message>
    <message>
        <source>This server requires a secure connection (SSL)</source>
        <translation>Ovaj poslužitelj zahtijeva sigurnu vezu (SSL)</translation>
    </message>
    <message>
        <source>User Interface Language:</source>
        <translation>Jezik korisničkog sučelja:</translation>
    </message>
    <message>
        <source>Transfer List</source>
        <translation>Popis transfera</translation>
    </message>
    <message>
        <source>Show qBittorrent in notification area</source>
        <translation>Prikaži ikonu qBittorrenta u prostoru obavijesti</translation>
    </message>
    <message>
        <source>Hard Disk</source>
        <translation>Tvrdi disk</translation>
    </message>
    <message>
        <source>Listening Port</source>
        <translation>Osluškivanje porta</translation>
    </message>
    <message>
        <source>Connections Limits</source>
        <translation>Limiti spajanja</translation>
    </message>
    <message>
        <source>Proxy Server</source>
        <translation>Proxy poslužitelj</translation>
    </message>
    <message>
        <source>Torrent Queueing</source>
        <translation>Red čekanja torrenta</translation>
    </message>
    <message>
        <source>Share Ratio Limiting</source>
        <translation>Limitiranje omjera djeljenja</translation>
    </message>
    <message>
        <source>Use UPnP / NAT-PMP to forward the port from my router</source>
        <translation>Koristi UPnP / NAT-PMP za prosljeđivanje porta s mojeg routera</translation>
    </message>
    <message>
        <source>Update my dynamic domain name</source>
        <translation>Ažuriraj moje dinamičko ime domene</translation>
    </message>
    <message>
        <source>Service:</source>
        <translation>Servis:</translation>
    </message>
    <message>
        <source>Register</source>
        <translation>Registar</translation>
    </message>
    <message>
        <source>Domain name:</source>
        <translation>Ime domene:</translation>
    </message>
    <message>
        <source>Global Rate Limits</source>
        <translation>Globalni limiti brzine</translation>
    </message>
    <message>
        <source>Apply rate limit to uTP connections</source>
        <translation>Primijeni limit brzine za uTP spajanja</translation>
    </message>
    <message>
        <source>Apply rate limit to transport overhead</source>
        <translation>Primijeni limit brzine za dodatni promet</translation>
    </message>
    <message>
        <source>Alternative Global Rate Limits</source>
        <translation>Alternativni globalni limiti brzine</translation>
    </message>
    <message>
        <source>Schedule the use of alternative rate limits</source>
        <translation>Planiraj korištenje alternativnih limita brzine</translation>
    </message>
    <message>
        <source>Enable bandwidth management (uTP)</source>
        <translation>Omogući upravljanje propusnošću (uTP)</translation>
    </message>
    <message>
        <source>Otherwise, the proxy server is only used for tracker connections</source>
        <translation>U drugom slučaju, proxy poslužitelj bit će korišten za spajanja trackera</translation>
    </message>
    <message>
        <source>Use proxy for peer connections</source>
        <translation>Koristi proxy za spajanja peerova</translation>
    </message>
    <message>
        <source>Use HTTPS instead of HTTP</source>
        <translation>Koristi HTTPS umjesto HTTP-a</translation>
    </message>
    <message>
        <source>Import SSL Certificate</source>
        <translation>Uvezi SSL certifikat</translation>
    </message>
    <message>
        <source>Import SSL Key</source>
        <translation>Uvezi SSl ključ</translation>
    </message>
    <message>
        <source>Certificate:</source>
        <translation>Certifikat:</translation>
    </message>
    <message>
        <source>Key:</source>
        <translation>Ključ:</translation>
    </message>
    <message>
        <source>&lt;a href=http://httpd.apache.org/docs/2.1/ssl/ssl_faq.html#aboutcerts&gt;Information about certificates&lt;/a&gt;</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>PreviewSelect</name>
    <message>
        <source>Name</source>
        <translation>Ime</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Veličina</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation>Napredak</translation>
    </message>
    <message>
        <source>Preview impossible</source>
        <translation>Pregled nije moguć</translation>
    </message>
    <message>
        <source>Sorry, we can&apos;t preview this file</source>
        <translation>Oprostite, nije moguće pregledati datoteku</translation>
    </message>
</context>
<context>
    <name>ProgramUpdater</name>
    <message>
        <source>Could not create the file %1</source>
        <translation type="obsolete">Nije moguće kreiratidatoteku %1</translation>
    </message>
    <message>
        <source>Failed to download the update at %1</source>
        <comment>%1 is an URL</comment>
        <translation type="obsolete">Neuspješno preuzimanje ažuriranja s %1</translation>
    </message>
</context>
<context>
    <name>PropListDelegate</name>
    <message>
        <source>Not downloaded</source>
        <translation>Nije preuzeto</translation>
    </message>
    <message>
        <source>Normal</source>
        <comment>Normal (priority)</comment>
        <translation>Uobičajen</translation>
    </message>
    <message>
        <source>High</source>
        <comment>High (priority)</comment>
        <translation>Visok</translation>
    </message>
    <message>
        <source>Maximum</source>
        <comment>Maximum (priority)</comment>
        <translation>Najviši</translation>
    </message>
    <message>
        <source>Mixed</source>
        <comment>Mixed (priorities</comment>
        <translation>Miješani</translation>
    </message>
</context>
<context>
    <name>PropTabBar</name>
    <message>
        <source>General</source>
        <translation>Općenito</translation>
    </message>
    <message>
        <source>Trackers</source>
        <translation>Trackeri</translation>
    </message>
    <message>
        <source>Peers</source>
        <translation>Peerovi</translation>
    </message>
    <message>
        <source>URL Seeds</source>
        <translation type="obsolete">URL seedovi</translation>
    </message>
    <message>
        <source>Files</source>
        <translation type="obsolete">Datoteke</translation>
    </message>
    <message>
        <source>HTTP Sources</source>
        <translation>HTTP izvori</translation>
    </message>
    <message>
        <source>Content</source>
        <translation>Sadržaj</translation>
    </message>
</context>
<context>
    <name>PropertiesWidget</name>
    <message>
        <source>Save path:</source>
        <translation>Putanja za spremanje:</translation>
    </message>
    <message>
        <source>Torrent hash:</source>
        <translation>Torrent smjesa:</translation>
    </message>
    <message>
        <source>Share ratio:</source>
        <translation>Omjer dijeljenja:</translation>
    </message>
    <message>
        <source>Downloaded:</source>
        <translation>Preuzeto:</translation>
    </message>
    <message>
        <source>Availability:</source>
        <translation>Dostupnost:</translation>
    </message>
    <message>
        <source>Transfer</source>
        <translation>Transfer</translation>
    </message>
    <message>
        <source>Uploaded:</source>
        <translation>Poslano:</translation>
    </message>
    <message>
        <source>Wasted:</source>
        <translation>Izgubljeno:</translation>
    </message>
    <message>
        <source>UP limit:</source>
        <translation>Limit slanja:</translation>
    </message>
    <message>
        <source>DL limit:</source>
        <translation>Limit preuzimanja:</translation>
    </message>
    <message>
        <source>Time elapsed:</source>
        <translation type="obsolete">Isteklo vremena:</translation>
    </message>
    <message>
        <source>Connections:</source>
        <translation>Spajanja:</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Informacija</translation>
    </message>
    <message>
        <source>Created on:</source>
        <translation>Kreirano:</translation>
    </message>
    <message>
        <source>Comment:</source>
        <translation>Komentar:</translation>
    </message>
    <message>
        <source>Collapse all</source>
        <translation type="obsolete">Sklopi sve</translation>
    </message>
    <message>
        <source>Expand all</source>
        <translation type="obsolete">Proširi sve</translation>
    </message>
    <message>
        <source>General</source>
        <translation type="obsolete">Općenito</translation>
    </message>
    <message>
        <source>Trackers</source>
        <translation type="obsolete">Trackeri</translation>
    </message>
    <message>
        <source>Peers</source>
        <translation type="obsolete">Peerovi</translation>
    </message>
    <message>
        <source>URL seeds</source>
        <translation type="obsolete">URL seedovi</translation>
    </message>
    <message>
        <source>Files</source>
        <translation type="obsolete">Datoteke</translation>
    </message>
    <message>
        <source>Normal</source>
        <translation>Uobičajen</translation>
    </message>
    <message>
        <source>High</source>
        <translation>Visok</translation>
    </message>
    <message>
        <source>Maximum</source>
        <translation>Najviši</translation>
    </message>
    <message>
        <source>this session</source>
        <translation>ova sesija</translation>
    </message>
    <message>
        <source>/s</source>
        <comment>/second (i.e. per second)</comment>
        <translation>/s</translation>
    </message>
    <message>
        <source>Seeded for %1</source>
        <comment>e.g. Seeded for 3m10s</comment>
        <translation>Seedano za %1</translation>
    </message>
    <message>
        <source>%1 max</source>
        <comment>e.g. 10 max</comment>
        <translation>%1 najviše</translation>
    </message>
    <message>
        <source>I/O Error</source>
        <translation>I/O greška</translation>
    </message>
    <message>
        <source>This file does not exist yet.</source>
        <translation>Ta datoteka još ne postoji.</translation>
    </message>
    <message>
        <source>This folder does not exist yet.</source>
        <translation>Ta mapa još ne postoji.</translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation>Preimenuj ...</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Prioritet</translation>
    </message>
    <message>
        <source>Rename the file</source>
        <translation>Preimenuj ovu datoteku</translation>
    </message>
    <message>
        <source>New name:</source>
        <translation>Novo ime:</translation>
    </message>
    <message>
        <source>The file could not be renamed</source>
        <translation>Datoteka se ne može preimenovati</translation>
    </message>
    <message>
        <source>This file name contains forbidden characters, please choose a different one.</source>
        <translation>Ovo ime datoteke sadrži zabranjene znakove. Izaberite druge.</translation>
    </message>
    <message>
        <source>This name is already in use in this folder. Please use a different name.</source>
        <translation>Ovo ime već se koristi u toj mapi. Koristite drugo.</translation>
    </message>
    <message>
        <source>The folder could not be renamed</source>
        <translation>Mapa se ne može preimenovati</translation>
    </message>
    <message>
        <source>New url seed</source>
        <comment>New HTTP source</comment>
        <translation>Novi URL seed</translation>
    </message>
    <message>
        <source>New url seed:</source>
        <translation>Novi URL seed:</translation>
    </message>
    <message>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <source>This url seed is already in the list.</source>
        <translation>Taj URL seed je već na listi.</translation>
    </message>
    <message>
        <source>Choose save path</source>
        <translation>Izaberite putanju za spremanje</translation>
    </message>
    <message>
        <source>Save path creation error</source>
        <translation type="obsolete">Greška prilikom kreiranja  putanje za spremanje</translation>
    </message>
    <message>
        <source>Could not create the save path</source>
        <translation type="obsolete">Nije moguće kreirati putanju za spremanje</translation>
    </message>
    <message>
        <source>Reannounce in:</source>
        <translation>Ponovno objavi u:</translation>
    </message>
    <message>
        <source>Force reannounce</source>
        <translation type="obsolete">Prisili ponovno objavljivanje</translation>
    </message>
    <message>
        <source>Not downloaded</source>
        <translation type="obsolete">Nije preuzeto</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Odaberi sve</translation>
    </message>
    <message>
        <source>Select None</source>
        <translation>Ne odaberi ništa</translation>
    </message>
    <message>
        <source>Do not download</source>
        <translation>Ne preuzimaj</translation>
    </message>
    <message>
        <source>Pieces size:</source>
        <translation>Veličina djelića:</translation>
    </message>
    <message>
        <source>Time active:</source>
        <extracomment>Time (duration) the torrent is active (not paused)</extracomment>
        <translation>Aktivno:</translation>
    </message>
    <message>
        <source>Torrent content:</source>
        <translation>Sadržaj torrenta:</translation>
    </message>
</context>
<context>
    <name>QBtSession</name>
    <message>
        <source>%1 reached the maximum ratio you set.</source>
        <translation>%1 dostigao je najveći zadani omjer.</translation>
    </message>
    <message>
        <source>Removing torrent %1...</source>
        <translation>Uklanjanje torrenta %1 ...</translation>
    </message>
    <message>
        <source>Pausing torrent %1...</source>
        <translation>Pauziranje torrenta %1 ...</translation>
    </message>
    <message>
        <source>qBittorrent is bound to port: TCP/%1</source>
        <comment>e.g: qBittorrent is bound to port: 6881</comment>
        <translation>qBittorrent je povezan s portom: TCP/%1</translation>
    </message>
    <message>
        <source>UPnP support [ON]</source>
        <translation type="obsolete">Podrška za UPnP [UKLJUČENO]</translation>
    </message>
    <message>
        <source>UPnP support [OFF]</source>
        <translation type="obsolete">Podrška za UPnP [ISKLJUČENO]</translation>
    </message>
    <message>
        <source>NAT-PMP support [ON]</source>
        <translation type="obsolete">Podrška za NAT-PMP [UKLJUČENO]</translation>
    </message>
    <message>
        <source>NAT-PMP support [OFF]</source>
        <translation type="obsolete">Podrška za NAT-PMP [ISKLJUČENO]</translation>
    </message>
    <message>
        <source>HTTP user agent is %1</source>
        <translation>Agent HTTP korisnika je %1</translation>
    </message>
    <message>
        <source>Using a disk cache size of %1 MiB</source>
        <translation type="obsolete">Korištenje privremene memorije diska od %1 MiB</translation>
    </message>
    <message>
        <source>DHT support [ON], port: UDP/%1</source>
        <translation>Podrška za DHT [UKLJUČENO], port: UDP/%1</translation>
    </message>
    <message>
        <source>DHT support [OFF]</source>
        <translation>Podrška za DHT [ISKLJUČENO]</translation>
    </message>
    <message>
        <source>PeX support [ON]</source>
        <translation>Podrška za PeX [UKLJUČENO]</translation>
    </message>
    <message>
        <source>PeX support [OFF]</source>
        <translation>Podrška za PeX [ISKLJUČENO]</translation>
    </message>
    <message>
        <source>Restart is required to toggle PeX support</source>
        <translation>Potrebno je ponovno pokretanje za uključivanje/isključivanje podrške za PeX</translation>
    </message>
    <message>
        <source>Local Peer Discovery [ON]</source>
        <translation type="obsolete">Otkrivanje lokalnih peerova [UKLJUČENO]</translation>
    </message>
    <message>
        <source>Local Peer Discovery support [OFF]</source>
        <translation>Podrška za otkrivanje lokalnih peerova [ISKLJUČENO]</translation>
    </message>
    <message>
        <source>Encryption support [ON]</source>
        <translation>Podrška za kriptiranje [UKLJUČENO]</translation>
    </message>
    <message>
        <source>Encryption support [FORCED]</source>
        <translation>Podrška za kriptiranje [PRISILNO]</translation>
    </message>
    <message>
        <source>Encryption support [OFF]</source>
        <translation>Podrška za kriptiranje [ISKLJUČENO]</translation>
    </message>
    <message>
        <source>Embedded Tracker [ON]</source>
        <translation>Ugrađeni tracker [UKLJUČENO]</translation>
    </message>
    <message>
        <source>Failed to start the embedded tracker!</source>
        <translation>Nije moguće pokrenuti ugrađeni tracker!</translation>
    </message>
    <message>
        <source>Embedded Tracker [OFF]</source>
        <translation>Ugrađeni tracker [ISKLJUČENO]</translation>
    </message>
    <message>
        <source>The Web UI is listening on port %1</source>
        <translation>Web sučelje osluškuje na portu %1</translation>
    </message>
    <message>
        <source>Web User Interface Error - Unable to bind Web UI to port %1</source>
        <translation>Greška web korisničkog sučelja - Nije moguće povezati web korisničko sučelje s portom %1</translation>
    </message>
    <message>
        <source>&apos;%1&apos; was removed from transfer list and hard disk.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>&apos;%1&apos; je uklonjena s popisa transfera i čvrstog diska.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; was removed from transfer list.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>&apos;%1&apos; je uklonjena s popisa transfera.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is not a valid magnet URI.</source>
        <translation>&apos;%1&apos; nije valjani magnet URI.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is already in download list.</source>
        <comment>e.g: &apos;xxx.avi&apos; is already in download list.</comment>
        <translation>&apos;%1&apos; je već na popisu preuzimanja.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; resumed. (fast resume)</source>
        <comment>&apos;/home/y/xxx.torrent&apos; was resumed. (fast resume)</comment>
        <translation>&apos;%1&apos; počinje iznova. (brzo)</translation>
    </message>
    <message>
        <source>&apos;%1&apos; added to download list.</source>
        <comment>&apos;/home/y/xxx.torrent&apos; was added to download list.</comment>
        <translation>&apos;%1&apos; je dodan popisu preuzimanja.</translation>
    </message>
    <message>
        <source>Unable to decode torrent file: &apos;%1&apos;</source>
        <comment>e.g: Unable to decode torrent file: &apos;/home/y/xxx.torrent&apos;</comment>
        <translation>Nije moguće dekodirati torrent datoteku: &apos;%1&apos;</translation>
    </message>
    <message>
        <source>This file is either corrupted or this isn&apos;t a torrent.</source>
        <translation>Ta datoteka je i dalje neispravna ili nije torrent.</translation>
    </message>
    <message>
        <source>Error: The torrent %1 does not contain any file.</source>
        <translation>Greška: Torrent %1 ne sadrži nikakve datoteke.</translation>
    </message>
    <message>
        <source>Note: new trackers were added to the existing torrent.</source>
        <translation>Opaska: novi trackeri su dodani postojećem torrentu.</translation>
    </message>
    <message>
        <source>Note: new URL seeds were added to the existing torrent.</source>
        <translation>Opaska: novi URL seedovi dodani su postojećem torrentu.</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;was blocked due to your IP filter&lt;/i&gt;</source>
        <comment>x.y.z.w was blocked</comment>
        <translation>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;blokirano s obzirom na IP filter&lt;/i&gt;</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;was banned due to corrupt pieces&lt;/i&gt;</source>
        <comment>x.y.z.w was banned</comment>
        <translation>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;zabranjeno zbog neispravnih dijelova&lt;/i&gt;</translation>
    </message>
    <message>
        <source>Recursive download of file %1 embedded in torrent %2</source>
        <comment>Recursive download of test.torrent embedded in torrent test2</comment>
        <translation>Rekurzivno preuzimanje datoteke %1 ugrađeno u torrent %2</translation>
    </message>
    <message>
        <source>Unable to decode %1 torrent file.</source>
        <translation>Nije moguće dekodirati %1 torrent datoteku.</translation>
    </message>
    <message>
        <source>Torrent name: %1</source>
        <translation>Ime torrenta: %1</translation>
    </message>
    <message>
        <source>Torrent size: %1</source>
        <translation>Veličina torrenta: %1</translation>
    </message>
    <message>
        <source>Save path: %1</source>
        <translation>Putanja spremanja: %1</translation>
    </message>
    <message>
        <source>The torrent was downloaded in %1.</source>
        <comment>The torrent was downloaded in 1 hour and 20 seconds</comment>
        <translation>Torrent je preuzet u %1.</translation>
    </message>
    <message>
        <source>Thank you for using qBittorrent.</source>
        <translation>Hvala vam što ste koristili qBittorrent.</translation>
    </message>
    <message>
        <source>[qBittorrent] %1 has finished downloading</source>
        <translation>[qBittorrent] %1 je preuzet</translation>
    </message>
    <message>
        <source>An I/O error occured, &apos;%1&apos; paused.</source>
        <translation>Dogodila se I/O greška. &apos;%1&apos; pauziran.</translation>
    </message>
    <message>
        <source>Reason: %1</source>
        <translation>Razlog: %1</translation>
    </message>
    <message>
        <source>UPnP/NAT-PMP: Port mapping failure, message: %1</source>
        <translation>UPnP/NAT-PMP: Mapiranje porta nije uspjelo, poruka: %1</translation>
    </message>
    <message>
        <source>UPnP/NAT-PMP: Port mapping successful, message: %1</source>
        <translation>UPnP/NAT-PMP: Mapiranje porta je uspjelo, poruka: %1</translation>
    </message>
    <message>
        <source>File sizes mismatch for torrent %1, pausing it.</source>
        <translation>Veličine datoteka se ne slažu za torrent %1, tako da će biti pauziran.</translation>
    </message>
    <message>
        <source>Fast resume data was rejected for torrent %1, checking again...</source>
        <translation>Brzi ponovni početak je odbijen za torrent %1, ponovna provjera ...</translation>
    </message>
    <message>
        <source>Url seed lookup failed for url: %1, message: %2</source>
        <translation>Traženje URL seeda nije uspjelo za URL: %1, poruka: %2</translation>
    </message>
    <message>
        <source>Downloading &apos;%1&apos;, please wait...</source>
        <comment>e.g: Downloading &apos;xxx.torrent&apos;, please wait...</comment>
        <translation>Preuzimanje &apos;%1&apos;, pričekajte ...</translation>
    </message>
    <message>
        <source>The network interface defined is invalid: %1</source>
        <translation>Definirano mrežno sučelje nije ispravno: %1</translation>
    </message>
    <message>
        <source>Trying any other network interface available instead.</source>
        <translation>Isprobavanje bilo kojeg drugog mrežnog sučelje umjesto raspoloživog.</translation>
    </message>
    <message>
        <source>Listening on IP address %1 on network interface %2...</source>
        <translation>Osluškivanje na IP adresi %1 na mrežnom sučelju %2 ...</translation>
    </message>
    <message>
        <source>Failed to listen on network interface %1</source>
        <translation>Nije uspjelo osluškivanje na mrežnom sučelju %1</translation>
    </message>
    <message>
        <source>UPnP / NAT-PMP support [ON]</source>
        <translation>Podrška za UPnP / NAT-PMP [UKLJUČENA]</translation>
    </message>
    <message>
        <source>UPnP / NAT-PMP support [OFF]</source>
        <translation>Podrška za UPnP / NAT-PMP [ISKLJUČENA]</translation>
    </message>
    <message>
        <source>Local Peer Discovery support [ON]</source>
        <translation>Podrška za lokalno otkrivanje peerova [UKLJUČENA]</translation>
    </message>
    <message>
        <source>Successfuly parsed the provided IP filter: %1 rules were applied.</source>
        <comment>%1 is a number</comment>
        <translation>Uspješno razrješen dani IP filter: Primjenjena su %1 pravila.</translation>
    </message>
    <message>
        <source>Error: Failed to parse the provided IP filter.</source>
        <translation>Greška: Razrješavanje danog IP filtera nije uspjelo.</translation>
    </message>
    <message>
        <source>Reporting IP address %1 to trackers...</source>
        <translation>Prijavljivanje IP adrese trackerima...</translation>
    </message>
    <message>
        <source>The computer will now go to sleep mode unless you cancel within the next 15 seconds...</source>
        <translation>Računalo će sada prijeći u stanje mirovanja osim ako ne otkažete unutar sljedećih 15 sekundi ...</translation>
    </message>
    <message>
        <source>The computer will now be switched off unless you cancel within the next 15 seconds...</source>
        <translation>Računalo će sada biti isključeno osim ako ne otkažete unutar sljedećih 15 sekundi ...</translation>
    </message>
    <message>
        <source>qBittorrent will now exit unless you cancel within the next 15 seconds...</source>
        <translation>qBittorrent će se sada zatvoriti osim ako ne otkažete unutar sljedećih 15 sekundi ...</translation>
    </message>
</context>
<context>
    <name>RSS</name>
    <message>
        <source>Search</source>
        <translation>Traži</translation>
    </message>
    <message>
        <source>New subscription</source>
        <translation>Nova predbilježba</translation>
    </message>
    <message>
        <source>Mark items read</source>
        <translation>Označi stavke kao pročitane</translation>
    </message>
    <message>
        <source>Update all</source>
        <translation>Ažuriraj sve</translation>
    </message>
    <message>
        <source>RSS feeds</source>
        <translation type="obsolete">RSS kanali</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Torrents:&lt;/span&gt; &lt;span style=&quot; font-style:italic;&quot;&gt;(double-click to download)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Torrenti:&lt;/span&gt; &lt;span style=&quot; font-style:italic;&quot;&gt;(dvostruki klik za preuzimanje )&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Article title</source>
        <translation type="obsolete">Naslov članka</translation>
    </message>
    <message>
        <source>Feed URL</source>
        <translation type="obsolete">URL kanala</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Izbriši</translation>
    </message>
    <message>
        <source>Rename</source>
        <translation>Preimenuj</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Ažuriraj</translation>
    </message>
    <message>
        <source>Update all feeds</source>
        <translation>Ažuriraj sve kanale</translation>
    </message>
    <message>
        <source>Download torrent</source>
        <translation>Preuzmi torrent</translation>
    </message>
    <message>
        <source>Open news URL</source>
        <translation>Otvori news URL</translation>
    </message>
    <message>
        <source>Copy feed URL</source>
        <translation>Kopiraj URL kanala</translation>
    </message>
    <message>
        <source>RSS feed downloader</source>
        <translation type="obsolete">Preuzimač RSS kanala</translation>
    </message>
    <message>
        <source>New folder</source>
        <translation type="obsolete">Nova mapa</translation>
    </message>
    <message>
        <source>Refresh RSS streams</source>
        <translation>Osvježi RSS strujanja</translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation>Preimenuj ...</translation>
    </message>
    <message>
        <source>New subscription...</source>
        <translation>Nova predbilježba ...</translation>
    </message>
    <message>
        <source>RSS feed downloader...</source>
        <translation type="obsolete">Preuzimatelj RSS kanala ...</translation>
    </message>
    <message>
        <source>New folder...</source>
        <translation>Nova mapa ...</translation>
    </message>
    <message>
        <source>Manage cookies...</source>
        <translation>Upravljaj kolačićima ...</translation>
    </message>
    <message>
        <source>Settings...</source>
        <translation>Postavke ...</translation>
    </message>
    <message>
        <source>RSS Downloader...</source>
        <translation>RSS preuzimatelj</translation>
    </message>
</context>
<context>
    <name>RSSImp</name>
    <message>
        <source>Please type a rss stream url</source>
        <translation>Utipkajte URL RSS strujanja</translation>
    </message>
    <message>
        <source>Stream URL:</source>
        <translation>URL strujanja:</translation>
    </message>
    <message>
        <source>Are you sure? -- qBittorrent</source>
        <translation>Jeste li sigurni? -- qBittorrent</translation>
    </message>
    <message>
        <source>&amp;Yes</source>
        <translation>&amp;Da</translation>
    </message>
    <message>
        <source>&amp;No</source>
        <translation>&amp;Ne</translation>
    </message>
    <message>
        <source>Please choose a folder name</source>
        <translation>Izaberite ime mape</translation>
    </message>
    <message>
        <source>Folder name:</source>
        <translation>Ime mape:</translation>
    </message>
    <message>
        <source>New folder</source>
        <translation>Nova mapa</translation>
    </message>
    <message>
        <source>Overwrite attempt</source>
        <translation>Pokušaj pisanja preko</translation>
    </message>
    <message>
        <source>You cannot overwrite %1 item.</source>
        <comment>You cannot overwrite myFolder item.</comment>
        <translation>Ne možete pisti preko %1 stavke.</translation>
    </message>
    <message>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <source>This rss feed is already in the list.</source>
        <translation>Taj RSS kanal je već na popisu.</translation>
    </message>
    <message>
        <source>Are you sure you want to delete these elements from the list?</source>
        <translation>Jeste li sigurni da želite izbrisati te elemente s popisa?</translation>
    </message>
    <message>
        <source>Are you sure you want to delete this element from the list?</source>
        <translation>Jeste li sigurni da želite izbrisati taj element s popisa?</translation>
    </message>
    <message>
        <source>Please choose a new name for this RSS feed</source>
        <translation>Izaberite novo ime za taj RSS kanal</translation>
    </message>
    <message>
        <source>New feed name:</source>
        <translation>Novo ime kanala:</translation>
    </message>
    <message>
        <source>Name already in use</source>
        <translation>Ime se već koristi</translation>
    </message>
    <message>
        <source>This name is already used by another item, please choose another one.</source>
        <translation>To ime već koristi neka druga stavka. Izaberite drugo.</translation>
    </message>
    <message>
        <source>Date: </source>
        <translation>Datum: </translation>
    </message>
    <message>
        <source>Author: </source>
        <translation>Autor:</translation>
    </message>
    <message>
        <source>Unread</source>
        <translation>Nepročitano</translation>
    </message>
</context>
<context>
    <name>RssArticle</name>
    <message>
        <source>No description available</source>
        <translation type="obsolete">Opis nije dostupan</translation>
    </message>
</context>
<context>
    <name>RssFeed</name>
    <message>
        <source>Automatically downloading %1 torrent from %2 RSS feed...</source>
        <translation>Automatsko preuzimanje %1 torrenta sa %2 RSS kanala ...</translation>
    </message>
</context>
<context>
    <name>RssItem</name>
    <message>
        <source>No description available</source>
        <translation type="obsolete">Opis nije dostupan</translation>
    </message>
</context>
<context>
    <name>RssSettings</name>
    <message>
        <source>RSS Reader Settings</source>
        <translation type="obsolete">Postavke RSS čitača</translation>
    </message>
    <message>
        <source>RSS feeds refresh interval:</source>
        <translation type="obsolete">Interval osvježavanja RSS kanala:</translation>
    </message>
    <message>
        <source>minutes</source>
        <translation type="obsolete">minute</translation>
    </message>
    <message>
        <source>Maximum number of articles per feed:</source>
        <translation type="obsolete">Najveći broj članaka po kanalu:</translation>
    </message>
</context>
<context>
    <name>RssSettingsDlg</name>
    <message>
        <source>RSS Reader Settings</source>
        <translation>Postavke RSS čitača</translation>
    </message>
    <message>
        <source>RSS feeds refresh interval:</source>
        <translation>Interval osvježavanja RSS kanala:</translation>
    </message>
    <message>
        <source>minutes</source>
        <translation>minute</translation>
    </message>
    <message>
        <source>Maximum number of articles per feed:</source>
        <translation>Najveći broj članaka po kanalu:</translation>
    </message>
</context>
<context>
    <name>RssStream</name>
    <message>
        <source>Automatically downloading %1 torrent from %2 RSS feed...</source>
        <translation type="obsolete">Automatsko preuzimanje %1 torrenta sa %2 RSS kanala ...</translation>
    </message>
</context>
<context>
    <name>ScanFoldersModel</name>
    <message>
        <source>Watched Folder</source>
        <translation>Pregledana mapa</translation>
    </message>
    <message>
        <source>Download here</source>
        <translation>Preuzmi ovdje</translation>
    </message>
</context>
<context>
    <name>SearchCategories</name>
    <message>
        <source>All categories</source>
        <translation>Kategorije</translation>
    </message>
    <message>
        <source>Movies</source>
        <translation>Filmovi</translation>
    </message>
    <message>
        <source>TV shows</source>
        <translation>TV emisije</translation>
    </message>
    <message>
        <source>Music</source>
        <translation>Glazba</translation>
    </message>
    <message>
        <source>Games</source>
        <translation>Igre</translation>
    </message>
    <message>
        <source>Anime</source>
        <translation>Animirani</translation>
    </message>
    <message>
        <source>Software</source>
        <translation>Softver</translation>
    </message>
    <message>
        <source>Pictures</source>
        <translation>Slike</translation>
    </message>
    <message>
        <source>Books</source>
        <translation>Knjige</translation>
    </message>
</context>
<context>
    <name>SearchEngine</name>
    <message>
        <source>Cut</source>
        <translation>Izreži</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Kopiraj</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation>Zalijepi</translation>
    </message>
    <message>
        <source>Clear field</source>
        <translation>Očisti polje</translation>
    </message>
    <message>
        <source>Clear completion history</source>
        <translation>Izbriši povijest upotpunjavanja</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Traži</translation>
    </message>
    <message>
        <source>Empty search pattern</source>
        <translation>Prazan predložak potrage</translation>
    </message>
    <message>
        <source>Please type a search pattern first</source>
        <translation>Prvo utipkajte predložak potrage</translation>
    </message>
    <message>
        <source>Results</source>
        <translation>Rezultati</translation>
    </message>
    <message>
        <source>Searching...</source>
        <translation>Potraga ...</translation>
    </message>
    <message>
        <source>Search Engine</source>
        <translation>Tražilica</translation>
    </message>
    <message>
        <source>Search has finished</source>
        <translation>Potraga je gotova</translation>
    </message>
    <message>
        <source>An error occured during search...</source>
        <translation>Dogodila se greška za vrijeme potrage ...</translation>
    </message>
    <message>
        <source>Search aborted</source>
        <translation>Potraga je otkazana</translation>
    </message>
    <message>
        <source>Search returned no results</source>
        <translation>Potraga vraćena bez rezultata</translation>
    </message>
    <message>
        <source>Results</source>
        <comment>i.e: Search results</comment>
        <translation>Rezultati</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Nije poznato</translation>
    </message>
    <message>
        <source>Download error</source>
        <translation>Greška prilikom preuzimanja</translation>
    </message>
    <message>
        <source>Python setup could not be downloaded, reason: %1.
Please install it manually.</source>
        <translation>Python setup nije moguće preuzeti. Razlog: %1.
Instalirajte ručno.</translation>
    </message>
    <message>
        <source>Missing Python Interpreter</source>
        <translation>Nedostaje Python Interpreter</translation>
    </message>
    <message>
        <source>Python 2.x is required to use the search engine but it does not seem to be installed.
Do you want to install it now?</source>
        <translation>Python 2.x je nužan kako biste mogli koristiti tražilicu i čini se da nije instaliran.
Želite li ga sada instalirati?</translation>
    </message>
    <message>
        <source>Confirmation</source>
        <translation>Potvrda</translation>
    </message>
    <message>
        <source>Are you sure you want to clear the history?</source>
        <translation>Jeste li sigurni da želite izbrisati povijest?</translation>
    </message>
</context>
<context>
    <name>SearchTab</name>
    <message>
        <source>Name</source>
        <comment>i.e: file name</comment>
        <translation>Ime</translation>
    </message>
    <message>
        <source>Size</source>
        <comment>i.e: file size</comment>
        <translation>Veličina</translation>
    </message>
    <message>
        <source>Seeders</source>
        <comment>i.e: Number of full sources</comment>
        <translation>Seederi</translation>
    </message>
    <message>
        <source>Leechers</source>
        <comment>i.e: Number of partial sources</comment>
        <translation>Leecheri</translation>
    </message>
    <message>
        <source>Search engine</source>
        <translation>Tražilica</translation>
    </message>
</context>
<context>
    <name>ShutdownConfirmDlg</name>
    <message>
        <source>Shutdown confirmation</source>
        <translation>Potvrda isključivanja</translation>
    </message>
</context>
<context>
    <name>SpeedLimitDialog</name>
    <message>
        <source>KiB/s</source>
        <translation>KiB/s</translation>
    </message>
</context>
<context>
    <name>StatusBar</name>
    <message>
        <source>Connection status:</source>
        <translation>Status spajanja:</translation>
    </message>
    <message>
        <source>No direct connections. This may indicate network configuration problems.</source>
        <translation>Nema izravnih spajanja. Ovo može značiti probleme u postavkama mreže.</translation>
    </message>
    <message>
        <source>D: %1 B/s - T: %2</source>
        <comment>Download speed: x B/s - Transferred: x MiB</comment>
        <translation type="obsolete">Preuzimanje: %1 B/s - Preuzeto: %2</translation>
    </message>
    <message>
        <source>U: %1 B/s - T: %2</source>
        <comment>Upload speed: x B/s - Transferred: x MiB</comment>
        <translation type="obsolete">Slanje: %1 B/s - Poslano: %2</translation>
    </message>
    <message>
        <source>DHT: %1 nodes</source>
        <translation>DHT: %1 čvorova</translation>
    </message>
    <message>
        <source>Connection Status:</source>
        <translation>Status spajanja:</translation>
    </message>
    <message>
        <source>Offline. This usually means that qBittorrent failed to listen on the selected port for incoming connections.</source>
        <translation>Odspojeno. Ovo najčešće znači da qBittorrent nije uspio u očekivanju veze na odabranom portu za dolazna spajanja.</translation>
    </message>
    <message>
        <source>Online</source>
        <translation>Spojeno</translation>
    </message>
    <message>
        <source>D: %1/s - T: %2</source>
        <comment>Download speed: x KiB/s - Transferred: x MiB</comment>
        <translation type="obsolete">Preuzimanje: %1/s - Preuzeto: %2</translation>
    </message>
    <message>
        <source>U: %1/s - T: %2</source>
        <comment>Upload speed: x KiB/s - Transferred: x MiB</comment>
        <translation type="obsolete">Slanje: %1/s - Poslano: %2</translation>
    </message>
    <message>
        <source>Click to disable alternative speed limits</source>
        <translation type="obsolete">Kliknite kako biste onemogućili alternativne limite brzine</translation>
    </message>
    <message>
        <source>Click to enable alternative speed limits</source>
        <translation type="obsolete">Kliknite kako biste omogućili alternativne limite brzine</translation>
    </message>
    <message>
        <source>Global Download Speed Limit</source>
        <translation>Globalni limit brzine preuzimanja</translation>
    </message>
    <message>
        <source>Global Upload Speed Limit</source>
        <translation>Globalni limit brzine slanja</translation>
    </message>
    <message>
        <source>qBittorrent needs to be restarted</source>
        <translation>qBittorrent treba ponovno pokrenuti</translation>
    </message>
    <message>
        <source>qBittorrent was just updated and needs to be restarted for the changes to be effective.</source>
        <translation>qBittorrent je upravo ažuriran i treba ga ponovno pokrenuti kako bi promjene postale učinkovite.</translation>
    </message>
    <message>
        <source>Click to switch to alternative speed limits</source>
        <translation>Kliknite za prelazak na alternativne limite brzine</translation>
    </message>
    <message>
        <source>Click to switch to regular speed limits</source>
        <translation>Kliknite za prelazak na uobičajene limite brzine</translation>
    </message>
    <message>
        <source>%1/s</source>
        <comment>Per second</comment>
        <translation>%1/s</translation>
    </message>
</context>
<context>
    <name>TorrentCreatorDlg</name>
    <message>
        <source>Select a folder to add to the torrent</source>
        <translation>Izaberite mapu koja će biti dodana torrentu</translation>
    </message>
    <message>
        <source>Select a file to add to the torrent</source>
        <translation>Izaberite datoteku koja će biti dodana torrentu</translation>
    </message>
    <message>
        <source>No input path set</source>
        <translation>Nije zadana ulazna putanja</translation>
    </message>
    <message>
        <source>Please type an input path first</source>
        <translation>Upišite prvo ulaznu putanju</translation>
    </message>
    <message>
        <source>Select destination torrent file</source>
        <translation>Izabrite odredišnu torrent datoteku</translation>
    </message>
    <message>
        <source>Torrent Files</source>
        <translation>Torrent datoteke</translation>
    </message>
    <message>
        <source>Torrent creation</source>
        <translation>Kreiranje torrenta</translation>
    </message>
    <message>
        <source>Torrent creation was unsuccessful, reason: %1</source>
        <translation>Kreiranje torrenta nije uspjelo. Razlog: %1</translation>
    </message>
    <message>
        <source>Created torrent file is invalid. It won&apos;t be added to download list.</source>
        <translation>Kreirana torrent datoteka nije ispravna. Neće biti dodana na popis preuzimanja.</translation>
    </message>
    <message>
        <source>Torrent was created successfully:</source>
        <translation>Torrent je uspješno kreiran:</translation>
    </message>
</context>
<context>
    <name>TorrentFilesModel</name>
    <message>
        <source>Name</source>
        <translation>Ime</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Veličina</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation>Napredak</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Prioritet</translation>
    </message>
</context>
<context>
    <name>TorrentImportDlg</name>
    <message>
        <source>Torrent Import</source>
        <translation>Uvoz torrenta</translation>
    </message>
    <message>
        <source>This assistant will help you share with qBittorrent a torrent that you have already downloaded.</source>
        <translation>Ovaj pomoćnik će vam olakšati dijeliti pomoću qBittorrenta torrent koji ste već preuzeli.</translation>
    </message>
    <message>
        <source>Torrent file to import:</source>
        <translation>Torrent datoteka za uvoz:</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Content location:</source>
        <translation>Lokacija sadržaja:</translation>
    </message>
    <message>
        <source>Skip the data checking stage and start seeding immediately</source>
        <translation>Preskoči korak provjere podataka i trenutno započni seedanje</translation>
    </message>
    <message>
        <source>Import</source>
        <translation>Uvezi</translation>
    </message>
    <message>
        <source>Torrent file to import</source>
        <translation>Torrent datoteka za uvoz</translation>
    </message>
    <message>
        <source>Torrent files (*.torrent)</source>
        <translation>Torrent datoteke (*.torrent)</translation>
    </message>
    <message>
        <source>%1 Files</source>
        <comment>%1 is a file extension (e.g. PDF)</comment>
        <translation>%1 datoteke</translation>
    </message>
    <message>
        <source>Please provide the location of %1</source>
        <comment>%1 is a file name</comment>
        <translation>Navedite lokaciju %1</translation>
    </message>
    <message>
        <source>Please point to the location of the torrent: %1</source>
        <translation>Istaknite lokaciju torrenta: %1</translation>
    </message>
    <message>
        <source>Invalid torrent file</source>
        <translation>Neispravna torrent datoteka</translation>
    </message>
    <message>
        <source>This is not a valid torrent file.</source>
        <translation>Ovo nije ispravna torrent datoteka.</translation>
    </message>
</context>
<context>
    <name>TorrentModel</name>
    <message>
        <source>Name</source>
        <comment>i.e: torrent name</comment>
        <translation>Ime</translation>
    </message>
    <message>
        <source>Size</source>
        <comment>i.e: torrent size</comment>
        <translation>Veličina</translation>
    </message>
    <message>
        <source>Done</source>
        <comment>% Done</comment>
        <translation>Napredak</translation>
    </message>
    <message>
        <source>Status</source>
        <comment>Torrent status (e.g. downloading, seeding, paused)</comment>
        <translation>Status</translation>
    </message>
    <message>
        <source>Seeds</source>
        <comment>i.e. full sources (often untranslated)</comment>
        <translation>Seedovi</translation>
    </message>
    <message>
        <source>Peers</source>
        <comment>i.e. partial sources (often untranslated)</comment>
        <translation>Peerovi</translation>
    </message>
    <message>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Brzina preuzimanja</translation>
    </message>
    <message>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Brzina slanja</translation>
    </message>
    <message>
        <source>Ratio</source>
        <comment>Share ratio</comment>
        <translation>Omjer</translation>
    </message>
    <message>
        <source>ETA</source>
        <comment>i.e: Estimated Time of Arrival / Time left</comment>
        <translation>Preostalo vrijeme</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Oznaka</translation>
    </message>
    <message>
        <source>Added On</source>
        <comment>Torrent was added to transfer list on 01/01/2010 08:00</comment>
        <translation>Dodano</translation>
    </message>
    <message>
        <source>Completed On</source>
        <comment>Torrent was completed on 01/01/2010 08:00</comment>
        <translation>Dovršeno</translation>
    </message>
    <message>
        <source>Tracker</source>
        <translation>Tracker</translation>
    </message>
    <message>
        <source>Down Limit</source>
        <comment>i.e: Download limit</comment>
        <translation>Limit preuzimanja</translation>
    </message>
    <message>
        <source>Up Limit</source>
        <comment>i.e: Upload limit</comment>
        <translation>Limit slanja</translation>
    </message>
    <message>
        <source>Amount downloaded</source>
        <comment>Amount of data downloaded (e.g. in MB)</comment>
        <translation>Preuzeta količina</translation>
    </message>
    <message>
        <source>Amount left</source>
        <comment>Amount of data left to download (e.g. in MB)</comment>
        <translation>Preostala količina</translation>
    </message>
    <message>
        <source>Time Active</source>
        <comment>Time (duration) the torrent is active (not paused)</comment>
        <translation>Vrijeme aktivnosti</translation>
    </message>
</context>
<context>
    <name>TrackerList</name>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <source>Peers</source>
        <translation>Peerovi</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Poruka</translation>
    </message>
    <message>
        <source>[DHT]</source>
        <translation>[DHT]</translation>
    </message>
    <message>
        <source>[PeX]</source>
        <translation>[PeX]</translation>
    </message>
    <message>
        <source>[LSD]</source>
        <translation>[LSD]</translation>
    </message>
    <message>
        <source>Working</source>
        <translation>Radi</translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Onemogućeno</translation>
    </message>
    <message>
        <source>This torrent is private</source>
        <translation>Ovaj torrent je privatan</translation>
    </message>
    <message>
        <source>Updating...</source>
        <translation>Ažuriranje ...</translation>
    </message>
    <message>
        <source>Not working</source>
        <translation>Ne radi</translation>
    </message>
    <message>
        <source>Not contacted yet</source>
        <translation>Još nije kontaktirano</translation>
    </message>
    <message>
        <source>Add a new tracker</source>
        <translation type="obsolete">Dodaj novi tracker</translation>
    </message>
    <message>
        <source>Add a new tracker...</source>
        <translation>Dodaj novi tracker ...</translation>
    </message>
    <message>
        <source>Remove tracker</source>
        <translation>Ukloni tracker</translation>
    </message>
    <message>
        <source>Force reannounce</source>
        <translation>Prisili ponovno objavljivanje</translation>
    </message>
</context>
<context>
    <name>TrackersAdditionDlg</name>
    <message>
        <source>Trackers addition dialog</source>
        <translation>Dijalog dodavanja trackera</translation>
    </message>
    <message>
        <source>List of trackers to add (one per line):</source>
        <translation>Popis trackera za dodati (jedan po liniji):</translation>
    </message>
    <message utf8="true">
        <source>µTorrent compatible list URL:</source>
        <translation>Popis URL-ova kompatibilan s µTorrentom:</translation>
    </message>
    <message>
        <source>I/O Error</source>
        <translation>I/O greška</translation>
    </message>
    <message>
        <source>Error while trying to open the downloaded file.</source>
        <translation>Greška prilikom pokušaja otvaranja preuzete datoteke.</translation>
    </message>
    <message>
        <source>No change</source>
        <translation>Bez promjene</translation>
    </message>
    <message>
        <source>No additional trackers were found.</source>
        <translation>Nisu pronađeni dodatni trackeri.</translation>
    </message>
    <message>
        <source>Download error</source>
        <translation>Greška prilikom preuzimanja</translation>
    </message>
    <message>
        <source>The trackers list could not be downloaded, reason: %1</source>
        <translation>Popis trackera nije moguće preuzeti. Razlog: %1</translation>
    </message>
</context>
<context>
    <name>TransferListDelegate</name>
    <message>
        <source>Downloading</source>
        <translation>Preuzimanje</translation>
    </message>
    <message>
        <source>Paused</source>
        <translation>Pauzirano</translation>
    </message>
    <message>
        <source>Queued</source>
        <comment>i.e. torrent is queued</comment>
        <translation>Na čekanju</translation>
    </message>
    <message>
        <source>Seeding</source>
        <comment>Torrent is complete and in upload-only mode</comment>
        <translation>Seedanje</translation>
    </message>
    <message>
        <source>Stalled</source>
        <comment>Torrent is waiting for download to begin</comment>
        <translation>Zastoj</translation>
    </message>
    <message>
        <source>Checking</source>
        <comment>Torrent local data is being checked</comment>
        <translation>Provjeravanje</translation>
    </message>
    <message>
        <source>/s</source>
        <comment>/second (.i.e per second)</comment>
        <translation>/s</translation>
    </message>
    <message>
        <source>KiB/s</source>
        <comment>KiB/second (.i.e per second)</comment>
        <translation>KiB/s</translation>
    </message>
    <message>
        <source>Seeded for %1</source>
        <comment>e.g. Seeded for 3m10s</comment>
        <translation>Seedano za %1</translation>
    </message>
</context>
<context>
    <name>TransferListFiltersWidget</name>
    <message>
        <source>All</source>
        <translation>Sve</translation>
    </message>
    <message>
        <source>Downloading</source>
        <translation>Preuzimanja</translation>
    </message>
    <message>
        <source>Completed</source>
        <translation>Završeno</translation>
    </message>
    <message>
        <source>Active</source>
        <translation>Aktivno</translation>
    </message>
    <message>
        <source>Inactive</source>
        <translation>Neaktivno</translation>
    </message>
    <message>
        <source>All labels</source>
        <translation>Sve označeno</translation>
    </message>
    <message>
        <source>Unlabeled</source>
        <translation>Neoznačeno</translation>
    </message>
    <message>
        <source>Remove label</source>
        <translation>Ukloni oznaku</translation>
    </message>
    <message>
        <source>Add label</source>
        <translation type="obsolete">Dodaj oznaku</translation>
    </message>
    <message>
        <source>New Label</source>
        <translation>Nova oznaka</translation>
    </message>
    <message>
        <source>Label:</source>
        <translation>Oznaka:</translation>
    </message>
    <message>
        <source>Invalid label name</source>
        <translation>Neispravno ime oznake</translation>
    </message>
    <message>
        <source>Please don&apos;t use any special characters in the label name.</source>
        <translation>Nemojte koristiti niti jedan poseban znak u imenu oznake.</translation>
    </message>
    <message>
        <source>Paused</source>
        <translation>Pauzirano</translation>
    </message>
    <message>
        <source>Add label...</source>
        <translation>Dodaj oznaku ...</translation>
    </message>
    <message>
        <source>Resume torrents</source>
        <translation>Nastavi s torrentima</translation>
    </message>
    <message>
        <source>Pause torrents</source>
        <translation>Pauziraj torrente</translation>
    </message>
    <message>
        <source>Delete torrents</source>
        <translation>Izbriši torrente</translation>
    </message>
</context>
<context>
    <name>TransferListWidget</name>
    <message>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation type="obsolete">Brzina preuzimanja</translation>
    </message>
    <message>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation type="obsolete">Brzina slanja</translation>
    </message>
    <message>
        <source>ETA</source>
        <comment>i.e: Estimated Time of Arrival / Time left</comment>
        <translation type="obsolete">Preostalo vrijeme</translation>
    </message>
    <message>
        <source>Column visibility</source>
        <translation>Vidljivost stupca</translation>
    </message>
    <message>
        <source>Start</source>
        <translation type="obsolete">Započni</translation>
    </message>
    <message>
        <source>Pause</source>
        <translation type="obsolete">Pauziraj</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="obsolete">Izbriši</translation>
    </message>
    <message>
        <source>Preview file</source>
        <translation type="obsolete">Pregledaj datoteku</translation>
    </message>
    <message>
        <source>Name</source>
        <comment>i.e: torrent name</comment>
        <translation type="obsolete">Ime</translation>
    </message>
    <message>
        <source>Size</source>
        <comment>i.e: torrent size</comment>
        <translation type="obsolete">Veličina</translation>
    </message>
    <message>
        <source>Done</source>
        <comment>% Done</comment>
        <translation type="obsolete">Gotovo</translation>
    </message>
    <message>
        <source>Status</source>
        <comment>Torrent status (e.g. downloading, seeding, paused)</comment>
        <translation type="obsolete">Status</translation>
    </message>
    <message>
        <source>Seeds</source>
        <comment>i.e. full sources (often untranslated)</comment>
        <translation type="obsolete">Seedovi</translation>
    </message>
    <message>
        <source>Peers</source>
        <comment>i.e. partial sources (often untranslated)</comment>
        <translation type="obsolete">Peerovi</translation>
    </message>
    <message>
        <source>Ratio</source>
        <comment>Share ratio</comment>
        <translation type="obsolete">Omjer</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Oznaka</translation>
    </message>
    <message>
        <source>Added On</source>
        <comment>Torrent was added to transfer list on 01/01/2010 08:00</comment>
        <translation type="obsolete">Dodano</translation>
    </message>
    <message>
        <source>Completed On</source>
        <comment>Torrent was completed on 01/01/2010 08:00</comment>
        <translation type="obsolete">Dovršeno</translation>
    </message>
    <message>
        <source>Down Limit</source>
        <comment>i.e: Download limit</comment>
        <translation type="obsolete">Limit preuzimanja</translation>
    </message>
    <message>
        <source>Up Limit</source>
        <comment>i.e: Upload limit</comment>
        <translation type="obsolete">Limit slanja</translation>
    </message>
    <message>
        <source>Torrent Download Speed Limiting</source>
        <translation>Limitiranje brzine preuzimanja torrenta</translation>
    </message>
    <message>
        <source>Torrent Upload Speed Limiting</source>
        <translation>Limitiranje brzine slanja torrenta</translation>
    </message>
    <message>
        <source>New Label</source>
        <translation>Nova oznaka</translation>
    </message>
    <message>
        <source>Label:</source>
        <translation>Oznaka:</translation>
    </message>
    <message>
        <source>Invalid label name</source>
        <translation>Neispravno ime oznake</translation>
    </message>
    <message>
        <source>Please don&apos;t use any special characters in the label name.</source>
        <translation>Nemojte koristiti niti jedan poseban znak u imenu oznake.</translation>
    </message>
    <message>
        <source>Rename</source>
        <translation>Preimenovanje</translation>
    </message>
    <message>
        <source>New name:</source>
        <translation>Novo ime:</translation>
    </message>
    <message>
        <source>Limit upload rate</source>
        <translation type="obsolete">Limitiraj brzinu slanja</translation>
    </message>
    <message>
        <source>Limit download rate</source>
        <translation type="obsolete">Limitiraj brzinu preuzimanja</translation>
    </message>
    <message>
        <source>Open destination folder</source>
        <translation>Otvori odredišnu mapu</translation>
    </message>
    <message>
        <source>Buy it</source>
        <translation type="obsolete">Kupi</translation>
    </message>
    <message>
        <source>Increase priority</source>
        <translation type="obsolete">Povećaj prioritet</translation>
    </message>
    <message>
        <source>Decrease priority</source>
        <translation type="obsolete">Smanji prioritet</translation>
    </message>
    <message>
        <source>Force recheck</source>
        <translation>Prisili ponovnu provjeru</translation>
    </message>
    <message>
        <source>Copy magnet link</source>
        <translation>Kopiraj magnet link</translation>
    </message>
    <message>
        <source>Super seeding mode</source>
        <translation>Način superseedanja</translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation>Preimenuj ...</translation>
    </message>
    <message>
        <source>Download in sequential order</source>
        <translation>Preuzmi u sekvencijskom poretku</translation>
    </message>
    <message>
        <source>Download first and last piece first</source>
        <translation>Preuzmi prvi i zadnji djelić</translation>
    </message>
    <message>
        <source>New...</source>
        <comment>New label...</comment>
        <translation>Nova ...</translation>
    </message>
    <message>
        <source>Reset</source>
        <comment>Reset label</comment>
        <translation>Poništi</translation>
    </message>
    <message>
        <source>Choose save path</source>
        <translation>Izaberi putanju spremanja</translation>
    </message>
    <message>
        <source>Save path creation error</source>
        <translation type="obsolete">Greška prilikom kreiranja putanje spremanja</translation>
    </message>
    <message>
        <source>Could not create the save path</source>
        <translation type="obsolete">Nije moguće kreirati putanju spremanja</translation>
    </message>
    <message>
        <source>Set location...</source>
        <translation>Postavi mjesto ...</translation>
    </message>
    <message>
        <source>Preview file...</source>
        <translation>Pregledaj datoteke</translation>
    </message>
    <message>
        <source>Limit upload rate...</source>
        <translation>Limitiraj brzinu slanja ...</translation>
    </message>
    <message>
        <source>Limit download rate...</source>
        <translation>Limitiraj brzinu preuzimanja ...</translation>
    </message>
    <message>
        <source>Move up</source>
        <comment>i.e. move up in the queue</comment>
        <translation>Pomakni gore</translation>
    </message>
    <message>
        <source>Move down</source>
        <comment>i.e. Move down in the queue</comment>
        <translation>Pomakni dolje</translation>
    </message>
    <message>
        <source>Move to top</source>
        <comment>i.e. Move to top of the queue</comment>
        <translation>Na vrh</translation>
    </message>
    <message>
        <source>Move to bottom</source>
        <comment>i.e. Move to bottom of the queue</comment>
        <translation>Na dno</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Prioritet</translation>
    </message>
    <message>
        <source>Resume</source>
        <comment>Resume/start the torrent</comment>
        <translation>Nastavi</translation>
    </message>
    <message>
        <source>Pause</source>
        <comment>Pause the torrent</comment>
        <translation>Pauziraj</translation>
    </message>
    <message>
        <source>Delete</source>
        <comment>Delete the torrent</comment>
        <translation>Izbriši</translation>
    </message>
    <message>
        <source>Limit share ratio...</source>
        <translation>Limit omjera djeljenja</translation>
    </message>
</context>
<context>
    <name>UpDownRatioDlg</name>
    <message>
        <source>Torrent Upload/Download Ratio Limiting</source>
        <translation>Limitiranje omjera slanja/preuzimanja torrenta</translation>
    </message>
    <message>
        <source>Use global ratio limit</source>
        <translation>Koristi globalni limit omjera</translation>
    </message>
    <message>
        <source>buttonGroup</source>
        <translation>buttonGroup</translation>
    </message>
    <message>
        <source>Set no ratio limit</source>
        <translation>Ne podešavaj limit omjera</translation>
    </message>
    <message>
        <source>Set ratio limit to</source>
        <translation>Podesi limit omjera na</translation>
    </message>
</context>
<context>
    <name>UsageDisplay</name>
    <message>
        <source>Usage:</source>
        <translation>Upotreba:</translation>
    </message>
    <message>
        <source>displays program version</source>
        <translation>prikazuje verziju programa</translation>
    </message>
    <message>
        <source>disable splash screen</source>
        <translation>onemogućava najavni zaslon</translation>
    </message>
    <message>
        <source>displays this help message</source>
        <translation>prikazuje ovu poruku pomoći</translation>
    </message>
    <message>
        <source>changes the webui port (current: %1)</source>
        <translation>mijenja port web sučelja(trenutni: %1)</translation>
    </message>
    <message>
        <source>[files or urls]: downloads the torrents passed by the user (optional)</source>
        <translation>[datoteke ili URL-ovi]: preuzima torrente koje je korisnik dopustio (neobavezno)</translation>
    </message>
</context>
<context>
    <name>about</name>
    <message>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <source>I would like to thank the following people who volunteered to translate qBittorrent:</source>
        <translation>Zahvaljujem sljedećim ljudima koji su dobrovoljno preveli qBittorrent:</translation>
    </message>
    <message>
        <source>Please contact me if you would like to translate qBittorrent into your own language.</source>
        <translation>Molim vas da me obavijestite ako želite prevesti qBittorrent na svoj jezik.</translation>
    </message>
</context>
<context>
    <name>addPeerDialog</name>
    <message>
        <source>Peer addition</source>
        <translation>Dodavanje peerova</translation>
    </message>
    <message>
        <source>IP</source>
        <translation>IP</translation>
    </message>
    <message>
        <source>Port</source>
        <translation>Port</translation>
    </message>
</context>
<context>
    <name>addTorrentDialog</name>
    <message>
        <source>Torrent addition dialog</source>
        <translation>Dijalog dodavanja torrenta</translation>
    </message>
    <message>
        <source>Save path:</source>
        <translation>Putanja za spremanje:</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Torrent size:</source>
        <translation>Veličina torrenta:</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Nije poznato</translation>
    </message>
    <message>
        <source>Free disk space:</source>
        <translation>Slobodan prostor na disku:</translation>
    </message>
    <message>
        <source>Label:</source>
        <translation>Oznaka:</translation>
    </message>
    <message>
        <source>Torrent content:</source>
        <translation>Sadržaj torrenta:</translation>
    </message>
    <message>
        <source>Download in sequential order (slower but good for previewing)</source>
        <translation>Preuzmi u sekvencijskom poretku (sporije, ali dobro za pregledavanje)</translation>
    </message>
    <message>
        <source>Skip file checking and start seeding immediately</source>
        <translation>Preskoči provjeru datoteke i trenutno započni seedanje</translation>
    </message>
    <message>
        <source>Add to download list in paused state</source>
        <translation>Dodaj popisu preuzimanja u zaustavljenom stanju</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>Dodaj</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Odustani</translation>
    </message>
    <message>
        <source>Normal</source>
        <translation>Uobičajen</translation>
    </message>
    <message>
        <source>High</source>
        <translation>Visok</translation>
    </message>
    <message>
        <source>Maximum</source>
        <translation>Najviši</translation>
    </message>
    <message>
        <source>Collapse all</source>
        <translation type="obsolete">Sklopi sve</translation>
    </message>
    <message>
        <source>Expand all</source>
        <translation type="obsolete">Proširi sve</translation>
    </message>
    <message>
        <source>Not downloaded</source>
        <translation type="obsolete">Nije preuzeto</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Odaberi sve</translation>
    </message>
    <message>
        <source>Select None</source>
        <translation>Ne odaberi ništa</translation>
    </message>
    <message>
        <source>Do not download</source>
        <translation>Ne preuzimaj</translation>
    </message>
</context>
<context>
    <name>authentication</name>
    <message>
        <source>Tracker authentication</source>
        <translation>Ovjera trackera</translation>
    </message>
    <message>
        <source>Tracker:</source>
        <translation>Tracker:</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Prijava</translation>
    </message>
    <message>
        <source>Username:</source>
        <translation>Korisničko ime:</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation>Lozinka:</translation>
    </message>
    <message>
        <source>Log in</source>
        <translation>Prijavi se</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Odustani</translation>
    </message>
</context>
<context>
    <name>confirmDeletionDlg</name>
    <message>
        <source>Deletion confirmation - qBittorrent</source>
        <translation>Potvrda brisanja - qBittorrent</translation>
    </message>
    <message>
        <source>Are you sure you want to delete the selected torrents from the transfer list?</source>
        <translation>Jeste li sigurni da želite izbrisati odabrane torrente s popisa transfera?</translation>
    </message>
    <message>
        <source>Delete the files on the hard disk as well</source>
        <translation type="obsolete">Brisati datoteke i na tvrdom disku</translation>
    </message>
    <message>
        <source>Remember choice</source>
        <translation>Zapamti izbor</translation>
    </message>
    <message>
        <source>Also delete the files on the hard disk</source>
        <translation>Također izbriši datoteke i na čvrstom disku</translation>
    </message>
</context>
<context>
    <name>createTorrentDialog</name>
    <message>
        <source>Cancel</source>
        <translation>Odustani</translation>
    </message>
    <message>
        <source>Torrent Creation Tool</source>
        <translation>Alat za kreiranje torrenta</translation>
    </message>
    <message>
        <source>Torrent file creation</source>
        <translation>Kreiranje torrent datoteke</translation>
    </message>
    <message>
        <source>Add file</source>
        <translation>Dodaj datoteku</translation>
    </message>
    <message>
        <source>Add folder</source>
        <translation>Dodaj mapu</translation>
    </message>
    <message>
        <source>Announce urls (trackers):</source>
        <translation type="obsolete">Objavi URL-ove (trackeri):</translation>
    </message>
    <message>
        <source>Comment (optional):</source>
        <translation type="obsolete">Komentar (neobavezno):</translation>
    </message>
    <message>
        <source>Web seeds urls (optional):</source>
        <translation type="obsolete">URL-ovi web seedova (neobavezno):</translation>
    </message>
    <message>
        <source>File or folder to add to the torrent:</source>
        <translation>Datoteka ili mapa za dodati u torrent:</translation>
    </message>
    <message>
        <source>Piece size:</source>
        <translation>Veličina djelića:</translation>
    </message>
    <message>
        <source>32 KiB</source>
        <translation>32 KiB</translation>
    </message>
    <message>
        <source>64 KiB</source>
        <translation>64 KiB</translation>
    </message>
    <message>
        <source>128 KiB</source>
        <translation>128 KiB</translation>
    </message>
    <message>
        <source>256 KiB</source>
        <translation>256 KiB</translation>
    </message>
    <message>
        <source>512 KiB</source>
        <translation>512 KiB</translation>
    </message>
    <message>
        <source>1 MiB</source>
        <translation>1 MiB</translation>
    </message>
    <message>
        <source>2 MiB</source>
        <translation>2 MiB</translation>
    </message>
    <message>
        <source>4 MiB</source>
        <translation>4 MiB</translation>
    </message>
    <message>
        <source>Private (won&apos;t be distributed on DHT network if enabled)</source>
        <translation>Privatno (neće biti distribuirano na DHT mreži ako je omogućeno)</translation>
    </message>
    <message>
        <source>Start seeding after creation</source>
        <translation>Započni seedanje nakon kreiranja</translation>
    </message>
    <message>
        <source>Create and save...</source>
        <translation>Kreiraj i spremi ...</translation>
    </message>
    <message>
        <source>Progress:</source>
        <translation>Napredak:</translation>
    </message>
    <message>
        <source>Tracker URLs:</source>
        <translation>URL-ovi trackera:</translation>
    </message>
    <message>
        <source>Web seeds urls:</source>
        <translation>URL-ovi web seedova:</translation>
    </message>
    <message>
        <source>Comment:</source>
        <translation>Komentar:</translation>
    </message>
    <message>
        <source>Auto</source>
        <translation>Auto</translation>
    </message>
</context>
<context>
    <name>createtorrent</name>
    <message>
        <source>Select destination torrent file</source>
        <translation type="obsolete">Izabrite odredišnu torrent datoteku</translation>
    </message>
    <message>
        <source>Torrent Files</source>
        <translation type="obsolete">Torrent datoteke</translation>
    </message>
    <message>
        <source>No input path set</source>
        <translation type="obsolete">Nije zadana ulazna putanja</translation>
    </message>
    <message>
        <source>Please type an input path first</source>
        <translation type="obsolete">Upišite prvo ulaznu putanju</translation>
    </message>
    <message>
        <source>Torrent creation</source>
        <translation type="obsolete">Kreiranje torrenta</translation>
    </message>
    <message>
        <source>Torrent was created successfully:</source>
        <translation type="obsolete">Torrent je uspješno kreiran:</translation>
    </message>
    <message>
        <source>Select a folder to add to the torrent</source>
        <translation type="obsolete">Izaberite mapu koja će biti dodana torrentu</translation>
    </message>
    <message>
        <source>Please type an announce URL</source>
        <translation type="obsolete">Upišite objavljeni URL</translation>
    </message>
    <message>
        <source>Torrent creation was unsuccessful, reason: %1</source>
        <translation type="obsolete">Kreiranje torrenta nije uspjelo. Razlog: %1</translation>
    </message>
    <message>
        <source>Announce URL:</source>
        <comment>Tracker URL</comment>
        <translation type="obsolete">Objavljeni URL:</translation>
    </message>
    <message>
        <source>Please type a web seed url</source>
        <translation type="obsolete">Upišite URL web seeda</translation>
    </message>
    <message>
        <source>Web seed URL:</source>
        <translation type="obsolete">URL web seeda:</translation>
    </message>
    <message>
        <source>Select a file to add to the torrent</source>
        <translation type="obsolete">Izaberite datoteku koja će biti dodana torrentu</translation>
    </message>
    <message>
        <source>Created torrent file is invalid. It won&apos;t be added to download list.</source>
        <translation type="obsolete">Kreirana torrent datoteka nije ispravna. Neće biti dodana na popis preuzimanja.</translation>
    </message>
</context>
<context>
    <name>downloadFromURL</name>
    <message>
        <source>Download Torrents from URLs</source>
        <translation type="obsolete">Preuzmi torrente s URL-ova</translation>
    </message>
    <message>
        <source>Only one URL per line</source>
        <translation type="obsolete">Samo jedan URL po liniji</translation>
    </message>
    <message>
        <source>Download</source>
        <translation>Preuzmi</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Odustani</translation>
    </message>
    <message>
        <source>Download from urls</source>
        <translation>Preuzmi s URL-ova</translation>
    </message>
    <message>
        <source>No URL entered</source>
        <translation>Nije unesen URL</translation>
    </message>
    <message>
        <source>Please type at least one URL.</source>
        <translation>Upišite bar jedan URL.</translation>
    </message>
    <message>
        <source>Add torrent links</source>
        <translation>Dodaj linkove torrenta</translation>
    </message>
    <message>
        <source>Both HTTP and Magnet links are supported</source>
        <translation>Podržani su HTTP i Magnet linkovi</translation>
    </message>
</context>
<context>
    <name>downloadThread</name>
    <message>
        <source>I/O Error</source>
        <translation type="obsolete">I/O greška</translation>
    </message>
    <message>
        <source>The remote host name was not found (invalid hostname)</source>
        <translation type="obsolete">Ime udaljenog računala nije nađeno (neispravno ime računala)</translation>
    </message>
    <message>
        <source>The operation was canceled</source>
        <translation type="obsolete">Operacija je otkazana</translation>
    </message>
    <message>
        <source>The remote server closed the connection prematurely, before the entire reply was received and processed</source>
        <translation type="obsolete">Udaljeni poslužitelj je prerano prekinuo spajanje, prije nego je primljen i obrađen cijeli odgovor</translation>
    </message>
    <message>
        <source>The connection to the remote server timed out</source>
        <translation type="obsolete">Spajanje s udaljenim poslužiteljem je isteklo</translation>
    </message>
    <message>
        <source>SSL/TLS handshake failed</source>
        <translation type="obsolete">SSL/TLS usklađivanje nije uspjelo</translation>
    </message>
    <message>
        <source>The remote server refused the connection</source>
        <translation type="obsolete">Udaljeni poslužitelj odbija spajanje</translation>
    </message>
    <message>
        <source>The connection to the proxy server was refused</source>
        <translation type="obsolete">Spajanje s proxy poslužiteljem je odbijeno</translation>
    </message>
    <message>
        <source>The proxy server closed the connection prematurely</source>
        <translation type="obsolete">Proxy server je prerano prekinuo spajanje</translation>
    </message>
    <message>
        <source>The proxy host name was not found</source>
        <translation type="obsolete">Ime proxy računala nije nađeno</translation>
    </message>
    <message>
        <source>The connection to the proxy timed out or the proxy did not reply in time to the request sent</source>
        <translation type="obsolete">Spajanje prema proxyju je isteklo ili proxy nije na vrijeme odgovorio na poslani zahtjev</translation>
    </message>
    <message>
        <source>The proxy requires authentication in order to honour the request but did not accept any credentials offered</source>
        <translation type="obsolete">Proxy zahtjeva ovjeru kako bi prihvatio zahtjev, ali nije prihvatio ponuđene vjerodajnice</translation>
    </message>
    <message>
        <source>The access to the remote content was denied (401)</source>
        <translation type="obsolete">Pristup udaljenom sadržaju je odbijen (401)</translation>
    </message>
    <message>
        <source>The operation requested on the remote content is not permitted</source>
        <translation type="obsolete">Tražena operacija nad udaljenim sadržajem nije dopuštena</translation>
    </message>
    <message>
        <source>The remote content was not found at the server (404)</source>
        <translation type="obsolete">Udaljeni sadržaj nije nađen na poslužitelju (404)</translation>
    </message>
    <message>
        <source>The remote server requires authentication to serve the content but the credentials provided were not accepted</source>
        <translation type="obsolete">Udaljeni poslužitelj zahtjeva ovjeru kako bi dostavio sadržaj, ali pružene vjerodajnice nisu prihvaćene</translation>
    </message>
    <message>
        <source>The Network Access API cannot honor the request because the protocol is not known</source>
        <translation type="obsolete">Network Access API ne može prihvatiti zahtjev jer protokol nije poznat</translation>
    </message>
    <message>
        <source>The requested operation is invalid for this protocol</source>
        <translation type="obsolete">Tražena operacija je neispravna za ovaj protokol</translation>
    </message>
    <message>
        <source>An unknown network-related error was detected</source>
        <translation type="obsolete">Otkrivena je nepoznata greška vezana za mrežu</translation>
    </message>
    <message>
        <source>An unknown proxy-related error was detected</source>
        <translation type="obsolete">Otkrivena je nepoznata greška vezana za proxy</translation>
    </message>
    <message>
        <source>An unknown error related to the remote content was detected</source>
        <translation type="obsolete">Otkrivena je nepoznata greška vezana za udaljeni sadržaj </translation>
    </message>
    <message>
        <source>A breakdown in protocol was detected</source>
        <translation type="obsolete">Otkriven je kvar u protokolu</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation type="obsolete">Nepoznata greška</translation>
    </message>
</context>
<context>
    <name>engineSelect</name>
    <message>
        <source>Search plugins</source>
        <translation>Tražilice</translation>
    </message>
    <message>
        <source>Installed search engines:</source>
        <translation>Instalirane tražilice:</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Ime</translation>
    </message>
    <message>
        <source>Url</source>
        <translation>Url</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Omogućeno</translation>
    </message>
    <message>
        <source>You can get new search engine plugins here: &lt;a href=&quot;http://plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</source>
        <translation>Nove tražilice možete naći ovdje: &lt;a href=&quot;http://plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</translation>
    </message>
    <message>
        <source>Install a new one</source>
        <translation>Instaliraj novu</translation>
    </message>
    <message>
        <source>Check for updates</source>
        <translation>Provjeri ažuriranja</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Zatvori</translation>
    </message>
    <message>
        <source>Enable</source>
        <translation type="obsolete">Omogući</translation>
    </message>
    <message>
        <source>Disable</source>
        <translation type="obsolete">Onemogući</translation>
    </message>
    <message>
        <source>Uninstall</source>
        <translation>Deinstaliraj</translation>
    </message>
</context>
<context>
    <name>engineSelectDlg</name>
    <message>
        <source>Uninstall warning</source>
        <translation>Upozorenje deinstalacije</translation>
    </message>
    <message>
        <source>Some plugins could not be uninstalled because they are included in qBittorrent.
 Only the ones you added yourself can be uninstalled.
However, those plugins were disabled.</source>
        <translation>Neke tražilice ne mogu biti instalirane jer su već uključene u QBittorrent.
Samo one koje ste sami dodali mogu biti deinstalirane.
Međutim, te tražilice su bile onemogućene.</translation>
    </message>
    <message>
        <source>Uninstall success</source>
        <translation>Deinstalacija je uspjela</translation>
    </message>
    <message>
        <source>Select search plugins</source>
        <translation>Izaberite tražilice</translation>
    </message>
    <message>
        <source>qBittorrent search plugins</source>
        <translation>qBittorrentove tražilice</translation>
    </message>
    <message>
        <source>Search plugin install</source>
        <translation>Instalacija tražilice</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Da</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Ne</translation>
    </message>
    <message>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <source>A more recent version of %1 search engine plugin is already installed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>Novija verzija %1 tražilice je već instalirana.</translation>
    </message>
    <message>
        <source>Search plugin update</source>
        <translation>Ažuriranje tražilice</translation>
    </message>
    <message>
        <source>Sorry, update server is temporarily unavailable.</source>
        <translation>Oprostite, ali poslužitelj za ažuriranje trenutno nije raspoloživ.</translation>
    </message>
    <message>
        <source>All your plugins are already up to date.</source>
        <translation>Sve vaše tražilice su ažurirane.</translation>
    </message>
    <message>
        <source>%1 search engine plugin could not be updated, keeping old version.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>%1 tražilica ne može biti ažurirana tako da ostaje stara verzija.</translation>
    </message>
    <message>
        <source>%1 search engine plugin could not be installed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>%1 tražilicu nije moguće instalirati.</translation>
    </message>
    <message>
        <source>All selected plugins were uninstalled successfully</source>
        <translation>Sve izabrane tražilice su uspješno deinstalirane</translation>
    </message>
    <message>
        <source>%1 search engine plugin was successfully updated.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>%1 tražilica je uspješno ažurirana.</translation>
    </message>
    <message>
        <source>%1 search engine plugin was successfully installed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>%1 tražilica je uspješno instalirana.</translation>
    </message>
    <message>
        <source>Sorry, %1 search plugin install failed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>Oprostite, ali instalacija %1 tražilice nije uspjela.</translation>
    </message>
    <message>
        <source>New search engine plugin URL</source>
        <translation>Novi URL tražilice</translation>
    </message>
    <message>
        <source>URL:</source>
        <translation>URL:</translation>
    </message>
</context>
<context>
    <name>misc</name>
    <message>
        <source>B</source>
        <comment>bytes</comment>
        <translation>B</translation>
    </message>
    <message>
        <source>KiB</source>
        <comment>kibibytes (1024 bytes)</comment>
        <translation>KiB</translation>
    </message>
    <message>
        <source>MiB</source>
        <comment>mebibytes (1024 kibibytes)</comment>
        <translation>MiB</translation>
    </message>
    <message>
        <source>GiB</source>
        <comment>gibibytes (1024 mibibytes)</comment>
        <translation>GiB</translation>
    </message>
    <message>
        <source>TiB</source>
        <comment>tebibytes (1024 gibibytes)</comment>
        <translation>TiB</translation>
    </message>
    <message>
        <source>Unknown</source>
        <comment>Unknown (size)</comment>
        <translation>Nije poznato</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Nije poznato</translation>
    </message>
    <message>
        <source>&lt; 1m</source>
        <comment>&lt; 1 minute</comment>
        <translation>&lt; 1m</translation>
    </message>
    <message>
        <source>%1m</source>
        <comment>e.g: 10minutes</comment>
        <translation>%1m</translation>
    </message>
    <message>
        <source>%1h%2m</source>
        <comment>e.g: 3hours 5minutes</comment>
        <translation type="obsolete">%1s%2m</translation>
    </message>
    <message>
        <source>%1d%2h%3m</source>
        <comment>e.g: 2days 10hours 2minutes</comment>
        <translation type="obsolete">%1d%2s%3m</translation>
    </message>
    <message>
        <source>%1h %2m</source>
        <comment>e.g: 3hours 5minutes</comment>
        <translation>%1s %2m</translation>
    </message>
    <message>
        <source>%1d %2h</source>
        <comment>e.g: 2days 10hours</comment>
        <translation>%1d %2s</translation>
    </message>
    <message>
        <source>qBittorrent will shutdown the computer now because all downloads are complete.</source>
        <translation>qBittorrent će sada isključiti računalo jer su sva preuzimanja završila.</translation>
    </message>
</context>
<context>
    <name>options_imp</name>
    <message>
        <source>Choose scan directory</source>
        <translation type="obsolete">Izaberite direktorij za skeniranje</translation>
    </message>
    <message>
        <source>Choose export directory</source>
        <translation>Izaberite direktorij za izvoz</translation>
    </message>
    <message>
        <source>Choose a save directory</source>
        <translation>Izaberite direktorij za spremanje</translation>
    </message>
    <message>
        <source>Choose an ip filter file</source>
        <translation>Izaberite datoteku za ip filtriranje</translation>
    </message>
    <message>
        <source>Filters</source>
        <translation>Filteri</translation>
    </message>
    <message>
        <source>Add directory to scan</source>
        <translation>Dodaj direktorij za skeniranje</translation>
    </message>
    <message>
        <source>Folder is already being watched.</source>
        <translation>Mapa je već pregledana.</translation>
    </message>
    <message>
        <source>Folder does not exist.</source>
        <translation>Mapa ne postoji.</translation>
    </message>
    <message>
        <source>Folder is not readable.</source>
        <translation>Mapa nije čitljiva.</translation>
    </message>
    <message>
        <source>Failure</source>
        <translation>Neuspjeh</translation>
    </message>
    <message>
        <source>Failed to add Scan Folder &apos;%1&apos;: %2</source>
        <translation>Nije uspjelo dodavanje mape za skeniranje &apos;%1&apos;: %2</translation>
    </message>
    <message>
        <source>Parsing error</source>
        <translation>Greška razrješavanja</translation>
    </message>
    <message>
        <source>Failed to parse the provided IP filter</source>
        <translation>Razrješavanje danog IP filtera nije uspjelo</translation>
    </message>
    <message>
        <source>Succesfully refreshed</source>
        <translation type="obsolete">Uspješno obnovljeno</translation>
    </message>
    <message>
        <source>Successfuly parsed the provided IP filter: %1 rules were applied.</source>
        <comment>%1 is a number</comment>
        <translation>Uspješno razrješen dani IP filter: Primjenjena su %1 pravila.</translation>
    </message>
    <message>
        <source>Successfully refreshed</source>
        <translation>Uspješno obnovljeno</translation>
    </message>
    <message>
        <source>SSL Certificate (*.crt *.pem)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SSL Key (*.key *.pem)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This is not a valid SSL key.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid certificate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This is not a valid SSL certificate.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>pluginSourceDlg</name>
    <message>
        <source>Plugin source</source>
        <translation>Izvor priključka</translation>
    </message>
    <message>
        <source>Search plugin source:</source>
        <translation>Potraži izvor priključka:</translation>
    </message>
    <message>
        <source>Local file</source>
        <translation>Lokalna datoteka</translation>
    </message>
    <message>
        <source>Web link</source>
        <translation>Web link</translation>
    </message>
</context>
<context>
    <name>preview</name>
    <message>
        <source>Preview selection</source>
        <translation>Pregledaj odabir</translation>
    </message>
    <message>
        <source>File preview</source>
        <translation>Pregled datoteke</translation>
    </message>
    <message>
        <source>The following files support previewing, &lt;br&gt;please select one of them:</source>
        <translation>Sljedeće datoteke podržavaju pregledavanje, &lt;br&gt;izaberite jednu od njih:</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Pregledaj</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Odustani</translation>
    </message>
</context>
<context>
    <name>previewSelect</name>
    <message>
        <source>Preview impossible</source>
        <translation type="obsolete">Pregled nije moguć</translation>
    </message>
    <message>
        <source>Sorry, we can&apos;t preview this file</source>
        <translation type="obsolete">Oprostite, nije moguće pregledati datoteku</translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="obsolete">Ime</translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="obsolete">Veličina</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation type="obsolete">Napredak</translation>
    </message>
</context>
<context>
    <name>search_engine</name>
    <message>
        <source>Search</source>
        <translation>Traži</translation>
    </message>
    <message>
        <source>Status:</source>
        <translation>Status:</translation>
    </message>
    <message>
        <source>Stopped</source>
        <translation>Zaustavljeno</translation>
    </message>
    <message>
        <source>Download</source>
        <translation>Preuzmi</translation>
    </message>
    <message>
        <source>Search engines...</source>
        <translation>Tražilice ...</translation>
    </message>
    <message>
        <source>Go to description page</source>
        <translation>Idi na stranicu opisa</translation>
    </message>
</context>
<context>
    <name>torrentAdditionDialog</name>
    <message>
        <source>Unable to decode magnet link:</source>
        <translation>Nije moguće dekodirati magnet link:</translation>
    </message>
    <message>
        <source>Magnet Link</source>
        <translation>Magnet link</translation>
    </message>
    <message>
        <source>Unable to decode torrent file:</source>
        <translation>Nije moguće dekodirati torrent datoteku:</translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation>Preimenuj ...</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Prioritet</translation>
    </message>
    <message>
        <source>Rename the file</source>
        <translation>Preimenuj datoteku</translation>
    </message>
    <message>
        <source>New name:</source>
        <translation>Novo ime:</translation>
    </message>
    <message>
        <source>The file could not be renamed</source>
        <translation>Datoteku nije moguće preimenovati</translation>
    </message>
    <message>
        <source>This file name contains forbidden characters, please choose a different one.</source>
        <translation>Datoteka sadrži nedopuštene znakove. Izaberite drukčije znakove. </translation>
    </message>
    <message>
        <source>This name is already in use in this folder. Please use a different name.</source>
        <translation>Ime se već koristi u toj mapi. Koristite drugo ime.</translation>
    </message>
    <message>
        <source>The folder could not be renamed</source>
        <translation>Mapu nije moguće preimenovati</translation>
    </message>
    <message>
        <source>(%1 left after torrent download)</source>
        <comment>e.g. (100MiB left after torrent download)</comment>
        <translation>(%1 ostalo nakon preuzimanja torrenta)</translation>
    </message>
    <message>
        <source>(%1 more are required to download)</source>
        <comment>e.g. (100MiB more are required to download)</comment>
        <translation>(%1 više je potrebno za preuzimanje)</translation>
    </message>
    <message>
        <source>Choose save path</source>
        <translation>Izaberite putanju za spremanje</translation>
    </message>
    <message>
        <source>Empty save path</source>
        <translation>Ispraznite putanju za spremanje</translation>
    </message>
    <message>
        <source>Please enter a save path</source>
        <translation>Upišite putanju za spremanje</translation>
    </message>
    <message>
        <source>Save path creation error</source>
        <translation>Greška prilikom kreiranja putanje za spremanje</translation>
    </message>
    <message>
        <source>Could not create the save path</source>
        <translation>Nije moguće kreirati putanju za spremanje</translation>
    </message>
    <message>
        <source>Invalid label name</source>
        <translation>Neispravano ime oznake</translation>
    </message>
    <message>
        <source>Please don&apos;t use any special characters in the label name.</source>
        <translation>Nemojte koristiti nijedan poseban znak u imenu oznake.</translation>
    </message>
    <message>
        <source>Seeding mode error</source>
        <translation>Greška seeding moda</translation>
    </message>
    <message>
        <source>You chose to skip file checking. However, local files do not seem to exist in the current destionation folder. Please disable this feature or update the save path.</source>
        <translation>Izabrali ste preskočiti provjeru datoteke. Ipak, čini se da lokalne datoteke ne postoje u trenutnoj odredišnoj mapi. Onemogućite ovu značajku ili ažurirajte putanju za spremanje.</translation>
    </message>
    <message>
        <source>Invalid file selection</source>
        <translation>Neispravan odabir datoteke</translation>
    </message>
    <message>
        <source>You must select at least one file in the torrent</source>
        <translation>Morate izabrati najmanje jednu datoteku u torrentu</translation>
    </message>
</context>
</TS>
