<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>AboutDlg</name>
    <message>
        <source>About qBittorrent</source>
        <translation>Despre qBittorrent</translation>
    </message>
    <message>
        <source>About</source>
        <translation>Despre</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation>Nume:</translation>
    </message>
    <message>
        <source>Country:</source>
        <translation>Ţara:</translation>
    </message>
    <message>
        <source>E-mail:</source>
        <translation>E-Mail:</translation>
    </message>
    <message>
        <source>Christophe Dumez</source>
        <translation>Christophe Dumez</translation>
    </message>
    <message>
        <source>France</source>
        <translation>Franţa</translation>
    </message>
    <message>
        <source>Translation</source>
        <translation>Translare</translation>
    </message>
    <message>
        <source>License</source>
        <translation>Licensă</translation>
    </message>
    <message>
        <source>&lt;h3&gt;&lt;b&gt;qBittorrent&lt;/b&gt;&lt;/h3&gt;</source>
        <translation>&lt;h3&gt;&lt;b&gt;qBittorrent&lt;/b&gt;&lt;/h3&gt;</translation>
    </message>
    <message>
        <source>chris@qbittorrent.org</source>
        <translation>chris@qbittorrent.org</translation>
    </message>
    <message>
        <source>Thanks to</source>
        <translation>Mulţumesc lui</translation>
    </message>
    <message utf8="true">
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;An advanced BitTorrent client programmed in C++, based on Qt4 toolkit and libtorrent-rasterbar. &lt;br /&gt;&lt;br /&gt;Copyright ©2006-2011 Christophe Dumez&lt;br /&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Home Page:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://www.qbittorrent.org&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans&apos;; text-decoration: underline; color:#0057ae;&quot;&gt;http://www.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Bug Tracker:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://bugs.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;http://bugs.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Forum:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://forum.qbittorrent.org&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans&apos;; text-decoration: underline; color:#0057ae;&quot;&gt;http://forum.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;IRC:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; #qbittorrent on Freenode&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AdvancedSettings</name>
    <message>
        <source>Ignore transfer limits on local network</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Disk write cache size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> MiB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Outgoing ports (Min) [0: Disabled]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Outgoing ports (Max) [0: Disabled]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Recheck torrents on completion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Transfer list refresh interval</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> ms</source>
        <comment> milliseconds</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Resolve peer countries (GeoIP)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Resolve peer host names</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Maximum number of half-open connections [0: Disabled]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Strict super seeding</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Network Interface (requires restart)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Any interface</source>
        <comment>i.e. Any network interface</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable embedded tracker</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Embedded tracker port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Check for software updates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use system icon theme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confirm torrent deletion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>IP Address to report to trackers (requires restart)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Setting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Value</source>
        <comment>Value set for this setting</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Display program on-screen notifications</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exchange trackers with other peers</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AutomatedRssDownloader</name>
    <message>
        <source>Automated RSS Downloader</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable the automated RSS downloader</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Download rules</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rule definition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Must contain:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Must not contain:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>...</source>
        <translation type="unfinished">...</translation>
    </message>
    <message>
        <source>Assign label:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Apply rule to feeds:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Matching RSS articles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save to a different directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save to:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Import...</source>
        <translation type="unfinished">Import...</translation>
    </message>
    <message>
        <source>Export...</source>
        <translation type="unfinished">Export...</translation>
    </message>
    <message>
        <source>New rule name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please type the name of the new download rule.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rule name conflict</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A rule with this name already exists, please choose another name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Are you sure you want to remove the download rule named %1?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Are you sure you want to remove the selected download rules?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rule deletion confirmation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Destination directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The list is empty, there is nothing to export.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Where would you like to save the list?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rules list (*.rssrules)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>I/O Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to create the destination file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please point to the RSS download rules file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rules list (*.rssrules *.filters)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Import Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to import the selected rules file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add new rule...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete rule</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rename rule...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete selected rules</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rule renaming</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please type the new rule name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use regular expressions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Regex mode: use Perl-like regular expressions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Wildcard mode: you can use&lt;ul&gt;&lt;li&gt;? to match any single character&lt;/li&gt;&lt;li&gt;* to match zero or more of any characters&lt;/li&gt;&lt;li&gt;Whitespaces count as AND operators&lt;/li&gt;&lt;/ul&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Wildcard mode: you can use&lt;ul&gt;&lt;li&gt;? to match any single character&lt;/li&gt;&lt;li&gt;* to match zero or more of any characters&lt;/li&gt;&lt;li&gt;| is used as OR operator&lt;/li&gt;&lt;/ul&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Bittorrent</name>
    <message>
        <source>%1 reached the maximum ratio you set.</source>
        <translation type="obsolete">%1 a ajuns la rata maximă setată.</translation>
    </message>
    <message>
        <source>qBittorrent is bound to port: TCP/%1</source>
        <comment>e.g: qBittorrent is bound to port: 6881</comment>
        <translation type="obsolete">qBittorrent utilizează portul : TCP/%1</translation>
    </message>
    <message>
        <source>UPnP support [ON]</source>
        <translation type="obsolete">Suport UPnP[Activat]</translation>
    </message>
    <message>
        <source>UPnP support [OFF]</source>
        <translation type="obsolete">suport de UPnP[Dezactivat]</translation>
    </message>
    <message>
        <source>NAT-PMP support [ON]</source>
        <translation type="obsolete">suport NAT-PMP[Activat]</translation>
    </message>
    <message>
        <source>NAT-PMP support [OFF]</source>
        <translation type="obsolete">suport NAT-PMP[Dezactivat]</translation>
    </message>
    <message>
        <source>DHT support [ON], port: UDP/%1</source>
        <translation type="obsolete">DHT activat, portul : UDP/%1</translation>
    </message>
    <message>
        <source>DHT support [OFF]</source>
        <translation type="obsolete">Suport DHT[Dezactivat]</translation>
    </message>
    <message>
        <source>PeX support [ON]</source>
        <translation type="obsolete">Suport PeX[Activat]</translation>
    </message>
    <message>
        <source>Local Peer Discovery [ON]</source>
        <translation type="obsolete">Căutare peer locali[Activat]</translation>
    </message>
    <message>
        <source>Local Peer Discovery support [OFF]</source>
        <translation type="obsolete">Căutarea peer locali[Dezactivat]</translation>
    </message>
    <message>
        <source>Encryption support [ON]</source>
        <translation type="obsolete">Suport de codificate[Activat]</translation>
    </message>
    <message>
        <source>Encryption support [FORCED]</source>
        <translation type="obsolete">Suport de codificare[Forţat]</translation>
    </message>
    <message>
        <source>Encryption support [OFF]</source>
        <translation type="obsolete">Suport de codificare [Dezactivat]</translation>
    </message>
    <message>
        <source>Web User Interface Error - Unable to bind Web UI to port %1</source>
        <translation type="obsolete">Eroare în interfața Web - Nu pot conecta interfața Web cu portul %1</translation>
    </message>
    <message>
        <source>&apos;%1&apos; was removed from transfer list and hard disk.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation type="obsolete">&apos;%1&apos; a fost șters din lista de transferuri și de pe hard disk.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; was removed from transfer list.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation type="obsolete">&apos;%1&apos; a fost șters din lista de transferuri.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is not a valid magnet URI.</source>
        <translation type="obsolete">&apos;%1&apos; nu este valid URI.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is already in download list.</source>
        <comment>e.g: &apos;xxx.avi&apos; is already in download list.</comment>
        <translation type="obsolete">&apos;%1&apos; este de acum in lista de descărcare.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; resumed. (fast resume)</source>
        <comment>&apos;/home/y/xxx.torrent&apos; was resumed. (fast resume)</comment>
        <translation type="obsolete">&apos;%1&apos; resumat. (resumare rapidă)</translation>
    </message>
    <message>
        <source>&apos;%1&apos; added to download list.</source>
        <comment>&apos;/home/y/xxx.torrent&apos; was added to download list.</comment>
        <translation type="obsolete">&apos;%1&apos; adăugat la lista de descărcare.</translation>
    </message>
    <message>
        <source>Unable to decode torrent file: &apos;%1&apos;</source>
        <comment>e.g: Unable to decode torrent file: &apos;/home/y/xxx.torrent&apos;</comment>
        <translation type="obsolete">Nu pot decodifica torrent-ul : &apos;%1&apos;</translation>
    </message>
    <message>
        <source>This file is either corrupted or this isn&apos;t a torrent.</source>
        <translation type="obsolete">Acest fişier este deteriorat sau nu este torrent.</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;was blocked due to your IP filter&lt;/i&gt;</source>
        <comment>x.y.z.w was blocked</comment>
        <translation type="obsolete">&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;a fost blocat conform IP filtrului&lt;/i&gt;</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;was banned due to corrupt pieces&lt;/i&gt;</source>
        <comment>x.y.z.w was banned</comment>
        <translation type="obsolete">&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;a fost banat din cauza fragmentelor eronate&lt;/i&gt;</translation>
    </message>
    <message>
        <source>Recursive download of file %1 embedded in torrent %2</source>
        <comment>Recursive download of test.torrent embedded in torrent test2</comment>
        <translation type="obsolete">Descarcă recursiv fișierul %1 din torrentul %2</translation>
    </message>
    <message>
        <source>Unable to decode %1 torrent file.</source>
        <translation type="obsolete">Nu pot citi torrentul %1.</translation>
    </message>
    <message>
        <source>UPnP/NAT-PMP: Port mapping failure, message: %1</source>
        <translation type="obsolete">UPnP/NAT-PMP: Port mapping failure, message: %1</translation>
    </message>
    <message>
        <source>UPnP/NAT-PMP: Port mapping successful, message: %1</source>
        <translation type="obsolete">UPnP/NAT-PMP: Port mapping successful, message: %1</translation>
    </message>
    <message>
        <source>Fast resume data was rejected for torrent %1, checking again...</source>
        <translation type="obsolete">Resumarea rapidă a fost respinsă pentru torrent-ul %1, verific încă o dată...</translation>
    </message>
    <message>
        <source>Url seed lookup failed for url: %1, message: %2</source>
        <translation type="obsolete">Conectarea la seed a eşuat pentru : %1, mesajul : %2</translation>
    </message>
    <message>
        <source>Downloading &apos;%1&apos;, please wait...</source>
        <comment>e.g: Downloading &apos;xxx.torrent&apos;, please wait...</comment>
        <translation type="obsolete">Descarc &apos;%1&apos;, vă rugăm să aşteptaţi...</translation>
    </message>
    <message>
        <source>Using a disk cache size of %1 MiB</source>
        <translation type="obsolete">Utilizez cache de pe disk la %1 MiB</translation>
    </message>
    <message>
        <source>PeX support [OFF]</source>
        <translation type="obsolete">Suport PeX [Oprit]</translation>
    </message>
    <message>
        <source>Restart is required to toggle PeX support</source>
        <translation type="obsolete">Restartarea este necesară pentru a activa suport PeX</translation>
    </message>
    <message>
        <source>The Web UI is listening on port %1</source>
        <translation type="obsolete">Interfața Web este activă pe portul %1</translation>
    </message>
    <message>
        <source>HTTP user agent is %1</source>
        <translation type="obsolete">HTTP agentul este %1</translation>
    </message>
</context>
<context>
    <name>ConsoleDlg</name>
    <message>
        <source>General</source>
        <translation type="obsolete">General</translation>
    </message>
    <message>
        <source>Blocked IPs</source>
        <translation type="obsolete">IP-uri blocate</translation>
    </message>
</context>
<context>
    <name>CookiesDlg</name>
    <message>
        <source>Cookies management</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Key</source>
        <extracomment>As in Key/Value pair</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Value</source>
        <extracomment>As in Key/Value pair</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Common keys for cookies are : &apos;%1&apos;, &apos;%2&apos;.
You should get this information from your Web browser preferences.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DNSUpdater</name>
    <message>
        <source>Your dynamic DNS was successfuly updated.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dynamic DNS error: The service is temporarily unavailable, it will be retried in 30 minutes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dynamic DNS error: hostname supplied does not exist under specified account.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dynamic DNS error: Invalid username/password.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dynamic DNS error: qBittorrent was blacklisted by the service, please report a bug at http://bugs.qbittorrent.org.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dynamic DNS error: %1 was returned by the service, please report a bug at http://bugs.qbittorrent.org.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dynamic DNS error: Your username was blocked due to abuse.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dynamic DNS error: supplied domain name is invalid.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dynamic DNS error: supplied username is too short.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dynamic DNS error: supplied password is too short.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DownloadThread</name>
    <message>
        <source>I/O Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The remote host name was not found (invalid hostname)</source>
        <translation type="unfinished">Numele host-ului nu a fost găsit(nume invalid)</translation>
    </message>
    <message>
        <source>The operation was canceled</source>
        <translation type="unfinished">Operțiunea a fost anulată</translation>
    </message>
    <message>
        <source>The remote server closed the connection prematurely, before the entire reply was received and processed</source>
        <translation type="unfinished">Serverul a închis conectarea înainte ca să recepționez și proceses răspunsul</translation>
    </message>
    <message>
        <source>The connection to the remote server timed out</source>
        <translation type="unfinished">Timpul de conectare la server a expirat</translation>
    </message>
    <message>
        <source>SSL/TLS handshake failed</source>
        <translation type="unfinished">Conectarea SSL/TLS eșuată</translation>
    </message>
    <message>
        <source>The remote server refused the connection</source>
        <translation type="unfinished">Serverul refuză conectarea</translation>
    </message>
    <message>
        <source>The connection to the proxy server was refused</source>
        <translation type="unfinished">Conectarea prin proxy server refuzată</translation>
    </message>
    <message>
        <source>The proxy server closed the connection prematurely</source>
        <translation type="unfinished">Serverul proxy a închis conectarea pre deverme</translation>
    </message>
    <message>
        <source>The proxy host name was not found</source>
        <translation type="unfinished">Numele serverului proxy nu este găsit</translation>
    </message>
    <message>
        <source>The connection to the proxy timed out or the proxy did not reply in time to the request sent</source>
        <translation type="unfinished">Timpul de conectare la proxy a expirat</translation>
    </message>
    <message>
        <source>The proxy requires authentication in order to honour the request but did not accept any credentials offered</source>
        <translation type="unfinished">The proxy requires authentication in order to honour the request but did not accept any credentials offered</translation>
    </message>
    <message>
        <source>The access to the remote content was denied (401)</source>
        <translation type="unfinished">The access to the remote content was denied (401)</translation>
    </message>
    <message>
        <source>The operation requested on the remote content is not permitted</source>
        <translation type="unfinished">The operation requested on the remote content is not permitted</translation>
    </message>
    <message>
        <source>The remote content was not found at the server (404)</source>
        <translation type="unfinished">The remote content was not found at the server (404)</translation>
    </message>
    <message>
        <source>The remote server requires authentication to serve the content but the credentials provided were not accepted</source>
        <translation type="unfinished">The remote server requires authentication to serve the content but the credentials provided were not accepted</translation>
    </message>
    <message>
        <source>The Network Access API cannot honor the request because the protocol is not known</source>
        <translation type="unfinished">The Network Access API cannot honor the request because the protocol is not known</translation>
    </message>
    <message>
        <source>The requested operation is invalid for this protocol</source>
        <translation type="unfinished">The requested operation is invalid for this protocol</translation>
    </message>
    <message>
        <source>An unknown network-related error was detected</source>
        <translation type="unfinished">An unknown network-related error was detected</translation>
    </message>
    <message>
        <source>An unknown proxy-related error was detected</source>
        <translation type="unfinished">An unknown proxy-related error was detected</translation>
    </message>
    <message>
        <source>An unknown error related to the remote content was detected</source>
        <translation type="unfinished">An unknown error related to the remote content was detected</translation>
    </message>
    <message>
        <source>A breakdown in protocol was detected</source>
        <translation type="unfinished">A breakdown in protocol was detected</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation type="unfinished">Eroare necunoscută</translation>
    </message>
</context>
<context>
    <name>EventManager</name>
    <message>
        <source>%1/s</source>
        <comment>e.g. 120 KiB/s</comment>
        <translation>%1/s</translation>
    </message>
    <message>
        <source>Working</source>
        <translation>Lucrează</translation>
    </message>
    <message>
        <source>Updating...</source>
        <translation>Reînnoire...</translation>
    </message>
    <message>
        <source>Not working</source>
        <translation>Nu lucrează</translation>
    </message>
    <message>
        <source>Not contacted yet</source>
        <translation>Nu a fost contactat</translation>
    </message>
    <message>
        <source>this session</source>
        <translation>sesiunea aceasta</translation>
    </message>
    <message>
        <source>/s</source>
        <comment>/second (i.e. per second)</comment>
        <translation>/s</translation>
    </message>
    <message>
        <source>Seeded for %1</source>
        <comment>e.g. Seeded for 3m10s</comment>
        <translation>Sedat pentru %1</translation>
    </message>
    <message>
        <source>%1 max</source>
        <comment>e.g. 10 max</comment>
        <translation>%1 max</translation>
    </message>
</context>
<context>
    <name>ExecutionLog</name>
    <message>
        <source>General</source>
        <translation type="unfinished">General</translation>
    </message>
    <message>
        <source>Blocked IPs</source>
        <translation type="unfinished">IP-uri blocate</translation>
    </message>
</context>
<context>
    <name>FeedDownloader</name>
    <message>
        <source>RSS Feed downloader</source>
        <translation type="obsolete">RSS Feed download-er</translation>
    </message>
    <message>
        <source>RSS feed:</source>
        <translation type="obsolete">Feed RSS:</translation>
    </message>
    <message>
        <source>Feed name</source>
        <translation type="obsolete">Numele la Feed</translation>
    </message>
    <message>
        <source>Automatically download torrents from this feed</source>
        <translation type="obsolete">Automat descarcă torrente din acest feed</translation>
    </message>
    <message>
        <source>Download filters</source>
        <translation type="obsolete">Filtre de descărcare</translation>
    </message>
    <message>
        <source>Filters:</source>
        <translation type="obsolete">Filtre:</translation>
    </message>
    <message>
        <source>Filter settings</source>
        <translation type="obsolete">Stările filtrului</translation>
    </message>
    <message>
        <source>Matches:</source>
        <translation type="obsolete">Coincidențe:</translation>
    </message>
    <message>
        <source>Does not match:</source>
        <translation type="obsolete">Nu coincide:</translation>
    </message>
    <message>
        <source>Destination folder:</source>
        <translation type="obsolete">Directoriul destinație:</translation>
    </message>
    <message>
        <source>...</source>
        <translation type="obsolete">...</translation>
    </message>
    <message>
        <source>Filter testing</source>
        <translation type="obsolete">Setările filtrului</translation>
    </message>
    <message>
        <source>Torrent title:</source>
        <translation type="obsolete">Titlul torrent-ului:</translation>
    </message>
    <message>
        <source>Result:</source>
        <translation type="obsolete">Rezultat:</translation>
    </message>
    <message>
        <source>Test</source>
        <translation type="obsolete">Test</translation>
    </message>
    <message>
        <source>Import...</source>
        <translation type="obsolete">Import...</translation>
    </message>
    <message>
        <source>Export...</source>
        <translation type="obsolete">Export...</translation>
    </message>
    <message>
        <source>Rename filter</source>
        <translation type="obsolete">Redenumirea filtrului</translation>
    </message>
    <message>
        <source>Remove filter</source>
        <translation type="obsolete">Șterge filtrul</translation>
    </message>
    <message>
        <source>Add filter</source>
        <translation type="obsolete">Adaugă filtrul</translation>
    </message>
</context>
<context>
    <name>FeedDownloaderDlg</name>
    <message>
        <source>New filter</source>
        <translation type="obsolete">Nou filtru</translation>
    </message>
    <message>
        <source>Please choose a name for this filter</source>
        <translation type="obsolete">Alegeți un nume pentru acest filtru</translation>
    </message>
    <message>
        <source>Filter name:</source>
        <translation type="obsolete">Numele filtrului:</translation>
    </message>
    <message>
        <source>Invalid filter name</source>
        <translation type="obsolete">Numele filtrului invalid</translation>
    </message>
    <message>
        <source>The filter name cannot be left empty.</source>
        <translation type="obsolete">Numele filtrului nu poate fi vid.</translation>
    </message>
    <message>
        <source>This filter name is already in use.</source>
        <translation type="obsolete">Nume de filtru existent.</translation>
    </message>
    <message>
        <source>Filter testing error</source>
        <translation type="obsolete">Filtrul testare eroare</translation>
    </message>
    <message>
        <source>Please specify a test torrent name.</source>
        <translation type="obsolete">Specificați un nume de test a torrent-ului.</translation>
    </message>
    <message>
        <source>matches</source>
        <translation type="obsolete">coincidenț</translation>
    </message>
    <message>
        <source>does not match</source>
        <translation type="obsolete">nu coincide</translation>
    </message>
    <message>
        <source>Select file to import</source>
        <translation type="obsolete">Alegeți fișier pentru import</translation>
    </message>
    <message>
        <source>Filters Files</source>
        <translation type="obsolete">Filtrează Fișiere</translation>
    </message>
    <message>
        <source>Import successful</source>
        <translation type="obsolete">Import cu success</translation>
    </message>
    <message>
        <source>Filters import was successful.</source>
        <translation type="obsolete">Importul filtrelor a fost cu success.</translation>
    </message>
    <message>
        <source>Import failure</source>
        <translation type="obsolete">Importează failure</translation>
    </message>
    <message>
        <source>Filters could not be imported due to an I/O error.</source>
        <translation type="obsolete">Filtrele nu pot fi importate din cauza erorilor I/O.</translation>
    </message>
    <message>
        <source>Select destination file</source>
        <translation type="obsolete">Selectează fișierul de destinație</translation>
    </message>
    <message>
        <source>Export successful</source>
        <translation type="obsolete">Export cu success</translation>
    </message>
    <message>
        <source>Filters export was successful.</source>
        <translation type="obsolete">Exportul filtrelor a fost cu success.</translation>
    </message>
    <message>
        <source>Export failure</source>
        <translation type="obsolete">Export eșuat</translation>
    </message>
    <message>
        <source>Filters could not be exported due to an I/O error.</source>
        <translation type="obsolete">Filtrele nu pot fi exportate din cauza erorilor I/O.</translation>
    </message>
    <message>
        <source>Choose save path</source>
        <translation type="obsolete">Alegeţi calea de salvare</translation>
    </message>
</context>
<context>
    <name>FeedList</name>
    <message>
        <source>Unread</source>
        <translation type="obsolete">Necitit</translation>
    </message>
</context>
<context>
    <name>FeedListWidget</name>
    <message>
        <source>RSS feeds</source>
        <translation type="unfinished">RSS feed-uri</translation>
    </message>
    <message>
        <source>Unread</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GUI</name>
    <message>
        <source>Open Torrent Files</source>
        <translation type="obsolete">Deschide Fişiere Torrent</translation>
    </message>
    <message>
        <source>Torrent Files</source>
        <translation type="obsolete">Fişiere Torrent</translation>
    </message>
    <message>
        <source>qBittorrent</source>
        <translation type="obsolete">qBittorrent</translation>
    </message>
    <message>
        <source>Transfers</source>
        <translation type="obsolete">Transferuri</translation>
    </message>
    <message>
        <source>qBittorrent %1</source>
        <comment>e.g: qBittorrent v0.x</comment>
        <translation type="obsolete">qBittorrent %1</translation>
    </message>
    <message>
        <source>DL speed: %1 KiB/s</source>
        <comment>e.g: Download speed: 10 KiB/s</comment>
        <translation type="obsolete">Viteza DL: %1 KiB/s</translation>
    </message>
    <message>
        <source>UP speed: %1 KiB/s</source>
        <comment>e.g: Upload speed: 10 KiB/s</comment>
        <translation type="obsolete">Viteza IP: %1 KiB/s</translation>
    </message>
    <message>
        <source>%1 has finished downloading.</source>
        <comment>e.g: xxx.avi has finished downloading.</comment>
        <translation type="obsolete">%1 a fost terminat de descărcat.</translation>
    </message>
    <message>
        <source>I/O Error</source>
        <comment>i.e: Input/Output Error</comment>
        <translation type="obsolete">Eroare de intrare/eşire</translation>
    </message>
    <message>
        <source>Search</source>
        <translation type="obsolete">Caută</translation>
    </message>
    <message>
        <source>RSS</source>
        <translation type="obsolete">RSS</translation>
    </message>
    <message>
        <source>Alt+1</source>
        <comment>shortcut to switch to first tab</comment>
        <translation type="obsolete">Alt+1</translation>
    </message>
    <message>
        <source>An I/O error occured for torrent %1.
 Reason: %2</source>
        <comment>e.g: An error occured for torrent xxx.avi.
 Reason: disk is full.</comment>
        <translation type="obsolete">Eroare de intrare/ieșire pentru torrent-ul %1.
Motivul : %2</translation>
    </message>
    <message>
        <source>Url download error</source>
        <translation type="obsolete">Eroare la descărcare URL</translation>
    </message>
    <message>
        <source>Couldn&apos;t download file at url: %1, reason: %2.</source>
        <translation type="obsolete">Nu pot descărca fisierul de pe url: %1, motivul: %2.</translation>
    </message>
    <message>
        <source>Ctrl+F</source>
        <comment>shortcut to switch to search tab</comment>
        <translation type="obsolete">Ctrl+F</translation>
    </message>
    <message>
        <source>Options were saved successfully.</source>
        <translation type="obsolete">Opţiunile salvate cu success.</translation>
    </message>
    <message>
        <source>Download completion</source>
        <translation type="obsolete">Descărcarea completată</translation>
    </message>
    <message>
        <source>Some files are currently transferring.
Are you sure you want to quit qBittorrent?</source>
        <translation type="obsolete">Unele fișiere sunt transferate acum.
Sunteți siguri că doriți să închideți qBittorrent?</translation>
    </message>
    <message>
        <source>Alt+2</source>
        <comment>shortcut to switch to third tab</comment>
        <translation type="obsolete">Alt+2</translation>
    </message>
    <message>
        <source>Alt+3</source>
        <comment>shortcut to switch to fourth tab</comment>
        <translation type="obsolete">Alt+3</translation>
    </message>
    <message>
        <source>Global Upload Speed Limit</source>
        <translation type="obsolete">Limita de upload globală</translation>
    </message>
    <message>
        <source>Global Download Speed Limit</source>
        <translation type="obsolete">Limita de download globală</translation>
    </message>
    <message>
        <source>qBittorrent %1 (Down: %2/s, Up: %3/s)</source>
        <comment>%1 is qBittorrent version</comment>
        <translation type="obsolete">qBittorrent %1 (Down: %2/s, Up: %3/s)</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation type="obsolete">Da</translation>
    </message>
    <message>
        <source>No</source>
        <translation type="obsolete">Ny</translation>
    </message>
    <message>
        <source>Never</source>
        <translation type="obsolete">Niciodată</translation>
    </message>
</context>
<context>
    <name>GeoIP</name>
    <message>
        <source>France</source>
        <translation type="obsolete">Franţa</translation>
    </message>
</context>
<context>
    <name>HeadlessLoader</name>
    <message>
        <source>Information</source>
        <translation>Informație</translation>
    </message>
    <message>
        <source>To control qBittorrent, access the Web UI at http://localhost:%1</source>
        <translation>Pentru a controla qBittorrent, acesați interfața Web prin http://localhost:%1</translation>
    </message>
    <message>
        <source>The Web UI administrator user name is: %1</source>
        <translation>Numele administratorului interfeței web este: %1</translation>
    </message>
    <message>
        <source>The Web UI administrator password is still the default one: %1</source>
        <translation>Parola de acces a administratorului prin interfața Web este implicită : %1</translation>
    </message>
    <message>
        <source>This is a security risk, please consider changing your password from program preferences.</source>
        <translation>Aceasta este un risc de securitate, schimbati parola de acces din preferințe.</translation>
    </message>
</context>
<context>
    <name>HttpConnection</name>
    <message>
        <source>Your IP address has been banned after too many failed authentication attempts.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>D: %1/s - T: %2</source>
        <comment>Download speed: x KiB/s - Transferred: x MiB</comment>
        <translation type="unfinished">D: %1/s - T: %2</translation>
    </message>
    <message>
        <source>U: %1/s - T: %2</source>
        <comment>Upload speed: x KiB/s - Transferred: x MiB</comment>
        <translation type="unfinished">U: %1/s - T: %2</translation>
    </message>
</context>
<context>
    <name>HttpServer</name>
    <message>
        <source>File</source>
        <translation>Fișier</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editare</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Ajutor</translation>
    </message>
    <message>
        <source>Delete from HD</source>
        <translation type="obsolete">Șterge de pe Hard Disc</translation>
    </message>
    <message>
        <source>Download Torrents from their URL or Magnet link</source>
        <translation>Descarcă fișierele torrent din URL sau link Magnet</translation>
    </message>
    <message>
        <source>Only one link per line</source>
        <translation>Numai un link pe linie</translation>
    </message>
    <message>
        <source>Download</source>
        <translation>Descarcă</translation>
    </message>
    <message>
        <source>Download local torrent</source>
        <translation>Descarcă torrent-ul local</translation>
    </message>
    <message>
        <source>Torrent files were correctly added to download list.</source>
        <translation>Fișierele torrent care sunt correct adăugate la lista de descărcare.</translation>
    </message>
    <message>
        <source>Point to torrent file</source>
        <translation>Arată fișierul torrent</translation>
    </message>
    <message>
        <source>Are you sure you want to delete the selected torrents from the transfer list and hard disk?</source>
        <translation>Doriți să ștergeți torrent-urile selectate de pe hard disk ?</translation>
    </message>
    <message>
        <source>Download rate limit must be greater than 0 or disabled.</source>
        <translation>Limita de descărcare trebuie să fie mai mare ca 0 sau deactivată.</translation>
    </message>
    <message>
        <source>Upload rate limit must be greater than 0 or disabled.</source>
        <translation>Upload rate limit must be greater than 0 or disabled.</translation>
    </message>
    <message>
        <source>Maximum number of connections limit must be greater than 0 or disabled.</source>
        <translation>Maximum number of connections limit must be greater than 0 or disabled.</translation>
    </message>
    <message>
        <source>Maximum number of connections per torrent limit must be greater than 0 or disabled.</source>
        <translation>Maximum number of connections per torrent limit must be greater than 0 or disabled.</translation>
    </message>
    <message>
        <source>Maximum number of upload slots per torrent limit must be greater than 0 or disabled.</source>
        <translation>Maximum number of upload slots per torrent limit must be greater than 0 or disabled.</translation>
    </message>
    <message>
        <source>Unable to save program preferences, qBittorrent is probably unreachable.</source>
        <translation>Unable to save program preferences, qBittorrent is probably unreachable.</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Limba</translation>
    </message>
    <message>
        <source>The port used for incoming connections must be greater than 1024 and less than 65535.</source>
        <translation>The port used for incoming connections must be greater than 1024 and less than 65535.</translation>
    </message>
    <message>
        <source>The port used for the Web UI must be greater than 1024 and less than 65535.</source>
        <translation>The port used for the Web UI must be greater than 1024 and less than 65535.</translation>
    </message>
    <message>
        <source>The Web UI username must be at least 3 characters long.</source>
        <translation>The Web UI username must be at least 3 characters long.</translation>
    </message>
    <message>
        <source>The Web UI password must be at least 3 characters long.</source>
        <translation>The Web UI password must be at least 3 characters long.</translation>
    </message>
    <message>
        <source>Downloaded</source>
        <comment>Is the file downloaded or not?</comment>
        <translation>Descărcat</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>qBittorrent client is not reachable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>HTTP Server</source>
        <translation type="unfinished">HTTP Server</translation>
    </message>
    <message>
        <source>Torrent path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Torrent name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The following parameters are supported:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LegalNotice</name>
    <message>
        <source>Legal Notice</source>
        <translation>Notă legală</translation>
    </message>
    <message>
        <source>Legal notice</source>
        <translation>Notă legală</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Anulare</translation>
    </message>
    <message>
        <source>I Agree</source>
        <translation>Acceptare</translation>
    </message>
    <message>
        <source>qBittorrent is a file sharing program. When you run a torrent, its data will be made available to others by means of upload. Any content you share is your sole responsibility.

No further notices will be issued.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Press %1 key to accept and continue...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LineEdit</name>
    <message>
        <source>Clear the text</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>&amp;Edit</source>
        <translation>&amp;Editare</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Fişier</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Ajutor</translation>
    </message>
    <message>
        <source>Preview file</source>
        <translation type="obsolete">Preview fişier</translation>
    </message>
    <message>
        <source>Clear log</source>
        <translation type="obsolete">Curăţă log-ul</translation>
    </message>
    <message>
        <source>Decrease priority</source>
        <translation>Decrementează prioritatea</translation>
    </message>
    <message>
        <source>Increase priority</source>
        <translation>Incrementează prioritatea</translation>
    </message>
    <message>
        <source>&amp;Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Options...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Torrent &amp;creator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set upload limit...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set download limit...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set global download limit...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set global upload limit...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Top &amp;tool bar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Display top tool bar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Speed in title bar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show transfer speed in title bar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alternative speed limits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Pause</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>P&amp;ause All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Visit &amp;Website</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Report a &amp;bug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Documentation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;RSS reader</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search &amp;engine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lock qBittorrent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+L</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Resume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>R&amp;esume All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Import torrent...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Donate money</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If you like qBittorrent, please donate!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>qBittorrent %1</source>
        <comment>e.g: qBittorrent v0.x</comment>
        <translation type="unfinished">qBittorrent %1</translation>
    </message>
    <message>
        <source>Set the password...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Transfers</source>
        <translation type="unfinished">Transferuri</translation>
    </message>
    <message>
        <source>Torrent file association</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>qBittorrent is not the default application to open torrent files or Magnet links.
Do you want to associate qBittorrent to torrent files and Magnet links?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>UI lock password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please type the UI lock password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Password update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The UI lock password has been successfully updated</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>RSS</source>
        <translation type="unfinished">RSS</translation>
    </message>
    <message>
        <source>Search</source>
        <translation type="unfinished">Caută</translation>
    </message>
    <message>
        <source>Transfers (%1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Download completion</source>
        <translation type="unfinished">Descărcarea completată</translation>
    </message>
    <message>
        <source>%1 has finished downloading.</source>
        <comment>e.g: xxx.avi has finished downloading.</comment>
        <translation type="unfinished">%1 a fost terminat de descărcat.</translation>
    </message>
    <message>
        <source>I/O Error</source>
        <comment>i.e: Input/Output Error</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>An I/O error occured for torrent %1.
 Reason: %2</source>
        <comment>e.g: An error occured for torrent xxx.avi.
 Reason: disk is full.</comment>
        <translation type="unfinished">Eroare de intrare/ieșire pentru torrent-ul %1.
Motivul : %2</translation>
    </message>
    <message>
        <source>Alt+1</source>
        <comment>shortcut to switch to first tab</comment>
        <translation type="unfinished">Alt+1</translation>
    </message>
    <message>
        <source>Alt+2</source>
        <comment>shortcut to switch to third tab</comment>
        <translation type="unfinished">Alt+2</translation>
    </message>
    <message>
        <source>Ctrl+F</source>
        <comment>shortcut to switch to search tab</comment>
        <translation type="unfinished">Ctrl+F</translation>
    </message>
    <message>
        <source>Alt+3</source>
        <comment>shortcut to switch to fourth tab</comment>
        <translation type="unfinished">Alt+3</translation>
    </message>
    <message>
        <source>Recursive download confirmation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The torrent %1 contains torrent files, do you want to proceed with their download?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Yes</source>
        <translation type="unfinished">Da</translation>
    </message>
    <message>
        <source>No</source>
        <translation type="unfinished">Ny</translation>
    </message>
    <message>
        <source>Never</source>
        <translation type="unfinished">Niciodată</translation>
    </message>
    <message>
        <source>Url download error</source>
        <translation type="unfinished">Eroare la descărcare URL</translation>
    </message>
    <message>
        <source>Couldn&apos;t download file at url: %1, reason: %2.</source>
        <translation type="unfinished">Nu pot descărca fisierul de pe url: %1, motivul: %2.</translation>
    </message>
    <message>
        <source>Global Upload Speed Limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Global Download Speed Limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The password is invalid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exiting qBittorrent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Some files are currently transferring.
Are you sure you want to quit qBittorrent?</source>
        <translation type="unfinished">Unele fișiere sunt transferate acum.
Sunteți siguri că doriți să închideți qBittorrent?</translation>
    </message>
    <message>
        <source>Always</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open Torrent Files</source>
        <translation type="unfinished">Deschide Fişiere Torrent</translation>
    </message>
    <message>
        <source>Torrent Files</source>
        <translation type="unfinished">Fişiere Torrent</translation>
    </message>
    <message>
        <source>Options were saved successfully.</source>
        <translation type="unfinished">Opţiunile salvate cu success.</translation>
    </message>
    <message>
        <source>qBittorrent</source>
        <translation type="unfinished">qBittorrent</translation>
    </message>
    <message>
        <source>DL speed: %1 KiB/s</source>
        <comment>e.g: Download speed: 10 KiB/s</comment>
        <translation type="unfinished">Viteza DL: %1 KiB/s</translation>
    </message>
    <message>
        <source>UP speed: %1 KiB/s</source>
        <comment>e.g: Upload speed: 10 KiB/s</comment>
        <translation type="unfinished">Viteza IP: %1 KiB/s</translation>
    </message>
    <message>
        <source>qBittorrent %1 (Down: %2/s, Up: %3/s)</source>
        <comment>%1 is qBittorrent version</comment>
        <translation type="unfinished">qBittorrent %1 (Down: %2/s, Up: %3/s)</translation>
    </message>
    <message>
        <source>A newer version is available</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A newer version of qBittorrent is available on Sourceforge.
Would you like to update qBittorrent to version %1?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Impossible to update qBittorrent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>qBittorrent failed to update, reason: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Add torrent file...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add &amp;link to torrent...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Import existing torrent...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Execution &amp;Log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Execution Log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Auto-Shutdown on downloads completion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exit qBittorrent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Suspend system</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shutdown system</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The password should contain at least 3 characters</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PeerAdditionDlg</name>
    <message>
        <source>Invalid IP</source>
        <translation>IP greşit</translation>
    </message>
    <message>
        <source>The IP you provided is invalid.</source>
        <translation>IP-ul introdus este greșit.</translation>
    </message>
</context>
<context>
    <name>PeerListDelegate</name>
    <message>
        <source>/s</source>
        <comment>/second (i.e. per second)</comment>
        <translation type="unfinished">/s</translation>
    </message>
</context>
<context>
    <name>PeerListWidget</name>
    <message>
        <source>IP</source>
        <translation>IP</translation>
    </message>
    <message>
        <source>Client</source>
        <comment>i.e.: Client application</comment>
        <translation>Client</translation>
    </message>
    <message>
        <source>Progress</source>
        <comment>i.e: % downloaded</comment>
        <translation>Progress</translation>
    </message>
    <message>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Viteza de descărcare</translation>
    </message>
    <message>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>VIteza de încărcare</translation>
    </message>
    <message>
        <source>Downloaded</source>
        <comment>i.e: total data downloaded</comment>
        <translation>Descărcat</translation>
    </message>
    <message>
        <source>Uploaded</source>
        <comment>i.e: total data uploaded</comment>
        <translation>Încărcat</translation>
    </message>
    <message>
        <source>Ban peer permanently</source>
        <translation>Banează peer-ul permanent</translation>
    </message>
    <message>
        <source>Peer addition</source>
        <translation>Adăugă peer</translation>
    </message>
    <message>
        <source>The peer was added to this torrent.</source>
        <translation>Peer a fost adăugat la torrent.</translation>
    </message>
    <message>
        <source>The peer could not be added to this torrent.</source>
        <translation>Peer-ul nu poate fi adăugat la acest torrent.</translation>
    </message>
    <message>
        <source>Are you sure? -- qBittorrent</source>
        <translation>Sunteţi siguri? -- qBittorrent</translation>
    </message>
    <message>
        <source>Are you sure you want to ban permanently the selected peers?</source>
        <translation>Sunteți siguri că doriți să banați peer-ii selectați ?</translation>
    </message>
    <message>
        <source>&amp;Yes</source>
        <translation>&amp;Yes</translation>
    </message>
    <message>
        <source>&amp;No</source>
        <translation>&amp;No</translation>
    </message>
    <message>
        <source>Manually banning peer %1...</source>
        <translation>Manual banez peer-ul %1...</translation>
    </message>
    <message>
        <source>Upload rate limiting</source>
        <translation>Reînnoiește rata de încărcare</translation>
    </message>
    <message>
        <source>Download rate limiting</source>
        <translation>Reînnoiește rata de descărcare</translation>
    </message>
    <message>
        <source>Add a new peer...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Limit download rate...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Limit upload rate...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy IP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Connection</source>
        <translation type="unfinished">Conectare</translation>
    </message>
</context>
<context>
    <name>Preferences</name>
    <message>
        <source>UI</source>
        <extracomment>User Interface</extracomment>
        <translation type="obsolete">UI</translation>
    </message>
    <message>
        <source>Downloads</source>
        <translation>Descărcări</translation>
    </message>
    <message>
        <source>Connection</source>
        <translation>Conectare</translation>
    </message>
    <message>
        <source>Bittorrent</source>
        <translation type="obsolete">Bittorrent</translation>
    </message>
    <message>
        <source>Proxy</source>
        <translation type="obsolete">Proxy</translation>
    </message>
    <message>
        <source>Web UI</source>
        <translation>Interfață Web</translation>
    </message>
    <message>
        <source>Language:</source>
        <translation type="obsolete">Limbă:</translation>
    </message>
    <message>
        <source>(Requires restart)</source>
        <translation>(Necesită restartare)</translation>
    </message>
    <message>
        <source>Visual style:</source>
        <translation type="obsolete">Stilul vizual:</translation>
    </message>
    <message>
        <source>Transfer list</source>
        <translation type="obsolete">Transfer list</translation>
    </message>
    <message>
        <source>Use alternating row colors</source>
        <extracomment>In transfer list, one every two rows will have grey background.</extracomment>
        <translation>Use alternating row colors</translation>
    </message>
    <message>
        <source>File system</source>
        <translation type="obsolete">Sistem de fișiere</translation>
    </message>
    <message>
        <source>Torrent queueing</source>
        <translation type="obsolete">Torrent queueing</translation>
    </message>
    <message>
        <source>Maximum active downloads:</source>
        <translation>Numărul maxim de download-uri active:</translation>
    </message>
    <message>
        <source>Maximum active uploads:</source>
        <translation>Numărul maxim de încărcări active:</translation>
    </message>
    <message>
        <source>Maximum active torrents:</source>
        <translation>Numărul maxim de torrente active:</translation>
    </message>
    <message>
        <source>When adding a torrent</source>
        <translation>When adding a torrent</translation>
    </message>
    <message>
        <source>Display torrent content and some options</source>
        <translation>Afișează conținutul torrent-ului și unele opțiuni</translation>
    </message>
    <message>
        <source>Listening port</source>
        <translation type="obsolete">Portul ascultat</translation>
    </message>
    <message>
        <source>Port used for incoming connections:</source>
        <translation>Port used for incoming connections:</translation>
    </message>
    <message>
        <source>Random</source>
        <translation>Aleator</translation>
    </message>
    <message>
        <source>Enable UPnP port mapping</source>
        <translation type="obsolete">Activează maparea UPnP a porturilor</translation>
    </message>
    <message>
        <source>Enable NAT-PMP port mapping</source>
        <translation type="obsolete">Enable NAT-PMP port mapping</translation>
    </message>
    <message>
        <source>Connections limit</source>
        <translation type="obsolete">Limită de conectări</translation>
    </message>
    <message>
        <source>Global maximum number of connections:</source>
        <translation>Global maximum number of connections:</translation>
    </message>
    <message>
        <source>Maximum number of connections per torrent:</source>
        <translation>Maximum number of connections per torrent:</translation>
    </message>
    <message>
        <source>Maximum number of upload slots per torrent:</source>
        <translation>Maximum number of upload slots per torrent:</translation>
    </message>
    <message>
        <source>Upload:</source>
        <translation>Upload:</translation>
    </message>
    <message>
        <source>Download:</source>
        <translation>Download:</translation>
    </message>
    <message>
        <source>KiB/s</source>
        <translation>KiB/s</translation>
    </message>
    <message>
        <source>Bittorrent features</source>
        <translation type="obsolete">Bittorrent features</translation>
    </message>
    <message>
        <source>Enable DHT network (decentralized)</source>
        <translation type="obsolete">Enable DHT network (decentralized)</translation>
    </message>
    <message>
        <source>Use a different port for DHT and Bittorrent</source>
        <translation type="obsolete">Use a different port for DHT and Bittorrent</translation>
    </message>
    <message>
        <source>DHT port:</source>
        <translation>Portul DHT:</translation>
    </message>
    <message>
        <source>Enable Peer Exchange / PeX (requires restart)</source>
        <translation type="obsolete">Enable Peer Exchange / PeX (requires restart)</translation>
    </message>
    <message>
        <source>Enable Local Peer Discovery</source>
        <translation type="obsolete">Enable Local Peer Discovery</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation type="obsolete">Enabled</translation>
    </message>
    <message>
        <source>Forced</source>
        <translation type="obsolete">Forced</translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation type="obsolete">Disabled</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation>Type:</translation>
    </message>
    <message>
        <source>(None)</source>
        <translation>(None)</translation>
    </message>
    <message>
        <source>HTTP</source>
        <translation>HTTP</translation>
    </message>
    <message>
        <source>Port:</source>
        <translation>Port:</translation>
    </message>
    <message>
        <source>Authentication</source>
        <translation>Authentication</translation>
    </message>
    <message>
        <source>Username:</source>
        <translation>Username:</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation>Password:</translation>
    </message>
    <message>
        <source>SOCKS5</source>
        <translation>SOCKS5</translation>
    </message>
    <message>
        <source>HTTP Server</source>
        <translation type="obsolete">HTTP Server</translation>
    </message>
    <message>
        <source>Filter path (.dat, .p2p, .p2b):</source>
        <translation>Filter path (.dat, .p2p, .p2b):</translation>
    </message>
    <message>
        <source>HTTP Communications (trackers, Web seeds, search engine)</source>
        <translation type="obsolete">HTTP Communications (trackers, Web seeds, search engine)</translation>
    </message>
    <message>
        <source>Host:</source>
        <translation>Host:</translation>
    </message>
    <message>
        <source>Peer Communications</source>
        <translation type="obsolete">Peer Communications</translation>
    </message>
    <message>
        <source>SOCKS4</source>
        <translation>SOCKS4</translation>
    </message>
    <message>
        <source>Speed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>to</source>
        <extracomment>time1 to time2</extracomment>
        <translation type="unfinished">la</translation>
    </message>
    <message>
        <source>Every day</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Week days</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Week ends</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy .torrent files to:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="unfinished">Opţiuni</translation>
    </message>
    <message>
        <source>Action on double-click</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Downloading torrents:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open destination folder</source>
        <translation type="unfinished">Deschide directoriul destinaţie</translation>
    </message>
    <message>
        <source>Completed torrents:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Desktop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show splash screen on start up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Start qBittorrent minimized</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Minimize qBittorrent to notification area</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close qBittorrent to notification area</source>
        <comment>i.e: The systray tray icon will still be visible when closing the main window.</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do not start the download automatically</source>
        <comment>The torrent will be added to download list in pause state</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save files to location:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Append the label of the torrent to the save path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pre-allocate disk space for all files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Keep incomplete torrents in:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Automatically add torrents from:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add folder...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>IP Filtering</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>from</source>
        <extracomment>from (time1 to time2)</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>When:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Look for peers on your local network</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable Web User Interface (Remote control)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Seed torrents until their ratio reaches</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>then</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pause them</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove them</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Exchange peers with compatible Bittorrent clients (µTorrent, Vuze, ...)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email notification upon download completion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Destination email:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SMTP server:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Run an external program on torrent completion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>BitTorrent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Start / Stop Torrent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use UPnP / NAT-PMP port forwarding from my router</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Privacy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable DHT (decentralized network) to find more peers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use a different port for DHT and BitTorrent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable Peer Exchange (PeX) to find more peers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable Local Peer Discovery to find more peers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Encryption mode:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Prefer encryption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Require encryption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Disable encryption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reload the filter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Behavior</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Language</source>
        <translation type="unfinished">Limba</translation>
    </message>
    <message>
        <source>Power Management</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inhibit system sleep when torrents are active</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bypass authentication for localhost</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ask for program exit confirmation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The following parameters are supported:
&lt;ul&gt;
&lt;li&gt;%f: Torrent path&lt;/li&gt;
&lt;li&gt;%n: Torrent name&lt;/li&gt;
&lt;/ul&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tray icon style:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Normal</source>
        <translation type="unfinished">Normal</translation>
    </message>
    <message>
        <source>Monochrome (Dark theme)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Monochrome (Light theme)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This server requires a secure connection (SSL)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User Interface Language:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Transfer List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show qBittorrent in notification area</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hard Disk</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Listening Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Connections Limits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Proxy Server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Torrent Queueing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Share Ratio Limiting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use UPnP / NAT-PMP to forward the port from my router</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Update my dynamic domain name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Service:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Register</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Domain name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Global Rate Limits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Apply rate limit to uTP connections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Apply rate limit to transport overhead</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alternative Global Rate Limits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Schedule the use of alternative rate limits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable bandwidth management (uTP)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Otherwise, the proxy server is only used for tracker connections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use proxy for peer connections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Append .!qB extension to incomplete files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use HTTPS instead of HTTP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Import SSL Certificate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Import SSL Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Certificate:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Key:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;a href=http://httpd.apache.org/docs/2.1/ssl/ssl_faq.html#aboutcerts&gt;Information about certificates&lt;/a&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PreviewSelect</name>
    <message>
        <source>Name</source>
        <translation type="unfinished">Nume</translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="unfinished">Capacitate</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation type="unfinished">Progress</translation>
    </message>
    <message>
        <source>Preview impossible</source>
        <translation type="unfinished">Preview imposibil</translation>
    </message>
    <message>
        <source>Sorry, we can&apos;t preview this file</source>
        <translation type="unfinished">Nu putem face preview pentru acest fişier</translation>
    </message>
</context>
<context>
    <name>PropListDelegate</name>
    <message>
        <source>Normal</source>
        <comment>Normal (priority)</comment>
        <translation type="unfinished">Normal</translation>
    </message>
    <message>
        <source>High</source>
        <comment>High (priority)</comment>
        <translation type="unfinished">Înaltă</translation>
    </message>
    <message>
        <source>Maximum</source>
        <comment>Maximum (priority)</comment>
        <translation type="unfinished">Maximală</translation>
    </message>
    <message>
        <source>Not downloaded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mixed</source>
        <comment>Mixed (priorities</comment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PropTabBar</name>
    <message>
        <source>General</source>
        <translation type="unfinished">General</translation>
    </message>
    <message>
        <source>Trackers</source>
        <translation type="unfinished">Trackeri</translation>
    </message>
    <message>
        <source>Peers</source>
        <translation type="unfinished">Peer-i</translation>
    </message>
    <message>
        <source>Files</source>
        <translation type="obsolete">Fișiere</translation>
    </message>
    <message>
        <source>HTTP Sources</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Content</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PropertiesWidget</name>
    <message>
        <source>Save path:</source>
        <translation>Calea de salvare:</translation>
    </message>
    <message>
        <source>Torrent hash:</source>
        <translation>Hash-ul torrentului:</translation>
    </message>
    <message>
        <source>Comment:</source>
        <translation>Comentarii:</translation>
    </message>
    <message>
        <source>Share ratio:</source>
        <translation>Raţia de Share:</translation>
    </message>
    <message>
        <source>General</source>
        <translation type="obsolete">General</translation>
    </message>
    <message>
        <source>Trackers</source>
        <translation type="obsolete">Trackeri</translation>
    </message>
    <message>
        <source>URL seeds</source>
        <translation type="obsolete">URL-uri de sedare</translation>
    </message>
    <message>
        <source>Files</source>
        <translation type="obsolete">Fișiere</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation type="unfinished">Prioritate</translation>
    </message>
    <message>
        <source>New url seed</source>
        <comment>New HTTP source</comment>
        <translation>Nou URL de sedări</translation>
    </message>
    <message>
        <source>New url seed:</source>
        <translation>Nou URL de sedări:</translation>
    </message>
    <message>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <source>This url seed is already in the list.</source>
        <translation>Acest URL este deacum în listă.</translation>
    </message>
    <message>
        <source>Choose save path</source>
        <translation>Alegeţi calea de salvare</translation>
    </message>
    <message>
        <source>Save path creation error</source>
        <translation type="obsolete">Salvează calea care crează erori</translation>
    </message>
    <message>
        <source>Could not create the save path</source>
        <translation type="obsolete">Nu pot crea calea de salvare</translation>
    </message>
    <message>
        <source>Downloaded:</source>
        <translation>Descărcat:</translation>
    </message>
    <message>
        <source>Transfer</source>
        <translation>Transferat</translation>
    </message>
    <message>
        <source>Uploaded:</source>
        <translation>Încăcrat:</translation>
    </message>
    <message>
        <source>Wasted:</source>
        <translation>Pierdut:</translation>
    </message>
    <message>
        <source>UP limit:</source>
        <translation>UP limită:</translation>
    </message>
    <message>
        <source>DL limit:</source>
        <translation>DW limită:</translation>
    </message>
    <message>
        <source>Time elapsed:</source>
        <translation type="obsolete">Timpul estimat:</translation>
    </message>
    <message>
        <source>Connections:</source>
        <translation>Conectări:</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Informație</translation>
    </message>
    <message>
        <source>Created on:</source>
        <translation>Creat pe:</translation>
    </message>
    <message>
        <source>Peers</source>
        <translation type="obsolete">Peer-i</translation>
    </message>
    <message>
        <source>Normal</source>
        <translation type="unfinished">Normal</translation>
    </message>
    <message>
        <source>Maximum</source>
        <translation type="unfinished">Maximum</translation>
    </message>
    <message>
        <source>High</source>
        <translation type="unfinished">Mare</translation>
    </message>
    <message>
        <source>this session</source>
        <translation>sesiunea această</translation>
    </message>
    <message>
        <source>%1 max</source>
        <comment>e.g. 10 max</comment>
        <translation>%1 max</translation>
    </message>
    <message>
        <source>Availability:</source>
        <translation>Disponibilitatea:</translation>
    </message>
    <message>
        <source>/s</source>
        <comment>/second (i.e. per second)</comment>
        <translation>/s</translation>
    </message>
    <message>
        <source>Seeded for %1</source>
        <comment>e.g. Seeded for 3m10s</comment>
        <translation>Seed-eri pentru %1</translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation>Redenumește...</translation>
    </message>
    <message>
        <source>New name:</source>
        <translation>Nume nou:</translation>
    </message>
    <message>
        <source>The file could not be renamed</source>
        <translation>Fișierul nu poate fi redenumit</translation>
    </message>
    <message>
        <source>This name is already in use in this folder. Please use a different name.</source>
        <translation>This name is already in use in this folder. Please use a different name.</translation>
    </message>
    <message>
        <source>The folder could not be renamed</source>
        <translation>The folder could not be renamed</translation>
    </message>
    <message>
        <source>Rename the file</source>
        <translation>Redenumește fișierul</translation>
    </message>
    <message>
        <source>This file name contains forbidden characters, please choose a different one.</source>
        <translation>This file name contains forbidden characters, please choose a different one.</translation>
    </message>
    <message>
        <source>I/O Error</source>
        <translation>I/O Error</translation>
    </message>
    <message>
        <source>This file does not exist yet.</source>
        <translation>This file does not exist yet.</translation>
    </message>
    <message>
        <source>This folder does not exist yet.</source>
        <translation>This folder does not exist yet.</translation>
    </message>
    <message>
        <source>Reannounce in:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do not download</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pieces size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Time active:</source>
        <extracomment>Time (duration) the torrent is active (not paused)</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Torrent content:</source>
        <translation type="unfinished">Conţinutul torrent-ului:</translation>
    </message>
</context>
<context>
    <name>QBtSession</name>
    <message>
        <source>%1 reached the maximum ratio you set.</source>
        <translation type="unfinished">%1 a ajuns la rata maximă setată.</translation>
    </message>
    <message>
        <source>Removing torrent %1...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pausing torrent %1...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>qBittorrent is bound to port: TCP/%1</source>
        <comment>e.g: qBittorrent is bound to port: 6881</comment>
        <translation type="unfinished">qBittorrent utilizează portul : TCP/%1</translation>
    </message>
    <message>
        <source>UPnP support [ON]</source>
        <translation type="obsolete">Suport UPnP[Activat]</translation>
    </message>
    <message>
        <source>UPnP support [OFF]</source>
        <translation type="obsolete">suport de UPnP[Dezactivat]</translation>
    </message>
    <message>
        <source>NAT-PMP support [ON]</source>
        <translation type="obsolete">suport NAT-PMP[Activat]</translation>
    </message>
    <message>
        <source>NAT-PMP support [OFF]</source>
        <translation type="obsolete">suport NAT-PMP[Dezactivat]</translation>
    </message>
    <message>
        <source>HTTP user agent is %1</source>
        <translation type="unfinished">HTTP agentul este %1</translation>
    </message>
    <message>
        <source>Using a disk cache size of %1 MiB</source>
        <translation type="obsolete">Utilizez cache de pe disk la %1 MiB</translation>
    </message>
    <message>
        <source>DHT support [ON], port: UDP/%1</source>
        <translation type="unfinished">DHT activat, portul : UDP/%1</translation>
    </message>
    <message>
        <source>DHT support [OFF]</source>
        <translation type="unfinished">Suport DHT[Dezactivat]</translation>
    </message>
    <message>
        <source>PeX support [ON]</source>
        <translation type="unfinished">Suport PeX[Activat]</translation>
    </message>
    <message>
        <source>PeX support [OFF]</source>
        <translation type="unfinished">Suport PeX [Oprit]</translation>
    </message>
    <message>
        <source>Restart is required to toggle PeX support</source>
        <translation type="unfinished">Restartarea este necesară pentru a activa suport PeX</translation>
    </message>
    <message>
        <source>Local Peer Discovery [ON]</source>
        <translation type="obsolete">Căutare peer locali[Activat]</translation>
    </message>
    <message>
        <source>Local Peer Discovery support [OFF]</source>
        <translation type="unfinished">Căutarea peer locali[Dezactivat]</translation>
    </message>
    <message>
        <source>Encryption support [ON]</source>
        <translation type="unfinished">Suport de codificate[Activat]</translation>
    </message>
    <message>
        <source>Encryption support [FORCED]</source>
        <translation type="unfinished">Suport de codificare[Forţat]</translation>
    </message>
    <message>
        <source>Encryption support [OFF]</source>
        <translation type="unfinished">Suport de codificare [Dezactivat]</translation>
    </message>
    <message>
        <source>Embedded Tracker [ON]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to start the embedded tracker!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Embedded Tracker [OFF]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The Web UI is listening on port %1</source>
        <translation type="unfinished">Interfața Web este activă pe portul %1</translation>
    </message>
    <message>
        <source>Web User Interface Error - Unable to bind Web UI to port %1</source>
        <translation type="unfinished">Eroare în interfața Web - Nu pot conecta interfața Web cu portul %1</translation>
    </message>
    <message>
        <source>&apos;%1&apos; was removed from transfer list and hard disk.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation type="unfinished">&apos;%1&apos; a fost șters din lista de transferuri și de pe hard disk.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; was removed from transfer list.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation type="unfinished">&apos;%1&apos; a fost șters din lista de transferuri.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is not a valid magnet URI.</source>
        <translation type="unfinished">&apos;%1&apos; nu este valid URI.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is already in download list.</source>
        <comment>e.g: &apos;xxx.avi&apos; is already in download list.</comment>
        <translation type="unfinished">&apos;%1&apos; este de acum in lista de descărcare.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; resumed. (fast resume)</source>
        <comment>&apos;/home/y/xxx.torrent&apos; was resumed. (fast resume)</comment>
        <translation type="unfinished">&apos;%1&apos; resumat. (resumare rapidă)</translation>
    </message>
    <message>
        <source>&apos;%1&apos; added to download list.</source>
        <comment>&apos;/home/y/xxx.torrent&apos; was added to download list.</comment>
        <translation type="unfinished">&apos;%1&apos; adăugat la lista de descărcare.</translation>
    </message>
    <message>
        <source>Unable to decode torrent file: &apos;%1&apos;</source>
        <comment>e.g: Unable to decode torrent file: &apos;/home/y/xxx.torrent&apos;</comment>
        <translation type="unfinished">Nu pot decodifica torrent-ul : &apos;%1&apos;</translation>
    </message>
    <message>
        <source>This file is either corrupted or this isn&apos;t a torrent.</source>
        <translation type="unfinished">Acest fişier este deteriorat sau nu este torrent.</translation>
    </message>
    <message>
        <source>Error: The torrent %1 does not contain any file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Note: new trackers were added to the existing torrent.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Note: new URL seeds were added to the existing torrent.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;was blocked due to your IP filter&lt;/i&gt;</source>
        <comment>x.y.z.w was blocked</comment>
        <translation type="unfinished">&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;a fost blocat conform IP filtrului&lt;/i&gt;</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;was banned due to corrupt pieces&lt;/i&gt;</source>
        <comment>x.y.z.w was banned</comment>
        <translation type="unfinished">&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;a fost banat din cauza fragmentelor eronate&lt;/i&gt;</translation>
    </message>
    <message>
        <source>Recursive download of file %1 embedded in torrent %2</source>
        <comment>Recursive download of test.torrent embedded in torrent test2</comment>
        <translation type="unfinished">Descarcă recursiv fișierul %1 din torrentul %2</translation>
    </message>
    <message>
        <source>Unable to decode %1 torrent file.</source>
        <translation type="unfinished">Nu pot citi torrentul %1.</translation>
    </message>
    <message>
        <source>Torrent name: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Torrent size: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save path: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The torrent was downloaded in %1.</source>
        <comment>The torrent was downloaded in 1 hour and 20 seconds</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Thank you for using qBittorrent.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[qBittorrent] %1 has finished downloading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>An I/O error occured, &apos;%1&apos; paused.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reason: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>UPnP/NAT-PMP: Port mapping failure, message: %1</source>
        <translation type="unfinished">UPnP/NAT-PMP: Port mapping failure, message: %1</translation>
    </message>
    <message>
        <source>UPnP/NAT-PMP: Port mapping successful, message: %1</source>
        <translation type="unfinished">UPnP/NAT-PMP: Port mapping successful, message: %1</translation>
    </message>
    <message>
        <source>File sizes mismatch for torrent %1, pausing it.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fast resume data was rejected for torrent %1, checking again...</source>
        <translation type="unfinished">Resumarea rapidă a fost respinsă pentru torrent-ul %1, verific încă o dată...</translation>
    </message>
    <message>
        <source>Url seed lookup failed for url: %1, message: %2</source>
        <translation type="unfinished">Conectarea la seed a eşuat pentru : %1, mesajul : %2</translation>
    </message>
    <message>
        <source>Downloading &apos;%1&apos;, please wait...</source>
        <comment>e.g: Downloading &apos;xxx.torrent&apos;, please wait...</comment>
        <translation type="unfinished">Descarc &apos;%1&apos;, vă rugăm să aşteptaţi...</translation>
    </message>
    <message>
        <source>The network interface defined is invalid: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Trying any other network interface available instead.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Listening on IP address %1 on network interface %2...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to listen on network interface %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>UPnP / NAT-PMP support [ON]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>UPnP / NAT-PMP support [OFF]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Local Peer Discovery support [ON]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Successfuly parsed the provided IP filter: %1 rules were applied.</source>
        <comment>%1 is a number</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error: Failed to parse the provided IP filter.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reporting IP address %1 to trackers...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The computer will now go to sleep mode unless you cancel within the next 15 seconds...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The computer will now be switched off unless you cancel within the next 15 seconds...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>qBittorrent will now exit unless you cancel within the next 15 seconds...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RSS</name>
    <message>
        <source>Search</source>
        <translation>Caută</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Şterge</translation>
    </message>
    <message>
        <source>Rename</source>
        <translation>Redenumeşte</translation>
    </message>
    <message>
        <source>Refresh RSS streams</source>
        <translation>Reînnoieşte firul RSS</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Torrents:&lt;/span&gt; &lt;span style=&quot; font-style:italic;&quot;&gt;(double-click to download)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Torrents:&lt;/span&gt; &lt;span style=&quot; font-style:italic;&quot;&gt;(double-click to download)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Download torrent</source>
        <translation>Descarcă torrent-ul</translation>
    </message>
    <message>
        <source>Open news URL</source>
        <translation>Deschide noutățile URL</translation>
    </message>
    <message>
        <source>Copy feed URL</source>
        <translation>Copie URL feed-ul</translation>
    </message>
    <message>
        <source>New subscription</source>
        <translation>Noua subsriere</translation>
    </message>
    <message>
        <source>Mark items read</source>
        <translation>Marchează itemii citiți</translation>
    </message>
    <message>
        <source>Update all</source>
        <translation>Reînnoiește toate</translation>
    </message>
    <message>
        <source>Update all feeds</source>
        <translation>Reînnoiește toate feed-urile</translation>
    </message>
    <message>
        <source>RSS feeds</source>
        <translation type="obsolete">RSS feed-uri</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Reînnoiește</translation>
    </message>
    <message>
        <source>Feed URL</source>
        <translation type="obsolete">Feed URL</translation>
    </message>
    <message>
        <source>Article title</source>
        <translation type="obsolete">TItlul articolului</translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation type="unfinished">Redenumește...</translation>
    </message>
    <message>
        <source>New subscription...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New folder...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manage cookies...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Settings...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>RSS Downloader...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RSSImp</name>
    <message>
        <source>Please type a rss stream url</source>
        <translation>Introduceţi adresa URL la RSS fir</translation>
    </message>
    <message>
        <source>Stream URL:</source>
        <translation>Adresa URL:</translation>
    </message>
    <message>
        <source>Are you sure? -- qBittorrent</source>
        <translation>Sunteţi siguri? -- qBittorrent</translation>
    </message>
    <message>
        <source>&amp;Yes</source>
        <translation>&amp;Yes</translation>
    </message>
    <message>
        <source>&amp;No</source>
        <translation>&amp;No</translation>
    </message>
    <message>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <source>This rss feed is already in the list.</source>
        <translation>Acest RSS este deacum în listă.</translation>
    </message>
    <message>
        <source>Date: </source>
        <translation>Data: </translation>
    </message>
    <message>
        <source>Author: </source>
        <translation>Autor: </translation>
    </message>
    <message>
        <source>Please choose a folder name</source>
        <translation>Vă rugăm să alegeți altă denumire a directoriului</translation>
    </message>
    <message>
        <source>Folder name:</source>
        <translation>Denumirea folder-ului:</translation>
    </message>
    <message>
        <source>New folder</source>
        <translation>Nou directoriu</translation>
    </message>
    <message>
        <source>Are you sure you want to delete these elements from the list?</source>
        <translation>Doriti sa ștergeți aceste elemente?</translation>
    </message>
    <message>
        <source>Are you sure you want to delete this element from the list?</source>
        <translation>Sunteti siguri că doriti sa stergeti elementele selectate din listă?</translation>
    </message>
    <message>
        <source>Please choose a new name for this RSS feed</source>
        <translation>Alegeți alt nume pentru această listă RSS</translation>
    </message>
    <message>
        <source>New feed name:</source>
        <translation>Nou nume:</translation>
    </message>
    <message>
        <source>Name already in use</source>
        <translation>Numele este deacum utilizat</translation>
    </message>
    <message>
        <source>This name is already used by another item, please choose another one.</source>
        <translation>Numele este utilizat, alegeți altul.</translation>
    </message>
    <message>
        <source>Overwrite attempt</source>
        <translation>Încercare de rescriere</translation>
    </message>
    <message>
        <source>You cannot overwrite %1 item.</source>
        <comment>You cannot overwrite myFolder item.</comment>
        <translation>Nu puteți rescri itemul %1.</translation>
    </message>
    <message>
        <source>Unread</source>
        <translation>Recitit</translation>
    </message>
</context>
<context>
    <name>RssArticle</name>
    <message>
        <source>No description available</source>
        <translation type="obsolete">Descrierea nu este disponobilă</translation>
    </message>
</context>
<context>
    <name>RssFeed</name>
    <message>
        <source>Automatically downloading %1 torrent from %2 RSS feed...</source>
        <translation type="unfinished">Automat descarcă torrentul %1 din lista RSS %2...</translation>
    </message>
</context>
<context>
    <name>RssItem</name>
    <message>
        <source>No description available</source>
        <translation type="obsolete">Descrierea nu este disponobilă</translation>
    </message>
</context>
<context>
    <name>RssSettingsDlg</name>
    <message>
        <source>RSS Reader Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>RSS feeds refresh interval:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>minutes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Maximum number of articles per feed:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RssStream</name>
    <message>
        <source>Automatically downloading %1 torrent from %2 RSS feed...</source>
        <translation type="obsolete">Automat descarcă torrentul %1 din lista RSS %2...</translation>
    </message>
</context>
<context>
    <name>ScanFoldersModel</name>
    <message>
        <source>Watched Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Download here</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SearchCategories</name>
    <message>
        <source>All categories</source>
        <translation>Toate categoriile</translation>
    </message>
    <message>
        <source>Movies</source>
        <translation>Filme</translation>
    </message>
    <message>
        <source>TV shows</source>
        <translation>TV show-uri</translation>
    </message>
    <message>
        <source>Music</source>
        <translation>Muzică</translation>
    </message>
    <message>
        <source>Games</source>
        <translation>Jocuri</translation>
    </message>
    <message>
        <source>Anime</source>
        <translation>Anime</translation>
    </message>
    <message>
        <source>Software</source>
        <translation>Soft</translation>
    </message>
    <message>
        <source>Pictures</source>
        <translation>Fotografii</translation>
    </message>
    <message>
        <source>Books</source>
        <translation>Cărți</translation>
    </message>
</context>
<context>
    <name>SearchEngine</name>
    <message>
        <source>Empty search pattern</source>
        <translation>Şablonul de căutat este vid</translation>
    </message>
    <message>
        <source>Please type a search pattern first</source>
        <translation>Vă rugăm să completaţi şablonul de căutare</translation>
    </message>
    <message>
        <source>Results</source>
        <translation>Rezultate</translation>
    </message>
    <message>
        <source>Searching...</source>
        <translation>Căutare...</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation>Tăiere</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Copiere</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation>Pune</translation>
    </message>
    <message>
        <source>Clear field</source>
        <translation>Ștergerea cîmpului</translation>
    </message>
    <message>
        <source>Clear completion history</source>
        <translation>Șterge istoria de completare</translation>
    </message>
    <message>
        <source>Search Engine</source>
        <translation>Motor de Căutare</translation>
    </message>
    <message>
        <source>Search has finished</source>
        <translation>Căutarea a fost terminată</translation>
    </message>
    <message>
        <source>An error occured during search...</source>
        <translation>Eroare în timpul căutării...</translation>
    </message>
    <message>
        <source>Search aborted</source>
        <translation>Cautarea abordată</translation>
    </message>
    <message>
        <source>Search returned no results</source>
        <translation>Cautarea nu a returnat rezultate</translation>
    </message>
    <message>
        <source>Results</source>
        <comment>i.e: Search results</comment>
        <translation>Rezultate</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Necunoscut</translation>
    </message>
    <message>
        <source>Search</source>
        <translation type="unfinished">Caută</translation>
    </message>
    <message>
        <source>Download error</source>
        <translation type="unfinished">Eroare de descărcare</translation>
    </message>
    <message>
        <source>Python setup could not be downloaded, reason: %1.
Please install it manually.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Missing Python Interpreter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Python 2.x is required to use the search engine but it does not seem to be installed.
Do you want to install it now?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confirmation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Are you sure you want to clear the history?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SearchTab</name>
    <message>
        <source>Name</source>
        <comment>i.e: file name</comment>
        <translation>Nume</translation>
    </message>
    <message>
        <source>Size</source>
        <comment>i.e: file size</comment>
        <translation>Capacitate</translation>
    </message>
    <message>
        <source>Seeders</source>
        <comment>i.e: Number of full sources</comment>
        <translation>Seederi</translation>
    </message>
    <message>
        <source>Leechers</source>
        <comment>i.e: Number of partial sources</comment>
        <translation>Leecheri</translation>
    </message>
    <message>
        <source>Search engine</source>
        <translation>Motorul de căutare</translation>
    </message>
</context>
<context>
    <name>ShutdownConfirmDlg</name>
    <message>
        <source>Shutdown confirmation</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SpeedLimitDialog</name>
    <message>
        <source>KiB/s</source>
        <translation>KiB/s</translation>
    </message>
</context>
<context>
    <name>StatusBar</name>
    <message>
        <source>Connection status:</source>
        <translation>Starea conectării:</translation>
    </message>
    <message>
        <source>No direct connections. This may indicate network configuration problems.</source>
        <translation>Nu sunt connectări directe. Aceasta poate indica la probleme cu rețeaua.</translation>
    </message>
    <message>
        <source>DHT: %1 nodes</source>
        <translation>DHT: %1 noduri</translation>
    </message>
    <message>
        <source>Connection Status:</source>
        <translation>Starea conectării:</translation>
    </message>
    <message>
        <source>Online</source>
        <translation>Conectat</translation>
    </message>
    <message>
        <source>Global Download Speed Limit</source>
        <translation>Limita globală de descărcare</translation>
    </message>
    <message>
        <source>Global Upload Speed Limit</source>
        <translation>Limita globală de încărcare</translation>
    </message>
    <message>
        <source>D: %1/s - T: %2</source>
        <comment>Download speed: x KiB/s - Transferred: x MiB</comment>
        <translation type="obsolete">D: %1/s - T: %2</translation>
    </message>
    <message>
        <source>U: %1/s - T: %2</source>
        <comment>Upload speed: x KiB/s - Transferred: x MiB</comment>
        <translation type="obsolete">U: %1/s - T: %2</translation>
    </message>
    <message>
        <source>D: %1 B/s - T: %2</source>
        <comment>Download speed: x B/s - Transferred: x MiB</comment>
        <translation type="obsolete">D: %1 B/s - T: %2</translation>
    </message>
    <message>
        <source>U: %1 B/s - T: %2</source>
        <comment>Upload speed: x B/s - Transferred: x MiB</comment>
        <translation type="obsolete">U: %1 B/s - T: %2</translation>
    </message>
    <message>
        <source>Offline. This usually means that qBittorrent failed to listen on the selected port for incoming connections.</source>
        <translation>Offline. This usually means that qBittorrent failed to listen on the selected port for incoming connections.</translation>
    </message>
    <message>
        <source>qBittorrent needs to be restarted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>qBittorrent was just updated and needs to be restarted for the changes to be effective.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click to switch to alternative speed limits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click to switch to regular speed limits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1/s</source>
        <comment>Per second</comment>
        <translation type="unfinished">%1/s</translation>
    </message>
</context>
<context>
    <name>TorrentCreatorDlg</name>
    <message>
        <source>Select a folder to add to the torrent</source>
        <translation type="unfinished">Seletaţi directoriul pentru a fi adăugat în torrent fişier</translation>
    </message>
    <message>
        <source>Select a file to add to the torrent</source>
        <translation type="unfinished">Selectaţi un fişier pentru al adăuga la torrent</translation>
    </message>
    <message>
        <source>Please type an announce URL</source>
        <translation type="obsolete">Introduceţi URL-ul de anunţare</translation>
    </message>
    <message>
        <source>Announce URL:</source>
        <comment>Tracker URL</comment>
        <translation type="obsolete">URL-ul de anunţare:</translation>
    </message>
    <message>
        <source>Please type a web seed url</source>
        <translation type="obsolete">Introduceţi URL-ul de web seed</translation>
    </message>
    <message>
        <source>Web seed URL:</source>
        <translation type="obsolete">Web seed URL:</translation>
    </message>
    <message>
        <source>No input path set</source>
        <translation type="unfinished">Nu sunt selectate fişiere de intrare</translation>
    </message>
    <message>
        <source>Please type an input path first</source>
        <translation type="unfinished">Vă rugăm să arătaţi calea de intrare</translation>
    </message>
    <message>
        <source>Select destination torrent file</source>
        <translation type="unfinished">Selectează fişierul de destinare</translation>
    </message>
    <message>
        <source>Torrent Files</source>
        <translation type="unfinished">Fişiere Torrent</translation>
    </message>
    <message>
        <source>Torrent creation</source>
        <translation type="unfinished">Crearea torentului</translation>
    </message>
    <message>
        <source>Torrent creation was unsuccessful, reason: %1</source>
        <translation type="unfinished">Crearea torrent-ului a eşuat, motivul: %1</translation>
    </message>
    <message>
        <source>Created torrent file is invalid. It won&apos;t be added to download list.</source>
        <translation type="unfinished">Fişierul torrent creat este deteriorat. El nu va fi adăugat în lista de download-uri.</translation>
    </message>
    <message>
        <source>Torrent was created successfully:</source>
        <translation type="unfinished">Torrentul a fost creat cu success:</translation>
    </message>
</context>
<context>
    <name>TorrentFilesModel</name>
    <message>
        <source>Name</source>
        <translation>Nume</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Capacitate</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation>Progress</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation type="unfinished">Prioritate</translation>
    </message>
</context>
<context>
    <name>TorrentImportDlg</name>
    <message>
        <source>Torrent Import</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This assistant will help you share with qBittorrent a torrent that you have already downloaded.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Torrent file to import:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>...</source>
        <translation type="unfinished">...</translation>
    </message>
    <message>
        <source>Content location:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Skip the data checking stage and start seeding immediately</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Import</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Torrent file to import</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Torrent files (*.torrent)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 Files</source>
        <comment>%1 is a file extension (e.g. PDF)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please provide the location of %1</source>
        <comment>%1 is a file name</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please point to the location of the torrent: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid torrent file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This is not a valid torrent file.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TorrentModel</name>
    <message>
        <source>Name</source>
        <comment>i.e: torrent name</comment>
        <translation type="unfinished">Nume</translation>
    </message>
    <message>
        <source>Size</source>
        <comment>i.e: torrent size</comment>
        <translation type="unfinished">Capacitate</translation>
    </message>
    <message>
        <source>Done</source>
        <comment>% Done</comment>
        <translation type="unfinished">Obținut</translation>
    </message>
    <message>
        <source>Status</source>
        <comment>Torrent status (e.g. downloading, seeding, paused)</comment>
        <translation type="unfinished">Stare</translation>
    </message>
    <message>
        <source>Seeds</source>
        <comment>i.e. full sources (often untranslated)</comment>
        <translation type="unfinished">Seeds</translation>
    </message>
    <message>
        <source>Peers</source>
        <comment>i.e. partial sources (often untranslated)</comment>
        <translation type="unfinished">Peer-i</translation>
    </message>
    <message>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation type="unfinished">Viteza de descărcare</translation>
    </message>
    <message>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ratio</source>
        <comment>Share ratio</comment>
        <translation type="unfinished">Rata</translation>
    </message>
    <message>
        <source>ETA</source>
        <comment>i.e: Estimated Time of Arrival / Time left</comment>
        <translation type="unfinished">ETA</translation>
    </message>
    <message>
        <source>Label</source>
        <translation type="unfinished">Etichetă</translation>
    </message>
    <message>
        <source>Added On</source>
        <comment>Torrent was added to transfer list on 01/01/2010 08:00</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Completed On</source>
        <comment>Torrent was completed on 01/01/2010 08:00</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tracker</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Down Limit</source>
        <comment>i.e: Download limit</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Up Limit</source>
        <comment>i.e: Upload limit</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Amount downloaded</source>
        <comment>Amount of data downloaded (e.g. in MB)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Amount left</source>
        <comment>Amount of data left to download (e.g. in MB)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Time Active</source>
        <comment>Time (duration) the torrent is active (not paused)</comment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TrackerList</name>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Stare</translation>
    </message>
    <message>
        <source>Peers</source>
        <translation>Peer-i</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Mesaj</translation>
    </message>
    <message>
        <source>[DHT]</source>
        <translation>[DHT]</translation>
    </message>
    <message>
        <source>Working</source>
        <translation>Lucrează</translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Dezactivată</translation>
    </message>
    <message>
        <source>This torrent is private</source>
        <translation>Acest torrent este privat</translation>
    </message>
    <message>
        <source>Updating...</source>
        <translation>Reînnoire...</translation>
    </message>
    <message>
        <source>Not working</source>
        <translation>Nu lucrează</translation>
    </message>
    <message>
        <source>Not contacted yet</source>
        <translation>Nu a fost contactat</translation>
    </message>
    <message>
        <source>[PeX]</source>
        <translation>[PeX]</translation>
    </message>
    <message>
        <source>[LSD]</source>
        <translation>[LSD]</translation>
    </message>
    <message>
        <source>Add a new tracker...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove tracker</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Force reannounce</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TrackersAdditionDlg</name>
    <message>
        <source>Trackers addition dialog</source>
        <translation>Dialogul de adaugare a trackerilor</translation>
    </message>
    <message>
        <source>List of trackers to add (one per line):</source>
        <translation>Lista trackerilor(unul pe linie):</translation>
    </message>
    <message utf8="true">
        <source>µTorrent compatible list URL:</source>
        <translation>µTorrent compatible list URL:</translation>
    </message>
    <message>
        <source>I/O Error</source>
        <translation>I/O Error</translation>
    </message>
    <message>
        <source>Error while trying to open the downloaded file.</source>
        <translation>Error while trying to open the downloaded file.</translation>
    </message>
    <message>
        <source>No change</source>
        <translation>No change</translation>
    </message>
    <message>
        <source>No additional trackers were found.</source>
        <translation>No additional trackers were found.</translation>
    </message>
    <message>
        <source>Download error</source>
        <translation>Eroare de descărcare</translation>
    </message>
    <message>
        <source>The trackers list could not be downloaded, reason: %1</source>
        <translation>The trackers list could not be downloaded, reason: %1</translation>
    </message>
</context>
<context>
    <name>TransferListDelegate</name>
    <message>
        <source>Downloading</source>
        <translation>Descărcarea</translation>
    </message>
    <message>
        <source>Paused</source>
        <translation>Pauzat</translation>
    </message>
    <message>
        <source>Queued</source>
        <comment>i.e. torrent is queued</comment>
        <translation>În coadă</translation>
    </message>
    <message>
        <source>Seeding</source>
        <comment>Torrent is complete and in upload-only mode</comment>
        <translation>Sedarea</translation>
    </message>
    <message>
        <source>Stalled</source>
        <comment>Torrent is waiting for download to begin</comment>
        <translation>Oprit</translation>
    </message>
    <message>
        <source>Checking</source>
        <comment>Torrent local data is being checked</comment>
        <translation>Verificare</translation>
    </message>
    <message>
        <source>/s</source>
        <comment>/second (.i.e per second)</comment>
        <translation>/s</translation>
    </message>
    <message>
        <source>KiB/s</source>
        <comment>KiB/second (.i.e per second)</comment>
        <translation type="unfinished">KiB/s</translation>
    </message>
    <message>
        <source>Seeded for %1</source>
        <comment>e.g. Seeded for 3m10s</comment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TransferListFiltersWidget</name>
    <message>
        <source>All</source>
        <translation>Toate</translation>
    </message>
    <message>
        <source>Downloading</source>
        <translation>Descărcarea</translation>
    </message>
    <message>
        <source>Completed</source>
        <translation>Completat</translation>
    </message>
    <message>
        <source>Active</source>
        <translation>Activ</translation>
    </message>
    <message>
        <source>Inactive</source>
        <translation>Inactiv</translation>
    </message>
    <message>
        <source>All labels</source>
        <translation>Toate etichetele</translation>
    </message>
    <message>
        <source>Unlabeled</source>
        <translation>Unlabeled</translation>
    </message>
    <message>
        <source>Remove label</source>
        <translation>Șterge eticheta</translation>
    </message>
    <message>
        <source>New Label</source>
        <translation>Etichetă nouă</translation>
    </message>
    <message>
        <source>Label:</source>
        <translation>Etichetă:</translation>
    </message>
    <message>
        <source>Invalid label name</source>
        <translation>Numele etichetei invalid</translation>
    </message>
    <message>
        <source>Please don&apos;t use any special characters in the label name.</source>
        <translation>Please don&apos;t use any special characters in the label name.</translation>
    </message>
    <message>
        <source>Paused</source>
        <translation type="unfinished">Pauzat</translation>
    </message>
    <message>
        <source>Add label...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Resume torrents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pause torrents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete torrents</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TransferListWidget</name>
    <message>
        <source>ETA</source>
        <comment>i.e: Estimated Time of Arrival / Time left</comment>
        <translation type="obsolete">ETA</translation>
    </message>
    <message>
        <source>Column visibility</source>
        <translation>Vizibilitatea coloanei</translation>
    </message>
    <message>
        <source>Open destination folder</source>
        <translation>Deschide directoriul destinaţie</translation>
    </message>
    <message>
        <source>Force recheck</source>
        <translation>Reverificarea forţată</translation>
    </message>
    <message>
        <source>Copy magnet link</source>
        <translation>Copie link-ul magnet</translation>
    </message>
    <message>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation type="obsolete">Viteza de descărcare</translation>
    </message>
    <message>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation type="obsolete">Viteza de încărcare</translation>
    </message>
    <message>
        <source>Name</source>
        <comment>i.e: torrent name</comment>
        <translation type="obsolete">Nume</translation>
    </message>
    <message>
        <source>Size</source>
        <comment>i.e: torrent size</comment>
        <translation type="obsolete">Capacitate</translation>
    </message>
    <message>
        <source>Done</source>
        <comment>% Done</comment>
        <translation type="obsolete">Obținut</translation>
    </message>
    <message>
        <source>Status</source>
        <comment>Torrent status (e.g. downloading, seeding, paused)</comment>
        <translation type="obsolete">Stare</translation>
    </message>
    <message>
        <source>Seeds</source>
        <comment>i.e. full sources (often untranslated)</comment>
        <translation type="obsolete">Seeds</translation>
    </message>
    <message>
        <source>Peers</source>
        <comment>i.e. partial sources (often untranslated)</comment>
        <translation type="obsolete">Peer-i</translation>
    </message>
    <message>
        <source>Ratio</source>
        <comment>Share ratio</comment>
        <translation type="obsolete">Rata</translation>
    </message>
    <message>
        <source>Torrent Download Speed Limiting</source>
        <translation>Limitarea vitezei de descărcare pentru torrent</translation>
    </message>
    <message>
        <source>Torrent Upload Speed Limiting</source>
        <translation>Limitarea vitezei de încărcare pentru torrent</translation>
    </message>
    <message>
        <source>Super seeding mode</source>
        <translation>Mod de super sedare</translation>
    </message>
    <message>
        <source>Download in sequential order</source>
        <translation>Descarcă în ordine secvențială</translation>
    </message>
    <message>
        <source>Download first and last piece first</source>
        <translation>Descarcă prima și ultima parte din fișier</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Etichetă</translation>
    </message>
    <message>
        <source>New Label</source>
        <translation>Etichetă nouă</translation>
    </message>
    <message>
        <source>Label:</source>
        <translation>Etichetă:</translation>
    </message>
    <message>
        <source>New...</source>
        <comment>New label...</comment>
        <translation>Nou...</translation>
    </message>
    <message>
        <source>Reset</source>
        <comment>Reset label</comment>
        <translation>Resetează</translation>
    </message>
    <message>
        <source>Rename</source>
        <translation>Redenumești</translation>
    </message>
    <message>
        <source>New name:</source>
        <translation>Nume nou:</translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation>Redenumește...</translation>
    </message>
    <message>
        <source>Invalid label name</source>
        <translation>Numele etichetei invalid</translation>
    </message>
    <message>
        <source>Please don&apos;t use any special characters in the label name.</source>
        <translation>Please don&apos;t use any special characters in the label name.</translation>
    </message>
    <message>
        <source>Choose save path</source>
        <translation type="unfinished">Alegeţi calea de salvare</translation>
    </message>
    <message>
        <source>Save path creation error</source>
        <translation type="obsolete">Salvează calea care crează erori</translation>
    </message>
    <message>
        <source>Could not create the save path</source>
        <translation type="obsolete">Nu pot crea calea de salvare</translation>
    </message>
    <message>
        <source>Set location...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Preview file...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Limit upload rate...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Limit download rate...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move up</source>
        <comment>i.e. move up in the queue</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move down</source>
        <comment>i.e. Move down in the queue</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move to top</source>
        <comment>i.e. Move to top of the queue</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move to bottom</source>
        <comment>i.e. Move to bottom of the queue</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Priority</source>
        <translation type="unfinished">Prioritate</translation>
    </message>
    <message>
        <source>Resume</source>
        <comment>Resume/start the torrent</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pause</source>
        <comment>Pause the torrent</comment>
        <translation type="unfinished">Pauză</translation>
    </message>
    <message>
        <source>Delete</source>
        <comment>Delete the torrent</comment>
        <translation type="unfinished">Şterge</translation>
    </message>
    <message>
        <source>Limit share ratio...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UpDownRatioDlg</name>
    <message>
        <source>Torrent Upload/Download Ratio Limiting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use global ratio limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>buttonGroup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set no ratio limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set ratio limit to</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UsageDisplay</name>
    <message>
        <source>Usage:</source>
        <translation>Utilizat:</translation>
    </message>
    <message>
        <source>displays program version</source>
        <translation>displays program version</translation>
    </message>
    <message>
        <source>disable splash screen</source>
        <translation>disable splash screen</translation>
    </message>
    <message>
        <source>displays this help message</source>
        <translation>displays this help message</translation>
    </message>
    <message>
        <source>changes the webui port (current: %1)</source>
        <translation>changes the webui port (current: %1)</translation>
    </message>
    <message>
        <source>[files or urls]: downloads the torrents passed by the user (optional)</source>
        <translation>[files or urls]: downloads the torrents passed by the user (optional)</translation>
    </message>
</context>
<context>
    <name>about</name>
    <message>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <source>I would like to thank the following people who volunteered to translate qBittorrent:</source>
        <translation>Eu vreau să mulţumesc voluntarilor care au translat qBittorrent:</translation>
    </message>
    <message>
        <source>Please contact me if you would like to translate qBittorrent into your own language.</source>
        <translation>Contactaţimă dacă doriţi să traduceţi qBittorrent in limba dumneavoastră.</translation>
    </message>
</context>
<context>
    <name>addPeerDialog</name>
    <message>
        <source>Peer addition</source>
        <translation>Adaugă peer</translation>
    </message>
    <message>
        <source>IP</source>
        <translation>IP</translation>
    </message>
    <message>
        <source>Port</source>
        <translation>Port</translation>
    </message>
</context>
<context>
    <name>addTorrentDialog</name>
    <message>
        <source>Torrent addition dialog</source>
        <translation>Dialogul de adăugare a torrentului</translation>
    </message>
    <message>
        <source>Save path:</source>
        <translation>Calea de salvare:</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Torrent content:</source>
        <translation>Conţinutul torrent-ului:</translation>
    </message>
    <message>
        <source>Add to download list in paused state</source>
        <translation>Adauga în lista de descărcare în stare de pauză</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>Adaugă</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Anulare</translation>
    </message>
    <message>
        <source>Normal</source>
        <translation type="unfinished">Normal</translation>
    </message>
    <message>
        <source>High</source>
        <translation type="unfinished">Înalt</translation>
    </message>
    <message>
        <source>Maximum</source>
        <translation type="unfinished">Maximal</translation>
    </message>
    <message>
        <source>Torrent size:</source>
        <translation>Dimensiunea torrentului:</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Necunoscut</translation>
    </message>
    <message>
        <source>Free disk space:</source>
        <translation>Spațiu liber:</translation>
    </message>
    <message>
        <source>Download in sequential order (slower but good for previewing)</source>
        <translation>Descarcă în ordine secvențială (încet dar bine pentru preview)</translation>
    </message>
    <message>
        <source>Skip file checking and start seeding immediately</source>
        <translation>Nu verifica integritatea, începe sedarea imediat</translation>
    </message>
    <message>
        <source>Label:</source>
        <translation>Etichetă:</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do not download</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>authentication</name>
    <message>
        <source>Tracker authentication</source>
        <translation>Autentificarea pe Tracker</translation>
    </message>
    <message>
        <source>Tracker:</source>
        <translation>Tracker:</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Login</translation>
    </message>
    <message>
        <source>Username:</source>
        <translation>Numele de utilizator:</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation>Parola:</translation>
    </message>
    <message>
        <source>Log in</source>
        <translation>Logare</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Anulare</translation>
    </message>
</context>
<context>
    <name>confirmDeletionDlg</name>
    <message>
        <source>Deletion confirmation - qBittorrent</source>
        <translation>Confirmarea ștergerii - qBittorrent</translation>
    </message>
    <message>
        <source>Are you sure you want to delete the selected torrents from the transfer list?</source>
        <translation>Sunteți siguri că doriți să ștergeți torrent-urile selectate ?</translation>
    </message>
    <message>
        <source>Remember choice</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Also delete the files on the hard disk</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>createTorrentDialog</name>
    <message>
        <source>Cancel</source>
        <translation>Anulare</translation>
    </message>
    <message>
        <source>Torrent Creation Tool</source>
        <translation>Crearea Torrentului</translation>
    </message>
    <message>
        <source>Torrent file creation</source>
        <translation>Locaţia de creare a torrent-ului</translation>
    </message>
    <message>
        <source>Announce urls (trackers):</source>
        <translation type="obsolete">URL-uri de anunţare (tracke-ri):</translation>
    </message>
    <message>
        <source>Comment (optional):</source>
        <translation type="obsolete">Comentariu(opţional):</translation>
    </message>
    <message>
        <source>Web seeds urls (optional):</source>
        <translation type="obsolete">Web sedări(opţional):</translation>
    </message>
    <message>
        <source>File or folder to add to the torrent:</source>
        <translation>Fişier sau directoriu pentru a adăuga torentul:</translation>
    </message>
    <message>
        <source>Piece size:</source>
        <translation>Dimensiunea bucăţii:</translation>
    </message>
    <message>
        <source>32 KiB</source>
        <translation>32 KiB</translation>
    </message>
    <message>
        <source>64 KiB</source>
        <translation>64 KiB</translation>
    </message>
    <message>
        <source>128 KiB</source>
        <translation>128 KiB</translation>
    </message>
    <message>
        <source>256 KiB</source>
        <translation>256 KiB</translation>
    </message>
    <message>
        <source>512 KiB</source>
        <translation>512 KiB</translation>
    </message>
    <message>
        <source>1 MiB</source>
        <translation>1 MiB</translation>
    </message>
    <message>
        <source>2 MiB</source>
        <translation>2 MiB</translation>
    </message>
    <message>
        <source>4 MiB</source>
        <translation>4 MiB</translation>
    </message>
    <message>
        <source>Private (won&apos;t be distributed on DHT network if enabled)</source>
        <translation>Privat(nu va fi distribuit prin reţeaua DHT dacă este activată)</translation>
    </message>
    <message>
        <source>Start seeding after creation</source>
        <translation>Începe sedarea după creare</translation>
    </message>
    <message>
        <source>Create and save...</source>
        <translation>Crează şi salvează...</translation>
    </message>
    <message>
        <source>Progress:</source>
        <translation>Progress:</translation>
    </message>
    <message>
        <source>Add file</source>
        <translation>Adaugă fișier</translation>
    </message>
    <message>
        <source>Add folder</source>
        <translation>Adaugă directoriu</translation>
    </message>
    <message>
        <source>Tracker URLs:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Web seeds urls:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment:</source>
        <translation type="unfinished">Comentarii:</translation>
    </message>
    <message>
        <source>Auto</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>createtorrent</name>
    <message>
        <source>Select destination torrent file</source>
        <translation type="obsolete">Selectează fişierul de destinare</translation>
    </message>
    <message>
        <source>Torrent Files</source>
        <translation type="obsolete">Fişiere Torrent</translation>
    </message>
    <message>
        <source>No input path set</source>
        <translation type="obsolete">Nu sunt selectate fişiere de intrare</translation>
    </message>
    <message>
        <source>Please type an input path first</source>
        <translation type="obsolete">Vă rugăm să arătaţi calea de intrare</translation>
    </message>
    <message>
        <source>Torrent creation</source>
        <translation type="obsolete">Crearea torentului</translation>
    </message>
    <message>
        <source>Torrent was created successfully:</source>
        <translation type="obsolete">Torrentul a fost creat cu success:</translation>
    </message>
    <message>
        <source>Select a folder to add to the torrent</source>
        <translation type="obsolete">Seletaţi directoriul pentru a fi adăugat în torrent fişier</translation>
    </message>
    <message>
        <source>Please type an announce URL</source>
        <translation type="obsolete">Introduceţi URL-ul de anunţare</translation>
    </message>
    <message>
        <source>Torrent creation was unsuccessful, reason: %1</source>
        <translation type="obsolete">Crearea torrent-ului a eşuat, motivul: %1</translation>
    </message>
    <message>
        <source>Announce URL:</source>
        <comment>Tracker URL</comment>
        <translation type="obsolete">URL-ul de anunţare:</translation>
    </message>
    <message>
        <source>Please type a web seed url</source>
        <translation type="obsolete">Introduceţi URL-ul de web seed</translation>
    </message>
    <message>
        <source>Web seed URL:</source>
        <translation type="obsolete">Web seed URL:</translation>
    </message>
    <message>
        <source>Select a file to add to the torrent</source>
        <translation type="obsolete">Selectaţi un fişier pentru al adăuga la torrent</translation>
    </message>
    <message>
        <source>Created torrent file is invalid. It won&apos;t be added to download list.</source>
        <translation type="obsolete">Fişierul torrent creat este deteriorat. El nu va fi adăugat în lista de download-uri.</translation>
    </message>
</context>
<context>
    <name>downloadFromURL</name>
    <message>
        <source>Download Torrents from URLs</source>
        <translation type="obsolete">Descărcarea Torrent-uri de pe URL-uri</translation>
    </message>
    <message>
        <source>Only one URL per line</source>
        <translation type="obsolete">Numai un URL pe linie</translation>
    </message>
    <message>
        <source>Download</source>
        <translation>Descarcă</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Anulare</translation>
    </message>
    <message>
        <source>Download from urls</source>
        <translation>Descărcare de pe url-uri</translation>
    </message>
    <message>
        <source>No URL entered</source>
        <translation>Nu este introdus URL-ul</translation>
    </message>
    <message>
        <source>Please type at least one URL.</source>
        <translation>Vă rugăm să introduceţi cel puţin un URL.</translation>
    </message>
    <message>
        <source>Add torrent links</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Both HTTP and Magnet links are supported</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>downloadThread</name>
    <message>
        <source>I/O Error</source>
        <translation type="obsolete">Eroare de intrare/eşire</translation>
    </message>
    <message>
        <source>The remote host name was not found (invalid hostname)</source>
        <translation type="obsolete">Numele host-ului nu a fost găsit(nume invalid)</translation>
    </message>
    <message>
        <source>The operation was canceled</source>
        <translation type="obsolete">Operțiunea a fost anulată</translation>
    </message>
    <message>
        <source>The remote server closed the connection prematurely, before the entire reply was received and processed</source>
        <translation type="obsolete">Serverul a închis conectarea înainte ca să recepționez și proceses răspunsul</translation>
    </message>
    <message>
        <source>The connection to the remote server timed out</source>
        <translation type="obsolete">Timpul de conectare la server a expirat</translation>
    </message>
    <message>
        <source>SSL/TLS handshake failed</source>
        <translation type="obsolete">Conectarea SSL/TLS eșuată</translation>
    </message>
    <message>
        <source>The remote server refused the connection</source>
        <translation type="obsolete">Serverul refuză conectarea</translation>
    </message>
    <message>
        <source>The connection to the proxy server was refused</source>
        <translation type="obsolete">Conectarea prin proxy server refuzată</translation>
    </message>
    <message>
        <source>The proxy server closed the connection prematurely</source>
        <translation type="obsolete">Serverul proxy a închis conectarea pre deverme</translation>
    </message>
    <message>
        <source>The proxy host name was not found</source>
        <translation type="obsolete">Numele serverului proxy nu este găsit</translation>
    </message>
    <message>
        <source>The connection to the proxy timed out or the proxy did not reply in time to the request sent</source>
        <translation type="obsolete">Timpul de conectare la proxy a expirat</translation>
    </message>
    <message>
        <source>The proxy requires authentication in order to honour the request but did not accept any credentials offered</source>
        <translation type="obsolete">The proxy requires authentication in order to honour the request but did not accept any credentials offered</translation>
    </message>
    <message>
        <source>The access to the remote content was denied (401)</source>
        <translation type="obsolete">The access to the remote content was denied (401)</translation>
    </message>
    <message>
        <source>The operation requested on the remote content is not permitted</source>
        <translation type="obsolete">The operation requested on the remote content is not permitted</translation>
    </message>
    <message>
        <source>The remote content was not found at the server (404)</source>
        <translation type="obsolete">The remote content was not found at the server (404)</translation>
    </message>
    <message>
        <source>The remote server requires authentication to serve the content but the credentials provided were not accepted</source>
        <translation type="obsolete">The remote server requires authentication to serve the content but the credentials provided were not accepted</translation>
    </message>
    <message>
        <source>The Network Access API cannot honor the request because the protocol is not known</source>
        <translation type="obsolete">The Network Access API cannot honor the request because the protocol is not known</translation>
    </message>
    <message>
        <source>The requested operation is invalid for this protocol</source>
        <translation type="obsolete">The requested operation is invalid for this protocol</translation>
    </message>
    <message>
        <source>An unknown network-related error was detected</source>
        <translation type="obsolete">An unknown network-related error was detected</translation>
    </message>
    <message>
        <source>An unknown proxy-related error was detected</source>
        <translation type="obsolete">An unknown proxy-related error was detected</translation>
    </message>
    <message>
        <source>An unknown error related to the remote content was detected</source>
        <translation type="obsolete">An unknown error related to the remote content was detected</translation>
    </message>
    <message>
        <source>A breakdown in protocol was detected</source>
        <translation type="obsolete">A breakdown in protocol was detected</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation type="obsolete">Eroare necunoscută</translation>
    </message>
</context>
<context>
    <name>engineSelect</name>
    <message>
        <source>Search plugins</source>
        <translation>Plugin-uri de căutare</translation>
    </message>
    <message>
        <source>Installed search engines:</source>
        <translation>Motoare de căutare instalare:</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nume</translation>
    </message>
    <message>
        <source>Url</source>
        <translation>Url</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Activată</translation>
    </message>
    <message>
        <source>Install a new one</source>
        <translation>Instalez un nou</translation>
    </message>
    <message>
        <source>Check for updates</source>
        <translation>Verifică pentru veriuni mai noi</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Închide</translation>
    </message>
    <message>
        <source>Enable</source>
        <translation type="obsolete">Activează</translation>
    </message>
    <message>
        <source>Disable</source>
        <translation type="obsolete">Dezactivat</translation>
    </message>
    <message>
        <source>Uninstall</source>
        <translation>Dezinstalează</translation>
    </message>
    <message>
        <source>You can get new search engine plugins here: &lt;a href=&quot;http://plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</source>
        <translation>You can get new search engine plugins here: &lt;a href=&quot;http://plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</translation>
    </message>
</context>
<context>
    <name>engineSelectDlg</name>
    <message>
        <source>Uninstall warning</source>
        <translation>Avertizare de dezinstalare</translation>
    </message>
    <message>
        <source>Some plugins could not be uninstalled because they are included in qBittorrent.
 Only the ones you added yourself can be uninstalled.
However, those plugins were disabled.</source>
        <translation>Unele plug-inuri nu pot fi dezinstalate deoarece sunt incluse în qBittorrent.
Numai acele adăugate de dvs. pot fi dezinstalate.
</translation>
    </message>
    <message>
        <source>Uninstall success</source>
        <translation>Dezinstalare cu success</translation>
    </message>
    <message>
        <source>Select search plugins</source>
        <translation>Alege motorul de căutare</translation>
    </message>
    <message>
        <source>qBittorrent search plugins</source>
        <translation>Plugin-urilie de căutare al qBittorrent</translation>
    </message>
    <message>
        <source>Search plugin install</source>
        <translation>Caută plugin-ul instalat</translation>
    </message>
    <message>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <source>A more recent version of %1 search engine plugin is already installed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>O versiune mai recentă de al motorului de căutare %1 este de acum instalată.</translation>
    </message>
    <message>
        <source>Search plugin update</source>
        <translation>Reînnoirea plugin-ului de căutare</translation>
    </message>
    <message>
        <source>Sorry, update server is temporarily unavailable.</source>
        <translation>Ne cerem ertare, serverul este temporar inaccesibil.</translation>
    </message>
    <message>
        <source>All your plugins are already up to date.</source>
        <translation>Totate plugin-urile dvs sunt deacum reînnoite.</translation>
    </message>
    <message>
        <source>%1 search engine plugin could not be updated, keeping old version.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>%1 motorul de căutare nu a putut fi reînnoit, folosesc versiunea veche.</translation>
    </message>
    <message>
        <source>%1 search engine plugin could not be installed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>motorul de căutare %1 nu poate fi instalat.</translation>
    </message>
    <message>
        <source>All selected plugins were uninstalled successfully</source>
        <translation>Toate plugin-urile selectate sunt dezinstalate cu success</translation>
    </message>
    <message>
        <source>%1 search engine plugin was successfully updated.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>motorul de căutare %1 a fost reînnoit cu success.</translation>
    </message>
    <message>
        <source>%1 search engine plugin was successfully installed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>motorul de căutare %1 a fost instalat cu success.</translation>
    </message>
    <message>
        <source>Sorry, %1 search plugin install failed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>Instalarea motorului de căutare %1 a eşuat.</translation>
    </message>
    <message>
        <source>New search engine plugin URL</source>
        <translation>Adresa noului motor de căutare URL</translation>
    </message>
    <message>
        <source>URL:</source>
        <translation>URL:</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Da</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Ny</translation>
    </message>
</context>
<context>
    <name>misc</name>
    <message>
        <source>B</source>
        <comment>bytes</comment>
        <translation>B</translation>
    </message>
    <message>
        <source>KiB</source>
        <comment>kibibytes (1024 bytes)</comment>
        <translation>Kib</translation>
    </message>
    <message>
        <source>MiB</source>
        <comment>mebibytes (1024 kibibytes)</comment>
        <translation>Mib</translation>
    </message>
    <message>
        <source>GiB</source>
        <comment>gibibytes (1024 mibibytes)</comment>
        <translation>GiB</translation>
    </message>
    <message>
        <source>TiB</source>
        <comment>tebibytes (1024 gibibytes)</comment>
        <translation>TiB</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Necunoscut</translation>
    </message>
    <message>
        <source>Unknown</source>
        <comment>Unknown (size)</comment>
        <translation>Necunoscut</translation>
    </message>
    <message>
        <source>&lt; 1m</source>
        <comment>&lt; 1 minute</comment>
        <translation>&lt; 1m</translation>
    </message>
    <message>
        <source>%1m</source>
        <comment>e.g: 10minutes</comment>
        <translation>%1m</translation>
    </message>
    <message>
        <source>%1h %2m</source>
        <comment>e.g: 3hours 5minutes</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1d %2h</source>
        <comment>e.g: 2days 10hours</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>qBittorrent will shutdown the computer now because all downloads are complete.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>options_imp</name>
    <message>
        <source>Choose a save directory</source>
        <translation>Selectează directoriul de salvare</translation>
    </message>
    <message>
        <source>Choose an ip filter file</source>
        <translation>Alageţi un fişier ip filtru</translation>
    </message>
    <message>
        <source>Filters</source>
        <translation>Filtre</translation>
    </message>
    <message>
        <source>Choose export directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add directory to scan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Folder is already being watched.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Folder does not exist.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Folder is not readable.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to add Scan Folder &apos;%1&apos;: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Parsing error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to parse the provided IP filter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Successfuly parsed the provided IP filter: %1 rules were applied.</source>
        <comment>%1 is a number</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Successfully refreshed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This is not a valid SSL key.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid certificate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This is not a valid SSL certificate.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SSL Certificate (*.crt *.pem)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SSL Key (*.key *.pem)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>pluginSourceDlg</name>
    <message>
        <source>Plugin source</source>
        <translation>Sursa plugin-ului</translation>
    </message>
    <message>
        <source>Search plugin source:</source>
        <translation>Caută sursa plugin-ului:</translation>
    </message>
    <message>
        <source>Local file</source>
        <translation>Fişier local</translation>
    </message>
    <message>
        <source>Web link</source>
        <translation>Legătură web</translation>
    </message>
</context>
<context>
    <name>preview</name>
    <message>
        <source>Preview selection</source>
        <translation>Secţia de preview</translation>
    </message>
    <message>
        <source>File preview</source>
        <translation>Preview Fişier</translation>
    </message>
    <message>
        <source>The following files support previewing, &lt;br&gt;please select one of them:</source>
        <translation>Următoarele fişiere suportă preview, &lt;br&gt;selectaţi unul din ei:</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Preview</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Anulare</translation>
    </message>
</context>
<context>
    <name>previewSelect</name>
    <message>
        <source>Preview impossible</source>
        <translation type="obsolete">Preview imposibil</translation>
    </message>
    <message>
        <source>Sorry, we can&apos;t preview this file</source>
        <translation type="obsolete">Nu putem face preview pentru acest fişier</translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="obsolete">Nume</translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="obsolete">Capacitate</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation type="obsolete">Progress</translation>
    </message>
</context>
<context>
    <name>search_engine</name>
    <message>
        <source>Search</source>
        <translation>Caută</translation>
    </message>
    <message>
        <source>Status:</source>
        <translation>Stare:</translation>
    </message>
    <message>
        <source>Stopped</source>
        <translation>Oprit</translation>
    </message>
    <message>
        <source>Download</source>
        <translation>Descarcă</translation>
    </message>
    <message>
        <source>Search engines...</source>
        <translation>Motoare de căutare...</translation>
    </message>
    <message>
        <source>Go to description page</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>torrentAdditionDialog</name>
    <message>
        <source>Unable to decode torrent file:</source>
        <translation>Nu pot decoda fişierul torrent:</translation>
    </message>
    <message>
        <source>Choose save path</source>
        <translation>Alegeţi calea de salvare</translation>
    </message>
    <message>
        <source>Empty save path</source>
        <translation>Calea de salvare vidă</translation>
    </message>
    <message>
        <source>Please enter a save path</source>
        <translation>Vă rugăm să introduceţi calea de salvare</translation>
    </message>
    <message>
        <source>Save path creation error</source>
        <translation>Salvează calea care crează erori</translation>
    </message>
    <message>
        <source>Could not create the save path</source>
        <translation>Nu pot crea calea de salvare</translation>
    </message>
    <message>
        <source>Invalid file selection</source>
        <translation>Selecţia fişierului invalidă</translation>
    </message>
    <message>
        <source>You must select at least one file in the torrent</source>
        <translation>Trebuie să selectaţi cel puţin un fişier din torrent</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation type="unfinished">Prioritate</translation>
    </message>
    <message>
        <source>(%1 left after torrent download)</source>
        <comment>e.g. (100MiB left after torrent download)</comment>
        <translation>(%1 rămas după descărcare torrent-ului)</translation>
    </message>
    <message>
        <source>(%1 more are required to download)</source>
        <comment>e.g. (100MiB more are required to download)</comment>
        <translation>(%1 mai mult este necesar pentru a descărca)</translation>
    </message>
    <message>
        <source>Seeding mode error</source>
        <translation>Eroare în modul de sedare</translation>
    </message>
    <message>
        <source>You chose to skip file checking. However, local files do not seem to exist in the current destionation folder. Please disable this feature or update the save path.</source>
        <translation>You chose to skip file checking. However, local files do not seem to exist in the current destionation folder. Please disable this feature or update the save path.</translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation>Redenumește...</translation>
    </message>
    <message>
        <source>New name:</source>
        <translation>Nume nou:</translation>
    </message>
    <message>
        <source>The file could not be renamed</source>
        <translation>Fișierul  nu poate fi redenumit</translation>
    </message>
    <message>
        <source>This name is already in use in this folder. Please use a different name.</source>
        <translation>This name is already in use in this folder. Please use a different name.</translation>
    </message>
    <message>
        <source>The folder could not be renamed</source>
        <translation>The folder could not be renamed</translation>
    </message>
    <message>
        <source>Rename the file</source>
        <translation>Rename the file</translation>
    </message>
    <message>
        <source>Unable to decode magnet link:</source>
        <translation>Unable to decode magnet link:</translation>
    </message>
    <message>
        <source>Magnet Link</source>
        <translation>Link-ul Magnet</translation>
    </message>
    <message>
        <source>Invalid label name</source>
        <translation>Numele este invalid</translation>
    </message>
    <message>
        <source>Please don&apos;t use any special characters in the label name.</source>
        <translation>Please don&apos;t use any special characters in the label name.</translation>
    </message>
    <message>
        <source>This file name contains forbidden characters, please choose a different one.</source>
        <translation>This file name contains forbidden characters, please choose a different one.</translation>
    </message>
</context>
</TS>
