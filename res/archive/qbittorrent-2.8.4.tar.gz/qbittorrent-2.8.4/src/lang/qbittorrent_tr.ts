<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="tr_TR">
<context>
    <name>AboutDlg</name>
    <message>
        <source>About qBittorrent</source>
        <translation>qBittorrent Hakkında</translation>
    </message>
    <message>
        <source>About</source>
        <translation>Hakkında</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Yazar</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation>Ad:</translation>
    </message>
    <message>
        <source>Country:</source>
        <translation>Ülke:</translation>
    </message>
    <message>
        <source>E-mail:</source>
        <translation>E-posta:</translation>
    </message>
    <message>
        <source>Christophe Dumez</source>
        <translation>Christophe Dumez</translation>
    </message>
    <message>
        <source>France</source>
        <translation>Fransa</translation>
    </message>
    <message>
        <source>Translation</source>
        <translation>Çeviri</translation>
    </message>
    <message>
        <source>License</source>
        <translation>Lisans</translation>
    </message>
    <message>
        <source>&lt;h3&gt;&lt;b&gt;qBittorrent&lt;/b&gt;&lt;/h3&gt;</source>
        <translation>&lt;h3&gt;&lt;b&gt;qBittorrent&lt;/b&gt;&lt;/h3&gt;</translation>
    </message>
    <message>
        <source>chris@qbittorrent.org</source>
        <translation></translation>
    </message>
    <message>
        <source>Thanks to</source>
        <translation>Teşekkürler</translation>
    </message>
    <message utf8="true">
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;An advanced BitTorrent client programmed in C++, based on Qt4 toolkit and libtorrent-rasterbar. &lt;br /&gt;&lt;br /&gt;Copyright ©2006-2011 Christophe Dumez&lt;br /&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Home Page:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://www.qbittorrent.org&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans&apos;; text-decoration: underline; color:#0057ae;&quot;&gt;http://www.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Bug Tracker:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://bugs.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;http://bugs.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Forum:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://forum.qbittorrent.org&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans&apos;; text-decoration: underline; color:#0057ae;&quot;&gt;http://forum.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;IRC:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; #qbittorrent on Freenode&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AdvancedSettings</name>
    <message>
        <source>Property</source>
        <translation type="obsolete">Özellik</translation>
    </message>
    <message>
        <source>Value</source>
        <translation type="obsolete">Değer</translation>
    </message>
    <message>
        <source>Ignore transfer limits on local network</source>
        <translation>Yerel ağda tarım sınırlarını yoksay</translation>
    </message>
    <message>
        <source>Include TCP/IP overhead in transfer limits</source>
        <translation type="obsolete">Aktarım sınırı içine TCP/IP ek yükünü kat</translation>
    </message>
    <message>
        <source>Disk write cache size</source>
        <translation>Yazılabilir disk ön arabellek boyutu</translation>
    </message>
    <message>
        <source> MiB</source>
        <translation>MB</translation>
    </message>
    <message>
        <source>Outgoing ports (Min) [0: Disabled]</source>
        <translation>Giden portlar (Min) [0: Etkisiz]</translation>
    </message>
    <message>
        <source>Outgoing ports (Max) [0: Disabled]</source>
        <translation>Giden portlar (Maks) [0: Etkisiz]</translation>
    </message>
    <message>
        <source>Recheck torrents on completion</source>
        <translation>Tamamlanmış torentleri yeniden denetle</translation>
    </message>
    <message>
        <source>Transfer list refresh interval</source>
        <translation>Aktarım listesi yenilenme aralığı</translation>
    </message>
    <message>
        <source> ms</source>
        <comment> milliseconds</comment>
        <translatorcomment>milisaniye</translatorcomment>
        <translation>ms</translation>
    </message>
    <message>
        <source>Resolve peer countries (GeoIP)</source>
        <translation>Eş ülkelerini çözümle (GeoIP)</translation>
    </message>
    <message>
        <source>Resolve peer host names</source>
        <translation>Ana makina adı eşlerini çöz</translation>
    </message>
    <message>
        <source>Maximum number of half-open connections [0: Disabled]</source>
        <translation>Yarı açık bağlantıların azami sayısı [0: Etkisiz]</translation>
    </message>
    <message>
        <source>Strict super seeding</source>
        <translation>Süper gönderme kipi</translation>
    </message>
    <message>
        <source>Network Interface (requires restart)</source>
        <translation>Ağ arayüzü (yeniden başlatma gerektirir)</translation>
    </message>
    <message>
        <source>Any interface</source>
        <comment>i.e. Any network interface</comment>
        <translatorcomment>örn. Herhangi bir ağ arayüzü</translatorcomment>
        <translation>Herhangi bir arayüz</translation>
    </message>
    <message>
        <source>Enable embedded tracker</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Embedded tracker port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Check for software updates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use system icon theme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confirm torrent deletion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>IP Address to report to trackers (requires restart)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Setting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Value</source>
        <comment>Value set for this setting</comment>
        <translation type="unfinished">Değer</translation>
    </message>
    <message>
        <source>Display program on-screen notifications</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exchange trackers with other peers</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AutomatedRssDownloader</name>
    <message>
        <source>Automated RSS Downloader</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable the automated RSS downloader</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Download rules</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rule definition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Must contain:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Must not contain:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>...</source>
        <translation type="unfinished">...</translation>
    </message>
    <message>
        <source>Assign label:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Apply rule to feeds:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Matching RSS articles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save to a different directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save to:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Import...</source>
        <translation type="unfinished">İçe aktar...</translation>
    </message>
    <message>
        <source>Export...</source>
        <translation type="unfinished">Dışa aktar...</translation>
    </message>
    <message>
        <source>New rule name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please type the name of the new download rule.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rule name conflict</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A rule with this name already exists, please choose another name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Are you sure you want to remove the download rule named %1?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Are you sure you want to remove the selected download rules?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rule deletion confirmation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Destination directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The list is empty, there is nothing to export.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Where would you like to save the list?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rules list (*.rssrules)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>I/O Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to create the destination file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please point to the RSS download rules file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rules list (*.rssrules *.filters)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Import Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to import the selected rules file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add new rule...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete rule</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rename rule...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete selected rules</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rule renaming</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please type the new rule name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use regular expressions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Regex mode: use Perl-like regular expressions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Wildcard mode: you can use&lt;ul&gt;&lt;li&gt;? to match any single character&lt;/li&gt;&lt;li&gt;* to match zero or more of any characters&lt;/li&gt;&lt;li&gt;Whitespaces count as AND operators&lt;/li&gt;&lt;/ul&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Wildcard mode: you can use&lt;ul&gt;&lt;li&gt;? to match any single character&lt;/li&gt;&lt;li&gt;* to match zero or more of any characters&lt;/li&gt;&lt;li&gt;| is used as OR operator&lt;/li&gt;&lt;/ul&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Bittorrent</name>
    <message>
        <source>%1 reached the maximum ratio you set.</source>
        <translation type="obsolete">%1, ayarladığınız azami orana ulaştı.</translation>
    </message>
    <message>
        <source>qBittorrent is bound to port: TCP/%1</source>
        <comment>e.g: qBittorrent is bound to port: 6881</comment>
        <translation type="obsolete">qBittorrent&apos;in bağlı olduğu port: TCP/%1</translation>
    </message>
    <message>
        <source>UPnP support [ON]</source>
        <translation type="obsolete">UPnP desteği [ON]</translation>
    </message>
    <message>
        <source>UPnP support [OFF]</source>
        <translation type="obsolete">UPnP desteği [OFF]</translation>
    </message>
    <message>
        <source>NAT-PMP support [ON]</source>
        <translation type="obsolete">NAT-PMP desteği [ON]</translation>
    </message>
    <message>
        <source>NAT-PMP support [OFF]</source>
        <translation type="obsolete">NAT-PMP desteği [OFF]</translation>
    </message>
    <message>
        <source>DHT support [ON], port: UDP/%1</source>
        <translation type="obsolete">DHT desteği [ON], port: UDP/%1</translation>
    </message>
    <message>
        <source>DHT support [OFF]</source>
        <translation type="obsolete">DHT desteği [OFF]</translation>
    </message>
    <message>
        <source>PeX support [ON]</source>
        <translation type="obsolete">EşD desteği [ON]</translation>
    </message>
    <message>
        <source>Local Peer Discovery [ON]</source>
        <translation type="obsolete">Yerel Eş Keşfi [ON]</translation>
    </message>
    <message>
        <source>Local Peer Discovery support [OFF]</source>
        <translation type="obsolete">Yerel Eş Keşfi desteği [OFF]</translation>
    </message>
    <message>
        <source>Encryption support [ON]</source>
        <translation type="obsolete">Şifreleme desteği [ON]</translation>
    </message>
    <message>
        <source>Encryption support [FORCED]</source>
        <translation type="obsolete">Şifreleme desteği [FORCED]</translation>
    </message>
    <message>
        <source>Encryption support [OFF]</source>
        <translation type="obsolete">Şifreleme desteği [OFF]</translation>
    </message>
    <message>
        <source>Web User Interface Error - Unable to bind Web UI to port %1</source>
        <translation type="obsolete">Web Kullanıcı Arayüzü Hatası - Web arayüzü bağlanamadı, port %1</translation>
    </message>
    <message>
        <source>&apos;%1&apos; was removed from transfer list and hard disk.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation type="obsolete">&apos;%1&apos;, aktarım listesinden ve sabit diskten kaldırıldı.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; was removed from transfer list.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation type="obsolete">&apos;%1&apos;, aktarım listesinden kaldırıldı.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is not a valid magnet URI.</source>
        <translation type="obsolete">&apos;%1&apos; geçerli bir adres değil.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is already in download list.</source>
        <comment>e.g: &apos;xxx.avi&apos; is already in download list.</comment>
        <translation type="obsolete">&apos;%1&apos;, zaten indirme listesinde.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; resumed. (fast resume)</source>
        <comment>&apos;/home/y/xxx.torrent&apos; was resumed. (fast resume)</comment>
        <translation type="obsolete">&apos;%1&apos;, devam edildi. (hızlı devam)</translation>
    </message>
    <message>
        <source>&apos;%1&apos; added to download list.</source>
        <comment>&apos;/home/y/xxx.torrent&apos; was added to download list.</comment>
        <translation type="obsolete">&apos;%1&apos;, indirme listesine eklendi.</translation>
    </message>
    <message>
        <source>Unable to decode torrent file: &apos;%1&apos;</source>
        <comment>e.g: Unable to decode torrent file: &apos;/home/y/xxx.torrent&apos;</comment>
        <translation type="obsolete">Torrent dosyası çözümlenemiyor: &apos;%1&apos;</translation>
    </message>
    <message>
        <source>This file is either corrupted or this isn&apos;t a torrent.</source>
        <translation type="obsolete">Bu dosya bozuk ya da torrent dosyası değil.</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;was blocked due to your IP filter&lt;/i&gt;</source>
        <comment>x.y.z.w was blocked</comment>
        <translation type="obsolete">&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt;, &lt;i&gt;IP süzgeciniz tarafından engellendi&lt;/i&gt;</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;was banned due to corrupt pieces&lt;/i&gt;</source>
        <comment>x.y.z.w was banned</comment>
        <translation type="obsolete">&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt;, &lt;i&gt;bozuk parçalar sebebiyle engellendi&lt;/i&gt;</translation>
    </message>
    <message>
        <source>Recursive download of file %1 embedded in torrent %2</source>
        <comment>Recursive download of test.torrent embedded in torrent test2</comment>
        <translation type="obsolete">%1 dosyasının özyineli indirmesi %2 torenti içine gömülü</translation>
    </message>
    <message>
        <source>Unable to decode %1 torrent file.</source>
        <translation type="obsolete">%1 torent dosyası çözümlenemiyor.</translation>
    </message>
    <message>
        <source>UPnP/NAT-PMP: Port mapping failure, message: %1</source>
        <translation type="obsolete">UPnP/NAT-PMP: Port adresleme hatası, ileti: %1</translation>
    </message>
    <message>
        <source>UPnP/NAT-PMP: Port mapping successful, message: %1</source>
        <translation type="obsolete">UPnP/NAT-PMP: Port adresleme başarılı, ileti: %1</translation>
    </message>
    <message>
        <source>Fast resume data was rejected for torrent %1, checking again...</source>
        <translation type="obsolete">Hızlı devam verisi %1 torrenti için reddedildi, yeniden denetleniyor...</translation>
    </message>
    <message>
        <source>Url seed lookup failed for url: %1, message: %2</source>
        <translation type="obsolete">Url gönderme araştırması başarısız: %1, ileti: %2</translation>
    </message>
    <message>
        <source>Downloading &apos;%1&apos;, please wait...</source>
        <comment>e.g: Downloading &apos;xxx.torrent&apos;, please wait...</comment>
        <translation type="obsolete">&apos;%1&apos;, indiriliyor, lütfen bekleyin...</translation>
    </message>
    <message>
        <source>Using a disk cache size of %1 MiB</source>
        <translation type="obsolete">%1 MB&apos;lık disk önbelleği kullanılıyor</translation>
    </message>
    <message>
        <source>PeX support [OFF]</source>
        <translation type="obsolete">PeX desteği [KAPALI]</translation>
    </message>
    <message>
        <source>Restart is required to toggle PeX support</source>
        <translation type="obsolete">PeX desteğini açmak/kapatmak için yeniden başlatmak gerekir</translation>
    </message>
    <message>
        <source>The Web UI is listening on port %1</source>
        <translation type="obsolete">Ağ arayüzünün kullandığı port: %1</translation>
    </message>
    <message>
        <source>HTTP user agent is %1</source>
        <translation type="obsolete">HTTP istemcisi: %1</translation>
    </message>
    <message>
        <source>Reason: %1</source>
        <translation type="obsolete">Sebep: %1</translation>
    </message>
    <message>
        <source>Note: new trackers were added to the existing torrent.</source>
        <translation type="obsolete">Not: yeni izleyiciler varolan torente eklendi.</translation>
    </message>
    <message>
        <source>Note: new URL seeds were added to the existing torrent.</source>
        <translation type="obsolete">Not: yeni URL eşleri varolan torente eklendi.</translation>
    </message>
    <message>
        <source>An I/O error occured, &apos;%1&apos; paused.</source>
        <translation type="obsolete">Bir G/Ç hatası meydana geldi, &apos;%1&apos; duraklatıldı.</translation>
    </message>
    <message>
        <source>Removing torrent %1...</source>
        <translation type="obsolete">Torent kaldırılıyor: %1...</translation>
    </message>
    <message>
        <source>Pausing torrent %1...</source>
        <translation type="obsolete">Torent duraklatılıyor: %1...</translation>
    </message>
    <message>
        <source>Error: The torrent %1 does not contain any file.</source>
        <translation type="obsolete">Hata: %1 torenti herhangi bir dosya içermiyor.</translation>
    </message>
    <message>
        <source>File sizes mismatch for torrent %1, pausing it.</source>
        <translation type="obsolete">%1 torentinin dosya boyutu eşleşmiyor, duraklatılıyor.</translation>
    </message>
</context>
<context>
    <name>ConsoleDlg</name>
    <message>
        <source>General</source>
        <translation type="obsolete">Genel</translation>
    </message>
    <message>
        <source>Blocked IPs</source>
        <translation type="obsolete">Engellenmiş IP&apos;ler</translation>
    </message>
    <message>
        <source>qBittorrent log viewer</source>
        <translation type="obsolete">qBittorrent kayıt görüntüleyici</translation>
    </message>
</context>
<context>
    <name>CookiesDlg</name>
    <message>
        <source>Cookies management</source>
        <translation>Çerez yönetimi</translation>
    </message>
    <message>
        <source>Key</source>
        <extracomment>As in Key/Value pair</extracomment>
        <translation>Anahtar</translation>
    </message>
    <message>
        <source>Value</source>
        <extracomment>As in Key/Value pair</extracomment>
        <translation>Değer</translation>
    </message>
    <message>
        <source>Common keys for cookies are : &apos;%1&apos;, &apos;%2&apos;.
You should get this information from your Web browser preferences.</source>
        <translation>Çerezler için yaygın anahtarlar: &apos;%1&apos;, &apos;%2&apos;.
Bu bilgiyi ağ tarayıcınızın yeğlenenler kısmından almalısınız.</translation>
    </message>
</context>
<context>
    <name>DNSUpdater</name>
    <message>
        <source>Your dynamic DNS was successfuly updated.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dynamic DNS error: The service is temporarily unavailable, it will be retried in 30 minutes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dynamic DNS error: hostname supplied does not exist under specified account.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dynamic DNS error: Invalid username/password.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dynamic DNS error: qBittorrent was blacklisted by the service, please report a bug at http://bugs.qbittorrent.org.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dynamic DNS error: %1 was returned by the service, please report a bug at http://bugs.qbittorrent.org.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dynamic DNS error: Your username was blocked due to abuse.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dynamic DNS error: supplied domain name is invalid.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dynamic DNS error: supplied username is too short.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dynamic DNS error: supplied password is too short.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DownloadThread</name>
    <message>
        <source>I/O Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The remote host name was not found (invalid hostname)</source>
        <translation type="unfinished">Uzak makina adı bulunamadı (geçersiz makina adı)</translation>
    </message>
    <message>
        <source>The operation was canceled</source>
        <translation type="unfinished">İşlem iptal edildi</translation>
    </message>
    <message>
        <source>The remote server closed the connection prematurely, before the entire reply was received and processed</source>
        <translation type="unfinished">Uzak sunucu, yanıt alınmadan ve işlenmeden bağlantıyı kapattı</translation>
    </message>
    <message>
        <source>The connection to the remote server timed out</source>
        <translation type="unfinished">Uzak sunucuya bağlantı zaman aşımına uğradı</translation>
    </message>
    <message>
        <source>SSL/TLS handshake failed</source>
        <translation type="unfinished">SSL/TLS başarısız</translation>
    </message>
    <message>
        <source>The remote server refused the connection</source>
        <translation type="unfinished">Uzak sunucu bağlantıyı reddetti</translation>
    </message>
    <message>
        <source>The connection to the proxy server was refused</source>
        <translation type="unfinished">Vekil sunucuya bağlantı reddedildi</translation>
    </message>
    <message>
        <source>The proxy server closed the connection prematurely</source>
        <translation type="unfinished">Vekil sunucu bağlantıyı beklenmeyen şekilde kapattı</translation>
    </message>
    <message>
        <source>The proxy host name was not found</source>
        <translation type="unfinished">Vekil makina adı bulunamadı</translation>
    </message>
    <message>
        <source>The connection to the proxy timed out or the proxy did not reply in time to the request sent</source>
        <translation type="unfinished">Vekille olan bağlantı zaman aşımına uğradı ya da vekil gönderilen isteğe zamanında yanıt vermedi</translation>
    </message>
    <message>
        <source>The proxy requires authentication in order to honour the request but did not accept any credentials offered</source>
        <translation type="unfinished">Vekil, isteği gerçekleştirmek için yetkilendirme gerektiriyor ancak sunulan kimliklerin hiçbirini kabul etmedi</translation>
    </message>
    <message>
        <source>The access to the remote content was denied (401)</source>
        <translation type="unfinished">Uzak içeriğe giriş reddedildi (401)</translation>
    </message>
    <message>
        <source>The operation requested on the remote content is not permitted</source>
        <translation type="unfinished">Uzak içerikteki işlem isteğine izin verilmedi</translation>
    </message>
    <message>
        <source>The remote content was not found at the server (404)</source>
        <translation type="unfinished">Uzak içerik sunucuda bulunamadı (404)</translation>
    </message>
    <message>
        <source>The remote server requires authentication to serve the content but the credentials provided were not accepted</source>
        <translation type="unfinished">Uzak sunucu, içeriğin uygunluğu için yetkilendirme istiyor ancak istenen kimlik kabul edilmedi</translation>
    </message>
    <message>
        <source>The Network Access API cannot honor the request because the protocol is not known</source>
        <translation type="unfinished">Ağ Girişi API isteği gerçekleştiremedi çünkü protokol bilinmiyor</translation>
    </message>
    <message>
        <source>The requested operation is invalid for this protocol</source>
        <translation type="unfinished">İstenen işlem bu protokol için geçersiz</translation>
    </message>
    <message>
        <source>An unknown network-related error was detected</source>
        <translation type="unfinished">Bilinmeyen ağla ilgili bir hata belirlendi</translation>
    </message>
    <message>
        <source>An unknown proxy-related error was detected</source>
        <translation type="unfinished">Bilinmeyen vekille ilgili bir hata belirlendi</translation>
    </message>
    <message>
        <source>An unknown error related to the remote content was detected</source>
        <translation type="unfinished">Bilinmeyen uzak içerikle ilgili bir hata belirlendi</translation>
    </message>
    <message>
        <source>A breakdown in protocol was detected</source>
        <translation type="unfinished">Protokolde bir hata belirlendi</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation type="unfinished">Bilinmeyen hata</translation>
    </message>
</context>
<context>
    <name>EventManager</name>
    <message>
        <source>%1/s</source>
        <comment>e.g. 120 KiB/s</comment>
        <translation>%1/s</translation>
    </message>
    <message>
        <source>Working</source>
        <translation>Çalışıyor</translation>
    </message>
    <message>
        <source>Updating...</source>
        <translation>Güncelleniyor...</translation>
    </message>
    <message>
        <source>Not working</source>
        <translation>Çalışmıyor</translation>
    </message>
    <message>
        <source>Not contacted yet</source>
        <translation>Daha bağlanılamadı</translation>
    </message>
    <message>
        <source>this session</source>
        <translation>bu oturum</translation>
    </message>
    <message>
        <source>/s</source>
        <comment>/second (i.e. per second)</comment>
        <translation>/s</translation>
    </message>
    <message>
        <source>Seeded for %1</source>
        <comment>e.g. Seeded for 3m10s</comment>
        <translation>Gönderme zamanı: %1</translation>
    </message>
    <message>
        <source>%1 max</source>
        <comment>e.g. 10 max</comment>
        <translation>azami: %1</translation>
    </message>
</context>
<context>
    <name>ExecutionLog</name>
    <message>
        <source>General</source>
        <translation type="unfinished">Genel</translation>
    </message>
    <message>
        <source>Blocked IPs</source>
        <translation type="unfinished">Engellenmiş IP&apos;ler</translation>
    </message>
</context>
<context>
    <name>FeedDownloader</name>
    <message>
        <source>RSS Feed downloader</source>
        <translation type="obsolete">RSS Besleme indirici</translation>
    </message>
    <message>
        <source>RSS feed:</source>
        <translation type="obsolete">RSS beslemesi:</translation>
    </message>
    <message>
        <source>Feed name</source>
        <translation type="obsolete">Besleme adı</translation>
    </message>
    <message>
        <source>Automatically download torrents from this feed</source>
        <translation type="obsolete">Bu beslemeden torentleri kendiliğinden indir</translation>
    </message>
    <message>
        <source>Download filters</source>
        <translation type="obsolete">İndirme süzgeçleri</translation>
    </message>
    <message>
        <source>Filters:</source>
        <translation type="obsolete">Süzgeçler:</translation>
    </message>
    <message>
        <source>Filter settings</source>
        <translation type="obsolete">Süzgeç ayarları</translation>
    </message>
    <message>
        <source>Matches:</source>
        <translation type="obsolete">Eşleşmeler:</translation>
    </message>
    <message>
        <source>Does not match:</source>
        <translation type="obsolete">Eşleşmeyen:</translation>
    </message>
    <message>
        <source>Destination folder:</source>
        <translation type="obsolete">Hedef klasör:</translation>
    </message>
    <message>
        <source>...</source>
        <translation type="obsolete">...</translation>
    </message>
    <message>
        <source>Filter testing</source>
        <translation type="obsolete">Süzgeç sınama</translation>
    </message>
    <message>
        <source>Torrent title:</source>
        <translation type="obsolete">Torent başlığı:</translation>
    </message>
    <message>
        <source>Result:</source>
        <translation type="obsolete">Sonuç:</translation>
    </message>
    <message>
        <source>Test</source>
        <translation type="obsolete">Sına</translation>
    </message>
    <message>
        <source>Import...</source>
        <translation type="obsolete">İçe aktar...</translation>
    </message>
    <message>
        <source>Export...</source>
        <translation type="obsolete">Dışa aktar...</translation>
    </message>
    <message>
        <source>Rename filter</source>
        <translation type="obsolete">Süzgeci yeniden adlandır</translation>
    </message>
    <message>
        <source>Remove filter</source>
        <translation type="obsolete">Süzgeci kaldır</translation>
    </message>
    <message>
        <source>Add filter</source>
        <translation type="obsolete">Süzgeç ekle</translation>
    </message>
</context>
<context>
    <name>FeedDownloaderDlg</name>
    <message>
        <source>New filter</source>
        <translation type="obsolete">Yeni süzgeç</translation>
    </message>
    <message>
        <source>Please choose a name for this filter</source>
        <translation type="obsolete">Lütfen bu süzgeç için yeni bir ad seçin</translation>
    </message>
    <message>
        <source>Filter name:</source>
        <translation type="obsolete">Süzgeç adı:</translation>
    </message>
    <message>
        <source>Invalid filter name</source>
        <translation type="obsolete">Geçersiz süzgeç adı</translation>
    </message>
    <message>
        <source>The filter name cannot be left empty.</source>
        <translation type="obsolete">Süzgeç adı boş bırakılamaz.</translation>
    </message>
    <message>
        <source>This filter name is already in use.</source>
        <translation type="obsolete">Bu süzgeç adı kullanımda.</translation>
    </message>
    <message>
        <source>Filter testing error</source>
        <translation type="obsolete">Süzgeç sınama hatası</translation>
    </message>
    <message>
        <source>Please specify a test torrent name.</source>
        <translation type="obsolete">Lütfen bir sınama torenti adı belirtin.</translation>
    </message>
    <message>
        <source>matches</source>
        <translation type="obsolete">eşleşmeler</translation>
    </message>
    <message>
        <source>does not match</source>
        <translation type="obsolete">eşleşme yok</translation>
    </message>
    <message>
        <source>Select file to import</source>
        <translation type="obsolete">İçe aktarmak için dosya seçin</translation>
    </message>
    <message>
        <source>Filters Files</source>
        <translation type="obsolete">Süzgeç Dosyaları</translation>
    </message>
    <message>
        <source>Import successful</source>
        <translation type="obsolete">İçe aktarma başarılı</translation>
    </message>
    <message>
        <source>Filters import was successful.</source>
        <translation type="obsolete">Süzgeçler başarıyla içe aktarıldı.</translation>
    </message>
    <message>
        <source>Import failure</source>
        <translation type="obsolete">İçe aktarma başarısız</translation>
    </message>
    <message>
        <source>Filters could not be imported due to an I/O error.</source>
        <translation type="obsolete">Süzgeçler bir Girdi/Çıktı hatası sebebiyle içe aktarılamadı.</translation>
    </message>
    <message>
        <source>Select destination file</source>
        <translation type="obsolete">Hedef dosyayı seçin</translation>
    </message>
    <message>
        <source>Export successful</source>
        <translation type="obsolete">Dışa aktarım başarılı</translation>
    </message>
    <message>
        <source>Filters export was successful.</source>
        <translation type="obsolete">Süzgeçler dışa başarıyla aktarıldı.</translation>
    </message>
    <message>
        <source>Export failure</source>
        <translation type="obsolete">Dışa aktarım başarısız</translation>
    </message>
    <message>
        <source>Filters could not be exported due to an I/O error.</source>
        <translation type="obsolete">Süzgeçler bir Girdi/Çıktı hatası sebebiyle dışa aktarılamadı.</translation>
    </message>
    <message>
        <source>Choose save path</source>
        <translation type="obsolete">Kayıt yolunu seç</translation>
    </message>
</context>
<context>
    <name>FeedList</name>
    <message>
        <source>Unread</source>
        <translation type="obsolete">Okunmadı</translation>
    </message>
</context>
<context>
    <name>FeedListWidget</name>
    <message>
        <source>RSS feeds</source>
        <translation type="unfinished">RSS beslemeleri</translation>
    </message>
    <message>
        <source>Unread</source>
        <translation type="unfinished">Okunmadı</translation>
    </message>
</context>
<context>
    <name>GUI</name>
    <message>
        <source>Open Torrent Files</source>
        <translation type="obsolete">Torrent Dosyasını Aç</translation>
    </message>
    <message>
        <source>Torrent Files</source>
        <translation type="obsolete">Torrent Dosyaları</translation>
    </message>
    <message>
        <source>qBittorrent</source>
        <translation type="obsolete">qBittorrent</translation>
    </message>
    <message>
        <source>Transfers</source>
        <translation type="obsolete">Aktarımlar</translation>
    </message>
    <message>
        <source>qBittorrent %1</source>
        <comment>e.g: qBittorrent v0.x</comment>
        <translation type="obsolete">qBittorrent %1</translation>
    </message>
    <message>
        <source>DL speed: %1 KiB/s</source>
        <comment>e.g: Download speed: 10 KiB/s</comment>
        <translation type="obsolete">İND hızı: %1 KB/s</translation>
    </message>
    <message>
        <source>UP speed: %1 KiB/s</source>
        <comment>e.g: Upload speed: 10 KiB/s</comment>
        <translation type="obsolete">GÖN hızı: %1 KB/s</translation>
    </message>
    <message>
        <source>%1 has finished downloading.</source>
        <comment>e.g: xxx.avi has finished downloading.</comment>
        <translation type="obsolete">%1 indirildi.</translation>
    </message>
    <message>
        <source>I/O Error</source>
        <comment>i.e: Input/Output Error</comment>
        <translation type="obsolete">I/O Hatası</translation>
    </message>
    <message>
        <source>Search</source>
        <translation type="obsolete">Arama</translation>
    </message>
    <message>
        <source>RSS</source>
        <translation type="obsolete">RSS</translation>
    </message>
    <message>
        <source>An I/O error occured for torrent %1.
 Reason: %2</source>
        <comment>e.g: An error occured for torrent xxx.avi.
 Reason: disk is full.</comment>
        <translatorcomment>G/Ç: Girdi/Çıktı</translatorcomment>
        <translation type="obsolete">%1 torrenti için bir G/Ç hatası meydana geldi.
 Sebep: %2</translation>
    </message>
    <message>
        <source>Alt+1</source>
        <comment>shortcut to switch to first tab</comment>
        <translation type="obsolete">Alt+1</translation>
    </message>
    <message>
        <source>Url download error</source>
        <translation type="obsolete">Adres indirme hatası</translation>
    </message>
    <message>
        <source>Couldn&apos;t download file at url: %1, reason: %2.</source>
        <translation type="obsolete">Adresteki dosya indirilemedi: %1, neden: %2.</translation>
    </message>
    <message>
        <source>Ctrl+F</source>
        <comment>shortcut to switch to search tab</comment>
        <translation type="obsolete">Ctrl+F</translation>
    </message>
    <message>
        <source>Options were saved successfully.</source>
        <translation type="obsolete">Seçenekler başarıyla kaydedildi.</translation>
    </message>
    <message>
        <source>Download completion</source>
        <translation type="obsolete">İndirme durumu</translation>
    </message>
    <message>
        <source>Some files are currently transferring.
Are you sure you want to quit qBittorrent?</source>
        <translation type="obsolete">Bazı dosyalar hala aktarılıyor.
qBittorrent&apos;ten çıkmak istediğinize emin misiniz?</translation>
    </message>
    <message>
        <source>Alt+2</source>
        <comment>shortcut to switch to third tab</comment>
        <translation type="obsolete">Alt+2</translation>
    </message>
    <message>
        <source>Alt+3</source>
        <comment>shortcut to switch to fourth tab</comment>
        <translation type="obsolete">Alt+3</translation>
    </message>
    <message>
        <source>Global Upload Speed Limit</source>
        <translation type="obsolete">Genel Gönderme Hızı Sınırı</translation>
    </message>
    <message>
        <source>Global Download Speed Limit</source>
        <translation type="obsolete">Genel İndirme Hızı Sınırı</translation>
    </message>
    <message>
        <source>qBittorrent %1 (Down: %2/s, Up: %3/s)</source>
        <comment>%1 is qBittorrent version</comment>
        <translation type="obsolete">qBittorrent %1 (İND: %2KB/s, GÖN: %3KB/s)</translation>
    </message>
    <message>
        <source>Recursive download confirmation</source>
        <translation type="obsolete">Özyineli indirilen doğrulama</translation>
    </message>
    <message>
        <source>The torrent %1 contains torrent files, do you want to proceed with their download?</source>
        <translation type="obsolete">%1 , torent dosyaları içeriyor, bunların indirilmesini birlikte yürütmek istiyor musunuz?</translation>
    </message>
    <message>
        <source>Transfers (%1)</source>
        <translation type="obsolete">Aktarımlar: (%1)</translation>
    </message>
    <message>
        <source>Torrent file association</source>
        <translation type="obsolete">Torent dosyası ilişkisi</translation>
    </message>
    <message>
        <source>qBittorrent is not the default application to open torrent files or Magnet links.
Do you want to associate qBittorrent to torrent files and Magnet links?</source>
        <translation type="obsolete">qBittorrent torent dosyaranı ve benzer bağlantıları açmak için varsayılan uygulama değil.
qBittorrent&apos;u bunlarla ilişkilendirmek ister misiniz?</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation type="obsolete">Evet</translation>
    </message>
    <message>
        <source>No</source>
        <translation type="obsolete">Hayır</translation>
    </message>
    <message>
        <source>Never</source>
        <translation type="obsolete">Asla</translation>
    </message>
    <message>
        <source>Always</source>
        <translation type="obsolete">Her zaman</translation>
    </message>
    <message>
        <source>Exiting qBittorrent</source>
        <translation type="obsolete">qBittorrent&apos;ten çıkılıyor</translation>
    </message>
</context>
<context>
    <name>GeoIP</name>
    <message>
        <source>Australia</source>
        <translation type="obsolete">Avustralya</translation>
    </message>
    <message>
        <source>Argentina</source>
        <translation type="obsolete">Arjantin</translation>
    </message>
    <message>
        <source>Austria</source>
        <translation type="obsolete">Avusturya</translation>
    </message>
    <message>
        <source>United Arab Emirates</source>
        <translation type="obsolete">Birleşik Arap Emirlikleri</translation>
    </message>
    <message>
        <source>Brazil</source>
        <translation type="obsolete">Brezilye</translation>
    </message>
    <message>
        <source>Bulgaria</source>
        <translation type="obsolete">Bulgaristan</translation>
    </message>
    <message>
        <source>Belarus</source>
        <translation type="obsolete">Beyaz Rusya</translation>
    </message>
    <message>
        <source>Belgium</source>
        <translation type="obsolete">Belçika</translation>
    </message>
    <message>
        <source>Bosnia</source>
        <translation type="obsolete">Bosna Hersek</translation>
    </message>
    <message>
        <source>Canada</source>
        <translation type="obsolete">Kanada</translation>
    </message>
    <message>
        <source>Czech Republic</source>
        <translation type="obsolete">Çek Cumhuriyeti</translation>
    </message>
    <message>
        <source>China</source>
        <translation type="obsolete">Çin</translation>
    </message>
    <message>
        <source>Costa Rica</source>
        <translation type="obsolete">Kosta Rika</translation>
    </message>
    <message>
        <source>Switzerland</source>
        <translation type="obsolete">İsviçre</translation>
    </message>
    <message>
        <source>Germany</source>
        <translation type="obsolete">Almanya</translation>
    </message>
    <message>
        <source>Denmark</source>
        <translation type="obsolete">Danimarka</translation>
    </message>
    <message>
        <source>Algeria</source>
        <translation type="obsolete">Cezayir</translation>
    </message>
    <message>
        <source>Spain</source>
        <translation type="obsolete">İspanya</translation>
    </message>
    <message>
        <source>Egypt</source>
        <translation type="obsolete">Mısır</translation>
    </message>
    <message>
        <source>Finland</source>
        <translation type="obsolete">Finlandiya</translation>
    </message>
    <message>
        <source>France</source>
        <translation type="obsolete">Fransa</translation>
    </message>
    <message>
        <source>United Kingdom</source>
        <translation type="obsolete">Birleşik Krallık</translation>
    </message>
    <message>
        <source>Greece</source>
        <translation type="obsolete">Yunanistan</translation>
    </message>
    <message>
        <source>Georgia</source>
        <translation type="obsolete">Gürcistan</translation>
    </message>
    <message>
        <source>Hungary</source>
        <translation type="obsolete">Macaristan</translation>
    </message>
    <message>
        <source>Croatia</source>
        <translation type="obsolete">Hırvatistan</translation>
    </message>
    <message>
        <source>Italy</source>
        <translation type="obsolete">İtalya</translation>
    </message>
    <message>
        <source>India</source>
        <translation type="obsolete">Hindistan</translation>
    </message>
    <message>
        <source>Israel</source>
        <translation type="obsolete">İsrail</translation>
    </message>
    <message>
        <source>Ireland</source>
        <translation type="obsolete">İrlanda</translation>
    </message>
    <message>
        <source>Iceland</source>
        <translation type="obsolete">İzlanda</translation>
    </message>
    <message>
        <source>Indonesia</source>
        <translation type="obsolete">Endonezya</translation>
    </message>
    <message>
        <source>Japan</source>
        <translation type="obsolete">Japonya</translation>
    </message>
    <message>
        <source>South Korea</source>
        <translation type="obsolete">Güney Kore</translation>
    </message>
    <message>
        <source>Luxembourg</source>
        <translation type="obsolete">Lüksemburg</translation>
    </message>
    <message>
        <source>Malaysia</source>
        <translation type="obsolete">Malezya</translation>
    </message>
    <message>
        <source>Mexico</source>
        <translation type="obsolete">Meksika</translation>
    </message>
    <message>
        <source>Serbia</source>
        <translation type="obsolete">Sırbistan</translation>
    </message>
    <message>
        <source>Morocco</source>
        <translation type="obsolete">Fas</translation>
    </message>
    <message>
        <source>Netherlands</source>
        <translation type="obsolete">Hollanda</translation>
    </message>
    <message>
        <source>Norway</source>
        <translation type="obsolete">Norveç</translation>
    </message>
    <message>
        <source>New Zealand</source>
        <translation type="obsolete">Yeni Zelanda</translation>
    </message>
    <message>
        <source>Portugal</source>
        <translation type="obsolete">Portekiz</translation>
    </message>
    <message>
        <source>Poland</source>
        <translation type="obsolete">Polonya</translation>
    </message>
    <message>
        <source>Pakistan</source>
        <translation type="obsolete">Pakistan</translation>
    </message>
    <message>
        <source>Philippines</source>
        <translation type="obsolete">Filipinler</translation>
    </message>
    <message>
        <source>Russia</source>
        <translation type="obsolete">Rusya</translation>
    </message>
    <message>
        <source>Romania</source>
        <translation type="obsolete">Romanya</translation>
    </message>
    <message>
        <source>France (Reunion Island)</source>
        <translation type="obsolete">Fransa (Birleşik Ada)</translation>
    </message>
    <message>
        <source>Sweden</source>
        <translation type="obsolete">İsveç</translation>
    </message>
    <message>
        <source>Slovakia</source>
        <translation type="obsolete">Slovakya</translation>
    </message>
    <message>
        <source>Singapore</source>
        <translation type="obsolete">Singapur</translation>
    </message>
    <message>
        <source>Slovenia</source>
        <translation type="obsolete">Slovenya</translation>
    </message>
    <message>
        <source>Taiwan</source>
        <translation type="obsolete">Tayvan</translation>
    </message>
    <message>
        <source>Turkey</source>
        <translation type="obsolete">Türkiye</translation>
    </message>
    <message>
        <source>Thailand</source>
        <translation type="obsolete">Tayland</translation>
    </message>
    <message>
        <source>USA</source>
        <translation type="obsolete">ABD</translation>
    </message>
    <message>
        <source>Ukraine</source>
        <translation type="obsolete">Ukrayna</translation>
    </message>
    <message>
        <source>South Africa</source>
        <translation type="obsolete">Güney Afrika</translation>
    </message>
    <message>
        <source>Saudi Arabia</source>
        <translation type="obsolete">Suudi Arabistan</translation>
    </message>
</context>
<context>
    <name>HeadlessLoader</name>
    <message>
        <source>Information</source>
        <translation>Bilgi</translation>
    </message>
    <message>
        <source>To control qBittorrent, access the Web UI at http://localhost:%1</source>
        <translation>qBittorrent&apos;i kontrol etmek için, Web Arayüzü&apos;ne giriş yolu: http://localhost:%1</translation>
    </message>
    <message>
        <source>The Web UI administrator user name is: %1</source>
        <translation>Web Arayüzü yöneticisinin kullanıcı adı: %1</translation>
    </message>
    <message>
        <source>The Web UI administrator password is still the default one: %1</source>
        <translation>Web Arayüzü yöneticisinin parolası hala varsayılan: %1</translation>
    </message>
    <message>
        <source>This is a security risk, please consider changing your password from program preferences.</source>
        <translation>Bu bir güvenlik riskidir, lütfen program yeğlenenlerinden parolanızı değiştirin.</translation>
    </message>
</context>
<context>
    <name>HttpConnection</name>
    <message>
        <source>Your IP address has been banned after too many failed authentication attempts.</source>
        <translation>IP adresiniz çok fazla yetkilendirme denemesi başarısızlığı nedeniyle yasaklandı.</translation>
    </message>
    <message>
        <source>D: %1/s - T: %2</source>
        <comment>Download speed: x KiB/s - Transferred: x MiB</comment>
        <translatorcomment>İndirme hızı: x KB/s - Aktarılan: x MB</translatorcomment>
        <translation>İND: %1/s - Top: %2</translation>
    </message>
    <message>
        <source>U: %1/s - T: %2</source>
        <comment>Upload speed: x KiB/s - Transferred: x MiB</comment>
        <translatorcomment>Gönderme hızı: x KB/s - Aktarılan: x MB</translatorcomment>
        <translation>GÖN: %1/s - Top: %2</translation>
    </message>
</context>
<context>
    <name>HttpServer</name>
    <message>
        <source>File</source>
        <translation>Dosya</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Düzenle</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Yardım</translation>
    </message>
    <message>
        <source>Delete from HD</source>
        <translation type="obsolete">Sabit diskten sil</translation>
    </message>
    <message>
        <source>Download Torrents from their URL or Magnet link</source>
        <translation>Torrentleri bir adresten ya da ilgili bağlantıdan indir</translation>
    </message>
    <message>
        <source>Only one link per line</source>
        <translation>Her satıra bir bağlantı</translation>
    </message>
    <message>
        <source>Download</source>
        <translation>İndir</translation>
    </message>
    <message>
        <source>Download local torrent</source>
        <translation>Yerel torrenti indir</translation>
    </message>
    <message>
        <source>Torrent files were correctly added to download list.</source>
        <translation>Torrent dosyaları indirme listesine başarılı bir şekilde eklendi.</translation>
    </message>
    <message>
        <source>Point to torrent file</source>
        <translation>Torrent dosyasını gösterir</translation>
    </message>
    <message>
        <source>Are you sure you want to delete the selected torrents from the transfer list and hard disk?</source>
        <translation>Seçili torrentleri aktarım listesinden ve sabit diskinizden silmek istediğinize emin misiniz?</translation>
    </message>
    <message>
        <source>Download rate limit must be greater than 0 or disabled.</source>
        <translation>İndirme oranı 0 büyük ya da etkisiz olmalı.</translation>
    </message>
    <message>
        <source>Upload rate limit must be greater than 0 or disabled.</source>
        <translation>Gönderme oranı 0&apos;dan büyük ya da etkisiz olmalı.</translation>
    </message>
    <message>
        <source>Maximum number of connections limit must be greater than 0 or disabled.</source>
        <translation>En yüksek sayıdaki bağlantı sınırı 0&apos;dan büyük ya da etkisiz olmalı.</translation>
    </message>
    <message>
        <source>Maximum number of connections per torrent limit must be greater than 0 or disabled.</source>
        <translation>Torrent başına en yüksek sayıdaki bağlantı sınırı 0&apos;dan büyük ya da etkisiz olmalı.</translation>
    </message>
    <message>
        <source>Maximum number of upload slots per torrent limit must be greater than 0 or disabled.</source>
        <translation>Torrent başına en yüksek sayıdaki gönderme yuvası sınırı 0&apos;dan yüksek ya da etkisiz olmalı.</translation>
    </message>
    <message>
        <source>Unable to save program preferences, qBittorrent is probably unreachable.</source>
        <translation>Program yeğlenenleri kaydedilemedi, qBittorrent&apos;e muhtemelen ulaşılamıyor.</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Dil</translation>
    </message>
    <message>
        <source>The port used for incoming connections must be greater than 1024 and less than 65535.</source>
        <translation>Gelen bağlantıların portu 1024&apos;ten büyük, 65535&apos;ten küçük olmalı.</translation>
    </message>
    <message>
        <source>The port used for the Web UI must be greater than 1024 and less than 65535.</source>
        <translation>Web Arayüzü için kullanılan port 1024&apos;ten büyük, 65535&apos;ten küçük olmalı.</translation>
    </message>
    <message>
        <source>The Web UI username must be at least 3 characters long.</source>
        <translation>Web arayüzü kullanıcı adı en az 3 karakter uzunluğunda olmalı.</translation>
    </message>
    <message>
        <source>The Web UI password must be at least 3 characters long.</source>
        <translation>Web arayüzü parolası en az 3 karakter uzunluğunda olmalı.</translation>
    </message>
    <message>
        <source>Downloaded</source>
        <comment>Is the file downloaded or not?</comment>
        <translatorcomment>Dosya indirildi mi indirilmedi mi?</translatorcomment>
        <translation>İndirilen</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>qBittorrent client is not reachable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>HTTP Server</source>
        <translation type="unfinished">HTTP Sunucu</translation>
    </message>
    <message>
        <source>Torrent path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Torrent name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The following parameters are supported:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LegalNotice</name>
    <message>
        <source>Legal Notice</source>
        <translation>Yasal Not</translation>
    </message>
    <message>
        <source>Legal notice</source>
        <translation>Yasal not</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Vazgeç</translation>
    </message>
    <message>
        <source>I Agree</source>
        <translation>Katılıyorum</translation>
    </message>
    <message>
        <source>qBittorrent is a file sharing program. When you run a torrent, its data will be made available to others by means of upload. Any content you share is your sole responsibility.

No further notices will be issued.</source>
        <translation>qBittorrent bir dosya paylaşım programıdır. Bir torent çalıştırdığınızda başkaları tarafından kopyalanabilecektir. Paylaştığınız tüm içerik sizin sorumluluğunuzdadır.

Başka bir bildiri yayınlanmayacaktır.</translation>
    </message>
    <message>
        <source>Press %1 key to accept and continue...</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>LineEdit</name>
    <message>
        <source>Clear the text</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>&amp;Edit</source>
        <translation>D&amp;üzen</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Dosya</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Yardım</translation>
    </message>
    <message>
        <source>Preview file</source>
        <translation type="obsolete">Dosya önizleme</translation>
    </message>
    <message>
        <source>Clear log</source>
        <translation type="obsolete">Günlüğü temizle</translation>
    </message>
    <message>
        <source>Decrease priority</source>
        <translation>Önceliği düşür</translation>
    </message>
    <message>
        <source>Increase priority</source>
        <translation>Önceliği arttır</translation>
    </message>
    <message>
        <source>&amp;Tools</source>
        <translation>&amp;Araçlar</translation>
    </message>
    <message>
        <source>&amp;View</source>
        <translation>&amp;Görünüm</translation>
    </message>
    <message>
        <source>&amp;Add File...</source>
        <translation type="obsolete">&amp;Dosya Ekle...</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation type="obsolete">Çı&amp;kış</translation>
    </message>
    <message>
        <source>&amp;Options...</source>
        <translation>&amp;Seçenekler...</translation>
    </message>
    <message>
        <source>Add &amp;URL...</source>
        <translation type="obsolete">&amp;URL ekle...</translation>
    </message>
    <message>
        <source>Torrent &amp;creator</source>
        <translation>Torent &amp;oluşturucu</translation>
    </message>
    <message>
        <source>Set upload limit...</source>
        <translation>Gönderim sınırı ayarla...</translation>
    </message>
    <message>
        <source>Set download limit...</source>
        <translation>İndirme sınırı ayarla...</translation>
    </message>
    <message>
        <source>Set global download limit...</source>
        <translation>Genel indirme sınırı ayarla...</translation>
    </message>
    <message>
        <source>Set global upload limit...</source>
        <translation>Genel gönderim sınırı ayarla...</translation>
    </message>
    <message>
        <source>&amp;Log viewer...</source>
        <translation type="obsolete">&amp;Kayıt görüntüleyici...</translation>
    </message>
    <message>
        <source>Top &amp;tool bar</source>
        <translation>Üst &amp;araç çubuğu</translation>
    </message>
    <message>
        <source>Display top tool bar</source>
        <translation>Üst araç çubuğunu göster</translation>
    </message>
    <message>
        <source>&amp;Speed in title bar</source>
        <translation>Başlık çubuğunda &amp;hızı göster</translation>
    </message>
    <message>
        <source>Show transfer speed in title bar</source>
        <translation>Aktarım hızını başlık çubuğunda göster</translation>
    </message>
    <message>
        <source>Alternative speed limits</source>
        <translation>Akıllı hız sınırları</translation>
    </message>
    <message>
        <source>&amp;About</source>
        <translation>&amp;Hakkında</translation>
    </message>
    <message>
        <source>&amp;Pause</source>
        <translation>&amp;Duraklat</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>&amp;Sil</translation>
    </message>
    <message>
        <source>P&amp;ause All</source>
        <translation>Tümünü D&amp;uraklat</translation>
    </message>
    <message>
        <source>Visit &amp;Website</source>
        <translation>S&amp;iteyi Ziyaret Et</translation>
    </message>
    <message>
        <source>Report a &amp;bug</source>
        <translation>Bir hata &amp;bildir</translation>
    </message>
    <message>
        <source>&amp;Documentation</source>
        <translation>B&amp;elgeleme</translation>
    </message>
    <message>
        <source>&amp;RSS reader</source>
        <translation>&amp;RSS okuyucu</translation>
    </message>
    <message>
        <source>Search &amp;engine</source>
        <translation>Arama &amp;motoru</translation>
    </message>
    <message>
        <source>Log viewer</source>
        <translation type="obsolete">Kayıt görüntüleyici</translation>
    </message>
    <message>
        <source>Lock qBittorrent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+L</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Resume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>R&amp;esume All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Import torrent...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Donate money</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If you like qBittorrent, please donate!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>qBittorrent %1</source>
        <comment>e.g: qBittorrent v0.x</comment>
        <translation type="unfinished">qBittorrent %1</translation>
    </message>
    <message>
        <source>Set the password...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Transfers</source>
        <translation type="unfinished">Aktarımlar</translation>
    </message>
    <message>
        <source>Torrent file association</source>
        <translation type="unfinished">Torent dosyası ilişkisi</translation>
    </message>
    <message>
        <source>qBittorrent is not the default application to open torrent files or Magnet links.
Do you want to associate qBittorrent to torrent files and Magnet links?</source>
        <translation type="unfinished">qBittorrent torent dosyaranı ve benzer bağlantıları açmak için varsayılan uygulama değil.
qBittorrent&apos;u bunlarla ilişkilendirmek ister misiniz?</translation>
    </message>
    <message>
        <source>UI lock password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please type the UI lock password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Password update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The UI lock password has been successfully updated</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>RSS</source>
        <translation type="unfinished">RSS</translation>
    </message>
    <message>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Transfers (%1)</source>
        <translation type="unfinished">Aktarımlar: (%1)</translation>
    </message>
    <message>
        <source>Download completion</source>
        <translation type="unfinished">İndirme durumu</translation>
    </message>
    <message>
        <source>%1 has finished downloading.</source>
        <comment>e.g: xxx.avi has finished downloading.</comment>
        <translation type="unfinished">%1 indirildi.</translation>
    </message>
    <message>
        <source>I/O Error</source>
        <comment>i.e: Input/Output Error</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>An I/O error occured for torrent %1.
 Reason: %2</source>
        <comment>e.g: An error occured for torrent xxx.avi.
 Reason: disk is full.</comment>
        <translation type="unfinished">%1 torrenti için bir G/Ç hatası meydana geldi.
 Sebep: %2</translation>
    </message>
    <message>
        <source>Alt+1</source>
        <comment>shortcut to switch to first tab</comment>
        <translation type="unfinished">Alt+1</translation>
    </message>
    <message>
        <source>Alt+2</source>
        <comment>shortcut to switch to third tab</comment>
        <translation type="unfinished">Alt+2</translation>
    </message>
    <message>
        <source>Ctrl+F</source>
        <comment>shortcut to switch to search tab</comment>
        <translation type="unfinished">Ctrl+F</translation>
    </message>
    <message>
        <source>Alt+3</source>
        <comment>shortcut to switch to fourth tab</comment>
        <translation type="unfinished">Alt+3</translation>
    </message>
    <message>
        <source>Recursive download confirmation</source>
        <translation type="unfinished">Özyineli indirilen doğrulama</translation>
    </message>
    <message>
        <source>The torrent %1 contains torrent files, do you want to proceed with their download?</source>
        <translation type="unfinished">%1 , torent dosyaları içeriyor, bunların indirilmesini birlikte yürütmek istiyor musunuz?</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation type="unfinished">Evet</translation>
    </message>
    <message>
        <source>No</source>
        <translation type="unfinished">Hayır</translation>
    </message>
    <message>
        <source>Never</source>
        <translation type="unfinished">Asla</translation>
    </message>
    <message>
        <source>Url download error</source>
        <translation type="unfinished">Adres indirme hatası</translation>
    </message>
    <message>
        <source>Couldn&apos;t download file at url: %1, reason: %2.</source>
        <translation type="unfinished">Adresteki dosya indirilemedi: %1, neden: %2.</translation>
    </message>
    <message>
        <source>Global Upload Speed Limit</source>
        <translation type="unfinished">Genel Gönderme Hızı Sınırı</translation>
    </message>
    <message>
        <source>Global Download Speed Limit</source>
        <translation type="unfinished">Genel İndirme Hızı Sınırı</translation>
    </message>
    <message>
        <source>Invalid password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The password is invalid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exiting qBittorrent</source>
        <translation type="unfinished">qBittorrent&apos;ten çıkılıyor</translation>
    </message>
    <message>
        <source>Some files are currently transferring.
Are you sure you want to quit qBittorrent?</source>
        <translation type="unfinished">Bazı dosyalar hala aktarılıyor.
qBittorrent&apos;ten çıkmak istediğinize emin misiniz?</translation>
    </message>
    <message>
        <source>Always</source>
        <translation type="unfinished">Her zaman</translation>
    </message>
    <message>
        <source>Open Torrent Files</source>
        <translation type="unfinished">Torrent Dosyasını Aç</translation>
    </message>
    <message>
        <source>Torrent Files</source>
        <translation type="unfinished">Torrent Dosyaları</translation>
    </message>
    <message>
        <source>Options were saved successfully.</source>
        <translation type="unfinished">Seçenekler başarıyla kaydedildi.</translation>
    </message>
    <message>
        <source>qBittorrent</source>
        <translation type="unfinished">qBittorrent</translation>
    </message>
    <message>
        <source>DL speed: %1 KiB/s</source>
        <comment>e.g: Download speed: 10 KiB/s</comment>
        <translation type="unfinished">İND hızı: %1 KB/s</translation>
    </message>
    <message>
        <source>UP speed: %1 KiB/s</source>
        <comment>e.g: Upload speed: 10 KiB/s</comment>
        <translation type="unfinished">GÖN hızı: %1 KB/s</translation>
    </message>
    <message>
        <source>qBittorrent %1 (Down: %2/s, Up: %3/s)</source>
        <comment>%1 is qBittorrent version</comment>
        <translation type="unfinished">qBittorrent %1 (İND: %2KB/s, GÖN: %3KB/s)</translation>
    </message>
    <message>
        <source>A newer version is available</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A newer version of qBittorrent is available on Sourceforge.
Would you like to update qBittorrent to version %1?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Impossible to update qBittorrent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>qBittorrent failed to update, reason: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Add torrent file...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add &amp;link to torrent...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Import existing torrent...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Execution &amp;Log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Execution Log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Auto-Shutdown on downloads completion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exit qBittorrent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Suspend system</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shutdown system</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation type="unfinished">Etkisiz</translation>
    </message>
    <message>
        <source>The password should contain at least 3 characters</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PeerAdditionDlg</name>
    <message>
        <source>Invalid IP</source>
        <translation>Geçersiz IP</translation>
    </message>
    <message>
        <source>The IP you provided is invalid.</source>
        <translation>Sunduğunuz IP geçersiz.</translation>
    </message>
</context>
<context>
    <name>PeerListDelegate</name>
    <message>
        <source>/s</source>
        <comment>/second (i.e. per second)</comment>
        <translatorcomment>/saniye (örn. saniye başı)</translatorcomment>
        <translation>/s</translation>
    </message>
</context>
<context>
    <name>PeerListWidget</name>
    <message>
        <source>IP</source>
        <translation>IP</translation>
    </message>
    <message>
        <source>Client</source>
        <comment>i.e.: Client application</comment>
        <translation>İstemci</translation>
    </message>
    <message>
        <source>Progress</source>
        <comment>i.e: % downloaded</comment>
        <translation>İlerleme</translation>
    </message>
    <message>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>İndirme Hızı</translation>
    </message>
    <message>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Gönderme Hızı</translation>
    </message>
    <message>
        <source>Downloaded</source>
        <comment>i.e: total data downloaded</comment>
        <translation>İndirilen</translation>
    </message>
    <message>
        <source>Uploaded</source>
        <comment>i.e: total data uploaded</comment>
        <translation>Gönderilen</translation>
    </message>
    <message>
        <source>Ban peer permanently</source>
        <translation>Eşi kalıcı olarak yasakla</translation>
    </message>
    <message>
        <source>Peer addition</source>
        <translation>Eş ekleme</translation>
    </message>
    <message>
        <source>The peer was added to this torrent.</source>
        <translation>Eş, bu torrente eklendi.</translation>
    </message>
    <message>
        <source>The peer could not be added to this torrent.</source>
        <translation>Eş, bu torrente eklenemedi.</translation>
    </message>
    <message>
        <source>Are you sure? -- qBittorrent</source>
        <translation>Emin misiniz? -- qBittorrent</translation>
    </message>
    <message>
        <source>Are you sure you want to ban permanently the selected peers?</source>
        <translation>Seçili eşleri kalıcı olarak silmek istediğinizden emin misiniz?</translation>
    </message>
    <message>
        <source>&amp;Yes</source>
        <translation>&amp;Evet</translation>
    </message>
    <message>
        <source>&amp;No</source>
        <translation>&amp;Hayır</translation>
    </message>
    <message>
        <source>Manually banning peer %1...</source>
        <translation>Elle yasaklanan eş: %1...</translation>
    </message>
    <message>
        <source>Upload rate limiting</source>
        <translation>Gönderme oranını sınırla</translation>
    </message>
    <message>
        <source>Download rate limiting</source>
        <translation>İndirme oranını sınırla</translation>
    </message>
    <message>
        <source>Add a new peer...</source>
        <translation>Yeni bir eş ekle...</translation>
    </message>
    <message>
        <source>Limit download rate...</source>
        <translation>İndirme oranını sınırla...</translation>
    </message>
    <message>
        <source>Limit upload rate...</source>
        <translation>Gönderme oranını sınırla...</translation>
    </message>
    <message>
        <source>Copy IP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Connection</source>
        <translation type="unfinished">Bağlantı</translation>
    </message>
</context>
<context>
    <name>Preferences</name>
    <message>
        <source>UI</source>
        <extracomment>User Interface</extracomment>
        <translation type="obsolete">Arayüz</translation>
    </message>
    <message>
        <source>Downloads</source>
        <translation>İndirilenler</translation>
    </message>
    <message>
        <source>Connection</source>
        <translation>Bağlantı</translation>
    </message>
    <message>
        <source>Bittorrent</source>
        <translation type="obsolete">Bittorrent</translation>
    </message>
    <message>
        <source>Proxy</source>
        <translation type="obsolete">Vekil</translation>
    </message>
    <message>
        <source>Web UI</source>
        <translation>Web Arayüzü</translation>
    </message>
    <message>
        <source>Language:</source>
        <translation type="obsolete">Dil:</translation>
    </message>
    <message>
        <source>(Requires restart)</source>
        <translation>(Yeniden başlatma gerektirir)</translation>
    </message>
    <message>
        <source>Visual style:</source>
        <translation type="obsolete">Görsel biçem:</translation>
    </message>
    <message>
        <source>Transfer list</source>
        <translation type="obsolete">Aktarım listesi</translation>
    </message>
    <message>
        <source>Use alternating row colors</source>
        <extracomment>In transfer list, one every two rows will have grey background.</extracomment>
        <translatorcomment>Aktarım listesinde, her iki sırada bir gri artalan olacak.</translatorcomment>
        <translation>Başka sıra renkleri kullan</translation>
    </message>
    <message>
        <source>File system</source>
        <translation type="obsolete">Dosya sistemi</translation>
    </message>
    <message>
        <source>Torrent queueing</source>
        <translation type="obsolete">Torent kuyruğu</translation>
    </message>
    <message>
        <source>Maximum active downloads:</source>
        <translation>Azami etkin indirilen:</translation>
    </message>
    <message>
        <source>Maximum active uploads:</source>
        <translation>Azami etkin gönderilen:</translation>
    </message>
    <message>
        <source>Maximum active torrents:</source>
        <translation>Azami etkin torent:</translation>
    </message>
    <message>
        <source>When adding a torrent</source>
        <translation>Bir torent eklerken</translation>
    </message>
    <message>
        <source>Display torrent content and some options</source>
        <translation>Torent içeriğini ve bazı seçenekleri göster</translation>
    </message>
    <message>
        <source>Listening port</source>
        <translation type="obsolete">Kullanılan port</translation>
    </message>
    <message>
        <source>Port used for incoming connections:</source>
        <translation>Gelen bağlantılar için kullanılacak port:</translation>
    </message>
    <message>
        <source>Random</source>
        <translation>Rastgele</translation>
    </message>
    <message>
        <source>Enable UPnP port mapping</source>
        <translation type="obsolete">UPnP port haritalamayı etkinleştir</translation>
    </message>
    <message>
        <source>Enable NAT-PMP port mapping</source>
        <translation type="obsolete">NAT-PMP port haritalamayı etkinleştir</translation>
    </message>
    <message>
        <source>Connections limit</source>
        <translation type="obsolete">Bağlantı sınırı</translation>
    </message>
    <message>
        <source>Global maximum number of connections:</source>
        <translation>Genel azami bağlantı sayısı:</translation>
    </message>
    <message>
        <source>Maximum number of connections per torrent:</source>
        <translation>Torent başına azami bağlantı sayısı:</translation>
    </message>
    <message>
        <source>Maximum number of upload slots per torrent:</source>
        <translation>Torent başına azami gönderme yuvası sayısı:</translation>
    </message>
    <message>
        <source>Upload:</source>
        <translation>Gönderme:</translation>
    </message>
    <message>
        <source>Download:</source>
        <translation>İndirme:</translation>
    </message>
    <message>
        <source>KiB/s</source>
        <translation>KB/s</translation>
    </message>
    <message>
        <source>Bittorrent features</source>
        <translation type="obsolete">Bittorrent özellikleri</translation>
    </message>
    <message>
        <source>Enable DHT network (decentralized)</source>
        <translation type="obsolete">DHT ağını etkinleştir (dağıtılmış)</translation>
    </message>
    <message>
        <source>Use a different port for DHT and Bittorrent</source>
        <translation type="obsolete">DHT ve Bittorrent için farklı bir port kullan</translation>
    </message>
    <message>
        <source>DHT port:</source>
        <translation>DHT portu:</translation>
    </message>
    <message>
        <source>Enable Peer Exchange / PeX (requires restart)</source>
        <translation type="obsolete">Eş Değişimini Etkinleştir / PeX (yeniden başlatmak gerekir)</translation>
    </message>
    <message>
        <source>Enable Local Peer Discovery</source>
        <translation type="obsolete">Yerel Eş Keşfini Etkinleştir</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation type="obsolete">Etkin</translation>
    </message>
    <message>
        <source>Forced</source>
        <translation type="obsolete">Zorlandı</translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation type="obsolete">Etkisiz</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation>Tip:</translation>
    </message>
    <message>
        <source>(None)</source>
        <translation>(Hiçbiri)</translation>
    </message>
    <message>
        <source>HTTP</source>
        <translation>HTTP</translation>
    </message>
    <message>
        <source>Port:</source>
        <translation>Port:</translation>
    </message>
    <message>
        <source>Authentication</source>
        <translation>Kimlik Denetimi</translation>
    </message>
    <message>
        <source>Username:</source>
        <translation>Kullanıcı adı:</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation>Parola:</translation>
    </message>
    <message>
        <source>SOCKS5</source>
        <translation>SOCKS5</translation>
    </message>
    <message>
        <source>HTTP Server</source>
        <translation type="obsolete">HTTP Sunucu</translation>
    </message>
    <message>
        <source>Filter path (.dat, .p2p, .p2b):</source>
        <translation>Süzgeç yolu (.dat, .p2p, .p2b):</translation>
    </message>
    <message>
        <source>HTTP Communications (trackers, Web seeds, search engine)</source>
        <translation type="obsolete">HTTP İletişimi (izleyiciler, Web eşleri, arama motoru)</translation>
    </message>
    <message>
        <source>Host:</source>
        <translation>Ana Makina:</translation>
    </message>
    <message>
        <source>Peer Communications</source>
        <translation type="obsolete">Eş İletişimi</translation>
    </message>
    <message>
        <source>SOCKS4</source>
        <translation>SOCKS4</translation>
    </message>
    <message>
        <source>Speed</source>
        <translation>Hız</translation>
    </message>
    <message>
        <source>Global speed limits</source>
        <translation type="obsolete">Genel hız sınırları</translation>
    </message>
    <message>
        <source>Alternative global speed limits</source>
        <translation type="obsolete">Akıllı genel hız sınırları</translation>
    </message>
    <message>
        <source>to</source>
        <extracomment>time1 to time2</extracomment>
        <translatorcomment>zaman1&apos;den zaman2&apos;ye</translatorcomment>
        <translation>&gt;</translation>
    </message>
    <message>
        <source>Every day</source>
        <translation>Her gün</translation>
    </message>
    <message>
        <source>Week days</source>
        <translation>Hafta içi</translation>
    </message>
    <message>
        <source>Week ends</source>
        <translation>Haftasonu</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Gelişmiş</translation>
    </message>
    <message>
        <source>Copy .torrent files to:</source>
        <translation>.torrent dosyasını kopyala:</translation>
    </message>
    <message>
        <source>Remove folder</source>
        <translation>Klasörü kaldır</translation>
    </message>
    <message>
        <source>No action</source>
        <translation>Hiçbir şey yapma</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>Seçenekler</translation>
    </message>
    <message>
        <source>Visual Appearance</source>
        <translation type="obsolete">Görsel Özellikler</translation>
    </message>
    <message>
        <source>Action on double-click</source>
        <translation>Çift tıklama eylemi</translation>
    </message>
    <message>
        <source>Downloading torrents:</source>
        <translation>Torent indiriliyor:</translation>
    </message>
    <message>
        <source>Start / Stop</source>
        <translation type="obsolete">Başlat / Durdur</translation>
    </message>
    <message>
        <source>Open destination folder</source>
        <translation>Hedef klasörü aç</translation>
    </message>
    <message>
        <source>Completed torrents:</source>
        <translation>Tamamlanan torentler:</translation>
    </message>
    <message>
        <source>Desktop</source>
        <translation>Masaüstü</translation>
    </message>
    <message>
        <source>Show splash screen on start up</source>
        <translation>Açılış ekranını başlangıçta göster</translation>
    </message>
    <message>
        <source>Start qBittorrent minimized</source>
        <translation>qBittorrent&apos;i küçültülmüş başlat</translation>
    </message>
    <message>
        <source>Show qBittorrent icon in notification area</source>
        <translation type="obsolete">qBittorrent simgesini bildirim alanında göster</translation>
    </message>
    <message>
        <source>Minimize qBittorrent to notification area</source>
        <translation>qBittorrent&apos;i bildirim alanına küçült</translation>
    </message>
    <message>
        <source>Close qBittorrent to notification area</source>
        <comment>i.e: The systray tray icon will still be visible when closing the main window.</comment>
        <translatorcomment>örn. Sistem tepsisi simgesi ana pencere kapatıldığında görünür.</translatorcomment>
        <translation>qBittorrent&apos;i bildirim alanına kapat</translation>
    </message>
    <message>
        <source>Do not start the download automatically</source>
        <comment>The torrent will be added to download list in pause state</comment>
        <translatorcomment>Torent, indirme listesine duraklatılmış durumda eklenir</translatorcomment>
        <translation>İndirmeyi kendiliğinden olarak başlatma</translation>
    </message>
    <message>
        <source>Save files to location:</source>
        <translation>Dosyaların kaydedileceği yer:</translation>
    </message>
    <message>
        <source>Append the label of the torrent to the save path</source>
        <translation>Kayıt yoluna toren etiketini de ekle</translation>
    </message>
    <message>
        <source>Pre-allocate disk space for all files</source>
        <translation>Tüm dosyalar için disk alanı tahsisi yap</translation>
    </message>
    <message>
        <source>Keep incomplete torrents in:</source>
        <translation>Tamamlanmamış torentlerin tutulacağı yer:</translation>
    </message>
    <message>
        <source>Append .!qB extension to incomplete files&apos; names</source>
        <translation type="obsolete">Tamamlanmamış dosya adlarına .!qB eklentisini ekle</translation>
    </message>
    <message>
        <source>Automatically add torrents from:</source>
        <translation>Torentlerin kendiliğinden ekleneceği yer:</translation>
    </message>
    <message>
        <source>Add folder...</source>
        <translation>Klasör ekle...</translation>
    </message>
    <message>
        <source>IP Filtering</source>
        <translation>IP Süzgeci</translation>
    </message>
    <message>
        <source>Schedule the use of alternative speed limits</source>
        <translation type="obsolete">Akıllı hız sınırlarının kullanım zamanı</translation>
    </message>
    <message>
        <source>from</source>
        <extracomment>from (time1 to time2)</extracomment>
        <translation>Başlangıç</translation>
    </message>
    <message>
        <source>When:</source>
        <translation>Zaman:</translation>
    </message>
    <message>
        <source>Look for peers on your local network</source>
        <translation>Yerel ağda eş ara</translation>
    </message>
    <message>
        <source>Protocol encryption:</source>
        <translation type="obsolete">İletişim kuralı şifreleme:</translation>
    </message>
    <message>
        <source>Enable Web User Interface (Remote control)</source>
        <translation>Web Kullanıcı Arayüzünü Etkinleştir (Uzaktan Kontrol)</translation>
    </message>
    <message>
        <source>Share ratio limiting</source>
        <translation type="obsolete">Paylaşım oranı sınırlama</translation>
    </message>
    <message>
        <source>Seed torrents until their ratio reaches</source>
        <translation>Torentleri paylaşım oranlarına ulaşıncaya kadar gönder</translation>
    </message>
    <message>
        <source>then</source>
        <translation>sonra</translation>
    </message>
    <message>
        <source>Pause them</source>
        <translation>Duraklat</translation>
    </message>
    <message>
        <source>Remove them</source>
        <translation>Kaldır</translation>
    </message>
    <message utf8="true">
        <source>Exchange peers with compatible Bittorrent clients (µTorrent, Vuze, ...)</source>
        <translation>Eşleri uyumlu Bittorrent istemcileri ile değiştir (µTorrent, Vuze, ...)</translation>
    </message>
    <message>
        <source>Email notification upon download completion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Destination email:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SMTP server:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Run an external program on torrent completion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>BitTorrent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Start / Stop Torrent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use UPnP / NAT-PMP port forwarding from my router</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Privacy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable DHT (decentralized network) to find more peers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use a different port for DHT and BitTorrent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable Peer Exchange (PeX) to find more peers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable Local Peer Discovery to find more peers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Encryption mode:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Prefer encryption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Require encryption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Disable encryption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reload the filter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Behavior</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Language</source>
        <translation type="unfinished">Dil</translation>
    </message>
    <message>
        <source>Power Management</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inhibit system sleep when torrents are active</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bypass authentication for localhost</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ask for program exit confirmation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The following parameters are supported:
&lt;ul&gt;
&lt;li&gt;%f: Torrent path&lt;/li&gt;
&lt;li&gt;%n: Torrent name&lt;/li&gt;
&lt;/ul&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tray icon style:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Normal</source>
        <translation type="unfinished">Normal</translation>
    </message>
    <message>
        <source>Monochrome (Dark theme)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Monochrome (Light theme)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This server requires a secure connection (SSL)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User Interface Language:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Transfer List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show qBittorrent in notification area</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hard Disk</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Listening Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Connections Limits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Proxy Server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Torrent Queueing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Share Ratio Limiting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use UPnP / NAT-PMP to forward the port from my router</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Update my dynamic domain name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Service:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Register</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Domain name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Global Rate Limits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Apply rate limit to uTP connections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Apply rate limit to transport overhead</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alternative Global Rate Limits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Schedule the use of alternative rate limits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable bandwidth management (uTP)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Otherwise, the proxy server is only used for tracker connections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use proxy for peer connections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Append .!qB extension to incomplete files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use HTTPS instead of HTTP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Import SSL Certificate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Import SSL Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Certificate:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Key:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;a href=http://httpd.apache.org/docs/2.1/ssl/ssl_faq.html#aboutcerts&gt;Information about certificates&lt;/a&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PreviewSelect</name>
    <message>
        <source>Name</source>
        <translation type="unfinished">Ad</translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="unfinished">Boyut</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation type="unfinished">İlerleme</translation>
    </message>
    <message>
        <source>Preview impossible</source>
        <translation type="unfinished">Önizleme yapılamıyor</translation>
    </message>
    <message>
        <source>Sorry, we can&apos;t preview this file</source>
        <translation type="unfinished">Üzgünüz, bu dosyanın önizlemesi yapılamıyor</translation>
    </message>
</context>
<context>
    <name>PropListDelegate</name>
    <message>
        <source>Normal</source>
        <comment>Normal (priority)</comment>
        <translatorcomment>Normal (öncelik)</translatorcomment>
        <translation>Normal</translation>
    </message>
    <message>
        <source>High</source>
        <comment>High (priority)</comment>
        <translatorcomment>Yüksek (öncelik)</translatorcomment>
        <translation>Yüksek</translation>
    </message>
    <message>
        <source>Maximum</source>
        <comment>Maximum (priority)</comment>
        <translatorcomment>En yüksek (öncelik)</translatorcomment>
        <translation>En yüksek</translation>
    </message>
    <message>
        <source>Not downloaded</source>
        <translation>İndirilmedi</translation>
    </message>
    <message>
        <source>Mixed</source>
        <comment>Mixed (priorities</comment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PropTabBar</name>
    <message>
        <source>General</source>
        <translation type="unfinished">Genel</translation>
    </message>
    <message>
        <source>Trackers</source>
        <translation type="unfinished">İzleyiciler</translation>
    </message>
    <message>
        <source>Peers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Files</source>
        <translation type="obsolete">Dosyalar</translation>
    </message>
    <message>
        <source>HTTP Sources</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Content</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PropertiesWidget</name>
    <message>
        <source>Save path:</source>
        <translation>Kayıt Yolu:</translation>
    </message>
    <message>
        <source>Torrent hash:</source>
        <translation>Torrent adresleme:</translation>
    </message>
    <message>
        <source>Comment:</source>
        <translation>Yorum:</translation>
    </message>
    <message>
        <source>Share ratio:</source>
        <translation>Paylaşım oranı:</translation>
    </message>
    <message>
        <source>General</source>
        <translation type="obsolete">Genel</translation>
    </message>
    <message>
        <source>Trackers</source>
        <translation type="obsolete">İzleyiciler</translation>
    </message>
    <message>
        <source>URL seeds</source>
        <translation type="obsolete">URL eşler</translation>
    </message>
    <message>
        <source>Files</source>
        <translation type="obsolete">Dosyalar</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Öncelik</translation>
    </message>
    <message>
        <source>New url seed</source>
        <comment>New HTTP source</comment>
        <translation>Yeni gönderen adresi</translation>
    </message>
    <message>
        <source>New url seed:</source>
        <translation>Yeni gönderen adresi:</translation>
    </message>
    <message>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <source>This url seed is already in the list.</source>
        <translation>Bu gönderen adresi zaten listede.</translation>
    </message>
    <message>
        <source>Choose save path</source>
        <translation>Kayıt yolunu seçin</translation>
    </message>
    <message>
        <source>Save path creation error</source>
        <translation type="obsolete">Kayıt yolu oluşturulmada hata</translation>
    </message>
    <message>
        <source>Could not create the save path</source>
        <translation type="obsolete">Kayıt yolu oluşturulamadı</translation>
    </message>
    <message>
        <source>Downloaded:</source>
        <translation>İndirilen:</translation>
    </message>
    <message>
        <source>Transfer</source>
        <translation>Aktarım</translation>
    </message>
    <message>
        <source>Uploaded:</source>
        <translation>Gönderilen:</translation>
    </message>
    <message>
        <source>Wasted:</source>
        <translation>Boşa giden:</translation>
    </message>
    <message>
        <source>UP limit:</source>
        <translation>Gönderme Sınırı:</translation>
    </message>
    <message>
        <source>DL limit:</source>
        <translation>İndirme Sınırı:</translation>
    </message>
    <message>
        <source>Time elapsed:</source>
        <translation type="obsolete">Geçen zaman:</translation>
    </message>
    <message>
        <source>Connections:</source>
        <translation>Bağlantı:</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Bilgi</translation>
    </message>
    <message>
        <source>Created on:</source>
        <translation>Oluşturma:</translation>
    </message>
    <message>
        <source>Peers</source>
        <translation type="obsolete">Eşler</translation>
    </message>
    <message>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <source>Maximum</source>
        <translation>En Yüksek</translation>
    </message>
    <message>
        <source>High</source>
        <translation>Yüksek</translation>
    </message>
    <message>
        <source>this session</source>
        <translation>bu oturum</translation>
    </message>
    <message>
        <source>%1 max</source>
        <comment>e.g. 10 max</comment>
        <translation>azami: %1</translation>
    </message>
    <message>
        <source>Availability:</source>
        <translation>Kullanılırlık:</translation>
    </message>
    <message>
        <source>/s</source>
        <comment>/second (i.e. per second)</comment>
        <translation>/s</translation>
    </message>
    <message>
        <source>Seeded for %1</source>
        <comment>e.g. Seeded for 3m10s</comment>
        <translation>Gönderme zamanı:  %1</translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation>Yeniden adlandır...</translation>
    </message>
    <message>
        <source>New name:</source>
        <translation>Yeni ad:</translation>
    </message>
    <message>
        <source>The file could not be renamed</source>
        <translation>Dosya yeniden adlandırılamadı</translation>
    </message>
    <message>
        <source>This name is already in use in this folder. Please use a different name.</source>
        <translation>Bu ad başka bir öğe tarafından kullanılıyor, Lütfen başka bir ad seçin.</translation>
    </message>
    <message>
        <source>The folder could not be renamed</source>
        <translation>Dosya yeniden adlandırılamadı</translation>
    </message>
    <message>
        <source>Rename the file</source>
        <translation>Dosyayı yeniden adlandır</translation>
    </message>
    <message>
        <source>This file name contains forbidden characters, please choose a different one.</source>
        <translation>Bu dosya adı yasak karakterler içeriyor, lütfen başka bir ad seçin.</translation>
    </message>
    <message>
        <source>I/O Error</source>
        <translation>Girdi/Çıktı Hatası</translation>
    </message>
    <message>
        <source>This file does not exist yet.</source>
        <translation>Bu dosya henüz mevcut değil.</translation>
    </message>
    <message>
        <source>This folder does not exist yet.</source>
        <translation>Bu klasör henüz mevcut değil.</translation>
    </message>
    <message>
        <source>Reannounce in:</source>
        <translation>Yeniden duyuru yeri:</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Tümünü Seç</translation>
    </message>
    <message>
        <source>Select None</source>
        <translation>Hiçbirini Seçme</translation>
    </message>
    <message>
        <source>Do not download</source>
        <translation>İndirme</translation>
    </message>
    <message>
        <source>Pieces size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Time active:</source>
        <extracomment>Time (duration) the torrent is active (not paused)</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Torrent content:</source>
        <translation type="unfinished">Torrent içeriği:</translation>
    </message>
</context>
<context>
    <name>QBtSession</name>
    <message>
        <source>%1 reached the maximum ratio you set.</source>
        <translation type="unfinished">%1, ayarladığınız azami orana ulaştı.</translation>
    </message>
    <message>
        <source>Removing torrent %1...</source>
        <translation type="unfinished">Torent kaldırılıyor: %1...</translation>
    </message>
    <message>
        <source>Pausing torrent %1...</source>
        <translation type="unfinished">Torent duraklatılıyor: %1...</translation>
    </message>
    <message>
        <source>qBittorrent is bound to port: TCP/%1</source>
        <comment>e.g: qBittorrent is bound to port: 6881</comment>
        <translation type="unfinished">qBittorrent&apos;in bağlı olduğu port: TCP/%1</translation>
    </message>
    <message>
        <source>UPnP support [ON]</source>
        <translation type="obsolete">UPnP desteği [ON]</translation>
    </message>
    <message>
        <source>UPnP support [OFF]</source>
        <translation type="obsolete">UPnP desteği [OFF]</translation>
    </message>
    <message>
        <source>NAT-PMP support [ON]</source>
        <translation type="obsolete">NAT-PMP desteği [ON]</translation>
    </message>
    <message>
        <source>NAT-PMP support [OFF]</source>
        <translation type="obsolete">NAT-PMP desteği [OFF]</translation>
    </message>
    <message>
        <source>HTTP user agent is %1</source>
        <translation type="unfinished">HTTP istemcisi: %1</translation>
    </message>
    <message>
        <source>Using a disk cache size of %1 MiB</source>
        <translation type="obsolete">%1 MB&apos;lık disk önbelleği kullanılıyor</translation>
    </message>
    <message>
        <source>DHT support [ON], port: UDP/%1</source>
        <translation type="unfinished">DHT desteği [ON], port: UDP/%1</translation>
    </message>
    <message>
        <source>DHT support [OFF]</source>
        <translation type="unfinished">DHT desteği [OFF]</translation>
    </message>
    <message>
        <source>PeX support [ON]</source>
        <translation type="unfinished">EşD desteği [ON]</translation>
    </message>
    <message>
        <source>PeX support [OFF]</source>
        <translation type="unfinished">PeX desteği [KAPALI]</translation>
    </message>
    <message>
        <source>Restart is required to toggle PeX support</source>
        <translation type="unfinished">PeX desteğini açmak/kapatmak için yeniden başlatmak gerekir</translation>
    </message>
    <message>
        <source>Local Peer Discovery [ON]</source>
        <translation type="obsolete">Yerel Eş Keşfi [ON]</translation>
    </message>
    <message>
        <source>Local Peer Discovery support [OFF]</source>
        <translation type="unfinished">Yerel Eş Keşfi desteği [OFF]</translation>
    </message>
    <message>
        <source>Encryption support [ON]</source>
        <translation type="unfinished">Şifreleme desteği [ON]</translation>
    </message>
    <message>
        <source>Encryption support [FORCED]</source>
        <translation type="unfinished">Şifreleme desteği [FORCED]</translation>
    </message>
    <message>
        <source>Encryption support [OFF]</source>
        <translation type="unfinished">Şifreleme desteği [OFF]</translation>
    </message>
    <message>
        <source>Embedded Tracker [ON]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to start the embedded tracker!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Embedded Tracker [OFF]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The Web UI is listening on port %1</source>
        <translation type="unfinished">Ağ arayüzünün kullandığı port: %1</translation>
    </message>
    <message>
        <source>Web User Interface Error - Unable to bind Web UI to port %1</source>
        <translation type="unfinished">Web Kullanıcı Arayüzü Hatası - Web arayüzü bağlanamadı, port %1</translation>
    </message>
    <message>
        <source>&apos;%1&apos; was removed from transfer list and hard disk.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation type="unfinished">&apos;%1&apos;, aktarım listesinden ve sabit diskten kaldırıldı.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; was removed from transfer list.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation type="unfinished">&apos;%1&apos;, aktarım listesinden kaldırıldı.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is not a valid magnet URI.</source>
        <translation type="unfinished">&apos;%1&apos; geçerli bir adres değil.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is already in download list.</source>
        <comment>e.g: &apos;xxx.avi&apos; is already in download list.</comment>
        <translation type="unfinished">&apos;%1&apos;, zaten indirme listesinde.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; resumed. (fast resume)</source>
        <comment>&apos;/home/y/xxx.torrent&apos; was resumed. (fast resume)</comment>
        <translation type="unfinished">&apos;%1&apos;, devam edildi. (hızlı devam)</translation>
    </message>
    <message>
        <source>&apos;%1&apos; added to download list.</source>
        <comment>&apos;/home/y/xxx.torrent&apos; was added to download list.</comment>
        <translation type="unfinished">&apos;%1&apos;, indirme listesine eklendi.</translation>
    </message>
    <message>
        <source>Unable to decode torrent file: &apos;%1&apos;</source>
        <comment>e.g: Unable to decode torrent file: &apos;/home/y/xxx.torrent&apos;</comment>
        <translation type="unfinished">Torrent dosyası çözümlenemiyor: &apos;%1&apos;</translation>
    </message>
    <message>
        <source>This file is either corrupted or this isn&apos;t a torrent.</source>
        <translation type="unfinished">Bu dosya bozuk ya da torrent dosyası değil.</translation>
    </message>
    <message>
        <source>Error: The torrent %1 does not contain any file.</source>
        <translation type="unfinished">Hata: %1 torenti herhangi bir dosya içermiyor.</translation>
    </message>
    <message>
        <source>Note: new trackers were added to the existing torrent.</source>
        <translation type="unfinished">Not: yeni izleyiciler varolan torente eklendi.</translation>
    </message>
    <message>
        <source>Note: new URL seeds were added to the existing torrent.</source>
        <translation type="unfinished">Not: yeni URL eşleri varolan torente eklendi.</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;was blocked due to your IP filter&lt;/i&gt;</source>
        <comment>x.y.z.w was blocked</comment>
        <translation type="unfinished">&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt;, &lt;i&gt;IP süzgeciniz tarafından engellendi&lt;/i&gt;</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;was banned due to corrupt pieces&lt;/i&gt;</source>
        <comment>x.y.z.w was banned</comment>
        <translation type="unfinished">&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt;, &lt;i&gt;bozuk parçalar sebebiyle engellendi&lt;/i&gt;</translation>
    </message>
    <message>
        <source>Recursive download of file %1 embedded in torrent %2</source>
        <comment>Recursive download of test.torrent embedded in torrent test2</comment>
        <translation type="unfinished">%1 dosyasının özyineli indirmesi %2 torenti içine gömülü</translation>
    </message>
    <message>
        <source>Unable to decode %1 torrent file.</source>
        <translation type="unfinished">%1 torent dosyası çözümlenemiyor.</translation>
    </message>
    <message>
        <source>Torrent name: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Torrent size: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save path: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The torrent was downloaded in %1.</source>
        <comment>The torrent was downloaded in 1 hour and 20 seconds</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Thank you for using qBittorrent.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[qBittorrent] %1 has finished downloading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>An I/O error occured, &apos;%1&apos; paused.</source>
        <translation type="unfinished">Bir G/Ç hatası meydana geldi, &apos;%1&apos; duraklatıldı.</translation>
    </message>
    <message>
        <source>Reason: %1</source>
        <translation type="unfinished">Sebep: %1</translation>
    </message>
    <message>
        <source>UPnP/NAT-PMP: Port mapping failure, message: %1</source>
        <translation type="unfinished">UPnP/NAT-PMP: Port adresleme hatası, ileti: %1</translation>
    </message>
    <message>
        <source>UPnP/NAT-PMP: Port mapping successful, message: %1</source>
        <translation type="unfinished">UPnP/NAT-PMP: Port adresleme başarılı, ileti: %1</translation>
    </message>
    <message>
        <source>File sizes mismatch for torrent %1, pausing it.</source>
        <translation type="unfinished">%1 torentinin dosya boyutu eşleşmiyor, duraklatılıyor.</translation>
    </message>
    <message>
        <source>Fast resume data was rejected for torrent %1, checking again...</source>
        <translation type="unfinished">Hızlı devam verisi %1 torrenti için reddedildi, yeniden denetleniyor...</translation>
    </message>
    <message>
        <source>Url seed lookup failed for url: %1, message: %2</source>
        <translation type="unfinished">Url gönderme araştırması başarısız: %1, ileti: %2</translation>
    </message>
    <message>
        <source>Downloading &apos;%1&apos;, please wait...</source>
        <comment>e.g: Downloading &apos;xxx.torrent&apos;, please wait...</comment>
        <translation type="unfinished">&apos;%1&apos;, indiriliyor, lütfen bekleyin...</translation>
    </message>
    <message>
        <source>The network interface defined is invalid: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Trying any other network interface available instead.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Listening on IP address %1 on network interface %2...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to listen on network interface %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>UPnP / NAT-PMP support [ON]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>UPnP / NAT-PMP support [OFF]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Local Peer Discovery support [ON]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Successfuly parsed the provided IP filter: %1 rules were applied.</source>
        <comment>%1 is a number</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error: Failed to parse the provided IP filter.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reporting IP address %1 to trackers...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The computer will now go to sleep mode unless you cancel within the next 15 seconds...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The computer will now be switched off unless you cancel within the next 15 seconds...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>qBittorrent will now exit unless you cancel within the next 15 seconds...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RSS</name>
    <message>
        <source>Search</source>
        <translation>Arama</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Sil</translation>
    </message>
    <message>
        <source>Rename</source>
        <translation>Yeniden adlandır</translation>
    </message>
    <message>
        <source>Refresh RSS streams</source>
        <translation>RSS akımlarını yenile</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Torrents:&lt;/span&gt; &lt;span style=&quot; font-style:italic;&quot;&gt;(double-click to download)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Torentler:&lt;/span&gt; &lt;span style=&quot; font-style:italic;&quot;&gt;(indirmek için çift tıklayın)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Download torrent</source>
        <translation>Torenti indir</translation>
    </message>
    <message>
        <source>Open news URL</source>
        <translation>Haber adresini aç</translation>
    </message>
    <message>
        <source>Copy feed URL</source>
        <translation>Besleme adresini kopyala</translation>
    </message>
    <message>
        <source>New subscription</source>
        <translation>Yeni abonelik</translation>
    </message>
    <message>
        <source>Mark items read</source>
        <translation>Öğeleri okundu olarak işaretle</translation>
    </message>
    <message>
        <source>Update all</source>
        <translation>Tümünü güncelle</translation>
    </message>
    <message>
        <source>Update all feeds</source>
        <translation>Tüm beslemeleri güncelle</translation>
    </message>
    <message>
        <source>RSS feeds</source>
        <translation type="obsolete">RSS beslemeleri</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Güncelle</translation>
    </message>
    <message>
        <source>Feed URL</source>
        <translation type="obsolete">Besleme adresi</translation>
    </message>
    <message>
        <source>Article title</source>
        <translation type="obsolete">Yazı başlığı</translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation>Yeniden adlandır...</translation>
    </message>
    <message>
        <source>New subscription...</source>
        <translation>Yeni abonelik...</translation>
    </message>
    <message>
        <source>RSS feed downloader...</source>
        <translation type="obsolete">RSS Beslemesi indirici...</translation>
    </message>
    <message>
        <source>New folder...</source>
        <translation>Yeni klasör...</translation>
    </message>
    <message>
        <source>Manage cookies...</source>
        <translation>Çerezleri yönet...</translation>
    </message>
    <message>
        <source>Settings...</source>
        <translation>Ayarlar...</translation>
    </message>
    <message>
        <source>RSS Downloader...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RSSImp</name>
    <message>
        <source>Please type a rss stream url</source>
        <translation>Lütfen bir rss akımı adresi yazın</translation>
    </message>
    <message>
        <source>Stream URL:</source>
        <translation>Akım adresi:</translation>
    </message>
    <message>
        <source>Are you sure? -- qBittorrent</source>
        <translation>Emin misiniz? -- qBittorrent</translation>
    </message>
    <message>
        <source>&amp;Yes</source>
        <translation>&amp;Evet</translation>
    </message>
    <message>
        <source>&amp;No</source>
        <translation>&amp;Hayır</translation>
    </message>
    <message>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <source>This rss feed is already in the list.</source>
        <translation>Bu rss beslemesi zaten listede var.</translation>
    </message>
    <message>
        <source>Date: </source>
        <translation>Tarih: </translation>
    </message>
    <message>
        <source>Author: </source>
        <translation>Yazar: </translation>
    </message>
    <message>
        <source>Please choose a folder name</source>
        <translation>Lütfen bir klasör adı seçin</translation>
    </message>
    <message>
        <source>Folder name:</source>
        <translation>Klasör adı:</translation>
    </message>
    <message>
        <source>New folder</source>
        <translation>Yeni klasör</translation>
    </message>
    <message>
        <source>Are you sure you want to delete these elements from the list?</source>
        <translation>Bu öğeleri listeden silmek istediğinize emin misiniz?</translation>
    </message>
    <message>
        <source>Are you sure you want to delete this element from the list?</source>
        <translation>Bu öğeyi listeden silmek istediğinize emin misiniz?</translation>
    </message>
    <message>
        <source>Please choose a new name for this RSS feed</source>
        <translation>Lütfen bu RSS beslemesi için yeni bir ad seçin</translation>
    </message>
    <message>
        <source>New feed name:</source>
        <translation>Yeni besleme adı:</translation>
    </message>
    <message>
        <source>Name already in use</source>
        <translation>Bu ad kullanımda</translation>
    </message>
    <message>
        <source>This name is already used by another item, please choose another one.</source>
        <translation>Bu ad başka bir öğe tarafından kullanılıyor, lütfen başka bir tane seçin.</translation>
    </message>
    <message>
        <source>Overwrite attempt</source>
        <translation>Üzerine yazma girişimi</translation>
    </message>
    <message>
        <source>You cannot overwrite %1 item.</source>
        <comment>You cannot overwrite myFolder item.</comment>
        <translation>%1 öğesi üzerine yazamazsınız.</translation>
    </message>
    <message>
        <source>Unread</source>
        <translation>Okunmadı</translation>
    </message>
</context>
<context>
    <name>RssArticle</name>
    <message>
        <source>No description available</source>
        <translation type="obsolete">Kullanılır betimleme yok</translation>
    </message>
</context>
<context>
    <name>RssFeed</name>
    <message>
        <source>Automatically downloading %1 torrent from %2 RSS feed...</source>
        <translation type="unfinished">%2 beslemesinden %1 torent kendiliğinden indiriliyor...</translation>
    </message>
</context>
<context>
    <name>RssItem</name>
    <message>
        <source>No description available</source>
        <translation type="obsolete">Kullanılır betimleme yok</translation>
    </message>
</context>
<context>
    <name>RssSettings</name>
    <message>
        <source>RSS Reader Settings</source>
        <translation type="obsolete">RSS Okuyucu Ayarları</translation>
    </message>
    <message>
        <source>RSS feeds refresh interval:</source>
        <translation type="obsolete">RSS beslemeleri yenileme süresi:</translation>
    </message>
    <message>
        <source>minutes</source>
        <translation type="obsolete">dakika</translation>
    </message>
    <message>
        <source>Maximum number of articles per feed:</source>
        <translation type="obsolete">Besleme başına azami makale sayısı:</translation>
    </message>
</context>
<context>
    <name>RssSettingsDlg</name>
    <message>
        <source>RSS Reader Settings</source>
        <translation type="unfinished">RSS Okuyucu Ayarları</translation>
    </message>
    <message>
        <source>RSS feeds refresh interval:</source>
        <translation type="unfinished">RSS beslemeleri yenileme süresi:</translation>
    </message>
    <message>
        <source>minutes</source>
        <translation type="unfinished">dakika</translation>
    </message>
    <message>
        <source>Maximum number of articles per feed:</source>
        <translation type="unfinished">Besleme başına azami makale sayısı:</translation>
    </message>
</context>
<context>
    <name>RssStream</name>
    <message>
        <source>Automatically downloading %1 torrent from %2 RSS feed...</source>
        <translation type="obsolete">%2 beslemesinden %1 torent kendiliğinden indiriliyor...</translation>
    </message>
</context>
<context>
    <name>ScanFoldersModel</name>
    <message>
        <source>Watched Folder</source>
        <translation>İzlenen Klasör</translation>
    </message>
    <message>
        <source>Download here</source>
        <translation>Buraya indir</translation>
    </message>
</context>
<context>
    <name>SearchCategories</name>
    <message>
        <source>All categories</source>
        <translation>Tüm kategoriler</translation>
    </message>
    <message>
        <source>Movies</source>
        <translation>Filmler</translation>
    </message>
    <message>
        <source>TV shows</source>
        <translation>Televizyon programları</translation>
    </message>
    <message>
        <source>Music</source>
        <translation>Müzik</translation>
    </message>
    <message>
        <source>Games</source>
        <translation>Oyunlar</translation>
    </message>
    <message>
        <source>Anime</source>
        <translation>Canlandırma</translation>
    </message>
    <message>
        <source>Software</source>
        <translation>Yazılım</translation>
    </message>
    <message>
        <source>Pictures</source>
        <translation>Fotoğraflar</translation>
    </message>
    <message>
        <source>Books</source>
        <translation>Kitaplar</translation>
    </message>
</context>
<context>
    <name>SearchEngine</name>
    <message>
        <source>Empty search pattern</source>
        <translation>Boş arama örüntüsü</translation>
    </message>
    <message>
        <source>Please type a search pattern first</source>
        <translation>Lütfen önce bir arama örüntüsü girin</translation>
    </message>
    <message>
        <source>Results</source>
        <translation>Sonuçlar</translation>
    </message>
    <message>
        <source>Searching...</source>
        <translation>Aranıyor...</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation>Kes</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Kopyala</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation>Yapıştır</translation>
    </message>
    <message>
        <source>Clear field</source>
        <translation>Temizle</translation>
    </message>
    <message>
        <source>Clear completion history</source>
        <translation>Tamamlanma geçmişini temizle</translation>
    </message>
    <message>
        <source>Search Engine</source>
        <translation>Arama Motoru</translation>
    </message>
    <message>
        <source>Search has finished</source>
        <translation>Arama bitti</translation>
    </message>
    <message>
        <source>An error occured during search...</source>
        <translation>Arama yapılırken bir hata oluştu...</translation>
    </message>
    <message>
        <source>Search aborted</source>
        <translation>Arama iptal edildi</translation>
    </message>
    <message>
        <source>Search returned no results</source>
        <translation>Arama sonuç bulamadı</translation>
    </message>
    <message>
        <source>Results</source>
        <comment>i.e: Search results</comment>
        <translation>Sonuçlar</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Bilinmeyen</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Ara</translation>
    </message>
    <message>
        <source>Download error</source>
        <translation>İndirme hatası</translation>
    </message>
    <message>
        <source>Python setup could not be downloaded, reason: %1.
Please install it manually.</source>
        <translation>Python kurulumu indirilemedi, sebep: %1.
Lütfen elle yükleyiniz.</translation>
    </message>
    <message>
        <source>Missing Python Interpreter</source>
        <translation>Python Yorumlayıcısı Eksik</translation>
    </message>
    <message>
        <source>Python 2.x is required to use the search engine but it does not seem to be installed.
Do you want to install it now?</source>
        <translation>Python 2.x&apos;nin arama motoruna ihtiyacı var ancak yüklenmemiş görünüyor.
Şimdi yüklemek ister misiniz?</translation>
    </message>
    <message>
        <source>Confirmation</source>
        <translation>Doğrulama</translation>
    </message>
    <message>
        <source>Are you sure you want to clear the history?</source>
        <translation>Geçmişi temizlemek istediğinize emin misiniz?</translation>
    </message>
</context>
<context>
    <name>SearchTab</name>
    <message>
        <source>Name</source>
        <comment>i.e: file name</comment>
        <translation>Ad</translation>
    </message>
    <message>
        <source>Size</source>
        <comment>i.e: file size</comment>
        <translation>Boyut</translation>
    </message>
    <message>
        <source>Seeders</source>
        <comment>i.e: Number of full sources</comment>
        <translation>Gönderen</translation>
    </message>
    <message>
        <source>Leechers</source>
        <comment>i.e: Number of partial sources</comment>
        <translation>Çeken</translation>
    </message>
    <message>
        <source>Search engine</source>
        <translation>Arama motoru</translation>
    </message>
</context>
<context>
    <name>ShutdownConfirmDlg</name>
    <message>
        <source>Shutdown confirmation</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SpeedLimitDialog</name>
    <message>
        <source>KiB/s</source>
        <translation>KB/s</translation>
    </message>
</context>
<context>
    <name>StatusBar</name>
    <message>
        <source>Connection status:</source>
        <translation>Bağlantı durumu:</translation>
    </message>
    <message>
        <source>No direct connections. This may indicate network configuration problems.</source>
        <translation>Doğrudan bağlantı yok. Bu, ağ yapılandırma problemi olduğunu gösteriyor.</translation>
    </message>
    <message>
        <source>DHT: %1 nodes</source>
        <translation>DHT: %1 düğüm</translation>
    </message>
    <message>
        <source>Connection Status:</source>
        <translation>Bağlantı Durumu:</translation>
    </message>
    <message>
        <source>Online</source>
        <translation>Çevrimiçi</translation>
    </message>
    <message>
        <source>Global Download Speed Limit</source>
        <translation>Genel İndirme Hızı Sınırı</translation>
    </message>
    <message>
        <source>Global Upload Speed Limit</source>
        <translation>Genel Gönderme Hızı Sınırı</translation>
    </message>
    <message>
        <source>D: %1/s - T: %2</source>
        <comment>Download speed: x KiB/s - Transferred: x MiB</comment>
        <translation type="obsolete">İND: %1/s - Top: %2</translation>
    </message>
    <message>
        <source>U: %1/s - T: %2</source>
        <comment>Upload speed: x KiB/s - Transferred: x MiB</comment>
        <translation type="obsolete">GÖN: %1/s - Top: %2</translation>
    </message>
    <message>
        <source>D: %1 B/s - T: %2</source>
        <comment>Download speed: x B/s - Transferred: x MiB</comment>
        <translation type="obsolete">İND: %1 B/s - Top: %2</translation>
    </message>
    <message>
        <source>U: %1 B/s - T: %2</source>
        <comment>Upload speed: x B/s - Transferred: x MiB</comment>
        <translation type="obsolete">GÖN: %1 B/s - Top: %2</translation>
    </message>
    <message>
        <source>Offline. This usually means that qBittorrent failed to listen on the selected port for incoming connections.</source>
        <translation>Çevrimdışı. Bu genellikle qBittorrent&apos;in gelen bağlantılar için seçilmiş porta bağlanamadığı anlamındadır.</translation>
    </message>
    <message>
        <source>Click to disable alternative speed limits</source>
        <translation type="obsolete">Akıllı hız sınırlarını etkisizleştirmek için tıklayın</translation>
    </message>
    <message>
        <source>Click to enable alternative speed limits</source>
        <translation type="obsolete">Akıllı hız sınırlarını etkinleştirmek için tıklayın</translation>
    </message>
    <message>
        <source>qBittorrent needs to be restarted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>qBittorrent was just updated and needs to be restarted for the changes to be effective.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click to switch to alternative speed limits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click to switch to regular speed limits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1/s</source>
        <comment>Per second</comment>
        <translation type="unfinished">%1/s</translation>
    </message>
</context>
<context>
    <name>TorrentCreatorDlg</name>
    <message>
        <source>Select a folder to add to the torrent</source>
        <translation type="unfinished">Torrente eklemek için bir klasör seçin</translation>
    </message>
    <message>
        <source>Select a file to add to the torrent</source>
        <translation type="unfinished">Torrente eklemek için bir dosya seçin</translation>
    </message>
    <message>
        <source>Please type an announce URL</source>
        <translation type="obsolete">Lütfen bir duyuru adresi yazın</translation>
    </message>
    <message>
        <source>Announce URL:</source>
        <comment>Tracker URL</comment>
        <translation type="obsolete">Duyuru adresi:</translation>
    </message>
    <message>
        <source>Please type a web seed url</source>
        <translation type="obsolete">Lütfen bir ağ göndereni adresi yazın</translation>
    </message>
    <message>
        <source>Web seed URL:</source>
        <translation type="obsolete">Ağ göndereni adresi:</translation>
    </message>
    <message>
        <source>No input path set</source>
        <translation type="unfinished">Ayarlanmış girdi yolu yok</translation>
    </message>
    <message>
        <source>Please type an input path first</source>
        <translation type="unfinished">Lütfen önce bir girdi yolu yazın</translation>
    </message>
    <message>
        <source>Select destination torrent file</source>
        <translation type="unfinished">Hedef Torrent dosyasını seç</translation>
    </message>
    <message>
        <source>Torrent Files</source>
        <translation type="unfinished">Torrent Dosyaları</translation>
    </message>
    <message>
        <source>Torrent creation</source>
        <translation type="unfinished">Torrent oluşturma</translation>
    </message>
    <message>
        <source>Torrent creation was unsuccessful, reason: %1</source>
        <translation type="unfinished">Torrent oluşturma başarısızlıkla sonuçlandı, neden: %1</translation>
    </message>
    <message>
        <source>Created torrent file is invalid. It won&apos;t be added to download list.</source>
        <translation type="unfinished">Oluşturulmuş torrent dosyası geçersiz. İndirme listesine eklenmeyecek.</translation>
    </message>
    <message>
        <source>Torrent was created successfully:</source>
        <translation type="unfinished">Torrent başarıyla oluşturuldu:</translation>
    </message>
</context>
<context>
    <name>TorrentFilesModel</name>
    <message>
        <source>Name</source>
        <translation>Ad</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Boyut</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation>İlerleme</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Öncelik</translation>
    </message>
</context>
<context>
    <name>TorrentImportDlg</name>
    <message>
        <source>Torrent Import</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This assistant will help you share with qBittorrent a torrent that you have already downloaded.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Torrent file to import:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>...</source>
        <translation type="unfinished">...</translation>
    </message>
    <message>
        <source>Content location:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Skip the data checking stage and start seeding immediately</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Import</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Torrent file to import</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Torrent files (*.torrent)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 Files</source>
        <comment>%1 is a file extension (e.g. PDF)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please provide the location of %1</source>
        <comment>%1 is a file name</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please point to the location of the torrent: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid torrent file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This is not a valid torrent file.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TorrentModel</name>
    <message>
        <source>Name</source>
        <comment>i.e: torrent name</comment>
        <translation type="unfinished">Ad</translation>
    </message>
    <message>
        <source>Size</source>
        <comment>i.e: torrent size</comment>
        <translation type="unfinished">Boyut</translation>
    </message>
    <message>
        <source>Done</source>
        <comment>% Done</comment>
        <translation type="unfinished">Bitti</translation>
    </message>
    <message>
        <source>Status</source>
        <comment>Torrent status (e.g. downloading, seeding, paused)</comment>
        <translation type="unfinished">Durum</translation>
    </message>
    <message>
        <source>Seeds</source>
        <comment>i.e. full sources (often untranslated)</comment>
        <translation type="unfinished">Gönderenler</translation>
    </message>
    <message>
        <source>Peers</source>
        <comment>i.e. partial sources (often untranslated)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation type="unfinished">İndirme Hızı</translation>
    </message>
    <message>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation type="unfinished">Gönderme Hızı</translation>
    </message>
    <message>
        <source>Ratio</source>
        <comment>Share ratio</comment>
        <translation type="unfinished">Oran</translation>
    </message>
    <message>
        <source>ETA</source>
        <comment>i.e: Estimated Time of Arrival / Time left</comment>
        <translation type="unfinished">Kalan Zaman</translation>
    </message>
    <message>
        <source>Label</source>
        <translation type="unfinished">Etiket</translation>
    </message>
    <message>
        <source>Added On</source>
        <comment>Torrent was added to transfer list on 01/01/2010 08:00</comment>
        <translation type="unfinished">Eklendi</translation>
    </message>
    <message>
        <source>Completed On</source>
        <comment>Torrent was completed on 01/01/2010 08:00</comment>
        <translation type="unfinished">Tamamlandı</translation>
    </message>
    <message>
        <source>Tracker</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Down Limit</source>
        <comment>i.e: Download limit</comment>
        <translation type="unfinished">İnd. Sınırı</translation>
    </message>
    <message>
        <source>Up Limit</source>
        <comment>i.e: Upload limit</comment>
        <translation type="unfinished">Gön. Sınırı</translation>
    </message>
    <message>
        <source>Amount downloaded</source>
        <comment>Amount of data downloaded (e.g. in MB)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Amount left</source>
        <comment>Amount of data left to download (e.g. in MB)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Time Active</source>
        <comment>Time (duration) the torrent is active (not paused)</comment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TrackerList</name>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Durum</translation>
    </message>
    <message>
        <source>Peers</source>
        <translation>Kaynak</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>İleti</translation>
    </message>
    <message>
        <source>[DHT]</source>
        <translation>[DHT]</translation>
    </message>
    <message>
        <source>Working</source>
        <translation>Çalışıyor</translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Etkisiz</translation>
    </message>
    <message>
        <source>This torrent is private</source>
        <translation>Bu torrent özel</translation>
    </message>
    <message>
        <source>Updating...</source>
        <translation>Güncelleniyor...</translation>
    </message>
    <message>
        <source>Not working</source>
        <translation>Çalışmıyor</translation>
    </message>
    <message>
        <source>Not contacted yet</source>
        <translation>Daha bağlanılamadı</translation>
    </message>
    <message>
        <source>[PeX]</source>
        <translation>[PeX]</translation>
    </message>
    <message>
        <source>[LSD]</source>
        <translation>[LSD]</translation>
    </message>
    <message>
        <source>Add a new tracker...</source>
        <translation>Yeni bir izleyici ekle...</translation>
    </message>
    <message>
        <source>Remove tracker</source>
        <translation>İzleyiciyi Kaldır</translation>
    </message>
    <message>
        <source>Force reannounce</source>
        <translation>Yeniden duyurmaya çalış</translation>
    </message>
</context>
<context>
    <name>TrackersAdditionDlg</name>
    <message>
        <source>Trackers addition dialog</source>
        <translation>İzleyici ekleme kutusu</translation>
    </message>
    <message>
        <source>List of trackers to add (one per line):</source>
        <translation>Eklemek için izleyici listesi (satır başına bir tane):</translation>
    </message>
    <message utf8="true">
        <source>µTorrent compatible list URL:</source>
        <translation>µTorrent uyumlu URL listesi:</translation>
    </message>
    <message>
        <source>I/O Error</source>
        <translation>Girdi/Çıktı Hatası</translation>
    </message>
    <message>
        <source>Error while trying to open the downloaded file.</source>
        <translation>İndirilen dosyayı açmaya çalışırken bir hata oluştu.</translation>
    </message>
    <message>
        <source>No change</source>
        <translation>Değişiklik yok</translation>
    </message>
    <message>
        <source>No additional trackers were found.</source>
        <translation>Eklenen izleyiciler bulunamadı.</translation>
    </message>
    <message>
        <source>Download error</source>
        <translation>İndirme hatası</translation>
    </message>
    <message>
        <source>The trackers list could not be downloaded, reason: %1</source>
        <translation>İzleyici listesi indirilemedi, sebep: %1</translation>
    </message>
</context>
<context>
    <name>TransferListDelegate</name>
    <message>
        <source>Downloading</source>
        <translation>İndiriliyor</translation>
    </message>
    <message>
        <source>Paused</source>
        <translation>Duraklatıldı</translation>
    </message>
    <message>
        <source>Queued</source>
        <comment>i.e. torrent is queued</comment>
        <translation>Sırada</translation>
    </message>
    <message>
        <source>Seeding</source>
        <comment>Torrent is complete and in upload-only mode</comment>
        <translation>Gönderiliyor</translation>
    </message>
    <message>
        <source>Stalled</source>
        <comment>Torrent is waiting for download to begin</comment>
        <translation>Askıda</translation>
    </message>
    <message>
        <source>Checking</source>
        <comment>Torrent local data is being checked</comment>
        <translation>Denetleniyor</translation>
    </message>
    <message>
        <source>/s</source>
        <comment>/second (.i.e per second)</comment>
        <translation>/s</translation>
    </message>
    <message>
        <source>KiB/s</source>
        <comment>KiB/second (.i.e per second)</comment>
        <translatorcomment>KB/saniye (örn. saniye başı)</translatorcomment>
        <translation>KB/s</translation>
    </message>
    <message>
        <source>Seeded for %1</source>
        <comment>e.g. Seeded for 3m10s</comment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TransferListFiltersWidget</name>
    <message>
        <source>All</source>
        <translation>Tümü</translation>
    </message>
    <message>
        <source>Downloading</source>
        <translation>İndiriliyor</translation>
    </message>
    <message>
        <source>Completed</source>
        <translation>Tamamlandı</translation>
    </message>
    <message>
        <source>Active</source>
        <translation>Etkin</translation>
    </message>
    <message>
        <source>Inactive</source>
        <translation>Etkisiz</translation>
    </message>
    <message>
        <source>All labels</source>
        <translation>Tüm etiketler</translation>
    </message>
    <message>
        <source>Unlabeled</source>
        <translation>Etiketlenmemiş</translation>
    </message>
    <message>
        <source>Remove label</source>
        <translation>Etiketi kaldır</translation>
    </message>
    <message>
        <source>New Label</source>
        <translation>Yeni etiket</translation>
    </message>
    <message>
        <source>Label:</source>
        <translation>Etiket:</translation>
    </message>
    <message>
        <source>Invalid label name</source>
        <translation>Geçersiz etiket adı</translation>
    </message>
    <message>
        <source>Please don&apos;t use any special characters in the label name.</source>
        <translation>Lütfen etiket adı içinde hiçbir özel karakter kullanmayınız.</translation>
    </message>
    <message>
        <source>Paused</source>
        <translation>Duraklatıldı</translation>
    </message>
    <message>
        <source>Add label...</source>
        <translation>Etiket ekle...</translation>
    </message>
    <message>
        <source>Resume torrents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pause torrents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete torrents</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TransferListWidget</name>
    <message>
        <source>ETA</source>
        <comment>i.e: Estimated Time of Arrival / Time left</comment>
        <translation type="obsolete">Kalan Zaman</translation>
    </message>
    <message>
        <source>Column visibility</source>
        <translation>Sütun görünürlüğü</translation>
    </message>
    <message>
        <source>Open destination folder</source>
        <translation>Hedef klasörü aç</translation>
    </message>
    <message>
        <source>Force recheck</source>
        <translation>Yeniden denetlemeye çalış</translation>
    </message>
    <message>
        <source>Copy magnet link</source>
        <translation>Çeken bağlantıyı kopyala</translation>
    </message>
    <message>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation type="obsolete">İndirme Hızı</translation>
    </message>
    <message>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation type="obsolete">Gönderme Hızı</translation>
    </message>
    <message>
        <source>Name</source>
        <comment>i.e: torrent name</comment>
        <translation type="obsolete">Ad</translation>
    </message>
    <message>
        <source>Size</source>
        <comment>i.e: torrent size</comment>
        <translation type="obsolete">Boyut</translation>
    </message>
    <message>
        <source>Done</source>
        <comment>% Done</comment>
        <translation type="obsolete">Bitti</translation>
    </message>
    <message>
        <source>Status</source>
        <comment>Torrent status (e.g. downloading, seeding, paused)</comment>
        <translation type="obsolete">Durum</translation>
    </message>
    <message>
        <source>Seeds</source>
        <comment>i.e. full sources (often untranslated)</comment>
        <translation type="obsolete">Gönderenler</translation>
    </message>
    <message>
        <source>Peers</source>
        <comment>i.e. partial sources (often untranslated)</comment>
        <translation type="obsolete">Eşler</translation>
    </message>
    <message>
        <source>Ratio</source>
        <comment>Share ratio</comment>
        <translation type="obsolete">Oran</translation>
    </message>
    <message>
        <source>Torrent Download Speed Limiting</source>
        <translation>Torren İndirme Hızı Sınırlama</translation>
    </message>
    <message>
        <source>Torrent Upload Speed Limiting</source>
        <translation>Torrent Gönderme Hızı Sınırlama</translation>
    </message>
    <message>
        <source>Super seeding mode</source>
        <translation>Süper gönderme kipi</translation>
    </message>
    <message>
        <source>Download in sequential order</source>
        <translation>Sıralı şekilde indir</translation>
    </message>
    <message>
        <source>Download first and last piece first</source>
        <translation>Önce ilk ve son parçayı indir</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Etiket</translation>
    </message>
    <message>
        <source>New Label</source>
        <translation>Yeni Etiket</translation>
    </message>
    <message>
        <source>Label:</source>
        <translation>Etiket:</translation>
    </message>
    <message>
        <source>New...</source>
        <comment>New label...</comment>
        <translatorcomment>Yeni etiket...</translatorcomment>
        <translation>Yeni...</translation>
    </message>
    <message>
        <source>Reset</source>
        <comment>Reset label</comment>
        <translatorcomment>Etiketi sıfırla</translatorcomment>
        <translation>Sıfırla</translation>
    </message>
    <message>
        <source>Rename</source>
        <translation>Yeniden adlandır</translation>
    </message>
    <message>
        <source>New name:</source>
        <translation>Yeni ad:</translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation>Yeniden adlandır...</translation>
    </message>
    <message>
        <source>Invalid label name</source>
        <translation>Geçersiz etiket adı</translation>
    </message>
    <message>
        <source>Please don&apos;t use any special characters in the label name.</source>
        <translation>Lütfen etiket adı içinde hiçbir özel karakter kullanmayınız.</translation>
    </message>
    <message>
        <source>Added On</source>
        <comment>Torrent was added to transfer list on 01/01/2010 08:00</comment>
        <translatorcomment>Torent, 01/01/2010 08:00 tarihinde aktarım listesine eklendi</translatorcomment>
        <translation type="obsolete">Eklendi</translation>
    </message>
    <message>
        <source>Completed On</source>
        <comment>Torrent was completed on 01/01/2010 08:00</comment>
        <translatorcomment>Torent, 01/01/2010 08:00 tarihinde tamamlandı</translatorcomment>
        <translation type="obsolete">Tamamlandı</translation>
    </message>
    <message>
        <source>Down Limit</source>
        <comment>i.e: Download limit</comment>
        <translation type="obsolete">İnd. Sınırı</translation>
    </message>
    <message>
        <source>Up Limit</source>
        <comment>i.e: Upload limit</comment>
        <translation type="obsolete">Gön. Sınırı</translation>
    </message>
    <message>
        <source>Choose save path</source>
        <translation>Kayıt yolunu seç</translation>
    </message>
    <message>
        <source>Save path creation error</source>
        <translation type="obsolete">Kayıt yolu oluşturulmada hata</translation>
    </message>
    <message>
        <source>Could not create the save path</source>
        <translation type="obsolete">Kayıt yolu oluşturulamadı</translation>
    </message>
    <message>
        <source>Set location...</source>
        <translation>Konum ayarla...</translation>
    </message>
    <message>
        <source>Preview file...</source>
        <translation>Dosya önizleme...</translation>
    </message>
    <message>
        <source>Limit upload rate...</source>
        <translation>Gönderme oranını sınırla...</translation>
    </message>
    <message>
        <source>Limit download rate...</source>
        <translation>İndirme oranını sınırla...</translation>
    </message>
    <message>
        <source>Move up</source>
        <comment>i.e. move up in the queue</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move down</source>
        <comment>i.e. Move down in the queue</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move to top</source>
        <comment>i.e. Move to top of the queue</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move to bottom</source>
        <comment>i.e. Move to bottom of the queue</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Priority</source>
        <translation type="unfinished">Öncelik</translation>
    </message>
    <message>
        <source>Resume</source>
        <comment>Resume/start the torrent</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pause</source>
        <comment>Pause the torrent</comment>
        <translation type="unfinished">Duraklat</translation>
    </message>
    <message>
        <source>Delete</source>
        <comment>Delete the torrent</comment>
        <translation type="unfinished">Sil</translation>
    </message>
    <message>
        <source>Limit share ratio...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UpDownRatioDlg</name>
    <message>
        <source>Torrent Upload/Download Ratio Limiting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use global ratio limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>buttonGroup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set no ratio limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set ratio limit to</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UsageDisplay</name>
    <message>
        <source>Usage:</source>
        <translation>Kullanım:</translation>
    </message>
    <message>
        <source>displays program version</source>
        <translation>program sürümünü gösterir</translation>
    </message>
    <message>
        <source>disable splash screen</source>
        <translation>açılış ekranını etkisizleştirir</translation>
    </message>
    <message>
        <source>displays this help message</source>
        <translation>bu yardım iletisini gösterir</translation>
    </message>
    <message>
        <source>changes the webui port (current: %1)</source>
        <translation>ağ arayüzü portunu değiştirir (şimdiki: %1)</translation>
    </message>
    <message>
        <source>[files or urls]: downloads the torrents passed by the user (optional)</source>
        <translation>[dosya ya da url]: kullanıcı tarafından seçilen torentleri indirir (seçime bağlı)</translation>
    </message>
</context>
<context>
    <name>about</name>
    <message>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <source>I would like to thank the following people who volunteered to translate qBittorrent:</source>
        <translation>qBittorrent için gönüllü olarak çevirmenlik yapanlara teşekkürlerimi sunarım:</translation>
    </message>
    <message>
        <source>Please contact me if you would like to translate qBittorrent into your own language.</source>
        <translation>Eğer qBittorrent&apos;i kendi dilinize çevirmek isterseniz benimle iletişim kurun.</translation>
    </message>
</context>
<context>
    <name>addPeerDialog</name>
    <message>
        <source>Peer addition</source>
        <translation>Eş ekleme</translation>
    </message>
    <message>
        <source>IP</source>
        <translation>IP</translation>
    </message>
    <message>
        <source>Port</source>
        <translation>Port</translation>
    </message>
</context>
<context>
    <name>addTorrentDialog</name>
    <message>
        <source>Torrent addition dialog</source>
        <translation>Torrent ekleme kutusu</translation>
    </message>
    <message>
        <source>Save path:</source>
        <translation>Kaydetme yolu:</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Torrent content:</source>
        <translation>Torrent içeriği:</translation>
    </message>
    <message>
        <source>Add to download list in paused state</source>
        <translation>İndirme listesine duraklatılmış durumda ekle</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>Ekle</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Vazgeç</translation>
    </message>
    <message>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <source>High</source>
        <translation>Yüksek</translation>
    </message>
    <message>
        <source>Maximum</source>
        <translation>En Yüksek</translation>
    </message>
    <message>
        <source>Torrent size:</source>
        <translation>Torent boyutu:</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Bilinmeyen</translation>
    </message>
    <message>
        <source>Free disk space:</source>
        <translation>Boş disk alanı:</translation>
    </message>
    <message>
        <source>Download in sequential order (slower but good for previewing)</source>
        <translation>Doğru düzende indir (yavaş ama önizleme için iyi)</translation>
    </message>
    <message>
        <source>Skip file checking and start seeding immediately</source>
        <translation>Dosya denetlemeyi atla ve hemen göndermeye başla</translation>
    </message>
    <message>
        <source>Label:</source>
        <translation>Etiket:</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Tümünü Seç</translation>
    </message>
    <message>
        <source>Select None</source>
        <translation>Hiçbirini Seçme</translation>
    </message>
    <message>
        <source>Do not download</source>
        <translation>İndirme</translation>
    </message>
</context>
<context>
    <name>authentication</name>
    <message>
        <source>Tracker authentication</source>
        <translation>İzleyici kimlik denetimi</translation>
    </message>
    <message>
        <source>Tracker:</source>
        <translation>İzleyici:</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Oturum aç</translation>
    </message>
    <message>
        <source>Username:</source>
        <translation>Kullanıcı adı:</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation>Parola:</translation>
    </message>
    <message>
        <source>Log in</source>
        <translation>Giriş</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Vazgeç</translation>
    </message>
</context>
<context>
    <name>confirmDeletionDlg</name>
    <message>
        <source>Deletion confirmation - qBittorrent</source>
        <translation>Silme isteği - qBittorrent</translation>
    </message>
    <message>
        <source>Are you sure you want to delete the selected torrents from the transfer list?</source>
        <translation>Seçili torrentleri aktarım listenizden silmek istedğinize emin misiniz?</translation>
    </message>
    <message>
        <source>Remember choice</source>
        <translation>Seçimi hatırla</translation>
    </message>
    <message>
        <source>Also delete the files on the hard disk</source>
        <translation>Ayrıca sabit diskteki dosyaları sil</translation>
    </message>
</context>
<context>
    <name>createTorrentDialog</name>
    <message>
        <source>Cancel</source>
        <translation>Vazgeç</translation>
    </message>
    <message>
        <source>Torrent Creation Tool</source>
        <translation>Torrent Oluşturma Aracı</translation>
    </message>
    <message>
        <source>Torrent file creation</source>
        <translation>Torrent dosyası oluşumu</translation>
    </message>
    <message>
        <source>Announce urls (trackers):</source>
        <translation type="obsolete">Duyuru adresleri (izleyiciler):</translation>
    </message>
    <message>
        <source>Comment (optional):</source>
        <translation type="obsolete">Yorum (seçime bağlı):</translation>
    </message>
    <message>
        <source>Web seeds urls (optional):</source>
        <translation type="obsolete">Ağda gönderenlerin adresleri  (seçime bağlı):</translation>
    </message>
    <message>
        <source>File or folder to add to the torrent:</source>
        <translation>Torrente eklemek için bir dosya veya klasör:</translation>
    </message>
    <message>
        <source>Piece size:</source>
        <translation>Parça boyutu:</translation>
    </message>
    <message>
        <source>32 KiB</source>
        <translation>32 KB</translation>
    </message>
    <message>
        <source>64 KiB</source>
        <translation>64 KB</translation>
    </message>
    <message>
        <source>128 KiB</source>
        <translation>128 KB</translation>
    </message>
    <message>
        <source>256 KiB</source>
        <translation>256 KB</translation>
    </message>
    <message>
        <source>512 KiB</source>
        <translation>512 KB</translation>
    </message>
    <message>
        <source>1 MiB</source>
        <translation>1 MB</translation>
    </message>
    <message>
        <source>2 MiB</source>
        <translation>2 MB</translation>
    </message>
    <message>
        <source>4 MiB</source>
        <translation>4 MB</translation>
    </message>
    <message>
        <source>Private (won&apos;t be distributed on DHT network if enabled)</source>
        <translation>Özel (etkinleştirildiğinde DHT ağında dağıtılmaz)</translation>
    </message>
    <message>
        <source>Start seeding after creation</source>
        <translation>Oluşturmadan sonra göndermeye başla</translation>
    </message>
    <message>
        <source>Create and save...</source>
        <translation>Oluştur ve kaydet...</translation>
    </message>
    <message>
        <source>Progress:</source>
        <translation>İlerleme:</translation>
    </message>
    <message>
        <source>Add file</source>
        <translation>Dosya ekle</translation>
    </message>
    <message>
        <source>Add folder</source>
        <translation>Klasör ekle</translation>
    </message>
    <message>
        <source>Tracker URLs:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Web seeds urls:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment:</source>
        <translation type="unfinished">Yorum:</translation>
    </message>
    <message>
        <source>Auto</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>createtorrent</name>
    <message>
        <source>Select destination torrent file</source>
        <translation type="obsolete">Hedef Torrent dosyasını seç</translation>
    </message>
    <message>
        <source>Torrent Files</source>
        <translation type="obsolete">Torrent Dosyaları</translation>
    </message>
    <message>
        <source>No input path set</source>
        <translation type="obsolete">Ayarlanmış girdi yolu yok</translation>
    </message>
    <message>
        <source>Please type an input path first</source>
        <translation type="obsolete">Lütfen önce bir girdi yolu yazın</translation>
    </message>
    <message>
        <source>Torrent creation</source>
        <translation type="obsolete">Torrent oluşturma</translation>
    </message>
    <message>
        <source>Torrent was created successfully:</source>
        <translation type="obsolete">Torrent başarıyla oluşturuldu:</translation>
    </message>
    <message>
        <source>Select a folder to add to the torrent</source>
        <translation type="obsolete">Torrente eklemek için bir klasör seçin</translation>
    </message>
    <message>
        <source>Please type an announce URL</source>
        <translation type="obsolete">Lütfen bir duyuru adresi yazın</translation>
    </message>
    <message>
        <source>Torrent creation was unsuccessful, reason: %1</source>
        <translation type="obsolete">Torrent oluşturma başarısızlıkla sonuçlandı, neden: %1</translation>
    </message>
    <message>
        <source>Announce URL:</source>
        <comment>Tracker URL</comment>
        <translation type="obsolete">Duyuru adresi:</translation>
    </message>
    <message>
        <source>Please type a web seed url</source>
        <translation type="obsolete">Lütfen bir ağ göndereni adresi yazın</translation>
    </message>
    <message>
        <source>Web seed URL:</source>
        <translation type="obsolete">Ağ göndereni adresi:</translation>
    </message>
    <message>
        <source>Select a file to add to the torrent</source>
        <translation type="obsolete">Torrente eklemek için bir dosya seçin</translation>
    </message>
    <message>
        <source>Created torrent file is invalid. It won&apos;t be added to download list.</source>
        <translation type="obsolete">Oluşturulmuş torrent dosyası geçersiz. İndirme listesine eklenmeyecek.</translation>
    </message>
</context>
<context>
    <name>downloadFromURL</name>
    <message>
        <source>Download Torrents from URLs</source>
        <translation type="obsolete">Adreslerden Torrentleri İndir</translation>
    </message>
    <message>
        <source>Only one URL per line</source>
        <translation type="obsolete">Her satırda bir Adres</translation>
    </message>
    <message>
        <source>Download</source>
        <translation>İndir</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Vazgeç</translation>
    </message>
    <message>
        <source>Download from urls</source>
        <translation>Adreslerden İndir</translation>
    </message>
    <message>
        <source>No URL entered</source>
        <translation>Girilmiş adres yok</translation>
    </message>
    <message>
        <source>Please type at least one URL.</source>
        <translation>Lütfen en az bir adres girin.</translation>
    </message>
    <message>
        <source>Add torrent links</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Both HTTP and Magnet links are supported</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>downloadThread</name>
    <message>
        <source>I/O Error</source>
        <translation type="obsolete">Girdi/Çıktı Hatası</translation>
    </message>
    <message>
        <source>The remote host name was not found (invalid hostname)</source>
        <translation type="obsolete">Uzak makina adı bulunamadı (geçersiz makina adı)</translation>
    </message>
    <message>
        <source>The operation was canceled</source>
        <translation type="obsolete">İşlem iptal edildi</translation>
    </message>
    <message>
        <source>The remote server closed the connection prematurely, before the entire reply was received and processed</source>
        <translation type="obsolete">Uzak sunucu, yanıt alınmadan ve işlenmeden bağlantıyı kapattı</translation>
    </message>
    <message>
        <source>The connection to the remote server timed out</source>
        <translation type="obsolete">Uzak sunucuya bağlantı zaman aşımına uğradı</translation>
    </message>
    <message>
        <source>SSL/TLS handshake failed</source>
        <translation type="obsolete">SSL/TLS başarısız</translation>
    </message>
    <message>
        <source>The remote server refused the connection</source>
        <translation type="obsolete">Uzak sunucu bağlantıyı reddetti</translation>
    </message>
    <message>
        <source>The connection to the proxy server was refused</source>
        <translation type="obsolete">Vekil sunucuya bağlantı reddedildi</translation>
    </message>
    <message>
        <source>The proxy server closed the connection prematurely</source>
        <translation type="obsolete">Vekil sunucu bağlantıyı beklenmeyen şekilde kapattı</translation>
    </message>
    <message>
        <source>The proxy host name was not found</source>
        <translation type="obsolete">Vekil makina adı bulunamadı</translation>
    </message>
    <message>
        <source>The connection to the proxy timed out or the proxy did not reply in time to the request sent</source>
        <translation type="obsolete">Vekille olan bağlantı zaman aşımına uğradı ya da vekil gönderilen isteğe zamanında yanıt vermedi</translation>
    </message>
    <message>
        <source>The proxy requires authentication in order to honour the request but did not accept any credentials offered</source>
        <translation type="obsolete">Vekil, isteği gerçekleştirmek için yetkilendirme gerektiriyor ancak sunulan kimliklerin hiçbirini kabul etmedi</translation>
    </message>
    <message>
        <source>The access to the remote content was denied (401)</source>
        <translation type="obsolete">Uzak içeriğe giriş reddedildi (401)</translation>
    </message>
    <message>
        <source>The operation requested on the remote content is not permitted</source>
        <translation type="obsolete">Uzak içerikteki işlem isteğine izin verilmedi</translation>
    </message>
    <message>
        <source>The remote content was not found at the server (404)</source>
        <translation type="obsolete">Uzak içerik sunucuda bulunamadı (404)</translation>
    </message>
    <message>
        <source>The remote server requires authentication to serve the content but the credentials provided were not accepted</source>
        <translation type="obsolete">Uzak sunucu, içeriğin uygunluğu için yetkilendirme istiyor ancak istenen kimlik kabul edilmedi</translation>
    </message>
    <message>
        <source>The Network Access API cannot honor the request because the protocol is not known</source>
        <translation type="obsolete">Ağ Girişi API isteği gerçekleştiremedi çünkü protokol bilinmiyor</translation>
    </message>
    <message>
        <source>The requested operation is invalid for this protocol</source>
        <translation type="obsolete">İstenen işlem bu protokol için geçersiz</translation>
    </message>
    <message>
        <source>An unknown network-related error was detected</source>
        <translation type="obsolete">Bilinmeyen ağla ilgili bir hata belirlendi</translation>
    </message>
    <message>
        <source>An unknown proxy-related error was detected</source>
        <translation type="obsolete">Bilinmeyen vekille ilgili bir hata belirlendi</translation>
    </message>
    <message>
        <source>An unknown error related to the remote content was detected</source>
        <translation type="obsolete">Bilinmeyen uzak içerikle ilgili bir hata belirlendi</translation>
    </message>
    <message>
        <source>A breakdown in protocol was detected</source>
        <translation type="obsolete">Protokolde bir hata belirlendi</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation type="obsolete">Bilinmeyen hata</translation>
    </message>
</context>
<context>
    <name>engineSelect</name>
    <message>
        <source>Search plugins</source>
        <translation>Arama eklentileri</translation>
    </message>
    <message>
        <source>Installed search engines:</source>
        <translation>Yüklenmiş arama motorları:</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Ad</translation>
    </message>
    <message>
        <source>Url</source>
        <translation>Adres</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Etkinleştirildi</translation>
    </message>
    <message>
        <source>Install a new one</source>
        <translation>Yeni bir tane yükle</translation>
    </message>
    <message>
        <source>Check for updates</source>
        <translation>Güncellemeler için denetle</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Kapat</translation>
    </message>
    <message>
        <source>Enable</source>
        <translation type="obsolete">Etkinleştir</translation>
    </message>
    <message>
        <source>Disable</source>
        <translation type="obsolete">Etkisizleştir</translation>
    </message>
    <message>
        <source>Uninstall</source>
        <translation>Yüklemeyi kaldır</translation>
    </message>
    <message>
        <source>You can get new search engine plugins here: &lt;a href=&quot;http://plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</source>
        <translation>Yeni arama motoru eklentilerini burada bulabilirsiniz: &lt;a href=&quot;http://plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</translation>
    </message>
</context>
<context>
    <name>engineSelectDlg</name>
    <message>
        <source>Uninstall warning</source>
        <translation>Yüklemeyi kaldırma uyarısı</translation>
    </message>
    <message>
        <source>Some plugins could not be uninstalled because they are included in qBittorrent.
 Only the ones you added yourself can be uninstalled.
However, those plugins were disabled.</source>
        <translation>Bazı eklentiler kaldırılamadı çünkü bunlar qBittorrent&apos;te kullanılıyor.
 Sadece kendi ekledikleriniz kaldırılabilir.
Bununla birlikte, o eklentiler devre dışı.</translation>
    </message>
    <message>
        <source>Uninstall success</source>
        <translation>Yükleme kaldırılması başarılı</translation>
    </message>
    <message>
        <source>Select search plugins</source>
        <translation>Arama eklentilerini seç</translation>
    </message>
    <message>
        <source>qBittorrent search plugins</source>
        <translation>qBittorrent arama eklentileri</translation>
    </message>
    <message>
        <source>Search plugin install</source>
        <translation>Arama eklentisi yüklemesi</translation>
    </message>
    <message>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <source>A more recent version of %1 search engine plugin is already installed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>%1 arama motoru eklentisinin daha güncel sürümü zaten yüklü durumda.</translation>
    </message>
    <message>
        <source>Search plugin update</source>
        <translation>Eklenti güncellemesi ara</translation>
    </message>
    <message>
        <source>Sorry, update server is temporarily unavailable.</source>
        <translation>Üzgünüz, güncelleme sunucusu geçici olarak servis dışı.</translation>
    </message>
    <message>
        <source>All your plugins are already up to date.</source>
        <translation>Bütün eklentileriniz zaten güncel durumda.</translation>
    </message>
    <message>
        <source>%1 search engine plugin could not be updated, keeping old version.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>%1 arama motoru eklentisi güncellenemedi, eski sürüm tutulacak.</translation>
    </message>
    <message>
        <source>%1 search engine plugin could not be installed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>%1 arama motoru eklentisi yüklenemedi.</translation>
    </message>
    <message>
        <source>All selected plugins were uninstalled successfully</source>
        <translation>Bütün seçili eklentiler başarıyla kaldırıldı</translation>
    </message>
    <message>
        <source>%1 search engine plugin was successfully updated.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>%1 arama motoru eklentisi başarıyla güncellendi.</translation>
    </message>
    <message>
        <source>%1 search engine plugin was successfully installed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>%1 arama motoru eklentisi başarıyla yüklendi.</translation>
    </message>
    <message>
        <source>Sorry, %1 search plugin install failed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>Üzgünüz, %1 arama eklenti yüklemesi başarısız oldu.</translation>
    </message>
    <message>
        <source>New search engine plugin URL</source>
        <translation>Yeni arama motoru eklentisi adresi</translation>
    </message>
    <message>
        <source>URL:</source>
        <translation>Adres:</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Evet</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Hayır</translation>
    </message>
</context>
<context>
    <name>misc</name>
    <message>
        <source>B</source>
        <comment>bytes</comment>
        <translation>B</translation>
    </message>
    <message>
        <source>KiB</source>
        <comment>kibibytes (1024 bytes)</comment>
        <translation>KB</translation>
    </message>
    <message>
        <source>MiB</source>
        <comment>mebibytes (1024 kibibytes)</comment>
        <translation>MB</translation>
    </message>
    <message>
        <source>GiB</source>
        <comment>gibibytes (1024 mibibytes)</comment>
        <translation>GB</translation>
    </message>
    <message>
        <source>TiB</source>
        <comment>tebibytes (1024 gibibytes)</comment>
        <translation>TB</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Bilinmeyen</translation>
    </message>
    <message>
        <source>Unknown</source>
        <comment>Unknown (size)</comment>
        <translation>Bilinmeyen</translation>
    </message>
    <message>
        <source>&lt; 1m</source>
        <comment>&lt; 1 minute</comment>
        <translation>&lt; 1d</translation>
    </message>
    <message>
        <source>%1m</source>
        <comment>e.g: 10minutes</comment>
        <translation>%1d</translation>
    </message>
    <message>
        <source>%1h %2m</source>
        <comment>e.g: 3hours 5minutes</comment>
        <translation>%1sa %2dk</translation>
    </message>
    <message>
        <source>%1d %2h</source>
        <comment>e.g: 2days 10hours</comment>
        <translation>%1gün %2sa</translation>
    </message>
    <message>
        <source>qBittorrent will shutdown the computer now because all downloads are complete.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>options_imp</name>
    <message>
        <source>Choose a save directory</source>
        <translation>Bir kayıt dizini seçin</translation>
    </message>
    <message>
        <source>Choose an ip filter file</source>
        <translation>Bir ip süzgeç dosyası seçin</translation>
    </message>
    <message>
        <source>Filters</source>
        <translation>Süzgeçler</translation>
    </message>
    <message>
        <source>Choose export directory</source>
        <translation>Dışa aktarım dizini seç</translation>
    </message>
    <message>
        <source>Add directory to scan</source>
        <translation>Taranacak dizin ekle</translation>
    </message>
    <message>
        <source>Folder is already being watched.</source>
        <translation>Bu klasör zaten izleniyor.</translation>
    </message>
    <message>
        <source>Folder does not exist.</source>
        <translation>Klasör mevcut değil.</translation>
    </message>
    <message>
        <source>Folder is not readable.</source>
        <translation>Klasör okunabilir değil.</translation>
    </message>
    <message>
        <source>Failure</source>
        <translation>Hata</translation>
    </message>
    <message>
        <source>Failed to add Scan Folder &apos;%1&apos;: %2</source>
        <translation>Tarama Klasörü &apos;%1&apos; ekleme başarısız: %2</translation>
    </message>
    <message>
        <source>Parsing error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to parse the provided IP filter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Successfuly parsed the provided IP filter: %1 rules were applied.</source>
        <comment>%1 is a number</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Successfully refreshed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This is not a valid SSL key.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid certificate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This is not a valid SSL certificate.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SSL Certificate (*.crt *.pem)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SSL Key (*.key *.pem)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>pluginSourceDlg</name>
    <message>
        <source>Plugin source</source>
        <translation>Eklenti kaynağı</translation>
    </message>
    <message>
        <source>Search plugin source:</source>
        <translation>Eklenti kaynağı ara:</translation>
    </message>
    <message>
        <source>Local file</source>
        <translation>Yerel dosya</translation>
    </message>
    <message>
        <source>Web link</source>
        <translation>Ağ bağlantısı</translation>
    </message>
</context>
<context>
    <name>preview</name>
    <message>
        <source>Preview selection</source>
        <translation>Önizleme seçimi</translation>
    </message>
    <message>
        <source>File preview</source>
        <translation>Dosya önizlemesi</translation>
    </message>
    <message>
        <source>The following files support previewing, &lt;br&gt;please select one of them:</source>
        <translation>Aşağıdaki dosyalar önizlemeyi destekliyor, &lt;br&gt;lütfen birini seçin:</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Önizleme</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Vazgeç</translation>
    </message>
</context>
<context>
    <name>previewSelect</name>
    <message>
        <source>Preview impossible</source>
        <translation type="obsolete">Önizleme yapılamıyor</translation>
    </message>
    <message>
        <source>Sorry, we can&apos;t preview this file</source>
        <translation type="obsolete">Üzgünüz, bu dosyanın önizlemesi yapılamıyor</translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="obsolete">Ad</translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="obsolete">Boyut</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation type="obsolete">İlerleme</translation>
    </message>
</context>
<context>
    <name>search_engine</name>
    <message>
        <source>Search</source>
        <translation>Ara</translation>
    </message>
    <message>
        <source>Status:</source>
        <translation>Durum:</translation>
    </message>
    <message>
        <source>Stopped</source>
        <translation>Durdu</translation>
    </message>
    <message>
        <source>Download</source>
        <translation>İndir</translation>
    </message>
    <message>
        <source>Search engines...</source>
        <translation>Arama motorları...</translation>
    </message>
    <message>
        <source>Go to description page</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>torrentAdditionDialog</name>
    <message>
        <source>Unable to decode torrent file:</source>
        <translation>Torrent dosyası çözülemiyor:</translation>
    </message>
    <message>
        <source>Choose save path</source>
        <translation>Kayıt klasörünü seçin</translation>
    </message>
    <message>
        <source>Empty save path</source>
        <translation>Boş kayıt yolu</translation>
    </message>
    <message>
        <source>Please enter a save path</source>
        <translation>Lütfen bir kayıt yolu girin</translation>
    </message>
    <message>
        <source>Save path creation error</source>
        <translation>Kayıt yolu oluşturulmada hata</translation>
    </message>
    <message>
        <source>Could not create the save path</source>
        <translation>Kayıt yolu oluşturulamıyor</translation>
    </message>
    <message>
        <source>Invalid file selection</source>
        <translation>Geçersiz dosya seçimi</translation>
    </message>
    <message>
        <source>You must select at least one file in the torrent</source>
        <translation>Torrent içinde en az bir dosya seçmek zorundasınız</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Öncelik</translation>
    </message>
    <message>
        <source>(%1 left after torrent download)</source>
        <comment>e.g. (100MiB left after torrent download)</comment>
        <translation>(torentin indirilmesinden sonra %1 kalacak)</translation>
    </message>
    <message>
        <source>(%1 more are required to download)</source>
        <comment>e.g. (100MiB more are required to download)</comment>
        <translation>(indirilmesi için %1 daha gerekli)</translation>
    </message>
    <message>
        <source>Seeding mode error</source>
        <translation>Gönderme kipi hatası</translation>
    </message>
    <message>
        <source>You chose to skip file checking. However, local files do not seem to exist in the current destionation folder. Please disable this feature or update the save path.</source>
        <translation>Dosya denetlemeyi es geçtiniz. Buna rağmen yerel dosyanın mevcut hedef klasör içinde bulunmadığı gözüküyor. Lütfen bu özelliği etkisizleştirin ya da kaydetme yolunu güncelleyin.</translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation>Yeniden adlandır...</translation>
    </message>
    <message>
        <source>New name:</source>
        <translation>Yeni ad:</translation>
    </message>
    <message>
        <source>The file could not be renamed</source>
        <translation>Dosya yeniden adlandırılamadı</translation>
    </message>
    <message>
        <source>This name is already in use in this folder. Please use a different name.</source>
        <translation>Bu ad klasör içinde başka bir öğe tarafından kullanılıyor, Lütfen başka bir ad seçin.</translation>
    </message>
    <message>
        <source>The folder could not be renamed</source>
        <translation>Klasör yeniden adlandırılamadı</translation>
    </message>
    <message>
        <source>Rename the file</source>
        <translation>Dosyayı yeniden adlandır</translation>
    </message>
    <message>
        <source>Unable to decode magnet link:</source>
        <translation>İlişik bağlantı kodu çözümlenemedi:</translation>
    </message>
    <message>
        <source>Magnet Link</source>
        <translation>İlişik Bağlantı</translation>
    </message>
    <message>
        <source>Invalid label name</source>
        <translation>Geçersiz etiket adı</translation>
    </message>
    <message>
        <source>Please don&apos;t use any special characters in the label name.</source>
        <translation>Lütfen etiket adı içinde hiçbir özel karakter kullanmayınız.</translation>
    </message>
    <message>
        <source>This file name contains forbidden characters, please choose a different one.</source>
        <translation>Bu dosya adı yasak karakterler içeriyor, lütfen başka bir ad seçin.</translation>
    </message>
</context>
</TS>
