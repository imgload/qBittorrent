<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="nl_NL" sourcelanguage="en">
<context>
    <name>AboutDlg</name>
    <message>
        <source>About qBittorrent</source>
        <translation>Over qBittorrent</translation>
    </message>
    <message>
        <source>About</source>
        <translation>Over</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Auteur</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation>Naam:</translation>
    </message>
    <message>
        <source>Country:</source>
        <translation>Land:</translation>
    </message>
    <message>
        <source>E-mail:</source>
        <translation>E-mail:</translation>
    </message>
    <message>
        <source>Christophe Dumez</source>
        <translation>Christophe Dumez</translation>
    </message>
    <message>
        <source>France</source>
        <translation>Frankrijk</translation>
    </message>
    <message>
        <source>Translation</source>
        <translation>Vertaling</translation>
    </message>
    <message>
        <source>License</source>
        <translation>Licentie</translation>
    </message>
    <message>
        <source>&lt;h3&gt;&lt;b&gt;qBittorrent&lt;/b&gt;&lt;/h3&gt;</source>
        <translation>&lt;h3&gt;&lt;b&gt;qBittorrent&lt;/b&gt;&lt;/h3&gt;</translation>
    </message>
    <message>
        <source>chris@qbittorrent.org</source>
        <translation></translation>
    </message>
    <message>
        <source>Thanks to</source>
        <translation>Met dank aan</translation>
    </message>
    <message utf8="true">
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;A Bittorrent client programmed in C++, based on Qt4 toolkit &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;and libtorrent-rasterbar. &lt;br /&gt;&lt;br /&gt;Copyright ©2006-2010 Christophe Dumez&lt;br /&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Home Page:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://www.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;http://www.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Forum:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://forum.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;http://forum.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;IRC:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; #qbittorrent on Freenode&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;Een Bittorrent client geprogrammeerd in C++, gebaseerd op Qt4 toolkit &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;en libtorrent-rasterbar. &lt;br /&gt;&lt;br /&gt;Copyright ©2006-2010 Christophe Dumez&lt;br /&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Home Page:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://www.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;http://www.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Forum:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://forum.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;http://forum.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;IRC:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; #qbittorrent op Freenode&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message utf8="true">
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;An advanced BitTorrent client programmed in C++, based on Qt4 toolkit and libtorrent-rasterbar. &lt;br /&gt;&lt;br /&gt;Copyright ©2006-2011 Christophe Dumez&lt;br /&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Home Page:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://www.qbittorrent.org&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans&apos;; text-decoration: underline; color:#0057ae;&quot;&gt;http://www.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Bug Tracker:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://bugs.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;http://bugs.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Forum:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://forum.qbittorrent.org&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans&apos;; text-decoration: underline; color:#0057ae;&quot;&gt;http://forum.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;IRC:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; #qbittorrent on Freenode&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;Een geavanceerde Bittorrent client geprogrammeerd in C++, gebaseerd op Qt4 toolkit en libtorrent-rasterbar. &lt;br /&gt;&lt;br /&gt;Copyright ©2006-2011 Christophe Dumez&lt;br /&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Home Page:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://www.qbittorrent.org&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans&apos;; text-decoration: underline; color:#0057ae;&quot;&gt;http://www.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Bug Tracker:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://bugs.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;http://bugs.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Forum:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://forum.qbittorrent.org&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans&apos;; text-decoration: underline; color:#0057ae;&quot;&gt;http://forum.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;IRC:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; #qbittorrent op Freenode&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
</context>
<context>
    <name>AdvancedSettings</name>
    <message>
        <source>Property</source>
        <translation type="obsolete">Eigenschap</translation>
    </message>
    <message>
        <source>Value</source>
        <translation type="obsolete">Waarde</translation>
    </message>
    <message>
        <source>Ignore transfer limits on local network</source>
        <translation>Negeer overdrachtlimieten op het locale netwerk</translation>
    </message>
    <message>
        <source>Include TCP/IP overhead in transfer limits</source>
        <translation type="obsolete">Includeer TCP/IP overheid in de overdrachtlimieten</translation>
    </message>
    <message>
        <source>Disk write cache size</source>
        <translation>Disk write cache grootte</translation>
    </message>
    <message>
        <source> MiB</source>
        <translation>MiB</translation>
    </message>
    <message>
        <source>Outgoing ports (Min) [0: Disabled]</source>
        <translation>Uitgaande poorten (Min) [0: Uitgeschakeld]</translation>
    </message>
    <message>
        <source>Outgoing ports (Max) [0: Disabled]</source>
        <translation>UItgaande poorten (Max) [0: Uitgeschakeld]</translation>
    </message>
    <message>
        <source>Recheck torrents on completion</source>
        <translation>Hercontroleer torrents bij voltooiing</translation>
    </message>
    <message>
        <source>Transfer list refresh interval</source>
        <translation>Overdrachtenlijst vernieuwinterval</translation>
    </message>
    <message>
        <source> ms</source>
        <comment> milliseconds</comment>
        <translation>ms</translation>
    </message>
    <message>
        <source>Resolve peer countries (GeoIP)</source>
        <translation>Ontbind peer landen (GeoIP)</translation>
    </message>
    <message>
        <source>Resolve peer host names</source>
        <translation>Ontbind peer hostnamen</translation>
    </message>
    <message>
        <source>Maximum number of half-open connections [0: Disabled]</source>
        <translation>Maximum aantal van half-open verbindingen [0 Uitgeschakeld]</translation>
    </message>
    <message>
        <source>Strict super seeding</source>
        <translation>Stricte super seeding</translation>
    </message>
    <message>
        <source>Network Interface (requires restart)</source>
        <translation>Netwerkinterface (vereist herstart)</translation>
    </message>
    <message>
        <source>Any interface</source>
        <comment>i.e. Any network interface</comment>
        <translation>Gelijk welke interface</translation>
    </message>
    <message>
        <source>Display program notification balloons</source>
        <translation type="obsolete">Toon programma notificatie ballonnen</translation>
    </message>
    <message>
        <source>Enable embedded tracker</source>
        <translation>Activeer embedded tracker</translation>
    </message>
    <message>
        <source>Embedded tracker port</source>
        <translation>Embedded trackerpoort</translation>
    </message>
    <message>
        <source>Check for software updates</source>
        <translation>Controleer op software updates</translation>
    </message>
    <message>
        <source>Use system icon theme</source>
        <translation>Gebruik systeem iconen thema</translation>
    </message>
    <message>
        <source>Confirm torrent deletion</source>
        <translation>Bevestig verwijder torrent</translation>
    </message>
    <message>
        <source>IP Address to report to trackers (requires restart)</source>
        <translation>IP-adres om te melden aan trackers (vereist herstart)</translation>
    </message>
    <message>
        <source>Display program on-screen notifications</source>
        <translation>Toon programma on-screen meldingen</translation>
    </message>
    <message>
        <source>Setting</source>
        <translation>Instelling</translation>
    </message>
    <message>
        <source>Value</source>
        <comment>Value set for this setting</comment>
        <translation>Waarde</translation>
    </message>
    <message>
        <source>Exchange trackers with other peers</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AutomatedRssDownloader</name>
    <message>
        <source>Automated RSS Downloader</source>
        <translation>Automatische RSS Downloader</translation>
    </message>
    <message>
        <source>Enable the automated RSS downloader</source>
        <translation>Activeer de automatische RSS downloader</translation>
    </message>
    <message>
        <source>Download rules</source>
        <translation>Downloadregels</translation>
    </message>
    <message>
        <source>Rule definition</source>
        <translation>Regeldefinitie</translation>
    </message>
    <message>
        <source>Must contain:</source>
        <translation>Moet bevatten:</translation>
    </message>
    <message>
        <source>Must not contain:</source>
        <translation>Mag niet bevatten:</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Assign label:</source>
        <translation>Ken label toe:</translation>
    </message>
    <message>
        <source>Apply rule to feeds:</source>
        <translation>Pas regel toe op feeds:</translation>
    </message>
    <message>
        <source>Matching RSS articles</source>
        <translation>Overeenkomstige RSS artikels</translation>
    </message>
    <message>
        <source>Save to a different directory</source>
        <translation>Opslaan in een andere map</translation>
    </message>
    <message>
        <source>Save to:</source>
        <translation>Opslaan in:</translation>
    </message>
    <message>
        <source>Import...</source>
        <translation>Importeer...</translation>
    </message>
    <message>
        <source>Export...</source>
        <translation>Exporteer...</translation>
    </message>
    <message>
        <source>New rule name</source>
        <translation>Nieuwe regel naam</translation>
    </message>
    <message>
        <source>Please type the name of the new download rule.</source>
        <translation>Type de naam van de nieuwe downloadregel.</translation>
    </message>
    <message>
        <source>Rule name conflict</source>
        <translation>Regelnaam conflict</translation>
    </message>
    <message>
        <source>A rule with this name already exists, please choose another name.</source>
        <translation>Een regel met deze naam bestaat reeds, kies een andere naam.</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the download rule named %1?</source>
        <translation>Bent u zeker dat u de downloadregel met naam %1 wilt verwijderen?</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the selected download rules?</source>
        <translation>Bent u zeker dat u de geselecteerde downloadregel wilt verwijderen?</translation>
    </message>
    <message>
        <source>Rule deletion confirmation</source>
        <translation>Regelverwijdering bevestiging</translation>
    </message>
    <message>
        <source>Destination directory</source>
        <translation>Bestemmingsmap</translation>
    </message>
    <message>
        <source>Invalid action</source>
        <translation>Ongeldige actie</translation>
    </message>
    <message>
        <source>The list is empty, there is nothing to export.</source>
        <translation>De lijst is leeg, er is niets om te importeren.</translation>
    </message>
    <message>
        <source>Where would you like to save the list?</source>
        <translation>Waar wilt u de lijst opslaan?</translation>
    </message>
    <message>
        <source>Rules list (*.rssrules)</source>
        <translation>Ruleslijst (*.rssrules)</translation>
    </message>
    <message>
        <source>I/O Error</source>
        <translation>I/O Fout</translation>
    </message>
    <message>
        <source>Failed to create the destination file</source>
        <translation>Mislukt om het bestemmingsbestand te maken</translation>
    </message>
    <message>
        <source>Please point to the RSS download rules file</source>
        <translation>Gelieve te verwijzen naar het RSS download regelsbestand</translation>
    </message>
    <message>
        <source>Rules list (*.rssrules *.filters)</source>
        <translation>Regelslijst (*.rssrules *.filters)</translation>
    </message>
    <message>
        <source>Import Error</source>
        <translation>Import Fout</translation>
    </message>
    <message>
        <source>Failed to import the selected rules file</source>
        <translation>Mislukt om de geselecteerd regelslijst te importeren</translation>
    </message>
    <message>
        <source>Add new rule...</source>
        <translation>Voeg een nieuwe regel toe...</translation>
    </message>
    <message>
        <source>Delete rule</source>
        <translation>Verwijder regel</translation>
    </message>
    <message>
        <source>Rename rule...</source>
        <translation>Hernoem regel...</translation>
    </message>
    <message>
        <source>Delete selected rules</source>
        <translation>Verwijder geselecteerd regels</translation>
    </message>
    <message>
        <source>Rule renaming</source>
        <translation>Regelhernoeming</translation>
    </message>
    <message>
        <source>Please type the new rule name</source>
        <translation>Gelieve de nieuwe regelnaam te geven</translation>
    </message>
    <message>
        <source>Use regular expressions</source>
        <translation>Gebruike reguliere expressies</translation>
    </message>
    <message>
        <source>Regex mode: use Perl-like regular expressions</source>
        <translation>Regex modues: gebruik reguliere expressies die gelijkaardig zijn aa Perl</translation>
    </message>
    <message>
        <source>Wildcard mode: you can use&lt;ul&gt;&lt;li&gt;? to match any single character&lt;/li&gt;&lt;li&gt;* to match zero or more of any characters&lt;/li&gt;&lt;li&gt;Whitespaces count as AND operators&lt;/li&gt;&lt;/ul&gt;</source>
        <translation>Wildcard modus: u kan gebruikem maken van &lt;ul&gt;&lt;li&gt;? om één enkel teken voor te stellen&lt;/li&gt;&lt;li&gt;* om nul of meerdere tekens voor te stellen&lt;li&gt;&lt;li&gt;Witruimtes tellen als AND operatoren&lt;li&gt;&lt;lu&gt;</translation>
    </message>
    <message>
        <source>Wildcard mode: you can use&lt;ul&gt;&lt;li&gt;? to match any single character&lt;/li&gt;&lt;li&gt;* to match zero or more of any characters&lt;/li&gt;&lt;li&gt;| is used as OR operator&lt;/li&gt;&lt;/ul&gt;</source>
        <translation>Wildcard modus: u kan gebruikem maken van &lt;ul&gt;&lt;li&gt;? om één enkel teken voor te stellen&lt;/li&gt;&lt;li&gt;* om nul of meerdere tekens voor te stellen&lt;li&gt;&lt;li&gt;| wordt gebruikt als als OR operator&lt;li&gt;&lt;lu&gt;</translation>
    </message>
</context>
<context>
    <name>Bittorrent</name>
    <message>
        <source>%1 reached the maximum ratio you set.</source>
        <translation type="obsolete">%1 heeft de maximum ingestelde verhouding bereikt.</translation>
    </message>
    <message>
        <source>qBittorrent is bound to port: TCP/%1</source>
        <comment>e.g: qBittorrent is bound to port: 6881</comment>
        <translation type="obsolete">qBittorrent is verbonden met poort: TCP/%1</translation>
    </message>
    <message>
        <source>UPnP support [ON]</source>
        <translation type="obsolete">UPnP ondersteuning [AAN]</translation>
    </message>
    <message>
        <source>UPnP support [OFF]</source>
        <translation type="obsolete">UPnP ondersteuning [UIT]</translation>
    </message>
    <message>
        <source>NAT-PMP support [ON]</source>
        <translation type="obsolete">NAT-PMP ondersteuning [AAN]</translation>
    </message>
    <message>
        <source>NAT-PMP support [OFF]</source>
        <translation type="obsolete">NAT-PMP ondersteuning [UIT]</translation>
    </message>
    <message>
        <source>DHT support [ON], port: UDP/%1</source>
        <translation type="obsolete">DHT ondersteuning [AAN], poort: UDP/%1</translation>
    </message>
    <message>
        <source>DHT support [OFF]</source>
        <translation type="obsolete">DHT ondersteuning [UIT]</translation>
    </message>
    <message>
        <source>PeX support [ON]</source>
        <translation type="obsolete">PeX ondersteuning [AAN]</translation>
    </message>
    <message>
        <source>Local Peer Discovery [ON]</source>
        <translation type="obsolete">Local Peer Discovery [AAN]</translation>
    </message>
    <message>
        <source>Local Peer Discovery support [OFF]</source>
        <translation type="obsolete">Local Peer Discovery ondersteuning [UIT]</translation>
    </message>
    <message>
        <source>Encryption support [ON]</source>
        <translation type="obsolete">Encryptie ondersteuning [AAN]</translation>
    </message>
    <message>
        <source>Encryption support [FORCED]</source>
        <translation type="obsolete">Encryptie ondersteuning [GEFORCEERD]</translation>
    </message>
    <message>
        <source>Encryption support [OFF]</source>
        <translation type="obsolete">Encryptie ondersteuning [UIT]</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is not a valid magnet URI.</source>
        <translation type="obsolete">&apos;%1&apos; is geen juiste magnet URI.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is already in download list.</source>
        <comment>e.g: &apos;xxx.avi&apos; is already in download list.</comment>
        <translation type="obsolete">&apos;%1&apos; staat al in de downloadlijst.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; resumed. (fast resume)</source>
        <comment>&apos;/home/y/xxx.torrent&apos; was resumed. (fast resume)</comment>
        <translation type="obsolete">&apos;%1&apos; hervat. (snelle hervatting)</translation>
    </message>
    <message>
        <source>&apos;%1&apos; added to download list.</source>
        <comment>&apos;/home/y/xxx.torrent&apos; was added to download list.</comment>
        <translation type="obsolete">&apos;%1&apos; toegevoegd aan de downloadlijst.</translation>
    </message>
    <message>
        <source>Unable to decode torrent file: &apos;%1&apos;</source>
        <comment>e.g: Unable to decode torrent file: &apos;/home/y/xxx.torrent&apos;</comment>
        <translation type="obsolete">Torrentbestand kan niet worden gedecodeerd: &apos;%1&apos;</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;was blocked due to your IP filter&lt;/i&gt;</source>
        <comment>x.y.z.w was blocked</comment>
        <translation type="obsolete">&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;is geblokkeerd door de IP filter&lt;/i&gt;</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;was banned due to corrupt pieces&lt;/i&gt;</source>
        <comment>x.y.z.w was banned</comment>
        <translation type="obsolete">&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;is verbannen door onjuiste stukjes&lt;/i&gt;</translation>
    </message>
    <message>
        <source>Recursive download of file %1 embedded in torrent %2</source>
        <comment>Recursive download of test.torrent embedded in torrent test2</comment>
        <translation type="obsolete">Recursieve download van bestand %1 in torrent %2</translation>
    </message>
    <message>
        <source>Unable to decode %1 torrent file.</source>
        <translation type="obsolete">Kon torrentbestand %1 niet decoderen.</translation>
    </message>
    <message>
        <source>UPnP/NAT-PMP: Port mapping failure, message: %1</source>
        <translation type="obsolete">UPnP/NAT-PMP: Port mapping fout, bericht: %1</translation>
    </message>
    <message>
        <source>UPnP/NAT-PMP: Port mapping successful, message: %1</source>
        <translation type="obsolete">UPnP/NAT-PMP: Port mapping succesvol, bericht: %1</translation>
    </message>
    <message>
        <source>Url seed lookup failed for url: %1, message: %2</source>
        <translation type="obsolete">Url seed raadpleging mislukt voor url: %1, bericht: %2</translation>
    </message>
    <message>
        <source>Downloading &apos;%1&apos;, please wait...</source>
        <comment>e.g: Downloading &apos;xxx.torrent&apos;, please wait...</comment>
        <translation type="obsolete">Bezig met downloaden van &apos;%1&apos;, even geduld alstublieft...</translation>
    </message>
    <message>
        <source>PeX support [OFF]</source>
        <translation type="obsolete">PeX ondersteuning [UIT]</translation>
    </message>
</context>
<context>
    <name>ConsoleDlg</name>
    <message>
        <source>General</source>
        <translation type="obsolete">Algemeen</translation>
    </message>
    <message>
        <source>Blocked IPs</source>
        <translation type="obsolete">Geblokkeerde IP&apos;s</translation>
    </message>
    <message>
        <source>qBittorrent log viewer</source>
        <translation type="obsolete">qBittorrent log viewer</translation>
    </message>
</context>
<context>
    <name>CookiesDlg</name>
    <message>
        <source>Cookies management</source>
        <translation>Cookiesbeheer</translation>
    </message>
    <message>
        <source>Key</source>
        <extracomment>As in Key/Value pair</extracomment>
        <translation>Sleutel</translation>
    </message>
    <message>
        <source>Value</source>
        <extracomment>As in Key/Value pair</extracomment>
        <translation>Waarde</translation>
    </message>
    <message>
        <source>Common keys for cookies are : &apos;%1&apos;, &apos;%2&apos;.
You should get this information from your Web browser preferences.</source>
        <translation>Algemene sleutel voor cookies zijn : &apos;%1&apos;, &apos;%2&apos;.
U zou informatie moeten krijgen van u Webbrowser voorkeuren.</translation>
    </message>
</context>
<context>
    <name>DNSUpdater</name>
    <message>
        <source>Your dynamic DNS was successfuly updated.</source>
        <translation>U dynamisch DNS werd succesvol geüpdate.</translation>
    </message>
    <message>
        <source>Dynamic DNS error: The service is temporarily unavailable, it will be retried in 30 minutes.</source>
        <translation>Dynamische DNS error: De service is tijdelijk onbeschikbaar, er wordt opnieuw geprobeerd binnen 30 minuten.</translation>
    </message>
    <message>
        <source>Dynamic DNS error: hostname supplied does not exist under specified account.</source>
        <translation>Dynamische DNS error: opgegeven hostname bestaat niet bij de opgegeven account.</translation>
    </message>
    <message>
        <source>Dynamic DNS error: Invalid username/password.</source>
        <translation>Dynamische DNS error: Ongeldige gebruikersnaam/wachtwoord.</translation>
    </message>
    <message>
        <source>Dynamic DNS error: qBittorrent was blacklisted by the service, please report a bug at http://bugs.qbittorrent.org.</source>
        <translation>Dynamische DNS error: qBittorrent werd geblacklist door deze service, gelieve de bug te rapporteren op http://bugs.qbittorent.org.</translation>
    </message>
    <message>
        <source>Dynamic DNS error: %1 was returned by the service, please report a bug at http://bugs.qbittorrent.org.</source>
        <translation>Dynamische DNS error: %1 werd teruggegeven door de service, gelieve de bug te rapporteren op http://bugs.qbittorrent.org.</translation>
    </message>
    <message>
        <source>Dynamic DNS error: Your username was blocked due to abuse.</source>
        <translation>Dynamische DNS error: U gebruikersnaam werd geblokkeerd door misbruik.</translation>
    </message>
    <message>
        <source>Dynamic DNS error: supplied domain name is invalid.</source>
        <translation>Dynamische DNS error: opgegeven domeinnaam is ongeldig.</translation>
    </message>
    <message>
        <source>Dynamic DNS error: supplied username is too short.</source>
        <translation>Dynamische DNS error: opgegegeven gebruikersnaam is te kort.</translation>
    </message>
    <message>
        <source>Dynamic DNS error: supplied password is too short.</source>
        <translation>Dynamische DNS error: opgegegeven wachtwoord is te kort.</translation>
    </message>
</context>
<context>
    <name>DownloadThread</name>
    <message>
        <source>I/O Error</source>
        <translation>I/O Fout</translation>
    </message>
    <message>
        <source>The remote host name was not found (invalid hostname)</source>
        <translation>De remote hostnaam werd niet gevonden (ongeldige hostnaam)</translation>
    </message>
    <message>
        <source>The operation was canceled</source>
        <translation>De operatie werd geannuleerd</translation>
    </message>
    <message>
        <source>The remote server closed the connection prematurely, before the entire reply was received and processed</source>
        <translation>De remote server sloot de verbinding permanent, voor de gehele reactie werd ontvangen en verwerkt</translation>
    </message>
    <message>
        <source>The connection to the remote server timed out</source>
        <translation>De verbinding naar de remote server timede out</translation>
    </message>
    <message>
        <source>SSL/TLS handshake failed</source>
        <translation>SSL/T|S handshake mislukt</translation>
    </message>
    <message>
        <source>The remote server refused the connection</source>
        <translation>De remote server weigerde de verbinding</translation>
    </message>
    <message>
        <source>The connection to the proxy server was refused</source>
        <translation>De verbinding naar de proxy server werd geweigerd</translation>
    </message>
    <message>
        <source>The proxy server closed the connection prematurely</source>
        <translation>De proxy server sloot de verbinding permanent</translation>
    </message>
    <message>
        <source>The proxy host name was not found</source>
        <translation>De proxy host name werd niet gevonden</translation>
    </message>
    <message>
        <source>The connection to the proxy timed out or the proxy did not reply in time to the request sent</source>
        <translation>De verbinding naar de proxy timede out of the proxy reageerde niet op tijd op het verzonden verzoek</translation>
    </message>
    <message>
        <source>The proxy requires authentication in order to honour the request but did not accept any credentials offered</source>
        <translation>De proxy vereist authenticatie om in te kunnen gaan op het verzoek maar accepteerde geen van de aangeboden credentials</translation>
    </message>
    <message>
        <source>The access to the remote content was denied (401)</source>
        <translation>De toegang tot de remote content werd genegeerd (401)</translation>
    </message>
    <message>
        <source>The operation requested on the remote content is not permitted</source>
        <translation>De gevraagde operatie op de remote content is niet toegestaan</translation>
    </message>
    <message>
        <source>The remote content was not found at the server (404)</source>
        <translation>De remote content werd niet gevonden op de server (404)</translation>
    </message>
    <message>
        <source>The remote server requires authentication to serve the content but the credentials provided were not accepted</source>
        <translation>De remote server vereist authenticatie om de inhoud te presenteren maar de gegeven credentials werden niet geaccepteerd</translation>
    </message>
    <message>
        <source>The Network Access API cannot honor the request because the protocol is not known</source>
        <translation>De Network Access API kon niet ingaan op het verzoek want het protocol is niet bekend</translation>
    </message>
    <message>
        <source>The requested operation is invalid for this protocol</source>
        <translation>De verzochte operatie is niet geldig voor dit protocol</translation>
    </message>
    <message>
        <source>An unknown network-related error was detected</source>
        <translation>Een onbekende netwerkgerelateerde fout werd gevonden</translation>
    </message>
    <message>
        <source>An unknown proxy-related error was detected</source>
        <translation>Een onbekende proxy-gerelateerde fout werd gevonden</translation>
    </message>
    <message>
        <source>An unknown error related to the remote content was detected</source>
        <translation>Een onbekende error gerelateerd tot de remote content werd gevonden</translation>
    </message>
    <message>
        <source>A breakdown in protocol was detected</source>
        <translation>Een storing in het protocol werd gedetecteerd</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Onbekende fout</translation>
    </message>
</context>
<context>
    <name>EventManager</name>
    <message>
        <source>%1/s</source>
        <comment>e.g. 120 KiB/s</comment>
        <translation>%1/s</translation>
    </message>
    <message>
        <source>Working</source>
        <translation>Bezig</translation>
    </message>
    <message>
        <source>Updating...</source>
        <translation>Updating...</translation>
    </message>
    <message>
        <source>Not working</source>
        <translation>Niet bezig</translation>
    </message>
    <message>
        <source>Not contacted yet</source>
        <translation>Nog niet gecontacteerd</translation>
    </message>
    <message>
        <source>this session</source>
        <translation>Deze sessie</translation>
    </message>
    <message>
        <source>/s</source>
        <comment>/second (i.e. per second)</comment>
        <translation>/s</translation>
    </message>
    <message>
        <source>Seeded for %1</source>
        <comment>e.g. Seeded for 3m10s</comment>
        <translation>Geseed voor %1</translation>
    </message>
    <message>
        <source>%1 max</source>
        <comment>e.g. 10 max</comment>
        <translation>%1 max</translation>
    </message>
</context>
<context>
    <name>ExecutionLog</name>
    <message>
        <source>Form</source>
        <translation type="obsolete">Formulier</translation>
    </message>
    <message>
        <source>General</source>
        <translation>Algemeen</translation>
    </message>
    <message>
        <source>Blocked IPs</source>
        <translation>Geblokkeerde IP&apos;s</translation>
    </message>
</context>
<context>
    <name>FeedDownloader</name>
    <message>
        <source>RSS Feed downloader</source>
        <translation type="obsolete">RSS Feed downloader</translation>
    </message>
    <message>
        <source>RSS feed:</source>
        <translation type="obsolete">RSS feed:</translation>
    </message>
    <message>
        <source>Feed name</source>
        <translation type="obsolete">Feed naam</translation>
    </message>
    <message>
        <source>Automatically download torrents from this feed</source>
        <translation type="obsolete">Automatisch torrents downloaden van deze feed</translation>
    </message>
    <message>
        <source>Download filters</source>
        <translation type="obsolete">Download filters</translation>
    </message>
    <message>
        <source>Filters:</source>
        <translation type="obsolete">Filters:</translation>
    </message>
    <message>
        <source>Filter settings</source>
        <translation type="obsolete">Filterinstellingen</translation>
    </message>
    <message>
        <source>Matches:</source>
        <translation type="obsolete">Resultaten:</translation>
    </message>
    <message>
        <source>Does not match:</source>
        <translation type="obsolete">Komt niet overeen:</translation>
    </message>
    <message>
        <source>Destination folder:</source>
        <translation type="obsolete">Doelmap:</translation>
    </message>
    <message>
        <source>...</source>
        <translation type="obsolete">...</translation>
    </message>
    <message>
        <source>Filter testing</source>
        <translation type="obsolete">Filter testen</translation>
    </message>
    <message>
        <source>Torrent title:</source>
        <translation type="obsolete">Torrent titel:</translation>
    </message>
    <message>
        <source>Result:</source>
        <translation type="obsolete">Resultaat:</translation>
    </message>
    <message>
        <source>Test</source>
        <translation type="obsolete">Test</translation>
    </message>
    <message>
        <source>Import...</source>
        <translation type="obsolete">Importeer...</translation>
    </message>
    <message>
        <source>Export...</source>
        <translation type="obsolete">Exporteer...</translation>
    </message>
    <message>
        <source>Rename filter</source>
        <translation type="obsolete">Hernoem filter</translation>
    </message>
    <message>
        <source>Remove filter</source>
        <translation type="obsolete">Verwijder filter</translation>
    </message>
    <message>
        <source>Add filter</source>
        <translation type="obsolete">Voeg filter toe</translation>
    </message>
</context>
<context>
    <name>FeedDownloaderDlg</name>
    <message>
        <source>New filter</source>
        <translation type="obsolete">Nieuwe filter</translation>
    </message>
    <message>
        <source>Please choose a name for this filter</source>
        <translation type="obsolete">Kies alstublieft een naam voor de filter</translation>
    </message>
    <message>
        <source>Filter name:</source>
        <translation type="obsolete">Filternaam:</translation>
    </message>
    <message>
        <source>Invalid filter name</source>
        <translation type="obsolete">Onjuiste filternaam</translation>
    </message>
    <message>
        <source>The filter name cannot be left empty.</source>
        <translation type="obsolete">De filternaam kan niet leeg blijven.</translation>
    </message>
    <message>
        <source>This filter name is already in use.</source>
        <translation type="obsolete">Deze filternaam is al gebruikt.</translation>
    </message>
    <message>
        <source>Filter testing error</source>
        <translation type="obsolete">Filtertest fout</translation>
    </message>
    <message>
        <source>Please specify a test torrent name.</source>
        <translation type="obsolete">Specificeer een testtorrentnaam.</translation>
    </message>
    <message>
        <source>matches</source>
        <translation type="obsolete">resultaten</translation>
    </message>
    <message>
        <source>does not match</source>
        <translation type="obsolete">komt niet overeen</translation>
    </message>
    <message>
        <source>Select file to import</source>
        <translation type="obsolete">Selecteer bestand om te importeren</translation>
    </message>
    <message>
        <source>Filters Files</source>
        <translation type="obsolete">Filtert bestanden</translation>
    </message>
    <message>
        <source>Import successful</source>
        <translation type="obsolete">Importeren gelukt</translation>
    </message>
    <message>
        <source>Filters import was successful.</source>
        <translation type="obsolete">Filters importeren gelukt.</translation>
    </message>
    <message>
        <source>Import failure</source>
        <translation type="obsolete">Fout tijdens importeren</translation>
    </message>
    <message>
        <source>Filters could not be imported due to an I/O error.</source>
        <translation type="obsolete">Filters konden niet worden geïmporteerd door een I/O fout.</translation>
    </message>
    <message>
        <source>Select destination file</source>
        <translation type="obsolete">Selecteer doelbestand</translation>
    </message>
    <message>
        <source>Export successful</source>
        <translation type="obsolete">Exporteren gelukt</translation>
    </message>
    <message>
        <source>Filters export was successful.</source>
        <translation type="obsolete">Filters exporteren gelukt.</translation>
    </message>
    <message>
        <source>Export failure</source>
        <translation type="obsolete">Fout tijdens exporteren</translation>
    </message>
    <message>
        <source>Filters could not be exported due to an I/O error.</source>
        <translation type="obsolete">Filters konden niet worden geëxporteerd door een I/O fout.</translation>
    </message>
    <message>
        <source>Choose save path</source>
        <translation type="obsolete">Kies opslag pad</translation>
    </message>
</context>
<context>
    <name>FeedList</name>
    <message>
        <source>Unread</source>
        <translation type="obsolete">Ongelezen</translation>
    </message>
</context>
<context>
    <name>FeedListWidget</name>
    <message>
        <source>RSS feeds</source>
        <translation>RSS feeds</translation>
    </message>
    <message>
        <source>Unread</source>
        <translation>Ongelezen</translation>
    </message>
</context>
<context>
    <name>GUI</name>
    <message>
        <source>qBittorrent</source>
        <translation type="obsolete">qBittorrent</translation>
    </message>
    <message>
        <source>Open Torrent Files</source>
        <translation type="obsolete">Open Torrent bestanden</translation>
    </message>
    <message>
        <source>Torrent Files</source>
        <translation type="obsolete">Torrent bestanden</translation>
    </message>
    <message>
        <source>Transfers</source>
        <translation type="obsolete">Overdrachten</translation>
    </message>
    <message>
        <source>qBittorrent %1</source>
        <comment>e.g: qBittorrent v0.x</comment>
        <translation type="obsolete">qBittorrent %1</translation>
    </message>
    <message>
        <source>DL speed: %1 KiB/s</source>
        <comment>e.g: Download speed: 10 KiB/s</comment>
        <translation type="obsolete">DL snelheid: %1 KiB/s</translation>
    </message>
    <message>
        <source>UP speed: %1 KiB/s</source>
        <comment>e.g: Upload speed: 10 KiB/s</comment>
        <translation type="obsolete">UP snelheid: %1 KiB/s</translation>
    </message>
    <message>
        <source>%1 has finished downloading.</source>
        <comment>e.g: xxx.avi has finished downloading.</comment>
        <translation type="obsolete">%1 is klaar met downloaden.</translation>
    </message>
    <message>
        <source>I/O Error</source>
        <comment>i.e: Input/Output Error</comment>
        <translation type="obsolete">I/O Fout</translation>
    </message>
    <message>
        <source>Search</source>
        <translation type="obsolete">Zoeken</translation>
    </message>
    <message>
        <source>RSS</source>
        <translation type="obsolete">RSS</translation>
    </message>
    <message>
        <source>Alt+1</source>
        <comment>shortcut to switch to first tab</comment>
        <translation type="obsolete">Alt+1</translation>
    </message>
    <message>
        <source>An I/O error occured for torrent %1.
 Reason: %2</source>
        <comment>e.g: An error occured for torrent xxx.avi.
 Reason: disk is full.</comment>
        <translation type="obsolete">Een I/O fout trad op voor torrent %1. Reden: %2</translation>
    </message>
    <message>
        <source>Url download error</source>
        <translation type="obsolete">Url download fout</translation>
    </message>
    <message>
        <source>Couldn&apos;t download file at url: %1, reason: %2.</source>
        <translation type="obsolete">Kon bestand niet downloaden vanaf url: %1, reden: %2.</translation>
    </message>
    <message>
        <source>Ctrl+F</source>
        <comment>shortcut to switch to search tab</comment>
        <translation type="obsolete">Ctrl+F</translation>
    </message>
    <message>
        <source>Options were saved successfully.</source>
        <translation type="obsolete">Opties zijn succesvol opgeslagen.</translation>
    </message>
    <message>
        <source>Alt+2</source>
        <comment>shortcut to switch to third tab</comment>
        <translation type="obsolete">Alt+2</translation>
    </message>
    <message>
        <source>Alt+3</source>
        <comment>shortcut to switch to fourth tab</comment>
        <translation type="obsolete">Alt+3</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation type="obsolete">Ja</translation>
    </message>
    <message>
        <source>No</source>
        <translation type="obsolete">Nee</translation>
    </message>
    <message>
        <source>Never</source>
        <translation type="obsolete">Nooit</translation>
    </message>
    <message>
        <source>A newer version is available</source>
        <translation type="obsolete">Er is een nieuwere versie beschikbaar</translation>
    </message>
    <message>
        <source>A newer version of qBittorrent is available on Sourceforge.
Would you like to update qBittorrent to version %1?</source>
        <translation type="obsolete">Er is een nieuwere versie van qBittorrent beschikbaar op Sourceforge.
Wil u qBittorrent updaten naar versie %1?</translation>
    </message>
    <message>
        <source>Impossible to update qBittorrent</source>
        <translation type="obsolete">Onmogelijk om qBittorrent up te daten</translation>
    </message>
    <message>
        <source>qBittorrent failed to update, reason: %1</source>
        <translation type="obsolete">qBittorrent slaagde er niet in om up te daten, reason: %1</translation>
    </message>
</context>
<context>
    <name>GeoIP</name>
    <message>
        <source>Australia</source>
        <translation type="obsolete">Australië</translation>
    </message>
    <message>
        <source>Argentina</source>
        <translation type="obsolete">Argentinië</translation>
    </message>
    <message>
        <source>Austria</source>
        <translation type="obsolete">Oostenrijk</translation>
    </message>
    <message>
        <source>United Arab Emirates</source>
        <translation type="obsolete">Verenigde Arabische Emiraten</translation>
    </message>
    <message>
        <source>Brazil</source>
        <translation type="obsolete">Brazilië</translation>
    </message>
    <message>
        <source>Bulgaria</source>
        <translation type="obsolete">Bulgarije</translation>
    </message>
    <message>
        <source>Belarus</source>
        <translation type="obsolete">Wit-Rusland</translation>
    </message>
    <message>
        <source>Belgium</source>
        <translation type="obsolete">België</translation>
    </message>
    <message>
        <source>Bosnia</source>
        <translation type="obsolete">Bosnië</translation>
    </message>
    <message>
        <source>Canada</source>
        <translation type="obsolete">Canada</translation>
    </message>
    <message>
        <source>Czech Republic</source>
        <translation type="obsolete">Tsjechische Republiek</translation>
    </message>
    <message>
        <source>China</source>
        <translation type="obsolete">China</translation>
    </message>
    <message>
        <source>Costa Rica</source>
        <translation type="obsolete">Costa Rica</translation>
    </message>
    <message>
        <source>Switzerland</source>
        <translation type="obsolete">Zwitserland</translation>
    </message>
    <message>
        <source>Germany</source>
        <translation type="obsolete">Duitsland</translation>
    </message>
    <message>
        <source>Denmark</source>
        <translation type="obsolete">Denemarken</translation>
    </message>
    <message>
        <source>Algeria</source>
        <translation type="obsolete">Algerije</translation>
    </message>
    <message>
        <source>Spain</source>
        <translation type="obsolete">Spanje</translation>
    </message>
    <message>
        <source>Egypt</source>
        <translation type="obsolete">Egypte</translation>
    </message>
    <message>
        <source>Finland</source>
        <translation type="obsolete">Finland</translation>
    </message>
    <message>
        <source>France</source>
        <translation type="obsolete">Frankrijk</translation>
    </message>
    <message>
        <source>United Kingdom</source>
        <translation type="obsolete">Verenigd Koninkrijk</translation>
    </message>
    <message>
        <source>Greece</source>
        <translation type="obsolete">Griekenland</translation>
    </message>
    <message>
        <source>Georgia</source>
        <translation type="obsolete">Georgië</translation>
    </message>
    <message>
        <source>Hungary</source>
        <translation type="obsolete">Hongarije</translation>
    </message>
    <message>
        <source>Croatia</source>
        <translation type="obsolete">Kroatië</translation>
    </message>
    <message>
        <source>Italy</source>
        <translation type="obsolete">Italië</translation>
    </message>
    <message>
        <source>India</source>
        <translation type="obsolete">India</translation>
    </message>
    <message>
        <source>Israel</source>
        <translation type="obsolete">Israël</translation>
    </message>
    <message>
        <source>Ireland</source>
        <translation type="obsolete">Ierland</translation>
    </message>
    <message>
        <source>Iceland</source>
        <translation type="obsolete">Ijsland</translation>
    </message>
    <message>
        <source>Indonesia</source>
        <translation type="obsolete">Indonesië</translation>
    </message>
    <message>
        <source>Japan</source>
        <translation type="obsolete">Japan</translation>
    </message>
    <message>
        <source>South Korea</source>
        <translation type="obsolete">Zuid-Korea</translation>
    </message>
    <message>
        <source>Luxembourg</source>
        <translation type="obsolete">Luxemburg</translation>
    </message>
    <message>
        <source>Mexico</source>
        <translation type="obsolete">Mexico</translation>
    </message>
    <message>
        <source>Netherlands</source>
        <translation type="obsolete">Nederland</translation>
    </message>
    <message>
        <source>Norway</source>
        <translation type="obsolete">Noorwegen</translation>
    </message>
    <message>
        <source>New Zealand</source>
        <translation type="obsolete">Nieuw-Zeeland</translation>
    </message>
    <message>
        <source>Portugal</source>
        <translation type="obsolete">Portugal</translation>
    </message>
    <message>
        <source>Poland</source>
        <translation type="obsolete">Polen</translation>
    </message>
    <message>
        <source>Pakistan</source>
        <translation type="obsolete">Pakistan</translation>
    </message>
    <message>
        <source>Russia</source>
        <translation type="obsolete">Rusland</translation>
    </message>
    <message>
        <source>Sweden</source>
        <translation type="obsolete">Zweden</translation>
    </message>
    <message>
        <source>Slovakia</source>
        <translation type="obsolete">Slovakije</translation>
    </message>
    <message>
        <source>Singapore</source>
        <translation type="obsolete">Singapore</translation>
    </message>
    <message>
        <source>Slovenia</source>
        <translation type="obsolete">Slovenië</translation>
    </message>
    <message>
        <source>Taiwan</source>
        <translation type="obsolete">Taiwan</translation>
    </message>
    <message>
        <source>Turkey</source>
        <translation type="obsolete">Turkije</translation>
    </message>
    <message>
        <source>Thailand</source>
        <translation type="obsolete">Thailand</translation>
    </message>
    <message>
        <source>USA</source>
        <translation type="obsolete">VSA</translation>
    </message>
    <message>
        <source>Ukraine</source>
        <translation type="obsolete">Oekraine</translation>
    </message>
    <message>
        <source>South Africa</source>
        <translation type="obsolete">Zuid-Afrika</translation>
    </message>
    <message>
        <source>Saudi Arabia</source>
        <translation type="obsolete">Saudi-Arabië</translation>
    </message>
</context>
<context>
    <name>HeadlessLoader</name>
    <message>
        <source>Information</source>
        <translation>Informatie</translation>
    </message>
    <message>
        <source>To control qBittorrent, access the Web UI at http://localhost:%1</source>
        <translation>Om qBittorrent te besturen, gebruik de Web UI op http://localhost:%1</translation>
    </message>
    <message>
        <source>The Web UI administrator user name is: %1</source>
        <translation>De Web UI administrator gebruikersnaam is: %1</translation>
    </message>
    <message>
        <source>The Web UI administrator password is still the default one: %1</source>
        <translation>Het Web UI administrator paswoord is still nog steeds het standaard: %1</translation>
    </message>
    <message>
        <source>This is a security risk, please consider changing your password from program preferences.</source>
        <translation>Dit is een beveiligingsrisico, gelieve te overwegen om u paswoord aan te passen via programmavoorkeuren.</translation>
    </message>
</context>
<context>
    <name>HttpConnection</name>
    <message>
        <source>Your IP address has been banned after too many failed authentication attempts.</source>
        <translation>U IP-adres is geband na te veel mislukte autorisatiepogingen.</translation>
    </message>
    <message>
        <source>D: %1/s - T: %2</source>
        <comment>Download speed: x KiB/s - Transferred: x MiB</comment>
        <translation>D: %1/s - O: %2</translation>
    </message>
    <message>
        <source>U: %1/s - T: %2</source>
        <comment>Upload speed: x KiB/s - Transferred: x MiB</comment>
        <translation>U: %1/s - O: %2</translation>
    </message>
</context>
<context>
    <name>HttpServer</name>
    <message>
        <source>File</source>
        <translation>Bestand</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Bewerk</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Help</translation>
    </message>
    <message>
        <source>Delete from HD</source>
        <translation type="obsolete">Verwijder van HD</translation>
    </message>
    <message>
        <source>Download Torrents from their URL or Magnet link</source>
        <translation>Download Torrent van hun URL of Magnet link</translation>
    </message>
    <message>
        <source>Only one link per line</source>
        <translation>Slechts ééen link per lijn</translation>
    </message>
    <message>
        <source>Download</source>
        <translation>Download</translation>
    </message>
    <message>
        <source>Download local torrent</source>
        <translation>Download lokale torrent</translation>
    </message>
    <message>
        <source>Torrent files were correctly added to download list.</source>
        <translation>Torrentbestanden werden correct toegevoegd aan de downloadlijst.</translation>
    </message>
    <message>
        <source>Point to torrent file</source>
        <translation>Wijst naar torrentbestand</translation>
    </message>
    <message>
        <source>Are you sure you want to delete the selected torrents from the transfer list and hard disk?</source>
        <translation>Bent u zeker dat u de geselecteerde torrents wilt verwijderen van de overdrachtenlijst en harde schijf?</translation>
    </message>
    <message>
        <source>Download rate limit must be greater than 0 or disabled.</source>
        <translation>Downloadsnelheidslimiet moet groter zijn dan 0 of uitgeschakeld.</translation>
    </message>
    <message>
        <source>Upload rate limit must be greater than 0 or disabled.</source>
        <translation>Uploadsnelheidslimiet moet groter zijn dan 0 of uitgeschakeld.</translation>
    </message>
    <message>
        <source>Maximum number of connections limit must be greater than 0 or disabled.</source>
        <translation>Maximum aantal verbindingen limiet moet groter zijn dan 0 of uitgeschakeld.</translation>
    </message>
    <message>
        <source>Maximum number of connections per torrent limit must be greater than 0 or disabled.</source>
        <translation>Maximum aantal verbindingen per torrentlimiet moet groter zijn dan 0 of uitgeschakeld.</translation>
    </message>
    <message>
        <source>Maximum number of upload slots per torrent limit must be greater than 0 or disabled.</source>
        <translation>Maximum aantal uploadslots per torrent limiet moet groter zijn dan 0 of uigeschakeld.</translation>
    </message>
    <message>
        <source>Unable to save program preferences, qBittorrent is probably unreachable.</source>
        <translation>Onmogelijk om programmavoorkeuren op te slaan, qBittorrent is waarschijnlijk onbereikbaar.</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Taal</translation>
    </message>
    <message>
        <source>The port used for incoming connections must be greater than 1024 and less than 65535.</source>
        <translation>De poort gebruikt voor inkomende verbindingen moet groter zijn dan 1024 en kleiner dan 65535.</translation>
    </message>
    <message>
        <source>The port used for the Web UI must be greater than 1024 and less than 65535.</source>
        <translation>De poort gebruikt voor de Web UI moet groter zijn dan 1024 en kleiner dan 65535.</translation>
    </message>
    <message>
        <source>The Web UI username must be at least 3 characters long.</source>
        <translation>De Web UI-gebruikersnaam moet minstens 3 characters lang zijn.</translation>
    </message>
    <message>
        <source>The Web UI password must be at least 3 characters long.</source>
        <translation>Het Web UI-paswoord moet minstens 3 characters lang zijn.</translation>
    </message>
    <message>
        <source>Downloaded</source>
        <comment>Is the file downloaded or not?</comment>
        <translation>Gedownload</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Sla op</translation>
    </message>
    <message>
        <source>qBittorrent client is not reachable</source>
        <translation>qBittorrent client is niet bereikbaar</translation>
    </message>
    <message>
        <source>HTTP Server</source>
        <translation>HTTP Server</translation>
    </message>
    <message>
        <source>Torrent path</source>
        <translation>Torrent pad</translation>
    </message>
    <message>
        <source>Torrent name</source>
        <translation>Torrent naam</translation>
    </message>
    <message>
        <source>The following parameters are supported:</source>
        <translation>De volgende parameters worden ondersteund:</translation>
    </message>
</context>
<context>
    <name>LegalNotice</name>
    <message>
        <source>Legal Notice</source>
        <translation>Juridische mededeling</translation>
    </message>
    <message>
        <source>Legal notice</source>
        <translation>Juridische mededeling</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Annuleren</translation>
    </message>
    <message>
        <source>I Agree</source>
        <translation>Ik ga akkoord</translation>
    </message>
    <message>
        <source>qBittorrent is a file sharing program. When you run a torrent, its data will be made available to others by means of upload. Any content you share is your sole responsibility.

No further notices will be issued.</source>
        <translation>qBittorrent is een bestanddelingsprogramma. Als u een torrent gebruikt zal zijn data beschikbaar worden gesteld voor anderen door het te uploaden. Elke inhoud die je sharet is alleen jouw verantwoordelijkheid.</translation>
    </message>
    <message>
        <source>Press %1 key to accept and continue...</source>
        <translation>Druk op de %1 toets om te accepteren en verder te gaan...</translation>
    </message>
</context>
<context>
    <name>LineEdit</name>
    <message>
        <source>Clear the text</source>
        <translation>Verwijder de tekst</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Bestand</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Help</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>&amp;Bewerken</translation>
    </message>
    <message>
        <source>Preview file</source>
        <translation type="obsolete">Kijk vooruit op bestand</translation>
    </message>
    <message>
        <source>Clear log</source>
        <translation type="obsolete">Wist log</translation>
    </message>
    <message>
        <source>Decrease priority</source>
        <translation>Prioriteit verlagen</translation>
    </message>
    <message>
        <source>Increase priority</source>
        <translation>Prioriteit verhogen</translation>
    </message>
    <message>
        <source>&amp;Tools</source>
        <translation>&amp;Tools</translation>
    </message>
    <message>
        <source>&amp;View</source>
        <translation>&amp;Weergave</translation>
    </message>
    <message>
        <source>&amp;Add File...</source>
        <translation type="obsolete">&amp;Voeg Bestand toe...</translation>
    </message>
    <message>
        <source>&amp;Options...</source>
        <translation>&amp;Opties...</translation>
    </message>
    <message>
        <source>Add &amp;URL...</source>
        <translation type="obsolete">Voeg &amp;URL toe...</translation>
    </message>
    <message>
        <source>Torrent &amp;creator</source>
        <translation>Torrent &amp;creator</translation>
    </message>
    <message>
        <source>Set upload limit...</source>
        <translation>Stel uploadlimiet in...</translation>
    </message>
    <message>
        <source>Set download limit...</source>
        <translation>stel downloadlimiet in...</translation>
    </message>
    <message>
        <source>Set global download limit...</source>
        <translation>Stel globale downloadlimiet in...</translation>
    </message>
    <message>
        <source>Set global upload limit...</source>
        <translation>Stel globale uploadlimiet in...</translation>
    </message>
    <message>
        <source>&amp;Log viewer...</source>
        <translation type="obsolete">&amp;Log viewer...</translation>
    </message>
    <message>
        <source>Top &amp;tool bar</source>
        <translation>Bovenste &amp;werkbalk</translation>
    </message>
    <message>
        <source>Display top tool bar</source>
        <translation>Toon bovenste werkbalk</translation>
    </message>
    <message>
        <source>&amp;Speed in title bar</source>
        <translation>&amp;Snelheid in titelbalk</translation>
    </message>
    <message>
        <source>Show transfer speed in title bar</source>
        <translation>Toon overdrachtsnelheid in titelbar</translation>
    </message>
    <message>
        <source>Alternative speed limits</source>
        <translation>Alternative snelheidslimieten</translation>
    </message>
    <message>
        <source>&amp;About</source>
        <translation>&amp;Over</translation>
    </message>
    <message>
        <source>&amp;Pause</source>
        <translation>&amp;Pauzeer</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>&amp;Verwijder</translation>
    </message>
    <message>
        <source>P&amp;ause All</source>
        <translation>P&amp;auzeer alles</translation>
    </message>
    <message>
        <source>Visit &amp;Website</source>
        <translation>Bezoek de &amp;Website</translation>
    </message>
    <message>
        <source>Report a &amp;bug</source>
        <translation>Rapporteer een &amp;bug</translation>
    </message>
    <message>
        <source>&amp;Documentation</source>
        <translation>&amp;Documentatie</translation>
    </message>
    <message>
        <source>&amp;RSS reader</source>
        <translation>&amp;RSS reader</translation>
    </message>
    <message>
        <source>Search &amp;engine</source>
        <translation>Zoek &amp;machine</translation>
    </message>
    <message>
        <source>Log viewer</source>
        <translation type="obsolete">Log viewer</translation>
    </message>
    <message>
        <source>Lock qBittorrent</source>
        <translation>Vergrendel qBittorrent</translation>
    </message>
    <message>
        <source>Ctrl+L</source>
        <translation>Ctrl+L</translation>
    </message>
    <message>
        <source>Shutdown computer when downloads complete</source>
        <translation type="obsolete">Sluit de computer af wanneer de downloads voltooid zijn</translation>
    </message>
    <message>
        <source>&amp;Resume</source>
        <translation>&amp;Herneem</translation>
    </message>
    <message>
        <source>R&amp;esume All</source>
        <translation>H&amp;erneem alles</translation>
    </message>
    <message>
        <source>Shutdown qBittorrent when downloads complete</source>
        <translation type="obsolete">Sluit qBittorrent af wanneer de downloads voltooid zijn</translation>
    </message>
    <message>
        <source>Exit</source>
        <translation>Afsluiten</translation>
    </message>
    <message>
        <source>Import torrent...</source>
        <translation>Importeer torrent...</translation>
    </message>
    <message>
        <source>Donate money</source>
        <translation>Doneer geld</translation>
    </message>
    <message>
        <source>If you like qBittorrent, please donate!</source>
        <translation>Als u qBittorrent goed vindt, gelieve te doneren!</translation>
    </message>
    <message>
        <source>qBittorrent %1</source>
        <comment>e.g: qBittorrent v0.x</comment>
        <translation>qBittorrent %1</translation>
    </message>
    <message>
        <source>Set the password...</source>
        <translation>Stel paswoord in...</translation>
    </message>
    <message>
        <source>Transfers</source>
        <translation>Overdrachten</translation>
    </message>
    <message>
        <source>Torrent file association</source>
        <translation>Torrentbestand associatie</translation>
    </message>
    <message>
        <source>qBittorrent is not the default application to open torrent files or Magnet links.
Do you want to associate qBittorrent to torrent files and Magnet links?</source>
        <translation>qBittorrent is niet het standaardprogramma om torrentbestanden of Magnetlinks te openen.
Wilt u qBittorrent associëren met torrentbestanden en Magnetlinks?</translation>
    </message>
    <message>
        <source>UI lock password</source>
        <translation>UI lock paswoord</translation>
    </message>
    <message>
        <source>Please type the UI lock password:</source>
        <translation>Gelieve het UI lock paswoord op te geven:</translation>
    </message>
    <message>
        <source>Password update</source>
        <translation>Paswoord update</translation>
    </message>
    <message>
        <source>The UI lock password has been successfully updated</source>
        <translation>Het UI lock paswoord is succesvol geupdated</translation>
    </message>
    <message>
        <source>RSS</source>
        <translation>RSS</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Zoeken</translation>
    </message>
    <message>
        <source>Transfers (%1)</source>
        <translation>Overdrachten (%1)</translation>
    </message>
    <message>
        <source>Download completion</source>
        <translation>Download voltooid</translation>
    </message>
    <message>
        <source>%1 has finished downloading.</source>
        <comment>e.g: xxx.avi has finished downloading.</comment>
        <translation>%1 is klaar met downloaden.</translation>
    </message>
    <message>
        <source>I/O Error</source>
        <comment>i.e: Input/Output Error</comment>
        <translation>I/O Fout</translation>
    </message>
    <message>
        <source>An I/O error occured for torrent %1.
 Reason: %2</source>
        <comment>e.g: An error occured for torrent xxx.avi.
 Reason: disk is full.</comment>
        <translation>Een I/O fout trad op voor torrent %1. Reden: %2</translation>
    </message>
    <message>
        <source>Alt+1</source>
        <comment>shortcut to switch to first tab</comment>
        <translation>Alt+1</translation>
    </message>
    <message>
        <source>Alt+2</source>
        <comment>shortcut to switch to third tab</comment>
        <translation>Alt+2</translation>
    </message>
    <message>
        <source>Ctrl+F</source>
        <comment>shortcut to switch to search tab</comment>
        <translation>Ctrl+F</translation>
    </message>
    <message>
        <source>Alt+3</source>
        <comment>shortcut to switch to fourth tab</comment>
        <translation>Alt+3</translation>
    </message>
    <message>
        <source>Recursive download confirmation</source>
        <translation>Recursieve donwloadbevestiging</translation>
    </message>
    <message>
        <source>The torrent %1 contains torrent files, do you want to proceed with their download?</source>
        <translation>De torrent %1 bevat torrentbestanden, wilt u verdergaan met hun download?</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Nee</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Nooit</translation>
    </message>
    <message>
        <source>Url download error</source>
        <translation>Url download fout</translation>
    </message>
    <message>
        <source>Couldn&apos;t download file at url: %1, reason: %2.</source>
        <translation>Kon bestand niet downloaden vanaf url: %1, reden: %2.</translation>
    </message>
    <message>
        <source>Global Upload Speed Limit</source>
        <translation>Globale uploadsnelheidslimiet</translation>
    </message>
    <message>
        <source>Global Download Speed Limit</source>
        <translation>Globale downloadsnelheidslimiet</translation>
    </message>
    <message>
        <source>Invalid password</source>
        <translation>Ongeldig paswoord</translation>
    </message>
    <message>
        <source>The password is invalid</source>
        <translation>Het paswoord is ongeldig</translation>
    </message>
    <message>
        <source>Exiting qBittorrent</source>
        <translation>qBittorrent wordt afgesloten</translation>
    </message>
    <message>
        <source>Some files are currently transferring.
Are you sure you want to quit qBittorrent?</source>
        <translation>Sommige bestanden worden momenteel overgedragen.
Weet u zeker dat u qBittorrent wilt afsluiten?</translation>
    </message>
    <message>
        <source>Always</source>
        <translation>Altijd</translation>
    </message>
    <message>
        <source>Open Torrent Files</source>
        <translation>Open Torrent bestanden</translation>
    </message>
    <message>
        <source>Torrent Files</source>
        <translation>Torrent bestanden</translation>
    </message>
    <message>
        <source>Options were saved successfully.</source>
        <translation>Opties zijn succesvol opgeslagen.</translation>
    </message>
    <message>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <source>DL speed: %1 KiB/s</source>
        <comment>e.g: Download speed: 10 KiB/s</comment>
        <translation>DL snelheid: %1 KiB/s</translation>
    </message>
    <message>
        <source>UP speed: %1 KiB/s</source>
        <comment>e.g: Upload speed: 10 KiB/s</comment>
        <translation>UP snelheid: %1 KiB/s</translation>
    </message>
    <message>
        <source>qBittorrent %1 (Down: %2/s, Up: %3/s)</source>
        <comment>%1 is qBittorrent version</comment>
        <translation>qBittorrent %1 (Down: %2/s, Up: %3/s)</translation>
    </message>
    <message>
        <source>A newer version is available</source>
        <translation>Er is een nieuwere versie beschikbaar</translation>
    </message>
    <message>
        <source>A newer version of qBittorrent is available on Sourceforge.
Would you like to update qBittorrent to version %1?</source>
        <translation>Er is een nieuwere versie van qBittorrent beschikbaar op Sourceforge.
Wil u qBittorrent updaten naar versie %1?</translation>
    </message>
    <message>
        <source>Impossible to update qBittorrent</source>
        <translation>Onmogelijk om qBittorrent up te daten</translation>
    </message>
    <message>
        <source>qBittorrent failed to update, reason: %1</source>
        <translation>qBittorrent slaagde er niet in om up te daten, reason: %1</translation>
    </message>
    <message>
        <source>&amp;Add torrent file...</source>
        <translation>&amp;Voeg torrent bestand toe...</translation>
    </message>
    <message>
        <source>Add &amp;link to torrent...</source>
        <translation>Voeg &amp;link toe aan torrent...</translation>
    </message>
    <message>
        <source>Import existing torrent...</source>
        <translation>Importeer bestaande torrent...</translation>
    </message>
    <message>
        <source>Execution &amp;Log</source>
        <translation>Uitvoerings&amp;log</translation>
    </message>
    <message>
        <source>Execution Log</source>
        <translation>Uitvoeringslog</translation>
    </message>
    <message>
        <source>Auto-Shutdown on downloads completion</source>
        <translation>Autmatisch aflsuiten als de downloads volledig zijn</translation>
    </message>
    <message>
        <source>Exit qBittorrent</source>
        <translation>Sluit qBittorrent</translation>
    </message>
    <message>
        <source>Suspend system</source>
        <translation>Schors systeem</translation>
    </message>
    <message>
        <source>Shutdown system</source>
        <translation>Sluit het systeem af</translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Uitgeschakeld</translation>
    </message>
    <message>
        <source>The password should contain at least 3 characters</source>
        <translation>Het wachtwoord moet minstens 3 tekens bevatten</translation>
    </message>
</context>
<context>
    <name>PeerAdditionDlg</name>
    <message>
        <source>Invalid IP</source>
        <translation>Ongeldig IP</translation>
    </message>
    <message>
        <source>The IP you provided is invalid.</source>
        <translation>Het gegeven IP is ongeldig.</translation>
    </message>
</context>
<context>
    <name>PeerListDelegate</name>
    <message>
        <source>/s</source>
        <comment>/second (i.e. per second)</comment>
        <translation>/s</translation>
    </message>
</context>
<context>
    <name>PeerListWidget</name>
    <message>
        <source>IP</source>
        <translation>IP</translation>
    </message>
    <message>
        <source>Client</source>
        <comment>i.e.: Client application</comment>
        <translation>Client</translation>
    </message>
    <message>
        <source>Progress</source>
        <comment>i.e: % downloaded</comment>
        <translation>Voortgang</translation>
    </message>
    <message>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Down-snelheid</translation>
    </message>
    <message>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Up-snelheid</translation>
    </message>
    <message>
        <source>Downloaded</source>
        <comment>i.e: total data downloaded</comment>
        <translation>Gedownload</translation>
    </message>
    <message>
        <source>Uploaded</source>
        <comment>i.e: total data uploaded</comment>
        <translation>Geupload</translation>
    </message>
    <message>
        <source>Ban peer permanently</source>
        <translation>Peer permanent verbannen</translation>
    </message>
    <message>
        <source>Peer addition</source>
        <translation>Peer toevoeging</translation>
    </message>
    <message>
        <source>The peer was added to this torrent.</source>
        <translation>De peer werd toegevoegd aan de torrent.</translation>
    </message>
    <message>
        <source>The peer could not be added to this torrent.</source>
        <translation>De peer kon niet toegevoegd worden aan deze torrent.</translation>
    </message>
    <message>
        <source>Are you sure? -- qBittorrent</source>
        <translation>Weet u het zeker? -- qBittorrent</translation>
    </message>
    <message>
        <source>Are you sure you want to ban permanently the selected peers?</source>
        <translation>Bent u zeker dat u de geselecteerd peer permanent wilt verbannen?</translation>
    </message>
    <message>
        <source>&amp;Yes</source>
        <translation>&amp;Ja</translation>
    </message>
    <message>
        <source>&amp;No</source>
        <translation>&amp;Nee</translation>
    </message>
    <message>
        <source>Manually banning peer %1...</source>
        <translation>Peer %1 wordt manueel verbannen...</translation>
    </message>
    <message>
        <source>Upload rate limiting</source>
        <translation>Uploadsnelheid limieteren</translation>
    </message>
    <message>
        <source>Download rate limiting</source>
        <translation>Downloadsnelheid limieteren</translation>
    </message>
    <message>
        <source>Add a new peer...</source>
        <translation>Voeg nieuwe peer toe...</translation>
    </message>
    <message>
        <source>Limit download rate...</source>
        <translation>Limieteer downloadsnelheid...</translation>
    </message>
    <message>
        <source>Limit upload rate...</source>
        <translation>Limieteer uploadsnelheid...</translation>
    </message>
    <message>
        <source>Copy IP</source>
        <translation>Kopiëer IP</translation>
    </message>
    <message>
        <source>Connection</source>
        <translation>Verbinding</translation>
    </message>
</context>
<context>
    <name>Preferences</name>
    <message>
        <source>UI</source>
        <extracomment>User Interface</extracomment>
        <translation type="obsolete">UI</translation>
    </message>
    <message>
        <source>Downloads</source>
        <translation>Downloads</translation>
    </message>
    <message>
        <source>Connection</source>
        <translation>Verbinding</translation>
    </message>
    <message>
        <source>Bittorrent</source>
        <translation type="obsolete">Bittorrent</translation>
    </message>
    <message>
        <source>Proxy</source>
        <translation type="obsolete">Proxy</translation>
    </message>
    <message>
        <source>Web UI</source>
        <translation>Web UI</translation>
    </message>
    <message>
        <source>Language:</source>
        <translation type="obsolete">Taal:</translation>
    </message>
    <message>
        <source>(Requires restart)</source>
        <translation>(herstart vereist)</translation>
    </message>
    <message>
        <source>Visual style:</source>
        <translation type="obsolete">Visuele stijl:</translation>
    </message>
    <message>
        <source>Transfer list</source>
        <translation type="obsolete">Overdrachtenlijst</translation>
    </message>
    <message>
        <source>Use alternating row colors</source>
        <extracomment>In transfer list, one every two rows will have grey background.</extracomment>
        <translation>Gebruik alternatieve rijkleuren</translation>
    </message>
    <message>
        <source>File system</source>
        <translation type="obsolete">Bestandssysteem</translation>
    </message>
    <message>
        <source>Torrent queueing</source>
        <translation type="obsolete">Torrent wachtrij</translation>
    </message>
    <message>
        <source>Maximum active downloads:</source>
        <translation>Maximum actieve downloads:</translation>
    </message>
    <message>
        <source>Maximum active uploads:</source>
        <translation>Maximum actieve uploads:</translation>
    </message>
    <message>
        <source>Maximum active torrents:</source>
        <translation>Maximum actieve torrents:</translation>
    </message>
    <message>
        <source>When adding a torrent</source>
        <translation>Tijdens torrent toevoegen</translation>
    </message>
    <message>
        <source>Display torrent content and some options</source>
        <translation>Torrentinhoud en enkele opties weergeven</translation>
    </message>
    <message>
        <source>Listening port</source>
        <translation type="obsolete">Luisterpoort</translation>
    </message>
    <message>
        <source>Port used for incoming connections:</source>
        <translation>Poort voor inkomende verbindingen:</translation>
    </message>
    <message>
        <source>Random</source>
        <translation>Willekeurig</translation>
    </message>
    <message>
        <source>Enable UPnP port mapping</source>
        <translation type="obsolete">UPnP port mapping inschakelen</translation>
    </message>
    <message>
        <source>Enable NAT-PMP port mapping</source>
        <translation type="obsolete">NAT-PMP port mapping inschakelen</translation>
    </message>
    <message>
        <source>Connections limit</source>
        <translation type="obsolete">Verbindingslimiet</translation>
    </message>
    <message>
        <source>Global maximum number of connections:</source>
        <translation>Globale verbindingslimiet:</translation>
    </message>
    <message>
        <source>Maximum number of connections per torrent:</source>
        <translation>Verbindingslimiet per torrent:</translation>
    </message>
    <message>
        <source>Maximum number of upload slots per torrent:</source>
        <translation>Maximum aantal uploads per torrent:</translation>
    </message>
    <message>
        <source>Upload:</source>
        <translation>Upload:</translation>
    </message>
    <message>
        <source>Download:</source>
        <translation>Download:</translation>
    </message>
    <message>
        <source>KiB/s</source>
        <translation>KiB/s</translation>
    </message>
    <message>
        <source>Bittorrent features</source>
        <translation type="obsolete">Bittorrent features</translation>
    </message>
    <message>
        <source>Enable DHT network (decentralized)</source>
        <translation type="obsolete">DHT (gedecentraliseerd) netwerk inschakelen</translation>
    </message>
    <message>
        <source>Use a different port for DHT and Bittorrent</source>
        <translation type="obsolete">Gebruik een andere poort voor DHT en Bittorrent</translation>
    </message>
    <message>
        <source>DHT port:</source>
        <translation>DHT poort:</translation>
    </message>
    <message>
        <source>Enable Peer Exchange / PeX (requires restart)</source>
        <translation type="obsolete">Schakel Peer Exchange in / PeX (herstart vereist)</translation>
    </message>
    <message>
        <source>Enable Local Peer Discovery</source>
        <translation type="obsolete">Local Peer Discovery inschakelen</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation type="obsolete">Ingeschakeld</translation>
    </message>
    <message>
        <source>Forced</source>
        <translation type="obsolete">Geforceerd</translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation type="obsolete">Uitgeschakeld</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation>Type:</translation>
    </message>
    <message>
        <source>(None)</source>
        <translation>(Geen)</translation>
    </message>
    <message>
        <source>HTTP</source>
        <translation>HTTP</translation>
    </message>
    <message>
        <source>Port:</source>
        <translation>Poort:</translation>
    </message>
    <message>
        <source>Authentication</source>
        <translation>Authenticatie</translation>
    </message>
    <message>
        <source>Username:</source>
        <translation>Gebruikersnaam:</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation>Paswoord:</translation>
    </message>
    <message>
        <source>SOCKS5</source>
        <translation>SOCKS5</translation>
    </message>
    <message>
        <source>HTTP Server</source>
        <translation type="obsolete">HTTP Server</translation>
    </message>
    <message>
        <source>Filter path (.dat, .p2p, .p2b):</source>
        <translation>Filter pad (.dat, p2p, p2b):</translation>
    </message>
    <message>
        <source>HTTP Communications (trackers, Web seeds, search engine)</source>
        <translation type="obsolete">HTTP Communicaties (trackers, Web seeds, zoekmachine)</translation>
    </message>
    <message>
        <source>Host:</source>
        <translation>Host:</translation>
    </message>
    <message>
        <source>Peer Communications</source>
        <translation type="obsolete">Peer communicaties</translation>
    </message>
    <message>
        <source>SOCKS4</source>
        <translation>SOCKS4</translation>
    </message>
    <message>
        <source>Speed</source>
        <translation>Snelheid</translation>
    </message>
    <message>
        <source>Global speed limits</source>
        <translation type="obsolete">Globale snelheidslimieten</translation>
    </message>
    <message>
        <source>Alternative global speed limits</source>
        <translation type="obsolete">Alternatieve globale snelheidslimieten</translation>
    </message>
    <message>
        <source>to</source>
        <extracomment>time1 to time2</extracomment>
        <translation>tot</translation>
    </message>
    <message>
        <source>Every day</source>
        <translation>Elke dag</translation>
    </message>
    <message>
        <source>Week days</source>
        <translation>Weekdagen</translation>
    </message>
    <message>
        <source>Week ends</source>
        <translation>Weekenden</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Geavanceerd</translation>
    </message>
    <message>
        <source>Copy .torrent files to:</source>
        <translation>Kopieer .torrentbestanden naar:</translation>
    </message>
    <message>
        <source>Remove folder</source>
        <translation>Verwijder map</translation>
    </message>
    <message>
        <source>No action</source>
        <translation>Geen actie</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>Instellingen</translation>
    </message>
    <message>
        <source>Visual Appearance</source>
        <translation type="obsolete">Visuele stijl</translation>
    </message>
    <message>
        <source>Action on double-click</source>
        <translation>Actie bij dubbel-klikken</translation>
    </message>
    <message>
        <source>Downloading torrents:</source>
        <translation>Download torrents:</translation>
    </message>
    <message>
        <source>Start / Stop</source>
        <translation type="obsolete">Start / Stop</translation>
    </message>
    <message>
        <source>Open destination folder</source>
        <translation>Open doel map</translation>
    </message>
    <message>
        <source>Completed torrents:</source>
        <translation>Voltooide torrents:</translation>
    </message>
    <message>
        <source>Desktop</source>
        <translation>Bureaublad</translation>
    </message>
    <message>
        <source>Show splash screen on start up</source>
        <translation>Toon splash screen bij het opstarten</translation>
    </message>
    <message>
        <source>Start qBittorrent minimized</source>
        <translation>Start qBittorrent geminimaliseerd</translation>
    </message>
    <message>
        <source>Show qBittorrent icon in notification area</source>
        <translation type="obsolete">Toon qBittorrenpictogram in notificatie ruimte</translation>
    </message>
    <message>
        <source>Minimize qBittorrent to notification area</source>
        <translation>Miminalizeer qBittorrent naar de notificatie ruimte</translation>
    </message>
    <message>
        <source>Close qBittorrent to notification area</source>
        <comment>i.e: The systray tray icon will still be visible when closing the main window.</comment>
        <translation>Sluit qBittorrent naar de notificatie ruimte</translation>
    </message>
    <message>
        <source>Do not start the download automatically</source>
        <comment>The torrent will be added to download list in pause state</comment>
        <translation>Start the download niet automatisch</translation>
    </message>
    <message>
        <source>Save files to location:</source>
        <translation>Sla bestanden op op locatie:</translation>
    </message>
    <message>
        <source>Append the label of the torrent to the save path</source>
        <translation>Voeg het label toe aan het opslag pad van de torrent</translation>
    </message>
    <message>
        <source>Pre-allocate disk space for all files</source>
        <translation>Pre-allocate schijfruimte voor alle bestanden</translation>
    </message>
    <message>
        <source>Keep incomplete torrents in:</source>
        <translation>Bewaar onvoltooide torrent in:</translation>
    </message>
    <message>
        <source>Append .!qB extension to incomplete files&apos; names</source>
        <translation type="obsolete">Voeg de .!qB-extensie toe aan onvoltooide bestanden hun namen</translation>
    </message>
    <message>
        <source>Automatically add torrents from:</source>
        <translation>Voeg automatisch torrents toe van:</translation>
    </message>
    <message>
        <source>Add folder...</source>
        <translation>Voeg map toe...</translation>
    </message>
    <message>
        <source>IP Filtering</source>
        <translation>IP Filtering</translation>
    </message>
    <message>
        <source>Schedule the use of alternative speed limits</source>
        <translation type="obsolete">Plan het gebruik van alternatieve snelheidslimieten</translation>
    </message>
    <message>
        <source>from</source>
        <extracomment>from (time1 to time2)</extracomment>
        <translation>van</translation>
    </message>
    <message>
        <source>When:</source>
        <translation>Wanneer:</translation>
    </message>
    <message>
        <source>Look for peers on your local network</source>
        <translation>Zoek naar peers in u lokaal netwerk</translation>
    </message>
    <message>
        <source>Protocol encryption:</source>
        <translation type="obsolete">Protocol encryptie:</translation>
    </message>
    <message>
        <source>Enable Web User Interface (Remote control)</source>
        <translation>Schakel Webuserinterface in (Remote control)</translation>
    </message>
    <message>
        <source>Share ratio limiting</source>
        <translation type="obsolete">Deelverhouding limieteren</translation>
    </message>
    <message>
        <source>Seed torrents until their ratio reaches</source>
        <translation>Seed torrents totdat hun verhouding bereikt is</translation>
    </message>
    <message>
        <source>then</source>
        <translation>dan</translation>
    </message>
    <message>
        <source>Pause them</source>
        <translation>Pauseer hen</translation>
    </message>
    <message>
        <source>Remove them</source>
        <translation>Verwijder hen</translation>
    </message>
    <message utf8="true">
        <source>Exchange peers with compatible Bittorrent clients (µTorrent, Vuze, ...)</source>
        <translation>Wissel peers uit met compatibele Bittorrent clients (µTorrent, Vuze, ...)</translation>
    </message>
    <message>
        <source>Email notification upon download completion</source>
        <translation>Email notificatie wanneer download voltooid</translation>
    </message>
    <message>
        <source>Destination email:</source>
        <translation>Bestemming email:</translation>
    </message>
    <message>
        <source>SMTP server:</source>
        <translation>SMTP server:</translation>
    </message>
    <message>
        <source>Run an external program on torrent completion</source>
        <translation>Voer een extern programma uit bij de voltooiing van de torrent</translation>
    </message>
    <message>
        <source>Use %f to pass the torrent path in parameters</source>
        <translation type="obsolete">Gebruik %f om het torrentpad door te geven in parameters</translation>
    </message>
    <message>
        <source>Proxy server</source>
        <translation type="obsolete">Proxy server</translation>
    </message>
    <message>
        <source>BitTorrent</source>
        <translation>BitTorrent</translation>
    </message>
    <message>
        <source>Start / Stop Torrent</source>
        <translation>Start / Stop Torrent</translation>
    </message>
    <message>
        <source>Use UPnP / NAT-PMP port forwarding from my router</source>
        <translation>Gebruik UPnP / NAT-PMP port forwarding van mijn router</translation>
    </message>
    <message>
        <source>Privacy</source>
        <translation>Privacy</translation>
    </message>
    <message>
        <source>Enable DHT (decentralized network) to find more peers</source>
        <translation>Schakel DHT (decentralized network) in om andere peers te vinden</translation>
    </message>
    <message>
        <source>Use a different port for DHT and BitTorrent</source>
        <translation>Gebruik een verschillende poort voor DHT en BitTorrent</translation>
    </message>
    <message>
        <source>Enable Peer Exchange (PeX) to find more peers</source>
        <translation>Schakel Peer Exchange (PeX) in om peers te vinden</translation>
    </message>
    <message>
        <source>Enable Local Peer Discovery to find more peers</source>
        <translation>Schakel Local Peer Discovery in om meer peers te vinden</translation>
    </message>
    <message>
        <source>Encryption mode:</source>
        <translation>Encryptiemodus:</translation>
    </message>
    <message>
        <source>Prefer encryption</source>
        <translation>Verkies encryptie</translation>
    </message>
    <message>
        <source>Require encryption</source>
        <translation>Vereis encryptie</translation>
    </message>
    <message>
        <source>Disable encryption</source>
        <translation>Schakel encryptie uit</translation>
    </message>
    <message>
        <source>User Interface</source>
        <translation type="obsolete">Gebruikersinterface</translation>
    </message>
    <message>
        <source>Reload the filter</source>
        <translation>Herlaad de filter</translation>
    </message>
    <message>
        <source>Behavior</source>
        <translation>Gedrag</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Taal</translation>
    </message>
    <message>
        <source>Power Management</source>
        <translation>Power Management</translation>
    </message>
    <message>
        <source>Inhibit system sleep when torrents are active</source>
        <translation>Stop systeem sleep wanneer torrent actief zijn</translation>
    </message>
    <message>
        <source>Bypass authentication for localhost</source>
        <translation>Sla authenticatie over voor localhost</translation>
    </message>
    <message>
        <source>Ask for program exit confirmation</source>
        <translation>Vraag voor programma afsluiten bevestiging</translation>
    </message>
    <message>
        <source>Use monochrome system tray icon (requires restart)</source>
        <translation type="obsolete">Gebruik monochrome system tray icon (vereist herstart)</translation>
    </message>
    <message>
        <source>The following parameters are supported:
&lt;ul&gt;
&lt;li&gt;%f: Torrent path&lt;/li&gt;
&lt;li&gt;%n: Torrent name&lt;/li&gt;
&lt;/ul&gt;</source>
        <translation>De volgende parameters worden ondersteund:
&lt;ul&gt;
&lt;li&gt;%f: Torrent pad&lt;/li&gt;
&lt;li&gt;%n: Torrent naam&lt;/li&gt;
&lt;/ul&gt;</translation>
    </message>
    <message>
        <source>Tray icon style:</source>
        <translation>Tray icon stijl:</translation>
    </message>
    <message>
        <source>Normal</source>
        <translation>Normaal</translation>
    </message>
    <message>
        <source>Monochrome (Dark theme)</source>
        <translation>Monochroom (Donker thema)</translation>
    </message>
    <message>
        <source>Monochrome (Light theme)</source>
        <translation>Monochroom (Licht thema)</translation>
    </message>
    <message>
        <source>This server requires a secure connection (SSL)</source>
        <translation>Deze server vereist een veilige verbinding (SSL)</translation>
    </message>
    <message>
        <source>User Interface Language:</source>
        <translation>Gebuikersinterface taal:</translation>
    </message>
    <message>
        <source>Transfer List</source>
        <translation>Overdrachtenlijst</translation>
    </message>
    <message>
        <source>Show qBittorrent in notification area</source>
        <translation>Toon qBittorrent in de notificatie ruimte</translation>
    </message>
    <message>
        <source>Hard Disk</source>
        <translation>Harde Schijf</translation>
    </message>
    <message>
        <source>Listening Port</source>
        <translation>Luisterpoort</translation>
    </message>
    <message>
        <source>Connections Limits</source>
        <translation>Connectielimieten</translation>
    </message>
    <message>
        <source>Proxy Server</source>
        <translation>Proxy Server</translation>
    </message>
    <message>
        <source>Torrent Queueing</source>
        <translation>Torrent op de wachtlijst plaatsen</translation>
    </message>
    <message>
        <source>Share Ratio Limiting</source>
        <translation>Deel ratio limietering</translation>
    </message>
    <message>
        <source>Use UPnP / NAT-PMP to forward the port from my router</source>
        <translation>Gebruik UPnP / NAT-PMP om de poort van de router te forwarden</translation>
    </message>
    <message>
        <source>Update my dynamic domain name</source>
        <translation>Update mijn dynamische domeinnaam</translation>
    </message>
    <message>
        <source>Service:</source>
        <translation>Service:</translation>
    </message>
    <message>
        <source>Register</source>
        <translation>Registreer</translation>
    </message>
    <message>
        <source>Domain name:</source>
        <translation>Domeinnaam:</translation>
    </message>
    <message>
        <source>Global Rate Limits</source>
        <translation>Globale rate limieten</translation>
    </message>
    <message>
        <source>Apply rate limit to uTP connections</source>
        <translation>Pas rate limiet toe op uTP connecties</translation>
    </message>
    <message>
        <source>Apply rate limit to transport overhead</source>
        <translation>Pas rate limiet to op transport overhead</translation>
    </message>
    <message>
        <source>Alternative Global Rate Limits</source>
        <translation>Alternatieve globale rate limieten</translation>
    </message>
    <message>
        <source>Schedule the use of alternative rate limits</source>
        <translation>Stel het gebruik van alternatieve limieten in</translation>
    </message>
    <message>
        <source>Enable bandwidth management (uTP)</source>
        <translation>Schakel bandbreedte management in (uTP)</translation>
    </message>
    <message>
        <source>Otherwise, the proxy server is only used for tracker connections</source>
        <translation>Anders, de proxy server wordt alleen gebruikt voor tracker connecties</translation>
    </message>
    <message>
        <source>Use proxy for peer connections</source>
        <translation>Gebruik proxy voor peer connecties</translation>
    </message>
    <message>
        <source>Append .!qB extension to incomplete files</source>
        <translation>Voeg .!qB extensie toe aan onvolledige bestanden</translation>
    </message>
    <message>
        <source>Use HTTPS instead of HTTP</source>
        <translation>Gebruik HTTPS in plaats van HTTP</translation>
    </message>
    <message>
        <source>Import SSL Certificate</source>
        <translation>Importeer SSL certificaat</translation>
    </message>
    <message>
        <source>Import SSL Key</source>
        <translation>Importeer SSL Key</translation>
    </message>
    <message>
        <source>Certificate:</source>
        <translation>Certificaat:</translation>
    </message>
    <message>
        <source>Key:</source>
        <translation>Key:</translation>
    </message>
    <message>
        <source>&lt;a href=http://httpd.apache.org/docs/2.1/ssl/ssl_faq.html#aboutcerts&gt;Information about certificates&lt;/a&gt;</source>
        <translation>&lt;a href=http://httpd.apache.org/docs/2.1/ssl/ssl_faq.html#aboutcerts&gt;Informatie over certificaten&lt;/a&gt;</translation>
    </message>
</context>
<context>
    <name>PreviewSelect</name>
    <message>
        <source>Name</source>
        <translation>Naam</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Grootte</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation>Voortgang</translation>
    </message>
    <message>
        <source>Preview impossible</source>
        <translation>Vooruitkijken onmogelijk</translation>
    </message>
    <message>
        <source>Sorry, we can&apos;t preview this file</source>
        <translation>Sorry, we kunnen dit bestand niet vooruit bekijken</translation>
    </message>
</context>
<context>
    <name>ProgramUpdater</name>
    <message>
        <source>Could not create the file %1</source>
        <translation type="obsolete">Kon het bestand %1 niet maken</translation>
    </message>
    <message>
        <source>Failed to download the update at %1</source>
        <comment>%1 is an URL</comment>
        <translation type="obsolete">Mislukt om de update te downloaden van %1</translation>
    </message>
</context>
<context>
    <name>PropListDelegate</name>
    <message>
        <source>Normal</source>
        <comment>Normal (priority)</comment>
        <translation>Normaal</translation>
    </message>
    <message>
        <source>High</source>
        <comment>High (priority)</comment>
        <translation>Hoog</translation>
    </message>
    <message>
        <source>Maximum</source>
        <comment>Maximum (priority)</comment>
        <translation>Maximum</translation>
    </message>
    <message>
        <source>Not downloaded</source>
        <translation>Niet gedownload</translation>
    </message>
    <message>
        <source>Mixed</source>
        <comment>Mixed (priorities</comment>
        <translation>Meerdere</translation>
    </message>
</context>
<context>
    <name>PropTabBar</name>
    <message>
        <source>General</source>
        <translation>Algemeen</translation>
    </message>
    <message>
        <source>Trackers</source>
        <translation>Trackers</translation>
    </message>
    <message>
        <source>Peers</source>
        <translation>Peers</translation>
    </message>
    <message>
        <source>URL Seeds</source>
        <translation type="obsolete">URL Seeds</translation>
    </message>
    <message>
        <source>Files</source>
        <translation type="obsolete">Bestanden</translation>
    </message>
    <message>
        <source>HTTP Sources</source>
        <translation>HTTP Bronnen</translation>
    </message>
    <message>
        <source>Content</source>
        <translation>Inhoud</translation>
    </message>
</context>
<context>
    <name>PropertiesWidget</name>
    <message>
        <source>Save path:</source>
        <translation>Opslag pad:</translation>
    </message>
    <message>
        <source>Torrent hash:</source>
        <translation>Torrent hash:</translation>
    </message>
    <message>
        <source>Comment:</source>
        <translation>Opmerkingen:</translation>
    </message>
    <message>
        <source>Share ratio:</source>
        <translation>Deelratio:</translation>
    </message>
    <message>
        <source>General</source>
        <translation type="obsolete">Algemeen</translation>
    </message>
    <message>
        <source>Trackers</source>
        <translation type="obsolete">Trackers</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Prioriteit</translation>
    </message>
    <message>
        <source>New url seed</source>
        <comment>New HTTP source</comment>
        <translation>Nieuwe url seed</translation>
    </message>
    <message>
        <source>New url seed:</source>
        <translation>Nieuwe url seed:</translation>
    </message>
    <message>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <source>This url seed is already in the list.</source>
        <translation>Deze url seed staat al in de lijst.</translation>
    </message>
    <message>
        <source>Choose save path</source>
        <translation>Kies opslag pad</translation>
    </message>
    <message>
        <source>Save path creation error</source>
        <translation type="obsolete">Opslag pad aanmaak fout</translation>
    </message>
    <message>
        <source>Could not create the save path</source>
        <translation type="obsolete">Kon het opslag pad niet aanmaken</translation>
    </message>
    <message>
        <source>Downloaded:</source>
        <translation>Gedownload:</translation>
    </message>
    <message>
        <source>Transfer</source>
        <translation>Transfer</translation>
    </message>
    <message>
        <source>Uploaded:</source>
        <translation>Geüpload:</translation>
    </message>
    <message>
        <source>Wasted:</source>
        <translation>Verspild:</translation>
    </message>
    <message>
        <source>UP limit:</source>
        <translation>UP limiet:</translation>
    </message>
    <message>
        <source>DL limit:</source>
        <translation>DL limiet:</translation>
    </message>
    <message>
        <source>Time elapsed:</source>
        <translation type="obsolete">Tijd verstreken:</translation>
    </message>
    <message>
        <source>Connections:</source>
        <translation>Verbindingen:</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Informatie</translation>
    </message>
    <message>
        <source>Created on:</source>
        <translation>Gecreëerd op:</translation>
    </message>
    <message>
        <source>Normal</source>
        <translation>Normaal</translation>
    </message>
    <message>
        <source>Maximum</source>
        <translation>Maximum</translation>
    </message>
    <message>
        <source>High</source>
        <translation>Hoog</translation>
    </message>
    <message>
        <source>this session</source>
        <translation>Deze sessie</translation>
    </message>
    <message>
        <source>%1 max</source>
        <comment>e.g. 10 max</comment>
        <translation>%1 max</translation>
    </message>
    <message>
        <source>Availability:</source>
        <translation>Beschikbaarheid:</translation>
    </message>
    <message>
        <source>/s</source>
        <comment>/second (i.e. per second)</comment>
        <translation>/s</translation>
    </message>
    <message>
        <source>Seeded for %1</source>
        <comment>e.g. Seeded for 3m10s</comment>
        <translation>Geseed voor %1</translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation>Hernoem...</translation>
    </message>
    <message>
        <source>New name:</source>
        <translation>Nieuwe naam:</translation>
    </message>
    <message>
        <source>The file could not be renamed</source>
        <translation>Het bestand kon niet hernoemd worden</translation>
    </message>
    <message>
        <source>This name is already in use in this folder. Please use a different name.</source>
        <translation>Deze naam bestaat al in deze map. Gelieve een andere naam te gebruiken.</translation>
    </message>
    <message>
        <source>The folder could not be renamed</source>
        <translation>Deze map kon niet hernoemd worden</translation>
    </message>
    <message>
        <source>Rename the file</source>
        <translation>Hernoem het bestand</translation>
    </message>
    <message>
        <source>This file name contains forbidden characters, please choose a different one.</source>
        <translation>Dit bestand bevat verboden character, gelieven een andere te kiezen.</translation>
    </message>
    <message>
        <source>I/O Error</source>
        <translation>I/O Fout</translation>
    </message>
    <message>
        <source>This file does not exist yet.</source>
        <translation>Dit bestand bestaat nog niet.</translation>
    </message>
    <message>
        <source>This folder does not exist yet.</source>
        <translation>Deze map bestaat nog niet.</translation>
    </message>
    <message>
        <source>Reannounce in:</source>
        <translation>Heraankondigen in:</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Selecteer Alles</translation>
    </message>
    <message>
        <source>Select None</source>
        <translation>Selecteer Geen</translation>
    </message>
    <message>
        <source>Do not download</source>
        <translation>Download niet</translation>
    </message>
    <message>
        <source>Pieces size:</source>
        <translation>Delen grootte:</translation>
    </message>
    <message>
        <source>Time active:</source>
        <extracomment>Time (duration) the torrent is active (not paused)</extracomment>
        <translation>Tijd actief:</translation>
    </message>
    <message>
        <source>Torrent content:</source>
        <translation>Torrent inhoud:</translation>
    </message>
</context>
<context>
    <name>QBtSession</name>
    <message>
        <source>%1 reached the maximum ratio you set.</source>
        <translation>%1 heeft de maximum ingestelde verhouding bereikt.</translation>
    </message>
    <message>
        <source>Removing torrent %1...</source>
        <translation>Verwijderen torrent %1...</translation>
    </message>
    <message>
        <source>Pausing torrent %1...</source>
        <translation>Pauzeren torrent %1...</translation>
    </message>
    <message>
        <source>qBittorrent is bound to port: TCP/%1</source>
        <comment>e.g: qBittorrent is bound to port: 6881</comment>
        <translation>qBittorrent is verbonden met poort: TCP/%1</translation>
    </message>
    <message>
        <source>UPnP support [ON]</source>
        <translation type="obsolete">UPnP ondersteuning [AAN]</translation>
    </message>
    <message>
        <source>UPnP support [OFF]</source>
        <translation type="obsolete">UPnP ondersteuning [UIT]</translation>
    </message>
    <message>
        <source>NAT-PMP support [ON]</source>
        <translation type="obsolete">NAT-PMP ondersteuning [AAN]</translation>
    </message>
    <message>
        <source>NAT-PMP support [OFF]</source>
        <translation type="obsolete">NAT-PMP ondersteuning [UIT]</translation>
    </message>
    <message>
        <source>HTTP user agent is %1</source>
        <translation>HTTP user agent is %1</translation>
    </message>
    <message>
        <source>Using a disk cache size of %1 MiB</source>
        <translation type="obsolete">Gebruikt een disk cache grootte van %1 MiB</translation>
    </message>
    <message>
        <source>DHT support [ON], port: UDP/%1</source>
        <translation>DHT ondersteuning [AAN], poort: UDP/%1</translation>
    </message>
    <message>
        <source>DHT support [OFF]</source>
        <translation>DHT ondersteuning [UIT]</translation>
    </message>
    <message>
        <source>PeX support [ON]</source>
        <translation>PeX ondersteuning [AAN]</translation>
    </message>
    <message>
        <source>PeX support [OFF]</source>
        <translation>PeX ondersteuning [UIT]</translation>
    </message>
    <message>
        <source>Restart is required to toggle PeX support</source>
        <translation>Herstart is vereist om Pex supporten om te wisselen</translation>
    </message>
    <message>
        <source>Local Peer Discovery [ON]</source>
        <translation type="obsolete">Local Peer Discovery [AAN]</translation>
    </message>
    <message>
        <source>Local Peer Discovery support [OFF]</source>
        <translation>Local Peer Discovery ondersteuning [UIT]</translation>
    </message>
    <message>
        <source>Encryption support [ON]</source>
        <translation>Encryptie ondersteuning [AAN]</translation>
    </message>
    <message>
        <source>Encryption support [FORCED]</source>
        <translation>Encryptie ondersteuning [GEFORCEERD]</translation>
    </message>
    <message>
        <source>Encryption support [OFF]</source>
        <translation>Encryptie ondersteuning [UIT]</translation>
    </message>
    <message>
        <source>Embedded Tracker [ON]</source>
        <translation>Embedded Trackker[AAN]</translation>
    </message>
    <message>
        <source>Failed to start the embedded tracker!</source>
        <translation>Mistlukt om the embedded tracker te starten!</translation>
    </message>
    <message>
        <source>Embedded Tracker [OFF]</source>
        <translation>Embedded Tracker [OFF]</translation>
    </message>
    <message>
        <source>The Web UI is listening on port %1</source>
        <translation>De Web UI luistert naar poort %1</translation>
    </message>
    <message>
        <source>Web User Interface Error - Unable to bind Web UI to port %1</source>
        <translation>Webgebruikersinterface fout - Niet mogelijk om Web UI te binden aan poort %1</translation>
    </message>
    <message>
        <source>&apos;%1&apos; was removed from transfer list and hard disk.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>&apos;%1&apos; werd verwijderd van de overdrachtenlijst en harde schijf.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; was removed from transfer list.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>&apos;%1&apos; werd verwijderd van de overdrachtenlijst.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is not a valid magnet URI.</source>
        <translation>&apos;%1&apos; is geen geldige magnet URI.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is already in download list.</source>
        <comment>e.g: &apos;xxx.avi&apos; is already in download list.</comment>
        <translation>&apos;%1&apos; staat al in de downloadlijst.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; resumed. (fast resume)</source>
        <comment>&apos;/home/y/xxx.torrent&apos; was resumed. (fast resume)</comment>
        <translation>&apos;%1&apos; hervat. (snelle hervatting)</translation>
    </message>
    <message>
        <source>&apos;%1&apos; added to download list.</source>
        <comment>&apos;/home/y/xxx.torrent&apos; was added to download list.</comment>
        <translation>&apos;%1&apos; toegevoegd aan de downloadlijst.</translation>
    </message>
    <message>
        <source>Unable to decode torrent file: &apos;%1&apos;</source>
        <comment>e.g: Unable to decode torrent file: &apos;/home/y/xxx.torrent&apos;</comment>
        <translation>Torrentbestand kan niet worden gedecodeerd: &apos;%1&apos;</translation>
    </message>
    <message>
        <source>This file is either corrupted or this isn&apos;t a torrent.</source>
        <translation>Dit bestand is ofwel corrupt of is geen torrent.</translation>
    </message>
    <message>
        <source>Error: The torrent %1 does not contain any file.</source>
        <translation>Fout: De torrent %1 bevat geen enkel bestand.</translation>
    </message>
    <message>
        <source>Note: new trackers were added to the existing torrent.</source>
        <translation>Opmerking: nieuwe trackers werden toegevoegd aan de bestaande torrent.</translation>
    </message>
    <message>
        <source>Note: new URL seeds were added to the existing torrent.</source>
        <translation>Opmerking: nieuwe URL seeds werden toegevoegd aan de bestaande torrent.</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;was blocked due to your IP filter&lt;/i&gt;</source>
        <comment>x.y.z.w was blocked</comment>
        <translation>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;is geblokkeerd door de IP filter&lt;/i&gt;</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;was banned due to corrupt pieces&lt;/i&gt;</source>
        <comment>x.y.z.w was banned</comment>
        <translation>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;is verbannen door onjuiste delen&lt;/i&gt;</translation>
    </message>
    <message>
        <source>Recursive download of file %1 embedded in torrent %2</source>
        <comment>Recursive download of test.torrent embedded in torrent test2</comment>
        <translation>Recursieve download van bestand %1 in torrent %2</translation>
    </message>
    <message>
        <source>Unable to decode %1 torrent file.</source>
        <translation>Kon torrentbestand %1 niet decoderen.</translation>
    </message>
    <message>
        <source>Torrent name: %1</source>
        <translation>Torrentnaam: %1</translation>
    </message>
    <message>
        <source>Torrent size: %1</source>
        <translation>Torrentgrootte %1</translation>
    </message>
    <message>
        <source>Save path: %1</source>
        <translation>Opslagpad: %1</translation>
    </message>
    <message>
        <source>The torrent was downloaded in %1.</source>
        <comment>The torrent was downloaded in 1 hour and 20 seconds</comment>
        <translation>De torrent werd gedownload in %1.</translation>
    </message>
    <message>
        <source>Thank you for using qBittorrent.</source>
        <translation>Bedankt om qBittorrent te gebruiken.</translation>
    </message>
    <message>
        <source>[qBittorrent] %1 has finished downloading</source>
        <translation>[qBittorrent] %1 is klaar met downloaden</translation>
    </message>
    <message>
        <source>An I/O error occured, &apos;%1&apos; paused.</source>
        <translation>I/O fout gebeurd, &apos;%1&apos; gepauzeerd.</translation>
    </message>
    <message>
        <source>Reason: %1</source>
        <translation>Reden: %1</translation>
    </message>
    <message>
        <source>UPnP/NAT-PMP: Port mapping failure, message: %1</source>
        <translation>UPnP/NAT-PMP: Port mapping fout, bericht: %1</translation>
    </message>
    <message>
        <source>UPnP/NAT-PMP: Port mapping successful, message: %1</source>
        <translation>UPnP/NAT-PMP: Port mapping succesvol, bericht: %1</translation>
    </message>
    <message>
        <source>File sizes mismatch for torrent %1, pausing it.</source>
        <translation>Bestandgroottes komen niet overeen voor torrent %1, wordt gepauzeerd.</translation>
    </message>
    <message>
        <source>Fast resume data was rejected for torrent %1, checking again...</source>
        <translation>Snel hernemen van de data werd afgewezen door torrent %1, wordt opnieuw gecontroleerd...</translation>
    </message>
    <message>
        <source>Url seed lookup failed for url: %1, message: %2</source>
        <translation>Url seed raadpleging mislukt voor url: %1, bericht: %2</translation>
    </message>
    <message>
        <source>Downloading &apos;%1&apos;, please wait...</source>
        <comment>e.g: Downloading &apos;xxx.torrent&apos;, please wait...</comment>
        <translation>Bezig met downloaden van &apos;%1&apos;, even geduld alstublieft...</translation>
    </message>
    <message>
        <source>The network interface defined is invalid: %1</source>
        <translation>De gedefiniëerde netwerkinterface is ongeldig: %1</translation>
    </message>
    <message>
        <source>Trying any other network interface available instead.</source>
        <translation>Probeer een andere beeschikbaar netwerkinterface in de plaats.</translation>
    </message>
    <message>
        <source>Listening on IP address %1 on network interface %2...</source>
        <translation>Luisteren naar IP-adres %1 via netwerkinterface %2...</translation>
    </message>
    <message>
        <source>Failed to listen on network interface %1</source>
        <translation>Mislukt om te luisteren naar netwerkinterface %1</translation>
    </message>
    <message>
        <source>UPnP / NAT-PMP support [ON]</source>
        <translation>UPnP / NAT-PMP support [AAN]</translation>
    </message>
    <message>
        <source>UPnP / NAT-PMP support [OFF]</source>
        <translation>UPnP / NAT-PMP support [UIT]</translation>
    </message>
    <message>
        <source>Local Peer Discovery support [ON]</source>
        <translation>Local Peer Discovery support [AAN]</translation>
    </message>
    <message>
        <source>Successfuly parsed the provided IP filter: %1 rules were applied.</source>
        <comment>%1 is a number</comment>
        <translation>De opgegeven IP filter werd succesvol ontleed: %1 regels werden toegepast.</translation>
    </message>
    <message>
        <source>Error: Failed to parse the provided IP filter.</source>
        <translation>Error: Mislukt om de opgegeven IP filter te ontleden.</translation>
    </message>
    <message>
        <source>Reporting IP address %1 to trackers...</source>
        <translation>Melden van IP-adres %1 aan trackers...</translation>
    </message>
    <message>
        <source>The computer will now go to sleep mode unless you cancel within the next 15 seconds...</source>
        <translation>De computer zal nu in sleep modus gaan tenzij u annuleert binnen 15 seconden...</translation>
    </message>
    <message>
        <source>The computer will now be switched off unless you cancel within the next 15 seconds...</source>
        <translation>De computer zal nu afgesloten worden tenzij u annuleert binnen 15 seconden...</translation>
    </message>
    <message>
        <source>qBittorrent will now exit unless you cancel within the next 15 seconds...</source>
        <translation>qBittorrent zal nu afsluiten tenzij u annuleert binnen 15 seconden...</translation>
    </message>
</context>
<context>
    <name>RSS</name>
    <message>
        <source>Search</source>
        <translation>Zoeken</translation>
    </message>
    <message>
        <source>New subscription</source>
        <translation>Nieuwe subscriptie</translation>
    </message>
    <message>
        <source>Mark items read</source>
        <translation>Markeer items als gelezen</translation>
    </message>
    <message>
        <source>Update all</source>
        <translation>Update alles</translation>
    </message>
    <message>
        <source>Feed URL</source>
        <translation type="obsolete">Feed URL</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Updaten</translation>
    </message>
    <message>
        <source>RSS feeds</source>
        <translation type="obsolete">RSS feeds</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Torrents:&lt;/span&gt; &lt;span style=&quot; font-style:italic;&quot;&gt;(double-click to download)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Torrents:&lt;/span&gt; &lt;span style=&quot; font-style:italic;&quot;&gt;(dubbelklik om te downloaden)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Update all feeds</source>
        <translation>Update alle feeds</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Verwijderen</translation>
    </message>
    <message>
        <source>Rename</source>
        <translation>Hernoemen</translation>
    </message>
    <message>
        <source>Download torrent</source>
        <translation>Download torrent</translation>
    </message>
    <message>
        <source>Open news URL</source>
        <translation>Open nieuws URL</translation>
    </message>
    <message>
        <source>Copy feed URL</source>
        <translation>Kopieer feed URL</translation>
    </message>
    <message>
        <source>Refresh RSS streams</source>
        <translation>Vernieuw RRS streams</translation>
    </message>
    <message>
        <source>Article title</source>
        <translation type="obsolete">Artikeltitel</translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation>Hernoemen...</translation>
    </message>
    <message>
        <source>New subscription...</source>
        <translation>Nieuw abonnement...</translation>
    </message>
    <message>
        <source>New folder...</source>
        <translation>Nieuwe map...</translation>
    </message>
    <message>
        <source>Manage cookies...</source>
        <translation>Beheer cookies...</translation>
    </message>
    <message>
        <source>Settings...</source>
        <translation>Instellingen...</translation>
    </message>
    <message>
        <source>RSS Downloader...</source>
        <translation>RSS Downloader...</translation>
    </message>
</context>
<context>
    <name>RSSImp</name>
    <message>
        <source>Please type a rss stream url</source>
        <translation>Geef alstublieft een rss stream url</translation>
    </message>
    <message>
        <source>Stream URL:</source>
        <translation>Stream URL:</translation>
    </message>
    <message>
        <source>Are you sure? -- qBittorrent</source>
        <translation>Weet u het zeker? -- qBittorrent</translation>
    </message>
    <message>
        <source>&amp;Yes</source>
        <translation>&amp;Ja</translation>
    </message>
    <message>
        <source>&amp;No</source>
        <translation>&amp;Nee</translation>
    </message>
    <message>
        <source>Please choose a folder name</source>
        <translation>Kies een mapnaam</translation>
    </message>
    <message>
        <source>Folder name:</source>
        <translation>Mapnaam:</translation>
    </message>
    <message>
        <source>New folder</source>
        <translation>Nieuwe map</translation>
    </message>
    <message>
        <source>Overwrite attempt</source>
        <translation>Overschrijfpoging</translation>
    </message>
    <message>
        <source>You cannot overwrite %1 item.</source>
        <comment>You cannot overwrite myFolder item.</comment>
        <translation>Kan %1 item niet overschrijven.</translation>
    </message>
    <message>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <source>This rss feed is already in the list.</source>
        <translation>Deze rss feed staat al in de lijst.</translation>
    </message>
    <message>
        <source>Are you sure you want to delete these elements from the list?</source>
        <translation>Weet u zeker dat u deze elementen van de lijst wil verwijderen?</translation>
    </message>
    <message>
        <source>Are you sure you want to delete this element from the list?</source>
        <translation>Weet u zeker dat u dit element van de lijst wil verwijderen?</translation>
    </message>
    <message>
        <source>Please choose a new name for this RSS feed</source>
        <translation>Kies een nieuwe naam voor deze RSS feed</translation>
    </message>
    <message>
        <source>New feed name:</source>
        <translation>Nieuwe feed naam:</translation>
    </message>
    <message>
        <source>Name already in use</source>
        <translation>Naam al in gebruik</translation>
    </message>
    <message>
        <source>This name is already used by another item, please choose another one.</source>
        <translation>Deze naam is al gebruikt door een ander item, kies een andere naam.</translation>
    </message>
    <message>
        <source>Date: </source>
        <translation>Datum: </translation>
    </message>
    <message>
        <source>Author: </source>
        <translation>Auteur: </translation>
    </message>
    <message>
        <source>Unread</source>
        <translation>Ongelezen</translation>
    </message>
</context>
<context>
    <name>RssArticle</name>
    <message>
        <source>No description available</source>
        <translation type="obsolete">Geen omschrijving beschikbaar</translation>
    </message>
</context>
<context>
    <name>RssFeed</name>
    <message>
        <source>Automatically downloading %1 torrent from %2 RSS feed...</source>
        <translation>Download automatisch %1 torrent van %2 RSS feed...</translation>
    </message>
</context>
<context>
    <name>RssItem</name>
    <message>
        <source>No description available</source>
        <translation type="obsolete">Geen omschrijving beschikbaar</translation>
    </message>
</context>
<context>
    <name>RssSettings</name>
    <message>
        <source>RSS feeds refresh interval:</source>
        <translation type="obsolete">RSS feeds vernieuwingsinterval:</translation>
    </message>
    <message>
        <source>minutes</source>
        <translation type="obsolete">minuten</translation>
    </message>
    <message>
        <source>Maximum number of articles per feed:</source>
        <translation type="obsolete">Maximum aantal artikelen per feed:</translation>
    </message>
</context>
<context>
    <name>RssSettingsDlg</name>
    <message>
        <source>RSS Reader Settings</source>
        <translation>RSS Reader instellingen</translation>
    </message>
    <message>
        <source>RSS feeds refresh interval:</source>
        <translation>RSS feeds vernieuwingsinterval:</translation>
    </message>
    <message>
        <source>minutes</source>
        <translation>minuten</translation>
    </message>
    <message>
        <source>Maximum number of articles per feed:</source>
        <translation>Maximum aantal artikelen per feed:</translation>
    </message>
</context>
<context>
    <name>ScanFoldersModel</name>
    <message>
        <source>Watched Folder</source>
        <translation>Bekeken map</translation>
    </message>
    <message>
        <source>Download here</source>
        <translation>Download hier</translation>
    </message>
</context>
<context>
    <name>SearchCategories</name>
    <message>
        <source>All categories</source>
        <translation>Alle categorieën</translation>
    </message>
    <message>
        <source>Movies</source>
        <translation>Films</translation>
    </message>
    <message>
        <source>TV shows</source>
        <translation>TV programma&apos;s</translation>
    </message>
    <message>
        <source>Music</source>
        <translation>Muziek</translation>
    </message>
    <message>
        <source>Games</source>
        <translation>Spellen</translation>
    </message>
    <message>
        <source>Anime</source>
        <translation>Anime</translation>
    </message>
    <message>
        <source>Software</source>
        <translation>Software</translation>
    </message>
    <message>
        <source>Pictures</source>
        <translation>Afbeeldingen</translation>
    </message>
    <message>
        <source>Books</source>
        <translation>Boeken</translation>
    </message>
</context>
<context>
    <name>SearchEngine</name>
    <message>
        <source>Empty search pattern</source>
        <translation>Leeg zoekpatroon</translation>
    </message>
    <message>
        <source>Please type a search pattern first</source>
        <translation>Type alstublieft eerst een zoekpatroon</translation>
    </message>
    <message>
        <source>Results</source>
        <translation>Resultaten</translation>
    </message>
    <message>
        <source>Searching...</source>
        <translation>Zoeken...</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation>Knippen</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Kopiëren</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation>Plakken</translation>
    </message>
    <message>
        <source>Clear field</source>
        <translation>Veld wissen</translation>
    </message>
    <message>
        <source>Clear completion history</source>
        <translation>Wis aanvulgeschiedenis</translation>
    </message>
    <message>
        <source>Search Engine</source>
        <translation>Zoekmachine</translation>
    </message>
    <message>
        <source>Search has finished</source>
        <translation>Zoeken is klaar</translation>
    </message>
    <message>
        <source>An error occured during search...</source>
        <translation>Een fout trad op tijdens zoeken...</translation>
    </message>
    <message>
        <source>Search aborted</source>
        <translation>Zoeken afgebroken</translation>
    </message>
    <message>
        <source>Search returned no results</source>
        <translation>Zoeken gaf geen resultaten</translation>
    </message>
    <message>
        <source>Results</source>
        <comment>i.e: Search results</comment>
        <translation>Resultaten</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Onbekend</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Zoeken</translation>
    </message>
    <message>
        <source>Download error</source>
        <translation>Download fout</translation>
    </message>
    <message>
        <source>Python setup could not be downloaded, reason: %1.
Please install it manually.</source>
        <translation>Python-installatie kon niet worden gedownload, reason: %1.
Gelieve het manueel te installeren.</translation>
    </message>
    <message>
        <source>Missing Python Interpreter</source>
        <translation>Ontbrekende Python Interpreter</translation>
    </message>
    <message>
        <source>Python 2.x is required to use the search engine but it does not seem to be installed.
Do you want to install it now?</source>
        <translation>Python 2.x is vereist om de zoekmachine te gebruiken maar dit lijkt niet geinstalleerd.
Wilt u het nu installeren?</translation>
    </message>
    <message>
        <source>Confirmation</source>
        <translation>Bevestiging</translation>
    </message>
    <message>
        <source>Are you sure you want to clear the history?</source>
        <translation>Bent u zeker dat u de geschiedenis wilt wissen?</translation>
    </message>
</context>
<context>
    <name>SearchTab</name>
    <message>
        <source>Name</source>
        <comment>i.e: file name</comment>
        <translation>Naam</translation>
    </message>
    <message>
        <source>Size</source>
        <comment>i.e: file size</comment>
        <translation>Grootte</translation>
    </message>
    <message>
        <source>Seeders</source>
        <comment>i.e: Number of full sources</comment>
        <translation>Uploaders</translation>
    </message>
    <message>
        <source>Leechers</source>
        <comment>i.e: Number of partial sources</comment>
        <translation>Downloaders</translation>
    </message>
    <message>
        <source>Search engine</source>
        <translation>Zoekmachine</translation>
    </message>
</context>
<context>
    <name>ShutdownConfirmDlg</name>
    <message>
        <source>Shutdown confirmation</source>
        <translation>Afsluit bevestiging</translation>
    </message>
</context>
<context>
    <name>SpeedLimitDialog</name>
    <message>
        <source>KiB/s</source>
        <translation>KiB/s</translation>
    </message>
</context>
<context>
    <name>StatusBar</name>
    <message>
        <source>Connection status:</source>
        <translation>Verbindingsstatus:</translation>
    </message>
    <message>
        <source>No direct connections. This may indicate network configuration problems.</source>
        <translation>Geen directe verbindingen. Dit kan komen door netwerkconfiguratieproblemen.</translation>
    </message>
    <message>
        <source>DHT: %1 nodes</source>
        <translation>DHT: %1 nodes</translation>
    </message>
    <message>
        <source>Connection Status:</source>
        <translation>Verbindingsstatus:</translation>
    </message>
    <message>
        <source>Online</source>
        <translation>Online</translation>
    </message>
    <message>
        <source>Global Download Speed Limit</source>
        <translation>Globale downloadsnelheidslimit</translation>
    </message>
    <message>
        <source>Global Upload Speed Limit</source>
        <translation>Globale uploadsnelheidslimit</translation>
    </message>
    <message>
        <source>D: %1/s - T: %2</source>
        <comment>Download speed: x KiB/s - Transferred: x MiB</comment>
        <translation type="obsolete">D: %1/s - O: %2</translation>
    </message>
    <message>
        <source>U: %1/s - T: %2</source>
        <comment>Upload speed: x KiB/s - Transferred: x MiB</comment>
        <translation type="obsolete">U: %1/s - O: %2</translation>
    </message>
    <message>
        <source>D: %1 B/s - T: %2</source>
        <comment>Download speed: x B/s - Transferred: x MiB</comment>
        <translation type="obsolete">D: %1 B/s - O: %2</translation>
    </message>
    <message>
        <source>U: %1 B/s - T: %2</source>
        <comment>Upload speed: x B/s - Transferred: x MiB</comment>
        <translation type="obsolete">U: %1 B/s - O: %2</translation>
    </message>
    <message>
        <source>Offline. This usually means that qBittorrent failed to listen on the selected port for incoming connections.</source>
        <translation>Offline. Dit betekent meestal dat qBittorrent mislukte om te luisteren naar de geselecteerde poort voor inkomende verbindingen.</translation>
    </message>
    <message>
        <source>Click to disable alternative speed limits</source>
        <translation type="obsolete">Klik om de alternatieve snelheidslimieten uit te schakelen</translation>
    </message>
    <message>
        <source>Click to enable alternative speed limits</source>
        <translation type="obsolete">Klik om de alternatieve snelheidslimieten in te schakelen</translation>
    </message>
    <message>
        <source>qBittorrent needs to be restarted</source>
        <translation>qBittorrent moet opnieuw opgestart worden</translation>
    </message>
    <message>
        <source>qBittorrent was just updated and needs to be restarted for the changes to be effective.</source>
        <translation>qBittorrent is geüpdatet en moet opnieuw opgestart worden zodat de veranderingen doorgevoerd zijn.</translation>
    </message>
    <message>
        <source>Click to switch to alternative speed limits</source>
        <translation>Klik om om te schakelen naar alternatieve snelheidslimieten</translation>
    </message>
    <message>
        <source>Click to switch to regular speed limits</source>
        <translation>Klik om om te schakelen naar algemene snelheidslimieten</translation>
    </message>
    <message>
        <source>%1/s</source>
        <comment>Per second</comment>
        <translation>%1/s</translation>
    </message>
</context>
<context>
    <name>TorrentCreatorDlg</name>
    <message>
        <source>Select a folder to add to the torrent</source>
        <translation>Selecteer een map om toe te voegen aan de torrent</translation>
    </message>
    <message>
        <source>Select a file to add to the torrent</source>
        <translation>Selecteer een bestand om toe te voegen aan de torrent</translation>
    </message>
    <message>
        <source>Please type an announce URL</source>
        <translation type="obsolete">Type een announce URL</translation>
    </message>
    <message>
        <source>Announce URL:</source>
        <comment>Tracker URL</comment>
        <translation type="obsolete">Announce URL:</translation>
    </message>
    <message>
        <source>Please type a web seed url</source>
        <translation type="obsolete">Type een web seed url</translation>
    </message>
    <message>
        <source>Web seed URL:</source>
        <translation type="obsolete">Web seed URL:</translation>
    </message>
    <message>
        <source>No input path set</source>
        <translation>Geen bron pad gekozen</translation>
    </message>
    <message>
        <source>Please type an input path first</source>
        <translation>Geef alstublieft eerst een doel pad</translation>
    </message>
    <message>
        <source>Select destination torrent file</source>
        <translation>Kies torrent doelbestand</translation>
    </message>
    <message>
        <source>Torrent Files</source>
        <translation>Torrent bestanden</translation>
    </message>
    <message>
        <source>Torrent creation</source>
        <translation>Torrent maken</translation>
    </message>
    <message>
        <source>Torrent creation was unsuccessful, reason: %1</source>
        <translation>Fout tijdens het maken van torrent, reden: %1</translation>
    </message>
    <message>
        <source>Created torrent file is invalid. It won&apos;t be added to download list.</source>
        <translation>Gecreëerd torrentbestand is onjuist. Het wordt niet toegevoegd aan de downloadlijst.</translation>
    </message>
    <message>
        <source>Torrent was created successfully:</source>
        <translation>Torrent was succesvol gemaakt:</translation>
    </message>
</context>
<context>
    <name>TorrentFilesModel</name>
    <message>
        <source>Name</source>
        <translation>Naam</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Grootte</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation>Voortgang</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Prioriteit</translation>
    </message>
</context>
<context>
    <name>TorrentImportDlg</name>
    <message>
        <source>Torrent Import</source>
        <translation>Torrent Import</translation>
    </message>
    <message>
        <source>This assistant will help you share with qBittorrent a torrent that you have already downloaded.</source>
        <translation>Deze assistent zal u helpen om een torrent te delen met qBittorrent dat u reeds gedownload hebt.</translation>
    </message>
    <message>
        <source>Torrent file to import:</source>
        <translation>Torrentbestand om te importeren:</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Content location:</source>
        <translation>Inhoudlocatie:</translation>
    </message>
    <message>
        <source>Skip the data checking stage and start seeding immediately</source>
        <translation>Sla het controleren van de data over en start onmiddellijk het seeden</translation>
    </message>
    <message>
        <source>Import</source>
        <translation>Importeer</translation>
    </message>
    <message>
        <source>Torrent file to import</source>
        <translation>Torrentbestand om te importeren</translation>
    </message>
    <message>
        <source>Torrent files (*.torrent)</source>
        <translation>Torrentbestanden (*.torrent)</translation>
    </message>
    <message>
        <source>%1 Files</source>
        <comment>%1 is a file extension (e.g. PDF)</comment>
        <translation>%1 bestanden</translation>
    </message>
    <message>
        <source>Please provide the location of %1</source>
        <comment>%1 is a file name</comment>
        <translation>Gelieve de locatie van %1 op te geven</translation>
    </message>
    <message>
        <source>Please point to the location of the torrent: %1</source>
        <translation>Gelieve de locatie op te geven van de torrent: %1</translation>
    </message>
    <message>
        <source>Invalid torrent file</source>
        <translation>Ongeldig torrentbestand</translation>
    </message>
    <message>
        <source>This is not a valid torrent file.</source>
        <translation>Dit is geen geldig torrentbestand.</translation>
    </message>
</context>
<context>
    <name>TorrentModel</name>
    <message>
        <source>Name</source>
        <comment>i.e: torrent name</comment>
        <translation>Naam</translation>
    </message>
    <message>
        <source>Size</source>
        <comment>i.e: torrent size</comment>
        <translation>Grootte</translation>
    </message>
    <message>
        <source>Done</source>
        <comment>% Done</comment>
        <translation>Gereed</translation>
    </message>
    <message>
        <source>Status</source>
        <comment>Torrent status (e.g. downloading, seeding, paused)</comment>
        <translation>Status</translation>
    </message>
    <message>
        <source>Seeds</source>
        <comment>i.e. full sources (often untranslated)</comment>
        <translation>Uploaders</translation>
    </message>
    <message>
        <source>Peers</source>
        <comment>i.e. partial sources (often untranslated)</comment>
        <translation>Peers</translation>
    </message>
    <message>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Down-snelheid</translation>
    </message>
    <message>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Up-snelheid</translation>
    </message>
    <message>
        <source>Ratio</source>
        <comment>Share ratio</comment>
        <translation>Verhouding</translation>
    </message>
    <message>
        <source>ETA</source>
        <comment>i.e: Estimated Time of Arrival / Time left</comment>
        <translation>Geschatte resterende tijd</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Label</translation>
    </message>
    <message>
        <source>Added On</source>
        <comment>Torrent was added to transfer list on 01/01/2010 08:00</comment>
        <translation>Toegevoegd op</translation>
    </message>
    <message>
        <source>Completed On</source>
        <comment>Torrent was completed on 01/01/2010 08:00</comment>
        <translation>Voltooid op</translation>
    </message>
    <message>
        <source>Tracker</source>
        <translation>Tracker</translation>
    </message>
    <message>
        <source>Down Limit</source>
        <comment>i.e: Download limit</comment>
        <translation>Down-limiet</translation>
    </message>
    <message>
        <source>Up Limit</source>
        <comment>i.e: Upload limit</comment>
        <translation>Up-limiet</translation>
    </message>
    <message>
        <source>Amount downloaded</source>
        <comment>Amount of data downloaded (e.g. in MB)</comment>
        <translation>Hoeveel gedownload</translation>
    </message>
    <message>
        <source>Amount left</source>
        <comment>Amount of data left to download (e.g. in MB)</comment>
        <translation>Hoeveel over</translation>
    </message>
    <message>
        <source>Time Active</source>
        <comment>Time (duration) the torrent is active (not paused)</comment>
        <translation>Tijd actief</translation>
    </message>
</context>
<context>
    <name>TrackerList</name>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <source>Peers</source>
        <translation>Peers</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Bericht</translation>
    </message>
    <message>
        <source>[DHT]</source>
        <translation>[DHT]</translation>
    </message>
    <message>
        <source>Working</source>
        <translation>Bezig</translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Uitgeschakeld</translation>
    </message>
    <message>
        <source>This torrent is private</source>
        <translation>Deze torrent is privé</translation>
    </message>
    <message>
        <source>Updating...</source>
        <translation>Updating...</translation>
    </message>
    <message>
        <source>Not working</source>
        <translation>Niet bezig</translation>
    </message>
    <message>
        <source>Not contacted yet</source>
        <translation>Nog niet gecontacteerd</translation>
    </message>
    <message>
        <source>[PeX]</source>
        <translation>[PeX]</translation>
    </message>
    <message>
        <source>[LSD]</source>
        <translation>[LSD]</translation>
    </message>
    <message>
        <source>Add a new tracker...</source>
        <translation>Voeg een nieuwe tracker toe...</translation>
    </message>
    <message>
        <source>Remove tracker</source>
        <translation>Verwijder tracker</translation>
    </message>
    <message>
        <source>Force reannounce</source>
        <translation>Forceer heraankondiging</translation>
    </message>
</context>
<context>
    <name>TrackersAdditionDlg</name>
    <message>
        <source>Trackers addition dialog</source>
        <translation>Trackers toevoegen dialoog</translation>
    </message>
    <message>
        <source>List of trackers to add (one per line):</source>
        <translation>Lijst van toe te voegen trackers (een per regel):</translation>
    </message>
    <message utf8="true">
        <source>µTorrent compatible list URL:</source>
        <translation>µTorrent compatibiliteitslijst URL:</translation>
    </message>
    <message>
        <source>I/O Error</source>
        <translation>I/O Fout</translation>
    </message>
    <message>
        <source>Error while trying to open the downloaded file.</source>
        <translation>Fout tijdens het openen van het gedownloade bestand.</translation>
    </message>
    <message>
        <source>No change</source>
        <translation>Geen verandering</translation>
    </message>
    <message>
        <source>No additional trackers were found.</source>
        <translation>Geen extre trackers werden gevonden.</translation>
    </message>
    <message>
        <source>Download error</source>
        <translation>Download-fout</translation>
    </message>
    <message>
        <source>The trackers list could not be downloaded, reason: %1</source>
        <translation>De trackerslijst kon niet worden gedownload, reden: %1</translation>
    </message>
</context>
<context>
    <name>TransferListDelegate</name>
    <message>
        <source>Downloading</source>
        <translation>Downloaden</translation>
    </message>
    <message>
        <source>Paused</source>
        <translation>Gepauzeerd</translation>
    </message>
    <message>
        <source>Queued</source>
        <comment>i.e. torrent is queued</comment>
        <translation>In de wachtlijn geplaatst</translation>
    </message>
    <message>
        <source>Seeding</source>
        <comment>Torrent is complete and in upload-only mode</comment>
        <translation>Seeden</translation>
    </message>
    <message>
        <source>Stalled</source>
        <comment>Torrent is waiting for download to begin</comment>
        <translation>Wacht</translation>
    </message>
    <message>
        <source>Checking</source>
        <comment>Torrent local data is being checked</comment>
        <translation>Wordt gecontroleerd</translation>
    </message>
    <message>
        <source>/s</source>
        <comment>/second (.i.e per second)</comment>
        <translation>/s</translation>
    </message>
    <message>
        <source>KiB/s</source>
        <comment>KiB/second (.i.e per second)</comment>
        <translation>KiB/s</translation>
    </message>
    <message>
        <source>Seeded for %1</source>
        <comment>e.g. Seeded for 3m10s</comment>
        <translation>Geseed voor %1</translation>
    </message>
</context>
<context>
    <name>TransferListFiltersWidget</name>
    <message>
        <source>All</source>
        <translation>Alle</translation>
    </message>
    <message>
        <source>Downloading</source>
        <translation>Downloaden</translation>
    </message>
    <message>
        <source>Completed</source>
        <translation>Voltooid</translation>
    </message>
    <message>
        <source>Active</source>
        <translation>Actief</translation>
    </message>
    <message>
        <source>Inactive</source>
        <translation>Inactief</translation>
    </message>
    <message>
        <source>All labels</source>
        <translation>Alle labels</translation>
    </message>
    <message>
        <source>Unlabeled</source>
        <translation>Ongelabeld</translation>
    </message>
    <message>
        <source>Remove label</source>
        <translation>Verwijder label</translation>
    </message>
    <message>
        <source>New Label</source>
        <translation>Nieuw label</translation>
    </message>
    <message>
        <source>Label:</source>
        <translation>Label:</translation>
    </message>
    <message>
        <source>Invalid label name</source>
        <translation>Ongeldige labelnaam</translation>
    </message>
    <message>
        <source>Please don&apos;t use any special characters in the label name.</source>
        <translation>Gelieve geen speciale characters te gebruiken in de labelnaam.</translation>
    </message>
    <message>
        <source>Paused</source>
        <translation>Gepauzeerd</translation>
    </message>
    <message>
        <source>Add label...</source>
        <translation>Voeg label toe...</translation>
    </message>
    <message>
        <source>Resume torrents</source>
        <translation>Herneem torrents</translation>
    </message>
    <message>
        <source>Pause torrents</source>
        <translation>Pauzeer torrents</translation>
    </message>
    <message>
        <source>Delete torrents</source>
        <translation>Verwijder torrents</translation>
    </message>
</context>
<context>
    <name>TransferListWidget</name>
    <message>
        <source>ETA</source>
        <comment>i.e: Estimated Time of Arrival / Time left</comment>
        <translation type="obsolete">Geschatte resterende tijd</translation>
    </message>
    <message>
        <source>Column visibility</source>
        <translation>Kolom zichtbaarheid</translation>
    </message>
    <message>
        <source>Open destination folder</source>
        <translation>Open doel map</translation>
    </message>
    <message>
        <source>Force recheck</source>
        <translation>Forceer hercontrole</translation>
    </message>
    <message>
        <source>Copy magnet link</source>
        <translation>Kopieer magnet link</translation>
    </message>
    <message>
        <source>Name</source>
        <comment>i.e: torrent name</comment>
        <translation type="obsolete">Naam</translation>
    </message>
    <message>
        <source>Size</source>
        <comment>i.e: torrent size</comment>
        <translation type="obsolete">Grootte</translation>
    </message>
    <message>
        <source>Status</source>
        <comment>Torrent status (e.g. downloading, seeding, paused)</comment>
        <translation type="obsolete">Status</translation>
    </message>
    <message>
        <source>Seeds</source>
        <comment>i.e. full sources (often untranslated)</comment>
        <translation type="obsolete">Uploaders</translation>
    </message>
    <message>
        <source>Ratio</source>
        <comment>Share ratio</comment>
        <translation type="obsolete">Verhouding</translation>
    </message>
    <message>
        <source>Torrent Download Speed Limiting</source>
        <translation>Torrent downloadsnelheidsbeperking</translation>
    </message>
    <message>
        <source>Torrent Upload Speed Limiting</source>
        <translation>Torrent uploadsnelheidsbeperking</translation>
    </message>
    <message>
        <source>Super seeding mode</source>
        <translation>Super seeding modus</translation>
    </message>
    <message>
        <source>Download in sequential order</source>
        <translation>Download in sequentiële volgorde</translation>
    </message>
    <message>
        <source>Download first and last piece first</source>
        <translation>Download het eerste en het laatste deel eerst</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Label</translation>
    </message>
    <message>
        <source>New Label</source>
        <translation>Nieuw label</translation>
    </message>
    <message>
        <source>Label:</source>
        <translation>Label:</translation>
    </message>
    <message>
        <source>New...</source>
        <comment>New label...</comment>
        <translation>Nieuw...</translation>
    </message>
    <message>
        <source>Reset</source>
        <comment>Reset label</comment>
        <translation>Reset</translation>
    </message>
    <message>
        <source>Rename</source>
        <translation>Hernoemen</translation>
    </message>
    <message>
        <source>New name:</source>
        <translation>Nieuwe naam:</translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation>Hernoem...</translation>
    </message>
    <message>
        <source>Invalid label name</source>
        <translation>Ongeldige labelnaam</translation>
    </message>
    <message>
        <source>Please don&apos;t use any special characters in the label name.</source>
        <translation>Gelieve geen speciale characters te gebruiken in de labelnaam.</translation>
    </message>
    <message>
        <source>Choose save path</source>
        <translation>Kies opslag pad</translation>
    </message>
    <message>
        <source>Save path creation error</source>
        <translation type="obsolete">Opslag pad aanmaak fout</translation>
    </message>
    <message>
        <source>Could not create the save path</source>
        <translation type="obsolete">Kon het opslag pad niet aanmaken</translation>
    </message>
    <message>
        <source>Set location...</source>
        <translation>Stel locatie in...</translation>
    </message>
    <message>
        <source>Preview file...</source>
        <translation>Bekijk bestand vooraf...</translation>
    </message>
    <message>
        <source>Limit upload rate...</source>
        <translation>Uploadverhoudingslimiet...</translation>
    </message>
    <message>
        <source>Limit download rate...</source>
        <translation>Downloadverhoudingslimiet...</translation>
    </message>
    <message>
        <source>Move up</source>
        <comment>i.e. move up in the queue</comment>
        <translation>Verplaats omhoog</translation>
    </message>
    <message>
        <source>Move down</source>
        <comment>i.e. Move down in the queue</comment>
        <translation>Verplaats omlaag</translation>
    </message>
    <message>
        <source>Move to top</source>
        <comment>i.e. Move to top of the queue</comment>
        <translation>Verplaats naar de top</translation>
    </message>
    <message>
        <source>Move to bottom</source>
        <comment>i.e. Move to bottom of the queue</comment>
        <translation>Verplaats naar het einde</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Prioriteit</translation>
    </message>
    <message>
        <source>Resume</source>
        <comment>Resume/start the torrent</comment>
        <translation>Herneem</translation>
    </message>
    <message>
        <source>Pause</source>
        <comment>Pause the torrent</comment>
        <translation>Pauzeer</translation>
    </message>
    <message>
        <source>Delete</source>
        <comment>Delete the torrent</comment>
        <translation>Verwijderen</translation>
    </message>
    <message>
        <source>Limit share ratio...</source>
        <translation>Limiet deel ratio...</translation>
    </message>
</context>
<context>
    <name>UpDownRatioDlg</name>
    <message>
        <source>Torrent Upload/Download Ratio Limiting</source>
        <translation>Torrent Upload/Download Ratio limietering</translation>
    </message>
    <message>
        <source>Use global ratio limit</source>
        <translation>Gebruik globale ratio limiet</translation>
    </message>
    <message>
        <source>buttonGroup</source>
        <translation>knopGroep</translation>
    </message>
    <message>
        <source>Set no ratio limit</source>
        <translation>Zet geen ratio limiet</translation>
    </message>
    <message>
        <source>Set ratio limit to</source>
        <translation>Zet ratio limiet op</translation>
    </message>
</context>
<context>
    <name>UsageDisplay</name>
    <message>
        <source>Usage:</source>
        <translation>Gebruik:</translation>
    </message>
    <message>
        <source>displays program version</source>
        <translation>Toon programmaversie</translation>
    </message>
    <message>
        <source>disable splash screen</source>
        <translation>deactiveer splash screen</translation>
    </message>
    <message>
        <source>displays this help message</source>
        <translation>toon dit helpbericht</translation>
    </message>
    <message>
        <source>changes the webui port (current: %1)</source>
        <translation>verandert de webui-poort (huidige: %1)</translation>
    </message>
    <message>
        <source>[files or urls]: downloads the torrents passed by the user (optional)</source>
        <translation>[bestanden of urls]: download de torrent doorgegeven door de gebruiker (optioneel)</translation>
    </message>
</context>
<context>
    <name>about</name>
    <message>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <source>I would like to thank the following people who volunteered to translate qBittorrent:</source>
        <translation>Ik wil de volgende mensen graag bedanken die qBittorrent hebben vertaald:</translation>
    </message>
    <message>
        <source>Please contact me if you would like to translate qBittorrent into your own language.</source>
        <translation>Neem contact met me op als u qBittorrent naar uw eigen taal wilt vertalen.</translation>
    </message>
</context>
<context>
    <name>addPeerDialog</name>
    <message>
        <source>Peer addition</source>
        <translation>Peer toevoeging</translation>
    </message>
    <message>
        <source>IP</source>
        <translation>IP</translation>
    </message>
    <message>
        <source>Port</source>
        <translation>Poort</translation>
    </message>
</context>
<context>
    <name>addTorrentDialog</name>
    <message>
        <source>Torrent addition dialog</source>
        <translation>Torrent toevoegen dialoog</translation>
    </message>
    <message>
        <source>Save path:</source>
        <translation>Opslag pad:</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Torrent size:</source>
        <translation>Torrent grootte:</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Onbekend</translation>
    </message>
    <message>
        <source>Free disk space:</source>
        <translation>Vrije schijfruimte:</translation>
    </message>
    <message>
        <source>Torrent content:</source>
        <translation>Torrent inhoud:</translation>
    </message>
    <message>
        <source>Download in sequential order (slower but good for previewing)</source>
        <translation>Download in sequentiële volgorde (langzamer maar goed om voorbeeld weer te geven)</translation>
    </message>
    <message>
        <source>Add to download list in paused state</source>
        <translation>Aan download lijst toevoegen in pauze stand</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>Toevoegen</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Annuleren</translation>
    </message>
    <message>
        <source>Normal</source>
        <translation>Normaal</translation>
    </message>
    <message>
        <source>High</source>
        <translation>Hoog</translation>
    </message>
    <message>
        <source>Maximum</source>
        <translation>Maximum</translation>
    </message>
    <message>
        <source>Skip file checking and start seeding immediately</source>
        <translation>Sla het controleren van het bestand over en start onmiddellijk met het seeden</translation>
    </message>
    <message>
        <source>Label:</source>
        <translation>Label:</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Selecteer alles</translation>
    </message>
    <message>
        <source>Select None</source>
        <translation>Selecteer geen</translation>
    </message>
    <message>
        <source>Do not download</source>
        <translation>Download niet</translation>
    </message>
</context>
<context>
    <name>authentication</name>
    <message>
        <source>Tracker authentication</source>
        <translation>Tracker authenticatie</translation>
    </message>
    <message>
        <source>Tracker:</source>
        <translation>Tracker:</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Login</translation>
    </message>
    <message>
        <source>Username:</source>
        <translation>Gebruikersnaam:</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation>Wachtwoord:</translation>
    </message>
    <message>
        <source>Log in</source>
        <translation>Log in</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Annuleren</translation>
    </message>
</context>
<context>
    <name>confirmDeletionDlg</name>
    <message>
        <source>Deletion confirmation - qBittorrent</source>
        <translation>Verwijderbevestiging - qBittorrent</translation>
    </message>
    <message>
        <source>Are you sure you want to delete the selected torrents from the transfer list?</source>
        <translation>Bent u zeker dat u de geselecteerde torrents wilt verwijderen van de overdrachtenlijst?</translation>
    </message>
    <message>
        <source>Remember choice</source>
        <translation>Onthoudt de keuze</translation>
    </message>
    <message>
        <source>Also delete the files on the hard disk</source>
        <translation>Verwijder ook de bestanden op de harde schijf</translation>
    </message>
</context>
<context>
    <name>createTorrentDialog</name>
    <message>
        <source>Cancel</source>
        <translation>Annuleren</translation>
    </message>
    <message>
        <source>Torrent Creation Tool</source>
        <translation>Hulpprogramma voor torrent maken</translation>
    </message>
    <message>
        <source>Torrent file creation</source>
        <translation>Torrentbestand maken</translation>
    </message>
    <message>
        <source>Announce urls (trackers):</source>
        <translation type="obsolete">Announce urls (trackers):</translation>
    </message>
    <message>
        <source>Comment (optional):</source>
        <translation type="obsolete">Commentaar (optioneel):</translation>
    </message>
    <message>
        <source>Web seeds urls (optional):</source>
        <translation type="obsolete">Web seeds urls (optioneel):</translation>
    </message>
    <message>
        <source>File or folder to add to the torrent:</source>
        <translation>Bestand of map om toe te voegen aan de torrent:</translation>
    </message>
    <message>
        <source>Add file</source>
        <translation>Voeg bestand toe</translation>
    </message>
    <message>
        <source>Add folder</source>
        <translation>Voeg map toe</translation>
    </message>
    <message>
        <source>Piece size:</source>
        <translation>Stukgrootte:</translation>
    </message>
    <message>
        <source>32 KiB</source>
        <translation>32 KiB</translation>
    </message>
    <message>
        <source>64 KiB</source>
        <translation>64 KiB</translation>
    </message>
    <message>
        <source>128 KiB</source>
        <translation>128 KiB</translation>
    </message>
    <message>
        <source>256 KiB</source>
        <translation>256 KiB</translation>
    </message>
    <message>
        <source>512 KiB</source>
        <translation>512 KiB</translation>
    </message>
    <message>
        <source>1 MiB</source>
        <translation>1 MiB</translation>
    </message>
    <message>
        <source>2 MiB</source>
        <translation>2 MiB</translation>
    </message>
    <message>
        <source>4 MiB</source>
        <translation>4 MiB</translation>
    </message>
    <message>
        <source>Private (won&apos;t be distributed on DHT network if enabled)</source>
        <translation>Privé (wordt niet verdeeld op het DHT netwerk indien ingeschakeld)</translation>
    </message>
    <message>
        <source>Start seeding after creation</source>
        <translation>Begin met delen na creatie</translation>
    </message>
    <message>
        <source>Create and save...</source>
        <translation>Aanmaken en opslaan...</translation>
    </message>
    <message>
        <source>Progress:</source>
        <translation>Voortgang:</translation>
    </message>
    <message>
        <source>Tracker URLs:</source>
        <translation>Tracker URLs:</translation>
    </message>
    <message>
        <source>Web seeds urls:</source>
        <translation>Web seeds urls:</translation>
    </message>
    <message>
        <source>Comment:</source>
        <translation>Opmerkingen:</translation>
    </message>
    <message>
        <source>Auto</source>
        <translation>Auto</translation>
    </message>
</context>
<context>
    <name>createtorrent</name>
    <message>
        <source>Select destination torrent file</source>
        <translation type="obsolete">Kies torrent doelbestand</translation>
    </message>
    <message>
        <source>Torrent Files</source>
        <translation type="obsolete">Torrent bestanden</translation>
    </message>
    <message>
        <source>No input path set</source>
        <translation type="obsolete">Geen bron pad gekozen</translation>
    </message>
    <message>
        <source>Please type an input path first</source>
        <translation type="obsolete">Geef alstublieft eerst een doel pad</translation>
    </message>
    <message>
        <source>Torrent creation</source>
        <translation type="obsolete">Torrent maken</translation>
    </message>
    <message>
        <source>Torrent was created successfully:</source>
        <translation type="obsolete">Torrent was succesvol gemaakt:</translation>
    </message>
    <message>
        <source>Select a folder to add to the torrent</source>
        <translation type="obsolete">Selecteer een map om toe te voegen aan de torrent</translation>
    </message>
    <message>
        <source>Please type an announce URL</source>
        <translation type="obsolete">Type een announce URL</translation>
    </message>
    <message>
        <source>Torrent creation was unsuccessful, reason: %1</source>
        <translation type="obsolete">Fout tijdens het maken van torrent, reden: %1</translation>
    </message>
    <message>
        <source>Announce URL:</source>
        <comment>Tracker URL</comment>
        <translation type="obsolete">Announce URL:</translation>
    </message>
    <message>
        <source>Please type a web seed url</source>
        <translation type="obsolete">Type een web seed url</translation>
    </message>
    <message>
        <source>Web seed URL:</source>
        <translation type="obsolete">Web seed URL:</translation>
    </message>
    <message>
        <source>Select a file to add to the torrent</source>
        <translation type="obsolete">Selecteer een bestand om toe te voegen aan de torrent</translation>
    </message>
    <message>
        <source>Created torrent file is invalid. It won&apos;t be added to download list.</source>
        <translation type="obsolete">Gecreëerd torrent bestand is onjuist. Het wordt niet toegevoegd aan de downloadlijst.</translation>
    </message>
</context>
<context>
    <name>downloadFromURL</name>
    <message>
        <source>Download Torrents from URLs</source>
        <translation type="obsolete">Download Torrents via URLs</translation>
    </message>
    <message>
        <source>Only one URL per line</source>
        <translation type="obsolete">1 url per lijn</translation>
    </message>
    <message>
        <source>Download</source>
        <translation>Download</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Annuleren</translation>
    </message>
    <message>
        <source>Download from urls</source>
        <translation>Download uit urls</translation>
    </message>
    <message>
        <source>No URL entered</source>
        <translation>Geen URL ingevoerd</translation>
    </message>
    <message>
        <source>Please type at least one URL.</source>
        <translation>Typ op zijn minst één URL.</translation>
    </message>
    <message>
        <source>Add torrent links</source>
        <translation>Voeg torrent links toe</translation>
    </message>
    <message>
        <source>Both HTTP and Magnet links are supported</source>
        <translation>Zowel HTTP als Magnet links worden ondersteund</translation>
    </message>
</context>
<context>
    <name>downloadThread</name>
    <message>
        <source>I/O Error</source>
        <translation type="obsolete">I/O Fout</translation>
    </message>
    <message>
        <source>The remote host name was not found (invalid hostname)</source>
        <translation type="obsolete">De remote hostnaam werd niet gevonden (ongeldige hostnaam)</translation>
    </message>
    <message>
        <source>The operation was canceled</source>
        <translation type="obsolete">De operatie werd geannuleerd</translation>
    </message>
    <message>
        <source>The remote server closed the connection prematurely, before the entire reply was received and processed</source>
        <translation type="obsolete">De remote server sloot the verbinding permanent, voor the gehele reactie werd ontvangen en verwerkt</translation>
    </message>
    <message>
        <source>The connection to the remote server timed out</source>
        <translation type="obsolete">De verbinding naar de remote server timede out</translation>
    </message>
    <message>
        <source>SSL/TLS handshake failed</source>
        <translation type="obsolete">SSL/T|S handshake mislukt</translation>
    </message>
    <message>
        <source>The remote server refused the connection</source>
        <translation type="obsolete">De remote server weigerde de verbinding</translation>
    </message>
    <message>
        <source>The connection to the proxy server was refused</source>
        <translation type="obsolete">De verbinding naar de proxy server werd geweigerd</translation>
    </message>
    <message>
        <source>The proxy server closed the connection prematurely</source>
        <translation type="obsolete">De proxy server sloot de verbinding permanent</translation>
    </message>
    <message>
        <source>The proxy host name was not found</source>
        <translation type="obsolete">De proxy host name werd niet gevonden</translation>
    </message>
    <message>
        <source>The connection to the proxy timed out or the proxy did not reply in time to the request sent</source>
        <translation type="obsolete">De verbinding naar de proxy timede out of the proxy reageerde niet op tijd op het verzonden verzoek</translation>
    </message>
    <message>
        <source>The proxy requires authentication in order to honour the request but did not accept any credentials offered</source>
        <translation type="obsolete">De proxy vereist authenticatie om in te kunnen gaan op het verzoek maar accepteerde geen van de aangeboden credentials</translation>
    </message>
    <message>
        <source>The access to the remote content was denied (401)</source>
        <translation type="obsolete">De toegang tot de remote content werd genegeerd (401)</translation>
    </message>
    <message>
        <source>The operation requested on the remote content is not permitted</source>
        <translation type="obsolete">De gevraagde operatie op de remote content is niet toegestaan</translation>
    </message>
    <message>
        <source>The remote content was not found at the server (404)</source>
        <translation type="obsolete">De remote content werd niet gevonden op de server (404)</translation>
    </message>
    <message>
        <source>The remote server requires authentication to serve the content but the credentials provided were not accepted</source>
        <translation type="obsolete">De remote server vereist authenticatie om de inhoud te presenteren maar de gegeven credentials werden niet geaccepteerd</translation>
    </message>
    <message>
        <source>The Network Access API cannot honor the request because the protocol is not known</source>
        <translation type="obsolete">De Network Access API kon niet ingaan op het verzoek want het protocol is niet bekend</translation>
    </message>
    <message>
        <source>The requested operation is invalid for this protocol</source>
        <translation type="obsolete">De verzochte operatie is niet geldig voor dit protocol</translation>
    </message>
    <message>
        <source>An unknown network-related error was detected</source>
        <translation type="obsolete">Een onbekende netwerkgerelateerde fout werd gevonden</translation>
    </message>
    <message>
        <source>An unknown proxy-related error was detected</source>
        <translation type="obsolete">Een onbekende proxy-gerelateerde fout werd gevonden</translation>
    </message>
    <message>
        <source>An unknown error related to the remote content was detected</source>
        <translation type="obsolete">Een onbekende error gerelateerd tot de remote content werd gevonden</translation>
    </message>
    <message>
        <source>A breakdown in protocol was detected</source>
        <translation type="obsolete">Een storing in het protocol werd gedetecteerd</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation type="obsolete">Onbekende fout</translation>
    </message>
</context>
<context>
    <name>engineSelect</name>
    <message>
        <source>Search plugins</source>
        <translation>Zoekplugins</translation>
    </message>
    <message>
        <source>Installed search engines:</source>
        <translation>Geïnstalleerde zoekplugins:</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Naam</translation>
    </message>
    <message>
        <source>Url</source>
        <translation>Url</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Ingeschakeld</translation>
    </message>
    <message>
        <source>Install a new one</source>
        <translation>Installeer een nieuwe</translation>
    </message>
    <message>
        <source>Check for updates</source>
        <translation>Controleer op updates</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Sluiten</translation>
    </message>
    <message>
        <source>Enable</source>
        <translation type="obsolete">Inschakelen</translation>
    </message>
    <message>
        <source>Disable</source>
        <translation type="obsolete">Uitschakelen</translation>
    </message>
    <message>
        <source>Uninstall</source>
        <translation>Deïnstalleren</translation>
    </message>
    <message>
        <source>You can get new search engine plugins here: &lt;a href=&quot;http://plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</source>
        <translation>U kan hier nieuwe zoekmachineplugins vinden:&lt;a href=&quot;http://plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</translation>
    </message>
</context>
<context>
    <name>engineSelectDlg</name>
    <message>
        <source>Uninstall warning</source>
        <translation>Deïnstallatie waarschuwing</translation>
    </message>
    <message>
        <source>Some plugins could not be uninstalled because they are included in qBittorrent.
 Only the ones you added yourself can be uninstalled.
However, those plugins were disabled.</source>
        <translation>Niet alle plugins konden worden gedeïnstalleerd omdat ze bij qBittorrent horen.
Alleen de door u toegevoegde plugins kunnen worden gedeïnstalleerd.
De plugins zijn uitgeschakeld.</translation>
    </message>
    <message>
        <source>Uninstall success</source>
        <translation>Deïnstallatie succesvol</translation>
    </message>
    <message>
        <source>Select search plugins</source>
        <translation>Kies zoekplugins</translation>
    </message>
    <message>
        <source>qBittorrent search plugins</source>
        <translation>qBittorrent zoekplugins</translation>
    </message>
    <message>
        <source>Search plugin install</source>
        <translation>Zoekplugins installatie</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Nee</translation>
    </message>
    <message>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <source>A more recent version of %1 search engine plugin is already installed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>Een nieuwere versie van %1 zoekmachineplugin is al geïnstalleerd.</translation>
    </message>
    <message>
        <source>Search plugin update</source>
        <translation>Zoekplugin update</translation>
    </message>
    <message>
        <source>Sorry, update server is temporarily unavailable.</source>
        <translation>Sorry, updateserver is tijdelijk niet bereikbaar.</translation>
    </message>
    <message>
        <source>All your plugins are already up to date.</source>
        <translation>Uw plugins zijn al het nieuwst.</translation>
    </message>
    <message>
        <source>All selected plugins were uninstalled successfully</source>
        <translation>Alle gekozen plugins zijn succesvol gedeïnstalleerd</translation>
    </message>
    <message>
        <source>%1 search engine plugin could not be updated, keeping old version.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>%1 zoekmachineplugin kon niet worden vernieuwd. Oude versie wordt behouden.</translation>
    </message>
    <message>
        <source>%1 search engine plugin could not be installed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>%1 zoekmachineplugin kon niet worden geïnstalleerd.</translation>
    </message>
    <message>
        <source>%1 search engine plugin was successfully updated.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>%1 zoekmachineplugin is succesvol vernieuwd.</translation>
    </message>
    <message>
        <source>%1 search engine plugin was successfully installed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>%1 zoekmachineplugin is succesvol geïnstalleerd.</translation>
    </message>
    <message>
        <source>Sorry, %1 search plugin install failed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>%1 zoekplugin installatie mislukt.</translation>
    </message>
    <message>
        <source>New search engine plugin URL</source>
        <translation>Nieuwe zoekmachineplugin URL</translation>
    </message>
    <message>
        <source>URL:</source>
        <translation>URL:</translation>
    </message>
</context>
<context>
    <name>misc</name>
    <message>
        <source>B</source>
        <comment>bytes</comment>
        <translation>B</translation>
    </message>
    <message>
        <source>KiB</source>
        <comment>kibibytes (1024 bytes)</comment>
        <translation>KiB</translation>
    </message>
    <message>
        <source>MiB</source>
        <comment>mebibytes (1024 kibibytes)</comment>
        <translation>MiB</translation>
    </message>
    <message>
        <source>GiB</source>
        <comment>gibibytes (1024 mibibytes)</comment>
        <translation>GiB</translation>
    </message>
    <message>
        <source>TiB</source>
        <comment>tebibytes (1024 gibibytes)</comment>
        <translation>TiB</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Onbekend</translation>
    </message>
    <message>
        <source>Unknown</source>
        <comment>Unknown (size)</comment>
        <translation>Onbekend</translation>
    </message>
    <message>
        <source>&lt; 1m</source>
        <comment>&lt; 1 minute</comment>
        <translation>&lt; 1m</translation>
    </message>
    <message>
        <source>%1m</source>
        <comment>e.g: 10minutes</comment>
        <translation>%1m</translation>
    </message>
    <message>
        <source>%1h %2m</source>
        <comment>e.g: 3hours 5minutes</comment>
        <translation>%1u %2m</translation>
    </message>
    <message>
        <source>%1d %2h</source>
        <comment>e.g: 2days 10hours</comment>
        <translation>%1d %2u</translation>
    </message>
    <message>
        <source>qBittorrent will shutdown the computer now because all downloads are complete.</source>
        <translation>qBittorrent zal de computer afsluiten, want alle downloads zijn voltooid.</translation>
    </message>
</context>
<context>
    <name>options_imp</name>
    <message>
        <source>Choose a save directory</source>
        <translation>Kies een opslagmap</translation>
    </message>
    <message>
        <source>Choose an ip filter file</source>
        <translation>Kies een ip filter bestand</translation>
    </message>
    <message>
        <source>Filters</source>
        <translation>Filters</translation>
    </message>
    <message>
        <source>Choose export directory</source>
        <translation>Kies export map</translation>
    </message>
    <message>
        <source>Add directory to scan</source>
        <translation>Voeg map toe aan scannen</translation>
    </message>
    <message>
        <source>Folder is already being watched.</source>
        <translation>Map wordt reeds bekeken.</translation>
    </message>
    <message>
        <source>Folder does not exist.</source>
        <translation>Map bestaat niet.</translation>
    </message>
    <message>
        <source>Folder is not readable.</source>
        <translation>Map kan niet gelezen worden.</translation>
    </message>
    <message>
        <source>Failure</source>
        <translation>Fout</translation>
    </message>
    <message>
        <source>Failed to add Scan Folder &apos;%1&apos;: %2</source>
        <translation>Mislukt om scan map toe te voegen &apos;%1&apos;: %2</translation>
    </message>
    <message>
        <source>Parsing error</source>
        <translation>Ontledings error</translation>
    </message>
    <message>
        <source>Failed to parse the provided IP filter</source>
        <translation>Mislukt om de opgegeven IP filter te ontleden</translation>
    </message>
    <message>
        <source>Succesfully refreshed</source>
        <translation type="obsolete">Succesvol vernieuwd</translation>
    </message>
    <message>
        <source>Successfuly parsed the provided IP filter: %1 rules were applied.</source>
        <comment>%1 is a number</comment>
        <translation>De opgegeven IP filter werd succesvol ontleed: %1 regels werden toegepast.</translation>
    </message>
    <message>
        <source>Successfully refreshed</source>
        <translation>Succesvol vernieuwd</translation>
    </message>
    <message>
        <source>SSL Certificate (*.crt *.pem)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SSL Key (*.key *.pem)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This is not a valid SSL key.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid certificate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This is not a valid SSL certificate.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>pluginSourceDlg</name>
    <message>
        <source>Plugin source</source>
        <translation>Pluginbron</translation>
    </message>
    <message>
        <source>Search plugin source:</source>
        <translation>Zoekpluginbron:</translation>
    </message>
    <message>
        <source>Local file</source>
        <translation>Lokaal bestand</translation>
    </message>
    <message>
        <source>Web link</source>
        <translation>Weblink</translation>
    </message>
</context>
<context>
    <name>preview</name>
    <message>
        <source>Preview selection</source>
        <translation>Vooruitblik selectie</translation>
    </message>
    <message>
        <source>File preview</source>
        <translation>Bestand vooruitblik</translation>
    </message>
    <message>
        <source>The following files support previewing, &lt;br&gt;please select one of them:</source>
        <translation>De volgende bestanden ondersteunen vooruitkijken.
selecteer alstublieft een er van:</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Vooruitblik</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Annuleren</translation>
    </message>
</context>
<context>
    <name>previewSelect</name>
    <message>
        <source>Preview impossible</source>
        <translation type="obsolete">Vooruitkijken onmogelijk</translation>
    </message>
    <message>
        <source>Sorry, we can&apos;t preview this file</source>
        <translation type="obsolete">Sorry, we kunnen dit bestand niet vooruit bekijken</translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="obsolete">Naam</translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="obsolete">Grootte</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation type="obsolete">Voortgang</translation>
    </message>
</context>
<context>
    <name>search_engine</name>
    <message>
        <source>Search</source>
        <translation>Zoeken</translation>
    </message>
    <message>
        <source>Status:</source>
        <translation>Status:</translation>
    </message>
    <message>
        <source>Stopped</source>
        <translation>Gestopt</translation>
    </message>
    <message>
        <source>Download</source>
        <translation>Download</translation>
    </message>
    <message>
        <source>Search engines...</source>
        <translation>Zoekmachines...</translation>
    </message>
    <message>
        <source>Go to description page</source>
        <translation>Ga naar de beschrijvingspagina</translation>
    </message>
</context>
<context>
    <name>torrentAdditionDialog</name>
    <message>
        <source>Unable to decode torrent file:</source>
        <translation>Torrentfile kan niet gedecodeerd worden:</translation>
    </message>
    <message>
        <source>Choose save path</source>
        <translation>Kies opslag pad</translation>
    </message>
    <message>
        <source>(%1 left after torrent download)</source>
        <comment>e.g. (100MiB left after torrent download)</comment>
        <translation>(%1 over na torrent download)</translation>
    </message>
    <message>
        <source>(%1 more are required to download)</source>
        <comment>e.g. (100MiB more are required to download)</comment>
        <translation>(%1 extra is nodig om te downloaden)</translation>
    </message>
    <message>
        <source>Empty save path</source>
        <translation>Leeg opslag pad</translation>
    </message>
    <message>
        <source>Please enter a save path</source>
        <translation>Geef alstublieft een opslag pad</translation>
    </message>
    <message>
        <source>Save path creation error</source>
        <translation>Opslag pad aanmaak fout</translation>
    </message>
    <message>
        <source>Could not create the save path</source>
        <translation>Kon het opslag pad niet aanmaken</translation>
    </message>
    <message>
        <source>Invalid file selection</source>
        <translation>Ongeldige bestand selectie</translation>
    </message>
    <message>
        <source>You must select at least one file in the torrent</source>
        <translation>U moet tenminste een bestand in de torrent selecteren</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Prioriteit</translation>
    </message>
    <message>
        <source>Seeding mode error</source>
        <translation>Seeding modus fout</translation>
    </message>
    <message>
        <source>You chose to skip file checking. However, local files do not seem to exist in the current destionation folder. Please disable this feature or update the save path.</source>
        <translation>U kiest ervoor om bestandscontrole over te slaan. Alhoewel, lokale bestanden blijken niet te bestaan in de huidige bestemmingsmap. Gelieve deze feature uit te schakelen of update het opslagpad.</translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation>Hernoemen...</translation>
    </message>
    <message>
        <source>New name:</source>
        <translation>Nieuwe naam:</translation>
    </message>
    <message>
        <source>The file could not be renamed</source>
        <translation>Dit bestand kon niet hernoemd worden</translation>
    </message>
    <message>
        <source>This name is already in use in this folder. Please use a different name.</source>
        <translation>Deze naam bestaat reeds in deze map. Gelieve een andere naam te gebruiken.</translation>
    </message>
    <message>
        <source>The folder could not be renamed</source>
        <translation>Deze map kon niet hernoemd worden</translation>
    </message>
    <message>
        <source>Rename the file</source>
        <translation>Hernoem het bestand</translation>
    </message>
    <message>
        <source>Unable to decode magnet link:</source>
        <translation></translation>
    </message>
    <message>
        <source>Magnet Link</source>
        <translation>Magnetlink</translation>
    </message>
    <message>
        <source>Invalid label name</source>
        <translation>Ongeldige labelnaam</translation>
    </message>
    <message>
        <source>Please don&apos;t use any special characters in the label name.</source>
        <translation>Gelieve geen speciale characters te gebruiken in de labelnaam.</translation>
    </message>
    <message>
        <source>This file name contains forbidden characters, please choose a different one.</source>
        <translation>Deze bestandsnaam bevat verboden character, gelieve een andere te kiezen.</translation>
    </message>
</context>
</TS>
