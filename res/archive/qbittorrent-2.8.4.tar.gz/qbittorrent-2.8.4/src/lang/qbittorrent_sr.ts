<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="sr">
<context>
    <name>AboutDlg</name>
    <message>
        <source>About qBittorrent</source>
        <translation>O qBittorrent-у</translation>
    </message>
    <message>
        <source>About</source>
        <translation>О програму</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Аутор</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation>Име:</translation>
    </message>
    <message>
        <source>Country:</source>
        <translation>Земља:</translation>
    </message>
    <message>
        <source>E-mail:</source>
        <translation>Електронска-пошта:</translation>
    </message>
    <message>
        <source>Christophe Dumez</source>
        <translation>Christophe Dumez</translation>
    </message>
    <message>
        <source>France</source>
        <translation>Француска</translation>
    </message>
    <message>
        <source>Translation</source>
        <translatorcomment>by Anaximandar</translatorcomment>
        <translation>Превод</translation>
    </message>
    <message>
        <source>License</source>
        <translation>Лиценца</translation>
    </message>
    <message>
        <source>&lt;h3&gt;&lt;b&gt;qBittorrent&lt;/b&gt;&lt;/h3&gt;</source>
        <translation>&lt;h3&gt;&lt;b&gt;qBittorrent&lt;/b&gt;&lt;/h3&gt;</translation>
    </message>
    <message>
        <source>chris@qbittorrent.org</source>
        <translation>chris@qbittorrent.org</translation>
    </message>
    <message>
        <source>Thanks to</source>
        <translation>Хвала на</translation>
    </message>
    <message utf8="true">
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;A Bittorrent client programmed in C++, based on Qt4 toolkit &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;and libtorrent-rasterbar. &lt;br /&gt;&lt;br /&gt;Copyright ©2006-2010 Christophe Dumez&lt;br /&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Home Page:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://www.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;http://www.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Forum:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://forum.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;http://forum.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;IRC:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; #qbittorrent on Freenode&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;Бит-торен клијент програмиран у C++, базиран на Qt4 програмском алату &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;и libtorrent-rasterbar-у. &lt;br /&gt;&lt;br /&gt;Copyright ©2006-2010 Christophe Dumez&lt;br /&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Home Page:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://www.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;http://www.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Forum:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://forum.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;http://forum.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;IRC:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; #qbittorrent on Freenode&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message utf8="true">
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;An advanced BitTorrent client programmed in C++, based on Qt4 toolkit and libtorrent-rasterbar. &lt;br /&gt;&lt;br /&gt;Copyright ©2006-2011 Christophe Dumez&lt;br /&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Home Page:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://www.qbittorrent.org&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans&apos;; text-decoration: underline; color:#0057ae;&quot;&gt;http://www.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Bug Tracker:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://bugs.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;http://bugs.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Forum:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://forum.qbittorrent.org&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans&apos;; text-decoration: underline; color:#0057ae;&quot;&gt;http://forum.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;IRC:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; #qbittorrent on Freenode&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;Напредни Бит-торен клијент програмиран у C++, базиран на Qt4 програмском алату и libtorrent-rasterbar-у. &lt;br /&gt;&lt;br /&gt;Copyright ©2006-2011 Christophe Dumez&lt;br /&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Home Page:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://www.qbittorrent.org&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans&apos;; text-decoration: underline; color:#0057ae;&quot;&gt;http://www.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Bug Tracker:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://bugs.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;http://bugs.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Forum:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://forum.qbittorrent.org&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans&apos;; text-decoration: underline; color:#0057ae;&quot;&gt;http://forum.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;IRC:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; #qbittorrent on Freenode&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
</context>
<context>
    <name>AdvancedSettings</name>
    <message>
        <source>Property</source>
        <translation type="obsolete">Својства</translation>
    </message>
    <message>
        <source>Value</source>
        <translation type="obsolete">Вредност</translation>
    </message>
    <message>
        <source>Disk write cache size</source>
        <translation>Величина кеша Диска</translation>
    </message>
    <message>
        <source> MiB</source>
        <translation> MiB</translation>
    </message>
    <message>
        <source>Outgoing ports (Min) [0: Disabled]</source>
        <translation>Одлазних портова (Min) [0: Искључено]</translation>
    </message>
    <message>
        <source>Outgoing ports (Max) [0: Disabled]</source>
        <translation>Одлазних портова (Max) [0: Искључено]</translation>
    </message>
    <message>
        <source>Recheck torrents on completion</source>
        <translation>Провери торенте на завршетку</translation>
    </message>
    <message>
        <source>Transfer list refresh interval</source>
        <translation>Трансфер листа интервал освежавања</translation>
    </message>
    <message>
        <source> ms</source>
        <comment> milliseconds</comment>
        <translatorcomment>милисекунди</translatorcomment>
        <translation> ms</translation>
    </message>
    <message>
        <source>Resolve peer countries (GeoIP)</source>
        <translation>Одреди земљу peer-а (учесника) (GeoIP)</translation>
    </message>
    <message>
        <source>Resolve peer host names</source>
        <translation>Одреди име хоста peer-а (учесника)</translation>
    </message>
    <message>
        <source>Ignore transfer limits on local network</source>
        <translation>Игнориши ограничење преноса на локалној мрежи</translation>
    </message>
    <message>
        <source>Include TCP/IP overhead in transfer limits</source>
        <translation type="obsolete">Укључи TCP/IP прекорачење при ограничењу преноса</translation>
    </message>
    <message>
        <source>Maximum number of half-open connections [0: Disabled]</source>
        <translation>Максимални број полу-отворених конекција [0: Онемогућено]</translation>
    </message>
    <message>
        <source>Strict super seeding</source>
        <translatorcomment>донирање-seeding</translatorcomment>
        <translation>Искључиво супер донирање (seeding)</translation>
    </message>
    <message>
        <source>Network Interface (requires restart)</source>
        <translation>Мрежни интерфејс (захтева рестарт)</translation>
    </message>
    <message>
        <source>Any interface</source>
        <comment>i.e. Any network interface</comment>
        <translation>Било који мрежни интерфејс</translation>
    </message>
    <message>
        <source>Display program notification baloons</source>
        <translation type="obsolete">Прикажи балоне са програмским коментарима</translation>
    </message>
    <message>
        <source>Display program notification balloons</source>
        <translation type="obsolete">Прикажи балоне са програмским коментарима</translation>
    </message>
    <message>
        <source>Enable embedded tracker</source>
        <translation>Омогући уграђени пратилац</translation>
    </message>
    <message>
        <source>Embedded tracker port</source>
        <translation>Уграђени пратилац порта</translation>
    </message>
    <message>
        <source>Check for software updates</source>
        <translation>Проверите за надоградњу софтвера</translation>
    </message>
    <message>
        <source>Use system icon theme</source>
        <translation>Користи тему системских икона</translation>
    </message>
    <message>
        <source>Confirm torrent deletion</source>
        <translation>Потврда брисања торента</translation>
    </message>
    <message>
        <source>IP Address to report to trackers (requires restart)</source>
        <translation>IP адресни извештај о пратиоцима (захтева рестарт)</translation>
    </message>
    <message>
        <source>Display program on-screen notifications</source>
        <translation>Прикажи програмска обавештења на екрану</translation>
    </message>
    <message>
        <source>Setting</source>
        <translation>Подешавање</translation>
    </message>
    <message>
        <source>Value</source>
        <comment>Value set for this setting</comment>
        <translation>Вредност</translation>
    </message>
    <message>
        <source>Exchange trackers with other peers</source>
        <translation>Размена претилаца са осталим учесницима</translation>
    </message>
</context>
<context>
    <name>AutomatedRssDownloader</name>
    <message>
        <source>Automated RSS Downloader</source>
        <translation>Аутоматизовани RSS преузимач</translation>
    </message>
    <message>
        <source>Enable the automated RSS downloader</source>
        <translation>Омогући аутоматско преузимање RSS порука</translation>
    </message>
    <message>
        <source>Download rules</source>
        <translation>Правила преузимања</translation>
    </message>
    <message>
        <source>Rule definition</source>
        <translation>Дефинисање правила</translation>
    </message>
    <message>
        <source>Must contain:</source>
        <translation>Мора да садржи:</translation>
    </message>
    <message>
        <source>Must not contain:</source>
        <translation>Не треба да садржи:</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Assign label:</source>
        <translation>Додели ознаку:</translation>
    </message>
    <message>
        <source>Apply rule to feeds:</source>
        <translatorcomment>feeds-поруке;фидови;канали</translatorcomment>
        <translation>Примени правило на поруке:</translation>
    </message>
    <message>
        <source>Matching RSS articles</source>
        <translation>Усклађивање RSS чланака</translation>
    </message>
    <message>
        <source>Save to a different directory</source>
        <translation>Сачувај у другом директоријуму</translation>
    </message>
    <message>
        <source>Save to:</source>
        <translation>Сачувај у:</translation>
    </message>
    <message>
        <source>Import...</source>
        <translation>Увези...</translation>
    </message>
    <message>
        <source>Export...</source>
        <translation>Извези...</translation>
    </message>
    <message>
        <source>New rule name</source>
        <translation>Назив новог правила</translation>
    </message>
    <message>
        <source>Please type the name of the new download rule.</source>
        <translation>Молим упишите назив новог правила преузимања.</translation>
    </message>
    <message>
        <source>Rule name conflict</source>
        <translation>Конфликт у називу правила</translation>
    </message>
    <message>
        <source>A rule with this name already exists, please choose another name.</source>
        <translation>Правило са овим називом већ постоји, молим изаберите неки други назив.</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the download rule named %1?</source>
        <translation>Да ли сте сигурни да желите да уклоните правило преузимања назива %1?</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the selected download rules?</source>
        <translation>Да ли сте сигурни да желите да уклоните изабрана правила преузимања?</translation>
    </message>
    <message>
        <source>Rule deletion confirmation</source>
        <translation>Потврда брисања - правила</translation>
    </message>
    <message>
        <source>Destination directory</source>
        <translation>Одредишни директоријум</translation>
    </message>
    <message>
        <source>Invalid action</source>
        <translation>Неважећа акција</translation>
    </message>
    <message>
        <source>The list is empty, there is nothing to export.</source>
        <translation>Листа је празна, не постоји ништа за извоз.</translation>
    </message>
    <message>
        <source>Where would you like to save the list?</source>
        <translation>Где желите да сачувате листу?</translation>
    </message>
    <message>
        <source>Rules list (*.rssrules)</source>
        <translation>Листа правила (*.rssrules)</translation>
    </message>
    <message>
        <source>I/O Error</source>
        <translation>И/О Грешка</translation>
    </message>
    <message>
        <source>Failed to create the destination file</source>
        <translation>Грешка при креирању циљне датотеке</translation>
    </message>
    <message>
        <source>Please point to the RSS download rules file</source>
        <translation>Молим укажите на RSS датотеку са правилима преузимања</translation>
    </message>
    <message>
        <source>Rules list (*.rssrules *.filters)</source>
        <translation>Листа правила (*.rssrules *.filters)</translation>
    </message>
    <message>
        <source>Import Error</source>
        <translation>Грешка при увозу</translation>
    </message>
    <message>
        <source>Failed to import the selected rules file</source>
        <translation>Грешка при увозу изабране датотеке са правилима</translation>
    </message>
    <message>
        <source>Add new rule...</source>
        <translation>Додај ново правило...</translation>
    </message>
    <message>
        <source>Delete rule</source>
        <translation>Обриши правило</translation>
    </message>
    <message>
        <source>Rename rule...</source>
        <translation>Преименуј правило...</translation>
    </message>
    <message>
        <source>Delete selected rules</source>
        <translation>Обриши изабрана правила</translation>
    </message>
    <message>
        <source>Rule renaming</source>
        <translation>Преименовање правила</translation>
    </message>
    <message>
        <source>Please type the new rule name</source>
        <translation>Молим упишите назив за ново правило</translation>
    </message>
    <message>
        <source>Use regular expressions</source>
        <translation>Користите регуларне изразе</translation>
    </message>
    <message>
        <source>Regex mode: use Perl-like regular expressions</source>
        <translation>Regex мод: користи слично Perl-у регуларне изразе</translation>
    </message>
    <message>
        <source>Wildcard mode: you can use&lt;ul&gt;&lt;li&gt;? to match any single character&lt;/li&gt;&lt;li&gt;* to match zero or more of any characters&lt;/li&gt;&lt;li&gt;Whitespaces count as AND operators&lt;/li&gt;&lt;/ul&gt;</source>
        <translation>Џокер мод: можете користити&lt;ul&gt;&lt;li&gt;? да представља било који појединачни карактер&lt;/li&gt;&lt;li&gt;* да представља нулу или било које друге карактере&lt;/li&gt;&lt;li&gt;Размак број као AND операторе&lt;/li&gt;&lt;/ul&gt;</translation>
    </message>
    <message>
        <source>Wildcard mode: you can use&lt;ul&gt;&lt;li&gt;? to match any single character&lt;/li&gt;&lt;li&gt;* to match zero or more of any characters&lt;/li&gt;&lt;li&gt;| is used as OR operator&lt;/li&gt;&lt;/ul&gt;</source>
        <translation>Џокер мод: можете користити&lt;ul&gt;&lt;li&gt;? да представља било који појединачни карактер&lt;/li&gt;&lt;li&gt;* да представља нулу или било које друге карактере&lt;/li&gt;&lt;li&gt;| се користи као OR оператор&lt;/li&gt;&lt;/ul&gt;</translation>
    </message>
</context>
<context>
    <name>Bittorrent</name>
    <message>
        <source>%1 reached the maximum ratio you set.</source>
        <translation type="obsolete">%1 достигао је максимални ниво који сте подесили.</translation>
    </message>
    <message>
        <source>qBittorrent is bound to port: TCP/%1</source>
        <comment>e.g: qBittorrent is bound to port: 6881</comment>
        <translatorcomment>н.пр.: qBittorrent је повезан на порт: 6881</translatorcomment>
        <translation type="obsolete">qBittorrent је повезан на порт: TCP/%1</translation>
    </message>
    <message>
        <source>UPnP support [ON]</source>
        <translation type="obsolete">UPnP подршка [Укључена]</translation>
    </message>
    <message>
        <source>UPnP support [OFF]</source>
        <translation type="obsolete">UPnP подршка [Искључена]</translation>
    </message>
    <message>
        <source>NAT-PMP support [ON]</source>
        <translation type="obsolete">NAT-PMP подршка [Укључена]</translation>
    </message>
    <message>
        <source>NAT-PMP support [OFF]</source>
        <translation type="obsolete">NAT-PMP подршка [Искључена]</translation>
    </message>
    <message>
        <source>HTTP user agent is %1</source>
        <translation type="obsolete">HTTP кориснички агент је %1</translation>
    </message>
    <message>
        <source>Using a disk cache size of %1 MiB</source>
        <translation type="obsolete">Користи кеш диска величине %1 MiB</translation>
    </message>
    <message>
        <source>DHT support [ON], port: UDP/%1</source>
        <translation type="obsolete">DHT подршка [Укључена], порт: UDP/%1</translation>
    </message>
    <message>
        <source>DHT support [OFF]</source>
        <translation type="obsolete">DHT подршка [Искључена]</translation>
    </message>
    <message>
        <source>PeX support [ON]</source>
        <translation type="obsolete">PeX подршка [Укључена]</translation>
    </message>
    <message>
        <source>PeX support [OFF]</source>
        <translation type="obsolete">PeX подршка [Искључена]</translation>
    </message>
    <message>
        <source>Restart is required to toggle PeX support</source>
        <translation type="obsolete">Рестарт је потребан за укључивање PeX подршке</translation>
    </message>
    <message>
        <source>Local Peer Discovery [ON]</source>
        <translatorcomment>Peer-Учесник</translatorcomment>
        <translation type="obsolete">Претраживање локалних веза [Укључено]</translation>
    </message>
    <message>
        <source>Local Peer Discovery support [OFF]</source>
        <translatorcomment>Peer-Учесник</translatorcomment>
        <translation type="obsolete">Претраживање локалних веза подршка [Искључено]</translation>
    </message>
    <message>
        <source>Encryption support [ON]</source>
        <translation type="obsolete">Шифровање подршка [Укључена]</translation>
    </message>
    <message>
        <source>Encryption support [FORCED]</source>
        <translation type="obsolete">Шифровање подршка [Форсирано]</translation>
    </message>
    <message>
        <source>Encryption support [OFF]</source>
        <translation type="obsolete">Шифровање подршка [Искључена]</translation>
    </message>
    <message>
        <source>The Web UI is listening on port %1</source>
        <translation type="obsolete">Веб КИ надгледа порт %1</translation>
    </message>
    <message>
        <source>Web User Interface Error - Unable to bind Web UI to port %1</source>
        <translation type="obsolete">Веб Кориснички Интерфејс Грешка - Не могу да повежем Веб КИ на порт %1</translation>
    </message>
    <message>
        <source>&apos;%1&apos; was removed from transfer list and hard disk.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translatorcomment>&apos;xxx.avi&apos; је уклоњен...</translatorcomment>
        <translation type="obsolete">&apos;%1&apos; је уклоњен са трансфер листе и хард диска.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; was removed from transfer list.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translatorcomment>&apos;xxx.avi&apos; је уклоњен...</translatorcomment>
        <translation type="obsolete">&apos;%1&apos; је уклоњен са трансфер листе.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is not a valid magnet URI.</source>
        <translation type="obsolete">&apos;%1&apos; није валидан магнет URI.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is already in download list.</source>
        <comment>e.g: &apos;xxx.avi&apos; is already in download list.</comment>
        <translatorcomment>н.пр.: &apos;xxx.avi&apos; је већ на листи преузимања.</translatorcomment>
        <translation type="obsolete">&apos;%1&apos; већ је додат на листу за преузимање.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; resumed. (fast resume)</source>
        <comment>&apos;/home/y/xxx.torrent&apos; was resumed. (fast resume)</comment>
        <translatorcomment>&apos;/home/y/xxx.torrent&apos; је наставио. (брзи наставак)</translatorcomment>
        <translation type="obsolete">&apos;%1&apos; настави. (брзо настави)</translation>
    </message>
    <message>
        <source>&apos;%1&apos; added to download list.</source>
        <comment>&apos;/home/y/xxx.torrent&apos; was added to download list.</comment>
        <translatorcomment>&apos;/home/y/xxx.torrent&apos; је додат на листу преузимања.</translatorcomment>
        <translation type="obsolete">&apos;%1&apos; додат на листу за преузимање.</translation>
    </message>
    <message>
        <source>Unable to decode torrent file: &apos;%1&apos;</source>
        <comment>e.g: Unable to decode torrent file: &apos;/home/y/xxx.torrent&apos;</comment>
        <translatorcomment>н.пр.: Не може да декодира торент фајл: &apos;/home/y/xxx.torrent&apos;</translatorcomment>
        <translation type="obsolete">Није у стању да декодира торент фајл: &apos;%1&apos;</translation>
    </message>
    <message>
        <source>This file is either corrupted or this isn&apos;t a torrent.</source>
        <translation type="obsolete">Овај фајл је оштећен или ово није торент.</translation>
    </message>
    <message>
        <source>Note: new trackers were added to the existing torrent.</source>
        <translation type="obsolete">Напомена: нови пратиоци су додати у постојећи торент.</translation>
    </message>
    <message>
        <source>Note: new URL seeds were added to the existing torrent.</source>
        <translation type="obsolete">Напомена: нови URL донори су додати у постојећи торент.</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;was blocked due to your IP filter&lt;/i&gt;</source>
        <comment>x.y.z.w was blocked</comment>
        <translatorcomment>x.y.z.w је блокиран</translatorcomment>
        <translation type="obsolete">&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;је блокиран због вашег IP филтера&lt;/i&gt;</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;was banned due to corrupt pieces&lt;/i&gt;</source>
        <comment>x.y.z.w was banned</comment>
        <translatorcomment>x.y.z.w је одбачен</translatorcomment>
        <translation type="obsolete">&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;је одбачен због оштећених делова&lt;/i&gt;</translation>
    </message>
    <message>
        <source>Recursive download of file %1 embedded in torrent %2</source>
        <comment>Recursive download of test.torrent embedded in torrent test2</comment>
        <translation type="obsolete">Поновно преузимање фајла %1 омогућено у торенту %2</translation>
    </message>
    <message>
        <source>Unable to decode %1 torrent file.</source>
        <translation type="obsolete">Није у стању да декодира %1 торент фајл.</translation>
    </message>
    <message>
        <source>UPnP/NAT-PMP: Port mapping failure, message: %1</source>
        <translation type="obsolete">UPnP/NAT-PMP: Порт мапирање грешка, порука: %1</translation>
    </message>
    <message>
        <source>UPnP/NAT-PMP: Port mapping successful, message: %1</source>
        <translation type="obsolete">UPnP/NAT-PMP: Порт мапирање успешно, порука: %1</translation>
    </message>
    <message>
        <source>Fast resume data was rejected for torrent %1, checking again...</source>
        <translation type="obsolete">Брзи наставак података је одбијен за торент %1, покушајте поново...</translation>
    </message>
    <message>
        <source>Reason: %1</source>
        <translation type="obsolete">Разлог: %1</translation>
    </message>
    <message>
        <source>An I/O error occured, &apos;%1&apos; paused.</source>
        <translation type="obsolete">Нека И/О грешка се догодила, &apos;%1&apos; паузирано.</translation>
    </message>
    <message>
        <source>Url seed lookup failed for url: %1, message: %2</source>
        <translation type="obsolete">Url преглед донора , грешка url: %1, порука: %2</translation>
    </message>
    <message>
        <source>Downloading &apos;%1&apos;, please wait...</source>
        <comment>e.g: Downloading &apos;xxx.torrent&apos;, please wait...</comment>
        <translatorcomment>н.пр.: Преузимам &apos;xxx.torrent&apos;, молим сачекајте...</translatorcomment>
        <translation type="obsolete">Преузимање &apos;%1&apos;, молим сачекајте...</translation>
    </message>
    <message>
        <source>Removing torrent %1...</source>
        <translation type="obsolete">Уклањање торента %1...</translation>
    </message>
    <message>
        <source>Pausing torrent %1...</source>
        <translation type="obsolete">Паузирање торента %1...</translation>
    </message>
    <message>
        <source>Error: The torrent %1 does not contain any file.</source>
        <translation type="obsolete">Грешка: Торент %1 не садржи ни један фајл.</translation>
    </message>
    <message>
        <source>File sizes mismatch for torrent %1, pausing it.</source>
        <translation type="obsolete">Величина фајла није одговарајућа за торент %1, паузирајте га.</translation>
    </message>
    <message>
        <source>Torrent name: %1</source>
        <translation type="obsolete">Име Торента: %1</translation>
    </message>
    <message>
        <source>Torrent size: %1</source>
        <translation type="obsolete">Величина Торента: %1</translation>
    </message>
    <message>
        <source>Save path: %1</source>
        <translation type="obsolete">Путања чувања: %1</translation>
    </message>
    <message>
        <source>The torrent was downloaded in %1.</source>
        <comment>The torrent was downloaded in 1 hour and 20 seconds</comment>
        <translation type="obsolete">Торент ће бити преузет за %1.</translation>
    </message>
    <message>
        <source>Thank you for using qBittorrent.</source>
        <translation type="obsolete">Хвала што користите qBittorrent.</translation>
    </message>
    <message>
        <source>[qBittorrent] %1 has finished downloading</source>
        <translation type="obsolete">[qBittorrent] %1 је завршио преузимање</translation>
    </message>
</context>
<context>
    <name>ConsoleDlg</name>
    <message>
        <source>General</source>
        <translation type="obsolete">Опште</translation>
    </message>
    <message>
        <source>Blocked IPs</source>
        <translation type="obsolete">Блокирани IP-и</translation>
    </message>
    <message>
        <source>qBittorrent log viewer</source>
        <translation type="obsolete">qBittorrent преглед дневника</translation>
    </message>
</context>
<context>
    <name>CookiesDlg</name>
    <message>
        <source>Cookies management</source>
        <translation>Управљање колачићима</translation>
    </message>
    <message>
        <source>Key</source>
        <extracomment>As in Key/Value pair</extracomment>
        <translation>Кључ</translation>
    </message>
    <message>
        <source>Value</source>
        <extracomment>As in Key/Value pair</extracomment>
        <translation>Вредност</translation>
    </message>
    <message>
        <source>Common keys for cookies are : &apos;%1&apos;, &apos;%2&apos;.
You should get this information from your Web browser preferences.</source>
        <translation>Уобичајени кључеви за колачиће су : &apos;%1&apos;, &apos;%2&apos;.
Требало би да добијете ове информације из подешавања вашег Веб читача.</translation>
    </message>
</context>
<context>
    <name>DNSUpdater</name>
    <message>
        <source>Your dynamic DNS was successfuly updated.</source>
        <translation>Ваш динамички DNS је успешно ажуриран.</translation>
    </message>
    <message>
        <source>Dynamic DNS error: The service is temporarily unavailable, it will be retried in 30 minutes.</source>
        <translation>Динамички DNS грешка: сервис је привремено недоступан, биће проверено за 30 минута.</translation>
    </message>
    <message>
        <source>Dynamic DNS error: hostname supplied does not exist under specified account.</source>
        <translation>Динамички DNS грешка: наведено име рачунара не постоји на специфираном налогу.</translation>
    </message>
    <message>
        <source>Dynamic DNS error: Invalid username/password.</source>
        <translation>Динамички DNS грешка: Погрешно корисничко име/лозинка.</translation>
    </message>
    <message>
        <source>Dynamic DNS error: qBittorrent was blacklisted by the service, please report a bug at http://bugs.qbittorrent.org.</source>
        <translation>Динамички DNS грешка: qBittorrent је на црној листи сервиса, пријавите грешку на http://bugs.qbittorrent.org.</translation>
    </message>
    <message>
        <source>Dynamic DNS error: %1 was returned by the service, please report a bug at http://bugs.qbittorrent.org.</source>
        <translation>Динамички DNS грешка: %1 је враћен од сервиса, пријавите грешку на http://bugs.qbittorrent.org.</translation>
    </message>
    <message>
        <source>Dynamic DNS error: Your username was blocked due to abuse.</source>
        <translation>Динамички DNS грешка: Ваше корисничко име је блокирано због злоупотребе.</translation>
    </message>
    <message>
        <source>Dynamic DNS error: supplied domain name is invalid.</source>
        <translation>Динамички DNS грешка: Наведено име домена је погрешно.</translation>
    </message>
    <message>
        <source>Dynamic DNS error: supplied username is too short.</source>
        <translation>Динамички DNS грешка: Наведено корисничко име је прекратко.</translation>
    </message>
    <message>
        <source>Dynamic DNS error: supplied password is too short.</source>
        <translation>Динамички DNS грешка: Наведена лозинка је прекратка.</translation>
    </message>
</context>
<context>
    <name>DownloadThread</name>
    <message>
        <source>I/O Error</source>
        <translation>И/О Грешка</translation>
    </message>
    <message>
        <source>The remote host name was not found (invalid hostname)</source>
        <translation>Име удаљеног рачунара није пронађено (неисправно име рачунара)</translation>
    </message>
    <message>
        <source>The operation was canceled</source>
        <translation>Операција је отказана</translation>
    </message>
    <message>
        <source>The remote server closed the connection prematurely, before the entire reply was received and processed</source>
        <translation>Удаљени сервер је прерано затворио конекцију, пре него што је цео одговор примљен и обрађен</translation>
    </message>
    <message>
        <source>The connection to the remote server timed out</source>
        <translation>Конекција на удаљени сервер је временски истекла (покушајте поново)</translation>
    </message>
    <message>
        <source>SSL/TLS handshake failed</source>
        <translation>SSL/TLS управљање неуспешно</translation>
    </message>
    <message>
        <source>The remote server refused the connection</source>
        <translation>Удаљени сервер не прихвата конекцију</translation>
    </message>
    <message>
        <source>The connection to the proxy server was refused</source>
        <translation>Конекција на прокси сервер је одбијена</translation>
    </message>
    <message>
        <source>The proxy server closed the connection prematurely</source>
        <translation>Прокси сервер је превремено затворио конекцију</translation>
    </message>
    <message>
        <source>The proxy host name was not found</source>
        <translation>Назив прокси сервера није пронађен</translation>
    </message>
    <message>
        <source>The connection to the proxy timed out or the proxy did not reply in time to the request sent</source>
        <translation>Време повезивања са прокси-јем је истекло, или прокси није одговорио када је захтев послат</translation>
    </message>
    <message>
        <source>The proxy requires authentication in order to honour the request but did not accept any credentials offered</source>
        <translation>Прокси захтева проверу идентитета да би испунио захтев али не прихвата понуђене акредитиве</translation>
    </message>
    <message>
        <source>The access to the remote content was denied (401)</source>
        <translation>Приступ удаљеном садржају је одбијен (401)</translation>
    </message>
    <message>
        <source>The operation requested on the remote content is not permitted</source>
        <translation>Захтевана операција за удаљеним садржајем се не одобрава</translation>
    </message>
    <message>
        <source>The remote content was not found at the server (404)</source>
        <translation>Захтевани садржај, није пронађен на серверу (404)</translation>
    </message>
    <message>
        <source>The remote server requires authentication to serve the content but the credentials provided were not accepted</source>
        <translation>Удаљени сервер захтева ауторизацију за слање садржаја, али дати акредитиви нису прихваћени</translation>
    </message>
    <message>
        <source>The Network Access API cannot honor the request because the protocol is not known</source>
        <translation>Мрежни приступ API-ја не може да се прихвати јер протокол није познат</translation>
    </message>
    <message>
        <source>The requested operation is invalid for this protocol</source>
        <translation>Захтевана операција је погрешна за овај протокол</translation>
    </message>
    <message>
        <source>An unknown network-related error was detected</source>
        <translation>Детектована је непозната грешка у вези са мрежом</translation>
    </message>
    <message>
        <source>An unknown proxy-related error was detected</source>
        <translation>Детектована је непозната грешка у вези са проксијем</translation>
    </message>
    <message>
        <source>An unknown error related to the remote content was detected</source>
        <translation>Детектована је непозната грешка у вези са удаљеним садржајем</translation>
    </message>
    <message>
        <source>A breakdown in protocol was detected</source>
        <translation>Детектован је проблем са протоколом</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Непозната грешка</translation>
    </message>
</context>
<context>
    <name>EventManager</name>
    <message>
        <source>Working</source>
        <translation>Ради</translation>
    </message>
    <message>
        <source>Updating...</source>
        <translation>Ажурирање...</translation>
    </message>
    <message>
        <source>Not working</source>
        <translation>Не ради</translation>
    </message>
    <message>
        <source>Not contacted yet</source>
        <translation>Није још контактиран</translation>
    </message>
    <message>
        <source>this session</source>
        <translation>ова сесија</translation>
    </message>
    <message>
        <source>/s</source>
        <comment>/second (i.e. per second)</comment>
        <translation>/s</translation>
    </message>
    <message>
        <source>Seeded for %1</source>
        <comment>e.g. Seeded for 3m10s</comment>
        <translation>Донирано за %1</translation>
    </message>
    <message>
        <source>%1 max</source>
        <comment>e.g. 10 max</comment>
        <translation>%1 max</translation>
    </message>
    <message>
        <source>%1/s</source>
        <comment>e.g. 120 KiB/s</comment>
        <translatorcomment>н.пр. 120 KiB/s</translatorcomment>
        <translation>%1/s</translation>
    </message>
</context>
<context>
    <name>ExecutionLog</name>
    <message>
        <source>Form</source>
        <translation type="obsolete">Образац</translation>
    </message>
    <message>
        <source>General</source>
        <translation>Опште</translation>
    </message>
    <message>
        <source>Blocked IPs</source>
        <translation>Блокирани IP-и</translation>
    </message>
</context>
<context>
    <name>FeedDownloader</name>
    <message>
        <source>RSS Feed downloader</source>
        <translatorcomment>Feed-допис,порука,канал</translatorcomment>
        <translation type="obsolete">RSS преузимач Порука</translation>
    </message>
    <message>
        <source>RSS feed:</source>
        <translatorcomment>feed-допис,порука,канал</translatorcomment>
        <translation type="obsolete">RSS допис:</translation>
    </message>
    <message>
        <source>Feed name</source>
        <translatorcomment>Feed-допис,порука,канал</translatorcomment>
        <translation type="obsolete">Име поруке</translation>
    </message>
    <message>
        <source>Automatically download torrents from this feed</source>
        <translation type="obsolete">Аутоматски преузми торенте са ових дописа</translation>
    </message>
    <message>
        <source>Download filters</source>
        <translation type="obsolete">Преузимање филтера</translation>
    </message>
    <message>
        <source>Filters:</source>
        <translation type="obsolete">Филтери:</translation>
    </message>
    <message>
        <source>Filter settings</source>
        <translation type="obsolete">Подешавања филтера</translation>
    </message>
    <message>
        <source>Matches:</source>
        <translation type="obsolete">Усклађен:</translation>
    </message>
    <message>
        <source>Does not match:</source>
        <translation type="obsolete">Неусклађен:</translation>
    </message>
    <message>
        <source>Destination folder:</source>
        <translation type="obsolete">Одредишна фасцикла:</translation>
    </message>
    <message>
        <source>...</source>
        <translation type="obsolete">...</translation>
    </message>
    <message>
        <source>Filter testing</source>
        <translation type="obsolete">Тестирање филтера</translation>
    </message>
    <message>
        <source>Torrent title:</source>
        <translation type="obsolete">Име Торента (наслов):</translation>
    </message>
    <message>
        <source>Result:</source>
        <translation type="obsolete">Резултат:</translation>
    </message>
    <message>
        <source>Test</source>
        <translation type="obsolete">Тест</translation>
    </message>
    <message>
        <source>Import...</source>
        <translation type="obsolete">Увези...</translation>
    </message>
    <message>
        <source>Export...</source>
        <translation type="obsolete">Извези...</translation>
    </message>
    <message>
        <source>Rename filter</source>
        <translation type="obsolete">Преименуј филтер</translation>
    </message>
    <message>
        <source>Remove filter</source>
        <translation type="obsolete">Уклони филтер</translation>
    </message>
    <message>
        <source>Add filter</source>
        <translation type="obsolete">Додај филтер</translation>
    </message>
</context>
<context>
    <name>FeedDownloaderDlg</name>
    <message>
        <source>New filter</source>
        <translation type="obsolete">Нови филтер</translation>
    </message>
    <message>
        <source>Please choose a name for this filter</source>
        <translation type="obsolete">Молим изаберите име за овај филтер</translation>
    </message>
    <message>
        <source>Filter name:</source>
        <translation type="obsolete">Име филтера:</translation>
    </message>
    <message>
        <source>Invalid filter name</source>
        <translation type="obsolete">Погрешно име филтера</translation>
    </message>
    <message>
        <source>The filter name cannot be left empty.</source>
        <translation type="obsolete">Име филтера не може бити празно.</translation>
    </message>
    <message>
        <source>This filter name is already in use.</source>
        <translation type="obsolete">Ово име филтера већ постоји.</translation>
    </message>
    <message>
        <source>Choose save path</source>
        <translation type="obsolete">Изаберите путању чувања</translation>
    </message>
    <message>
        <source>Filter testing error</source>
        <translation type="obsolete">Грешака тестирања филтера</translation>
    </message>
    <message>
        <source>Please specify a test torrent name.</source>
        <translation type="obsolete">Молим наведите неко тест име за торент.</translation>
    </message>
    <message>
        <source>matches</source>
        <translation type="obsolete">усклађен</translation>
    </message>
    <message>
        <source>does not match</source>
        <translation type="obsolete">неусклађен</translation>
    </message>
    <message>
        <source>Select file to import</source>
        <translation type="obsolete">Изаберите фајл за увоз</translation>
    </message>
    <message>
        <source>Filters Files</source>
        <translation type="obsolete">Филтер фајлови</translation>
    </message>
    <message>
        <source>Import successful</source>
        <translation type="obsolete">Увоз успешан</translation>
    </message>
    <message>
        <source>Filters import was successful.</source>
        <translation type="obsolete">Увоз филтера је успешан.</translation>
    </message>
    <message>
        <source>Import failure</source>
        <translation type="obsolete">Увоз погрешан</translation>
    </message>
    <message>
        <source>Filters could not be imported due to an I/O error.</source>
        <translation type="obsolete">Филтери не могу бити увежени због неке I/O грешке.</translation>
    </message>
    <message>
        <source>Select destination file</source>
        <translation type="obsolete">Изабери одредишни фајл</translation>
    </message>
    <message>
        <source>Export successful</source>
        <translation type="obsolete">Извоз успешан</translation>
    </message>
    <message>
        <source>Filters export was successful.</source>
        <translation type="obsolete">Филтери су извезени успешно.</translation>
    </message>
    <message>
        <source>Export failure</source>
        <translation type="obsolete">Извоз погрешан</translation>
    </message>
    <message>
        <source>Filters could not be exported due to an I/O error.</source>
        <translation type="obsolete">Филтери не могу бити извежени због неке I/O грешке.</translation>
    </message>
</context>
<context>
    <name>FeedList</name>
    <message>
        <source>Unread</source>
        <translation type="obsolete">Непрочитане</translation>
    </message>
</context>
<context>
    <name>FeedListWidget</name>
    <message>
        <source>RSS feeds</source>
        <translation>RSS поруке</translation>
    </message>
    <message>
        <source>Unread</source>
        <translation>Непрочитане</translation>
    </message>
</context>
<context>
    <name>GUI</name>
    <message>
        <source>Open Torrent Files</source>
        <translation type="obsolete">Отвори Торент фајлове</translation>
    </message>
    <message>
        <source>Torrent Files</source>
        <translation type="obsolete">Торент Фајлови</translation>
    </message>
    <message>
        <source>qBittorrent %1</source>
        <comment>e.g: qBittorrent v0.x</comment>
        <translatorcomment>н.пр.: qBittorrent v0.x</translatorcomment>
        <translation type="obsolete">qBittorrent %1</translation>
    </message>
    <message>
        <source>qBittorrent</source>
        <translation type="obsolete">qBittorrent</translation>
    </message>
    <message>
        <source>DL speed: %1 KiB/s</source>
        <comment>e.g: Download speed: 10 KiB/s</comment>
        <translatorcomment>н.пр.: Брзина преузимања: 10 KiB/s</translatorcomment>
        <translation type="obsolete">ПР брзина: %1 KiB/s</translation>
    </message>
    <message>
        <source>UP speed: %1 KiB/s</source>
        <comment>e.g: Upload speed: 10 KiB/s</comment>
        <translatorcomment>н.пр.: Брзина слања: 10 KiB/s</translatorcomment>
        <translation type="obsolete">СЛ брзина: %1 KiB/s</translation>
    </message>
    <message>
        <source>%1 has finished downloading.</source>
        <comment>e.g: xxx.avi has finished downloading.</comment>
        <translatorcomment>н.пр.: xxx.avi је завршио преузимање.</translatorcomment>
        <translation type="obsolete">%1 је завршио преузимање.</translation>
    </message>
    <message>
        <source>I/O Error</source>
        <comment>i.e: Input/Output Error</comment>
        <translatorcomment>н.пр.: Улазно/Излазна грешка</translatorcomment>
        <translation type="obsolete">И/О Грешка</translation>
    </message>
    <message>
        <source>Search</source>
        <translation type="obsolete">Претраживање</translation>
    </message>
    <message>
        <source>RSS</source>
        <translatorcomment>RSS је породица веб формата који се користе за објављивање садржаја који се често мењају, као што су новински наслови. RSS документ садржи или сажетак садржаја са придружене веб стране, или читав текст. RSS вам омогућава да будете у току са изменама и новостима са неког веб сајта потпуно аутоматски, а тај садржај се може увести у RSS апликацију на вашој страни.</translatorcomment>
        <translation type="obsolete">RSS</translation>
    </message>
    <message>
        <source>Alt+1</source>
        <comment>shortcut to switch to first tab</comment>
        <translatorcomment>пречица за пребацивање на прво поље</translatorcomment>
        <translation type="obsolete">Alt+1</translation>
    </message>
    <message>
        <source>Url download error</source>
        <translation type="obsolete">Url грешка преузимања</translation>
    </message>
    <message>
        <source>Couldn&apos;t download file at url: %1, reason: %2.</source>
        <translation type="obsolete">Немогуће преузети фајл са url: %1, разлог: %2.</translation>
    </message>
    <message>
        <source>An I/O error occured for torrent %1.
 Reason: %2</source>
        <comment>e.g: An error occured for torrent xxx.avi.
 Reason: disk is full.</comment>
        <translatorcomment>н.пр.: Догодила се грешка са торентом xxx.avi. Разлог: диск је пун.</translatorcomment>
        <translation type="obsolete">Нека И/О грешка се догодила са торентом %1.
 Разлог: %2</translation>
    </message>
    <message>
        <source>Transfers</source>
        <translatorcomment>Преноси</translatorcomment>
        <translation type="obsolete">Трансфери</translation>
    </message>
    <message>
        <source>Download completion</source>
        <translation type="obsolete">Комплетно преузет</translation>
    </message>
    <message>
        <source>Alt+2</source>
        <comment>shortcut to switch to third tab</comment>
        <translation type="obsolete">Alt+2</translation>
    </message>
    <message>
        <source>Ctrl+F</source>
        <comment>shortcut to switch to search tab</comment>
        <translatorcomment>пречица за пребацивање на поље претраживања</translatorcomment>
        <translation type="obsolete">Ctrl+F</translation>
    </message>
    <message>
        <source>Alt+3</source>
        <comment>shortcut to switch to fourth tab</comment>
        <translation type="obsolete">Alt+3</translation>
    </message>
    <message>
        <source>Global Upload Speed Limit</source>
        <translation type="obsolete">Општи лимит брзине слања</translation>
    </message>
    <message>
        <source>Global Download Speed Limit</source>
        <translation type="obsolete">Општи лимит брзине преузимања</translation>
    </message>
    <message>
        <source>Some files are currently transferring.
Are you sure you want to quit qBittorrent?</source>
        <translation type="obsolete">Неки фајлови се тренутно преносе.
Да ли сте сигурни да желите да прекинете qBittorrent?</translation>
    </message>
    <message>
        <source>qBittorrent %1 (Down: %2/s, Up: %3/s)</source>
        <comment>%1 is qBittorrent version</comment>
        <translation type="obsolete">qBittorrent %1 (Преуз: %2/s, Сл: %3/s)</translation>
    </message>
    <message>
        <source>Options were saved successfully.</source>
        <translation type="obsolete">Опције када је сачуван успешно.</translation>
    </message>
    <message>
        <source>Recursive download confirmation</source>
        <translation type="obsolete">Потврда поновног преузимања</translation>
    </message>
    <message>
        <source>The torrent %1 contains torrent files, do you want to proceed with their download?</source>
        <translation type="obsolete">Торент %1 садржи торент фајлове, да ли желите да наставите њихово преузимање?</translation>
    </message>
    <message>
        <source>Torrent file association</source>
        <translation type="obsolete">Асоцириње Торент фајла</translation>
    </message>
    <message>
        <source>qBittorrent is not the default application to open torrent files or Magnet links.
Do you want to associate qBittorrent to torrent files and Magnet links?</source>
        <translation type="obsolete">qBittorrent није подразумевана апликација за отварање Торент фајлова или Magnet линкова.
Да ли желите да асоцирате qBittorrent за Торент фајлове и Magnet линкове?</translation>
    </message>
    <message>
        <source>Transfers (%1)</source>
        <translation type="obsolete">Трансфери (%1)</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation type="obsolete">Да</translation>
    </message>
    <message>
        <source>No</source>
        <translation type="obsolete">Не</translation>
    </message>
    <message>
        <source>Never</source>
        <translation type="obsolete">Никада</translation>
    </message>
    <message>
        <source>Always</source>
        <translation type="obsolete">Увек</translation>
    </message>
    <message>
        <source>Exiting qBittorrent</source>
        <translation type="obsolete">Излазак из qBittorrent-а</translation>
    </message>
    <message>
        <source>Set the password...</source>
        <translation type="obsolete">Подешавање лозинке...</translation>
    </message>
    <message>
        <source>Password update</source>
        <translation type="obsolete">Обнављање лозинке</translation>
    </message>
    <message>
        <source>The UI lock password has been successfully updated</source>
        <translatorcomment>КИ-кориснички интерфејс</translatorcomment>
        <translation type="obsolete">Закључавање КИ-а лозинком је успешно обновљено</translation>
    </message>
    <message>
        <source>UI lock password</source>
        <translatorcomment>КИ-кориснички интерфејс</translatorcomment>
        <translation type="obsolete">Закључавање КИ-а лозинком</translation>
    </message>
    <message>
        <source>Please type the UI lock password:</source>
        <translatorcomment>КИ-кориснички интерфејс</translatorcomment>
        <translation type="obsolete">Молим упишите лозинку закључавања КИ-а:</translation>
    </message>
    <message>
        <source>Invalid password</source>
        <translation type="obsolete">Погрешна лозинка</translation>
    </message>
    <message>
        <source>The password is invalid</source>
        <translation type="obsolete">Лозинка је погрешна</translation>
    </message>
    <message>
        <source>A newer version is available</source>
        <translation type="obsolete">Нова верзија је доступна</translation>
    </message>
    <message>
        <source>A newer version of qBittorrent is available on Sourceforge.
Would you like to update qBittorrent to version %1?</source>
        <translation type="obsolete">Нова верзија qBittorrent-а је доступна на Sourceforge-u.
Да ли желите да ажурирате qBittorrent на верзију %1?</translation>
    </message>
    <message>
        <source>Impossible to update qBittorrent</source>
        <translation type="obsolete">Није могуће ажурирање qBittorrent-а</translation>
    </message>
    <message>
        <source>qBittorrent failed to update, reason: %1</source>
        <translation type="obsolete">qBittorrent грешка при ажурирању, разлог: %1</translation>
    </message>
</context>
<context>
    <name>GeoIP</name>
    <message>
        <source>Australia</source>
        <translation type="obsolete">Аустралија</translation>
    </message>
    <message>
        <source>Argentina</source>
        <translation type="obsolete">Аргентина</translation>
    </message>
    <message>
        <source>Austria</source>
        <translation type="obsolete">Ауструја</translation>
    </message>
    <message>
        <source>United Arab Emirates</source>
        <translation type="obsolete">Уједињени Арапски Емирати</translation>
    </message>
    <message>
        <source>Brazil</source>
        <translation type="obsolete">Бразил</translation>
    </message>
    <message>
        <source>Bulgaria</source>
        <translation type="obsolete">Бугарска</translation>
    </message>
    <message>
        <source>Belarus</source>
        <translation type="obsolete">Белорусија</translation>
    </message>
    <message>
        <source>Belgium</source>
        <translation type="obsolete">Белгија</translation>
    </message>
    <message>
        <source>Bosnia</source>
        <translation type="obsolete">Босна</translation>
    </message>
    <message>
        <source>Canada</source>
        <translation type="obsolete">Канада</translation>
    </message>
    <message>
        <source>Czech Republic</source>
        <translation type="obsolete">Република Чешка</translation>
    </message>
    <message>
        <source>China</source>
        <translation type="obsolete">Кина</translation>
    </message>
    <message>
        <source>Costa Rica</source>
        <translation type="obsolete">Коста Рика</translation>
    </message>
    <message>
        <source>Switzerland</source>
        <translation type="obsolete">Швајцарска</translation>
    </message>
    <message>
        <source>Germany</source>
        <translation type="obsolete">Немачка</translation>
    </message>
    <message>
        <source>Denmark</source>
        <translation type="obsolete">Данска</translation>
    </message>
    <message>
        <source>Algeria</source>
        <translation type="obsolete">Алжир</translation>
    </message>
    <message>
        <source>Spain</source>
        <translation type="obsolete">Шпанија</translation>
    </message>
    <message>
        <source>Egypt</source>
        <translation type="obsolete">Египат</translation>
    </message>
    <message>
        <source>Finland</source>
        <translation type="obsolete">Финска</translation>
    </message>
    <message>
        <source>France</source>
        <translation type="obsolete">Француска</translation>
    </message>
    <message>
        <source>United Kingdom</source>
        <translation type="obsolete">Енглеска</translation>
    </message>
    <message>
        <source>Greece</source>
        <translation type="obsolete">Грчка</translation>
    </message>
    <message>
        <source>Georgia</source>
        <translation type="obsolete">Грузија</translation>
    </message>
    <message>
        <source>Hungary</source>
        <translation type="obsolete">Мађарска</translation>
    </message>
    <message>
        <source>Croatia</source>
        <translation type="obsolete">Хрватска</translation>
    </message>
    <message>
        <source>Italy</source>
        <translation type="obsolete">Италија</translation>
    </message>
    <message>
        <source>India</source>
        <translation type="obsolete">Индија</translation>
    </message>
    <message>
        <source>Israel</source>
        <translation type="obsolete">Израел</translation>
    </message>
    <message>
        <source>Ireland</source>
        <translation type="obsolete">Ирска</translation>
    </message>
    <message>
        <source>Iceland</source>
        <translation type="obsolete">Исланд</translation>
    </message>
    <message>
        <source>Indonesia</source>
        <translation type="obsolete">Индонезија</translation>
    </message>
    <message>
        <source>Japan</source>
        <translation type="obsolete">Јапан</translation>
    </message>
    <message>
        <source>South Korea</source>
        <translation type="obsolete">Јужна Кореја</translation>
    </message>
    <message>
        <source>Luxembourg</source>
        <translation type="obsolete">Луксембург</translation>
    </message>
    <message>
        <source>Malaysia</source>
        <translation type="obsolete">Малезија</translation>
    </message>
    <message>
        <source>Mexico</source>
        <translation type="obsolete">Мексико</translation>
    </message>
    <message>
        <source>Serbia</source>
        <translation type="obsolete">Србија</translation>
    </message>
    <message>
        <source>Morocco</source>
        <translation type="obsolete">Мароко</translation>
    </message>
    <message>
        <source>Netherlands</source>
        <translation type="obsolete">Холандија</translation>
    </message>
    <message>
        <source>Norway</source>
        <translation type="obsolete">Норвешка</translation>
    </message>
    <message>
        <source>New Zealand</source>
        <translation type="obsolete">Нови Зеланд</translation>
    </message>
    <message>
        <source>Portugal</source>
        <translation type="obsolete">Португалија</translation>
    </message>
    <message>
        <source>Poland</source>
        <translation type="obsolete">Пољска</translation>
    </message>
    <message>
        <source>Pakistan</source>
        <translation type="obsolete">Пакистан</translation>
    </message>
    <message>
        <source>Philippines</source>
        <translation type="obsolete">Филипини</translation>
    </message>
    <message>
        <source>Russia</source>
        <translation type="obsolete">Русија</translation>
    </message>
    <message>
        <source>Romania</source>
        <translation type="obsolete">Румунија</translation>
    </message>
    <message>
        <source>France (Reunion Island)</source>
        <translation type="obsolete">Француска (Reunion Island)</translation>
    </message>
    <message>
        <source>Sweden</source>
        <translation type="obsolete">Шведска</translation>
    </message>
    <message>
        <source>Slovakia</source>
        <translation type="obsolete">Словачка</translation>
    </message>
    <message>
        <source>Singapore</source>
        <translation type="obsolete">Сингапур</translation>
    </message>
    <message>
        <source>Slovenia</source>
        <translation type="obsolete">Словенија</translation>
    </message>
    <message>
        <source>Taiwan</source>
        <translation type="obsolete">Тајван</translation>
    </message>
    <message>
        <source>Turkey</source>
        <translation type="obsolete">Турска</translation>
    </message>
    <message>
        <source>Thailand</source>
        <translation type="obsolete">Тајланд</translation>
    </message>
    <message>
        <source>USA</source>
        <translation type="obsolete">САД</translation>
    </message>
    <message>
        <source>Ukraine</source>
        <translation type="obsolete">Украјина</translation>
    </message>
    <message>
        <source>South Africa</source>
        <translation type="obsolete">Јужна Африка</translation>
    </message>
    <message>
        <source>Saudi Arabia</source>
        <translation type="obsolete">Саудијска Арабија</translation>
    </message>
</context>
<context>
    <name>HeadlessLoader</name>
    <message>
        <source>Information</source>
        <translation>Информације</translation>
    </message>
    <message>
        <source>To control qBittorrent, access the Web UI at http://localhost:%1</source>
        <translation>Да управљате qBittorrent-ом, приступите са Веб КИ на http://localhost:%1</translation>
    </message>
    <message>
        <source>The Web UI administrator user name is: %1</source>
        <translation>Веб КИ име администратора је: %1</translation>
    </message>
    <message>
        <source>The Web UI administrator password is still the default one: %1</source>
        <translation>Веб КИ лозинка администратора  је још увек стандардна: %1</translation>
    </message>
    <message>
        <source>This is a security risk, please consider changing your password from program preferences.</source>
        <translation>То је безбедносни ризик, молимо Вас да размислите о промени лозинке из програмског подешавања.</translation>
    </message>
</context>
<context>
    <name>HttpConnection</name>
    <message>
        <source>Your IP address has been banned after too many failed authentication attempts.</source>
        <translation>Ваша IP адреса је одбијена после више покушаја аутентификације.</translation>
    </message>
    <message>
        <source>D: %1/s - T: %2</source>
        <comment>Download speed: x KiB/s - Transferred: x MiB</comment>
        <translatorcomment>Брзина преузимања: x KiB/s - Транспортовано: x MiB</translatorcomment>
        <translation>П: %1/s - T: %2</translation>
    </message>
    <message>
        <source>U: %1/s - T: %2</source>
        <comment>Upload speed: x KiB/s - Transferred: x MiB</comment>
        <translatorcomment>Брзина слања: x KiB/s - Транспортовано: x MiB</translatorcomment>
        <translation>С: %1/s - T: %2</translation>
    </message>
</context>
<context>
    <name>HttpServer</name>
    <message>
        <source>File</source>
        <translation>Фајл</translation>
    </message>
    <message>
        <source>Edit</source>
        <translatorcomment>Едитуј</translatorcomment>
        <translation>Уреди</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Помоћ</translation>
    </message>
    <message>
        <source>Delete from HD</source>
        <translation type="obsolete">Обриши са HD-а (хард диск-а)</translation>
    </message>
    <message>
        <source>Download Torrents from their URL or Magnet link</source>
        <translation>Преузми Торенте са овог URL-а или Магнет линка</translation>
    </message>
    <message>
        <source>Only one link per line</source>
        <translation>Само један линк по линији</translation>
    </message>
    <message>
        <source>Download local torrent</source>
        <translation>Преузми локални торент</translation>
    </message>
    <message>
        <source>Torrent files were correctly added to download list.</source>
        <translation>Торент фајлови су коректно додати на листу за преузимање.</translation>
    </message>
    <message>
        <source>Point to torrent file</source>
        <translation>Указивање на Торент фајл</translation>
    </message>
    <message>
        <source>Download</source>
        <translation>Преузимање</translation>
    </message>
    <message>
        <source>Are you sure you want to delete the selected torrents from the transfer list and hard disk?</source>
        <translation>Да ли сте сигурни да желите да обришете селектоване Торенте са трансфер листе и са хард диска?</translation>
    </message>
    <message>
        <source>Download rate limit must be greater than 0 or disabled.</source>
        <translation>Вредност лимита Преузимања мора бити већа од 0 или онемугућена.</translation>
    </message>
    <message>
        <source>Upload rate limit must be greater than 0 or disabled.</source>
        <translation>Вредност лимита Слања мора бити већа од 0 или онемугућена.</translation>
    </message>
    <message>
        <source>Maximum number of connections limit must be greater than 0 or disabled.</source>
        <translation>Максимални број конекција при лимитирању мора бити већи од 0 или онемогућен.</translation>
    </message>
    <message>
        <source>Maximum number of connections per torrent limit must be greater than 0 or disabled.</source>
        <translation>Максимални број конекција по Торенту при лимитирању мора бити већи од 0 или онемогућен.</translation>
    </message>
    <message>
        <source>Maximum number of upload slots per torrent limit must be greater than 0 or disabled.</source>
        <translation>Максимални број слотова за слање Торента при лимитирању мора бити већи од 0 или онемогућен.</translation>
    </message>
    <message>
        <source>Unable to save program preferences, qBittorrent is probably unreachable.</source>
        <translation>Не могу да сачувам програмска подешавања, qBittorrent је вероватно недоступан.</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Језик</translation>
    </message>
    <message>
        <source>Downloaded</source>
        <comment>Is the file downloaded or not?</comment>
        <translation>Преузет</translation>
    </message>
    <message>
        <source>The port used for incoming connections must be greater than 1024 and less than 65535.</source>
        <translation>Порт који се користи за долазне конекције мора бити већи од 1024 а мањи од 65535.</translation>
    </message>
    <message>
        <source>The port used for the Web UI must be greater than 1024 and less than 65535.</source>
        <translation>Порт који се користи за Веб КИ мора бити већи од 1024 а мањи од 65535.</translation>
    </message>
    <message>
        <source>The Web UI username must be at least 3 characters long.</source>
        <translation>Веб КИ име корисника мора имати најмање 3 карактера.</translation>
    </message>
    <message>
        <source>The Web UI password must be at least 3 characters long.</source>
        <translation>Веб КИ лозинка мора имати најмање 3 карактера.</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Сачувај</translation>
    </message>
    <message>
        <source>qBittorrent client is not reachable</source>
        <translation>qBittorrent клијент није доступан</translation>
    </message>
    <message>
        <source>HTTP Server</source>
        <translation>HTTP Сервер</translation>
    </message>
    <message>
        <source>Torrent path</source>
        <translation>Путања Трента</translation>
    </message>
    <message>
        <source>Torrent name</source>
        <translation>Име Торента</translation>
    </message>
    <message>
        <source>The following parameters are supported:</source>
        <translation>Следећи параметри су подржани:</translation>
    </message>
</context>
<context>
    <name>LegalNotice</name>
    <message>
        <source>Legal Notice</source>
        <translation>Правно Обавештење</translation>
    </message>
    <message>
        <source>qBittorrent is a file sharing program. When you run a torrent, its data will be made available to others by means of upload. Any content you share is your sole responsibility.

No further notices will be issued.</source>
        <translation>qBittorrent је програм за дељење датотека. Када покренете Торент, дељене датотеке ће бити доступне другима за преузимање. И наравно, било који садржај који делите је Ваша лична одговорност.

Ви вероватно то знате, тако да Вам то нећемо понављати.</translation>
    </message>
    <message>
        <source>Press %1 key to accept and continue...</source>
        <translation>Притисните %1 тастер да ово прихватите и наставите...</translation>
    </message>
    <message>
        <source>Legal notice</source>
        <translation>Правно обавештење</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Откажи</translation>
    </message>
    <message>
        <source>I Agree</source>
        <translatorcomment>Слажем се , Прихватам</translatorcomment>
        <translation>Сагласан сам</translation>
    </message>
</context>
<context>
    <name>LineEdit</name>
    <message>
        <source>Clear the text</source>
        <translation>Обриши текст</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>&amp;Edit</source>
        <translatorcomment>&amp;Едитуј</translatorcomment>
        <translation>&amp;Уреди</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translatorcomment>&amp;Датотека</translatorcomment>
        <translation>&amp;Фајл</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Помоћ</translation>
    </message>
    <message>
        <source>Preview file</source>
        <translation type="obsolete">Приказ датотеке</translation>
    </message>
    <message>
        <source>Clear log</source>
        <translation type="obsolete">Обриши лог</translation>
    </message>
    <message>
        <source>Decrease priority</source>
        <translation>Снизи приоритет</translation>
    </message>
    <message>
        <source>Increase priority</source>
        <translation>Повиси приоритет</translation>
    </message>
    <message>
        <source>&amp;Tools</source>
        <translation>&amp;Алати</translation>
    </message>
    <message>
        <source>&amp;View</source>
        <translation>&amp;Изглед</translation>
    </message>
    <message>
        <source>&amp;Add File...</source>
        <translation type="obsolete">&amp;Додај фајл...</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation type="obsolete">И&amp;злаз</translation>
    </message>
    <message>
        <source>&amp;Options...</source>
        <translation>&amp;Опције...</translation>
    </message>
    <message>
        <source>Add &amp;URL...</source>
        <translation type="obsolete">Додај &amp;URL...</translation>
    </message>
    <message>
        <source>Torrent &amp;creator</source>
        <translation>Торент &amp;креатор</translation>
    </message>
    <message>
        <source>Set upload limit...</source>
        <translation>Подеси ограничење слања...</translation>
    </message>
    <message>
        <source>Set download limit...</source>
        <translation>Подеси ограничење преузимања...</translation>
    </message>
    <message>
        <source>Set global download limit...</source>
        <translation>Подеси општи лимит преузимања...</translation>
    </message>
    <message>
        <source>Set global upload limit...</source>
        <translation>Подеси општи лимит слања...</translation>
    </message>
    <message>
        <source>&amp;Log viewer...</source>
        <translatorcomment>Log-Дневник-Лог</translatorcomment>
        <translation type="obsolete">&amp;Преглед дневника...</translation>
    </message>
    <message>
        <source>Top &amp;tool bar</source>
        <translation>Горња &amp;трака алата</translation>
    </message>
    <message>
        <source>Display top tool bar</source>
        <translation>Прикажи горњу траку алата</translation>
    </message>
    <message>
        <source>&amp;Speed in title bar</source>
        <translation>&amp;Брзина на насловној траци</translation>
    </message>
    <message>
        <source>Show transfer speed in title bar</source>
        <translation>Прикажи брзину преноса на насловној траци</translation>
    </message>
    <message>
        <source>Alternative speed limits</source>
        <translation>Алтернативно ограничење брзине</translation>
    </message>
    <message>
        <source>&amp;About</source>
        <translation>&amp;О програму</translation>
    </message>
    <message>
        <source>&amp;Pause</source>
        <translation>&amp;Пауза</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>&amp;Обриши</translation>
    </message>
    <message>
        <source>P&amp;ause All</source>
        <translation>П&amp;аузирај све</translation>
    </message>
    <message>
        <source>Visit &amp;Website</source>
        <translation>Посети &amp;Веб страну</translation>
    </message>
    <message>
        <source>Report a &amp;bug</source>
        <translation>Извести о &amp;грешци</translation>
    </message>
    <message>
        <source>&amp;Documentation</source>
        <translation>&amp;Документација</translation>
    </message>
    <message>
        <source>&amp;RSS reader</source>
        <translation>&amp;RSS читач</translation>
    </message>
    <message>
        <source>Search &amp;engine</source>
        <translation>Претраживачки &amp;модул</translation>
    </message>
    <message>
        <source>Log viewer</source>
        <translation type="obsolete">Преглед дневника</translation>
    </message>
    <message>
        <source>Lock qBittorrent</source>
        <translation>Закључај qBittorrent</translation>
    </message>
    <message>
        <source>Ctrl+L</source>
        <translation>Ctrl+L</translation>
    </message>
    <message>
        <source>Shutdown computer when downloads complete</source>
        <translation type="obsolete">Искључи рачунар по комплетном преузимању</translation>
    </message>
    <message>
        <source>&amp;Resume</source>
        <translation>&amp;Настави</translation>
    </message>
    <message>
        <source>R&amp;esume All</source>
        <translation>Н&amp;астави Све</translation>
    </message>
    <message>
        <source>Shutdown qBittorrent when downloads complete</source>
        <translation type="obsolete">Искључи qBittorrent по комплетном преузимању</translation>
    </message>
    <message>
        <source>Exit</source>
        <translation>Излаз</translation>
    </message>
    <message>
        <source>Import torrent...</source>
        <translation>Увези торент...</translation>
    </message>
    <message>
        <source>Donate money</source>
        <translation>Донирање новца</translation>
    </message>
    <message>
        <source>If you like qBittorrent, please donate!</source>
        <translation>Ако волите qBittorrent, молимо Вас донирајте!</translation>
    </message>
    <message>
        <source>qBittorrent %1</source>
        <comment>e.g: qBittorrent v0.x</comment>
        <translation>qBittorrent %1</translation>
    </message>
    <message>
        <source>Set the password...</source>
        <translation>Подешавање лозинке...</translation>
    </message>
    <message>
        <source>Transfers</source>
        <translation>Трансфери</translation>
    </message>
    <message>
        <source>Torrent file association</source>
        <translation>Асоцириње Торент фајла</translation>
    </message>
    <message>
        <source>qBittorrent is not the default application to open torrent files or Magnet links.
Do you want to associate qBittorrent to torrent files and Magnet links?</source>
        <translation>qBittorrent није подразумевана апликација за отварање Торент фајлова или Magnet линкова.
Да ли желите да асоцирате qBittorrent за Торент фајлове и Magnet линкове?</translation>
    </message>
    <message>
        <source>UI lock password</source>
        <translation>Закључавање КИ-а лозинком</translation>
    </message>
    <message>
        <source>Please type the UI lock password:</source>
        <translation>Молим упишите лозинку закључавања КИ-а:</translation>
    </message>
    <message>
        <source>Password update</source>
        <translation>Обнављање лозинке</translation>
    </message>
    <message>
        <source>The UI lock password has been successfully updated</source>
        <translation>Закључавање КИ-а лозинком је успешно обновљено</translation>
    </message>
    <message>
        <source>RSS</source>
        <translation>RSS</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Претраживање</translation>
    </message>
    <message>
        <source>Transfers (%1)</source>
        <translation>Трансфери (%1)</translation>
    </message>
    <message>
        <source>Download completion</source>
        <translation>Комплетно преузет</translation>
    </message>
    <message>
        <source>%1 has finished downloading.</source>
        <comment>e.g: xxx.avi has finished downloading.</comment>
        <translation>%1 је завршио преузимање.</translation>
    </message>
    <message>
        <source>I/O Error</source>
        <comment>i.e: Input/Output Error</comment>
        <translation>И/О Грешка</translation>
    </message>
    <message>
        <source>An I/O error occured for torrent %1.
 Reason: %2</source>
        <comment>e.g: An error occured for torrent xxx.avi.
 Reason: disk is full.</comment>
        <translation>Нека И/О грешка се догодила са торентом %1.
 Разлог: %2</translation>
    </message>
    <message>
        <source>Alt+1</source>
        <comment>shortcut to switch to first tab</comment>
        <translation>Alt+1</translation>
    </message>
    <message>
        <source>Alt+2</source>
        <comment>shortcut to switch to third tab</comment>
        <translation>Alt+2</translation>
    </message>
    <message>
        <source>Ctrl+F</source>
        <comment>shortcut to switch to search tab</comment>
        <translation>Ctrl+F</translation>
    </message>
    <message>
        <source>Alt+3</source>
        <comment>shortcut to switch to fourth tab</comment>
        <translation>Alt+3</translation>
    </message>
    <message>
        <source>Recursive download confirmation</source>
        <translation>Потврда поновног преузимања</translation>
    </message>
    <message>
        <source>The torrent %1 contains torrent files, do you want to proceed with their download?</source>
        <translation>Торент %1 садржи торент фајлове, да ли желите да наставите њихово преузимање?</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Да</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Не</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Никада</translation>
    </message>
    <message>
        <source>Url download error</source>
        <translation>Url грешка преузимања</translation>
    </message>
    <message>
        <source>Couldn&apos;t download file at url: %1, reason: %2.</source>
        <translation>Немогуће преузети фајл са url: %1, разлог: %2.</translation>
    </message>
    <message>
        <source>Global Upload Speed Limit</source>
        <translation>Општи лимит брзине слања</translation>
    </message>
    <message>
        <source>Global Download Speed Limit</source>
        <translation>Општи лимит брзине преузимања</translation>
    </message>
    <message>
        <source>Invalid password</source>
        <translation>Погрешна лозинка</translation>
    </message>
    <message>
        <source>The password is invalid</source>
        <translation>Лозинка је погрешна</translation>
    </message>
    <message>
        <source>Exiting qBittorrent</source>
        <translation>Излазак из qBittorrent-а</translation>
    </message>
    <message>
        <source>Some files are currently transferring.
Are you sure you want to quit qBittorrent?</source>
        <translation>Неки фајлови се тренутно преносе.
Да ли сте сигурни да желите да прекинете qBittorrent?</translation>
    </message>
    <message>
        <source>Always</source>
        <translation>Увек</translation>
    </message>
    <message>
        <source>Open Torrent Files</source>
        <translation>Отвори Торент фајлове</translation>
    </message>
    <message>
        <source>Torrent Files</source>
        <translation>Торент Фајлови</translation>
    </message>
    <message>
        <source>Options were saved successfully.</source>
        <translation>Опције када је сачуван успешно.</translation>
    </message>
    <message>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <source>DL speed: %1 KiB/s</source>
        <comment>e.g: Download speed: 10 KiB/s</comment>
        <translation>ПР брзина: %1 KiB/s</translation>
    </message>
    <message>
        <source>UP speed: %1 KiB/s</source>
        <comment>e.g: Upload speed: 10 KiB/s</comment>
        <translation>СЛ брзина: %1 KiB/s</translation>
    </message>
    <message>
        <source>qBittorrent %1 (Down: %2/s, Up: %3/s)</source>
        <comment>%1 is qBittorrent version</comment>
        <translation>qBittorrent %1 (Преуз: %2/s, Сл: %3/s)</translation>
    </message>
    <message>
        <source>A newer version is available</source>
        <translation>Нова верзија је доступна</translation>
    </message>
    <message>
        <source>A newer version of qBittorrent is available on Sourceforge.
Would you like to update qBittorrent to version %1?</source>
        <translation>Нова верзија qBittorrent-а је доступна на Sourceforge-u.
Да ли желите да ажурирате qBittorrent на верзију %1?</translation>
    </message>
    <message>
        <source>Impossible to update qBittorrent</source>
        <translation>Није могуће ажурирање qBittorrent-а</translation>
    </message>
    <message>
        <source>qBittorrent failed to update, reason: %1</source>
        <translation>qBittorrent грешка при ажурирању, разлог: %1</translation>
    </message>
    <message>
        <source>&amp;Add torrent file...</source>
        <translation>&amp;Додај торент фајл...</translation>
    </message>
    <message>
        <source>Add &amp;link to torrent...</source>
        <translation>Додај &amp;линк у торент...</translation>
    </message>
    <message>
        <source>Import existing torrent...</source>
        <translation>Увези постојећи торент...</translation>
    </message>
    <message>
        <source>Execution &amp;Log</source>
        <translation>Дневник &amp;Дешавања</translation>
    </message>
    <message>
        <source>Execution Log</source>
        <translation>Дневник догађаја</translation>
    </message>
    <message>
        <source>Auto-Shutdown on downloads completion</source>
        <translation>Ауто-Искључење по комплетном преузимању</translation>
    </message>
    <message>
        <source>Exit qBittorrent</source>
        <translation>Изађи из qBittorrent-а</translation>
    </message>
    <message>
        <source>Suspend system</source>
        <translation>Суспендуј рачунар</translation>
    </message>
    <message>
        <source>Shutdown system</source>
        <translation>Искључи рачунар</translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Онемогућено</translation>
    </message>
    <message>
        <source>The password should contain at least 3 characters</source>
        <translation>Лозинка мора имати најмање 3 карактера</translation>
    </message>
</context>
<context>
    <name>PeerAdditionDlg</name>
    <message>
        <source>Invalid IP</source>
        <translation>Погрешан IP</translation>
    </message>
    <message>
        <source>The IP you provided is invalid.</source>
        <translation>IP адреса коју сте унели није исправна.</translation>
    </message>
</context>
<context>
    <name>PeerListDelegate</name>
    <message>
        <source>/s</source>
        <comment>/second (i.e. per second)</comment>
        <translation>/s</translation>
    </message>
</context>
<context>
    <name>PeerListWidget</name>
    <message>
        <source>IP</source>
        <translation>IP</translation>
    </message>
    <message>
        <source>Client</source>
        <comment>i.e.: Client application</comment>
        <translation>Клијент</translation>
    </message>
    <message>
        <source>Progress</source>
        <comment>i.e: % downloaded</comment>
        <translatorcomment>н.пр.: % преузето</translatorcomment>
        <translation>Напредак</translation>
    </message>
    <message>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Брзина Преузимања</translation>
    </message>
    <message>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Брзина Слања</translation>
    </message>
    <message>
        <source>Downloaded</source>
        <comment>i.e: total data downloaded</comment>
        <translation>Преузето</translation>
    </message>
    <message>
        <source>Uploaded</source>
        <comment>i.e: total data uploaded</comment>
        <translation>Послато</translation>
    </message>
    <message>
        <source>Ban peer permanently</source>
        <translatorcomment>peer-учесник, активна веза</translatorcomment>
        <translation>Забрани(бануј) peer трајно</translation>
    </message>
    <message>
        <source>Peer addition</source>
        <translatorcomment>peer-учесник, активна веза</translatorcomment>
        <translation>Додавање (peer-a) учесника</translation>
    </message>
    <message>
        <source>The peer was added to this torrent.</source>
        <translation>Peer (учесник) је додат у овај торент.</translation>
    </message>
    <message>
        <source>The peer could not be added to this torrent.</source>
        <translation>Peer (учесник) не може бити додат у овај торент.</translation>
    </message>
    <message>
        <source>Are you sure? -- qBittorrent</source>
        <translation>Да ли сте сигурни? -- qBittorrent</translation>
    </message>
    <message>
        <source>Are you sure you want to ban permanently the selected peers?</source>
        <translation>Да ли сте сигурни да желите да забраните изабране учеснике трајно?</translation>
    </message>
    <message>
        <source>&amp;Yes</source>
        <translation>&amp;Да</translation>
    </message>
    <message>
        <source>&amp;No</source>
        <translation>&amp;Не</translation>
    </message>
    <message>
        <source>Manually banning peer %1...</source>
        <translatorcomment>peer-учесник, активна веза</translatorcomment>
        <translation>Ручно забрани(бануј) peer %1...</translation>
    </message>
    <message>
        <source>Upload rate limiting</source>
        <translation>Ограничење брзине слања</translation>
    </message>
    <message>
        <source>Download rate limiting</source>
        <translation>Ограничење брзине преузимања</translation>
    </message>
    <message>
        <source>Add a new peer...</source>
        <translation>Додај нов peer (учесник-а)...</translation>
    </message>
    <message>
        <source>Limit download rate...</source>
        <translation>Ограничење брзине преузимања...</translation>
    </message>
    <message>
        <source>Limit upload rate...</source>
        <translation>Ограничење брзине слања...</translation>
    </message>
    <message>
        <source>Copy IP</source>
        <translation>Копирај IP</translation>
    </message>
    <message>
        <source>Connection</source>
        <translation>Конекције</translation>
    </message>
</context>
<context>
    <name>Preferences</name>
    <message>
        <source>UI</source>
        <extracomment>User Interface</extracomment>
        <translatorcomment>КИ (Кориснички Интерфејс)</translatorcomment>
        <translation type="obsolete">КИ</translation>
    </message>
    <message>
        <source>Downloads</source>
        <translation>Преузимање</translation>
    </message>
    <message>
        <source>Connection</source>
        <translation>Конекције</translation>
    </message>
    <message>
        <source>Speed</source>
        <translation>Брзина</translation>
    </message>
    <message>
        <source>Bittorrent</source>
        <translation type="obsolete">Бит-торент</translation>
    </message>
    <message>
        <source>Proxy</source>
        <translation type="obsolete">Прокси</translation>
    </message>
    <message>
        <source>Web UI</source>
        <translatorcomment>Web UI (Веб Кориснички Интерфејс)</translatorcomment>
        <translation>Веб КИ</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Напредно</translation>
    </message>
    <message>
        <source>Language:</source>
        <translation type="obsolete">Језик:</translation>
    </message>
    <message>
        <source>(Requires restart)</source>
        <translation>(Захтева рестарт)</translation>
    </message>
    <message>
        <source>Visual style:</source>
        <translation type="obsolete">Изглед:</translation>
    </message>
    <message>
        <source>Transfer list</source>
        <translatorcomment>Листа преноса</translatorcomment>
        <translation type="obsolete">Трансфер листа</translation>
    </message>
    <message>
        <source>Use alternating row colors</source>
        <extracomment>In transfer list, one every two rows will have grey background.</extracomment>
        <translation>Користи различите боје за приказ редова</translation>
    </message>
    <message>
        <source>File system</source>
        <translation type="obsolete">Фајл систем</translation>
    </message>
    <message>
        <source>Copy .torrent files to:</source>
        <translation>Копирај .torrent фајлове у:</translation>
    </message>
    <message>
        <source>Torrent queueing</source>
        <translation type="obsolete">Торент опслуживање</translation>
    </message>
    <message>
        <source>Maximum active downloads:</source>
        <translation>Максимум активних преузимања:</translation>
    </message>
    <message>
        <source>Maximum active uploads:</source>
        <translation>Максимум активних слања:</translation>
    </message>
    <message>
        <source>Maximum active torrents:</source>
        <translation>Максимум активних торента:</translation>
    </message>
    <message>
        <source>When adding a torrent</source>
        <translation>Када додајете неки торент</translation>
    </message>
    <message>
        <source>Display torrent content and some options</source>
        <translation>Прикажи садржај торента и неке опције</translation>
    </message>
    <message>
        <source>Listening port</source>
        <translation type="obsolete">Надгледај порт</translation>
    </message>
    <message>
        <source>Port used for incoming connections:</source>
        <translation>Порт коришћен за долазне конекције:</translation>
    </message>
    <message>
        <source>Random</source>
        <translation>Случајан</translation>
    </message>
    <message>
        <source>Enable UPnP port mapping</source>
        <translation type="obsolete">Омогући UPnP мапирање порта</translation>
    </message>
    <message>
        <source>Enable NAT-PMP port mapping</source>
        <translation type="obsolete">Омогући NAT-PMP мапирање порта</translation>
    </message>
    <message>
        <source>Connections limit</source>
        <translation type="obsolete">Конекциона ограничења</translation>
    </message>
    <message>
        <source>Global maximum number of connections:</source>
        <translation>Општи максимални број конекција:</translation>
    </message>
    <message>
        <source>Maximum number of connections per torrent:</source>
        <translation>Максимални број конекција по торенту:</translation>
    </message>
    <message>
        <source>Maximum number of upload slots per torrent:</source>
        <translation>Максимални број слотова за слање по торенту:</translation>
    </message>
    <message>
        <source>Upload:</source>
        <translation>Слање:</translation>
    </message>
    <message>
        <source>Download:</source>
        <translation>Преузимање:</translation>
    </message>
    <message>
        <source>KiB/s</source>
        <translation>KiB/s</translation>
    </message>
    <message>
        <source>Global speed limits</source>
        <translation type="obsolete">Глобална ограничења брзине</translation>
    </message>
    <message>
        <source>Alternative global speed limits</source>
        <translation type="obsolete">Алтернатива глобалног ограничења брзине</translation>
    </message>
    <message>
        <source>to</source>
        <extracomment>time1 to time2</extracomment>
        <translation>до</translation>
    </message>
    <message>
        <source>Every day</source>
        <translation>Сваки дан</translation>
    </message>
    <message>
        <source>Week days</source>
        <translation>Радним данима</translation>
    </message>
    <message>
        <source>Week ends</source>
        <translation>Викендом</translation>
    </message>
    <message>
        <source>Bittorrent features</source>
        <translation type="obsolete">Бит-торент карактеристике</translation>
    </message>
    <message>
        <source>Enable DHT network (decentralized)</source>
        <translation type="obsolete">Омогући DHT мрежу (децентализовано)</translation>
    </message>
    <message>
        <source>Use a different port for DHT and Bittorrent</source>
        <translation type="obsolete">Користи различит порт за DHT и Бит-торент</translation>
    </message>
    <message>
        <source>DHT port:</source>
        <translation>DHT порт:</translation>
    </message>
    <message>
        <source>Enable Peer Exchange / PeX (requires restart)</source>
        <translatorcomment>Рестарт је потребан за старт PeX подршке</translatorcomment>
        <translation type="obsolete">Омогући Peer Exchange / PeX (захтева рестарт)</translation>
    </message>
    <message>
        <source>Enable Local Peer Discovery</source>
        <translation type="obsolete">Омогући откривање локалних веза Peer (учесника)</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation type="obsolete">Омогући</translation>
    </message>
    <message>
        <source>Forced</source>
        <translation type="obsolete">Форсирано</translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation type="obsolete">Онемогући</translation>
    </message>
    <message>
        <source>HTTP Communications (trackers, Web seeds, search engine)</source>
        <translation type="obsolete">HTTP Комуникације (пратиоци, Веб донори, претраживачки модул)</translation>
    </message>
    <message>
        <source>Host:</source>
        <translation>Домаћин:</translation>
    </message>
    <message>
        <source>Peer Communications</source>
        <translation type="obsolete">Peer (учесничке) Комуникације</translation>
    </message>
    <message>
        <source>SOCKS4</source>
        <translation>SOCKS4</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation>Тип:</translation>
    </message>
    <message>
        <source>Remove folder</source>
        <translatorcomment>фолдер-фасцикла-директоријум</translatorcomment>
        <translation>Уклони фолдер</translation>
    </message>
    <message>
        <source>(None)</source>
        <translation>(Ниједан)</translation>
    </message>
    <message>
        <source>HTTP</source>
        <translation>HTTP</translation>
    </message>
    <message>
        <source>Port:</source>
        <translation>Порт:</translation>
    </message>
    <message>
        <source>Authentication</source>
        <translation>Аутентификација</translation>
    </message>
    <message>
        <source>Username:</source>
        <translation>Корисничко име:</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation>Лозинка:</translation>
    </message>
    <message>
        <source>SOCKS5</source>
        <translation>SOCKS5</translation>
    </message>
    <message>
        <source>Filter path (.dat, .p2p, .p2b):</source>
        <translation>Филтер, путања фајла (.dat, .p2p, .p2b):</translation>
    </message>
    <message>
        <source>HTTP Server</source>
        <translation type="obsolete">HTTP Сервер</translation>
    </message>
    <message>
        <source>No action</source>
        <translation>Без дејства</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>Опције</translation>
    </message>
    <message>
        <source>Visual Appearance</source>
        <translatorcomment>Изглед</translatorcomment>
        <translation type="obsolete">Визуелни приказ</translation>
    </message>
    <message>
        <source>Action on double-click</source>
        <translation>Дејство при двоструком клику</translation>
    </message>
    <message>
        <source>Downloading torrents:</source>
        <translation>Преузимање торента:</translation>
    </message>
    <message>
        <source>Start / Stop</source>
        <translation type="obsolete">Старт/Стоп</translation>
    </message>
    <message>
        <source>Open destination folder</source>
        <translation>Отвори одредишну фасциклу</translation>
    </message>
    <message>
        <source>Completed torrents:</source>
        <translation>Завршени торенти:</translation>
    </message>
    <message>
        <source>Desktop</source>
        <translatorcomment>Desktop-Радни простор</translatorcomment>
        <translation>Радна површина</translation>
    </message>
    <message>
        <source>Show splash screen on start up</source>
        <translation>Прикажи уводни екран при пократању</translation>
    </message>
    <message>
        <source>Start qBittorrent minimized</source>
        <translation>Стартуј qBittorrent минимизовано</translation>
    </message>
    <message>
        <source>Show qBittorrent icon in notification area</source>
        <translation type="obsolete">Прикажи qBittorrent икону на системској палети</translation>
    </message>
    <message>
        <source>Minimize qBittorrent to notification area</source>
        <translation>Минимизуј qBittorrent на системску палету</translation>
    </message>
    <message>
        <source>Close qBittorrent to notification area</source>
        <comment>i.e: The systray tray icon will still be visible when closing the main window.</comment>
        <translation>Затвори qBittorrent на системску палету</translation>
    </message>
    <message>
        <source>Do not start the download automatically</source>
        <comment>The torrent will be added to download list in pause state</comment>
        <translation>Немој аутоматски да стартујеш преузимање</translation>
    </message>
    <message>
        <source>Save files to location:</source>
        <translation>Сачувај фајлове на локацији:</translation>
    </message>
    <message>
        <source>Append the label of the torrent to the save path</source>
        <translation>Додај ознаку торента у путању чувања</translation>
    </message>
    <message>
        <source>Pre-allocate disk space for all files</source>
        <translation>Додели простор на диску за све фајлове</translation>
    </message>
    <message>
        <source>Keep incomplete torrents in:</source>
        <translation>Задржи некомплетне торенте у:</translation>
    </message>
    <message>
        <source>Append .!qB extension to incomplete files&apos; names</source>
        <translation type="obsolete">Додај .!qB екстензију у некомплетна имена фајлова</translation>
    </message>
    <message>
        <source>Automatically add torrents from:</source>
        <translation>Аутоматски додај торенте из:</translation>
    </message>
    <message>
        <source>Add folder...</source>
        <translation>Додај фолдер...</translation>
    </message>
    <message>
        <source>IP Filtering</source>
        <translation>IP Филтрирање</translation>
    </message>
    <message>
        <source>Schedule the use of alternative speed limits</source>
        <translation type="obsolete">Распоред коришћења алтернативног ограничења брзине</translation>
    </message>
    <message>
        <source>from</source>
        <extracomment>from (time1 to time2)</extracomment>
        <translation>од</translation>
    </message>
    <message>
        <source>When:</source>
        <translation>Када:</translation>
    </message>
    <message>
        <source>Look for peers on your local network</source>
        <translatorcomment>peer-пир-учесник</translatorcomment>
        <translation>Потражите peer-ове на вашој локалној мрежи</translation>
    </message>
    <message>
        <source>Protocol encryption:</source>
        <translation type="obsolete">Протокол шифровања:</translation>
    </message>
    <message>
        <source>Enable Web User Interface (Remote control)</source>
        <translation>Омогући Веб Кориснички Интерфејс (Даљински приступ)</translation>
    </message>
    <message>
        <source>Share ratio limiting</source>
        <translation type="obsolete">Ограничење индекса дељења</translation>
    </message>
    <message>
        <source>Seed torrents until their ratio reaches</source>
        <translation>Донирај торенте док не достигнеш тражени ниво</translation>
    </message>
    <message>
        <source>then</source>
        <translation>затим</translation>
    </message>
    <message>
        <source>Pause them</source>
        <translation>Паузирај их</translation>
    </message>
    <message>
        <source>Remove them</source>
        <translation>Уклони их</translation>
    </message>
    <message utf8="true">
        <source>Exchange peers with compatible Bittorrent clients (µTorrent, Vuze, ...)</source>
        <translatorcomment>peer-пир-учесник</translatorcomment>
        <translation>Размењуј peer-ове са компатибилним Bittorrent клијентима (µTorrent, Vuze, ...)</translation>
    </message>
    <message>
        <source>Email notification upon download completion</source>
        <translation>Обавештење Е-поштом након комплетног преузимања</translation>
    </message>
    <message>
        <source>Destination email:</source>
        <translation>Адреса за Е-пошту:</translation>
    </message>
    <message>
        <source>SMTP server:</source>
        <translation>SMTP сервер:</translation>
    </message>
    <message>
        <source>Run an external program on torrent completion</source>
        <translation>Покрени екстерни програм по завршетку торента</translation>
    </message>
    <message>
        <source>Use %f to pass the torrent path in parameters</source>
        <translation type="obsolete">Користи %f за пролаз торент путање у параметрима</translation>
    </message>
    <message>
        <source>Proxy server</source>
        <translation type="obsolete">Прокси сервер</translation>
    </message>
    <message>
        <source>BitTorrent</source>
        <translation>Бит-торент</translation>
    </message>
    <message>
        <source>Start / Stop Torrent</source>
        <translation>Старт / Стоп Торент</translation>
    </message>
    <message>
        <source>Use UPnP / NAT-PMP port forwarding from my router</source>
        <translation>Користи UPnP / NAT-PMP преусмерење порта са мог рутера</translation>
    </message>
    <message>
        <source>Privacy</source>
        <translation>Приватност</translation>
    </message>
    <message>
        <source>Enable DHT (decentralized network) to find more peers</source>
        <translation>Омогући DHT (децентализовану мрежу) за налажење додатних учесника</translation>
    </message>
    <message>
        <source>Use a different port for DHT and BitTorrent</source>
        <translation>Користи различит порт за DHT и Бит-торент</translation>
    </message>
    <message>
        <source>Enable Peer Exchange (PeX) to find more peers</source>
        <translation>Омогући Peer Exchange (PeX) за налажење додатних учесника</translation>
    </message>
    <message>
        <source>Enable Local Peer Discovery to find more peers</source>
        <translation>Омогући откривање локалних веза за налажење додатних учесника</translation>
    </message>
    <message>
        <source>Encryption mode:</source>
        <translation>Режим шифровања:</translation>
    </message>
    <message>
        <source>Prefer encryption</source>
        <translation>Предложи шифровање</translation>
    </message>
    <message>
        <source>Require encryption</source>
        <translation>Захтевај шифровање</translation>
    </message>
    <message>
        <source>Disable encryption</source>
        <translation>Онемогући шифровање</translation>
    </message>
    <message>
        <source>User Interface</source>
        <translation type="obsolete">Кориснички интерфејс</translation>
    </message>
    <message>
        <source>Reload the filter</source>
        <translation>Поново учитај филтер</translation>
    </message>
    <message>
        <source>Behavior</source>
        <translation>Понашање</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Језик</translation>
    </message>
    <message>
        <source>Power Management</source>
        <translation>Управљање напајањем</translation>
    </message>
    <message>
        <source>Inhibit system sleep when torrents are active</source>
        <translation>Спречи стање мировања када су торенти активни</translation>
    </message>
    <message>
        <source>Bypass authentication for localhost</source>
        <translation>Заобиђи аутентификацију за localhost-а</translation>
    </message>
    <message>
        <source>Ask for program exit confirmation</source>
        <translation>Захтевај потврду за излазак из програма</translation>
    </message>
    <message>
        <source>Use monochrome system tray icon (requires restart)</source>
        <translation type="obsolete">Користи једнобојну икону на системској палети (захтева рестарт)</translation>
    </message>
    <message>
        <source>The following parameters are supported:
&lt;ul&gt;
&lt;li&gt;%f: Torrent path&lt;/li&gt;
&lt;li&gt;%n: Torrent name&lt;/li&gt;
&lt;/ul&gt;</source>
        <translation>Следећи параметри су подржани:
&lt;ul&gt;
&lt;li&gt;%f: Torrent путања&lt;/li&gt;
&lt;li&gt;%n: Torrent име&lt;/li&gt;
&lt;/ul&gt;</translation>
    </message>
    <message>
        <source>User Interface Language:</source>
        <translation>Кориснички интерфејс Језик:</translation>
    </message>
    <message>
        <source>Transfer List</source>
        <translation>Трансфер листа</translation>
    </message>
    <message>
        <source>Show qBittorrent in notification area</source>
        <translation>Прикажи qBittorrent на системској палети</translation>
    </message>
    <message>
        <source>Tray icon style:</source>
        <translation>Изглед системске иконе:</translation>
    </message>
    <message>
        <source>Normal</source>
        <translation>Нормалан</translation>
    </message>
    <message>
        <source>Monochrome (Dark theme)</source>
        <translation>Једнобојан (Тамна тема)</translation>
    </message>
    <message>
        <source>Monochrome (Light theme)</source>
        <translation>Једнобојан (Светла тема)</translation>
    </message>
    <message>
        <source>Hard Disk</source>
        <translation>Хард диск</translation>
    </message>
    <message>
        <source>This server requires a secure connection (SSL)</source>
        <translation>Овај сервер захтева безбедну конекцију (SSL)</translation>
    </message>
    <message>
        <source>Listening Port</source>
        <translation>Пријемни порт</translation>
    </message>
    <message>
        <source>Connections Limits</source>
        <translation>Конекциона ограничења</translation>
    </message>
    <message>
        <source>Proxy Server</source>
        <translation>Прокси сервер</translation>
    </message>
    <message>
        <source>Global Rate Limits</source>
        <translation>Општа вредност ограничења</translation>
    </message>
    <message>
        <source>Enable bandwidth management (uTP)</source>
        <translation>Омогући управљање пропусног опсега (uTP)</translation>
    </message>
    <message>
        <source>Apply rate limit to uTP connections</source>
        <translation>Примени ведност ограничења на  uTP конекције</translation>
    </message>
    <message>
        <source>Apply rate limit to transport overhead</source>
        <translation>Примени ведносна ограничења код прекорачење преноса</translation>
    </message>
    <message>
        <source>Alternative Global Rate Limits</source>
        <translation>Алтернатива општег ограничења брзине</translation>
    </message>
    <message>
        <source>Schedule the use of alternative rate limits</source>
        <translation>Распоред коришћења алтернативног ограничења брзине</translation>
    </message>
    <message>
        <source>Torrent Queueing</source>
        <translation>Опслуживање Торета</translation>
    </message>
    <message>
        <source>Share Ratio Limiting</source>
        <translation>Ограничење индекса дељења</translation>
    </message>
    <message>
        <source>Use UPnP / NAT-PMP to forward the port from my router</source>
        <translation>Користи UPnP / NAT-PMP преусмерење порта са мог рутера</translation>
    </message>
    <message>
        <source>Update my dynamic domain name</source>
        <translation>Обнови име мог динамичког домена</translation>
    </message>
    <message>
        <source>Service:</source>
        <translation>Сервис:</translation>
    </message>
    <message>
        <source>Register</source>
        <translation>Регистар</translation>
    </message>
    <message>
        <source>Domain name:</source>
        <translation>Име домена:</translation>
    </message>
    <message>
        <source>Otherwise, the proxy server is only used for tracker connections</source>
        <translatorcomment>tracker-пратилац</translatorcomment>
        <translation>У супротном, прокси сервер се једино користи за конекције tracker-а(пратилаца)</translation>
    </message>
    <message>
        <source>Use proxy for peer connections</source>
        <translatorcomment>peer-учесник</translatorcomment>
        <translation>Користи прокси за peer(учесничке) конекције</translation>
    </message>
    <message>
        <source>Append .!qB extension to incomplete files</source>
        <translation>Додај .!qB екстензију у некомплетне фајлове</translation>
    </message>
    <message>
        <source>Use HTTPS instead of HTTP</source>
        <translation>Користи HTTPS уместо HTTP</translation>
    </message>
    <message>
        <source>Import SSL Certificate</source>
        <translation>Увоз SSL сертификата</translation>
    </message>
    <message>
        <source>Import SSL Key</source>
        <translation>Увоз SSL кључа</translation>
    </message>
    <message>
        <source>Certificate:</source>
        <translation>Сертификат:</translation>
    </message>
    <message>
        <source>Key:</source>
        <translation>Кључ:</translation>
    </message>
    <message>
        <source>&lt;a href=http://httpd.apache.org/docs/2.1/ssl/ssl_faq.html#aboutcerts&gt;Information about certificates&lt;/a&gt;</source>
        <translation>&lt;a href=http://httpd.apache.org/docs/2.1/ssl/ssl_faq.html#aboutcerts&gt;Information about certificates&lt;/a&gt;</translation>
    </message>
</context>
<context>
    <name>PreviewSelect</name>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Величина</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation>Напредак</translation>
    </message>
    <message>
        <source>Preview impossible</source>
        <translation>Приказ немогућ</translation>
    </message>
    <message>
        <source>Sorry, we can&apos;t preview this file</source>
        <translation>Жалим не могу да прикажем овај фајл</translation>
    </message>
</context>
<context>
    <name>ProgramUpdater</name>
    <message>
        <source>Could not create the file %1</source>
        <translation type="obsolete">Није могуће креирати датотеку %1</translation>
    </message>
    <message>
        <source>Failed to download the update at %1</source>
        <comment>%1 is an URL</comment>
        <translation type="obsolete">Неуспешно преузимање ажурирања са %1</translation>
    </message>
</context>
<context>
    <name>PropListDelegate</name>
    <message>
        <source>Not downloaded</source>
        <translation>Не преузимај</translation>
    </message>
    <message>
        <source>Normal</source>
        <comment>Normal (priority)</comment>
        <translation>Нормалан</translation>
    </message>
    <message>
        <source>High</source>
        <comment>High (priority)</comment>
        <translation>Висок</translation>
    </message>
    <message>
        <source>Maximum</source>
        <comment>Maximum (priority)</comment>
        <translation>Максималан</translation>
    </message>
    <message>
        <source>Mixed</source>
        <comment>Mixed (priorities</comment>
        <translation>Комбинован</translation>
    </message>
</context>
<context>
    <name>PropTabBar</name>
    <message>
        <source>General</source>
        <translation>Опште</translation>
    </message>
    <message>
        <source>Trackers</source>
        <translation>Пратиоци</translation>
    </message>
    <message>
        <source>Peers</source>
        <translation>Peers (учесници)</translation>
    </message>
    <message>
        <source>URL Seeds</source>
        <translation type="obsolete">URL донори</translation>
    </message>
    <message>
        <source>Files</source>
        <translation type="obsolete">Фајлови</translation>
    </message>
    <message>
        <source>HTTP Sources</source>
        <translation>HTTP извори</translation>
    </message>
    <message>
        <source>Content</source>
        <translation>Садржај</translation>
    </message>
</context>
<context>
    <name>PropertiesWidget</name>
    <message>
        <source>Save path:</source>
        <translation>Сачувај у:</translation>
    </message>
    <message>
        <source>Torrent hash:</source>
        <translatorcomment>hash-контролна сума</translatorcomment>
        <translation>Торент hash:</translation>
    </message>
    <message>
        <source>Share ratio:</source>
        <translation>Однос дељења:</translation>
    </message>
    <message>
        <source>Downloaded:</source>
        <translation>Преузето:</translation>
    </message>
    <message>
        <source>Availability:</source>
        <translation>Доступност:</translation>
    </message>
    <message>
        <source>Transfer</source>
        <translatorcomment>Трансфер-Пренос</translatorcomment>
        <translation>Трансфер</translation>
    </message>
    <message>
        <source>Uploaded:</source>
        <translation>Послато:</translation>
    </message>
    <message>
        <source>Wasted:</source>
        <translation>Потрошено:</translation>
    </message>
    <message>
        <source>UP limit:</source>
        <translatorcomment>Ограничење слања</translatorcomment>
        <translation>СЛ лимит:</translation>
    </message>
    <message>
        <source>DL limit:</source>
        <translatorcomment>Ограничење преузимања</translatorcomment>
        <translation>ПР лимит:</translation>
    </message>
    <message>
        <source>Time elapsed:</source>
        <translation type="obsolete">Протекло време:</translation>
    </message>
    <message>
        <source>Connections:</source>
        <translation>Конекције:</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Информације</translation>
    </message>
    <message>
        <source>Created on:</source>
        <translation>Креирано у:</translation>
    </message>
    <message>
        <source>Comment:</source>
        <translation>Коментар:</translation>
    </message>
    <message>
        <source>General</source>
        <translation type="obsolete">Опште</translation>
    </message>
    <message>
        <source>Trackers</source>
        <translatorcomment>Trackers-Трагачи,Пратиоци</translatorcomment>
        <translation type="obsolete">Пратиоци</translation>
    </message>
    <message>
        <source>Peers</source>
        <translation type="obsolete">Peers (учесници)</translation>
    </message>
    <message>
        <source>URL seeds</source>
        <translatorcomment>донори-seeds</translatorcomment>
        <translation type="obsolete">URL донори</translation>
    </message>
    <message>
        <source>Files</source>
        <translation type="obsolete">Фајлови</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Приоритет</translation>
    </message>
    <message>
        <source>Normal</source>
        <translation>Нормалан</translation>
    </message>
    <message>
        <source>Maximum</source>
        <translation>Максималан</translation>
    </message>
    <message>
        <source>High</source>
        <translation>Висок</translation>
    </message>
    <message>
        <source>this session</source>
        <translation>ова сесија</translation>
    </message>
    <message>
        <source>/s</source>
        <comment>/second (i.e. per second)</comment>
        <translation>/s</translation>
    </message>
    <message>
        <source>Seeded for %1</source>
        <comment>e.g. Seeded for 3m10s</comment>
        <translation>Донирано за %1</translation>
    </message>
    <message>
        <source>%1 max</source>
        <comment>e.g. 10 max</comment>
        <translation>%1 max</translation>
    </message>
    <message>
        <source>I/O Error</source>
        <translation>И/О Грешка</translation>
    </message>
    <message>
        <source>This file does not exist yet.</source>
        <translation>Овај фајл више не постоји.</translation>
    </message>
    <message>
        <source>This folder does not exist yet.</source>
        <translation>Овај директоријум више не постоји.</translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation>Преименуј...</translation>
    </message>
    <message>
        <source>Rename the file</source>
        <translation>Преименуј фајл</translation>
    </message>
    <message>
        <source>New name:</source>
        <translation>Ново име:</translation>
    </message>
    <message>
        <source>The file could not be renamed</source>
        <translation>Фајл не може бити преименован</translation>
    </message>
    <message>
        <source>This file name contains forbidden characters, please choose a different one.</source>
        <translation>Ово име фајла садржи недозвољене карактере, молим изаберите неко друго.</translation>
    </message>
    <message>
        <source>This name is already in use in this folder. Please use a different name.</source>
        <translation>Ово име је већ у употреби молим изаберите неко друго.</translation>
    </message>
    <message>
        <source>The folder could not be renamed</source>
        <translation>Фолдер не може бити преименован</translation>
    </message>
    <message>
        <source>New url seed</source>
        <comment>New HTTP source</comment>
        <translation>Нови Url донор</translation>
    </message>
    <message>
        <source>New url seed:</source>
        <translation>Нови Url донор:</translation>
    </message>
    <message>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <source>This url seed is already in the list.</source>
        <translation>Овај Url донор је већ на листи.</translation>
    </message>
    <message>
        <source>Choose save path</source>
        <translation>Изаберите путању чувања</translation>
    </message>
    <message>
        <source>Save path creation error</source>
        <translation type="obsolete">Грешка у путањи за чување</translation>
    </message>
    <message>
        <source>Could not create the save path</source>
        <translation type="obsolete">Не могу да креирам путању за чување фајла</translation>
    </message>
    <message>
        <source>Reannounce in:</source>
        <translation>Поново објави за:</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Селектуј све</translation>
    </message>
    <message>
        <source>Select None</source>
        <translation>Деселектуј</translation>
    </message>
    <message>
        <source>Do not download</source>
        <translation>Не преузимај</translation>
    </message>
    <message>
        <source>Pieces size:</source>
        <translation>Делови величине:</translation>
    </message>
    <message>
        <source>Time active:</source>
        <extracomment>Time (duration) the torrent is active (not paused)</extracomment>
        <translation>Протекло време:</translation>
    </message>
    <message>
        <source>Torrent content:</source>
        <translation>Садржај Торента:</translation>
    </message>
</context>
<context>
    <name>QBtSession</name>
    <message>
        <source>%1 reached the maximum ratio you set.</source>
        <translation>%1 достигао је максимални ниво који сте подесили.</translation>
    </message>
    <message>
        <source>Removing torrent %1...</source>
        <translation>Уклањање торента %1...</translation>
    </message>
    <message>
        <source>Pausing torrent %1...</source>
        <translation>Паузирање торента %1...</translation>
    </message>
    <message>
        <source>qBittorrent is bound to port: TCP/%1</source>
        <comment>e.g: qBittorrent is bound to port: 6881</comment>
        <translation>qBittorrent је повезан на порт: TCP/%1</translation>
    </message>
    <message>
        <source>UPnP support [ON]</source>
        <translation type="obsolete">UPnP подршка [Укључена]</translation>
    </message>
    <message>
        <source>UPnP support [OFF]</source>
        <translation type="obsolete">UPnP подршка [Искључена]</translation>
    </message>
    <message>
        <source>NAT-PMP support [ON]</source>
        <translation type="obsolete">NAT-PMP подршка [Укључена]</translation>
    </message>
    <message>
        <source>NAT-PMP support [OFF]</source>
        <translation type="obsolete">NAT-PMP подршка [Искључена]</translation>
    </message>
    <message>
        <source>HTTP user agent is %1</source>
        <translation>HTTP кориснички агент је %1</translation>
    </message>
    <message>
        <source>Using a disk cache size of %1 MiB</source>
        <translation type="obsolete">Користи кеш диска величине %1 MiB</translation>
    </message>
    <message>
        <source>DHT support [ON], port: UDP/%1</source>
        <translation>DHT подршка [Укључена], порт: UDP/%1</translation>
    </message>
    <message>
        <source>DHT support [OFF]</source>
        <translation>DHT подршка [Искључена]</translation>
    </message>
    <message>
        <source>PeX support [ON]</source>
        <translation>PeX подршка [Укључена]</translation>
    </message>
    <message>
        <source>PeX support [OFF]</source>
        <translation>PeX подршка [Искључена]</translation>
    </message>
    <message>
        <source>Restart is required to toggle PeX support</source>
        <translation>Потребан је рестарт за активирање PeX подршке</translation>
    </message>
    <message>
        <source>Local Peer Discovery [ON]</source>
        <translation type="obsolete">Претраживање локалних веза [Укључено]</translation>
    </message>
    <message>
        <source>Local Peer Discovery support [OFF]</source>
        <translation>Претраживање локалних веза подршка [Искључено]</translation>
    </message>
    <message>
        <source>Encryption support [ON]</source>
        <translation>Шифровање подршка [Укључена]</translation>
    </message>
    <message>
        <source>Encryption support [FORCED]</source>
        <translation>Шифровање подршка [Форсирано]</translation>
    </message>
    <message>
        <source>Encryption support [OFF]</source>
        <translation>Шифровање подршка [Искључена]</translation>
    </message>
    <message>
        <source>Embedded Tracker [ON]</source>
        <translation>Уграђени пратилац [Укључен]</translation>
    </message>
    <message>
        <source>Failed to start the embedded tracker!</source>
        <translation>Неуспешно покретање уграђеног пратиоца!</translation>
    </message>
    <message>
        <source>Embedded Tracker [OFF]</source>
        <translation>Уграђени пратилац [Искључен]</translation>
    </message>
    <message>
        <source>The Web UI is listening on port %1</source>
        <translation>Веб КИ надгледа порт %1</translation>
    </message>
    <message>
        <source>Web User Interface Error - Unable to bind Web UI to port %1</source>
        <translation>Веб Кориснички Интерфејс Грешка - Не могу да повежем Веб КИ на порт %1</translation>
    </message>
    <message>
        <source>&apos;%1&apos; was removed from transfer list and hard disk.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>&apos;%1&apos; је уклоњен са трансфер листе и хард диска.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; was removed from transfer list.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>&apos;%1&apos; је уклоњен са трансфер листе.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is not a valid magnet URI.</source>
        <translation>&apos;%1&apos; није валидан магнет URI.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is already in download list.</source>
        <comment>e.g: &apos;xxx.avi&apos; is already in download list.</comment>
        <translation>&apos;%1&apos; већ је додат на листу за преузимање.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; resumed. (fast resume)</source>
        <comment>&apos;/home/y/xxx.torrent&apos; was resumed. (fast resume)</comment>
        <translation>&apos;%1&apos; настави. (брзо настави)</translation>
    </message>
    <message>
        <source>&apos;%1&apos; added to download list.</source>
        <comment>&apos;/home/y/xxx.torrent&apos; was added to download list.</comment>
        <translation>&apos;%1&apos; додат на листу за преузимање.</translation>
    </message>
    <message>
        <source>Unable to decode torrent file: &apos;%1&apos;</source>
        <comment>e.g: Unable to decode torrent file: &apos;/home/y/xxx.torrent&apos;</comment>
        <translation>Није у стању да декодира торент фајл: &apos;%1&apos;</translation>
    </message>
    <message>
        <source>This file is either corrupted or this isn&apos;t a torrent.</source>
        <translation>Овај фајл је оштећен или ово није торент.</translation>
    </message>
    <message>
        <source>Error: The torrent %1 does not contain any file.</source>
        <translation>Грешка: Торент %1 не садржи ни један фајл.</translation>
    </message>
    <message>
        <source>Note: new trackers were added to the existing torrent.</source>
        <translation>Напомена: нови пратиоци су додати у постојећи торент.</translation>
    </message>
    <message>
        <source>Note: new URL seeds were added to the existing torrent.</source>
        <translation>Напомена: нови URL донори су додати у постојећи торент.</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;was blocked due to your IP filter&lt;/i&gt;</source>
        <comment>x.y.z.w was blocked</comment>
        <translation>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;је блокиран због вашег IP филтера&lt;/i&gt;</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;was banned due to corrupt pieces&lt;/i&gt;</source>
        <comment>x.y.z.w was banned</comment>
        <translation>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;је одбачен због оштећених делова&lt;/i&gt;</translation>
    </message>
    <message>
        <source>Recursive download of file %1 embedded in torrent %2</source>
        <comment>Recursive download of test.torrent embedded in torrent test2</comment>
        <translation>Поновно преузимање фајла %1 омогућено у торенту %2</translation>
    </message>
    <message>
        <source>Unable to decode %1 torrent file.</source>
        <translation>Није у стању да декодира %1 торент фајл.</translation>
    </message>
    <message>
        <source>Torrent name: %1</source>
        <translation>Име Торента: %1</translation>
    </message>
    <message>
        <source>Torrent size: %1</source>
        <translation>Величина Торента: %1</translation>
    </message>
    <message>
        <source>Save path: %1</source>
        <translation>Путања чувања: %1</translation>
    </message>
    <message>
        <source>The torrent was downloaded in %1.</source>
        <comment>The torrent was downloaded in 1 hour and 20 seconds</comment>
        <translation>Торент ће бити преузет за %1.</translation>
    </message>
    <message>
        <source>Thank you for using qBittorrent.</source>
        <translation>Хвала што користите qBittorrent.</translation>
    </message>
    <message>
        <source>[qBittorrent] %1 has finished downloading</source>
        <translation>[qBittorrent] %1 је завршио преузимање</translation>
    </message>
    <message>
        <source>An I/O error occured, &apos;%1&apos; paused.</source>
        <translation>Нека И/О грешка се догодила, &apos;%1&apos; паузирано.</translation>
    </message>
    <message>
        <source>Reason: %1</source>
        <translation>Разлог: %1</translation>
    </message>
    <message>
        <source>UPnP/NAT-PMP: Port mapping failure, message: %1</source>
        <translation>UPnP/NAT-PMP: Порт мапирање грешка, порука: %1</translation>
    </message>
    <message>
        <source>UPnP/NAT-PMP: Port mapping successful, message: %1</source>
        <translation>UPnP/NAT-PMP: Порт мапирање успешно, порука: %1</translation>
    </message>
    <message>
        <source>File sizes mismatch for torrent %1, pausing it.</source>
        <translation>Величина фајла није одговарајућа за торент %1, паузирајте га.</translation>
    </message>
    <message>
        <source>Fast resume data was rejected for torrent %1, checking again...</source>
        <translation>Брзи наставак података је одбијен за торент %1, покушајте поново...</translation>
    </message>
    <message>
        <source>Url seed lookup failed for url: %1, message: %2</source>
        <translation>Url преглед донора , грешка url: %1, порука: %2</translation>
    </message>
    <message>
        <source>Downloading &apos;%1&apos;, please wait...</source>
        <comment>e.g: Downloading &apos;xxx.torrent&apos;, please wait...</comment>
        <translation>Преузимање &apos;%1&apos;, молим сачекајте...</translation>
    </message>
    <message>
        <source>The network interface defined is invalid: %1</source>
        <translation>Мрежни интерфејс који је задат је погрешан: %1</translation>
    </message>
    <message>
        <source>Trying any other network interface available instead.</source>
        <translation>Пробајте неки други доступни мрежни интрфејс уместо тога.</translation>
    </message>
    <message>
        <source>Listening on IP address %1 on network interface %2...</source>
        <translation>Надгледај IP адресе %1 на мрежном интерфејсу %2...</translation>
    </message>
    <message>
        <source>Failed to listen on network interface %1</source>
        <translation>Грешка при надгледању мрежног интрфејса %1</translation>
    </message>
    <message>
        <source>UPnP / NAT-PMP support [ON]</source>
        <translation>UPnP / NAT-PMP подршка [Укључена]</translation>
    </message>
    <message>
        <source>UPnP / NAT-PMP support [OFF]</source>
        <translation>UPnP / NAT-PMP подршка [Искључена]</translation>
    </message>
    <message>
        <source>Local Peer Discovery support [ON]</source>
        <translation>Претраживање локалних веза подршка [Укључено]</translation>
    </message>
    <message>
        <source>Successfuly parsed the provided IP filter: %1 rules were applied.</source>
        <comment>%1 is a number</comment>
        <translation>Успешна анализа датог IP филтера: %1 правила су примењена.</translation>
    </message>
    <message>
        <source>Error: Failed to parse the provided IP filter.</source>
        <translation>Грешка: Неспешна анализа датог IP филтера.</translation>
    </message>
    <message>
        <source>Reporting IP address %1 to trackers...</source>
        <translation>Пријављивање IP адреса %1 пратиоцима...</translation>
    </message>
    <message>
        <source>The computer will now go to sleep mode unless you cancel within the next 15 seconds...</source>
        <translation>Рачунар ће сада отићи у стање мировања осим ако то не откажете у наредних 15 секунди...</translation>
    </message>
    <message>
        <source>The computer will now be switched off unless you cancel within the next 15 seconds...</source>
        <translation>Рачунар ће сада бити искључен осим ако то не откажете у наредних 15 секунди...</translation>
    </message>
    <message>
        <source>qBittorrent will now exit unless you cancel within the next 15 seconds...</source>
        <translation>qBittorrent ће сада бити искључен осим ако то не откажете у наредних 15 секунди...</translation>
    </message>
</context>
<context>
    <name>RSS</name>
    <message>
        <source>Search</source>
        <translation>Претраживање</translation>
    </message>
    <message>
        <source>New subscription</source>
        <translation>Нови допис</translation>
    </message>
    <message>
        <source>Mark items read</source>
        <translation>Означи прочитане ставке</translation>
    </message>
    <message>
        <source>Update all</source>
        <translation>Ажурирај све</translation>
    </message>
    <message>
        <source>RSS feeds</source>
        <translatorcomment>feed-допис,порука</translatorcomment>
        <translation type="obsolete">RSS поруке</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Torrents:&lt;/span&gt; &lt;span style=&quot; font-style:italic;&quot;&gt;(double-click to download)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Торенти:&lt;/span&gt; &lt;span style=&quot; font-style:italic;&quot;&gt;(двоструки клик за преузимање)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Article title</source>
        <translation type="obsolete">Наслов чланка</translation>
    </message>
    <message>
        <source>Feed URL</source>
        <translation type="obsolete">Оглашавач URL</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Обриши</translation>
    </message>
    <message>
        <source>Rename</source>
        <translation>Преименуј</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Ажурирај</translation>
    </message>
    <message>
        <source>Update all feeds</source>
        <translation>Ажурирај све поруке</translation>
    </message>
    <message>
        <source>Download torrent</source>
        <translation>Преузми Торент</translation>
    </message>
    <message>
        <source>Open news URL</source>
        <translation>Отвори новости URL</translation>
    </message>
    <message>
        <source>Copy feed URL</source>
        <translatorcomment>feed-допис,порука</translatorcomment>
        <translation>Копирај feed URL</translation>
    </message>
    <message>
        <source>Refresh RSS streams</source>
        <translation>Освежи RSS токове података</translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation>Преименуј...</translation>
    </message>
    <message>
        <source>New subscription...</source>
        <translation>Нови допис...</translation>
    </message>
    <message>
        <source>RSS feed downloader...</source>
        <translation type="obsolete">RSS преузимач порука...</translation>
    </message>
    <message>
        <source>New folder...</source>
        <translation>Нова фасцикла...</translation>
    </message>
    <message>
        <source>Manage cookies...</source>
        <translation>Управљање колачићима...</translation>
    </message>
    <message>
        <source>Settings...</source>
        <translation>Подешавања...</translation>
    </message>
    <message>
        <source>RSS Downloader...</source>
        <translation>RSS преузимач порука...</translation>
    </message>
</context>
<context>
    <name>RSSImp</name>
    <message>
        <source>Please type a rss stream url</source>
        <translation>Молим упишите rss ток података url</translation>
    </message>
    <message>
        <source>Stream URL:</source>
        <translation>Ток података URL:</translation>
    </message>
    <message>
        <source>Are you sure? -- qBittorrent</source>
        <translation>Да ли сте сигурни? -- qBittorrent</translation>
    </message>
    <message>
        <source>&amp;Yes</source>
        <translation>&amp;Да</translation>
    </message>
    <message>
        <source>&amp;No</source>
        <translation>&amp;Не</translation>
    </message>
    <message>
        <source>Please choose a folder name</source>
        <translatorcomment>фасцикла-фолдер</translatorcomment>
        <translation>Молим изаберите име фасцикле</translation>
    </message>
    <message>
        <source>Folder name:</source>
        <translatorcomment>фасцикла-фолдер</translatorcomment>
        <translation>Име фасцикле:</translation>
    </message>
    <message>
        <source>New folder</source>
        <translatorcomment>фасцикла-фолдер</translatorcomment>
        <translation>Нова фасцикла</translation>
    </message>
    <message>
        <source>Overwrite attempt</source>
        <translation>Покушај преписивања</translation>
    </message>
    <message>
        <source>You cannot overwrite %1 item.</source>
        <comment>You cannot overwrite myFolder item.</comment>
        <translatorcomment>Не можете да препишете myFolder ставку.</translatorcomment>
        <translation>Не можете да препишете %1 ставку.</translation>
    </message>
    <message>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <source>This rss feed is already in the list.</source>
        <translation>Ова RSS порука већ постоји на листи.</translation>
    </message>
    <message>
        <source>Are you sure you want to delete these elements from the list?</source>
        <translation>Јесте ли сигурни да желите да избришете ове елементе из листе?</translation>
    </message>
    <message>
        <source>Are you sure you want to delete this element from the list?</source>
        <translation>Јесте ли сигурни да желите да обришете овај елемент са листе?</translation>
    </message>
    <message>
        <source>Please choose a new name for this RSS feed</source>
        <translatorcomment>feed-допис,порука</translatorcomment>
        <translation>Молим изаберит ново име за овај RSS допис</translation>
    </message>
    <message>
        <source>New feed name:</source>
        <translatorcomment>feed-допис,порука</translatorcomment>
        <translation>Ново feed име:</translation>
    </message>
    <message>
        <source>Name already in use</source>
        <translation>Име је већ у употреби</translation>
    </message>
    <message>
        <source>This name is already used by another item, please choose another one.</source>
        <translation>Ово име је већ у употреби молим изаберите неко друго.</translation>
    </message>
    <message>
        <source>Date: </source>
        <translation>Датум: </translation>
    </message>
    <message>
        <source>Author: </source>
        <translation>Аутор: </translation>
    </message>
    <message>
        <source>Unread</source>
        <translation>Непрочитан</translation>
    </message>
</context>
<context>
    <name>RssArticle</name>
    <message>
        <source>No description available</source>
        <translation type="obsolete">Нема доступних описа</translation>
    </message>
</context>
<context>
    <name>RssFeed</name>
    <message>
        <source>Automatically downloading %1 torrent from %2 RSS feed...</source>
        <translation>Аутоматски преузми %1 торент са %2 RSS feed-а...</translation>
    </message>
</context>
<context>
    <name>RssItem</name>
    <message>
        <source>No description available</source>
        <translation type="obsolete">Нема доступних описа</translation>
    </message>
</context>
<context>
    <name>RssSettings</name>
    <message>
        <source>RSS Reader Settings</source>
        <translation type="obsolete">RSS читач Подешавања</translation>
    </message>
    <message>
        <source>RSS feeds refresh interval:</source>
        <translation type="obsolete">RSS поруке интервал освежавања:</translation>
    </message>
    <message>
        <source>minutes</source>
        <translation type="obsolete">минута</translation>
    </message>
    <message>
        <source>Maximum number of articles per feed:</source>
        <translation type="obsolete">Максимални број чланака по допису:</translation>
    </message>
</context>
<context>
    <name>RssSettingsDlg</name>
    <message>
        <source>RSS Reader Settings</source>
        <translation>RSS читач Подешавања</translation>
    </message>
    <message>
        <source>RSS feeds refresh interval:</source>
        <translation>RSS поруке интервал освежавања:</translation>
    </message>
    <message>
        <source>minutes</source>
        <translation>минута</translation>
    </message>
    <message>
        <source>Maximum number of articles per feed:</source>
        <translation>Максимални број чланака по допису:</translation>
    </message>
</context>
<context>
    <name>RssStream</name>
    <message>
        <source>Automatically downloading %1 torrent from %2 RSS feed...</source>
        <translatorcomment>feed-допис,порука</translatorcomment>
        <translation type="obsolete">Аутоматски преузми %1 торент са %2 RSS feed...</translation>
    </message>
</context>
<context>
    <name>ScanFoldersModel</name>
    <message>
        <source>Watched Folder</source>
        <translation>Надгледани Фолдер</translation>
    </message>
    <message>
        <source>Download here</source>
        <translation>Преузими одавде</translation>
    </message>
</context>
<context>
    <name>SearchCategories</name>
    <message>
        <source>All categories</source>
        <translation>Све категорије</translation>
    </message>
    <message>
        <source>Movies</source>
        <translation>Филмови</translation>
    </message>
    <message>
        <source>TV shows</source>
        <translation>ТВ емисије</translation>
    </message>
    <message>
        <source>Music</source>
        <translation>Музика</translation>
    </message>
    <message>
        <source>Games</source>
        <translation>Игре</translation>
    </message>
    <message>
        <source>Anime</source>
        <translatorcomment>Забава</translatorcomment>
        <translation>Анимације</translation>
    </message>
    <message>
        <source>Software</source>
        <translation>Софтвер</translation>
    </message>
    <message>
        <source>Pictures</source>
        <translation>Слике</translation>
    </message>
    <message>
        <source>Books</source>
        <translation>Књиге</translation>
    </message>
</context>
<context>
    <name>SearchEngine</name>
    <message>
        <source>Cut</source>
        <translation>Исеци</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Копирај</translation>
    </message>
    <message>
        <source>Paste</source>
        <translatorcomment>Пренеси,Налепи</translatorcomment>
        <translation>Додај</translation>
    </message>
    <message>
        <source>Clear field</source>
        <translation>Обриши поље</translation>
    </message>
    <message>
        <source>Clear completion history</source>
        <translation>Обриши комплетну историју</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Претраживање</translation>
    </message>
    <message>
        <source>Empty search pattern</source>
        <translation>Празано поље претраживања</translation>
    </message>
    <message>
        <source>Please type a search pattern first</source>
        <translation>Унесите прво назив за претраживање</translation>
    </message>
    <message>
        <source>Results</source>
        <translation>Резултати</translation>
    </message>
    <message>
        <source>Searching...</source>
        <translation>Претраживање...</translation>
    </message>
    <message>
        <source>Search Engine</source>
        <translation>Претраживачки модул</translation>
    </message>
    <message>
        <source>Search has finished</source>
        <translation>Претраживање је завршено</translation>
    </message>
    <message>
        <source>An error occured during search...</source>
        <translation>Нека грешка се догодила током претраге...</translation>
    </message>
    <message>
        <source>Search aborted</source>
        <translation>Претраживање прекинуто</translation>
    </message>
    <message>
        <source>Search returned no results</source>
        <translation>Претрага није дала резултате</translation>
    </message>
    <message>
        <source>Results</source>
        <comment>i.e: Search results</comment>
        <translation>Резултати</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Непознат</translation>
    </message>
    <message>
        <source>Download error</source>
        <translation>Грешка преузимања</translation>
    </message>
    <message>
        <source>Python setup could not be downloaded, reason: %1.
Please install it manually.</source>
        <translation>Python setup не може бити преузет,разлог: %1.
Молим Вас инсталирајте га ручно.</translation>
    </message>
    <message>
        <source>Missing Python Interpreter</source>
        <translation>Недостаје Python преводилац</translation>
    </message>
    <message>
        <source>Python 2.x is required to use the search engine but it does not seem to be installed.
Do you want to install it now?</source>
        <translation>Pithon 2.х је потребан за коришћење претраживачког модула, али изгледа да није инсталиран.
Да ли желите да га инсталирате?</translation>
    </message>
    <message>
        <source>Confirmation</source>
        <translation>Потврђивање</translation>
    </message>
    <message>
        <source>Are you sure you want to clear the history?</source>
        <translation>Да ли сте сигурни да желите да обришете историјат?</translation>
    </message>
</context>
<context>
    <name>SearchTab</name>
    <message>
        <source>Name</source>
        <comment>i.e: file name</comment>
        <translation>Име</translation>
    </message>
    <message>
        <source>Size</source>
        <comment>i.e: file size</comment>
        <translation>Величина</translation>
    </message>
    <message>
        <source>Seeders</source>
        <comment>i.e: Number of full sources</comment>
        <translatorcomment>Seeders-Донори</translatorcomment>
        <translation>Донори</translation>
    </message>
    <message>
        <source>Leechers</source>
        <comment>i.e: Number of partial sources</comment>
        <translatorcomment>Leechers-Трагачи</translatorcomment>
        <translation>Трагачи</translation>
    </message>
    <message>
        <source>Search engine</source>
        <translation>Претраживачки модул</translation>
    </message>
</context>
<context>
    <name>ShutdownConfirmDlg</name>
    <message>
        <source>Shutdown confirmation</source>
        <translation>Потврђивање искључења</translation>
    </message>
</context>
<context>
    <name>SpeedLimitDialog</name>
    <message>
        <source>KiB/s</source>
        <translation>KiB/s</translation>
    </message>
</context>
<context>
    <name>StatusBar</name>
    <message>
        <source>Connection status:</source>
        <translation>Статус конекције:</translation>
    </message>
    <message>
        <source>No direct connections. This may indicate network configuration problems.</source>
        <translation>Нема директних конекција. То може указивати на проблем мрежне конфигурације.</translation>
    </message>
    <message>
        <source>D: %1 B/s - T: %2</source>
        <comment>Download speed: x B/s - Transferred: x MiB</comment>
        <translatorcomment>Брзина преузимања: x B/s - Транспортовано: x MiB</translatorcomment>
        <translation type="obsolete">П: %1 B/s - T: %2</translation>
    </message>
    <message>
        <source>U: %1 B/s - T: %2</source>
        <comment>Upload speed: x B/s - Transferred: x MiB</comment>
        <translatorcomment>Брзина слања: x B/s - Транспортовано: x MiB</translatorcomment>
        <translation type="obsolete">С: %1 B/s - T: %2</translation>
    </message>
    <message>
        <source>DHT: %1 nodes</source>
        <translation>DHT: %1 чворова</translation>
    </message>
    <message>
        <source>Connection Status:</source>
        <translation>Статус конекције:</translation>
    </message>
    <message>
        <source>Offline. This usually means that qBittorrent failed to listen on the selected port for incoming connections.</source>
        <translation>Није на вези. То обично значи да qBittorrent не надгледа изабрани порт за долазне конекције.</translation>
    </message>
    <message>
        <source>Online</source>
        <translation>На вези</translation>
    </message>
    <message>
        <source>D: %1/s - T: %2</source>
        <comment>Download speed: x KiB/s - Transferred: x MiB</comment>
        <translation type="obsolete">П: %1/s - T: %2</translation>
    </message>
    <message>
        <source>U: %1/s - T: %2</source>
        <comment>Upload speed: x KiB/s - Transferred: x MiB</comment>
        <translation type="obsolete">С: %1/s - T: %2</translation>
    </message>
    <message>
        <source>Click to disable alternative speed limits</source>
        <translation type="obsolete">Кликните да онемогућите алтернативно ограничење брзине</translation>
    </message>
    <message>
        <source>Click to enable alternative speed limits</source>
        <translation type="obsolete">Кликните да омогућите алтернативно ограничење брзине</translation>
    </message>
    <message>
        <source>Global Download Speed Limit</source>
        <translation>Општи лимит брзине преузимања</translation>
    </message>
    <message>
        <source>Global Upload Speed Limit</source>
        <translation>Општи лимит брзине слања</translation>
    </message>
    <message>
        <source>qBittorrent needs to be restarted</source>
        <translation>qBittorrent треба бити рестартован</translation>
    </message>
    <message>
        <source>qBittorrent was just updated and needs to be restarted for the changes to be effective.</source>
        <translation>qBittorrent је управо ажуриран и треба бити рестартован, да би&apos; промене имале ефекта.</translation>
    </message>
    <message>
        <source>Click to switch to alternative speed limits</source>
        <translation>Кликните да укључите алтернативно ограничење брзине</translation>
    </message>
    <message>
        <source>Click to switch to regular speed limits</source>
        <translation>Кликните да укључите уобичајено ограничење брзине</translation>
    </message>
    <message>
        <source>%1/s</source>
        <comment>Per second</comment>
        <translation>%1/s</translation>
    </message>
</context>
<context>
    <name>TorrentCreatorDlg</name>
    <message>
        <source>Select a folder to add to the torrent</source>
        <translation>Селектујте фасциклу коју додајете у торент</translation>
    </message>
    <message>
        <source>Select a file to add to the torrent</source>
        <translation>Селектујте фајл који додајете у торент</translation>
    </message>
    <message>
        <source>Please type an announce URL</source>
        <translation type="obsolete">Молим упишите URL оглашавача</translation>
    </message>
    <message>
        <source>Announce URL:</source>
        <comment>Tracker URL</comment>
        <translation type="obsolete">Објављени URL:</translation>
    </message>
    <message>
        <source>Please type a web seed url</source>
        <translation type="obsolete">Молим упишите url веб донора</translation>
    </message>
    <message>
        <source>Web seed URL:</source>
        <translation type="obsolete">URL Веб донора:</translation>
    </message>
    <message>
        <source>No input path set</source>
        <translation>Није унета путања</translation>
    </message>
    <message>
        <source>Please type an input path first</source>
        <translation>Молим прво упишите улазну путању</translation>
    </message>
    <message>
        <source>Select destination torrent file</source>
        <translation>Изаберите дестинацију торент фајла</translation>
    </message>
    <message>
        <source>Torrent Files</source>
        <translation>Торент Фајлови</translation>
    </message>
    <message>
        <source>Torrent creation</source>
        <translation>Креирање Торента</translation>
    </message>
    <message>
        <source>Torrent creation was unsuccessful, reason: %1</source>
        <translation>Креирање Торента је неуспешно, разлог: %1</translation>
    </message>
    <message>
        <source>Created torrent file is invalid. It won&apos;t be added to download list.</source>
        <translation>Креирана Торент датотека је неважећа. Неће бити додата у листу за преузимање.</translation>
    </message>
    <message>
        <source>Torrent was created successfully:</source>
        <translation>Торент је креиран успешно:</translation>
    </message>
</context>
<context>
    <name>TorrentFilesModel</name>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Величина</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation>Напредак</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Приоритет</translation>
    </message>
</context>
<context>
    <name>TorrentImportDlg</name>
    <message>
        <source>Torrent Import</source>
        <translation>Увоз торента</translation>
    </message>
    <message>
        <source>This assistant will help you share with qBittorrent a torrent that you have already downloaded.</source>
        <translation>Овај асистен ће вам помоћи да делите са qBittorrent-ом торенте које сте већ преузели.</translation>
    </message>
    <message>
        <source>Torrent file to import:</source>
        <translation>Торент фајл за увоз:</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Content location:</source>
        <translation>Садржај локације:</translation>
    </message>
    <message>
        <source>Skip the data checking stage and start seeding immediately</source>
        <translation>Прескочи проверу података и одмах стартуј донирање</translation>
    </message>
    <message>
        <source>Import</source>
        <translation>Увоз</translation>
    </message>
    <message>
        <source>Torrent file to import</source>
        <translation>Торент фајл за увоз</translation>
    </message>
    <message>
        <source>Torrent files (*.torrent)</source>
        <translation>Торент фајлови (*.torrent)</translation>
    </message>
    <message>
        <source>%1 Files</source>
        <comment>%1 is a file extension (e.g. PDF)</comment>
        <translation>%1 Фајлови</translation>
    </message>
    <message>
        <source>Please provide the location of %1</source>
        <comment>%1 is a file name</comment>
        <translation>Наведите локацију %1</translation>
    </message>
    <message>
        <source>Please point to the location of the torrent: %1</source>
        <translation>Молим Вас укажите на локацију торента: %1</translation>
    </message>
    <message>
        <source>Invalid torrent file</source>
        <translation>Неисправна торент датотека</translation>
    </message>
    <message>
        <source>This is not a valid torrent file.</source>
        <translation>Ово није валидан торент фајл.</translation>
    </message>
</context>
<context>
    <name>TorrentModel</name>
    <message>
        <source>Name</source>
        <comment>i.e: torrent name</comment>
        <translation>Име</translation>
    </message>
    <message>
        <source>Size</source>
        <comment>i.e: torrent size</comment>
        <translation>Величина</translation>
    </message>
    <message>
        <source>Done</source>
        <comment>% Done</comment>
        <translation>Урађено</translation>
    </message>
    <message>
        <source>Status</source>
        <comment>Torrent status (e.g. downloading, seeding, paused)</comment>
        <translation>Статус</translation>
    </message>
    <message>
        <source>Seeds</source>
        <comment>i.e. full sources (often untranslated)</comment>
        <translation>Донори</translation>
    </message>
    <message>
        <source>Peers</source>
        <comment>i.e. partial sources (often untranslated)</comment>
        <translation>Peers (учесници)</translation>
    </message>
    <message>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Брзина Преуз</translation>
    </message>
    <message>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Брзина Слања</translation>
    </message>
    <message>
        <source>Ratio</source>
        <comment>Share ratio</comment>
        <translation>Однос</translation>
    </message>
    <message>
        <source>ETA</source>
        <comment>i.e: Estimated Time of Arrival / Time left</comment>
        <translatorcomment>очекивано време за преузимање</translatorcomment>
        <translation>ETA</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Ознака</translation>
    </message>
    <message>
        <source>Added On</source>
        <comment>Torrent was added to transfer list on 01/01/2010 08:00</comment>
        <translation>Додато на</translation>
    </message>
    <message>
        <source>Completed On</source>
        <comment>Torrent was completed on 01/01/2010 08:00</comment>
        <translation>Завршено дана</translation>
    </message>
    <message>
        <source>Tracker</source>
        <translation>Пратилац</translation>
    </message>
    <message>
        <source>Down Limit</source>
        <comment>i.e: Download limit</comment>
        <translation>Преуз. Лимит</translation>
    </message>
    <message>
        <source>Up Limit</source>
        <comment>i.e: Upload limit</comment>
        <translation>Слањ. Лимит</translation>
    </message>
    <message>
        <source>Amount downloaded</source>
        <comment>Amount of data downloaded (e.g. in MB)</comment>
        <translation>Износ преузетог</translation>
    </message>
    <message>
        <source>Amount left</source>
        <comment>Amount of data left to download (e.g. in MB)</comment>
        <translation>Преостали износ</translation>
    </message>
    <message>
        <source>Time Active</source>
        <comment>Time (duration) the torrent is active (not paused)</comment>
        <translation>Протекло време</translation>
    </message>
</context>
<context>
    <name>TrackerList</name>
    <message>
        <source>URL</source>
        <translatorcomment>Url (адреса)</translatorcomment>
        <translation>URL</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Статус</translation>
    </message>
    <message>
        <source>Peers</source>
        <translation>Peers (учесници)</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Порука</translation>
    </message>
    <message>
        <source>[DHT]</source>
        <translation>[DHT]</translation>
    </message>
    <message>
        <source>[PeX]</source>
        <translation>[PeX]</translation>
    </message>
    <message>
        <source>[LSD]</source>
        <translation>[LSD]</translation>
    </message>
    <message>
        <source>Working</source>
        <translation>Ради</translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Онемогућен</translation>
    </message>
    <message>
        <source>This torrent is private</source>
        <translation>Овај торент је приватан</translation>
    </message>
    <message>
        <source>Updating...</source>
        <translation>Ажурирање...</translation>
    </message>
    <message>
        <source>Not working</source>
        <translation>Не ради</translation>
    </message>
    <message>
        <source>Not contacted yet</source>
        <translation>Није још контактиран</translation>
    </message>
    <message>
        <source>Add a new tracker...</source>
        <translation>Додај нови пратилац...</translation>
    </message>
    <message>
        <source>Remove tracker</source>
        <translation>Уклони пратилац</translation>
    </message>
    <message>
        <source>Force reannounce</source>
        <translation>Форсирано реобјављивање</translation>
    </message>
</context>
<context>
    <name>TrackersAdditionDlg</name>
    <message>
        <source>Trackers addition dialog</source>
        <translation>Пратиоци, дијалог додавања</translation>
    </message>
    <message>
        <source>List of trackers to add (one per line):</source>
        <translation>Листа за додавање пратилаца (један по линији):</translation>
    </message>
    <message utf8="true">
        <source>µTorrent compatible list URL:</source>
        <translation>µTorrent компатибилна листа URL адреса:</translation>
    </message>
    <message>
        <source>I/O Error</source>
        <translation>И/О Грешка</translation>
    </message>
    <message>
        <source>Error while trying to open the downloaded file.</source>
        <translation>Грешка при покушају да се отвори преузета датотека.</translation>
    </message>
    <message>
        <source>No change</source>
        <translation>Без измена</translation>
    </message>
    <message>
        <source>No additional trackers were found.</source>
        <translation>Нису пронађени додатни пратиоци.</translation>
    </message>
    <message>
        <source>Download error</source>
        <translation>Грешка преузимања</translation>
    </message>
    <message>
        <source>The trackers list could not be downloaded, reason: %1</source>
        <translation>Листа пратилаца не може бити преузета, разлог: %1</translation>
    </message>
</context>
<context>
    <name>TransferListDelegate</name>
    <message>
        <source>Downloading</source>
        <translation>Преузимање</translation>
    </message>
    <message>
        <source>Paused</source>
        <translation>Паузиран</translation>
    </message>
    <message>
        <source>Queued</source>
        <comment>i.e. torrent is queued</comment>
        <translation>Редослед</translation>
    </message>
    <message>
        <source>Seeding</source>
        <comment>Torrent is complete and in upload-only mode</comment>
        <translation>Донирање</translation>
    </message>
    <message>
        <source>Stalled</source>
        <comment>Torrent is waiting for download to begin</comment>
        <translation>Застој</translation>
    </message>
    <message>
        <source>Checking</source>
        <comment>Torrent local data is being checked</comment>
        <translation>Провера</translation>
    </message>
    <message>
        <source>/s</source>
        <comment>/second (.i.e per second)</comment>
        <translation>/s</translation>
    </message>
    <message>
        <source>KiB/s</source>
        <comment>KiB/second (.i.e per second)</comment>
        <translation>KiB/s</translation>
    </message>
    <message>
        <source>Seeded for %1</source>
        <comment>e.g. Seeded for 3m10s</comment>
        <translation>Донирано за %1</translation>
    </message>
</context>
<context>
    <name>TransferListFiltersWidget</name>
    <message>
        <source>All</source>
        <translation>Сви</translation>
    </message>
    <message>
        <source>Downloading</source>
        <translation>Преузимање</translation>
    </message>
    <message>
        <source>Completed</source>
        <translation>Комплетирани</translation>
    </message>
    <message>
        <source>Active</source>
        <translation>Активни</translation>
    </message>
    <message>
        <source>Inactive</source>
        <translation>Неактивни</translation>
    </message>
    <message>
        <source>All labels</source>
        <translation>Све ознаке</translation>
    </message>
    <message>
        <source>Unlabeled</source>
        <translation>Неозначено</translation>
    </message>
    <message>
        <source>Remove label</source>
        <translation>Уклони ознаку</translation>
    </message>
    <message>
        <source>New Label</source>
        <translation>Нова ознака</translation>
    </message>
    <message>
        <source>Label:</source>
        <translatorcomment>Label-Ознака,Маркер</translatorcomment>
        <translation>Ознака:</translation>
    </message>
    <message>
        <source>Invalid label name</source>
        <translation>Погрешно име ознаке</translation>
    </message>
    <message>
        <source>Please don&apos;t use any special characters in the label name.</source>
        <translation>Молимо Вас да не користите специјалне карактере у имену ознаке.</translation>
    </message>
    <message>
        <source>Paused</source>
        <translation>Паузирани</translation>
    </message>
    <message>
        <source>Add label...</source>
        <translation>Додај ознаку...</translation>
    </message>
    <message>
        <source>Resume torrents</source>
        <translation>Настави торенте</translation>
    </message>
    <message>
        <source>Pause torrents</source>
        <translation>Паузирај торенте</translation>
    </message>
    <message>
        <source>Delete torrents</source>
        <translation>Обриши торенте</translation>
    </message>
</context>
<context>
    <name>TransferListWidget</name>
    <message>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation type="obsolete">Брзина Преуз</translation>
    </message>
    <message>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation type="obsolete">Брзина Слања</translation>
    </message>
    <message>
        <source>ETA</source>
        <comment>i.e: Estimated Time of Arrival / Time left</comment>
        <translatorcomment>н.пр.: Приближно време завршетка</translatorcomment>
        <translation type="obsolete">ETA</translation>
    </message>
    <message>
        <source>Column visibility</source>
        <translation>Прегледност колона</translation>
    </message>
    <message>
        <source>Name</source>
        <comment>i.e: torrent name</comment>
        <translation type="obsolete">Име</translation>
    </message>
    <message>
        <source>Size</source>
        <comment>i.e: torrent size</comment>
        <translation type="obsolete">Величина</translation>
    </message>
    <message>
        <source>Done</source>
        <comment>% Done</comment>
        <translation type="obsolete">Урађено</translation>
    </message>
    <message>
        <source>Status</source>
        <comment>Torrent status (e.g. downloading, seeding, paused)</comment>
        <translation type="obsolete">Статус</translation>
    </message>
    <message>
        <source>Seeds</source>
        <comment>i.e. full sources (often untranslated)</comment>
        <translation type="obsolete">Донори</translation>
    </message>
    <message>
        <source>Peers</source>
        <comment>i.e. partial sources (often untranslated)</comment>
        <translation type="obsolete">Peers (учесници)</translation>
    </message>
    <message>
        <source>Ratio</source>
        <comment>Share ratio</comment>
        <translation type="obsolete">Однос</translation>
    </message>
    <message>
        <source>Label</source>
        <translatorcomment>Label-Ознака,Маркер</translatorcomment>
        <translation>Ознака</translation>
    </message>
    <message>
        <source>Added On</source>
        <comment>Torrent was added to transfer list on 01/01/2010 08:00</comment>
        <translation type="obsolete">Додато на</translation>
    </message>
    <message>
        <source>Completed On</source>
        <comment>Torrent was completed on 01/01/2010 08:00</comment>
        <translation type="obsolete">Завршено дана</translation>
    </message>
    <message>
        <source>Down Limit</source>
        <comment>i.e: Download limit</comment>
        <translatorcomment>н.пр.: Ограничење преузимања</translatorcomment>
        <translation type="obsolete">Преуз. Лимит</translation>
    </message>
    <message>
        <source>Up Limit</source>
        <comment>i.e: Upload limit</comment>
        <translatorcomment>н.пр.: Ограничење слања</translatorcomment>
        <translation type="obsolete">Слањ. Лимит</translation>
    </message>
    <message>
        <source>Torrent Download Speed Limiting</source>
        <translation>Ограничење брзине преузимања Торента</translation>
    </message>
    <message>
        <source>Torrent Upload Speed Limiting</source>
        <translation>Ограничење брзине слања Торента</translation>
    </message>
    <message>
        <source>New Label</source>
        <translation>Нова ознака</translation>
    </message>
    <message>
        <source>Label:</source>
        <translation>Ознака:</translation>
    </message>
    <message>
        <source>Invalid label name</source>
        <translation>Погрешно име ознаке</translation>
    </message>
    <message>
        <source>Please don&apos;t use any special characters in the label name.</source>
        <translation>Молимо Вас да не користите специјалне карактере у имену ознаке.</translation>
    </message>
    <message>
        <source>Rename</source>
        <translation>Преименуј</translation>
    </message>
    <message>
        <source>New name:</source>
        <translation>Ново име:</translation>
    </message>
    <message>
        <source>Open destination folder</source>
        <translatorcomment>фасцикла-фолдер</translatorcomment>
        <translation>Отвори одредишну фасциклу</translation>
    </message>
    <message>
        <source>Force recheck</source>
        <translation>Форсирано провери</translation>
    </message>
    <message>
        <source>Copy magnet link</source>
        <translation>Копирај магнет линк</translation>
    </message>
    <message>
        <source>Super seeding mode</source>
        <translation>Супер seeding (донирајући) мод</translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation>Преименуј...</translation>
    </message>
    <message>
        <source>Download in sequential order</source>
        <translation>Преузимање у сријском редоследу</translation>
    </message>
    <message>
        <source>Download first and last piece first</source>
        <translation>Преузимање почетних и крајњих делова</translation>
    </message>
    <message>
        <source>New...</source>
        <comment>New label...</comment>
        <translation>Нова...</translation>
    </message>
    <message>
        <source>Reset</source>
        <comment>Reset label</comment>
        <translatorcomment>Поништи ознаке</translatorcomment>
        <translation>Поништи</translation>
    </message>
    <message>
        <source>Choose save path</source>
        <translation>Изаберите путању чувања</translation>
    </message>
    <message>
        <source>Save path creation error</source>
        <translation type="obsolete">Грешка при креирању путање чувања</translation>
    </message>
    <message>
        <source>Could not create the save path</source>
        <translation type="obsolete">Не могу да креирам путању за чување фајла</translation>
    </message>
    <message>
        <source>Set location...</source>
        <translation>Подесите локацију...</translation>
    </message>
    <message>
        <source>Preview file...</source>
        <translation>Приказ датотеке...</translation>
    </message>
    <message>
        <source>Limit upload rate...</source>
        <translation>Ограничење брзине слања...</translation>
    </message>
    <message>
        <source>Limit download rate...</source>
        <translation>Ограничење брзине преузимања...</translation>
    </message>
    <message>
        <source>Move up</source>
        <comment>i.e. move up in the queue</comment>
        <translation>Премести навише</translation>
    </message>
    <message>
        <source>Move down</source>
        <comment>i.e. Move down in the queue</comment>
        <translation>Премести надоле</translation>
    </message>
    <message>
        <source>Move to top</source>
        <comment>i.e. Move to top of the queue</comment>
        <translation>Премести на врх</translation>
    </message>
    <message>
        <source>Move to bottom</source>
        <comment>i.e. Move to bottom of the queue</comment>
        <translation>Премести на дно</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Приоритет</translation>
    </message>
    <message>
        <source>Resume</source>
        <comment>Resume/start the torrent</comment>
        <translation>Настави</translation>
    </message>
    <message>
        <source>Pause</source>
        <comment>Pause the torrent</comment>
        <translation>Пауза</translation>
    </message>
    <message>
        <source>Delete</source>
        <comment>Delete the torrent</comment>
        <translation>Обриши</translation>
    </message>
    <message>
        <source>Limit share ratio...</source>
        <translation>Ограничење односа дељења...</translation>
    </message>
</context>
<context>
    <name>UpDownRatioDlg</name>
    <message>
        <source>Torrent Upload/Download Ratio Limiting</source>
        <translation>Однос ограничења слања/преузимања торента</translation>
    </message>
    <message>
        <source>Use global ratio limit</source>
        <translation>Користи општи однос ограничења</translation>
    </message>
    <message>
        <source>buttonGroup</source>
        <translation>дугмад Група</translation>
    </message>
    <message>
        <source>Set no ratio limit</source>
        <translation>Постави без односа ограничења</translation>
    </message>
    <message>
        <source>Set ratio limit to</source>
        <translation>Постави односа ограничења на</translation>
    </message>
</context>
<context>
    <name>UsageDisplay</name>
    <message>
        <source>Usage:</source>
        <translation>Начин употребе:</translation>
    </message>
    <message>
        <source>displays program version</source>
        <translation>прикажи верзију програма</translation>
    </message>
    <message>
        <source>disable splash screen</source>
        <translation>онемогући уводни екран</translation>
    </message>
    <message>
        <source>displays this help message</source>
        <translation>прикажи ову поруку о помоћи</translation>
    </message>
    <message>
        <source>changes the webui port (current: %1)</source>
        <translation>промени Веб КИ порт (тренутно: %1)</translation>
    </message>
    <message>
        <source>[files or urls]: downloads the torrents passed by the user (optional)</source>
        <translation>[фајлови или urls]:преузимање торента које чини корисник (опционо)</translation>
    </message>
</context>
<context>
    <name>about</name>
    <message>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <source>I would like to thank the following people who volunteered to translate qBittorrent:</source>
        <translation>Желео бих да се захвалим следећим људима који су добровољно превели qBittorrent:</translation>
    </message>
    <message>
        <source>Please contact me if you would like to translate qBittorrent into your own language.</source>
        <translation>Контактирајте ме ако желите да преведете qBittorrent на свој језик.</translation>
    </message>
</context>
<context>
    <name>addPeerDialog</name>
    <message>
        <source>Peer addition</source>
        <translation>Додавање (peer)учесника</translation>
    </message>
    <message>
        <source>IP</source>
        <translation>IP</translation>
    </message>
    <message>
        <source>Port</source>
        <translation>Порт</translation>
    </message>
</context>
<context>
    <name>addTorrentDialog</name>
    <message>
        <source>Torrent addition dialog</source>
        <translation>Торент дијалог додавања</translation>
    </message>
    <message>
        <source>Save path:</source>
        <translation>Сачувај у:</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Torrent size:</source>
        <translation>Величина Торента:</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Непознат-а</translation>
    </message>
    <message>
        <source>Free disk space:</source>
        <translation>Слободан простор на диску:</translation>
    </message>
    <message>
        <source>Label:</source>
        <translatorcomment>Label-Ознака,Маркер</translatorcomment>
        <translation>Ознака:</translation>
    </message>
    <message>
        <source>Torrent content:</source>
        <translation>Садржај Торента:</translation>
    </message>
    <message>
        <source>Download in sequential order (slower but good for previewing)</source>
        <translation>Пренеси секвенционално (споро, али боље за преглед)</translation>
    </message>
    <message>
        <source>Skip file checking and start seeding immediately</source>
        <translation>Прескочи проверу фајла и одмах стартуј донирање</translation>
    </message>
    <message>
        <source>Add to download list in paused state</source>
        <translation>Додај на листу преузимања у стању паузе</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>Додај</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Откажи</translation>
    </message>
    <message>
        <source>Normal</source>
        <translation>Нормалан</translation>
    </message>
    <message>
        <source>High</source>
        <translation>Висок</translation>
    </message>
    <message>
        <source>Maximum</source>
        <translation>Максималан</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Селектуј све</translation>
    </message>
    <message>
        <source>Select None</source>
        <translation>Деселектуј</translation>
    </message>
    <message>
        <source>Do not download</source>
        <translation>Не преузимај</translation>
    </message>
</context>
<context>
    <name>authentication</name>
    <message>
        <source>Tracker authentication</source>
        <translation>Аутентификација пратилаца</translation>
    </message>
    <message>
        <source>Tracker:</source>
        <translation>Пратилац:</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Логовање</translation>
    </message>
    <message>
        <source>Username:</source>
        <translation>Корисничко име:</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation>Лозинка:</translation>
    </message>
    <message>
        <source>Log in</source>
        <translation>Логуј се</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Откажи</translation>
    </message>
</context>
<context>
    <name>confirmDeletionDlg</name>
    <message>
        <source>Deletion confirmation - qBittorrent</source>
        <translation>Потврда брисања - qBittorrent</translation>
    </message>
    <message>
        <source>Are you sure you want to delete the selected torrents from the transfer list?</source>
        <translation>Да ли сте сигурни да желите да обришете селектоване Торенте са трансфер листе?</translation>
    </message>
    <message>
        <source>Remember choice</source>
        <translation>Запамти избор</translation>
    </message>
    <message>
        <source>Also delete the files on the hard disk</source>
        <translation>Такође избриши датотеке на чврстом диску</translation>
    </message>
</context>
<context>
    <name>createTorrentDialog</name>
    <message>
        <source>Cancel</source>
        <translation>Откажи</translation>
    </message>
    <message>
        <source>Torrent Creation Tool</source>
        <translation>Алат креирања Торента</translation>
    </message>
    <message>
        <source>Torrent file creation</source>
        <translation>Креирање Торент фајла</translation>
    </message>
    <message>
        <source>Add file</source>
        <translation>Додај фајл</translation>
    </message>
    <message>
        <source>Add folder</source>
        <translatorcomment>фасцикла-фолдер</translatorcomment>
        <translation>Додај фасциклу</translation>
    </message>
    <message>
        <source>Announce urls (trackers):</source>
        <translatorcomment>trackers-пратиоци</translatorcomment>
        <translation type="obsolete">Објави urls (пратиоци):</translation>
    </message>
    <message>
        <source>Comment (optional):</source>
        <translation type="obsolete">Коментар (опционо):</translation>
    </message>
    <message>
        <source>Web seeds urls (optional):</source>
        <translation type="obsolete">Веб донори urls (опционо):</translation>
    </message>
    <message>
        <source>File or folder to add to the torrent:</source>
        <translatorcomment>фасцикла-фолдер</translatorcomment>
        <translation>Фајл или фасцикла за додавање у Торент:</translation>
    </message>
    <message>
        <source>Piece size:</source>
        <translation>Делови величине:</translation>
    </message>
    <message>
        <source>32 KiB</source>
        <translation>32 KiB</translation>
    </message>
    <message>
        <source>64 KiB</source>
        <translation>64 KiB</translation>
    </message>
    <message>
        <source>128 KiB</source>
        <translation>128 KiB</translation>
    </message>
    <message>
        <source>256 KiB</source>
        <translation>256 KiB</translation>
    </message>
    <message>
        <source>512 KiB</source>
        <translation>512 KiB</translation>
    </message>
    <message>
        <source>1 MiB</source>
        <translation>1 MiB</translation>
    </message>
    <message>
        <source>2 MiB</source>
        <translation>2 MiB</translation>
    </message>
    <message>
        <source>4 MiB</source>
        <translation>4 MiB</translation>
    </message>
    <message>
        <source>Private (won&apos;t be distributed on DHT network if enabled)</source>
        <translation>Приватност (неће бити дистрибуиран на DHT мрежу ако је омогућена)</translation>
    </message>
    <message>
        <source>Start seeding after creation</source>
        <translation>Стартуј донирање после креирања</translation>
    </message>
    <message>
        <source>Create and save...</source>
        <translation>Креирај и сачувај...</translation>
    </message>
    <message>
        <source>Progress:</source>
        <translation>Напредак:</translation>
    </message>
    <message>
        <source>Tracker URLs:</source>
        <translatorcomment>URLs-Веб адресе</translatorcomment>
        <translation>Пратилац URLs:</translation>
    </message>
    <message>
        <source>Web seeds urls:</source>
        <translatorcomment>URL-Веб адреса</translatorcomment>
        <translation>Веб донори URLs:</translation>
    </message>
    <message>
        <source>Comment:</source>
        <translation>Коментар:</translation>
    </message>
    <message>
        <source>Auto</source>
        <translation>Аутоматски</translation>
    </message>
</context>
<context>
    <name>createtorrent</name>
    <message>
        <source>Select destination torrent file</source>
        <translation type="obsolete">Изаберите дестинацију торент фајла</translation>
    </message>
    <message>
        <source>Torrent Files</source>
        <translation type="obsolete">Торент Фајлови</translation>
    </message>
    <message>
        <source>No input path set</source>
        <translation type="obsolete">Није унета путања</translation>
    </message>
    <message>
        <source>Please type an input path first</source>
        <translation type="obsolete">Молим прво упишите улазну путању</translation>
    </message>
    <message>
        <source>Torrent creation</source>
        <translation type="obsolete">Креирање Торента</translation>
    </message>
    <message>
        <source>Torrent was created successfully:</source>
        <translation type="obsolete">Торент је креиран успешно:</translation>
    </message>
    <message>
        <source>Select a folder to add to the torrent</source>
        <translation type="obsolete">Селектујте фасциклу коју додајете у торент</translation>
    </message>
    <message>
        <source>Please type an announce URL</source>
        <translation type="obsolete">Молим упишите URL оглашавача</translation>
    </message>
    <message>
        <source>Torrent creation was unsuccessful, reason: %1</source>
        <translation type="obsolete">Креирање Торента је неуспешно, разлог: %1</translation>
    </message>
    <message>
        <source>Announce URL:</source>
        <comment>Tracker URL</comment>
        <translation type="obsolete">Објављени URL:</translation>
    </message>
    <message>
        <source>Please type a web seed url</source>
        <translatorcomment>url-интернет адреса</translatorcomment>
        <translation type="obsolete">Молим упишите url веб донора</translation>
    </message>
    <message>
        <source>Web seed URL:</source>
        <translatorcomment>URL-интернет адреса</translatorcomment>
        <translation type="obsolete">URL Веб донора:</translation>
    </message>
    <message>
        <source>Select a file to add to the torrent</source>
        <translation type="obsolete">Селектујте фајл који додајете у торент</translation>
    </message>
    <message>
        <source>Created torrent file is invalid. It won&apos;t be added to download list.</source>
        <translation type="obsolete">Креирана Торент датотека је неважећа. Неће бити додата у листу за преузимање.</translation>
    </message>
</context>
<context>
    <name>downloadFromURL</name>
    <message>
        <source>Download Torrents from URLs</source>
        <translatorcomment>URL-интенет адреса</translatorcomment>
        <translation type="obsolete">Преузимање Торента са URL-а</translation>
    </message>
    <message>
        <source>Only one URL per line</source>
        <translatorcomment>URL-интенет адреса</translatorcomment>
        <translation type="obsolete">Само један URL по линији</translation>
    </message>
    <message>
        <source>Download</source>
        <translation>Преузми</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Откажи</translation>
    </message>
    <message>
        <source>Download from urls</source>
        <translatorcomment>URL-интенет адреса</translatorcomment>
        <translation>Преузимање са urls</translation>
    </message>
    <message>
        <source>No URL entered</source>
        <translatorcomment>URL-интенет адреса</translatorcomment>
        <translation>URL није унет</translation>
    </message>
    <message>
        <source>Please type at least one URL.</source>
        <translatorcomment>URL-интенет адреса</translatorcomment>
        <translation>Молим упишите најмање један URL.</translation>
    </message>
    <message>
        <source>Add torrent links</source>
        <translation>Додај торент линкове</translation>
    </message>
    <message>
        <source>Both HTTP and Magnet links are supported</source>
        <translation>Оба, HTTP и Magnet линкови су подржани</translation>
    </message>
</context>
<context>
    <name>downloadThread</name>
    <message>
        <source>I/O Error</source>
        <translation type="obsolete">И/О Грешка</translation>
    </message>
    <message>
        <source>The remote host name was not found (invalid hostname)</source>
        <translation type="obsolete">Име удаљеног домаћина није пронађено (неважеће hostname)</translation>
    </message>
    <message>
        <source>The operation was canceled</source>
        <translation type="obsolete">Операција је отказана</translation>
    </message>
    <message>
        <source>The remote server closed the connection prematurely, before the entire reply was received and processed</source>
        <translation type="obsolete">Удаљени сервер је прерано затворио конекцију, пре него што је цео одговор примљен и обрађен</translation>
    </message>
    <message>
        <source>The connection to the remote server timed out</source>
        <translation type="obsolete">Конекција на удаљени сервер је временски истекла (покушајте поново)</translation>
    </message>
    <message>
        <source>SSL/TLS handshake failed</source>
        <translation type="obsolete">SSL/TLS управљање неуспешно</translation>
    </message>
    <message>
        <source>The remote server refused the connection</source>
        <translation type="obsolete">Удаљени сервер не прихвата конекцију</translation>
    </message>
    <message>
        <source>The connection to the proxy server was refused</source>
        <translation type="obsolete">Конекција на прокси сервер је одбијена</translation>
    </message>
    <message>
        <source>The proxy server closed the connection prematurely</source>
        <translation type="obsolete">Прокси сервер је превремено затворио конекцију</translation>
    </message>
    <message>
        <source>The proxy host name was not found</source>
        <translation type="obsolete">Назив прокси сервера није пронађен</translation>
    </message>
    <message>
        <source>The connection to the proxy timed out or the proxy did not reply in time to the request sent</source>
        <translation type="obsolete">Време повезивања са прокси-јем је истекло, или прокси није одговорио када је захтев послат</translation>
    </message>
    <message>
        <source>The proxy requires authentication in order to honour the request but did not accept any credentials offered</source>
        <translation type="obsolete">Прокси захтева проверу идентитета да би испунио захтев али не прихвата понуђене акредитиве</translation>
    </message>
    <message>
        <source>The access to the remote content was denied (401)</source>
        <translation type="obsolete">Приступ удаљеном садржају је одбијен (401)</translation>
    </message>
    <message>
        <source>The operation requested on the remote content is not permitted</source>
        <translation type="obsolete">Захтевана операција за удаљеним садржајем се не одобрава</translation>
    </message>
    <message>
        <source>The remote content was not found at the server (404)</source>
        <translation type="obsolete">Захтевани садржај, није пронађен на серверу (404)</translation>
    </message>
    <message>
        <source>The remote server requires authentication to serve the content but the credentials provided were not accepted</source>
        <translation type="obsolete">Удаљени сервер захтева ауторизацију за слање садржаја, али дати акредитиви нису прихваћени</translation>
    </message>
    <message>
        <source>The Network Access API cannot honor the request because the protocol is not known</source>
        <translation type="obsolete">Мрежни приступ API-ја не може да се прихвати јер протокол није познат</translation>
    </message>
    <message>
        <source>The requested operation is invalid for this protocol</source>
        <translation type="obsolete">Захтевана операција је погрешна за овај протокол</translation>
    </message>
    <message>
        <source>An unknown network-related error was detected</source>
        <translation type="obsolete">Непозната грешка у вези са мрежом је откривена</translation>
    </message>
    <message>
        <source>An unknown proxy-related error was detected</source>
        <translation type="obsolete">Непозната грешка у вези са прокси-јем је откривена</translation>
    </message>
    <message>
        <source>An unknown error related to the remote content was detected</source>
        <translation type="obsolete">Непозната грешка у вези са удаљеним садржајем је откривена</translation>
    </message>
    <message>
        <source>A breakdown in protocol was detected</source>
        <translation type="obsolete">Детектован је проблем са протоколом</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation type="obsolete">Непозната грешка</translation>
    </message>
</context>
<context>
    <name>engineSelect</name>
    <message>
        <source>Search plugins</source>
        <translatorcomment>plugins-додаци</translatorcomment>
        <translation>Претраживачки додаци</translation>
    </message>
    <message>
        <source>Installed search engines:</source>
        <translation>Инсталирани претраживачки модули:</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Url</source>
        <translation>Url (адреса)</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Доступан</translation>
    </message>
    <message>
        <source>You can get new search engine plugins here: &lt;a href=&quot;http://plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</source>
        <translation>Преузмите нови додатак за претраживање овде: &lt;a href=&quot;http:plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</translation>
    </message>
    <message>
        <source>Install a new one</source>
        <translation>Инсталирајте нови</translation>
    </message>
    <message>
        <source>Check for updates</source>
        <translation>Проверите за надоградњу</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Затвори</translation>
    </message>
    <message>
        <source>Enable</source>
        <translation type="obsolete">Омогући</translation>
    </message>
    <message>
        <source>Disable</source>
        <translation type="obsolete">Онемогући</translation>
    </message>
    <message>
        <source>Uninstall</source>
        <translation>Деинсталирај</translation>
    </message>
</context>
<context>
    <name>engineSelectDlg</name>
    <message>
        <source>Uninstall warning</source>
        <translation>Деинсталационо упозорење</translation>
    </message>
    <message>
        <source>Some plugins could not be uninstalled because they are included in qBittorrent.
 Only the ones you added yourself can be uninstalled.
However, those plugins were disabled.</source>
        <translatorcomment>додатак-plugins</translatorcomment>
        <translation>Неки додаци нису могли бити деинсталирани јер су укључени у qBittorrent.
 Само оне које сте додали можете деинсталирати.
Међутим, ови додаци су онемогућени.</translation>
    </message>
    <message>
        <source>Uninstall success</source>
        <translation>Деинсталација успешна</translation>
    </message>
    <message>
        <source>Select search plugins</source>
        <translatorcomment>додатак-plugins</translatorcomment>
        <translation>Изаберите додатак за претраживач</translation>
    </message>
    <message>
        <source>qBittorrent search plugins</source>
        <translatorcomment>додатак-plugins</translatorcomment>
        <translation>qBittorrent претраживачки додатак</translation>
    </message>
    <message>
        <source>Search plugin install</source>
        <translatorcomment>додатак-plugin</translatorcomment>
        <translation>Претраживачки додатак инсталација</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Да</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Не</translation>
    </message>
    <message>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <source>A more recent version of %1 search engine plugin is already installed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>Новија верзија %1 претраживачких додатака је већ инсталирана.</translation>
    </message>
    <message>
        <source>Search plugin update</source>
        <translation>Претраживачки додаци ажурирање</translation>
    </message>
    <message>
        <source>Sorry, update server is temporarily unavailable.</source>
        <translation>Жао нам је, сервер за ажурирање је привремено недоступан.</translation>
    </message>
    <message>
        <source>All your plugins are already up to date.</source>
        <translation>Сви ваши додаци су већ ажурни.</translation>
    </message>
    <message>
        <source>%1 search engine plugin could not be updated, keeping old version.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>%1 претраживачки додаци нису могли бити ажурирани, задржите стару верзију.</translation>
    </message>
    <message>
        <source>%1 search engine plugin could not be installed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>%1 претраживачки додаци нису могли бити инсталирани.</translation>
    </message>
    <message>
        <source>All selected plugins were uninstalled successfully</source>
        <translation>Сви изабрани додаци су деинсталирани успешно</translation>
    </message>
    <message>
        <source>%1 search engine plugin was successfully updated.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>%1 претраживачки додаци су успешно ажурирани.</translation>
    </message>
    <message>
        <source>%1 search engine plugin was successfully installed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>%1 претраживачки додаци су успешно инсталирани.</translation>
    </message>
    <message>
        <source>Sorry, %1 search plugin install failed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>Жалим, %1 инсталирање претраживачких додатака није успело.</translation>
    </message>
    <message>
        <source>New search engine plugin URL</source>
        <translation>Нови додатак претраживачког модула URL</translation>
    </message>
    <message>
        <source>URL:</source>
        <translatorcomment>URL-интернет адреса</translatorcomment>
        <translation>URL:</translation>
    </message>
</context>
<context>
    <name>misc</name>
    <message>
        <source>B</source>
        <comment>bytes</comment>
        <translatorcomment>бајтова</translatorcomment>
        <translation>B</translation>
    </message>
    <message>
        <source>KiB</source>
        <comment>kibibytes (1024 bytes)</comment>
        <translation>KiB</translation>
    </message>
    <message>
        <source>MiB</source>
        <comment>mebibytes (1024 kibibytes)</comment>
        <translation>MiB</translation>
    </message>
    <message>
        <source>GiB</source>
        <comment>gibibytes (1024 mibibytes)</comment>
        <translation>GiB</translation>
    </message>
    <message>
        <source>TiB</source>
        <comment>tebibytes (1024 gibibytes)</comment>
        <translation>TiB</translation>
    </message>
    <message>
        <source>Unknown</source>
        <comment>Unknown (size)</comment>
        <translatorcomment>Непознат-a (величина)</translatorcomment>
        <translation>Непознат-а</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Непознат-а</translation>
    </message>
    <message>
        <source>&lt; 1m</source>
        <comment>&lt; 1 minute</comment>
        <translatorcomment>&lt; 1 минута</translatorcomment>
        <translation>&lt; 1m</translation>
    </message>
    <message>
        <source>%1m</source>
        <comment>e.g: 10minutes</comment>
        <translatorcomment>e.g: 10минута</translatorcomment>
        <translation>%1m</translation>
    </message>
    <message>
        <source>%1h %2m</source>
        <comment>e.g: 3hours 5minutes</comment>
        <translation>%1h%2m</translation>
    </message>
    <message>
        <source>%1d %2h</source>
        <comment>e.g: 2days 10hours</comment>
        <translation>%1d %2h</translation>
    </message>
    <message>
        <source>qBittorrent will shutdown the computer now because all downloads are complete.</source>
        <translation>qBittorrent ће искључити рачунар сада, јер су сва преузимања завршена.</translation>
    </message>
</context>
<context>
    <name>options_imp</name>
    <message>
        <source>Choose export directory</source>
        <translation>Изаберите директоријум за извоз</translation>
    </message>
    <message>
        <source>Choose a save directory</source>
        <translation>Изаберите директоријум за чување</translation>
    </message>
    <message>
        <source>Choose an ip filter file</source>
        <translation>Изаберите неки ip филтер фајл</translation>
    </message>
    <message>
        <source>Add directory to scan</source>
        <translation>Додај директоријум за скенирање</translation>
    </message>
    <message>
        <source>Folder is already being watched.</source>
        <translatorcomment>Фолдер-Фасцикла-Директоријум</translatorcomment>
        <translation>Фолдер је већ надгледан.</translation>
    </message>
    <message>
        <source>Folder does not exist.</source>
        <translatorcomment>Фолдер-Фасцикла-Директоријум</translatorcomment>
        <translation>Фолдер не постоји.</translation>
    </message>
    <message>
        <source>Folder is not readable.</source>
        <translatorcomment>Фолдер-Фасцикла-Директоријум</translatorcomment>
        <translation>Фолдер се не може прочитати.</translation>
    </message>
    <message>
        <source>Failure</source>
        <translation>Неуспешно</translation>
    </message>
    <message>
        <source>Failed to add Scan Folder &apos;%1&apos;: %2</source>
        <translation>Неуспешно додавање Фолдера Скенирања &apos;%1&apos;: %2</translation>
    </message>
    <message>
        <source>Filters</source>
        <translation>Филтери</translation>
    </message>
    <message>
        <source>Parsing error</source>
        <translation>Анализа грешака</translation>
    </message>
    <message>
        <source>Failed to parse the provided IP filter</source>
        <translation>Неспешна анализа датог IP филтера</translation>
    </message>
    <message>
        <source>Succesfully refreshed</source>
        <translation type="obsolete">Успешно обновљени</translation>
    </message>
    <message>
        <source>Successfuly parsed the provided IP filter: %1 rules were applied.</source>
        <comment>%1 is a number</comment>
        <translation>Успешна анализа датог IP филтера: %1 правила су примењена.</translation>
    </message>
    <message>
        <source>Successfully refreshed</source>
        <translation>Успешно обновљен</translation>
    </message>
    <message>
        <source>SSL Certificate (*.crt)</source>
        <translation type="obsolete">SSL Сертификат (*.crt)</translation>
    </message>
    <message>
        <source>SSL Key (*.key)</source>
        <translation type="obsolete">SSL Кључ (*.key)</translation>
    </message>
    <message>
        <source>Invalid key</source>
        <translation>Погрешан кључ</translation>
    </message>
    <message>
        <source>This is not a valid SSL key.</source>
        <translation>Ово није валидан SSL кључ.</translation>
    </message>
    <message>
        <source>Invalid certificate</source>
        <translation>Неважећи сертификат</translation>
    </message>
    <message>
        <source>This is not a valid SSL certificate.</source>
        <translation>Ово није валидан SSL сертификат.</translation>
    </message>
    <message>
        <source>SSL Certificate (*.crt *.pem)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SSL Key (*.key *.pem)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>pluginSourceDlg</name>
    <message>
        <source>Plugin source</source>
        <translatorcomment>додатак-plugin</translatorcomment>
        <translation>Додатак сорс</translation>
    </message>
    <message>
        <source>Search plugin source:</source>
        <translatorcomment>додатак-plugin</translatorcomment>
        <translation>Претраживачки додатак сорс:</translation>
    </message>
    <message>
        <source>Local file</source>
        <translation>Локални фајл</translation>
    </message>
    <message>
        <source>Web link</source>
        <translation>Веб линк</translation>
    </message>
</context>
<context>
    <name>preview</name>
    <message>
        <source>Preview selection</source>
        <translation>Избор приказа</translation>
    </message>
    <message>
        <source>File preview</source>
        <translation>Приказ датотеке</translation>
    </message>
    <message>
        <source>The following files support previewing, &lt;br&gt;please select one of them:</source>
        <translation>Следећи фајлови подржавају приказ, &lt;br&gt;молим изаберите један од њих:</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Прикажи</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Откажи</translation>
    </message>
</context>
<context>
    <name>previewSelect</name>
    <message>
        <source>Preview impossible</source>
        <translation type="obsolete">Приказ немогућ</translation>
    </message>
    <message>
        <source>Sorry, we can&apos;t preview this file</source>
        <translation type="obsolete">Жалим не могу да прикажем овај фајл</translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="obsolete">Име</translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="obsolete">Величина</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation type="obsolete">Напредак</translation>
    </message>
</context>
<context>
    <name>search_engine</name>
    <message>
        <source>Search</source>
        <translation>Претраживање</translation>
    </message>
    <message>
        <source>Status:</source>
        <translation>Статус:</translation>
    </message>
    <message>
        <source>Stopped</source>
        <translation>Стопиран</translation>
    </message>
    <message>
        <source>Download</source>
        <translation>Преузимање</translation>
    </message>
    <message>
        <source>Search engines...</source>
        <translation>Претраживачки модули...</translation>
    </message>
    <message>
        <source>Go to description page</source>
        <translation>Иди на веб страну са описом</translation>
    </message>
</context>
<context>
    <name>torrentAdditionDialog</name>
    <message>
        <source>Unable to decode magnet link:</source>
        <translation>Не могу да декодирам магнет линк:</translation>
    </message>
    <message>
        <source>Magnet Link</source>
        <translation>Магнет Линк</translation>
    </message>
    <message>
        <source>Unable to decode torrent file:</source>
        <translation>Не могу да декодирам Торент фајл:</translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation>Преименуј...</translation>
    </message>
    <message>
        <source>Rename the file</source>
        <translation>Преименуј фајл</translation>
    </message>
    <message>
        <source>New name:</source>
        <translation>Ново име:</translation>
    </message>
    <message>
        <source>The file could not be renamed</source>
        <translation>Фајл не може бити преименован</translation>
    </message>
    <message>
        <source>This file name contains forbidden characters, please choose a different one.</source>
        <translation>Ово име фајла садржи недозвољене карактере, молим изаберите неко друго.</translation>
    </message>
    <message>
        <source>This name is already in use in this folder. Please use a different name.</source>
        <translation>Ово име је већ у употреби у овом фолдеру. Молим изаберите неко друго.</translation>
    </message>
    <message>
        <source>The folder could not be renamed</source>
        <translation>Фолдер не може бити преименован</translation>
    </message>
    <message>
        <source>(%1 left after torrent download)</source>
        <comment>e.g. (100MiB left after torrent download)</comment>
        <translation>(%1 остаје након преузетог Торента)</translation>
    </message>
    <message>
        <source>(%1 more are required to download)</source>
        <comment>e.g. (100MiB more are required to download)</comment>
        <translation>(%1 више је потребно ради преузимања)</translation>
    </message>
    <message>
        <source>Choose save path</source>
        <translation>Изабери путању чувања</translation>
    </message>
    <message>
        <source>Empty save path</source>
        <translation>Празна путања чувања</translation>
    </message>
    <message>
        <source>Please enter a save path</source>
        <translation>Молим унесите путању за чување фајла</translation>
    </message>
    <message>
        <source>Save path creation error</source>
        <translation>Грешка креирања путање чувања</translation>
    </message>
    <message>
        <source>Could not create the save path</source>
        <translation>Не могу да креирам путању за чување фајла</translation>
    </message>
    <message>
        <source>Invalid label name</source>
        <translation>Погрешно име ознаке</translation>
    </message>
    <message>
        <source>Please don&apos;t use any special characters in the label name.</source>
        <translation>Молимо Вас да не користите специјалне карактере у имену ознаке.</translation>
    </message>
    <message>
        <source>Seeding mode error</source>
        <translation>Грешка у режиму донирања</translation>
    </message>
    <message>
        <source>You chose to skip file checking. However, local files do not seem to exist in the current destionation folder. Please disable this feature or update the save path.</source>
        <translation>Висте изабрали да прескочите проверу датотеке. Међутим, локални фајлови изгледа не постоје у одредишном директоријуму. Молим онемогућите ову функцију или ажурирајте путању фајла.</translation>
    </message>
    <message>
        <source>Invalid file selection</source>
        <translation>Погрешан избор датотеке</translation>
    </message>
    <message>
        <source>You must select at least one file in the torrent</source>
        <translation>Морате изабрати бар једну датотеку за Торент</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Приоритет</translation>
    </message>
</context>
</TS>
