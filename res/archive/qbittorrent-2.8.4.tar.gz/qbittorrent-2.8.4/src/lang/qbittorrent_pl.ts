<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="pl" sourcelanguage="en">
<context>
    <name>AboutDlg</name>
    <message>
        <source>About qBittorrent</source>
        <translation>O qBittorrent</translation>
    </message>
    <message>
        <source>About</source>
        <translation>O programie</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation>Imię i nazwisko:</translation>
    </message>
    <message>
        <source>Country:</source>
        <translation>Kraj:</translation>
    </message>
    <message>
        <source>E-mail:</source>
        <translation>E-mail:</translation>
    </message>
    <message>
        <source>Christophe Dumez</source>
        <translation>Christophe Dumez</translation>
    </message>
    <message>
        <source>France</source>
        <translation>Francja</translation>
    </message>
    <message>
        <source>Translation</source>
        <translation>Lokalizacja</translation>
    </message>
    <message>
        <source>License</source>
        <translation>Licencja</translation>
    </message>
    <message>
        <source>&lt;h3&gt;&lt;b&gt;qBittorrent&lt;/b&gt;&lt;/h3&gt;</source>
        <translation>&lt;h3&gt;&lt;b&gt;qBittorrent&lt;/b&gt;&lt;/h3&gt;</translation>
    </message>
    <message>
        <source>chris@qbittorrent.org</source>
        <translation>chris@qbittorrent.org</translation>
    </message>
    <message>
        <source>Thanks to</source>
        <translation>Podziękowania dla</translation>
    </message>
    <message utf8="true">
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;A Bittorrent client programmed in C++, based on Qt4 toolkit &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;and libtorrent-rasterbar. &lt;br /&gt;&lt;br /&gt;Copyright ©2006-2010 Christophe Dumez&lt;br /&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Home Page:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://www.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;http://www.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Forum:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://forum.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;http://forum.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;IRC:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; #qbittorrent on Freenode&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;Klient sieci bittorrent napisany w języku C++, wykorzystuje biblioteki Qt4&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;i libtorrent-rasterbar.&lt;br /&gt;&lt;br /&gt;Copyright ©2006-2010 Christophe Dumez&lt;br /&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Strona domowa:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://www.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;http://www.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Forum:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://forum.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;http://forum.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;IRC:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; #qbittorrent on Freenode&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message utf8="true">
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;An advanced BitTorrent client programmed in C++, based on Qt4 toolkit and libtorrent-rasterbar. &lt;br /&gt;&lt;br /&gt;Copyright ©2006-2011 Christophe Dumez&lt;br /&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Home Page:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://www.qbittorrent.org&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans&apos;; text-decoration: underline; color:#0057ae;&quot;&gt;http://www.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Bug Tracker:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://bugs.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;http://bugs.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Forum:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://forum.qbittorrent.org&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans&apos;; text-decoration: underline; color:#0057ae;&quot;&gt;http://forum.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;IRC:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; #qbittorrent on Freenode&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;Zaawansowany klient sieci bittorrent napisany w języku C++, z wykorzystaniem biblioteki Qt4 i libtorrent-rasterbar.&lt;br /&gt;&lt;br /&gt;Copyright ©2006-2011 Christophe Dumez&lt;br /&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Strona domowa:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://www.qbittorrent.org&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans&apos;; text-decoration: underline; color:#0057ae;&quot;&gt;http://www.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Bug Tracker:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://bugs.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;http://bugs.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Forum:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://forum.qbittorrent.org&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans&apos;; text-decoration: underline; color:#0057ae;&quot;&gt;http://forum.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;IRC:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; #qbittorrent on Freenode&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
</context>
<context>
    <name>AdvancedSettings</name>
    <message>
        <source>Property</source>
        <translation type="obsolete">Parametr</translation>
    </message>
    <message>
        <source>Value</source>
        <translation type="obsolete">Wartość</translation>
    </message>
    <message>
        <source>Ignore transfer limits on local network</source>
        <translation>Ignoruj limity prędkości w sieci lokalnej</translation>
    </message>
    <message>
        <source>Include TCP/IP overhead in transfer limits</source>
        <translation type="obsolete">Ignoruj narzuty protokołu TCP/IP w limitach prędkości</translation>
    </message>
    <message>
        <source>Disk write cache size</source>
        <translatorcomment>?</translatorcomment>
        <translation>Rozmiar pamięci podręcznej na dysku</translation>
    </message>
    <message>
        <source> MiB</source>
        <translation>MiB</translation>
    </message>
    <message>
        <source>Outgoing ports (Min) [0: Disabled]</source>
        <translation>Port wychodzący (Min) [0: wyłączony]</translation>
    </message>
    <message>
        <source>Outgoing ports (Max) [0: Disabled]</source>
        <translation>Port wychodzący (Max) [0: wyłączony]</translation>
    </message>
    <message>
        <source>Recheck torrents on completion</source>
        <translation>Sprawdzaj dane po pobraniu</translation>
    </message>
    <message>
        <source>Transfer list refresh interval</source>
        <translation>Częstotliwość odświeżania listy transferów</translation>
    </message>
    <message>
        <source> ms</source>
        <comment> milliseconds</comment>
        <translation> ms</translation>
    </message>
    <message>
        <source>Resolve peer countries (GeoIP)</source>
        <translation>Odczytuj kraje partnerów (GeoIP)</translation>
    </message>
    <message>
        <source>Resolve peer host names</source>
        <translation>Odczytuj nazwy hostów partnerów</translation>
    </message>
    <message>
        <source>Maximum number of half-open connections [0: Disabled]</source>
        <translation>Limit pół-otwartych połączeń  [0: Bez limitu]</translation>
    </message>
    <message>
        <source>Strict super seeding</source>
        <translation type="unfinished">Wyłącznie &apos;super seed&apos;</translation>
    </message>
    <message>
        <source>Network Interface (requires restart)</source>
        <translation>Interfejs sieciowy (wymaga ponownego uruchomienia)</translation>
    </message>
    <message>
        <source>Any interface</source>
        <comment>i.e. Any network interface</comment>
        <translation>Dowolny interfejs</translation>
    </message>
    <message>
        <source>Display program notification balloons</source>
        <translation type="obsolete">Wyświetlaj powiadomienia w dymkach</translation>
    </message>
    <message>
        <source>Enable embedded tracker</source>
        <translation>Włącz wbudowany tracker</translation>
    </message>
    <message>
        <source>Embedded tracker port</source>
        <translation>Port wbudowanego trackera</translation>
    </message>
    <message>
        <source>Check for software updates</source>
        <translation>Sprawdzaj aktualizacje programu</translation>
    </message>
    <message>
        <source>Use system icon theme</source>
        <translation>Używaj systemowego zestawu ikon</translation>
    </message>
    <message>
        <source>Confirm torrent deletion</source>
        <translation>Potwierdzaj usuwanie torrenta</translation>
    </message>
    <message>
        <source>IP Address to report to trackers (requires restart)</source>
        <translation>Adres IP zgłaszany trackerom (wymaga ponownego uruchomienia)</translation>
    </message>
    <message>
        <source>Setting</source>
        <translation>Ustawienie</translation>
    </message>
    <message>
        <source>Value</source>
        <comment>Value set for this setting</comment>
        <translation>Wartość</translation>
    </message>
    <message>
        <source>Display program on-screen notifications</source>
        <translation>Wyświetlaj powiadomienia na ekranie</translation>
    </message>
    <message>
        <source>Exchange trackers with other peers</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AutomatedRssDownloader</name>
    <message>
        <source>Automated RSS Downloader</source>
        <translation>Automatyczne pobieranie z RSS</translation>
    </message>
    <message>
        <source>Enable the automated RSS downloader</source>
        <translation>Włącz automatyczne pobieranie</translation>
    </message>
    <message>
        <source>Download rules</source>
        <translation>Reguły pobierania</translation>
    </message>
    <message>
        <source>Rule definition</source>
        <translation>Definicja reguły</translation>
    </message>
    <message>
        <source>Must contain:</source>
        <translation>Musi zawierać:</translation>
    </message>
    <message>
        <source>Must not contain:</source>
        <translation>Nie może zawierać:</translation>
    </message>
    <message>
        <source>Save torrent to:</source>
        <translation type="obsolete">Zapisz torrent do:</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Assign label:</source>
        <translation>Przypisz etykietę:</translation>
    </message>
    <message>
        <source>Apply rule to feeds:</source>
        <translation>Zastosuj regułę do kanałów:</translation>
    </message>
    <message>
        <source>Matching RSS articles</source>
        <translation type="unfinished">Pasujące wpisy RSS</translation>
    </message>
    <message>
        <source>Save to a different directory</source>
        <translation>Pobierz do innego katalogu</translation>
    </message>
    <message>
        <source>Save to:</source>
        <translation>Pobierz do:</translation>
    </message>
    <message>
        <source>Import...</source>
        <translation>Importuj...</translation>
    </message>
    <message>
        <source>Export...</source>
        <translation>Eksportuj...</translation>
    </message>
    <message>
        <source>New rule name</source>
        <translation>Nazwa nowej reguły</translation>
    </message>
    <message>
        <source>Please type the name of the new download rule.</source>
        <translation>Wprowadź nazwę dla tworzonej reguły.</translation>
    </message>
    <message>
        <source>Rule name conflict</source>
        <translation>Konflikt nazw reguł</translation>
    </message>
    <message>
        <source>A rule with this name already exists, please choose another name.</source>
        <translation>Reguła o wybranej nazwie już istnieje, należy wybrać inną.</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the download rule named %1?</source>
        <translation>Czy na pewno usunąć regułę pobierania o nazwie: %1?</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the selected download rules?</source>
        <translation>Czy na pewno usunąć wybrane reguły pobierania?</translation>
    </message>
    <message>
        <source>Rule deletion confirmation</source>
        <translation>Usuwanie reguły</translation>
    </message>
    <message>
        <source>Destination directory</source>
        <translation>Wybierz katalog docelowy</translation>
    </message>
    <message>
        <source>Invalid action</source>
        <translation>Nieprawidłowa operacja</translation>
    </message>
    <message>
        <source>The list is empty, there is nothing to export.</source>
        <translatorcomment>wtf?</translatorcomment>
        <translation type="unfinished">Lista jest pusta, nie ma czego eksportować.</translation>
    </message>
    <message>
        <source>Where would you like to save the list?</source>
        <translation type="unfinished">Wskaż położenie pliku gdzie zostanie wyeksportowana lista</translation>
    </message>
    <message>
        <source>Rules list (*.rssrules)</source>
        <translation>Lista reguł (*.rssrules)</translation>
    </message>
    <message>
        <source>I/O Error</source>
        <translation>Błąd We/Wy</translation>
    </message>
    <message>
        <source>Failed to create the destination file</source>
        <translation>Błąd podczas tworzenia pliku docelowego</translation>
    </message>
    <message>
        <source>Please point to the RSS download rules file</source>
        <translation>Wskaż położenie pliku reguł do zaimportowania</translation>
    </message>
    <message>
        <source>Rules list (*.rssrules *.filters)</source>
        <translation>Lista reguł (*.rssrules *.filters)</translation>
    </message>
    <message>
        <source>Import Error</source>
        <translation>Błąd podczas importowania</translation>
    </message>
    <message>
        <source>Failed to import the selected rules file</source>
        <translation>Nie udało się zaimportować wybranego pliku reguł</translation>
    </message>
    <message>
        <source>Add new rule...</source>
        <translation>Dodaj nową...</translation>
    </message>
    <message>
        <source>Delete rule</source>
        <translation>Usuń</translation>
    </message>
    <message>
        <source>Rename rule...</source>
        <translation>Zmień nazwę...</translation>
    </message>
    <message>
        <source>Delete selected rules</source>
        <translation>Usuń wybrane</translation>
    </message>
    <message>
        <source>Rule renaming</source>
        <translation>Zmiana nazwy</translation>
    </message>
    <message>
        <source>Please type the new rule name</source>
        <translation>Podaj nową nazwę reguły</translation>
    </message>
    <message>
        <source>Use regular expressions</source>
        <translation>Używaj wyrażeń regularnych</translation>
    </message>
    <message>
        <source>Regex mode: use Perl-like regular expressions</source>
        <translation>Tryb regex: używaj wyrażeń regularnych w stylu Perl</translation>
    </message>
    <message>
        <source>Wildcard mode: you can use&lt;ul&gt;&lt;li&gt;? to match any single character&lt;/li&gt;&lt;li&gt;* to match zero or more of any characters&lt;/li&gt;&lt;li&gt;Whitespaces count as AND operators&lt;/li&gt;&lt;/ul&gt;</source>
        <translation type="unfinished">Tryb wzorca: można użyć &lt;ul&gt;&lt;li&gt;? dla dowolnego pojedynczego znaku&lt;/li&gt;&lt;li&gt;* dla dowolnej ilości znaków&lt;/li&gt;&lt;li&gt;Białe znaki są traktowane jako operatory AND&lt;/li&gt;&lt;/ul&gt;</translation>
    </message>
    <message>
        <source>Wildcard mode: you can use&lt;ul&gt;&lt;li&gt;? to match any single character&lt;/li&gt;&lt;li&gt;* to match zero or more of any characters&lt;/li&gt;&lt;li&gt;| is used as OR operator&lt;/li&gt;&lt;/ul&gt;</source>
        <translation type="unfinished">Tryb wzorca: można użyć &lt;ul&gt;&lt;li&gt;? dla dowolnego pojedynczego znaku&lt;/li&gt;&lt;li&gt;* dla dowolnej ilości znaków&lt;/li&gt;&lt;li&gt;Białe znaki są traktowane jako operatory OR&lt;/li&gt;&lt;/ul&gt;</translation>
    </message>
</context>
<context>
    <name>Bittorrent</name>
    <message>
        <source>%1 reached the maximum ratio you set.</source>
        <translation type="obsolete">%1 osiagnął ustawiony przez ciebie współczynnik udziału.</translation>
    </message>
    <message>
        <source>qBittorrent is bound to port: TCP/%1</source>
        <comment>e.g: qBittorrent is bound to port: 6881</comment>
        <translation type="obsolete">qBittorrent jest połączony przez port: TCP/%1</translation>
    </message>
    <message>
        <source>UPnP support [ON]</source>
        <translation type="obsolete">Wsparcie UPnP [WŁ]</translation>
    </message>
    <message>
        <source>UPnP support [OFF]</source>
        <translation type="obsolete">Wsparcie UPnP [WYŁ]</translation>
    </message>
    <message>
        <source>NAT-PMP support [ON]</source>
        <translation type="obsolete">Wsparcie NAT-PMP [WŁ]</translation>
    </message>
    <message>
        <source>NAT-PMP support [OFF]</source>
        <translation type="obsolete">Wsparcie NAT-PMP [WYŁ]</translation>
    </message>
    <message>
        <source>DHT support [ON], port: UDP/%1</source>
        <translation type="obsolete">Wsparcie DHT [WŁ], port: UDP/%1</translation>
    </message>
    <message>
        <source>DHT support [OFF]</source>
        <translation type="obsolete">Wsparcie DHT [WYŁ]</translation>
    </message>
    <message>
        <source>PeX support [ON]</source>
        <translation type="obsolete">Wsparcie PeX [WŁ]</translation>
    </message>
    <message>
        <source>Local Peer Discovery [ON]</source>
        <translation type="obsolete">Wyszukiwanie partnerów lokalnych [WŁ]</translation>
    </message>
    <message>
        <source>Local Peer Discovery support [OFF]</source>
        <translation type="obsolete">Wyszukiwanie partnerów lokalnych [WYŁ]</translation>
    </message>
    <message>
        <source>Encryption support [ON]</source>
        <translation type="obsolete">Wsparcie szyfrowania [WŁ]</translation>
    </message>
    <message>
        <source>Encryption support [FORCED]</source>
        <translation type="obsolete">Wsparcie szyfrowania [WYMUSZONE]</translation>
    </message>
    <message>
        <source>Encryption support [OFF]</source>
        <translation type="obsolete">Wsparcie szyfrowania [WYŁ]</translation>
    </message>
    <message>
        <source>Web User Interface Error - Unable to bind Web UI to port %1</source>
        <translation type="obsolete">Błąd interfejsu www - Nie można uruchomić interefejsu www na porcie %1</translation>
    </message>
    <message>
        <source>&apos;%1&apos; was removed from transfer list and hard disk.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation type="obsolete">&apos;%1&apos; usunięto z listy transferów i twardego dysku.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; was removed from transfer list.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation type="obsolete">&apos;%1&apos; usunięto z listy transferów.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is not a valid magnet URI.</source>
        <translation type="obsolete">&apos;%1&apos; jest niepoprawnym adresem magnet.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is already in download list.</source>
        <comment>e.g: &apos;xxx.avi&apos; is already in download list.</comment>
        <translation type="obsolete">&apos;%1&apos; jest już na liście pobierania.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; resumed. (fast resume)</source>
        <comment>&apos;/home/y/xxx.torrent&apos; was resumed. (fast resume)</comment>
        <translation type="obsolete">&apos;%1&apos; wznowiony. (szybkie wznawianie)</translation>
    </message>
    <message>
        <source>&apos;%1&apos; added to download list.</source>
        <comment>&apos;/home/y/xxx.torrent&apos; was added to download list.</comment>
        <translation type="obsolete">&apos;%1&apos; dodano do listy pobierania.</translation>
    </message>
    <message>
        <source>Unable to decode torrent file: &apos;%1&apos;</source>
        <comment>e.g: Unable to decode torrent file: &apos;/home/y/xxx.torrent&apos;</comment>
        <translation type="obsolete">Nie można odczytać pliku torrent: &apos;%1&apos;</translation>
    </message>
    <message>
        <source>This file is either corrupted or this isn&apos;t a torrent.</source>
        <translation type="obsolete">Plik jest uszkodzony lub nie jest plikiem torrent.</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;was blocked due to your IP filter&lt;/i&gt;</source>
        <comment>x.y.z.w was blocked</comment>
        <translation type="obsolete">&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;zablokowany przez filtr IP&lt;/i&gt;</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;was banned due to corrupt pieces&lt;/i&gt;</source>
        <comment>x.y.z.w was banned</comment>
        <translation type="obsolete">&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;zablokowany z powodu uszkodzonych części&lt;/i&gt;</translation>
    </message>
    <message>
        <source>Recursive download of file %1 embedded in torrent %2</source>
        <comment>Recursive download of test.torrent embedded in torrent test2</comment>
        <translation type="obsolete">Rekursywne pobieranie pliku %1 osadzonego w pliku torrent %2</translation>
    </message>
    <message>
        <source>Unable to decode %1 torrent file.</source>
        <translation type="obsolete">Nie można odczytać pliku torrent: &apos;%1&apos;.</translation>
    </message>
    <message>
        <source>UPnP/NAT-PMP: Port mapping failure, message: %1</source>
        <translation type="obsolete">UPnP/NAT-PMP: Błąd mapowania portu, wiadomość %1</translation>
    </message>
    <message>
        <source>UPnP/NAT-PMP: Port mapping successful, message: %1</source>
        <translation type="obsolete">UPnP/NAT-PMP: Udane mapowanie portu, wiadomość %1</translation>
    </message>
    <message>
        <source>Fast resume data was rejected for torrent %1, checking again...</source>
        <translation type="obsolete">Szybkie wznowienie danych zostało odrzucone przez torrent %1, ponowne sprawdzanie...</translation>
    </message>
    <message>
        <source>Url seed lookup failed for url: %1, message: %2</source>
        <translation type="obsolete">Błąd wyszukiwania url partnera dla adresu:%1, wiadomość: %2</translation>
    </message>
    <message>
        <source>Downloading &apos;%1&apos;, please wait...</source>
        <comment>e.g: Downloading &apos;xxx.torrent&apos;, please wait...</comment>
        <translation type="obsolete">Pobieranie &apos;%1&apos;, proszę czekać...</translation>
    </message>
    <message>
        <source>Using a disk cache size of %1 MiB</source>
        <translation type="obsolete">Rozmiar pamięci podręcznej na dysku wynosi %1 MiB</translation>
    </message>
    <message>
        <source>PeX support [OFF]</source>
        <translation type="obsolete">Wsparcie PeX [WYŁ]</translation>
    </message>
    <message>
        <source>Restart is required to toggle PeX support</source>
        <translation type="obsolete">Zmiana statusu PeX wymaga ponownego uruchomienia</translation>
    </message>
    <message>
        <source>The Web UI is listening on port %1</source>
        <translation type="obsolete">Interfejs www nasłuchuje na porcie: %1</translation>
    </message>
    <message>
        <source>HTTP user agent is %1</source>
        <translation type="obsolete">HTTP user agent: %1</translation>
    </message>
    <message>
        <source>Reason: %1</source>
        <translation type="obsolete">Powód: %1</translation>
    </message>
    <message>
        <source>Note: new trackers were added to the existing torrent.</source>
        <translation type="obsolete">Uwaga: nowe trackery zostały dodane do istniejącego torrenta.</translation>
    </message>
    <message>
        <source>Note: new URL seeds were added to the existing torrent.</source>
        <translation type="obsolete">Uwaga: nowe URL seedów zostały dodane do istniejącego torrenta.</translation>
    </message>
    <message>
        <source>An I/O error occured, &apos;%1&apos; paused.</source>
        <translation type="obsolete">Wystąpił błąd We/Wy, &apos;%1&apos; wstrzymany.</translation>
    </message>
    <message>
        <source>Removing torrent %1...</source>
        <translation type="obsolete">Usuwanie torrenta %1...</translation>
    </message>
    <message>
        <source>Pausing torrent %1...</source>
        <translation type="obsolete">Wstrzymywanie torrenta %1...</translation>
    </message>
    <message>
        <source>Error: The torrent %1 does not contain any file.</source>
        <translation type="obsolete">Błąd: Torrent %1 nie zawiera żadnego pliku.</translation>
    </message>
    <message>
        <source>File sizes mismatch for torrent %1, pausing it.</source>
        <translation type="obsolete">Błędny razmiar pliku z torrenta %1, wstrzymuję pobieranie.</translation>
    </message>
</context>
<context>
    <name>ConsoleDlg</name>
    <message>
        <source>General</source>
        <translation type="obsolete">Główne</translation>
    </message>
    <message>
        <source>Blocked IPs</source>
        <translation type="obsolete">Zablokowane IP</translation>
    </message>
    <message>
        <source>qBittorrent log viewer</source>
        <translation type="obsolete">Przeglądarka dziennika qBittorrent</translation>
    </message>
</context>
<context>
    <name>CookiesDlg</name>
    <message>
        <source>Cookies management</source>
        <translation>Zarządzanie ciasteczkami</translation>
    </message>
    <message>
        <source>Key</source>
        <extracomment>As in Key/Value pair</extracomment>
        <translation>Klucz</translation>
    </message>
    <message>
        <source>Value</source>
        <extracomment>As in Key/Value pair</extracomment>
        <translation>Wartość</translation>
    </message>
    <message>
        <source>Common keys for cookies are : &apos;%1&apos;, &apos;%2&apos;.
You should get this information from your Web browser preferences.</source>
        <translation>Zwykle klucze dla ciasteczek mają format: &apos;%1&apos;, &apos;%2&apos;.
Informacje te powinny zostać pobrane z ustawień przeglądarki internetowej.</translation>
    </message>
</context>
<context>
    <name>DNSUpdater</name>
    <message>
        <source>Your dynamic DNS was successfuly updated.</source>
        <translation>Pomyślnie zaktualizowano dynamiczny DNS.</translation>
    </message>
    <message>
        <source>Dynamic DNS error: The service is temporarily unavailable, it will be retried in 30 minutes.</source>
        <translation type="unfinished">Błąd dynamicznego DNS: Usługa tymczasowo niedostępna, ponowienie za 30 minut.</translation>
    </message>
    <message>
        <source>Dynamic DNS error: hostname supplied does not exist under specified account.</source>
        <translation type="unfinished">Błąd dynamicznego DNS: Wskazane konto nie zawiera podanej nazwy hosta.</translation>
    </message>
    <message>
        <source>Dynamic DNS error: Invalid username/password.</source>
        <translation>Błąd dynamicznego DNS: Nieprawidłowa nazwa użytkownika i/lub hasło.</translation>
    </message>
    <message>
        <source>Dynamic DNS error: qBittorrent was blacklisted by the service, please report a bug at http://bugs.qbittorrent.org.</source>
        <translation>Błąd dynamicznego DNS: Usługa dodała program qBittorrent do czarnej listy, proszę zgłosić błąd na stronie http://bugs.qbittorrent.org.</translation>
    </message>
    <message>
        <source>Dynamic DNS error: %1 was returned by the service, please report a bug at http://bugs.qbittorrent.org.</source>
        <translation>Błąd dynamicznego DNS: Usługa zwróciła: %1, proszę zgłosić błąd na stronie http://bugs.qbittorrent.org.</translation>
    </message>
    <message>
        <source>Dynamic DNS error: Your username was blocked due to abuse.</source>
        <translation>Błąd dynamicznego DNS: Z powodu nadużycia nazwa użytkownika została zablokowana.</translation>
    </message>
    <message>
        <source>Dynamic DNS error: supplied domain name is invalid.</source>
        <translation>Błąd dynamicznego DNS: Podana nazwa domeny jest nieprawidłowa.</translation>
    </message>
    <message>
        <source>Dynamic DNS error: supplied username is too short.</source>
        <translation>Błąd dynamicznego DNS: Podana nazwa użytkownika jest zbyt krótka.</translation>
    </message>
    <message>
        <source>Dynamic DNS error: supplied password is too short.</source>
        <translation>Błąd dynamicznego DNS: Podane hasło jest zbyt krótkie.</translation>
    </message>
</context>
<context>
    <name>DownloadThread</name>
    <message>
        <source>I/O Error</source>
        <translation>Błąd We/Wy</translation>
    </message>
    <message>
        <source>The remote host name was not found (invalid hostname)</source>
        <translation type="unfinished">Nie odnaleziono nazwy zdalnego hosta (nieprawidłowa nazwa hosta)</translation>
    </message>
    <message>
        <source>The operation was canceled</source>
        <translation type="unfinished">Operacja została anulowana</translation>
    </message>
    <message>
        <source>The remote server closed the connection prematurely, before the entire reply was received and processed</source>
        <translation type="unfinished">Zdalny serwer przedwcześnie zakończył połączenie, zanim otrzymano i przetworzono odpowiedź</translation>
    </message>
    <message>
        <source>The connection to the remote server timed out</source>
        <translation type="unfinished">Przekroczono czas oczekiwania na połącznie ze zdalnym serwerem</translation>
    </message>
    <message>
        <source>SSL/TLS handshake failed</source>
        <translation type="unfinished">Niepomyślna próba negocjacji połączenie SSL/TLS</translation>
    </message>
    <message>
        <source>The remote server refused the connection</source>
        <translation type="unfinished">Zdalny serwer odrzucił połączenie</translation>
    </message>
    <message>
        <source>The connection to the proxy server was refused</source>
        <translation type="unfinished">Połączenie z serwerem proxy zostało odrzucone</translation>
    </message>
    <message>
        <source>The proxy server closed the connection prematurely</source>
        <translation type="unfinished">Serwer proxy przedwcześnie zakończył połączenie</translation>
    </message>
    <message>
        <source>The proxy host name was not found</source>
        <translation type="unfinished">Nie znaleziono nazwy hosta serwera proxy</translation>
    </message>
    <message>
        <source>The connection to the proxy timed out or the proxy did not reply in time to the request sent</source>
        <translation type="unfinished">Przkroczono czas oczekiwania na połączenie z serwerm proxy lub serwer nie odpowiedział na czas</translation>
    </message>
    <message>
        <source>The proxy requires authentication in order to honour the request but did not accept any credentials offered</source>
        <translation type="unfinished">Serwer proxy wymaga uwierzytelnienia aby zaakceptować żądanie lecz oferowane dane uwierzytelnienia zostały odrzucone</translation>
    </message>
    <message>
        <source>The access to the remote content was denied (401)</source>
        <translation type="unfinished">Odmówiono dostępu do zdalnego zasobu (401)</translation>
    </message>
    <message>
        <source>The operation requested on the remote content is not permitted</source>
        <translation type="unfinished">Żądana operacja na zdalnym zasobie nie jest dozwolona</translation>
    </message>
    <message>
        <source>The remote content was not found at the server (404)</source>
        <translation type="unfinished">Nie znaleziono zdalnego zasobu na serwerze (404)</translation>
    </message>
    <message>
        <source>The remote server requires authentication to serve the content but the credentials provided were not accepted</source>
        <translation type="unfinished">Zdalny serwer wymaga uwierzytelnienia w celu dostępu do zasobu lecz dane uwierzytelniające nie zostały zaakceptowane</translation>
    </message>
    <message>
        <source>The Network Access API cannot honor the request because the protocol is not known</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The requested operation is invalid for this protocol</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>An unknown network-related error was detected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>An unknown proxy-related error was detected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>An unknown error related to the remote content was detected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A breakdown in protocol was detected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation type="unfinished">Nieznany błąd</translation>
    </message>
</context>
<context>
    <name>EventManager</name>
    <message>
        <source>%1/s</source>
        <comment>e.g. 120 KiB/s</comment>
        <translation>%1/s</translation>
    </message>
    <message>
        <source>Working</source>
        <translation>Działa</translation>
    </message>
    <message>
        <source>Updating...</source>
        <translation>Aktualizowanie...</translation>
    </message>
    <message>
        <source>Not working</source>
        <translation>Nie działa</translation>
    </message>
    <message>
        <source>Not contacted yet</source>
        <translation>Niesprawdzony</translation>
    </message>
    <message>
        <source>this session</source>
        <translation>w tej sesji</translation>
    </message>
    <message>
        <source>/s</source>
        <comment>/second (i.e. per second)</comment>
        <translation>/s</translation>
    </message>
    <message>
        <source>Seeded for %1</source>
        <comment>e.g. Seeded for 3m10s</comment>
        <translation>Rozsiewany przez %1</translation>
    </message>
    <message>
        <source>%1 max</source>
        <comment>e.g. 10 max</comment>
        <translation>max %1</translation>
    </message>
</context>
<context>
    <name>ExecutionLog</name>
    <message>
        <source>Form</source>
        <translation type="obsolete">Formularz</translation>
    </message>
    <message>
        <source>General</source>
        <translation>Główny</translation>
    </message>
    <message>
        <source>Blocked IPs</source>
        <translation>Zablokowane IP</translation>
    </message>
</context>
<context>
    <name>FeedDownloader</name>
    <message>
        <source>RSS Feed downloader</source>
        <translation type="obsolete">Pobieranie z kanałów RSS</translation>
    </message>
    <message>
        <source>RSS feed:</source>
        <translation type="obsolete">Kanał RSS:</translation>
    </message>
    <message>
        <source>Feed name</source>
        <translation type="obsolete">Nazwa kanału</translation>
    </message>
    <message>
        <source>Automatically download torrents from this feed</source>
        <translation type="obsolete">Automatyczne pobieranie plików torrent z tego kanału</translation>
    </message>
    <message>
        <source>Download filters</source>
        <translation type="obsolete">Filtry pobierania</translation>
    </message>
    <message>
        <source>Filters:</source>
        <translation type="obsolete">Filtry:</translation>
    </message>
    <message>
        <source>Filter settings</source>
        <translation type="obsolete">Ustawienia filtra</translation>
    </message>
    <message>
        <source>Matches:</source>
        <translation type="obsolete">Zgodne:</translation>
    </message>
    <message>
        <source>Does not match:</source>
        <translation type="obsolete">Niezgodne:</translation>
    </message>
    <message>
        <source>Destination folder:</source>
        <translation type="obsolete">Katalog docelowy:</translation>
    </message>
    <message>
        <source>...</source>
        <translation type="obsolete">...</translation>
    </message>
    <message>
        <source>Filter testing</source>
        <translation type="obsolete">Testowanie filtra</translation>
    </message>
    <message>
        <source>Torrent title:</source>
        <translation type="obsolete">Tytuł torrenta:</translation>
    </message>
    <message>
        <source>Result:</source>
        <translation type="obsolete">Wynik:</translation>
    </message>
    <message>
        <source>Test</source>
        <translation type="obsolete">Testuj</translation>
    </message>
    <message>
        <source>Import...</source>
        <translation type="obsolete">Importuj...</translation>
    </message>
    <message>
        <source>Export...</source>
        <translation type="obsolete">Eksportuj...</translation>
    </message>
    <message>
        <source>Rename filter</source>
        <translation type="obsolete">Zmień nazwę filtra</translation>
    </message>
    <message>
        <source>Remove filter</source>
        <translation type="obsolete">Usuń filtr</translation>
    </message>
    <message>
        <source>Add filter</source>
        <translation type="obsolete">Dodaj filtr</translation>
    </message>
</context>
<context>
    <name>FeedDownloaderDlg</name>
    <message>
        <source>New filter</source>
        <translation type="obsolete">Nowy filtr</translation>
    </message>
    <message>
        <source>Please choose a name for this filter</source>
        <translation type="obsolete">Należy podać nazwę dla tego filtra</translation>
    </message>
    <message>
        <source>Filter name:</source>
        <translation type="obsolete">Nazwa filtra:</translation>
    </message>
    <message>
        <source>Invalid filter name</source>
        <translation type="obsolete">Nieprawidłowa nazwa filtra</translation>
    </message>
    <message>
        <source>The filter name cannot be left empty.</source>
        <translation type="obsolete">Nazwa filtra nie może być pusta.</translation>
    </message>
    <message>
        <source>This filter name is already in use.</source>
        <translation type="obsolete">Taka nazwa filtra już istnieje.</translation>
    </message>
    <message>
        <source>Filter testing error</source>
        <translation type="obsolete">Błąd testowania filtra</translation>
    </message>
    <message>
        <source>Please specify a test torrent name.</source>
        <translation type="obsolete">Należy podać nazwę torrenta do przetestowania.</translation>
    </message>
    <message>
        <source>matches</source>
        <translation type="obsolete">pasuje</translation>
    </message>
    <message>
        <source>does not match</source>
        <translation type="obsolete">nie pasuje</translation>
    </message>
    <message>
        <source>Select file to import</source>
        <translation type="obsolete">Należy wybrać plik do zaimportowania</translation>
    </message>
    <message>
        <source>Filters Files</source>
        <translation type="obsolete">Pliki filtrów</translation>
    </message>
    <message>
        <source>Import successful</source>
        <translation type="obsolete">Udane importowanie</translation>
    </message>
    <message>
        <source>Filters import was successful.</source>
        <translation type="obsolete">Pomyślnie zaimportowano filtry.</translation>
    </message>
    <message>
        <source>Import failure</source>
        <translation type="obsolete">Błąd importowania</translation>
    </message>
    <message>
        <source>Filters could not be imported due to an I/O error.</source>
        <translation type="obsolete">Nieudane importowanie filtrów z powodu błędu We/Wy.</translation>
    </message>
    <message>
        <source>Select destination file</source>
        <translation type="obsolete">Należy wybrać plik docelowy</translation>
    </message>
    <message>
        <source>Export successful</source>
        <translation type="obsolete">Pomyślne eksportowanie</translation>
    </message>
    <message>
        <source>Filters export was successful.</source>
        <translation type="obsolete">Pomyślnie wyeksportowano fitry.</translation>
    </message>
    <message>
        <source>Export failure</source>
        <translation type="obsolete">Błąd eksportowania</translation>
    </message>
    <message>
        <source>Filters could not be exported due to an I/O error.</source>
        <translation type="obsolete">Nieudane eksportowanie filtrów z powodu błędu We/Wy.</translation>
    </message>
    <message>
        <source>Choose save path</source>
        <translation type="obsolete">Wybierz katalog docelowy</translation>
    </message>
</context>
<context>
    <name>FeedList</name>
    <message>
        <source>Unread</source>
        <translation type="obsolete">Nieprzeczytane</translation>
    </message>
</context>
<context>
    <name>FeedListWidget</name>
    <message>
        <source>RSS feeds</source>
        <translation>Kanały RSS</translation>
    </message>
    <message>
        <source>Unread</source>
        <translation>Nieprzeczytane</translation>
    </message>
</context>
<context>
    <name>GUI</name>
    <message>
        <source>Open Torrent Files</source>
        <translation type="obsolete">Otwórz pliki Torrent</translation>
    </message>
    <message>
        <source>Torrent Files</source>
        <translation type="obsolete">Pliki Torrent</translation>
    </message>
    <message>
        <source>qBittorrent</source>
        <translation type="obsolete">qBittorrent</translation>
    </message>
    <message>
        <source>Transfers</source>
        <translation type="obsolete">Transfery</translation>
    </message>
    <message>
        <source>qBittorrent %1</source>
        <comment>e.g: qBittorrent v0.x</comment>
        <translation type="obsolete">qBittorrent %1</translation>
    </message>
    <message>
        <source>DL speed: %1 KiB/s</source>
        <comment>e.g: Download speed: 10 KiB/s</comment>
        <translation type="obsolete">Prędkość DL: %1 KiB/s</translation>
    </message>
    <message>
        <source>UP speed: %1 KiB/s</source>
        <comment>e.g: Upload speed: 10 KiB/s</comment>
        <translation type="obsolete">Prędkość UP: %1 KiB/</translation>
    </message>
    <message>
        <source>%1 has finished downloading.</source>
        <comment>e.g: xxx.avi has finished downloading.</comment>
        <translation type="obsolete">%1 został pobrany.</translation>
    </message>
    <message>
        <source>I/O Error</source>
        <comment>i.e: Input/Output Error</comment>
        <translation type="obsolete">Błąd We/Wy</translation>
    </message>
    <message>
        <source>Search</source>
        <translation type="obsolete">Szukaj</translation>
    </message>
    <message>
        <source>RSS</source>
        <translation type="obsolete">RSS</translation>
    </message>
    <message>
        <source>An I/O error occured for torrent %1.
 Reason: %2</source>
        <comment>e.g: An error occured for torrent xxx.avi.
 Reason: disk is full.</comment>
        <translation type="obsolete">Wystąpił błąd We/Wy dla pliku torrent %1.
Powód: %2</translation>
    </message>
    <message>
        <source>Alt+1</source>
        <comment>shortcut to switch to first tab</comment>
        <translation type="obsolete">Alt+1</translation>
    </message>
    <message>
        <source>Url download error</source>
        <translation type="obsolete">Błąd pobierania adresu</translation>
    </message>
    <message>
        <source>Couldn&apos;t download file at url: %1, reason: %2.</source>
        <translation type="obsolete">Nie można pobrać pliku z url: %1, powód: %2.</translation>
    </message>
    <message>
        <source>Ctrl+F</source>
        <comment>shortcut to switch to search tab</comment>
        <translation type="obsolete">Ctrl+F</translation>
    </message>
    <message>
        <source>Options were saved successfully.</source>
        <translation type="obsolete">Ustawienia pomyślnie zapisane.</translation>
    </message>
    <message>
        <source>Download completion</source>
        <translation type="obsolete">Zakończenie pobierania</translation>
    </message>
    <message>
        <source>Some files are currently transferring.
Are you sure you want to quit qBittorrent?</source>
        <translation type="obsolete">Aktualnie trwa pobieranie plików.
Czy napewno zamknąć qBittorrent?</translation>
    </message>
    <message>
        <source>Alt+2</source>
        <comment>shortcut to switch to third tab</comment>
        <translation type="obsolete">Alt+2</translation>
    </message>
    <message>
        <source>Alt+3</source>
        <comment>shortcut to switch to fourth tab</comment>
        <translation type="obsolete">Alt+3</translation>
    </message>
    <message>
        <source>Global Upload Speed Limit</source>
        <translation type="obsolete">Ogólny limit wysyłania</translation>
    </message>
    <message>
        <source>Global Download Speed Limit</source>
        <translation type="obsolete">Ogólny limit pobierania</translation>
    </message>
    <message>
        <source>qBittorrent %1 (Down: %2/s, Up: %3/s)</source>
        <comment>%1 is qBittorrent version</comment>
        <translation type="obsolete">qBittorrent %1 (Pobieranie: %2/s, Wysyłanie: %3/s)</translation>
    </message>
    <message>
        <source>Recursive download confirmation</source>
        <translatorcomment>??</translatorcomment>
        <translation type="obsolete">Potwierdzenie pobierania rekursywnego</translation>
    </message>
    <message>
        <source>The torrent %1 contains torrent files, do you want to proceed with their download?</source>
        <translation type="obsolete">Torrent %1 zawiera pliki torrent, rozpocząć ich pobieranie?</translation>
    </message>
    <message>
        <source>Transfers (%1)</source>
        <translation type="obsolete">Transfery (%1)</translation>
    </message>
    <message>
        <source>Torrent file association</source>
        <translation type="obsolete">Powiązanie z plikami torrent</translation>
    </message>
    <message>
        <source>qBittorrent is not the default application to open torrent files or Magnet links.
Do you want to associate qBittorrent to torrent files and Magnet links?</source>
        <translation type="obsolete">qBittorrent nie jest domyślnym programem do obsługi plików torrent i linków Magnet.
Czy powiązać qBittorrent z plikami torrent i linkami Magnet?</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation type="obsolete">Tak</translation>
    </message>
    <message>
        <source>No</source>
        <translation type="obsolete">Nie</translation>
    </message>
    <message>
        <source>Never</source>
        <translation type="obsolete">Nigdy</translation>
    </message>
    <message>
        <source>Always</source>
        <translation type="obsolete">Zawsze</translation>
    </message>
    <message>
        <source>Exiting qBittorrent</source>
        <translation type="obsolete">Zamykanie qBittorrent</translation>
    </message>
    <message>
        <source>Set the password...</source>
        <translation type="obsolete">Ustaw hasło...</translation>
    </message>
    <message>
        <source>Password update</source>
        <translation type="obsolete">Aktualizacja hasła</translation>
    </message>
    <message>
        <source>Invalid password</source>
        <translation type="obsolete">Nieprawidłowe hasło</translation>
    </message>
    <message>
        <source>The password is invalid</source>
        <translation type="obsolete">Podane hasło jest nieprawidłowe</translation>
    </message>
    <message>
        <source>A newer version is available</source>
        <translation type="obsolete">Dostępna jest nowa wersja</translation>
    </message>
    <message>
        <source>A newer version of qBittorrent is available on Sourceforge.
Would you like to update qBittorrent to version %1?</source>
        <translation type="obsolete">Nowa wersja qBittorrenta jest dostępna na Sourceforge.
Czy chcesz zaktualizować program do wersji %1?</translation>
    </message>
    <message>
        <source>Impossible to update qBittorrent</source>
        <translation type="obsolete">Nie można zaktualizować qBittorrenta</translation>
    </message>
    <message>
        <source>qBittorrent failed to update, reason: %1</source>
        <translation type="obsolete">Aktualizacja qBittorrenta nie powiodła się, powód: %1</translation>
    </message>
</context>
<context>
    <name>GeoIP</name>
    <message>
        <source>Australia</source>
        <translation type="obsolete">Australia</translation>
    </message>
    <message>
        <source>Argentina</source>
        <translation type="obsolete">Argentyna</translation>
    </message>
    <message>
        <source>Austria</source>
        <translation type="obsolete">Austria</translation>
    </message>
    <message>
        <source>United Arab Emirates</source>
        <translation type="obsolete">Zjednoczone Emiraty Arabskie</translation>
    </message>
    <message>
        <source>Brazil</source>
        <translation type="obsolete">Brazylia</translation>
    </message>
    <message>
        <source>Bulgaria</source>
        <translation type="obsolete">Bułgaria</translation>
    </message>
    <message>
        <source>Belarus</source>
        <translation type="obsolete">Białoruś</translation>
    </message>
    <message>
        <source>Belgium</source>
        <translation type="obsolete">Belgia</translation>
    </message>
    <message>
        <source>Bosnia</source>
        <translation type="obsolete">Bośnia</translation>
    </message>
    <message>
        <source>Canada</source>
        <translation type="obsolete">Kanada</translation>
    </message>
    <message>
        <source>Czech Republic</source>
        <translation type="obsolete">Czechy</translation>
    </message>
    <message>
        <source>China</source>
        <translation type="obsolete">Chiny</translation>
    </message>
    <message>
        <source>Costa Rica</source>
        <translation type="obsolete">Kostaryka</translation>
    </message>
    <message>
        <source>Switzerland</source>
        <translation type="obsolete">Szwajcaria</translation>
    </message>
    <message>
        <source>Germany</source>
        <translation type="obsolete">Niemcy</translation>
    </message>
    <message>
        <source>Denmark</source>
        <translation type="obsolete">Dania</translation>
    </message>
    <message>
        <source>Algeria</source>
        <translation type="obsolete">Algeria</translation>
    </message>
    <message>
        <source>Spain</source>
        <translation type="obsolete">Hiszpania</translation>
    </message>
    <message>
        <source>Egypt</source>
        <translation type="obsolete">Egipt</translation>
    </message>
    <message>
        <source>Finland</source>
        <translation type="obsolete">Finlandia</translation>
    </message>
    <message>
        <source>France</source>
        <translation type="obsolete">Francja</translation>
    </message>
    <message>
        <source>United Kingdom</source>
        <translation type="obsolete">Wielka Brytania</translation>
    </message>
    <message>
        <source>Greece</source>
        <translation type="obsolete">Grecja</translation>
    </message>
    <message>
        <source>Georgia</source>
        <translation type="obsolete">Gruzja</translation>
    </message>
    <message>
        <source>Hungary</source>
        <translation type="obsolete">Węgry</translation>
    </message>
    <message>
        <source>Croatia</source>
        <translation type="obsolete">Chorwacja</translation>
    </message>
    <message>
        <source>Italy</source>
        <translation type="obsolete">Włochy</translation>
    </message>
    <message>
        <source>India</source>
        <translation type="obsolete">Indie</translation>
    </message>
    <message>
        <source>Israel</source>
        <translation type="obsolete">Izrael</translation>
    </message>
    <message>
        <source>Ireland</source>
        <translation type="obsolete">Irlandia</translation>
    </message>
    <message>
        <source>Iceland</source>
        <translation type="obsolete">Islandia</translation>
    </message>
    <message>
        <source>Indonesia</source>
        <translation type="obsolete">Indonezja</translation>
    </message>
    <message>
        <source>Japan</source>
        <translation type="obsolete">Japonia</translation>
    </message>
    <message>
        <source>South Korea</source>
        <translation type="obsolete">Korea Południowa</translation>
    </message>
    <message>
        <source>Luxembourg</source>
        <translation type="obsolete">Luksemburg</translation>
    </message>
    <message>
        <source>Malaysia</source>
        <translation type="obsolete">Malezja</translation>
    </message>
    <message>
        <source>Mexico</source>
        <translation type="obsolete">Meksyk</translation>
    </message>
    <message>
        <source>Serbia</source>
        <translation type="obsolete">Serbia</translation>
    </message>
    <message>
        <source>Morocco</source>
        <translation type="obsolete">Maroko</translation>
    </message>
    <message>
        <source>Netherlands</source>
        <translation type="obsolete">Holandia</translation>
    </message>
    <message>
        <source>Norway</source>
        <translation type="obsolete">Norwegia</translation>
    </message>
    <message>
        <source>New Zealand</source>
        <translation type="obsolete">Nowa Zelandia</translation>
    </message>
    <message>
        <source>Portugal</source>
        <translation type="obsolete">Portugalia</translation>
    </message>
    <message>
        <source>Poland</source>
        <translation type="obsolete">Polska</translation>
    </message>
    <message>
        <source>Pakistan</source>
        <translation type="obsolete">Pakistan</translation>
    </message>
    <message>
        <source>Philippines</source>
        <translation type="obsolete">Filipiny</translation>
    </message>
    <message>
        <source>Russia</source>
        <translation type="obsolete">Rosja</translation>
    </message>
    <message>
        <source>Romania</source>
        <translation type="obsolete">Rumunia</translation>
    </message>
    <message>
        <source>France (Reunion Island)</source>
        <translation type="obsolete">Francja</translation>
    </message>
    <message>
        <source>Sweden</source>
        <translation type="obsolete">Szwecja</translation>
    </message>
    <message>
        <source>Slovakia</source>
        <translation type="obsolete">Słowacja</translation>
    </message>
    <message>
        <source>Singapore</source>
        <translation type="obsolete">Singapur</translation>
    </message>
    <message>
        <source>Slovenia</source>
        <translation type="obsolete">Słowenia</translation>
    </message>
    <message>
        <source>Taiwan</source>
        <translation type="obsolete">Tajwan</translation>
    </message>
    <message>
        <source>Turkey</source>
        <translation type="obsolete">Turcja</translation>
    </message>
    <message>
        <source>Thailand</source>
        <translation type="obsolete">Tajlandia</translation>
    </message>
    <message>
        <source>USA</source>
        <translation type="obsolete">Stany Zjednoczone</translation>
    </message>
    <message>
        <source>Ukraine</source>
        <translation type="obsolete">Ukraina</translation>
    </message>
    <message>
        <source>South Africa</source>
        <translation type="obsolete">Republika Południowej Afryki</translation>
    </message>
    <message>
        <source>Saudi Arabia</source>
        <translation type="obsolete">Arabia Saudyjska</translation>
    </message>
</context>
<context>
    <name>HeadlessLoader</name>
    <message>
        <source>Information</source>
        <translation>Informacje</translation>
    </message>
    <message>
        <source>To control qBittorrent, access the Web UI at http://localhost:%1</source>
        <translation>Aby uzyskać dostęp do qBittorrent należy przejść w przeglądarce pod adres http://localhost:%1</translation>
    </message>
    <message>
        <source>The Web UI administrator user name is: %1</source>
        <translation>Nazwa administratora interfejsu www to: %1</translation>
    </message>
    <message>
        <source>The Web UI administrator password is still the default one: %1</source>
        <translation>Hasło administratora interfejsu www ustawione nadal na domyślne: %1</translation>
    </message>
    <message>
        <source>This is a security risk, please consider changing your password from program preferences.</source>
        <translation>Uwaga, z powodu bezpieczeństwa należy rozważyć zmianę hasła w ustawieniach programu.</translation>
    </message>
</context>
<context>
    <name>HttpConnection</name>
    <message>
        <source>Your IP address has been banned after too many failed authentication attempts.</source>
        <translation>Twój adres IP został zablokowany po zbyt wielu nieudanych próbach uwierzytelnienia.</translation>
    </message>
    <message>
        <source>D: %1/s - T: %2</source>
        <comment>Download speed: x KiB/s - Transferred: x MiB</comment>
        <translation>Pobieranie: %1/s - Pobrano: %2</translation>
    </message>
    <message>
        <source>U: %1/s - T: %2</source>
        <comment>Upload speed: x KiB/s - Transferred: x MiB</comment>
        <translation>Wysyłanie: %1/s - Wysłano: %2</translation>
    </message>
</context>
<context>
    <name>HttpServer</name>
    <message>
        <source>File</source>
        <translation>Plik</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Edycja</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Pomoc</translation>
    </message>
    <message>
        <source>Delete from HD</source>
        <translation type="obsolete">Usuń z dysku twardego</translation>
    </message>
    <message>
        <source>Download Torrents from their URL or Magnet link</source>
        <translation>Pobierz pliki torrent z adresu www lub magnet</translation>
    </message>
    <message>
        <source>Only one link per line</source>
        <translation>Można podać tylko jeden adres www w jednej linii</translation>
    </message>
    <message>
        <source>Download</source>
        <translation>Pobierz</translation>
    </message>
    <message>
        <source>Download local torrent</source>
        <translation>Pobierz pliki torrent z dysku twardego</translation>
    </message>
    <message>
        <source>Torrent files were correctly added to download list.</source>
        <translation>Pliki torrent poprawnie dodane do listy pobierania.</translation>
    </message>
    <message>
        <source>Point to torrent file</source>
        <translation>Ścieżka do pliku torrent</translation>
    </message>
    <message>
        <source>Are you sure you want to delete the selected torrents from the transfer list and hard disk?</source>
        <translation>Czy na pewno usunąć wybrane pliki torrent z listy transferów i z twardego dysku?</translation>
    </message>
    <message>
        <source>Download rate limit must be greater than 0 or disabled.</source>
        <translation>Limit prędkości pobierania musi być większy od 0 lub wyłączony.</translation>
    </message>
    <message>
        <source>Upload rate limit must be greater than 0 or disabled.</source>
        <translation>Limit prędkości wysyłania musi być większy od 0 lub wyłączony.</translation>
    </message>
    <message>
        <source>Maximum number of connections limit must be greater than 0 or disabled.</source>
        <translation>Limit połączeń musi być większy od 0 lub wyłączony.</translation>
    </message>
    <message>
        <source>Maximum number of connections per torrent limit must be greater than 0 or disabled.</source>
        <translation>Limit połączeń dla pliku torrent musi być większy od 0 lub wyłączony.</translation>
    </message>
    <message>
        <source>Maximum number of upload slots per torrent limit must be greater than 0 or disabled.</source>
        <translation>Limit slotów wysyłania dla pliku torrent musi być większy od 0 lub wyłączony.</translation>
    </message>
    <message>
        <source>Unable to save program preferences, qBittorrent is probably unreachable.</source>
        <translation>Nie można zapisać ustawień, prawdopodobnie qBittorrent jest nieosiągalny.</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Język</translation>
    </message>
    <message>
        <source>The port used for incoming connections must be greater than 1024 and less than 65535.</source>
        <translation>Port na którym nasłuchiwane są połączenia przychodzące musi zawierać się w zakresie 1024 - 65535.</translation>
    </message>
    <message>
        <source>The port used for the Web UI must be greater than 1024 and less than 65535.</source>
        <translation>Port na którym działa interfejs www musi zawierać się w zakresie 1024 - 65535.</translation>
    </message>
    <message>
        <source>The Web UI username must be at least 3 characters long.</source>
        <translation>Nazwa użytkownika interfejsu www musi składać się z co najmniej 3 znaków.</translation>
    </message>
    <message>
        <source>The Web UI password must be at least 3 characters long.</source>
        <translation>Hasło użytkownika interfejsu www musi składać się z co najmniej 3 znaków.</translation>
    </message>
    <message>
        <source>Downloaded</source>
        <comment>Is the file downloaded or not?</comment>
        <translation type="unfinished">Pobrany</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="unfinished">Zapisz</translation>
    </message>
    <message>
        <source>qBittorrent client is not reachable</source>
        <translation>Klient qBittorrent jest nieosiągalny</translation>
    </message>
    <message>
        <source>HTTP Server</source>
        <translation type="unfinished">Serwer www</translation>
    </message>
    <message>
        <source>Torrent path</source>
        <translation type="unfinished">Ścieżka torrenta</translation>
    </message>
    <message>
        <source>Torrent name</source>
        <translation type="unfinished">Nazwa torrenta</translation>
    </message>
    <message>
        <source>The following parameters are supported:</source>
        <translation>Obsługiwane są poniższe parametry:</translation>
    </message>
</context>
<context>
    <name>LegalNotice</name>
    <message>
        <source>Legal Notice</source>
        <translation>Nota prawna</translation>
    </message>
    <message>
        <source>Legal notice</source>
        <translation>Nota prawna</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Anuluj</translation>
    </message>
    <message>
        <source>I Agree</source>
        <translation>Zgadzam się</translation>
    </message>
    <message>
        <source>qBittorrent is a file sharing program. When you run a torrent, its data will be made available to others by means of upload. Any content you share is your sole responsibility.

No further notices will be issued.</source>
        <translation>qBittorrent jest programem do wymiany plików. Uruchomienie torrenta powoduje, że jego zawartość jest dostępna dla innych. Użytkownik ponosi pełną odpowiedzialność za udostępniane treści.

W przyszłości powiadomienie nie będzie wyświetlane.</translation>
    </message>
    <message>
        <source>Press %1 key to accept and continue...</source>
        <translation>Nacisnij klawisz %1 aby zaakceptować i kontynuować...</translation>
    </message>
</context>
<context>
    <name>LineEdit</name>
    <message>
        <source>Clear the text</source>
        <translation>Wyczyść tekst</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>&amp;Edit</source>
        <translation>&amp;Edycja</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>P&amp;lik</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Pomoc</translation>
    </message>
    <message>
        <source>Preview file</source>
        <translation type="obsolete">Podgląd pliku</translation>
    </message>
    <message>
        <source>Clear log</source>
        <translation type="obsolete">Wyczyść dziennik</translation>
    </message>
    <message>
        <source>Decrease priority</source>
        <translation>Zmniejsz priorytet</translation>
    </message>
    <message>
        <source>Increase priority</source>
        <translation>Zwiększ priorytet</translation>
    </message>
    <message>
        <source>&amp;Tools</source>
        <translation>&amp;Narzędzia</translation>
    </message>
    <message>
        <source>&amp;View</source>
        <translation>&amp;Widok</translation>
    </message>
    <message>
        <source>&amp;Add File...</source>
        <translation type="obsolete">&amp;Otwórz plik...</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation type="obsolete">&amp;Zakończ</translation>
    </message>
    <message>
        <source>&amp;Options...</source>
        <translation>&amp;Opcje...</translation>
    </message>
    <message>
        <source>Add &amp;URL...</source>
        <translation type="obsolete">Dodaj &amp;URL...</translation>
    </message>
    <message>
        <source>Torrent &amp;creator</source>
        <translation>Kreator plików torre&amp;nt</translation>
    </message>
    <message>
        <source>Set upload limit...</source>
        <translation>Ustaw limit wysyłania...</translation>
    </message>
    <message>
        <source>Set download limit...</source>
        <translation>Ustaw limit pobierania...</translation>
    </message>
    <message>
        <source>Set global download limit...</source>
        <translation>Ustaw ogólny limit pobierania...</translation>
    </message>
    <message>
        <source>Set global upload limit...</source>
        <translation>Ustaw ogólny limit wysyłania...</translation>
    </message>
    <message>
        <source>&amp;Log viewer...</source>
        <translation type="obsolete">Przeg&amp;lądanie dziennika...</translation>
    </message>
    <message>
        <source>Top &amp;tool bar</source>
        <translation>&amp;Górny pasek narzędziowy</translation>
    </message>
    <message>
        <source>Display top tool bar</source>
        <translation>Pokaż górny pasek narzędziowy</translation>
    </message>
    <message>
        <source>&amp;Speed in title bar</source>
        <translation>&amp;Prędkość na pasku tytułu</translation>
    </message>
    <message>
        <source>Show transfer speed in title bar</source>
        <translation>Pokaż prędkość na pasku tytułu</translation>
    </message>
    <message>
        <source>Alternative speed limits</source>
        <translation>Alternatywne limity prędkości</translation>
    </message>
    <message>
        <source>&amp;About</source>
        <translation>&amp;O programie</translation>
    </message>
    <message>
        <source>&amp;Pause</source>
        <translation>&amp;Wstrzymaj</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>U&amp;suń</translation>
    </message>
    <message>
        <source>P&amp;ause All</source>
        <translation>Ws&amp;trzymaj wszystkie</translation>
    </message>
    <message>
        <source>Visit &amp;Website</source>
        <translation>Od&amp;wiedź stronę</translation>
    </message>
    <message>
        <source>Report a &amp;bug</source>
        <translation>Zgłoś &amp;błąd</translation>
    </message>
    <message>
        <source>&amp;Documentation</source>
        <translation>&amp;Dokumentacja</translation>
    </message>
    <message>
        <source>&amp;RSS reader</source>
        <translation>Czytnik &amp;RSS</translation>
    </message>
    <message>
        <source>Search &amp;engine</source>
        <translation>Wy&amp;szukiwarka</translation>
    </message>
    <message>
        <source>Log viewer</source>
        <translation type="obsolete">Przeglądarka dziennika</translation>
    </message>
    <message>
        <source>Lock qBittorrent</source>
        <translation>Zablokuj qBittorrent</translation>
    </message>
    <message>
        <source>Ctrl+L</source>
        <translation>Ctrl+L</translation>
    </message>
    <message>
        <source>Shutdown computer when downloads complete</source>
        <translation type="obsolete">Wyłącz komputer po zakończeniu pobierań</translation>
    </message>
    <message>
        <source>&amp;Resume</source>
        <translation>W&amp;znów</translation>
    </message>
    <message>
        <source>R&amp;esume All</source>
        <translation>Wznów wszystki&amp;e</translation>
    </message>
    <message>
        <source>Shutdown qBittorrent when downloads complete</source>
        <translation type="obsolete">Zamknij qBittorrent po zakończeniu pobierań</translation>
    </message>
    <message>
        <source>Exit</source>
        <translation>Zakończ</translation>
    </message>
    <message>
        <source>Import torrent...</source>
        <translation>Importuj plik...</translation>
    </message>
    <message>
        <source>Donate money</source>
        <translation>Przekaż pieniądze</translation>
    </message>
    <message>
        <source>If you like qBittorrent, please donate!</source>
        <translation>Jeśli lubisz qBittorrent, przekaż pieniądze!</translation>
    </message>
    <message>
        <source>qBittorrent %1</source>
        <comment>e.g: qBittorrent v0.x</comment>
        <translation>qBittorrent %1</translation>
    </message>
    <message>
        <source>Set the password...</source>
        <translation>Ustaw hasło...</translation>
    </message>
    <message>
        <source>Transfers</source>
        <translation>Transfery</translation>
    </message>
    <message>
        <source>Torrent file association</source>
        <translation>Powiązanie z plikami torrent</translation>
    </message>
    <message>
        <source>qBittorrent is not the default application to open torrent files or Magnet links.
Do you want to associate qBittorrent to torrent files and Magnet links?</source>
        <translation>qBittorrent nie jest domyślnym programem do obsługi plików torrent i linków Magnet.
Czy powiązać qBittorrent z plikami torrent i linkami Magnet?</translation>
    </message>
    <message>
        <source>UI lock password</source>
        <translation>Hasło blokady interfejsu</translation>
    </message>
    <message>
        <source>Please type the UI lock password:</source>
        <translation>Proszę podać hasło blokady interfejsu:</translation>
    </message>
    <message>
        <source>Password update</source>
        <translation>Aktualizacja hasła</translation>
    </message>
    <message>
        <source>The UI lock password has been successfully updated</source>
        <translation>Pomyślnie zaktualizowano hasło blokady interfejsu</translation>
    </message>
    <message>
        <source>RSS</source>
        <translation>RSS</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Szukaj</translation>
    </message>
    <message>
        <source>Transfers (%1)</source>
        <translation>Transfery (%1)</translation>
    </message>
    <message>
        <source>Download completion</source>
        <translation>Zakończono pobieranie</translation>
    </message>
    <message>
        <source>%1 has finished downloading.</source>
        <comment>e.g: xxx.avi has finished downloading.</comment>
        <translation>%1 został pobrany.</translation>
    </message>
    <message>
        <source>I/O Error</source>
        <comment>i.e: Input/Output Error</comment>
        <translation>Błąd We/Wy</translation>
    </message>
    <message>
        <source>An I/O error occured for torrent %1.
 Reason: %2</source>
        <comment>e.g: An error occured for torrent xxx.avi.
 Reason: disk is full.</comment>
        <translation>Wystąpił błąd We/Wy dla pliku torrent %1.
Powód: %2</translation>
    </message>
    <message>
        <source>Alt+1</source>
        <comment>shortcut to switch to first tab</comment>
        <translation>Alt+1</translation>
    </message>
    <message>
        <source>Alt+2</source>
        <comment>shortcut to switch to third tab</comment>
        <translation>Alt+2</translation>
    </message>
    <message>
        <source>Ctrl+F</source>
        <comment>shortcut to switch to search tab</comment>
        <translation>Ctrl+F</translation>
    </message>
    <message>
        <source>Alt+3</source>
        <comment>shortcut to switch to fourth tab</comment>
        <translation>Alt+3</translation>
    </message>
    <message>
        <source>Recursive download confirmation</source>
        <translation>Potwierdzenie pobierania rekurencyjnego</translation>
    </message>
    <message>
        <source>The torrent %1 contains torrent files, do you want to proceed with their download?</source>
        <translation>Torrent %1 zawiera pliki torrent, rozpocząć ich pobieranie?</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Tak</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Nie</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Nigdy</translation>
    </message>
    <message>
        <source>Url download error</source>
        <translation>Błąd pobierania adresu</translation>
    </message>
    <message>
        <source>Couldn&apos;t download file at url: %1, reason: %2.</source>
        <translation>Nie można pobrać pliku z url: %1, powód: %2.</translation>
    </message>
    <message>
        <source>Global Upload Speed Limit</source>
        <translation>Ogólny limit wysyłania</translation>
    </message>
    <message>
        <source>Global Download Speed Limit</source>
        <translation>Ogólny limit pobierania</translation>
    </message>
    <message>
        <source>Invalid password</source>
        <translation>Nieprawidłowe hasło</translation>
    </message>
    <message>
        <source>The password is invalid</source>
        <translation>Podane hasło jest nieprawidłowe</translation>
    </message>
    <message>
        <source>Exiting qBittorrent</source>
        <translation>Zamykanie qBittorrent</translation>
    </message>
    <message>
        <source>Some files are currently transferring.
Are you sure you want to quit qBittorrent?</source>
        <translation>Aktualnie trwa pobieranie plików.
Czy na pewno zamknąć qBittorrent?</translation>
    </message>
    <message>
        <source>Always</source>
        <translation>Zawsze</translation>
    </message>
    <message>
        <source>Open Torrent Files</source>
        <translation>Otwórz pliki torrent</translation>
    </message>
    <message>
        <source>Torrent Files</source>
        <translation>Pliki .torrent</translation>
    </message>
    <message>
        <source>Options were saved successfully.</source>
        <translation>Ustawienia pomyślnie zapisane.</translation>
    </message>
    <message>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <source>DL speed: %1 KiB/s</source>
        <comment>e.g: Download speed: 10 KiB/s</comment>
        <translation>Pobieranie: %1 KiB/s</translation>
    </message>
    <message>
        <source>UP speed: %1 KiB/s</source>
        <comment>e.g: Upload speed: 10 KiB/s</comment>
        <translation>Wysyłanie: %1 KiB/</translation>
    </message>
    <message>
        <source>qBittorrent %1 (Down: %2/s, Up: %3/s)</source>
        <comment>%1 is qBittorrent version</comment>
        <translation>qBittorrent %1 (Pobieranie: %2/s, Wysyłanie: %3/s)</translation>
    </message>
    <message>
        <source>A newer version is available</source>
        <translation>Dostępna jest nowa wersja</translation>
    </message>
    <message>
        <source>A newer version of qBittorrent is available on Sourceforge.
Would you like to update qBittorrent to version %1?</source>
        <translation>Nowa wersja qBittorrent jest dostępna na Sourceforge.
Czy chcesz zaktualizować program do wersji %1?</translation>
    </message>
    <message>
        <source>Impossible to update qBittorrent</source>
        <translation>Nie można zaktualizować qBittorrent</translation>
    </message>
    <message>
        <source>qBittorrent failed to update, reason: %1</source>
        <translation>Aktualizacja qBittorrent nie powiodła się, powód: %1</translation>
    </message>
    <message>
        <source>&amp;Add torrent file...</source>
        <translation>&amp;Otwórz plik torrent...</translation>
    </message>
    <message>
        <source>Add &amp;link to torrent...</source>
        <translation>&amp;Dodaj odnośnik do pliku torrent...</translation>
    </message>
    <message>
        <source>Import existing torrent...</source>
        <translation>Importuj plik torrent...</translation>
    </message>
    <message>
        <source>Execution &amp;Log</source>
        <translation>&amp;Dziennik programu</translation>
    </message>
    <message>
        <source>Execution Log</source>
        <translation>Dziennik programu</translation>
    </message>
    <message>
        <source>Auto-Shutdown on downloads completion</source>
        <translation type="unfinished">Zamykanie po ukończeniu pobierania</translation>
    </message>
    <message>
        <source>Exit qBittorrent</source>
        <translation>Zakończ qBittorrent</translation>
    </message>
    <message>
        <source>Suspend system</source>
        <translation type="unfinished">Wstrzymaj system</translation>
    </message>
    <message>
        <source>Shutdown system</source>
        <translation type="unfinished">Zamknij system</translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Wyłączone</translation>
    </message>
    <message>
        <source>The password should contain at least 3 characters</source>
        <translation>Hasło powinno zawierać przynajmniej 3 znaki</translation>
    </message>
</context>
<context>
    <name>PeerAdditionDlg</name>
    <message>
        <source>Invalid IP</source>
        <translation>Niepoprawny adres IP</translation>
    </message>
    <message>
        <source>The IP you provided is invalid.</source>
        <translation>Wprowadzony adres IP jest niepoprawny.</translation>
    </message>
</context>
<context>
    <name>PeerListDelegate</name>
    <message>
        <source>/s</source>
        <comment>/second (i.e. per second)</comment>
        <translation>/s</translation>
    </message>
</context>
<context>
    <name>PeerListWidget</name>
    <message>
        <source>IP</source>
        <translation>Adres IP</translation>
    </message>
    <message>
        <source>Client</source>
        <comment>i.e.: Client application</comment>
        <translation>Klient</translation>
    </message>
    <message>
        <source>Progress</source>
        <comment>i.e: % downloaded</comment>
        <translation>Postęp</translation>
    </message>
    <message>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Pobieranie</translation>
    </message>
    <message>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Wysyłanie</translation>
    </message>
    <message>
        <source>Downloaded</source>
        <comment>i.e: total data downloaded</comment>
        <translation>Pobrano</translation>
    </message>
    <message>
        <source>Uploaded</source>
        <comment>i.e: total data uploaded</comment>
        <translation>Wysłano</translation>
    </message>
    <message>
        <source>Ban peer permanently</source>
        <translation>Blokuj parnera na stałe</translation>
    </message>
    <message>
        <source>Peer addition</source>
        <translation>Dodawanie partnera</translation>
    </message>
    <message>
        <source>The peer was added to this torrent.</source>
        <translation>Dodano partnera dla tego torrenta.</translation>
    </message>
    <message>
        <source>The peer could not be added to this torrent.</source>
        <translation>Nie można dodać partnera dla tego torrenta.</translation>
    </message>
    <message>
        <source>Are you sure? -- qBittorrent</source>
        <translation>Czy na pewno? -- qBittorrent</translation>
    </message>
    <message>
        <source>Are you sure you want to ban permanently the selected peers?</source>
        <translation>Czy na pewno zablokować na stałe wybranych partnerów?</translation>
    </message>
    <message>
        <source>&amp;Yes</source>
        <translation>&amp;Tak</translation>
    </message>
    <message>
        <source>&amp;No</source>
        <translation>&amp;Nie</translation>
    </message>
    <message>
        <source>Manually banning peer %1...</source>
        <translation>Ręczne blokowanie partnera %1...</translation>
    </message>
    <message>
        <source>Upload rate limiting</source>
        <translation>Ograniczanie prędkości wysyłania</translation>
    </message>
    <message>
        <source>Download rate limiting</source>
        <translation>Ograniczanie prędkości pobierania</translation>
    </message>
    <message>
        <source>Add a new peer...</source>
        <translation>Dodaj partnera...</translation>
    </message>
    <message>
        <source>Limit download rate...</source>
        <translation>Ogranicz prędkości pobierania...</translation>
    </message>
    <message>
        <source>Limit upload rate...</source>
        <translation>Ogranicz prędkości wysyłania...</translation>
    </message>
    <message>
        <source>Copy IP</source>
        <translation>Kopiuj adres IP</translation>
    </message>
    <message>
        <source>Connection</source>
        <translation>Połączenie</translation>
    </message>
</context>
<context>
    <name>Preferences</name>
    <message>
        <source>UI</source>
        <extracomment>User Interface</extracomment>
        <translation type="obsolete">Wygląd</translation>
    </message>
    <message>
        <source>Downloads</source>
        <translation>Pobieranie</translation>
    </message>
    <message>
        <source>Connection</source>
        <translation>Połączenie</translation>
    </message>
    <message>
        <source>Bittorrent</source>
        <translation type="obsolete">Bittorrent</translation>
    </message>
    <message>
        <source>Proxy</source>
        <translation type="obsolete">Proxy</translation>
    </message>
    <message>
        <source>Web UI</source>
        <translation>Interfejs www</translation>
    </message>
    <message>
        <source>Language:</source>
        <translation type="obsolete">Język:</translation>
    </message>
    <message>
        <source>(Requires restart)</source>
        <translation>(Wymaga ponownego uruchomienia)</translation>
    </message>
    <message>
        <source>Visual style:</source>
        <translation type="obsolete">Styl wizualny:</translation>
    </message>
    <message>
        <source>Transfer list</source>
        <translation type="obsolete">Lista transferów</translation>
    </message>
    <message>
        <source>Use alternating row colors</source>
        <extracomment>In transfer list, one every two rows will have grey background.</extracomment>
        <translation>Alternatywne kolorowanie wierszy</translation>
    </message>
    <message>
        <source>File system</source>
        <translation type="obsolete">Katalogi</translation>
    </message>
    <message>
        <source>Torrent queueing</source>
        <translation type="obsolete">Kolejkowanie torrentów</translation>
    </message>
    <message>
        <source>Maximum active downloads:</source>
        <translation>Maksymalna liczba aktywnych pobierań:</translation>
    </message>
    <message>
        <source>Maximum active uploads:</source>
        <translation>Maksymalna liczba aktywnych wysyłań:</translation>
    </message>
    <message>
        <source>Maximum active torrents:</source>
        <translation>Maksymalna liczba aktywnych torrentów:</translation>
    </message>
    <message>
        <source>When adding a torrent</source>
        <translation>Podczas dodawania torrenta</translation>
    </message>
    <message>
        <source>Display torrent content and some options</source>
        <translation>Pokaż zawartość torrenta i kilka opcji</translation>
    </message>
    <message>
        <source>Listening port</source>
        <translation type="obsolete">Port nasłuchu</translation>
    </message>
    <message>
        <source>Port used for incoming connections:</source>
        <translation>Port dla połączeń przychodzących:</translation>
    </message>
    <message>
        <source>Random</source>
        <translation>Losowy</translation>
    </message>
    <message>
        <source>Enable UPnP port mapping</source>
        <translation type="obsolete">Włącz mapowanie portu UPnP</translation>
    </message>
    <message>
        <source>Enable NAT-PMP port mapping</source>
        <translation type="obsolete">Włącz mapowanie portu NAT-PMP</translation>
    </message>
    <message>
        <source>Connections limit</source>
        <translation type="obsolete">Limit połączeń</translation>
    </message>
    <message>
        <source>Global maximum number of connections:</source>
        <translation>Maksymalna liczba połączeń:</translation>
    </message>
    <message>
        <source>Maximum number of connections per torrent:</source>
        <translation>Maksymalna liczba połączeń na torrent:</translation>
    </message>
    <message>
        <source>Maximum number of upload slots per torrent:</source>
        <translation>Maksymalna liczba slotów wysyłania na torrent:</translation>
    </message>
    <message>
        <source>Upload:</source>
        <translation>Wysyłanie:</translation>
    </message>
    <message>
        <source>Download:</source>
        <translation>Pobieranie:</translation>
    </message>
    <message>
        <source>KiB/s</source>
        <translation>KiB/s</translation>
    </message>
    <message>
        <source>Bittorrent features</source>
        <translation type="obsolete">Ustawienia bittorrent</translation>
    </message>
    <message>
        <source>Enable DHT network (decentralized)</source>
        <translation type="obsolete">Włącz sieć DHT (rozproszona)</translation>
    </message>
    <message>
        <source>Use a different port for DHT and Bittorrent</source>
        <translation type="obsolete">Używa innego portu dla DHT i bittorrent</translation>
    </message>
    <message>
        <source>DHT port:</source>
        <translation>Port DHT:</translation>
    </message>
    <message>
        <source>Enable Peer Exchange / PeX (requires restart)</source>
        <translation type="obsolete">Włącz Peer eXchange / (PeX) (wymaga ponownego uruchomienia)</translation>
    </message>
    <message>
        <source>Enable Local Peer Discovery</source>
        <translation type="obsolete">Włącz Local Peer Discovery</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation type="obsolete">Włączone</translation>
    </message>
    <message>
        <source>Forced</source>
        <translation type="obsolete">Wymuszone</translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation type="obsolete">Wyłączone</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation>Typ:</translation>
    </message>
    <message>
        <source>(None)</source>
        <translation>(Żaden)</translation>
    </message>
    <message>
        <source>HTTP</source>
        <translation>HTTP</translation>
    </message>
    <message>
        <source>Port:</source>
        <translation>Port:</translation>
    </message>
    <message>
        <source>Authentication</source>
        <translation>Uwierzytelnianie</translation>
    </message>
    <message>
        <source>Username:</source>
        <translation>Nazwa użytkownika:</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation>Hasło:</translation>
    </message>
    <message>
        <source>SOCKS5</source>
        <translation>SOCKS5</translation>
    </message>
    <message>
        <source>HTTP Server</source>
        <translation type="obsolete">Serwer www</translation>
    </message>
    <message>
        <source>Filter path (.dat, .p2p, .p2b):</source>
        <translation>Ścieżka do pliku filtra (.dat, .p2p, .p2b):</translation>
    </message>
    <message>
        <source>HTTP Communications (trackers, Web seeds, search engine)</source>
        <translation type="obsolete">Połączenia HTTP (trackery, seedy www, wtyczki wyszukiwania)</translation>
    </message>
    <message>
        <source>Host:</source>
        <translation>Host:</translation>
    </message>
    <message>
        <source>Peer Communications</source>
        <translation type="obsolete">Połączenia z partnerami</translation>
    </message>
    <message>
        <source>SOCKS4</source>
        <translation>SOCKS4</translation>
    </message>
    <message>
        <source>Speed</source>
        <translation>Prędkość</translation>
    </message>
    <message>
        <source>Global speed limits</source>
        <translation type="obsolete">Ogólne limity prędkości</translation>
    </message>
    <message>
        <source>Alternative global speed limits</source>
        <translation type="obsolete">Alternatywne ogólne limity prędkości</translation>
    </message>
    <message>
        <source>to</source>
        <extracomment>time1 to time2</extracomment>
        <translation>do</translation>
    </message>
    <message>
        <source>Every day</source>
        <translation>codziennie</translation>
    </message>
    <message>
        <source>Week days</source>
        <translation>dni robocze</translation>
    </message>
    <message>
        <source>Week ends</source>
        <translation>weekendy</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Zaawansowane</translation>
    </message>
    <message>
        <source>Copy .torrent files to:</source>
        <translation>Kopiuj pliki .torrent do:</translation>
    </message>
    <message>
        <source>Remove folder</source>
        <translation>Usuń katalog</translation>
    </message>
    <message>
        <source>No action</source>
        <translation>Nie rób nic</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>Opcje</translation>
    </message>
    <message>
        <source>Visual Appearance</source>
        <translation type="obsolete">Wygląd</translation>
    </message>
    <message>
        <source>Action on double-click</source>
        <translation>Podwójne kliknięcie</translation>
    </message>
    <message>
        <source>Downloading torrents:</source>
        <translation>na liście pobieranych:</translation>
    </message>
    <message>
        <source>Start / Stop</source>
        <translation type="obsolete">Uruchom/Zatrzymaj</translation>
    </message>
    <message>
        <source>Open destination folder</source>
        <translation>Otwórz katalog pobierań</translation>
    </message>
    <message>
        <source>Completed torrents:</source>
        <translation>na liście ukończonych:</translation>
    </message>
    <message>
        <source>Desktop</source>
        <translation>Pulpit</translation>
    </message>
    <message>
        <source>Show splash screen on start up</source>
        <translation>Pokazuj ekran startowy</translation>
    </message>
    <message>
        <source>Start qBittorrent minimized</source>
        <translation>Uruchamiaj qBittorrent zminimalizowany</translation>
    </message>
    <message>
        <source>Show qBittorrent icon in notification area</source>
        <translation type="obsolete">Pokazuj ikonę qBittorrent w obszarze powiadomień</translation>
    </message>
    <message>
        <source>Minimize qBittorrent to notification area</source>
        <translation>Minimalizuj qBittorrent do obszaru powiadomień</translation>
    </message>
    <message>
        <source>Close qBittorrent to notification area</source>
        <comment>i.e: The systray tray icon will still be visible when closing the main window.</comment>
        <translation>Zamykaj qBittorrent do obszaru powiadomień</translation>
    </message>
    <message>
        <source>Do not start the download automatically</source>
        <comment>The torrent will be added to download list in pause state</comment>
        <translation>Nie uruchamiaj automatycznie pobierań</translation>
    </message>
    <message>
        <source>Save files to location:</source>
        <translation>Domyślny katalog zapisywanych plików:</translation>
    </message>
    <message>
        <source>Append the label of the torrent to the save path</source>
        <translation>Dodaj etykietę torrenta do nazwy katalogu</translation>
    </message>
    <message>
        <source>Pre-allocate disk space for all files</source>
        <translation>Rezerwuj miejsce na dysku dla wszystkich plików</translation>
    </message>
    <message>
        <source>Keep incomplete torrents in:</source>
        <translation>Przechowuj niekompletne torrenty w:</translation>
    </message>
    <message>
        <source>Append .!qB extension to incomplete files&apos; names</source>
        <translation type="obsolete">Dodaj rozszerzenie .!qB do niekompletnych plików</translation>
    </message>
    <message>
        <source>Automatically add torrents from:</source>
        <translation>Automatyczne pobieranie plików torrent z katalogu:</translation>
    </message>
    <message>
        <source>Add folder...</source>
        <translation>Dodaj katalog...</translation>
    </message>
    <message>
        <source>IP Filtering</source>
        <translation>Filtrowanie IP</translation>
    </message>
    <message>
        <source>Schedule the use of alternative speed limits</source>
        <translation type="obsolete">Harmonogram użycia alternatywnych limitów prędkości</translation>
    </message>
    <message>
        <source>from</source>
        <extracomment>from (time1 to time2)</extracomment>
        <translation>od</translation>
    </message>
    <message>
        <source>When:</source>
        <translation>kiedy:</translation>
    </message>
    <message>
        <source>Look for peers on your local network</source>
        <translation>Wyszukiwanie partnerów w sieci lokalnej</translation>
    </message>
    <message>
        <source>Protocol encryption:</source>
        <translation type="obsolete">Szyfrowanie protokołu:</translation>
    </message>
    <message>
        <source>Enable Web User Interface (Remote control)</source>
        <translation>Włącz interfejs www (Zdalne zarządzanie)</translation>
    </message>
    <message>
        <source>Share ratio limiting</source>
        <translation type="obsolete">Ograniczenie współczynnika udziału</translation>
    </message>
    <message>
        <source>Seed torrents until their ratio reaches</source>
        <translation>Wysyłaj do czasu aż współczynnik udziału osiągnie</translation>
    </message>
    <message>
        <source>then</source>
        <translation>następnie</translation>
    </message>
    <message>
        <source>Pause them</source>
        <translation>Wstrzymaj</translation>
    </message>
    <message>
        <source>Remove them</source>
        <translation>Usuń</translation>
    </message>
    <message utf8="true">
        <source>Exchange peers with compatible Bittorrent clients (µTorrent, Vuze, ...)</source>
        <translation>Wymiana partnerów pomiędzy kompatybilnymi klientami sieci Bittorrent (µTorrent, Vuze, ...)</translation>
    </message>
    <message>
        <source>Email notification upon download completion</source>
        <translation>Wyślij e-mail po ukończeniu pobierania</translation>
    </message>
    <message>
        <source>Destination email:</source>
        <translation>Adres e-mail:</translation>
    </message>
    <message>
        <source>SMTP server:</source>
        <translation>Serwer SMTP:</translation>
    </message>
    <message>
        <source>Run an external program on torrent completion</source>
        <translation>Uruchom zewnętrzny program po ukończeniu pobierania</translation>
    </message>
    <message>
        <source>Use %f to pass the torrent path in parameters</source>
        <translation type="obsolete">Użyj %f w celu przekazania ścieżki torrenta jako parametru</translation>
    </message>
    <message>
        <source>Proxy server</source>
        <translation type="obsolete">Serwer proxy</translation>
    </message>
    <message>
        <source>BitTorrent</source>
        <translation>BitTorrent</translation>
    </message>
    <message>
        <source>Start / Stop Torrent</source>
        <translation>Wznów / Wstrzymaj pobieranie</translation>
    </message>
    <message>
        <source>Use UPnP / NAT-PMP port forwarding from my router</source>
        <translation>Używaj UPnP / NAT-PMP do przekierowania portów na routerze</translation>
    </message>
    <message>
        <source>Privacy</source>
        <translation>Ochrona prywatności</translation>
    </message>
    <message>
        <source>Enable DHT (decentralized network) to find more peers</source>
        <translation>Włącz sieć DHT (sieć rozproszona) w celu odnajdywania partnerów</translation>
    </message>
    <message>
        <source>Use a different port for DHT and BitTorrent</source>
        <translation>Używaj innego portu dla DHT i BitTorrent</translation>
    </message>
    <message>
        <source>Enable Peer Exchange (PeX) to find more peers</source>
        <translation>Włącz wymianę partnerów (PeX)</translation>
    </message>
    <message>
        <source>Enable Local Peer Discovery to find more peers</source>
        <translation>Włącz wykrywanie partnerów w sieci lokalnej (LPD)</translation>
    </message>
    <message>
        <source>Encryption mode:</source>
        <translation>Tryb szyfrowania:</translation>
    </message>
    <message>
        <source>Prefer encryption</source>
        <translation>Preferuj szyfrowanie</translation>
    </message>
    <message>
        <source>Require encryption</source>
        <translation>Wymagaj szyfrowania</translation>
    </message>
    <message>
        <source>Disable encryption</source>
        <translation>Wyłącz szyfrowanie</translation>
    </message>
    <message>
        <source>User Interface</source>
        <translation type="obsolete">Interfejs użytkownika</translation>
    </message>
    <message>
        <source>Reload the filter</source>
        <translation>Przeładuj filtr</translation>
    </message>
    <message>
        <source>Behavior</source>
        <translation>Zachowanie</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Język</translation>
    </message>
    <message>
        <source>Power Management</source>
        <translation>Zarządzanie energią</translation>
    </message>
    <message>
        <source>Inhibit system sleep when torrents are active</source>
        <translation type="unfinished">Nie pozwalaj na usypianie systemu gdy są aktywne torrenty</translation>
    </message>
    <message>
        <source>Bypass authentication for localhost</source>
        <translation>Pomiń uwierzytelnianie dla lokalnego hosta</translation>
    </message>
    <message>
        <source>Ask for program exit confirmation</source>
        <translation type="unfinished">Pytaj o potwierdzenie przy wyjściu</translation>
    </message>
    <message>
        <source>The following parameters are supported:
&lt;ul&gt;
&lt;li&gt;%f: Torrent path&lt;/li&gt;
&lt;li&gt;%n: Torrent name&lt;/li&gt;
&lt;/ul&gt;</source>
        <translation>Obsługiwane są poniższe parametry:
&lt;ul&gt;
&lt;li&gt;%f: ścieżka torrenta&lt;/li&gt;
&lt;li&gt;%n: nazwa torrenta&lt;/li&gt;
&lt;/ul&gt;</translation>
    </message>
    <message>
        <source>Tray icon style:</source>
        <translation>Styl ikony w obszarze powiadomień:</translation>
    </message>
    <message>
        <source>Normal</source>
        <translation type="unfinished">normalny</translation>
    </message>
    <message>
        <source>Monochrome (Dark theme)</source>
        <translation type="unfinished">monochromatyczny (ciemny motyw)</translation>
    </message>
    <message>
        <source>Monochrome (Light theme)</source>
        <translation type="unfinished">monochromatyczny (jasny motyw)</translation>
    </message>
    <message>
        <source>This server requires a secure connection (SSL)</source>
        <translation>Ten serwer wymaga bezpiecznego połączenia (SSL)</translation>
    </message>
    <message>
        <source>User Interface Language:</source>
        <translation>Język interfejsu:</translation>
    </message>
    <message>
        <source>Transfer List</source>
        <translation>Lista transferów</translation>
    </message>
    <message>
        <source>Show qBittorrent in notification area</source>
        <translation>Pokazuj ikonę qBittorrent w obszarze powiadomień</translation>
    </message>
    <message>
        <source>Hard Disk</source>
        <translatorcomment>A może lepiej &quot;Pamięć masowa&quot;, odnosi się to do ustawień związanych z miejscem gdzie mają być pobierane dane</translatorcomment>
        <translation type="unfinished">Dysk twardy</translation>
    </message>
    <message>
        <source>Listening Port</source>
        <translation>Port nasłuchu</translation>
    </message>
    <message>
        <source>Connections Limits</source>
        <translation>Limit połączeń</translation>
    </message>
    <message>
        <source>Proxy Server</source>
        <translation>Serwer proxy</translation>
    </message>
    <message>
        <source>Torrent Queueing</source>
        <translation>Kolejkowanie torrentów</translation>
    </message>
    <message>
        <source>Share Ratio Limiting</source>
        <translation>Ograniczenie współczynnika udziału</translation>
    </message>
    <message>
        <source>Use UPnP / NAT-PMP to forward the port from my router</source>
        <translation>Używaj UPnP / NAT-PMP do przekierowania portów na routerze</translation>
    </message>
    <message>
        <source>Update my dynamic domain name</source>
        <translation type="unfinished">Aktualizuj nazwę domeny dynamicznej</translation>
    </message>
    <message>
        <source>Service:</source>
        <translation>Usługa:</translation>
    </message>
    <message>
        <source>Register</source>
        <translation>Zarejestruj</translation>
    </message>
    <message>
        <source>Domain name:</source>
        <translation>Nazwa domeny:</translation>
    </message>
    <message>
        <source>Global Rate Limits</source>
        <translation type="unfinished">Ogólne limity prędkości</translation>
    </message>
    <message>
        <source>Apply rate limit to uTP connections</source>
        <translation type="unfinished">Stosuj limity prędkości do połączeń uTP</translation>
    </message>
    <message>
        <source>Apply rate limit to transport overhead</source>
        <translatorcomment>Jeszcze nie wiem o co kaman
Stara opcja była:
Ignoruj narzuty protokołu TCP/IP w limitach prędkości</translatorcomment>
        <translation type="unfinished">Stosuj limity prędkości do transferów z narzutem</translation>
    </message>
    <message>
        <source>Alternative Global Rate Limits</source>
        <translation type="unfinished">Alternatywne ogólne limity prędkości</translation>
    </message>
    <message>
        <source>Schedule the use of alternative rate limits</source>
        <translation>Harmonogram użycia alternatywnych limitów prędkości</translation>
    </message>
    <message>
        <source>Enable bandwidth management (uTP)</source>
        <translation>Włącz zarządzanie pasmem (uTP)</translation>
    </message>
    <message>
        <source>Otherwise, the proxy server is only used for tracker connections</source>
        <translation>W przeciwnym razie serwer proxy będzie używany tylko do połączeń z trackerem</translation>
    </message>
    <message>
        <source>Use proxy for peer connections</source>
        <translation>Używaj proxy do połączeń z partnerami</translation>
    </message>
    <message>
        <source>Append .!qB extension to incomplete files</source>
        <translation>Dodaj rozszerzenie .!qB do niekompletnych plików</translation>
    </message>
    <message>
        <source>Use HTTPS instead of HTTP</source>
        <translation>Używaj HTTPS zamiast HTTP</translation>
    </message>
    <message>
        <source>Import SSL Certificate</source>
        <translation type="unfinished">Importuj certyfikat SSL</translation>
    </message>
    <message>
        <source>Import SSL Key</source>
        <translation type="unfinished">Importuj klucz SSL</translation>
    </message>
    <message>
        <source>Certificate:</source>
        <translation>Certyfikat:</translation>
    </message>
    <message>
        <source>Key:</source>
        <translation>Klucz:</translation>
    </message>
    <message>
        <source>&lt;a href=http://httpd.apache.org/docs/2.1/ssl/ssl_faq.html#aboutcerts&gt;Information about certificates&lt;/a&gt;</source>
        <translation>&lt;a href=http://httpd.apache.org/docs/2.1/ssl/ssl_faq.html#aboutcerts&gt;Informacja na temat certyfikatów&lt;/a&gt;</translation>
    </message>
</context>
<context>
    <name>PreviewSelect</name>
    <message>
        <source>Name</source>
        <translation>Nazwa</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Rozmiar</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation>Postęp</translation>
    </message>
    <message>
        <source>Preview impossible</source>
        <translation>Nie ma możliwości podglądu</translation>
    </message>
    <message>
        <source>Sorry, we can&apos;t preview this file</source>
        <translation>Przepraszamy, podgląd pliku jest niedostępny</translation>
    </message>
</context>
<context>
    <name>ProgramUpdater</name>
    <message>
        <source>Could not create the file %1</source>
        <translation type="obsolete">Nie można utworzyć pliku %1</translation>
    </message>
    <message>
        <source>Failed to download the update at %1</source>
        <comment>%1 is an URL</comment>
        <translation type="obsolete">Nie można pobrać aktualizacji z %1</translation>
    </message>
</context>
<context>
    <name>PropListDelegate</name>
    <message>
        <source>Normal</source>
        <comment>Normal (priority)</comment>
        <translation>Normalny</translation>
    </message>
    <message>
        <source>High</source>
        <comment>High (priority)</comment>
        <translation>Wysoki</translation>
    </message>
    <message>
        <source>Maximum</source>
        <comment>Maximum (priority)</comment>
        <translation>Maksymalny</translation>
    </message>
    <message>
        <source>Not downloaded</source>
        <translation>Nie pobierany</translation>
    </message>
    <message>
        <source>Mixed</source>
        <comment>Mixed (priorities</comment>
        <translation>Różne</translation>
    </message>
</context>
<context>
    <name>PropTabBar</name>
    <message>
        <source>General</source>
        <translation>Główne</translation>
    </message>
    <message>
        <source>Trackers</source>
        <translation>Trackery</translation>
    </message>
    <message>
        <source>Peers</source>
        <translation>Partnerzy</translation>
    </message>
    <message>
        <source>URL Seeds</source>
        <translation type="obsolete">Seedy www</translation>
    </message>
    <message>
        <source>Files</source>
        <translation type="obsolete">Pliki</translation>
    </message>
    <message>
        <source>HTTP Sources</source>
        <translation>Źródła HTTP</translation>
    </message>
    <message>
        <source>Content</source>
        <translation>Zawartość</translation>
    </message>
</context>
<context>
    <name>PropertiesWidget</name>
    <message>
        <source>Save path:</source>
        <translation>Katalog docelowy:</translation>
    </message>
    <message>
        <source>Torrent hash:</source>
        <translation>Hash torrenta:</translation>
    </message>
    <message>
        <source>Comment:</source>
        <translation>Komentarz:</translation>
    </message>
    <message>
        <source>Share ratio:</source>
        <translation>Współczynnik udziału:</translation>
    </message>
    <message>
        <source>General</source>
        <translation type="obsolete">Główne</translation>
    </message>
    <message>
        <source>Trackers</source>
        <translation type="obsolete">Trackery</translation>
    </message>
    <message>
        <source>URL seeds</source>
        <translation type="obsolete">Seedy www</translation>
    </message>
    <message>
        <source>Files</source>
        <translation type="obsolete">Pliki</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Priorytet</translation>
    </message>
    <message>
        <source>New url seed</source>
        <comment>New HTTP source</comment>
        <translation>Nowy adres seeda</translation>
    </message>
    <message>
        <source>New url seed:</source>
        <translation>Nowy URL seeda:</translation>
    </message>
    <message>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <source>This url seed is already in the list.</source>
        <translation>Ten URL seeda już jest na liście.</translation>
    </message>
    <message>
        <source>Choose save path</source>
        <translation>Wybierz katalog docelowy</translation>
    </message>
    <message>
        <source>Save path creation error</source>
        <translation type="obsolete">Błąd tworzenia katalogu docelowego</translation>
    </message>
    <message>
        <source>Could not create the save path</source>
        <translation type="obsolete">Nie można założyć katalogu docelowego</translation>
    </message>
    <message>
        <source>Downloaded:</source>
        <translation>Pobrano:</translation>
    </message>
    <message>
        <source>Transfer</source>
        <translation>Transfer</translation>
    </message>
    <message>
        <source>Uploaded:</source>
        <translation>Wysłano:</translation>
    </message>
    <message>
        <source>Wasted:</source>
        <translation>Odrzucono:</translation>
    </message>
    <message>
        <source>UP limit:</source>
        <translation>Limit wysyłania:</translation>
    </message>
    <message>
        <source>DL limit:</source>
        <translation>Limit pobierania:</translation>
    </message>
    <message>
        <source>Time elapsed:</source>
        <translation type="obsolete">Czas działania:</translation>
    </message>
    <message>
        <source>Connections:</source>
        <translation>Połączeń:</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Informacje</translation>
    </message>
    <message>
        <source>Created on:</source>
        <translation>Utworzono:</translation>
    </message>
    <message>
        <source>Peers</source>
        <translation type="obsolete">Partnerzy</translation>
    </message>
    <message>
        <source>Normal</source>
        <translation>Normalny</translation>
    </message>
    <message>
        <source>Maximum</source>
        <translation>Maksymalny</translation>
    </message>
    <message>
        <source>High</source>
        <translation>Wysoki</translation>
    </message>
    <message>
        <source>this session</source>
        <translation>w tej sesji</translation>
    </message>
    <message>
        <source>%1 max</source>
        <comment>e.g. 10 max</comment>
        <translation>max %1</translation>
    </message>
    <message>
        <source>Availability:</source>
        <translation>Dostępność:</translation>
    </message>
    <message>
        <source>/s</source>
        <comment>/second (i.e. per second)</comment>
        <translation>/s</translation>
    </message>
    <message>
        <source>Seeded for %1</source>
        <comment>e.g. Seeded for 3m10s</comment>
        <translation>rozsiewany przez: %1</translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation>Zmień nazwę...</translation>
    </message>
    <message>
        <source>New name:</source>
        <translation>Nowa nazwa:</translation>
    </message>
    <message>
        <source>The file could not be renamed</source>
        <translation>Nie można zmienić nazwy pliku</translation>
    </message>
    <message>
        <source>This name is already in use in this folder. Please use a different name.</source>
        <translation>Wybrana nazwa jest już używana w tym katalogu. Proszę wybrać inną nazwę.</translation>
    </message>
    <message>
        <source>The folder could not be renamed</source>
        <translation>Nie można zmienić nazwy katalogu</translation>
    </message>
    <message>
        <source>Rename the file</source>
        <translation>Zmień nazwę pliku</translation>
    </message>
    <message>
        <source>This file name contains forbidden characters, please choose a different one.</source>
        <translation>Nazwa pliku zawiera zabronione znaki, proszę wybrać inną nazwę.</translation>
    </message>
    <message>
        <source>I/O Error</source>
        <translation>Błąd We/Wy</translation>
    </message>
    <message>
        <source>This file does not exist yet.</source>
        <translation>Plik jeszcze nie istnieje.</translation>
    </message>
    <message>
        <source>This folder does not exist yet.</source>
        <translation>Katalog jeszcze nie istnieje.</translation>
    </message>
    <message>
        <source>Reannounce in:</source>
        <translation>Sprawdzanie trackera za:</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Zaznacz wszystko</translation>
    </message>
    <message>
        <source>Select None</source>
        <translation>Odznacz wszystko</translation>
    </message>
    <message>
        <source>Do not download</source>
        <translation>Nie pobieraj</translation>
    </message>
    <message>
        <source>Pieces size:</source>
        <translation>Rozmiar części:</translation>
    </message>
    <message>
        <source>Time active:</source>
        <extracomment>Time (duration) the torrent is active (not paused)</extracomment>
        <translation>Pobierany przez:</translation>
    </message>
    <message>
        <source>Torrent content:</source>
        <translation>Zawartość torrenta:</translation>
    </message>
</context>
<context>
    <name>QBtSession</name>
    <message>
        <source>%1 reached the maximum ratio you set.</source>
        <translation>%1 osiagnął ustawiony przez ciebie współczynnik udziału.</translation>
    </message>
    <message>
        <source>Removing torrent %1...</source>
        <translation>Usuwanie torrenta %1...</translation>
    </message>
    <message>
        <source>Pausing torrent %1...</source>
        <translation>Wstrzymywanie torrenta %1...</translation>
    </message>
    <message>
        <source>qBittorrent is bound to port: TCP/%1</source>
        <comment>e.g: qBittorrent is bound to port: 6881</comment>
        <translation>qBittorrent jest połączony przez port: TCP/%1</translation>
    </message>
    <message>
        <source>UPnP support [ON]</source>
        <translation type="obsolete">Wsparcie UPnP [WŁ]</translation>
    </message>
    <message>
        <source>UPnP support [OFF]</source>
        <translation type="obsolete">Wsparcie UPnP [WYŁ]</translation>
    </message>
    <message>
        <source>NAT-PMP support [ON]</source>
        <translation type="obsolete">Wsparcie NAT-PMP [WŁ]</translation>
    </message>
    <message>
        <source>NAT-PMP support [OFF]</source>
        <translation type="obsolete">Wsparcie NAT-PMP [WYŁ]</translation>
    </message>
    <message>
        <source>HTTP user agent is %1</source>
        <translation type="unfinished">HTTP user agent: %1</translation>
    </message>
    <message>
        <source>Using a disk cache size of %1 MiB</source>
        <translation type="obsolete">Rozmiar pamięci podręcznej na dysku wynosi %1 MiB</translation>
    </message>
    <message>
        <source>DHT support [ON], port: UDP/%1</source>
        <translation>Wsparcie DHT [WŁ], port: UDP/%1</translation>
    </message>
    <message>
        <source>DHT support [OFF]</source>
        <translation>Wsparcie DHT [WYŁ]</translation>
    </message>
    <message>
        <source>PeX support [ON]</source>
        <translation>Wsparcie PeX [WŁ]</translation>
    </message>
    <message>
        <source>PeX support [OFF]</source>
        <translation>Wsparcie PeX [WYŁ]</translation>
    </message>
    <message>
        <source>Restart is required to toggle PeX support</source>
        <translation>Zmiana statusu PeX wymaga ponownego uruchomienia</translation>
    </message>
    <message>
        <source>Local Peer Discovery [ON]</source>
        <translation type="obsolete">Wyszukiwanie partnerów lokalnych [WŁ]</translation>
    </message>
    <message>
        <source>Local Peer Discovery support [OFF]</source>
        <translation>Wyszukiwanie partnerów lokalnych [WYŁ]</translation>
    </message>
    <message>
        <source>Encryption support [ON]</source>
        <translation>Wsparcie szyfrowania [WŁ]</translation>
    </message>
    <message>
        <source>Encryption support [FORCED]</source>
        <translation>Wsparcie szyfrowania [WYMUSZONE]</translation>
    </message>
    <message>
        <source>Encryption support [OFF]</source>
        <translation>Wsparcie szyfrowania [WYŁ]</translation>
    </message>
    <message>
        <source>Embedded Tracker [ON]</source>
        <translation>Wbudowany tracker [WŁ]</translation>
    </message>
    <message>
        <source>Failed to start the embedded tracker!</source>
        <translation>Nie udało się uruchomić wbudowanego trackera!</translation>
    </message>
    <message>
        <source>Embedded Tracker [OFF]</source>
        <translation>Wbudowany tracker [WYŁ]</translation>
    </message>
    <message>
        <source>The Web UI is listening on port %1</source>
        <translation>Interfejs www nasłuchuje na porcie: %1</translation>
    </message>
    <message>
        <source>Web User Interface Error - Unable to bind Web UI to port %1</source>
        <translation>Błąd interfejsu www - Nie można uruchomić interefejsu www na porcie %1</translation>
    </message>
    <message>
        <source>&apos;%1&apos; was removed from transfer list and hard disk.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>&apos;%1&apos; usunięto z listy transferów i twardego dysku.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; was removed from transfer list.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>&apos;%1&apos; usunięto z listy transferów.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is not a valid magnet URI.</source>
        <translation>&apos;%1&apos; jest niepoprawnym adresem magnet.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is already in download list.</source>
        <comment>e.g: &apos;xxx.avi&apos; is already in download list.</comment>
        <translation>&apos;%1&apos; jest już na liście pobierania.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; resumed. (fast resume)</source>
        <comment>&apos;/home/y/xxx.torrent&apos; was resumed. (fast resume)</comment>
        <translation>&apos;%1&apos; wznowiony. (szybkie wznawianie)</translation>
    </message>
    <message>
        <source>&apos;%1&apos; added to download list.</source>
        <comment>&apos;/home/y/xxx.torrent&apos; was added to download list.</comment>
        <translation>&apos;%1&apos; dodano do listy pobierania.</translation>
    </message>
    <message>
        <source>Unable to decode torrent file: &apos;%1&apos;</source>
        <comment>e.g: Unable to decode torrent file: &apos;/home/y/xxx.torrent&apos;</comment>
        <translation>Nie można otworzyć pliku torrent: &apos;%1&apos;</translation>
    </message>
    <message>
        <source>This file is either corrupted or this isn&apos;t a torrent.</source>
        <translation>Plik jest uszkodzony lub nie jest plikiem torrent.</translation>
    </message>
    <message>
        <source>Error: The torrent %1 does not contain any file.</source>
        <translation>Błąd: Torrent %1 nie zawiera żadnego pliku.</translation>
    </message>
    <message>
        <source>Note: new trackers were added to the existing torrent.</source>
        <translation>Uwaga: nowe trackery zostały dodane do istniejącego torrenta.</translation>
    </message>
    <message>
        <source>Note: new URL seeds were added to the existing torrent.</source>
        <translation>Uwaga: nowe URL seedów zostały dodane do istniejącego torrenta.</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;was blocked due to your IP filter&lt;/i&gt;</source>
        <comment>x.y.z.w was blocked</comment>
        <translation>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;zablokowany przez filtr IP&lt;/i&gt;</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;was banned due to corrupt pieces&lt;/i&gt;</source>
        <comment>x.y.z.w was banned</comment>
        <translation>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;zablokowany z powodu uszkodzonych części&lt;/i&gt;</translation>
    </message>
    <message>
        <source>Recursive download of file %1 embedded in torrent %2</source>
        <comment>Recursive download of test.torrent embedded in torrent test2</comment>
        <translation>Rekurencyjne pobieranie pliku %1 osadzonego w pliku torrent %2</translation>
    </message>
    <message>
        <source>Unable to decode %1 torrent file.</source>
        <translation>Nie można odczytać pliku torrent: &apos;%1&apos;.</translation>
    </message>
    <message>
        <source>Torrent name: %1</source>
        <translation>Nazwa torrenta: %1</translation>
    </message>
    <message>
        <source>Torrent size: %1</source>
        <translation>Rozmiar torrenta: %1</translation>
    </message>
    <message>
        <source>Save path: %1</source>
        <translation>Katalog docelowy: %1</translation>
    </message>
    <message>
        <source>The torrent was downloaded in %1.</source>
        <comment>The torrent was downloaded in 1 hour and 20 seconds</comment>
        <translation>Torrent został pobrany w %1.</translation>
    </message>
    <message>
        <source>Thank you for using qBittorrent.</source>
        <translation>Dziękujemy za używanie qBittorrent.</translation>
    </message>
    <message>
        <source>[qBittorrent] %1 has finished downloading</source>
        <translation>[qBittorrent] %1 został pobrany</translation>
    </message>
    <message>
        <source>An I/O error occured, &apos;%1&apos; paused.</source>
        <translation>Wystąpił błąd We/Wy, &apos;%1&apos; wstrzymany.</translation>
    </message>
    <message>
        <source>Reason: %1</source>
        <translation>Powód: %1</translation>
    </message>
    <message>
        <source>UPnP/NAT-PMP: Port mapping failure, message: %1</source>
        <translation>UPnP/NAT-PMP: Błąd mapowania portu, komunikat %1</translation>
    </message>
    <message>
        <source>UPnP/NAT-PMP: Port mapping successful, message: %1</source>
        <translation>UPnP/NAT-PMP: Udane mapowanie portu, komunikat %1</translation>
    </message>
    <message>
        <source>File sizes mismatch for torrent %1, pausing it.</source>
        <translation>Błędny razmiar pliku z torrenta %1, wstrzymuję pobieranie.</translation>
    </message>
    <message>
        <source>Fast resume data was rejected for torrent %1, checking again...</source>
        <translation>Szybkie wznowienie pobierania zostało odrzucone dla torrenta %1, ponowne sprawdzanie...</translation>
    </message>
    <message>
        <source>Url seed lookup failed for url: %1, message: %2</source>
        <translation>Błąd wyszukiwania url partnera dla adresu:%1, komunikat: %2</translation>
    </message>
    <message>
        <source>Downloading &apos;%1&apos;, please wait...</source>
        <comment>e.g: Downloading &apos;xxx.torrent&apos;, please wait...</comment>
        <translation>Pobieranie &apos;%1&apos;, proszę czekać...</translation>
    </message>
    <message>
        <source>The network interface defined is invalid: %1</source>
        <translation>Podany interfejs sieciowy jest nieprawidłowy: %1</translation>
    </message>
    <message>
        <source>Trying any other network interface available instead.</source>
        <translation>Testowanie innego interfejsu sieciowego.</translation>
    </message>
    <message>
        <source>Listening on IP address %1 on network interface %2...</source>
        <translation>Nasłuchiwanie na adresie IP %1 interfejsu sieciowego %2...</translation>
    </message>
    <message>
        <source>Failed to listen on network interface %1</source>
        <translation>Błąd nasłuchiwania na interfejsie %1</translation>
    </message>
    <message>
        <source>UPnP / NAT-PMP support [ON]</source>
        <translation>Wsparcie UPnP / NAT-PMP [WŁ]</translation>
    </message>
    <message>
        <source>UPnP / NAT-PMP support [OFF]</source>
        <translation>Wsparcie UPnP / NAT-PMP [WYŁ]</translation>
    </message>
    <message>
        <source>Local Peer Discovery support [ON]</source>
        <translation>Wykrywanie partnerów w sieci lokalnej (LPD) [WŁ]</translation>
    </message>
    <message>
        <source>Successfuly parsed the provided IP filter: %1 rules were applied.</source>
        <comment>%1 is a number</comment>
        <translation>Pomyślnie przetworzono podany filtr IP: zastosowano %1 reguł.</translation>
    </message>
    <message>
        <source>Error: Failed to parse the provided IP filter.</source>
        <translation>Błąd: Nie udało się przetworzyć podanego filtra IP.</translation>
    </message>
    <message>
        <source>Reporting IP address %1 to trackers...</source>
        <translation>Zgłaszanie trackerom adresu IP %1...</translation>
    </message>
    <message>
        <source>The computer will now go to sleep mode unless you cancel within the next 15 seconds...</source>
        <translation type="unfinished">Komputer zostanie uśpiony jeśli nie anulujesz akcji w ciągu 15 sekund...</translation>
    </message>
    <message>
        <source>The computer will now be switched off unless you cancel within the next 15 seconds...</source>
        <translation type="unfinished">Komputer zostanie wyłączony jeśli nie anulujesz akcji w ciągu 15 sekund...</translation>
    </message>
    <message>
        <source>qBittorrent will now exit unless you cancel within the next 15 seconds...</source>
        <translation type="unfinished">Działanie qBittorrent zostanie zakończone jeśli nie anulujesz akcji w ciągu 15 sekund...</translation>
    </message>
</context>
<context>
    <name>RSS</name>
    <message>
        <source>Search</source>
        <translation>Szukaj</translation>
    </message>
    <message>
        <source>New subscription</source>
        <translation>Nowy kanał RSS</translation>
    </message>
    <message>
        <source>Mark items read</source>
        <translation>Zaznacz jako przeczytane</translation>
    </message>
    <message>
        <source>Update all</source>
        <translation>Odśwież wszystkie</translation>
    </message>
    <message>
        <source>Feed URL</source>
        <translation type="obsolete">Adres kanału RSS</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Odśwież</translation>
    </message>
    <message>
        <source>RSS feeds</source>
        <translation type="obsolete">Kanały RSS</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Torrents:&lt;/span&gt; &lt;span style=&quot; font-style:italic;&quot;&gt;(double-click to download)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Torrenty:&lt;/span&gt; &lt;span style=&quot; font-style:italic;&quot;&gt;(kliknij dwukrotnie aby pobrać)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Article title</source>
        <translation type="obsolete">Tytuł</translation>
    </message>
    <message>
        <source>Update all feeds</source>
        <translation>Odśwież wszystkie kanały RSS</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Usuń</translation>
    </message>
    <message>
        <source>Rename</source>
        <translation>Zmień nazwę</translation>
    </message>
    <message>
        <source>Download torrent</source>
        <translation>Pobierz torrent</translation>
    </message>
    <message>
        <source>Open news URL</source>
        <translation>Otwórz URL wiadomości</translation>
    </message>
    <message>
        <source>Copy feed URL</source>
        <translation>Kopiuj adres kanału RSS</translation>
    </message>
    <message>
        <source>Refresh RSS streams</source>
        <translation>Odśwież kanały RSS</translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation>Zmień nazwę...</translation>
    </message>
    <message>
        <source>New subscription...</source>
        <translation>Nowy kanał RSS...</translation>
    </message>
    <message>
        <source>RSS feed downloader...</source>
        <translation type="obsolete">Pobieranie z kanałów RSS...</translation>
    </message>
    <message>
        <source>New folder...</source>
        <translation>Nowy katalog...</translation>
    </message>
    <message>
        <source>Manage cookies...</source>
        <translation>Zarządzanie ciasteczkami...</translation>
    </message>
    <message>
        <source>Settings...</source>
        <translation>Ustawienia...</translation>
    </message>
    <message>
        <source>RSS Downloader...</source>
        <translatorcomment>or something shorter?</translatorcomment>
        <translation type="unfinished">Pobieranie z kanałów RSS...</translation>
    </message>
</context>
<context>
    <name>RSSImp</name>
    <message>
        <source>Please type a rss stream url</source>
        <translation>Wprowadź URL kanału RSS</translation>
    </message>
    <message>
        <source>Stream URL:</source>
        <translation>Adres URL dla nowego kanału RSS:</translation>
    </message>
    <message>
        <source>Are you sure? -- qBittorrent</source>
        <translation>Czy na pewno? -- qBittorrent</translation>
    </message>
    <message>
        <source>&amp;Yes</source>
        <translation>&amp;Tak</translation>
    </message>
    <message>
        <source>&amp;No</source>
        <translation>&amp;Nie</translation>
    </message>
    <message>
        <source>Please choose a folder name</source>
        <translation>Wprowadź nazwę katalogu</translation>
    </message>
    <message>
        <source>Folder name:</source>
        <translation>Nazwa dla nowego katalogu:</translation>
    </message>
    <message>
        <source>New folder</source>
        <translation>Nowy katalog</translation>
    </message>
    <message>
        <source>Overwrite attempt</source>
        <translation>Próba nadpisania</translation>
    </message>
    <message>
        <source>You cannot overwrite %1 item.</source>
        <comment>You cannot overwrite myFolder item.</comment>
        <translation>Nie mozna nadpisać katalogu %1.</translation>
    </message>
    <message>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <source>This rss feed is already in the list.</source>
        <translation>Ten kanał RSS już jest na liście.</translation>
    </message>
    <message>
        <source>Are you sure you want to delete these elements from the list?</source>
        <translation>Czy na pewno usunąć wybrane elementy z listy?</translation>
    </message>
    <message>
        <source>Are you sure you want to delete this element from the list?</source>
        <translation>Czy na pewno usunąć wybrany element z listy?</translation>
    </message>
    <message>
        <source>Please choose a new name for this RSS feed</source>
        <translation>Należy podać nową nazwę dla tego kanału RSS</translation>
    </message>
    <message>
        <source>New feed name:</source>
        <translation>Nowa nazwa kanału RSS:</translation>
    </message>
    <message>
        <source>Name already in use</source>
        <translation>Podana nazwa już istnieje</translation>
    </message>
    <message>
        <source>This name is already used by another item, please choose another one.</source>
        <translation>Podana nazwa już istnieje, należy wybrać inną.</translation>
    </message>
    <message>
        <source>Date: </source>
        <translation>Data: </translation>
    </message>
    <message>
        <source>Author: </source>
        <translation>Autor: </translation>
    </message>
    <message>
        <source>Unread</source>
        <translation>Nieprzeczytane</translation>
    </message>
</context>
<context>
    <name>RssArticle</name>
    <message>
        <source>No description available</source>
        <translation type="obsolete">Opis niedostępny</translation>
    </message>
</context>
<context>
    <name>RssFeed</name>
    <message>
        <source>Automatically downloading %1 torrent from %2 RSS feed...</source>
        <translation>Automatyczne pobieranie torrenta %1z kanału RSS %2 ...</translation>
    </message>
</context>
<context>
    <name>RssItem</name>
    <message>
        <source>No description available</source>
        <translation type="obsolete">Opis niedostępny</translation>
    </message>
</context>
<context>
    <name>RssSettings</name>
    <message>
        <source>RSS Reader Settings</source>
        <translation type="obsolete">Ustawienia czytnika RSS</translation>
    </message>
    <message>
        <source>RSS feeds refresh interval:</source>
        <translation type="obsolete">Częstotliwość odświeżania kanałów RSS:</translation>
    </message>
    <message>
        <source>minutes</source>
        <translation type="obsolete">minut</translation>
    </message>
    <message>
        <source>Maximum number of articles per feed:</source>
        <translation type="obsolete">Maksymalna liczba wiadomości na kanał RSS:</translation>
    </message>
</context>
<context>
    <name>RssSettingsDlg</name>
    <message>
        <source>RSS Reader Settings</source>
        <translation>Ustawienia czytnika RSS</translation>
    </message>
    <message>
        <source>RSS feeds refresh interval:</source>
        <translation>Częstotliwość odświeżania kanałów:</translation>
    </message>
    <message>
        <source>minutes</source>
        <translation>minut</translation>
    </message>
    <message>
        <source>Maximum number of articles per feed:</source>
        <translation>Maksymalna liczba wiadomości na kanał:</translation>
    </message>
</context>
<context>
    <name>RssStream</name>
    <message>
        <source>Automatically downloading %1 torrent from %2 RSS feed...</source>
        <translation type="obsolete">Automatyczne pobieranie torrenta %1z kanału RSS %2 ...</translation>
    </message>
</context>
<context>
    <name>ScanFoldersModel</name>
    <message>
        <source>Watched Folder</source>
        <translation>Obserwowany katalog</translation>
    </message>
    <message>
        <source>Download here</source>
        <translation>Pobierz tutaj</translation>
    </message>
</context>
<context>
    <name>SearchCategories</name>
    <message>
        <source>All categories</source>
        <translation>Wszystko</translation>
    </message>
    <message>
        <source>Movies</source>
        <translation>Filmy</translation>
    </message>
    <message>
        <source>TV shows</source>
        <translation>Seriale TV</translation>
    </message>
    <message>
        <source>Music</source>
        <translation>Muzyka</translation>
    </message>
    <message>
        <source>Games</source>
        <translation>Gry</translation>
    </message>
    <message>
        <source>Anime</source>
        <translation>Anime</translation>
    </message>
    <message>
        <source>Software</source>
        <translation>Programy</translation>
    </message>
    <message>
        <source>Pictures</source>
        <translation>Obrazki</translation>
    </message>
    <message>
        <source>Books</source>
        <translation>Książki</translation>
    </message>
</context>
<context>
    <name>SearchEngine</name>
    <message>
        <source>Empty search pattern</source>
        <translation>Pusty wzorzec wyszukiwania</translation>
    </message>
    <message>
        <source>Please type a search pattern first</source>
        <translation>Proszę podać wzorzec wyszukiwania</translation>
    </message>
    <message>
        <source>Results</source>
        <translation>Wyniki</translation>
    </message>
    <message>
        <source>Searching...</source>
        <translation>Wyszukiwanie...</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation>Wytnij</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Kopiuj</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation>Wklej</translation>
    </message>
    <message>
        <source>Clear field</source>
        <translation>Wyczyść pole</translation>
    </message>
    <message>
        <source>Clear completion history</source>
        <translation>Wyczyść historię</translation>
    </message>
    <message>
        <source>Search Engine</source>
        <translation>Wyszukiwarka</translation>
    </message>
    <message>
        <source>Search has finished</source>
        <translation>Wyszukiwanie zakończone</translation>
    </message>
    <message>
        <source>An error occured during search...</source>
        <translation>Wystąpił błąd podczas wyszukiwania...</translation>
    </message>
    <message>
        <source>Search aborted</source>
        <translation>Wyszukiwanie przerwane</translation>
    </message>
    <message>
        <source>Search returned no results</source>
        <translation>Nic nie znaleziono</translation>
    </message>
    <message>
        <source>Results</source>
        <comment>i.e: Search results</comment>
        <translation>Wyniki</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Nieznany</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Szukaj</translation>
    </message>
    <message>
        <source>Download error</source>
        <translation>Błąd pobierania</translation>
    </message>
    <message>
        <source>Python setup could not be downloaded, reason: %1.
Please install it manually.</source>
        <translation>Nie można pobrać instalatora Python z powodu %1 .
Należy zainstalować go ręcznie.</translation>
    </message>
    <message>
        <source>Missing Python Interpreter</source>
        <translation>Nie znaleziono interpretera Python</translation>
    </message>
    <message>
        <source>Python 2.x is required to use the search engine but it does not seem to be installed.
Do you want to install it now?</source>
        <translation>Python w wersji 2.x jest wymagany do poprawnego działania wyszukiwarki. Wygląda na to,
że nie jest zainstalowany. Zainstalować teraz?</translation>
    </message>
    <message>
        <source>Confirmation</source>
        <translation>Potwierdzenie</translation>
    </message>
    <message>
        <source>Are you sure you want to clear the history?</source>
        <translation>Czy na pewno wyczyścić historię?</translation>
    </message>
</context>
<context>
    <name>SearchTab</name>
    <message>
        <source>Name</source>
        <comment>i.e: file name</comment>
        <translation>Nazwa</translation>
    </message>
    <message>
        <source>Size</source>
        <comment>i.e: file size</comment>
        <translation>Rozmiar</translation>
    </message>
    <message>
        <source>Seeders</source>
        <comment>i.e: Number of full sources</comment>
        <translation>Pełnych</translation>
    </message>
    <message>
        <source>Leechers</source>
        <comment>i.e: Number of partial sources</comment>
        <translation>Częściowych</translation>
    </message>
    <message>
        <source>Search engine</source>
        <translation>Wyszukiwarka</translation>
    </message>
</context>
<context>
    <name>ShutdownConfirmDlg</name>
    <message>
        <source>Shutdown confirmation</source>
        <translation type="unfinished">Potwierdzenie zamykania</translation>
    </message>
</context>
<context>
    <name>SpeedLimitDialog</name>
    <message>
        <source>KiB/s</source>
        <translation>KiB/s</translation>
    </message>
</context>
<context>
    <name>StatusBar</name>
    <message>
        <source>Connection status:</source>
        <translation>Status połączenia:</translation>
    </message>
    <message>
        <source>No direct connections. This may indicate network configuration problems.</source>
        <translation>Brak bezposrednich połączeń. Może to oznaczać problem z konfiguracją sieci.</translation>
    </message>
    <message>
        <source>DHT: %1 nodes</source>
        <translation>Węzły DHT: %1</translation>
    </message>
    <message>
        <source>Connection Status:</source>
        <translation>Status połączenia:</translation>
    </message>
    <message>
        <source>Online</source>
        <translation>Połączony</translation>
    </message>
    <message>
        <source>Global Download Speed Limit</source>
        <translation>Ogólny limit pobierania</translation>
    </message>
    <message>
        <source>Global Upload Speed Limit</source>
        <translation>Ogólny limit wysyłania</translation>
    </message>
    <message>
        <source>D: %1/s - T: %2</source>
        <comment>Download speed: x KiB/s - Transferred: x MiB</comment>
        <translation type="obsolete">Pobieranie: %1/s - Pobrano: %2</translation>
    </message>
    <message>
        <source>U: %1/s - T: %2</source>
        <comment>Upload speed: x KiB/s - Transferred: x MiB</comment>
        <translation type="obsolete">Wysyłanie: %1/s - Wysłano: %2</translation>
    </message>
    <message>
        <source>D: %1 B/s - T: %2</source>
        <comment>Download speed: x B/s - Transferred: x MiB</comment>
        <translation type="obsolete">Pobieranie: %1/s - Pobrano: %2</translation>
    </message>
    <message>
        <source>U: %1 B/s - T: %2</source>
        <comment>Upload speed: x B/s - Transferred: x MiB</comment>
        <translation type="obsolete">Wysyłanie: %1/s - Wysłano: %2</translation>
    </message>
    <message>
        <source>Offline. This usually means that qBittorrent failed to listen on the selected port for incoming connections.</source>
        <translation>Offline. Oznacza, że qBittorent nie jest w stanie nasłuchiwać połączeń przychodzących na wybranym porcie.</translation>
    </message>
    <message>
        <source>Click to disable alternative speed limits</source>
        <translation type="obsolete">Kliknij, aby wyłączyć alternatywne limity prędkości</translation>
    </message>
    <message>
        <source>Click to enable alternative speed limits</source>
        <translation type="obsolete">Kliknij, aby włączyć alternatywne limity prędkości</translation>
    </message>
    <message>
        <source>qBittorrent needs to be restarted</source>
        <translation>qBittorrent musi zostać uruchomiony ponownie</translation>
    </message>
    <message>
        <source>qBittorrent was just updated and needs to be restarted for the changes to be effective.</source>
        <translation>qBittorrent został zaktualizowany i konieczne jest jego ponowne uruchomienie.</translation>
    </message>
    <message>
        <source>Click to switch to alternative speed limits</source>
        <translation type="unfinished">Kliknij aby przełączyć na alternatywne limity prędkości</translation>
    </message>
    <message>
        <source>Click to switch to regular speed limits</source>
        <translation type="unfinished">Kliknij aby przełączyć na normalne limity prędkości</translation>
    </message>
    <message>
        <source>%1/s</source>
        <comment>Per second</comment>
        <translation>%1/s</translation>
    </message>
</context>
<context>
    <name>TorrentCreatorDlg</name>
    <message>
        <source>Select a folder to add to the torrent</source>
        <translation>Wybierz katalog który chcesz dodać do torrenta</translation>
    </message>
    <message>
        <source>Select a file to add to the torrent</source>
        <translation>Wybierz plik który chcesz dodać do torrenta</translation>
    </message>
    <message>
        <source>Please type an announce URL</source>
        <translation type="obsolete">Wprowadź adres trackera</translation>
    </message>
    <message>
        <source>Announce URL:</source>
        <comment>Tracker URL</comment>
        <translation type="obsolete">Adres trackera:</translation>
    </message>
    <message>
        <source>Please type a web seed url</source>
        <translation type="obsolete">Wprowadź adres seeda www</translation>
    </message>
    <message>
        <source>Web seed URL:</source>
        <translation type="obsolete">Adres seeda www:</translation>
    </message>
    <message>
        <source>No input path set</source>
        <translation>Nieznany katalog źródłowy</translation>
    </message>
    <message>
        <source>Please type an input path first</source>
        <translation>Proszę podać katalog żródłowy</translation>
    </message>
    <message>
        <source>Select destination torrent file</source>
        <translation>Wybierz plik docelowy</translation>
    </message>
    <message>
        <source>Torrent Files</source>
        <translation>Pliki .torrent</translation>
    </message>
    <message>
        <source>Torrent creation</source>
        <translation>Tworzenie pliku torrent</translation>
    </message>
    <message>
        <source>Torrent creation was unsuccessful, reason: %1</source>
        <translation>Nie udało się utworzyć pliku torrent z powodu: %1</translation>
    </message>
    <message>
        <source>Created torrent file is invalid. It won&apos;t be added to download list.</source>
        <translation>Utworzony plik torrent jest nieprawidłowy. Nie zostanie dodany do listy pobierania.</translation>
    </message>
    <message>
        <source>Torrent was created successfully:</source>
        <translation>Pomyślnie utworzono plik torrent:</translation>
    </message>
</context>
<context>
    <name>TorrentFilesModel</name>
    <message>
        <source>Name</source>
        <translation>Nazwa</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Rozmiar</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation>Postęp</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Priorytet</translation>
    </message>
</context>
<context>
    <name>TorrentImportDlg</name>
    <message>
        <source>Torrent Import</source>
        <translation>Importowanie pliku torrent</translation>
    </message>
    <message>
        <source>This assistant will help you share with qBittorrent a torrent that you have already downloaded.</source>
        <translation>Ten asystent pomoże Ci dzielić się plikami, które zostały już wcześniej pobrane.</translation>
    </message>
    <message>
        <source>Torrent file to import:</source>
        <translation>Plik torrent do zaimportowania:</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Content location:</source>
        <translation>Położenie zawartości:</translation>
    </message>
    <message>
        <source>Skip the data checking stage and start seeding immediately</source>
        <translation>Pomiń sprawdzanie danych i zacznij udostępniać od razu</translation>
    </message>
    <message>
        <source>Import</source>
        <translation>Importuj</translation>
    </message>
    <message>
        <source>Torrent file to import</source>
        <translation>Plik torrent do zaimportowania</translation>
    </message>
    <message>
        <source>Torrent files (*.torrent)</source>
        <translation>Pliki .torrent</translation>
    </message>
    <message>
        <source>%1 Files</source>
        <comment>%1 is a file extension (e.g. PDF)</comment>
        <translation>Pliki %1</translation>
    </message>
    <message>
        <source>Please provide the location of %1</source>
        <comment>%1 is a file name</comment>
        <translatorcomment>dialog window when only one file is in torrent</translatorcomment>
        <translation>Podaj położenie pliku %1</translation>
    </message>
    <message>
        <source>Please point to the location of the torrent: %1</source>
        <translatorcomment>dialog window when directory is in torrent</translatorcomment>
        <translation>Podaj położenie katalogu %1</translation>
    </message>
    <message>
        <source>Invalid torrent file</source>
        <translation>Nieprawidłowy plik torrent</translation>
    </message>
    <message>
        <source>This is not a valid torrent file.</source>
        <translation>To nie jest prawidłowy plik torrent.</translation>
    </message>
</context>
<context>
    <name>TorrentModel</name>
    <message>
        <source>Name</source>
        <comment>i.e: torrent name</comment>
        <translation>Nazwa</translation>
    </message>
    <message>
        <source>Size</source>
        <comment>i.e: torrent size</comment>
        <translation>Rozmiar</translation>
    </message>
    <message>
        <source>Done</source>
        <comment>% Done</comment>
        <translation>Ukończono</translation>
    </message>
    <message>
        <source>Status</source>
        <comment>Torrent status (e.g. downloading, seeding, paused)</comment>
        <translation>Status</translation>
    </message>
    <message>
        <source>Seeds</source>
        <comment>i.e. full sources (often untranslated)</comment>
        <translation>Pełnych</translation>
    </message>
    <message>
        <source>Peers</source>
        <comment>i.e. partial sources (often untranslated)</comment>
        <translation>Częściowych</translation>
    </message>
    <message>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Pobieranie</translation>
    </message>
    <message>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Wysyłanie</translation>
    </message>
    <message>
        <source>Ratio</source>
        <comment>Share ratio</comment>
        <translation>Udział</translation>
    </message>
    <message>
        <source>ETA</source>
        <comment>i.e: Estimated Time of Arrival / Time left</comment>
        <translation>ETA</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Etykieta</translation>
    </message>
    <message>
        <source>Added On</source>
        <comment>Torrent was added to transfer list on 01/01/2010 08:00</comment>
        <translation>Dodano</translation>
    </message>
    <message>
        <source>Completed On</source>
        <comment>Torrent was completed on 01/01/2010 08:00</comment>
        <translation>Ukończono</translation>
    </message>
    <message>
        <source>Tracker</source>
        <translation>Tracker</translation>
    </message>
    <message>
        <source>Down Limit</source>
        <comment>i.e: Download limit</comment>
        <translation>Limit pobierania</translation>
    </message>
    <message>
        <source>Up Limit</source>
        <comment>i.e: Upload limit</comment>
        <translation>Limit wysyłania</translation>
    </message>
    <message>
        <source>Amount downloaded</source>
        <comment>Amount of data downloaded (e.g. in MB)</comment>
        <translation>Pobrano</translation>
    </message>
    <message>
        <source>Amount left</source>
        <comment>Amount of data left to download (e.g. in MB)</comment>
        <translation>Pozostało</translation>
    </message>
    <message>
        <source>Time Active</source>
        <comment>Time (duration) the torrent is active (not paused)</comment>
        <translation type="unfinished">Aktywny przez</translation>
    </message>
</context>
<context>
    <name>TrackerList</name>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <source>Peers</source>
        <translation>Partnerów</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Komunikat</translation>
    </message>
    <message>
        <source>[DHT]</source>
        <translation>[DHT]</translation>
    </message>
    <message>
        <source>Working</source>
        <translation>Działa</translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Wyłączone</translation>
    </message>
    <message>
        <source>This torrent is private</source>
        <translation>Torrent prywatny</translation>
    </message>
    <message>
        <source>Updating...</source>
        <translation>Aktualizowanie...</translation>
    </message>
    <message>
        <source>Not working</source>
        <translation>Nie działa</translation>
    </message>
    <message>
        <source>Not contacted yet</source>
        <translation>Niesprawdzony</translation>
    </message>
    <message>
        <source>[PeX]</source>
        <translation>[PeX]</translation>
    </message>
    <message>
        <source>[LSD]</source>
        <translation>[LSD]</translation>
    </message>
    <message>
        <source>Add a new tracker...</source>
        <translation>Dodaj tracker...</translation>
    </message>
    <message>
        <source>Remove tracker</source>
        <translation>Usuń tracker</translation>
    </message>
    <message>
        <source>Force reannounce</source>
        <translation>Sprawdź tracker</translation>
    </message>
</context>
<context>
    <name>TrackersAdditionDlg</name>
    <message>
        <source>Trackers addition dialog</source>
        <translation>Dodawanie trackerów</translation>
    </message>
    <message>
        <source>List of trackers to add (one per line):</source>
        <translation>Lista trackerów do dodania (jeden na linię):</translation>
    </message>
    <message utf8="true">
        <source>µTorrent compatible list URL:</source>
        <translation>Adres kompatybilny z µTorrent:</translation>
    </message>
    <message>
        <source>I/O Error</source>
        <translation>Błąd We/Wy</translation>
    </message>
    <message>
        <source>Error while trying to open the downloaded file.</source>
        <translation>Błąd podczas próby otwarcia pobranego pliku.</translation>
    </message>
    <message>
        <source>No change</source>
        <translation>Bez zmian</translation>
    </message>
    <message>
        <source>No additional trackers were found.</source>
        <translation>Nie znaleziono dodatkowych trackerów.</translation>
    </message>
    <message>
        <source>Download error</source>
        <translation>Błąd pobierania</translation>
    </message>
    <message>
        <source>The trackers list could not be downloaded, reason: %1</source>
        <translation>Nie można pobrać listy trackerów z powodu %1</translation>
    </message>
</context>
<context>
    <name>TransferListDelegate</name>
    <message>
        <source>Downloading</source>
        <translation>Pobieranie</translation>
    </message>
    <message>
        <source>Paused</source>
        <translation>Wstrzymany</translation>
    </message>
    <message>
        <source>Queued</source>
        <comment>i.e. torrent is queued</comment>
        <translation>W kolejce</translation>
    </message>
    <message>
        <source>Seeding</source>
        <comment>Torrent is complete and in upload-only mode</comment>
        <translation>Wysyłanie</translation>
    </message>
    <message>
        <source>Stalled</source>
        <comment>Torrent is waiting for download to begin</comment>
        <translation>Oczekujący</translation>
    </message>
    <message>
        <source>Checking</source>
        <comment>Torrent local data is being checked</comment>
        <translation>Sprawdzanie</translation>
    </message>
    <message>
        <source>/s</source>
        <comment>/second (.i.e per second)</comment>
        <translation>/s</translation>
    </message>
    <message>
        <source>KiB/s</source>
        <comment>KiB/second (.i.e per second)</comment>
        <translation>KiB/s</translation>
    </message>
    <message>
        <source>Seeded for %1</source>
        <comment>e.g. Seeded for 3m10s</comment>
        <translation type="unfinished">wysyłany przez %1</translation>
    </message>
</context>
<context>
    <name>TransferListFiltersWidget</name>
    <message>
        <source>All</source>
        <translation>Wszystkie</translation>
    </message>
    <message>
        <source>Downloading</source>
        <translation>Pobierane</translation>
    </message>
    <message>
        <source>Completed</source>
        <translation>Ukończone</translation>
    </message>
    <message>
        <source>Active</source>
        <translation>Aktywne</translation>
    </message>
    <message>
        <source>Inactive</source>
        <translation>Nieaktywne</translation>
    </message>
    <message>
        <source>All labels</source>
        <translation>Wszystkie</translation>
    </message>
    <message>
        <source>Unlabeled</source>
        <translation>Bez etykiety</translation>
    </message>
    <message>
        <source>Remove label</source>
        <translation>Usuń etykietę</translation>
    </message>
    <message>
        <source>New Label</source>
        <translation>Nowa etykieta</translation>
    </message>
    <message>
        <source>Label:</source>
        <translation>Etykieta:</translation>
    </message>
    <message>
        <source>Invalid label name</source>
        <translation>Nieprawidłowa nazwa etykiety</translation>
    </message>
    <message>
        <source>Please don&apos;t use any special characters in the label name.</source>
        <translation>Nie należy używać żadnych znaków specjalnych w nazwach etykiet.</translation>
    </message>
    <message>
        <source>Paused</source>
        <translation>Wstrzymane</translation>
    </message>
    <message>
        <source>Add label...</source>
        <translation>Dodaj etykietę...</translation>
    </message>
    <message>
        <source>Resume torrents</source>
        <translation>Wznów torrenty</translation>
    </message>
    <message>
        <source>Pause torrents</source>
        <translation>Wstrzymaj torrenty</translation>
    </message>
    <message>
        <source>Delete torrents</source>
        <translation>Usuń torrenty</translation>
    </message>
</context>
<context>
    <name>TransferListWidget</name>
    <message>
        <source>ETA</source>
        <comment>i.e: Estimated Time of Arrival / Time left</comment>
        <translation type="obsolete">ETA</translation>
    </message>
    <message>
        <source>Column visibility</source>
        <translation>Widoczność kolumn</translation>
    </message>
    <message>
        <source>Open destination folder</source>
        <translation>Otwórz katalog pobierań</translation>
    </message>
    <message>
        <source>Force recheck</source>
        <translation>Sprawdź pobrane dane</translation>
    </message>
    <message>
        <source>Copy magnet link</source>
        <translation>Kopiuj adres magnet</translation>
    </message>
    <message>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation type="obsolete">Prędkość DL</translation>
    </message>
    <message>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation type="obsolete">Prędkość UP</translation>
    </message>
    <message>
        <source>Name</source>
        <comment>i.e: torrent name</comment>
        <translation type="obsolete">Nazwa</translation>
    </message>
    <message>
        <source>Size</source>
        <comment>i.e: torrent size</comment>
        <translation type="obsolete">Rozmiar</translation>
    </message>
    <message>
        <source>Done</source>
        <comment>% Done</comment>
        <translation type="obsolete">Ukończono</translation>
    </message>
    <message>
        <source>Status</source>
        <comment>Torrent status (e.g. downloading, seeding, paused)</comment>
        <translation type="obsolete">Status</translation>
    </message>
    <message>
        <source>Seeds</source>
        <comment>i.e. full sources (often untranslated)</comment>
        <translation type="obsolete">Pełnych</translation>
    </message>
    <message>
        <source>Peers</source>
        <comment>i.e. partial sources (often untranslated)</comment>
        <translation type="obsolete">Częściowych</translation>
    </message>
    <message>
        <source>Ratio</source>
        <comment>Share ratio</comment>
        <translation type="obsolete">Współczynnik udziału</translation>
    </message>
    <message>
        <source>Torrent Download Speed Limiting</source>
        <translation>Ograniczanie prędkości pobierania torrenta</translation>
    </message>
    <message>
        <source>Torrent Upload Speed Limiting</source>
        <translation>Ograniczanie prędkości wysyłania torrenta</translation>
    </message>
    <message>
        <source>Super seeding mode</source>
        <translation>Tryb &apos;super seed&apos;</translation>
    </message>
    <message>
        <source>Download in sequential order</source>
        <translation>Pobierz w kolejności sekwencyjnej</translation>
    </message>
    <message>
        <source>Download first and last piece first</source>
        <translation>Pobierz najpierw część pierwszą i ostatnią</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Etykieta</translation>
    </message>
    <message>
        <source>New Label</source>
        <translation>Nowa etykieta</translation>
    </message>
    <message>
        <source>Label:</source>
        <translation>Etykieta:</translation>
    </message>
    <message>
        <source>New...</source>
        <comment>New label...</comment>
        <translation>Nowa...</translation>
    </message>
    <message>
        <source>Reset</source>
        <comment>Reset label</comment>
        <translation>Usuń</translation>
    </message>
    <message>
        <source>Rename</source>
        <translation>Zmień nazwę</translation>
    </message>
    <message>
        <source>New name:</source>
        <translation>Nowa nazwa:</translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation>Zmień nazwę...</translation>
    </message>
    <message>
        <source>Invalid label name</source>
        <translation>Nieprawidłowa nazwa etykiety</translation>
    </message>
    <message>
        <source>Please don&apos;t use any special characters in the label name.</source>
        <translation>Nie należy używać żadnych znaków specjalnych w nazwach etykiet.</translation>
    </message>
    <message>
        <source>Added On</source>
        <comment>Torrent was added to transfer list on 01/01/2010 08:00</comment>
        <translation type="obsolete">Dodano</translation>
    </message>
    <message>
        <source>Completed On</source>
        <comment>Torrent was completed on 01/01/2010 08:00</comment>
        <translation type="obsolete">Ukończono</translation>
    </message>
    <message>
        <source>Down Limit</source>
        <comment>i.e: Download limit</comment>
        <translation type="obsolete">Limit DL</translation>
    </message>
    <message>
        <source>Up Limit</source>
        <comment>i.e: Upload limit</comment>
        <translation type="obsolete">Limit UP</translation>
    </message>
    <message>
        <source>Choose save path</source>
        <translation>Wybierz katalog docelowy</translation>
    </message>
    <message>
        <source>Save path creation error</source>
        <translation type="obsolete">Błąd tworzenia katalogu docelowego</translation>
    </message>
    <message>
        <source>Could not create the save path</source>
        <translation type="obsolete">Nie można utworzyć katalogu docelowego</translation>
    </message>
    <message>
        <source>Set location...</source>
        <translation>Zmień położenie...</translation>
    </message>
    <message>
        <source>Preview file...</source>
        <translation>Podgląd pliku...</translation>
    </message>
    <message>
        <source>Limit upload rate...</source>
        <translation>Ogranicz prędkości wysyłania...</translation>
    </message>
    <message>
        <source>Limit download rate...</source>
        <translation>Ogranicz prędkości pobierania...</translation>
    </message>
    <message>
        <source>Move up</source>
        <comment>i.e. move up in the queue</comment>
        <translation>Przenieś w górę</translation>
    </message>
    <message>
        <source>Move down</source>
        <comment>i.e. Move down in the queue</comment>
        <translation>Przenieś w dół</translation>
    </message>
    <message>
        <source>Move to top</source>
        <comment>i.e. Move to top of the queue</comment>
        <translation>Przenieś na początek</translation>
    </message>
    <message>
        <source>Move to bottom</source>
        <comment>i.e. Move to bottom of the queue</comment>
        <translation>Przenieś na koniec</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Priorytet</translation>
    </message>
    <message>
        <source>Resume</source>
        <comment>Resume/start the torrent</comment>
        <translation>Wznów</translation>
    </message>
    <message>
        <source>Pause</source>
        <comment>Pause the torrent</comment>
        <translation>Wstrzymaj</translation>
    </message>
    <message>
        <source>Delete</source>
        <comment>Delete the torrent</comment>
        <translation>Usuń</translation>
    </message>
    <message>
        <source>Tracker</source>
        <translation type="obsolete">Tracker</translation>
    </message>
    <message>
        <source>Limit share ratio...</source>
        <translation>Ogranicz współczynnik udziału...</translation>
    </message>
</context>
<context>
    <name>UpDownRatioDlg</name>
    <message>
        <source>Torrent Upload/Download Ratio Limiting</source>
        <translation type="unfinished">Ograniczanie współczynnika udziału</translation>
    </message>
    <message>
        <source>Use global ratio limit</source>
        <translation type="unfinished">Użyj globalnego limitu</translation>
    </message>
    <message>
        <source>buttonGroup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set no ratio limit</source>
        <translation type="unfinished">Ustaw bez limitu</translation>
    </message>
    <message>
        <source>Set ratio limit to</source>
        <translation type="unfinished">Ustaw limit na</translation>
    </message>
</context>
<context>
    <name>UsageDisplay</name>
    <message>
        <source>Usage:</source>
        <translation>Użycie:</translation>
    </message>
    <message>
        <source>displays program version</source>
        <translation>wyświetlenie wersji programu</translation>
    </message>
    <message>
        <source>disable splash screen</source>
        <translation>wyłączenie ekranu startowego</translation>
    </message>
    <message>
        <source>displays this help message</source>
        <translation>wyświetlenie tego opisu</translation>
    </message>
    <message>
        <source>changes the webui port (current: %1)</source>
        <translation>zmiana portu na którym działa interfejs www (obecnie: %1)</translation>
    </message>
    <message>
        <source>[files or urls]: downloads the torrents passed by the user (optional)</source>
        <translation>[pliki lub adresy URL]: pobieranie plików torrent podanych przez użytkownika (opcjonalnie)</translation>
    </message>
</context>
<context>
    <name>about</name>
    <message>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <source>I would like to thank the following people who volunteered to translate qBittorrent:</source>
        <translation>Chciałbym podziękować następującym osobom, które wspomogły lokalizację qBittorrenta:</translation>
    </message>
    <message>
        <source>Please contact me if you would like to translate qBittorrent into your own language.</source>
        <translation>Proszę o kontakt, jeżeli chcesz pomóc w tłumaczeniu qBittorrent.</translation>
    </message>
</context>
<context>
    <name>addPeerDialog</name>
    <message>
        <source>Peer addition</source>
        <translation>Dodawanie partnera</translation>
    </message>
    <message>
        <source>IP</source>
        <translation>Adres IP</translation>
    </message>
    <message>
        <source>Port</source>
        <translation>Port</translation>
    </message>
</context>
<context>
    <name>addTorrentDialog</name>
    <message>
        <source>Torrent addition dialog</source>
        <translation>Dodatkowe informacje o pliku torrent</translation>
    </message>
    <message>
        <source>Save path:</source>
        <translation>Katalog docelowy:</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Torrent size:</source>
        <translation>Rozmiar torrenta:</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Nieznany</translation>
    </message>
    <message>
        <source>Free disk space:</source>
        <translation>Wolne miejsce na dysku:</translation>
    </message>
    <message>
        <source>Torrent content:</source>
        <translation>Zawartość torrenta:</translation>
    </message>
    <message>
        <source>Download in sequential order (slower but good for previewing)</source>
        <translation>Pobierz w kolejności sekwencyjnej (wolniejsze ale lepsze przy korzystaniu z opcji podglądu)</translation>
    </message>
    <message>
        <source>Add to download list in paused state</source>
        <translation>Dodaj tylko do listy pobierania (bez rozpoczynania pobierania)</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>Dodaj</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Anuluj</translation>
    </message>
    <message>
        <source>Normal</source>
        <translation>Normalny</translation>
    </message>
    <message>
        <source>High</source>
        <translation>Wysoki</translation>
    </message>
    <message>
        <source>Maximum</source>
        <translation>Maksymalny</translation>
    </message>
    <message>
        <source>Skip file checking and start seeding immediately</source>
        <translation>Pomiń sprawdzanie danych i natychmiast rozpocznij wysyłanie</translation>
    </message>
    <message>
        <source>Label:</source>
        <translation>Etykieta:</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Zaznacz wszystko</translation>
    </message>
    <message>
        <source>Select None</source>
        <translation>Odznacz wszystko</translation>
    </message>
    <message>
        <source>Do not download</source>
        <translation>Nie pobieraj</translation>
    </message>
</context>
<context>
    <name>authentication</name>
    <message>
        <source>Tracker authentication</source>
        <translation>Autoryzacja do tracker-a</translation>
    </message>
    <message>
        <source>Tracker:</source>
        <translation>Tracker:</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Login</translation>
    </message>
    <message>
        <source>Username:</source>
        <translation>Nazwa użytkownika:</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation>Hasło:</translation>
    </message>
    <message>
        <source>Log in</source>
        <translation>Zaloguj</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Anuluj</translation>
    </message>
</context>
<context>
    <name>confirmDeletionDlg</name>
    <message>
        <source>Deletion confirmation - qBittorrent</source>
        <translation>Potwierdzenia usuwania - qBittorrent</translation>
    </message>
    <message>
        <source>Are you sure you want to delete the selected torrents from the transfer list?</source>
        <translation>Czy na pewno usunąć wybrane pliki torrent z listy transferów?</translation>
    </message>
    <message>
        <source>Remember choice</source>
        <translation>Zapamiętaj wybór</translation>
    </message>
    <message>
        <source>Also delete the files on the hard disk</source>
        <translation>Usuń także dane z twardego dysku</translation>
    </message>
</context>
<context>
    <name>createTorrentDialog</name>
    <message>
        <source>Cancel</source>
        <translation>Anuluj</translation>
    </message>
    <message>
        <source>Torrent Creation Tool</source>
        <translation>Kreator plików torrent</translation>
    </message>
    <message>
        <source>Torrent file creation</source>
        <translation>Tworzenie pliku torrent</translation>
    </message>
    <message>
        <source>Announce urls (trackers):</source>
        <translation type="obsolete">Adres trackera:</translation>
    </message>
    <message>
        <source>Comment (optional):</source>
        <translation type="obsolete">Komentarz (opcja):</translation>
    </message>
    <message>
        <source>Web seeds urls (optional):</source>
        <translation type="obsolete">Adres seedów www (opcja):</translation>
    </message>
    <message>
        <source>File or folder to add to the torrent:</source>
        <translation>Plik lub katalog który ma zostać dodany do torrenta:</translation>
    </message>
    <message>
        <source>Add file</source>
        <translation>Dodaj plik</translation>
    </message>
    <message>
        <source>Add folder</source>
        <translation>Dodaj katalog</translation>
    </message>
    <message>
        <source>Piece size:</source>
        <translation>Rozmiar części:</translation>
    </message>
    <message>
        <source>32 KiB</source>
        <translation>32 KiB</translation>
    </message>
    <message>
        <source>64 KiB</source>
        <translation>64 KiB</translation>
    </message>
    <message>
        <source>128 KiB</source>
        <translation>128 KiB</translation>
    </message>
    <message>
        <source>256 KiB</source>
        <translation>256 KiB</translation>
    </message>
    <message>
        <source>512 KiB</source>
        <translation>512 KiB</translation>
    </message>
    <message>
        <source>1 MiB</source>
        <translation>1 MiB</translation>
    </message>
    <message>
        <source>2 MiB</source>
        <translation>2 MiB</translation>
    </message>
    <message>
        <source>4 MiB</source>
        <translation>4 MiB</translation>
    </message>
    <message>
        <source>Private (won&apos;t be distributed on DHT network if enabled)</source>
        <translation>Prywatny (gdy zaznaczone torrent nie będzie rozprowadzany w sieci DHT)</translation>
    </message>
    <message>
        <source>Start seeding after creation</source>
        <translation>Uruchom wysyłanie po utworzeniu</translation>
    </message>
    <message>
        <source>Create and save...</source>
        <translation>Tworzenie i zapisywanie...</translation>
    </message>
    <message>
        <source>Progress:</source>
        <translation>Postęp:</translation>
    </message>
    <message>
        <source>Tracker URLs:</source>
        <translation>Adresy trackerów:</translation>
    </message>
    <message>
        <source>Web seeds urls:</source>
        <translation>Adresy seedów www:</translation>
    </message>
    <message>
        <source>Comment:</source>
        <translation>Komentarz:</translation>
    </message>
    <message>
        <source>Auto</source>
        <translation>Auto</translation>
    </message>
</context>
<context>
    <name>createtorrent</name>
    <message>
        <source>Select destination torrent file</source>
        <translation type="obsolete">Wybierz plik docelowy</translation>
    </message>
    <message>
        <source>Torrent Files</source>
        <translation type="obsolete">Pliki Torrent</translation>
    </message>
    <message>
        <source>No input path set</source>
        <translation type="obsolete">Katalog źródłowy nie zdefiniowany</translation>
    </message>
    <message>
        <source>Please type an input path first</source>
        <translation type="obsolete">Proszę podać katalog żródłowy</translation>
    </message>
    <message>
        <source>Torrent creation</source>
        <translation type="obsolete">Tworzenie torrenta</translation>
    </message>
    <message>
        <source>Torrent was created successfully:</source>
        <translation type="obsolete">Utworzono plik torrent:</translation>
    </message>
    <message>
        <source>Select a folder to add to the torrent</source>
        <translation type="obsolete">Wybierz katalog który chcesz dodać do torrenta</translation>
    </message>
    <message>
        <source>Please type an announce URL</source>
        <translation type="obsolete">Wprowadź adres trackera</translation>
    </message>
    <message>
        <source>Torrent creation was unsuccessful, reason: %1</source>
        <translation type="obsolete">Nie udało się stworzyć torrenta , powód: %1</translation>
    </message>
    <message>
        <source>Announce URL:</source>
        <comment>Tracker URL</comment>
        <translation type="obsolete">Adres trackera:</translation>
    </message>
    <message>
        <source>Please type a web seed url</source>
        <translation type="obsolete">Wprowadź adres seeda www</translation>
    </message>
    <message>
        <source>Web seed URL:</source>
        <translation type="obsolete">Adres seeda www:</translation>
    </message>
    <message>
        <source>Select a file to add to the torrent</source>
        <translation type="obsolete">Wybierz plik który chcesz dodać do torrenta</translation>
    </message>
    <message>
        <source>Created torrent file is invalid. It won&apos;t be added to download list.</source>
        <translation type="obsolete">Utworzony plik torrent jest nieprawidłowy. Nie zostanie dodany do listy pobierania.</translation>
    </message>
</context>
<context>
    <name>downloadFromURL</name>
    <message>
        <source>Download Torrents from URLs</source>
        <translation type="obsolete">Pobierz pliki torrent z adresów URL</translation>
    </message>
    <message>
        <source>Only one URL per line</source>
        <translation type="obsolete">Można podać tylko jeden adres URL w jednej linii</translation>
    </message>
    <message>
        <source>Download</source>
        <translation>Pobierz</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Anuluj</translation>
    </message>
    <message>
        <source>Download from urls</source>
        <translation>Pobierz z adresów</translation>
    </message>
    <message>
        <source>No URL entered</source>
        <translation>Nie wprowadzono adresu URL</translation>
    </message>
    <message>
        <source>Please type at least one URL.</source>
        <translation>Proszę podać przynajmniej jeden adres URL.</translation>
    </message>
    <message>
        <source>Add torrent links</source>
        <translation>Dodaj odnośniki do plików torrent</translation>
    </message>
    <message>
        <source>Both HTTP and Magnet links are supported</source>
        <translation>Wspierane są zarówno odnośniki HTTP jak i Magnet</translation>
    </message>
</context>
<context>
    <name>downloadThread</name>
    <message>
        <source>I/O Error</source>
        <translation type="obsolete">Błąd We/Wy</translation>
    </message>
    <message>
        <source>The remote host name was not found (invalid hostname)</source>
        <translation type="obsolete">Nie odnaleziono nazwy zdalnego hosta (nieprawidłowa nazwa hosta)</translation>
    </message>
    <message>
        <source>The operation was canceled</source>
        <translation type="obsolete">Operacja została anulowana</translation>
    </message>
    <message>
        <source>The remote server closed the connection prematurely, before the entire reply was received and processed</source>
        <translation type="obsolete">Zdalny serwer przedwcześnie zakończył połączenie, zanim otrzymano i przetworzono odpowiedź</translation>
    </message>
    <message>
        <source>The connection to the remote server timed out</source>
        <translation type="obsolete">Przekroczono czas oczekiwania na połącznie ze zdalnym serwerem</translation>
    </message>
    <message>
        <source>SSL/TLS handshake failed</source>
        <translation type="obsolete">Niepomyślna próba negocjacji połączenie SSL/TLS</translation>
    </message>
    <message>
        <source>The remote server refused the connection</source>
        <translation type="obsolete">Zdalny serwer odrzucił połączenie</translation>
    </message>
    <message>
        <source>The connection to the proxy server was refused</source>
        <translation type="obsolete">Połączenie z serwerem proxy zostało odrzucone</translation>
    </message>
    <message>
        <source>The proxy server closed the connection prematurely</source>
        <translation type="obsolete">Serwer proxy przedwcześnie zakończył połączenie</translation>
    </message>
    <message>
        <source>The proxy host name was not found</source>
        <translation type="obsolete">Nie znaleziono nazwy hosta serwera proxy</translation>
    </message>
    <message>
        <source>The connection to the proxy timed out or the proxy did not reply in time to the request sent</source>
        <translation type="obsolete">Przkroczono czas oczekiwania na połączenie z serwerm proxy lub serwer nie odpowiedział na czas</translation>
    </message>
    <message>
        <source>The proxy requires authentication in order to honour the request but did not accept any credentials offered</source>
        <translation type="obsolete">Serwer proxy wymaga uwierzytelnienia aby zaakceptować żądanie lecz oferowane dane uwierzytelnienia zostały odrzucone</translation>
    </message>
    <message>
        <source>The access to the remote content was denied (401)</source>
        <translation type="obsolete">Odmówiono dostępu do zdalnego zasobu (401)</translation>
    </message>
    <message>
        <source>The operation requested on the remote content is not permitted</source>
        <translation type="obsolete">Żądana operacja na zdalnym zasobie nie jest dozwolona</translation>
    </message>
    <message>
        <source>The remote content was not found at the server (404)</source>
        <translation type="obsolete">Nie znaleziono zdalnego zasobu na serwerze (404)</translation>
    </message>
    <message>
        <source>The remote server requires authentication to serve the content but the credentials provided were not accepted</source>
        <translation type="obsolete">Zdalny serwer wymaga uwierzytelnienia w celu dostępu do zasobu lecz dane uwierzytelniające nie zostały zaakceptowane</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation type="obsolete">Nieznany błąd</translation>
    </message>
</context>
<context>
    <name>engineSelect</name>
    <message>
        <source>Search plugins</source>
        <translation>Wtyczki wyszukiwania</translation>
    </message>
    <message>
        <source>Installed search engines:</source>
        <translation>Zainstalowane wyszukiwarki:</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nazwa</translation>
    </message>
    <message>
        <source>Url</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Włączone</translation>
    </message>
    <message>
        <source>Install a new one</source>
        <translation>Zainstaluj nową</translation>
    </message>
    <message>
        <source>Check for updates</source>
        <translation>Sprawdź aktualizację</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Zamknij</translation>
    </message>
    <message>
        <source>Enable</source>
        <translation type="obsolete">Włącz</translation>
    </message>
    <message>
        <source>Disable</source>
        <translation type="obsolete">Wyłącz</translation>
    </message>
    <message>
        <source>Uninstall</source>
        <translation>Odinstaluj</translation>
    </message>
    <message>
        <source>You can get new search engine plugins here: &lt;a href=&quot;http://plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</source>
        <translation>Tutaj możesz pobrać nowe wtyczki wyszukiwania: &lt;a href=&quot;http:plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</translation>
    </message>
</context>
<context>
    <name>engineSelectDlg</name>
    <message>
        <source>Uninstall warning</source>
        <translation>Ostrzeżenie deinstalacji</translation>
    </message>
    <message>
        <source>Some plugins could not be uninstalled because they are included in qBittorrent.
 Only the ones you added yourself can be uninstalled.
However, those plugins were disabled.</source>
        <translation>Niektóre wtyczki nie mogą zostać usunięte, ponieważ są częścią qBittorenta.
Tylko te, które dodałeś możesz usunąć.
Jednak tamte wtyczki były wyłączone.</translation>
    </message>
    <message>
        <source>Uninstall success</source>
        <translation>Deinstalacja zakończona</translation>
    </message>
    <message>
        <source>Select search plugins</source>
        <translation>Wybierz wtyczkę wyszukiwania</translation>
    </message>
    <message>
        <source>qBittorrent search plugins</source>
        <translation>wtyczka wyszukiwania qbittorrent</translation>
    </message>
    <message>
        <source>Search plugin install</source>
        <translation>Instalacja wtyczki wyszukiwania</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Tak</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Nie</translation>
    </message>
    <message>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <source>A more recent version of %1 search engine plugin is already installed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>Najnowsza wersja wtyczki wyszukiwania %1 jest już zainstalowana.</translation>
    </message>
    <message>
        <source>Search plugin update</source>
        <translation>Aktualizacja wtyczki wyszukiwania</translation>
    </message>
    <message>
        <source>Sorry, update server is temporarily unavailable.</source>
        <translation>Sorry, czasowo niedostępny serwer aktualizacji.</translation>
    </message>
    <message>
        <source>All your plugins are already up to date.</source>
        <translation>Wszystkie twoje wtyczki są aktualne.</translation>
    </message>
    <message>
        <source>All selected plugins were uninstalled successfully</source>
        <translation>Wszystkie wybrane wtyczki zostały zainstalowane</translation>
    </message>
    <message>
        <source>%1 search engine plugin could not be updated, keeping old version.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>Nie można zaktualizować wtyczki wyszukiwania %1, pozostaje stara wersja.</translation>
    </message>
    <message>
        <source>%1 search engine plugin could not be installed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>Wtyczka wyszukiwania %1 nie może być zainstalowana.</translation>
    </message>
    <message>
        <source>%1 search engine plugin was successfully updated.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>Pomyślnie zaktualizowano wtyczkę wyszukiwania %1.</translation>
    </message>
    <message>
        <source>%1 search engine plugin was successfully installed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>Pomyślnie zainstalowano wtyczkę wyszukiwania %1.</translation>
    </message>
    <message>
        <source>Sorry, %1 search plugin install failed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>Błąd instalacji wtyczki wyszukiwania %1.</translation>
    </message>
    <message>
        <source>New search engine plugin URL</source>
        <translation>URL nowej wtyczki wyszukiwania</translation>
    </message>
    <message>
        <source>URL:</source>
        <translation>URL:</translation>
    </message>
</context>
<context>
    <name>misc</name>
    <message>
        <source>B</source>
        <comment>bytes</comment>
        <translation>B</translation>
    </message>
    <message>
        <source>KiB</source>
        <comment>kibibytes (1024 bytes)</comment>
        <translation>KiB</translation>
    </message>
    <message>
        <source>MiB</source>
        <comment>mebibytes (1024 kibibytes)</comment>
        <translation>MiB</translation>
    </message>
    <message>
        <source>GiB</source>
        <comment>gibibytes (1024 mibibytes)</comment>
        <translation>GiB</translation>
    </message>
    <message>
        <source>TiB</source>
        <comment>tebibytes (1024 gibibytes)</comment>
        <translation>TiB</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Nieznany</translation>
    </message>
    <message>
        <source>Unknown</source>
        <comment>Unknown (size)</comment>
        <translation>Nieznany</translation>
    </message>
    <message>
        <source>&lt; 1m</source>
        <comment>&lt; 1 minute</comment>
        <translation>&lt; 1m</translation>
    </message>
    <message>
        <source>%1m</source>
        <comment>e.g: 10minutes</comment>
        <translation>%1m</translation>
    </message>
    <message>
        <source>%1h %2m</source>
        <comment>e.g: 3hours 5minutes</comment>
        <translation>%1h %2m</translation>
    </message>
    <message>
        <source>%1d %2h</source>
        <comment>e.g: 2days 10hours</comment>
        <translation>%1d %2h</translation>
    </message>
    <message>
        <source>qBittorrent will shutdown the computer now because all downloads are complete.</source>
        <translation>qBittorrent wyłączy teraz komputer, ponieważ pobieranie zostało ukończone.</translation>
    </message>
</context>
<context>
    <name>options_imp</name>
    <message>
        <source>Choose a save directory</source>
        <translation>Wybierz katalog docelowy</translation>
    </message>
    <message>
        <source>Choose an ip filter file</source>
        <translation>Wybierz plik filtra IP</translation>
    </message>
    <message>
        <source>Filters</source>
        <translation>Filtry</translation>
    </message>
    <message>
        <source>Choose export directory</source>
        <translation>Wybierz katalog eksportu</translation>
    </message>
    <message>
        <source>Add directory to scan</source>
        <translation>Dodaj katalog do przeszukiwania</translation>
    </message>
    <message>
        <source>Folder is already being watched.</source>
        <translation>Katalog jest już obserwowany.</translation>
    </message>
    <message>
        <source>Folder does not exist.</source>
        <translation>Katalog nie istnieje.</translation>
    </message>
    <message>
        <source>Folder is not readable.</source>
        <translation>Nie można czytać katalogu.</translation>
    </message>
    <message>
        <source>Failure</source>
        <translation>Błąd</translation>
    </message>
    <message>
        <source>Failed to add Scan Folder &apos;%1&apos;: %2</source>
        <translation>Błąd podczas dodawania katalogu do obserwowanych &apos;%1&apos;: %2</translation>
    </message>
    <message>
        <source>Parsing error</source>
        <translation>Błąd przetwarzania</translation>
    </message>
    <message>
        <source>Failed to parse the provided IP filter</source>
        <translation>Nie udało się przetworzyć podanego filtra IP</translation>
    </message>
    <message>
        <source>Succesfully refreshed</source>
        <translation type="obsolete">Przeładowano pomyślnie</translation>
    </message>
    <message>
        <source>Successfuly parsed the provided IP filter: %1 rules were applied.</source>
        <comment>%1 is a number</comment>
        <translation>Pomyślnie przetworzono podany filtr IP: zastosowano %1 reguł.</translation>
    </message>
    <message>
        <source>Successfully refreshed</source>
        <translatorcomment>filtr czy lista?</translatorcomment>
        <translation type="unfinished">Pomyślnie odświeżony</translation>
    </message>
    <message>
        <source>Invalid key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This is not a valid SSL key.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid certificate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This is not a valid SSL certificate.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SSL Certificate (*.crt *.pem)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SSL Key (*.key *.pem)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>pluginSourceDlg</name>
    <message>
        <source>Plugin source</source>
        <translation>Źródło wtyczki</translation>
    </message>
    <message>
        <source>Search plugin source:</source>
        <translation>Źródło wtyczki wyszukiwania:</translation>
    </message>
    <message>
        <source>Local file</source>
        <translation>Plik lokalny</translation>
    </message>
    <message>
        <source>Web link</source>
        <translation>Adres strony</translation>
    </message>
</context>
<context>
    <name>preview</name>
    <message>
        <source>Preview selection</source>
        <translation>Podgląd wybranego</translation>
    </message>
    <message>
        <source>File preview</source>
        <translation>Podgląd pliku</translation>
    </message>
    <message>
        <source>The following files support previewing, &lt;br&gt;please select one of them:</source>
        <translation>Istnieje możliwość podglądu następujących typów plików, &lt;br&gt; proszę wybrać jeden z nich:</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Podgląd</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Anuluj</translation>
    </message>
</context>
<context>
    <name>previewSelect</name>
    <message>
        <source>Preview impossible</source>
        <translation type="obsolete">Nie ma możliwości podglądu</translation>
    </message>
    <message>
        <source>Sorry, we can&apos;t preview this file</source>
        <translation type="obsolete">Przepraszamy, podgląd pliku jest niedostępny</translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="obsolete">Nazwa</translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="obsolete">Rozmiar</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation type="obsolete">Postęp</translation>
    </message>
</context>
<context>
    <name>search_engine</name>
    <message>
        <source>Search</source>
        <translation>Szukaj</translation>
    </message>
    <message>
        <source>Status:</source>
        <translation>Status:</translation>
    </message>
    <message>
        <source>Stopped</source>
        <translation>Zatrzymany</translation>
    </message>
    <message>
        <source>Download</source>
        <translation>Pobierz</translation>
    </message>
    <message>
        <source>Search engines...</source>
        <translation>Wtyczki wyszukiwania...</translation>
    </message>
    <message>
        <source>Go to description page</source>
        <translation>Otwórz stronę z opisem</translation>
    </message>
</context>
<context>
    <name>torrentAdditionDialog</name>
    <message>
        <source>Unable to decode torrent file:</source>
        <translation>Problem z odkodowaniem pliku torrent:</translation>
    </message>
    <message>
        <source>Choose save path</source>
        <translation>Wybierz katalog docelowy</translation>
    </message>
    <message>
        <source>(%1 left after torrent download)</source>
        <comment>e.g. (100MiB left after torrent download)</comment>
        <translation>(%1 po pobraniu torrenta)</translation>
    </message>
    <message>
        <source>(%1 more are required to download)</source>
        <comment>e.g. (100MiB more are required to download)</comment>
        <translation>(aby pobrać torrenta potrzeba jeszcze %1 wolnego miejsca)</translation>
    </message>
    <message>
        <source>Empty save path</source>
        <translation>Niepoprawny katalog docelowy</translation>
    </message>
    <message>
        <source>Please enter a save path</source>
        <translation>Podaj katalog docelowy</translation>
    </message>
    <message>
        <source>Save path creation error</source>
        <translation>Błąd tworzenia katalogu docelowego</translation>
    </message>
    <message>
        <source>Could not create the save path</source>
        <translation>Nie można założyć katalogu docelowego</translation>
    </message>
    <message>
        <source>Invalid file selection</source>
        <translation>Wybrano niepoprawny plik</translation>
    </message>
    <message>
        <source>You must select at least one file in the torrent</source>
        <translation>Musisz wybrać przynajmniej jeden plik z pliku torrent</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Priorytet</translation>
    </message>
    <message>
        <source>Seeding mode error</source>
        <translation>Błąd trybu rozsiewania</translation>
    </message>
    <message>
        <source>You chose to skip file checking. However, local files do not seem to exist in the current destionation folder. Please disable this feature or update the save path.</source>
        <translation>Wybrano pomijanie sprawdzania pliku, jednak pliki lokalne prawdopodobnie nie istnieją w aktualnym katalogu pobierań. Należy wyłączyć tą opcję lub zaktualizować katalog zapisu.</translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation>Zmień nazwę...</translation>
    </message>
    <message>
        <source>New name:</source>
        <translation>Nowa nazwa:</translation>
    </message>
    <message>
        <source>The file could not be renamed</source>
        <translation>Nie można zmienić nazwy pliku</translation>
    </message>
    <message>
        <source>This name is already in use in this folder. Please use a different name.</source>
        <translation>Wybrana nazwa jest już używana w tym katalogu. Proszę wybrać inną nazwę.</translation>
    </message>
    <message>
        <source>The folder could not be renamed</source>
        <translation>Nie można zmienić nazwy katalogu</translation>
    </message>
    <message>
        <source>Rename the file</source>
        <translation>Zmień nazwę pliku</translation>
    </message>
    <message>
        <source>Unable to decode magnet link:</source>
        <translation>Nie można odczytać adresu magnet:</translation>
    </message>
    <message>
        <source>Magnet Link</source>
        <translation>Adres magnet</translation>
    </message>
    <message>
        <source>Invalid label name</source>
        <translation>Nieprawidłowa nazwa etykiety</translation>
    </message>
    <message>
        <source>Please don&apos;t use any special characters in the label name.</source>
        <translation>Nie należy używać żadnych znaków specjalnych w nazwach etykiet.</translation>
    </message>
    <message>
        <source>This file name contains forbidden characters, please choose a different one.</source>
        <translation>Nazwa pliku zawiera zabronione znaki, proszę wybrać inną nazwę.</translation>
    </message>
</context>
</TS>
