<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="es_ES">
<context>
    <name>AboutDlg</name>
    <message>
        <location filename="../about.ui" line="21"/>
        <source>About qBittorrent</source>
        <translation>Acerca de qBittorrent</translation>
    </message>
    <message>
        <location filename="../about.ui" line="83"/>
        <source>About</source>
        <translation>Acerca de</translation>
    </message>
    <message utf8="true">
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;A Bittorrent client programmed in C++, based on Qt4 toolkit &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;and libtorrent-rasterbar. &lt;br /&gt;&lt;br /&gt;Copyright ©2006-2010 Christophe Dumez&lt;br /&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Home Page:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://www.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;http://www.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Forum:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://forum.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;http://forum.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;IRC:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; #qbittorrent on Freenode&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;Es un cliente Bittorrent programado en C++, basado en Qt4 toolkit &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;y libtorrent-rasterbar. &lt;br /&gt;&lt;br /&gt;Copyright ©2006-2010 Christophe Dumez&lt;br /&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Página Oficial:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://www.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;http://www.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Forum:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://forum.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;http://forum.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;IRC:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; #qbittorrent on Freenode&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../about.ui" line="134"/>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
    <message>
        <location filename="../about.ui" line="157"/>
        <source>Name:</source>
        <translation>Nombre:</translation>
    </message>
    <message>
        <location filename="../about.ui" line="195"/>
        <source>Country:</source>
        <translation>País:</translation>
    </message>
    <message>
        <location filename="../about.ui" line="220"/>
        <source>E-mail:</source>
        <translation>E-Mail:</translation>
    </message>
    <message>
        <location filename="../about.ui" line="164"/>
        <source>Christophe Dumez</source>
        <translation>Christophe Dumez</translation>
    </message>
    <message utf8="true">
        <location filename="../about.ui" line="105"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;An advanced BitTorrent client programmed in C++, based on Qt4 toolkit and libtorrent-rasterbar. &lt;br /&gt;&lt;br /&gt;Copyright ©2006-2011 Christophe Dumez&lt;br /&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Home Page:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://www.qbittorrent.org&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans&apos;; text-decoration: underline; color:#0057ae;&quot;&gt;http://www.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Bug Tracker:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://bugs.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;http://bugs.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Forum:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://forum.qbittorrent.org&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans&apos;; text-decoration: underline; color:#0057ae;&quot;&gt;http://forum.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;IRC:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; #qbittorrent on Freenode&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;Cliente avanzado Bittorrent programado en C++, basado en Qt4 toolkit y libtorrent-rasterbar. &lt;br /&gt;&lt;br /&gt;Copyright ©2006-2011 Christophe Dumez&lt;br /&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Home Page:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://www.qbittorrent.org&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans&apos;; text-decoration: underline; color:#0057ae;&quot;&gt;http://www.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Bug Tracker:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://bugs.qbittorrent.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;http://bugs.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;Forum:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;http://forum.qbittorrent.org&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans&apos;; text-decoration: underline; color:#0057ae;&quot;&gt;http://forum.qbittorrent.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; text-decoration: underline;&quot;&gt;IRC:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt; #qbittorrent on Freenode&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../about.ui" line="202"/>
        <source>France</source>
        <translation>Francia</translation>
    </message>
    <message>
        <location filename="../about.ui" line="264"/>
        <source>Translation</source>
        <translation>Traducción</translation>
    </message>
    <message>
        <location filename="../about.ui" line="281"/>
        <source>License</source>
        <translation>Licencia</translation>
    </message>
    <message>
        <location filename="../about.ui" line="54"/>
        <source>&lt;h3&gt;&lt;b&gt;qBittorrent&lt;/b&gt;&lt;/h3&gt;</source>
        <translation>&lt;h3&gt;&lt;b&gt;qBittorrent&lt;/b&gt;&lt;/h3&gt;</translation>
    </message>
    <message>
        <location filename="../about.ui" line="227"/>
        <source>chris@qbittorrent.org</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../about.ui" line="251"/>
        <source>Thanks to</source>
        <translation>Gracias a</translation>
    </message>
</context>
<context>
    <name>AdvancedSettings</name>
    <message>
        <source>Property</source>
        <translation type="obsolete">Prioridad</translation>
    </message>
    <message>
        <source>Value</source>
        <translation type="obsolete">Valor</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="160"/>
        <source>Disk write cache size</source>
        <translation>Tamaño cache del Disco</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="159"/>
        <source> MiB</source>
        <translation> MiB</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="165"/>
        <source>Outgoing ports (Min) [0: Disabled]</source>
        <translation>Puertos de salida (Min) [0: Desactivado]</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="170"/>
        <source>Outgoing ports (Max) [0: Disabled]</source>
        <translation>Puertos de salida (Max) [0: Desactivado]</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="176"/>
        <source>Recheck torrents on completion</source>
        <translation>Verificar Torrents completados</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="182"/>
        <source>Transfer list refresh interval</source>
        <translation>Intervalo de actualización de las listas de transferencia</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="181"/>
        <source> ms</source>
        <comment> milliseconds</comment>
        <translation> ms</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="50"/>
        <source>Setting</source>
        <translation>Ajustes</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="50"/>
        <source>Value</source>
        <comment>Value set for this setting</comment>
        <translation>Valor</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="185"/>
        <source>Resolve peer countries (GeoIP)</source>
        <translation>Mostrar Pares por Países (GeoIP)</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="188"/>
        <source>Resolve peer host names</source>
        <translation>Mostrar Pares por nombre de Host</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="193"/>
        <source>Maximum number of half-open connections [0: Disabled]</source>
        <translation>Número máximo de conexiones abiertas [0: Desactivado]</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="200"/>
        <source>Strict super seeding</source>
        <translation>Siembra super estricta</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="212"/>
        <source>Network Interface (requires restart)</source>
        <translation>Selección de Red (es necesario reiniciar)</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="240"/>
        <source>Exchange trackers with other peers</source>
        <translation>Intercambio de pares con otros trackers</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="202"/>
        <source>Any interface</source>
        <comment>i.e. Any network interface</comment>
        <translation>Cualquier Red</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="215"/>
        <source>IP Address to report to trackers (requires restart)</source>
        <translation>Dirección IP para informe de incidencias a los trackers (es necesario reiniciar)</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="218"/>
        <source>Display program on-screen notifications</source>
        <translation>Visualización en pantalla de las notificaciones</translation>
    </message>
    <message>
        <source>Display program notification balloons</source>
        <translation type="obsolete">Mostrar globos de notificación</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="221"/>
        <source>Enable embedded tracker</source>
        <translation>Habilitar integración de tracker</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="226"/>
        <source>Embedded tracker port</source>
        <translation>Puerto de integración de tracker</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="229"/>
        <source>Check for software updates</source>
        <translation>Comprobar si hay actualizaciones</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="233"/>
        <source>Use system icon theme</source>
        <translation>Usar iconos del tema actual</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="237"/>
        <source>Confirm torrent deletion</source>
        <translation>Confirmar la eliminación del torrent</translation>
    </message>
    <message>
        <source>Display program notification baloons</source>
        <translation type="obsolete">Mostrar globos de notificación</translation>
    </message>
    <message>
        <location filename="../preferences/advancedsettings.h" line="173"/>
        <source>Ignore transfer limits on local network</source>
        <translation>Ignorar limites de transferencia de la red local</translation>
    </message>
    <message>
        <source>Include TCP/IP overhead in transfer limits</source>
        <translation type="obsolete">Incluir TCP / IP en los límites generales de transferencia</translation>
    </message>
</context>
<context>
    <name>AutomatedRssDownloader</name>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="14"/>
        <source>Automated RSS Downloader</source>
        <translation>Automatizar Descarga canales RSS</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="26"/>
        <source>Enable the automated RSS downloader</source>
        <translation>Activar Descarga automatizada de canales RSS</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="48"/>
        <source>Download rules</source>
        <translation>Reglas de Descargas</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="123"/>
        <source>Rule definition</source>
        <translation>Definición de reglas</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="138"/>
        <source>Must contain:</source>
        <translation>Debe contener:</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="180"/>
        <source>Must not contain:</source>
        <translation>No debe contener:</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="129"/>
        <source>Use regular expressions</source>
        <translation>Usar expresiones regulares</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="355"/>
        <source>Import...</source>
        <translation>Importar...</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="362"/>
        <source>Export...</source>
        <translation>Exportar...</translation>
    </message>
    <message>
        <source>Save torrent to:</source>
        <translation type="obsolete">Guardar torrent en:</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="286"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="233"/>
        <source>Assign label:</source>
        <translation>Etiquetar como:</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="252"/>
        <source>Save to a different directory</source>
        <translation>Guardar en un directorio diferente</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="264"/>
        <source>Save to:</source>
        <translation>Guardar en:</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="308"/>
        <source>Apply rule to feeds:</source>
        <translation>Aplicar reglas a los canales:</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.ui" line="330"/>
        <source>Matching RSS articles</source>
        <translation>Coincidencia de canales RSS</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="304"/>
        <source>New rule name</source>
        <translation>Nueva regla</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="304"/>
        <source>Please type the name of the new download rule.</source>
        <translation>Por favor, escriba el nombre de la nueva regla a descargar.</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="308"/>
        <location filename="../rss/automatedrssdownloader.cpp" line="423"/>
        <source>Rule name conflict</source>
        <translation>Conflicto con el nombre de la regla</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="308"/>
        <location filename="../rss/automatedrssdownloader.cpp" line="423"/>
        <source>A rule with this name already exists, please choose another name.</source>
        <translation>Ya existena una regla con este nombre, por favor, elija otro nombre.</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="326"/>
        <source>Are you sure you want to remove the download rule named %1?</source>
        <translation>¿Está seguro que desea eliminar la regla de transferencia llamada %1?</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="328"/>
        <source>Are you sure you want to remove the selected download rules?</source>
        <translation>¿Está seguro que desea eliminar las normas de descargas seleccionadas?</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="329"/>
        <source>Rule deletion confirmation</source>
        <translation>Confirmar eliminar regla</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="345"/>
        <source>Destination directory</source>
        <translation>Directorio de destino</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="353"/>
        <source>Invalid action</source>
        <translation>Acción no válida</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="353"/>
        <source>The list is empty, there is nothing to export.</source>
        <translation>La lista está vacía, no hay nada para exportar.</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="357"/>
        <source>Where would you like to save the list?</source>
        <translation>¿Dónde le gustaría guardar la lista?</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="357"/>
        <source>Rules list (*.rssrules)</source>
        <translation>Lista de reglas (*.rssrules)</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="362"/>
        <source>I/O Error</source>
        <translation>Error de Entrada/Salida</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="362"/>
        <source>Failed to create the destination file</source>
        <translation>No se pudo crear el archivo de destino</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="370"/>
        <source>Please point to the RSS download rules file</source>
        <translation>Por favor, seleccione las normas de descarga de canales RSS</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="370"/>
        <source>Rules list (*.rssrules *.filters)</source>
        <translation>Lista de reglas (*.rssrules *.filters)</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="374"/>
        <source>Import Error</source>
        <translation>Error al importar</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="374"/>
        <source>Failed to import the selected rules file</source>
        <translation>No se pudo importar el archivo de reglas seleccionado</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="385"/>
        <source>Add new rule...</source>
        <translation>Añadir nueva regla...</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="391"/>
        <source>Delete rule</source>
        <translation>Eliminar regla</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="393"/>
        <source>Rename rule...</source>
        <translation>Renombrar regla...</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="395"/>
        <source>Delete selected rules</source>
        <translation>Eliminar reglas seleccionadas</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="419"/>
        <source>Rule renaming</source>
        <translation>Regla renombrada</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="419"/>
        <source>Please type the new rule name</source>
        <translation>Por favor, escriba el nombre de la nueva regla</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="521"/>
        <source>Regex mode: use Perl-like regular expressions</source>
        <translation>Modo Regex: usar Perl-like  en expresiones regulares</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="525"/>
        <source>Wildcard mode: you can use&lt;ul&gt;&lt;li&gt;? to match any single character&lt;/li&gt;&lt;li&gt;* to match zero or more of any characters&lt;/li&gt;&lt;li&gt;Whitespaces count as AND operators&lt;/li&gt;&lt;/ul&gt;</source>
        <translation>Uso de comodines: se puede usar&lt;ul&gt;&lt;li&gt;? para que coincida con cualquier carácter individual&lt;/li&gt;&lt;li&gt;* para hacer coincidir cero o más de los caracteres&lt;/li&gt;&lt;li&gt; como Espacios en blanco y &lt;/li&gt;&lt;/ul&gt; para el operadore AND</translation>
    </message>
    <message>
        <location filename="../rss/automatedrssdownloader.cpp" line="527"/>
        <source>Wildcard mode: you can use&lt;ul&gt;&lt;li&gt;? to match any single character&lt;/li&gt;&lt;li&gt;* to match zero or more of any characters&lt;/li&gt;&lt;li&gt;| is used as OR operator&lt;/li&gt;&lt;/ul&gt;</source>
        <translation>Uso de comodines: se puede usar&lt;ul&gt;&lt;li&gt;? para que coincida con cualquier carácter individual&lt;/li&gt;&lt;li&gt;* para hacer coincidir cero o más de los caracteres&lt;/li&gt;&lt;li&gt; como Espacios en blanco y &lt;/li&gt;&lt;/ul&gt; para el operadore OR</translation>
    </message>
</context>
<context>
    <name>Bittorrent</name>
    <message>
        <source>%1 reached the maximum ratio you set.</source>
        <translation type="obsolete">%1 alcanzó el ratio máximo establecido.</translation>
    </message>
    <message>
        <source>Removing torrent %1...</source>
        <translation type="obsolete">Extrayendo torrent %1...</translation>
    </message>
    <message>
        <source>Pausing torrent %1...</source>
        <translation type="obsolete">Torrent Pausado %1...</translation>
    </message>
    <message>
        <source>qBittorrent is bound to port: TCP/%1</source>
        <comment>e.g: qBittorrent is bound to port: 6881</comment>
        <translation type="obsolete">qBittorrent está usando el puerto: TCP/%1</translation>
    </message>
    <message>
        <source>UPnP support [ON]</source>
        <translation type="obsolete">Soporte para UPnP [Encendido]</translation>
    </message>
    <message>
        <source>UPnP support [OFF]</source>
        <translation type="obsolete">Soporte para UPnP [Apagado]</translation>
    </message>
    <message>
        <source>NAT-PMP support [ON]</source>
        <translation type="obsolete">Soporte para NAT-PMP [Encendido]</translation>
    </message>
    <message>
        <source>NAT-PMP support [OFF]</source>
        <translation type="obsolete">Soporte para NAT-PMP[Apagado]</translation>
    </message>
    <message>
        <source>HTTP user agent is %1</source>
        <translation type="obsolete">HTTP de usuario es %1</translation>
    </message>
    <message>
        <source>Using a disk cache size of %1 MiB</source>
        <translation type="obsolete">Tamaño cache del Disco %1 MiB</translation>
    </message>
    <message>
        <source>DHT support [ON], port: UDP/%1</source>
        <translation type="obsolete">Soporte para DHT [Encendido], puerto: UPD/%1</translation>
    </message>
    <message>
        <source>DHT support [OFF]</source>
        <translation type="obsolete">Soporte para DHT [Apagado]</translation>
    </message>
    <message>
        <source>PeX support [ON]</source>
        <translation type="obsolete">Soporte para PeX [Encendido]</translation>
    </message>
    <message>
        <source>PeX support [OFF]</source>
        <translation type="obsolete">Soporte PeX [Apagado]</translation>
    </message>
    <message>
        <source>Restart is required to toggle PeX support</source>
        <translation type="obsolete">Es necesario reiniciar para activar soporte PeX</translation>
    </message>
    <message>
        <source>Local Peer Discovery [ON]</source>
        <translation type="obsolete">Estado local de Pares [Encendido]</translation>
    </message>
    <message>
        <source>Local Peer Discovery support [OFF]</source>
        <translation type="obsolete">Soporte para estado local de Pares [Apagado]</translation>
    </message>
    <message>
        <source>Encryption support [ON]</source>
        <translation type="obsolete">Soporte para encriptado [Encendido]</translation>
    </message>
    <message>
        <source>Encryption support [FORCED]</source>
        <translation type="obsolete">Soporte para encriptado [Forzado]</translation>
    </message>
    <message>
        <source>Encryption support [OFF]</source>
        <translation type="obsolete">Sopote para encriptado [Apagado]</translation>
    </message>
    <message>
        <source>The Web UI is listening on port %1</source>
        <translation type="obsolete">Puerto de escucha de Interfaz Usuario Web %1</translation>
    </message>
    <message>
        <source>Web User Interface Error - Unable to bind Web UI to port %1</source>
        <translation type="obsolete">Error interfaz de Usuario Web - No se puede enlazar al puerto %1</translation>
    </message>
    <message>
        <source>&apos;%1&apos; was removed from transfer list and hard disk.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation type="obsolete">&apos;%1&apos; Fue eliminado de la lista de transferencia y del disco.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; was removed from transfer list.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation type="obsolete">&apos;%1&apos; Fue eliminado de la lista de transferencia.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is not a valid magnet URI.</source>
        <translation type="obsolete">&apos;%1&apos; no es una URI válida.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is already in download list.</source>
        <comment>e.g: &apos;xxx.avi&apos; is already in download list.</comment>
        <translation type="obsolete">&apos;%1&apos; ya está en la lista de descargas.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; resumed. (fast resume)</source>
        <comment>&apos;/home/y/xxx.torrent&apos; was resumed. (fast resume)</comment>
        <translation type="obsolete">&apos;%1&apos; reiniciado. (reinicio rápido)</translation>
    </message>
    <message>
        <source>&apos;%1&apos; added to download list.</source>
        <comment>&apos;/home/y/xxx.torrent&apos; was added to download list.</comment>
        <translation type="obsolete">&apos;%1&apos; agregado a la lista de descargas.</translation>
    </message>
    <message>
        <source>Unable to decode torrent file: &apos;%1&apos;</source>
        <comment>e.g: Unable to decode torrent file: &apos;/home/y/xxx.torrent&apos;</comment>
        <translation type="obsolete">Imposible decodificar el archivo torrent: &apos;%1&apos;</translation>
    </message>
    <message>
        <source>This file is either corrupted or this isn&apos;t a torrent.</source>
        <translation type="obsolete">Este archivo puede estar corrupto, o no ser un torrent.</translation>
    </message>
    <message>
        <source>Note: new trackers were added to the existing torrent.</source>
        <translation type="obsolete">Nota: nuevos Trackers se han añadido al torrent existente.</translation>
    </message>
    <message>
        <source>Note: new URL seeds were added to the existing torrent.</source>
        <translation type="obsolete">Nota: nuevas semillas URL se han añadido al Torrent existente.</translation>
    </message>
    <message>
        <source>Error: The torrent %1 does not contain any file.</source>
        <translation type="obsolete">Error: este torrent %1 no contiene ningún archivo.</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;was blocked due to your IP filter&lt;/i&gt;</source>
        <comment>x.y.z.w was blocked</comment>
        <translation type="obsolete">&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;fue bloqueado debido al filtro IP&lt;/i&gt;</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;was banned due to corrupt pieces&lt;/i&gt;</source>
        <comment>x.y.z.w was banned</comment>
        <translation type="obsolete">&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;Fue bloqueado debido a fragmentos corruptos&lt;/i&gt;</translation>
    </message>
    <message>
        <source>Recursive download of file %1 embedded in torrent %2</source>
        <comment>Recursive download of test.torrent embedded in torrent test2</comment>
        <translation type="obsolete">Descarga recursiva de archivo %1 inscrustada en Torrent %2</translation>
    </message>
    <message>
        <source>Unable to decode %1 torrent file.</source>
        <translation type="obsolete">No se puede descodificar %1 archivo torrent.</translation>
    </message>
    <message>
        <source>UPnP/NAT-PMP: Port mapping failure, message: %1</source>
        <translation type="obsolete">UPnP/NAT-PMP: Falló el mapeo del puerto, mensaje: %1</translation>
    </message>
    <message>
        <source>UPnP/NAT-PMP: Port mapping successful, message: %1</source>
        <translation type="obsolete">UPnP/NAT-PMP: Mapeo del puerto exitoso, mensaje: %1</translation>
    </message>
    <message>
        <source>Fast resume data was rejected for torrent %1, checking again...</source>
        <translation type="obsolete">Se negaron los datos para reinicio rápido del torrent: %1, verificando de nuevo...</translation>
    </message>
    <message>
        <source>Reason: %1</source>
        <translation type="obsolete">Razón: %1</translation>
    </message>
    <message>
        <source>Torrent name: %1</source>
        <translation type="obsolete">Nombre del torrent: %1</translation>
    </message>
    <message>
        <source>Torrent size: %1</source>
        <translation type="obsolete">Tamaño del torrent: %1</translation>
    </message>
    <message>
        <source>Save path: %1</source>
        <translation type="obsolete">Guardar ruta: %1</translation>
    </message>
    <message>
        <source>The torrent was downloaded in %1.</source>
        <comment>The torrent was downloaded in 1 hour and 20 seconds</comment>
        <translation type="obsolete">El torrernt se descargó en %1.</translation>
    </message>
    <message>
        <source>Thank you for using qBittorrent.</source>
        <translation type="obsolete">Gracias por utilizar qBittorrent.</translation>
    </message>
    <message>
        <source>[qBittorrent] %1 has finished downloading</source>
        <translation type="obsolete">[qBittorrent] %1 ha finalizado la descarga</translation>
    </message>
    <message>
        <source>An I/O error occured, &apos;%1&apos; paused.</source>
        <translation type="obsolete">Error de E/S ocurrido, &apos;%1&apos; pausado.</translation>
    </message>
    <message>
        <source>File sizes mismatch for torrent %1, pausing it.</source>
        <translation type="obsolete">El tamaño de archivo no coincide con el torrent %1, pausandolo.</translation>
    </message>
    <message>
        <source>Url seed lookup failed for url: %1, message: %2</source>
        <translation type="obsolete">Falló la búsqueda de semilla por Url para la Url: %1, mensaje: %2</translation>
    </message>
    <message>
        <source>Downloading &apos;%1&apos;, please wait...</source>
        <comment>e.g: Downloading &apos;xxx.torrent&apos;, please wait...</comment>
        <translation type="obsolete">Descargando &apos;%1&apos;, por favor espere...</translation>
    </message>
</context>
<context>
    <name>ConsoleDlg</name>
    <message>
        <source>qBittorrent log viewer</source>
        <translation type="obsolete">qBittorrent visor de registros</translation>
    </message>
    <message>
        <source>General</source>
        <translation type="obsolete">General</translation>
    </message>
    <message>
        <source>Blocked IPs</source>
        <translation type="obsolete">IPs bloqueadas</translation>
    </message>
</context>
<context>
    <name>CookiesDlg</name>
    <message>
        <location filename="../rss/cookiesdlg.ui" line="14"/>
        <source>Cookies management</source>
        <translation>Administración de Cookies</translation>
    </message>
    <message>
        <location filename="../rss/cookiesdlg.ui" line="36"/>
        <source>Key</source>
        <extracomment>As in Key/Value pair</extracomment>
        <translation>Clave</translation>
    </message>
    <message>
        <location filename="../rss/cookiesdlg.ui" line="41"/>
        <source>Value</source>
        <extracomment>As in Key/Value pair</extracomment>
        <translation>Valor</translation>
    </message>
    <message>
        <location filename="../rss/cookiesdlg.cpp" line="48"/>
        <source>Common keys for cookies are : &apos;%1&apos;, &apos;%2&apos;.
You should get this information from your Web browser preferences.</source>
        <translation>Las Claves para las Cookies son : &apos;%1&apos;, &apos;%2&apos;
Debe obtener esta información de las preferencias de su navegador Web.</translation>
    </message>
</context>
<context>
    <name>DNSUpdater</name>
    <message>
        <location filename="../dnsupdater.cpp" line="178"/>
        <source>Your dynamic DNS was successfuly updated.</source>
        <translation>DNS dinámica actualizada con éxito.</translation>
    </message>
    <message>
        <location filename="../dnsupdater.cpp" line="182"/>
        <source>Dynamic DNS error: The service is temporarily unavailable, it will be retried in 30 minutes.</source>
        <translation>Error de DNS dinámica: El servicio no está disponible temporalmente, nuevo reintento en 30 minutos.</translation>
    </message>
    <message>
        <location filename="../dnsupdater.cpp" line="192"/>
        <source>Dynamic DNS error: hostname supplied does not exist under specified account.</source>
        <translation>Error de DNS dinámica: el nombre de host proporcionado no existe en la cuenta especificada.</translation>
    </message>
    <message>
        <location filename="../dnsupdater.cpp" line="198"/>
        <source>Dynamic DNS error: Invalid username/password.</source>
        <translation>Error DNS dinámica: nombre de usuario/contraseña no válidas.</translation>
    </message>
    <message>
        <location filename="../dnsupdater.cpp" line="203"/>
        <source>Dynamic DNS error: qBittorrent was blacklisted by the service, please report a bug at http://bugs.qbittorrent.org.</source>
        <translation>Error de DNS dinámica: qBittorrent ha sido incluido en la Lista Negra, por favor, informar de ésto en http://bugs.qbittorrent.org.</translation>
    </message>
    <message>
        <location filename="../dnsupdater.cpp" line="209"/>
        <source>Dynamic DNS error: %1 was returned by the service, please report a bug at http://bugs.qbittorrent.org.</source>
        <translation>Error de DNS dinámica: %1 fue rechazado por el servicio, por favor, informe de este error en http://bugs.qbittorrent.org.</translation>
    </message>
    <message>
        <location filename="../dnsupdater.cpp" line="215"/>
        <source>Dynamic DNS error: Your username was blocked due to abuse.</source>
        <translation>Error de DNS dinámica: Su nombre de usuario fue bloqueado debido a excesos.</translation>
    </message>
    <message>
        <location filename="../dnsupdater.cpp" line="236"/>
        <source>Dynamic DNS error: supplied domain name is invalid.</source>
        <translation>Error de DNS dinámica: nombre de dominio proporcionado no válido.</translation>
    </message>
    <message>
        <location filename="../dnsupdater.cpp" line="248"/>
        <source>Dynamic DNS error: supplied username is too short.</source>
        <translation>Error de DNS dinámica: el nombre de usuario suministrado es demasiado corto.</translation>
    </message>
    <message>
        <location filename="../dnsupdater.cpp" line="260"/>
        <source>Dynamic DNS error: supplied password is too short.</source>
        <translation>Error de DNS dinámica: contraseña proporcionada demasiado corta.</translation>
    </message>
</context>
<context>
    <name>DownloadThread</name>
    <message>
        <location filename="../downloadthread.cpp" line="98"/>
        <location filename="../downloadthread.cpp" line="102"/>
        <source>I/O Error</source>
        <translation>Error de Entrada/Salida</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="209"/>
        <source>The remote host name was not found (invalid hostname)</source>
        <translation>El nombre de host remoto no se ha encontrado (nombre de host no válido)</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="211"/>
        <source>The operation was canceled</source>
        <translation>La operación fue cancelada</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="213"/>
        <source>The remote server closed the connection prematurely, before the entire reply was received and processed</source>
        <translation>El servidor remoto cerró la conexión antes de tiempo, antes que fuese recibido y procesado</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="215"/>
        <source>The connection to the remote server timed out</source>
        <translation>Conexión con el servidor remoto fallida, Tiempo de espera agotado</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="217"/>
        <source>SSL/TLS handshake failed</source>
        <translation>SSL/TLS handshake fallida</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="219"/>
        <source>The remote server refused the connection</source>
        <translation>El servidor remoto rechazó la conexión</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="221"/>
        <source>The connection to the proxy server was refused</source>
        <translation>La conexión con el servidor proxy fue rechazada</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="223"/>
        <source>The proxy server closed the connection prematurely</source>
        <translation>Conexión cerrada antes de tiempo por el servidor proxy</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="225"/>
        <source>The proxy host name was not found</source>
        <translation>El nombre de host del proxy no se ha encontrado</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="227"/>
        <source>The connection to the proxy timed out or the proxy did not reply in time to the request sent</source>
        <translation>La conexión con el servidor proxy se ha agotado, o el proxy no respondió a tiempo a la solicitud enviada</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="229"/>
        <source>The proxy requires authentication in order to honour the request but did not accept any credentials offered</source>
        <translation>El proxy requiere autenticación con el fin de atender la solicitud, pero no aceptó las credenciales que ofreció</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="231"/>
        <source>The access to the remote content was denied (401)</source>
        <translation>El acceso al contenido remoto ha sido rechazado (401)</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="233"/>
        <source>The operation requested on the remote content is not permitted</source>
        <translation>La operación solicitada del contenido remoto no está permitida</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="235"/>
        <source>The remote content was not found at the server (404)</source>
        <translation>El contenido remoto no se encuentra en el servidor (404)</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="237"/>
        <source>The remote server requires authentication to serve the content but the credentials provided were not accepted</source>
        <translation>El servidor remoto requiere autenticación para servir el contenido, pero las credenciales proporcionadas no son correctas</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="239"/>
        <source>The Network Access API cannot honor the request because the protocol is not known</source>
        <translation>El acceso a la red de la API no puede cumplir con la solicitud debido a que el protocolo es desconocido</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="241"/>
        <source>The requested operation is invalid for this protocol</source>
        <translation>La operación solicitada no es válida para este protocolo</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="243"/>
        <source>An unknown network-related error was detected</source>
        <translation>Error de Red desconocido</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="245"/>
        <source>An unknown proxy-related error was detected</source>
        <translation>Error de Proxy desconocido</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="247"/>
        <source>An unknown error related to the remote content was detected</source>
        <translation>Error desconocido en el servidor remoto</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="249"/>
        <source>A breakdown in protocol was detected</source>
        <translation>Error de protocolo</translation>
    </message>
    <message>
        <location filename="../downloadthread.cpp" line="251"/>
        <source>Unknown error</source>
        <translation>Error desconocido</translation>
    </message>
</context>
<context>
    <name>EventManager</name>
    <message>
        <location filename="../webui/eventmanager.cpp" line="73"/>
        <location filename="../webui/eventmanager.cpp" line="87"/>
        <source>Working</source>
        <translation>Trabajando</translation>
    </message>
    <message>
        <location filename="../webui/eventmanager.cpp" line="76"/>
        <source>Updating...</source>
        <translation>Actualizando...</translation>
    </message>
    <message>
        <location filename="../webui/eventmanager.cpp" line="79"/>
        <location filename="../webui/eventmanager.cpp" line="90"/>
        <source>Not working</source>
        <translation>Sin servicio</translation>
    </message>
    <message>
        <location filename="../webui/eventmanager.cpp" line="81"/>
        <location filename="../webui/eventmanager.cpp" line="92"/>
        <source>Not contacted yet</source>
        <translation>No conectado todavía</translation>
    </message>
    <message>
        <location filename="../webui/eventmanager.cpp" line="405"/>
        <location filename="../webui/eventmanager.cpp" line="406"/>
        <source>this session</source>
        <translation>en esta sesión</translation>
    </message>
    <message>
        <location filename="../webui/eventmanager.cpp" line="410"/>
        <location filename="../webui/eventmanager.cpp" line="414"/>
        <source>/s</source>
        <comment>/second (i.e. per second)</comment>
        <translation>/s</translation>
    </message>
    <message>
        <location filename="../webui/eventmanager.cpp" line="417"/>
        <source>Seeded for %1</source>
        <comment>e.g. Seeded for 3m10s</comment>
        <translation>Completo desde %1</translation>
    </message>
    <message>
        <location filename="../webui/eventmanager.cpp" line="420"/>
        <source>%1 max</source>
        <comment>e.g. 10 max</comment>
        <translation></translation>
    </message>
    <message>
        <location filename="../webui/eventmanager.cpp" line="499"/>
        <location filename="../webui/eventmanager.cpp" line="508"/>
        <source>%1/s</source>
        <comment>e.g. 120 KiB/s</comment>
        <translation></translation>
    </message>
</context>
<context>
    <name>ExecutionLog</name>
    <message>
        <source>Form</source>
        <translation type="obsolete">Formulario</translation>
    </message>
    <message>
        <location filename="../executionlog.ui" line="27"/>
        <source>General</source>
        <translation>General</translation>
    </message>
    <message>
        <location filename="../executionlog.ui" line="41"/>
        <source>Blocked IPs</source>
        <translation>IPs bloqueadas</translation>
    </message>
</context>
<context>
    <name>FeedDownloader</name>
    <message>
        <source>RSS Feed downloader</source>
        <translation type="obsolete">Descargando canal RSS</translation>
    </message>
    <message>
        <source>RSS feed:</source>
        <translation type="obsolete">Canal RSS:</translation>
    </message>
    <message>
        <source>Feed name</source>
        <translation type="obsolete">Nombre del Canal</translation>
    </message>
    <message>
        <source>Automatically download torrents from this feed</source>
        <translation type="obsolete">Descargar automáticamente torrents desde este Canal</translation>
    </message>
    <message>
        <source>Download filters</source>
        <translation type="obsolete">Descargar filtros</translation>
    </message>
    <message>
        <source>Filters:</source>
        <translation type="obsolete">Filtros:</translation>
    </message>
    <message>
        <source>Filter settings</source>
        <translation type="obsolete">Ajustes de filtros</translation>
    </message>
    <message>
        <source>Matches:</source>
        <translation type="obsolete">Concordancias:</translation>
    </message>
    <message>
        <source>Does not match:</source>
        <translation type="obsolete">No coinciden con:</translation>
    </message>
    <message>
        <source>Destination folder:</source>
        <translation type="obsolete">Carpeta de destino:</translation>
    </message>
    <message>
        <source>...</source>
        <translation type="obsolete">...</translation>
    </message>
    <message>
        <source>Filter testing</source>
        <translation type="obsolete">Verificando filtros</translation>
    </message>
    <message>
        <source>Torrent title:</source>
        <translation type="obsolete">Título Torrent:</translation>
    </message>
    <message>
        <source>Result:</source>
        <translation type="obsolete">Resultado:</translation>
    </message>
    <message>
        <source>Test</source>
        <translation type="obsolete">Prueba</translation>
    </message>
    <message>
        <source>Import...</source>
        <translation type="obsolete">Importar...</translation>
    </message>
    <message>
        <source>Export...</source>
        <translation type="obsolete">Exportar...</translation>
    </message>
    <message>
        <source>Rename filter</source>
        <translation type="obsolete">Renombrar filtro</translation>
    </message>
    <message>
        <source>Remove filter</source>
        <translation type="obsolete">Eliminar filtro</translation>
    </message>
    <message>
        <source>Add filter</source>
        <translation type="obsolete">Agregar filtro</translation>
    </message>
</context>
<context>
    <name>FeedDownloaderDlg</name>
    <message>
        <source>New filter</source>
        <translation type="obsolete">Nuevo filtro</translation>
    </message>
    <message>
        <source>Please choose a name for this filter</source>
        <translation type="obsolete">Por favor, elija un nombre para este filtro</translation>
    </message>
    <message>
        <source>Filter name:</source>
        <translation type="obsolete">Nombre del filtro:</translation>
    </message>
    <message>
        <source>Invalid filter name</source>
        <translation type="obsolete">Nombre no valido para el filtro</translation>
    </message>
    <message>
        <source>The filter name cannot be left empty.</source>
        <translation type="obsolete">El nombre del filtro no puede quedar vació.</translation>
    </message>
    <message>
        <source>This filter name is already in use.</source>
        <translation type="obsolete">Este nombre de filtro ya se está usando.</translation>
    </message>
    <message>
        <source>Choose save path</source>
        <translation type="obsolete">Seleccione la ruta donde guardarlo</translation>
    </message>
    <message>
        <source>Filter testing error</source>
        <translation type="obsolete">Error en la verificación del filtro</translation>
    </message>
    <message>
        <source>Please specify a test torrent name.</source>
        <translation type="obsolete">Por favor, especifique el nombre del torrent a verificar.</translation>
    </message>
    <message>
        <source>matches</source>
        <translation type="obsolete">Contiene</translation>
    </message>
    <message>
        <source>does not match</source>
        <translation type="obsolete">no contiene</translation>
    </message>
    <message>
        <source>Select file to import</source>
        <translation type="obsolete">Seleccione el archivo a importar</translation>
    </message>
    <message>
        <source>Filters Files</source>
        <translation type="obsolete">Filtro de archivos</translation>
    </message>
    <message>
        <source>Import successful</source>
        <translation type="obsolete">Importación satisfactoria</translation>
    </message>
    <message>
        <source>Filters import was successful.</source>
        <translation type="obsolete">Filtros importados satisfactoriamente.</translation>
    </message>
    <message>
        <source>Import failure</source>
        <translation type="obsolete">Importación fallida</translation>
    </message>
    <message>
        <source>Filters could not be imported due to an I/O error.</source>
        <translation type="obsolete">Los filtros no pueden ser importados debido a un Error de Entrada/Salida.</translation>
    </message>
    <message>
        <source>Select destination file</source>
        <translation type="obsolete">Seleccione la ruta del archivo</translation>
    </message>
    <message>
        <source>Export successful</source>
        <translation type="obsolete">Exportación satisfactoria</translation>
    </message>
    <message>
        <source>Filters export was successful.</source>
        <translation type="obsolete">Filtros exportados satisfactoriamente.</translation>
    </message>
    <message>
        <source>Export failure</source>
        <translation type="obsolete">Exportación fallida</translation>
    </message>
    <message>
        <source>Filters could not be exported due to an I/O error.</source>
        <translation type="obsolete">Los filtros no pueden ser exportados debido a un Error de Entrada/Salida.</translation>
    </message>
</context>
<context>
    <name>FeedList</name>
    <message>
        <source>Unread</source>
        <translation type="obsolete">No leído</translation>
    </message>
</context>
<context>
    <name>FeedListWidget</name>
    <message>
        <location filename="../rss/feedlistwidget.cpp" line="41"/>
        <source>RSS feeds</source>
        <translation>Canales RSS</translation>
    </message>
    <message>
        <location filename="../rss/feedlistwidget.cpp" line="43"/>
        <source>Unread</source>
        <translation>No leídos</translation>
    </message>
</context>
<context>
    <name>GUI</name>
    <message>
        <source>Open Torrent Files</source>
        <translation type="obsolete">Abrir archivos Torrent</translation>
    </message>
    <message>
        <source>Torrent Files</source>
        <translation type="obsolete">Archivos Torrent</translation>
    </message>
    <message>
        <source>qBittorrent</source>
        <translation type="obsolete">qBittorrent</translation>
    </message>
    <message>
        <source>Transfers</source>
        <translation type="obsolete">Transferencia</translation>
    </message>
    <message>
        <source>qBittorrent %1</source>
        <comment>e.g: qBittorrent v0.x</comment>
        <translation type="obsolete">qBittorrent %1</translation>
    </message>
    <message>
        <source>DL speed: %1 KiB/s</source>
        <comment>e.g: Download speed: 10 KiB/s</comment>
        <translation type="obsolete">Vel. de Bajada: %1 KiB/s</translation>
    </message>
    <message>
        <source>UP speed: %1 KiB/s</source>
        <comment>e.g: Upload speed: 10 KiB/s</comment>
        <translation type="obsolete">Vel. de Subida: %1 KiB/s</translation>
    </message>
    <message>
        <source>%1 has finished downloading.</source>
        <comment>e.g: xxx.avi has finished downloading.</comment>
        <translation type="obsolete">%1 ha terminado de descargarse.</translation>
    </message>
    <message>
        <source>I/O Error</source>
        <comment>i.e: Input/Output Error</comment>
        <translation type="obsolete">Error de Entrada/Salida</translation>
    </message>
    <message>
        <source>Search</source>
        <translation type="obsolete">Buscar</translation>
    </message>
    <message>
        <source>Torrent file association</source>
        <translation type="obsolete">Asociación de archivos Torrent</translation>
    </message>
    <message>
        <source>Set the password...</source>
        <translation type="obsolete">Configurar Contraseña...</translation>
    </message>
    <message>
        <source>qBittorrent is not the default application to open torrent files or Magnet links.
Do you want to associate qBittorrent to torrent files and Magnet links?</source>
        <translation type="obsolete">qBittorrent no es la aplicación por defecto para abrir archivos Torrent o enlaces Magnet.
¿Quiere que qBittorrent sea el programa por defecto para gestionar estos archivos?</translation>
    </message>
    <message>
        <source>Password update</source>
        <translation type="obsolete">Actualizar Contraseña</translation>
    </message>
    <message>
        <source>The UI lock password has been successfully updated</source>
        <translation type="obsolete">La contraseña de bloqueo de qBittorrent se ha actualizado correctamente</translation>
    </message>
    <message>
        <source>RSS</source>
        <translation type="obsolete">RSS</translation>
    </message>
    <message>
        <source>Transfers (%1)</source>
        <translation type="obsolete">Transferencias (%1)</translation>
    </message>
    <message>
        <source>Download completion</source>
        <translation type="obsolete">Descarga completada</translation>
    </message>
    <message>
        <source>An I/O error occured for torrent %1.
 Reason: %2</source>
        <comment>e.g: An error occured for torrent xxx.avi.
 Reason: disk is full.</comment>
        <translation type="obsolete">Se produjo un Error de Entrada/Salida, torrent %1.
 Razón: %2</translation>
    </message>
    <message>
        <source>Alt+2</source>
        <comment>shortcut to switch to third tab</comment>
        <translation type="obsolete">Alt+2</translation>
    </message>
    <message>
        <source>Alt+3</source>
        <comment>shortcut to switch to fourth tab</comment>
        <translation type="obsolete">Alt+3</translation>
    </message>
    <message>
        <source>Recursive download confirmation</source>
        <translation type="obsolete">Confirmación descargas recursivas</translation>
    </message>
    <message>
        <source>The torrent %1 contains torrent files, do you want to proceed with their download?</source>
        <translation type="obsolete">Este torrent %1 contiene archivos torrent, ¿quiere seguir adelante con su descarga?</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation type="obsolete">Sí</translation>
    </message>
    <message>
        <source>No</source>
        <translation type="obsolete">No</translation>
    </message>
    <message>
        <source>Never</source>
        <translation type="obsolete">Nunca</translation>
    </message>
    <message>
        <source>Global Upload Speed Limit</source>
        <translation type="obsolete">Límite global de subida</translation>
    </message>
    <message>
        <source>Global Download Speed Limit</source>
        <translation type="obsolete">Limite global de bajada</translation>
    </message>
    <message>
        <source>A newer version is available</source>
        <translation type="obsolete">Hay una nueva versión disponible</translation>
    </message>
    <message>
        <source>A newer version of qBittorrent is available on Sourceforge.
Would you like to update qBittorrent to version %1?</source>
        <translation type="obsolete">Hay disponible una versión más reciente de qBittorrent en Sourceforge.
¿Desea actualizar qBittorrent a la versión%1?</translation>
    </message>
    <message>
        <source>Impossible to update qBittorrent</source>
        <translation type="obsolete">Ha sido imposible actualizar qBittorrent</translation>
    </message>
    <message>
        <source>qBittorrent failed to update, reason: %1</source>
        <translation type="obsolete">qBittorrent no pudo actualizarse, por la siguiente razón: %1</translation>
    </message>
    <message>
        <source>UI lock password</source>
        <translation type="obsolete">Contraseña de bloqueo</translation>
    </message>
    <message>
        <source>Please type the UI lock password:</source>
        <translation type="obsolete">Por favor, escriba la contraseña de bloqueo:</translation>
    </message>
    <message>
        <source>Invalid password</source>
        <translation type="obsolete">Contraseña no válida</translation>
    </message>
    <message>
        <source>The password is invalid</source>
        <translation type="obsolete">La contraseña no es válida</translation>
    </message>
    <message>
        <source>Exiting qBittorrent</source>
        <translation type="obsolete">Cerrando qBittorrent</translation>
    </message>
    <message>
        <source>Always</source>
        <translation type="obsolete">Siempre</translation>
    </message>
    <message>
        <source>qBittorrent %1 (Down: %2/s, Up: %3/s)</source>
        <comment>%1 is qBittorrent version</comment>
        <translation type="obsolete">qBittorrent %1 (Bajada: %2/s, Subida: %3/s)</translation>
    </message>
    <message>
        <source>Alt+1</source>
        <comment>shortcut to switch to first tab</comment>
        <translation type="obsolete">Alt+1</translation>
    </message>
    <message>
        <source>Url download error</source>
        <translation type="obsolete">Error de descarga de Url</translation>
    </message>
    <message>
        <source>Couldn&apos;t download file at url: %1, reason: %2.</source>
        <translation type="obsolete">No se pudo descargar el archivo en la url: %1, razón: %2.</translation>
    </message>
    <message>
        <source>Ctrl+F</source>
        <comment>shortcut to switch to search tab</comment>
        <translation type="obsolete">Ctrl + F</translation>
    </message>
    <message>
        <source>Some files are currently transferring.
Are you sure you want to quit qBittorrent?</source>
        <translation type="obsolete">Algunos archivos están aún transfiriendose.
¿Está seguro que quiere salir?</translation>
    </message>
    <message>
        <source>Options were saved successfully.</source>
        <translation type="obsolete">Opciones guardadas correctamente.</translation>
    </message>
</context>
<context>
    <name>GeoIP</name>
    <message>
        <source>France</source>
        <translation type="obsolete">Francia</translation>
    </message>
    <message>
        <source>Saudi Arabia</source>
        <translation type="obsolete">Arabia Saudí</translation>
    </message>
</context>
<context>
    <name>HeadlessLoader</name>
    <message>
        <location filename="../headlessloader.h" line="54"/>
        <source>Information</source>
        <translation>Información</translation>
    </message>
    <message>
        <location filename="../headlessloader.h" line="55"/>
        <source>To control qBittorrent, access the Web UI at http://localhost:%1</source>
        <translation>Control qBittorrent, acceso a interfaz de usuario Web a http://localhost:%1</translation>
    </message>
    <message>
        <location filename="../headlessloader.h" line="56"/>
        <source>The Web UI administrator user name is: %1</source>
        <translation>Nombre de usuario del administrador Web: %1</translation>
    </message>
    <message>
        <location filename="../headlessloader.h" line="59"/>
        <source>The Web UI administrator password is still the default one: %1</source>
        <translation>La contraseña del administrador de interfaz de usuario web sigue siendo por defecto:%1</translation>
    </message>
    <message>
        <location filename="../headlessloader.h" line="60"/>
        <source>This is a security risk, please consider changing your password from program preferences.</source>
        <translation>Esto es un riesgo de seguridad, por favor considere cambiar su contraseña de las preferencias del programa.</translation>
    </message>
</context>
<context>
    <name>HttpConnection</name>
    <message>
        <location filename="../webui/httpconnection.cpp" line="150"/>
        <source>Your IP address has been banned after too many failed authentication attempts.</source>
        <translation>Tras muchos intentos de conexión, parece ser que tu dirección IP ha sido restringida.</translation>
    </message>
    <message>
        <location filename="../webui/httpconnection.cpp" line="345"/>
        <source>D: %1/s - T: %2</source>
        <comment>Download speed: x KiB/s - Transferred: x MiB</comment>
        <translation>Bajada: %1/s - Total: %2</translation>
    </message>
    <message>
        <location filename="../webui/httpconnection.cpp" line="346"/>
        <source>U: %1/s - T: %2</source>
        <comment>Upload speed: x KiB/s - Transferred: x MiB</comment>
        <translation>Subida: %1/s - Total: %2</translation>
    </message>
</context>
<context>
    <name>HttpServer</name>
    <message>
        <location filename="../webui/httpserver.cpp" line="120"/>
        <source>File</source>
        <translation>Archivo</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="121"/>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="122"/>
        <source>Help</source>
        <translation>Ayuda</translation>
    </message>
    <message>
        <source>Delete from HD</source>
        <translation type="obsolete">Eliminar del disco</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="123"/>
        <source>Download Torrents from their URL or Magnet link</source>
        <translation>Descargar Torrents desde URL o Enlace (Link)</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="124"/>
        <source>Only one link per line</source>
        <translation>Solamente un enlace (Link) por línea</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="125"/>
        <source>Download local torrent</source>
        <translation>Descargar torrent local</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="126"/>
        <source>Torrent files were correctly added to download list.</source>
        <translation>Los archivos torrents se añadieron correctamente a la lista de descarga.</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="127"/>
        <source>Point to torrent file</source>
        <translation>Indique un archivo torrent</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="128"/>
        <source>Download</source>
        <translation>Descargar</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="129"/>
        <source>Are you sure you want to delete the selected torrents from the transfer list and hard disk?</source>
        <translation>¿Está seguro que quiere eliminar los torrents seleccionados de la lista de transferencia y del disco?</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="130"/>
        <source>Download rate limit must be greater than 0 or disabled.</source>
        <translation>El límite de la tasa de descarga debe ser mayor que 0 o estar inhabilitado.</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="131"/>
        <source>Upload rate limit must be greater than 0 or disabled.</source>
        <translation>El límite de la tasa de subida debe ser mayor que 0 o estar inhabilitado.</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="132"/>
        <source>Maximum number of connections limit must be greater than 0 or disabled.</source>
        <translation>El número máximo del limite de conexiones debe ser mayor que 0 o estar inhabilitado.</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="133"/>
        <source>Maximum number of connections per torrent limit must be greater than 0 or disabled.</source>
        <translation>El número máximo del limite de conexiones por torrent debe ser mayor que 0 o estar inhabilitado.</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="134"/>
        <source>Maximum number of upload slots per torrent limit must be greater than 0 or disabled.</source>
        <translation>El número máximo de subidas de slots por torrent debe ser mayor que 0 o estar inhabilitado.</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="135"/>
        <source>Unable to save program preferences, qBittorrent is probably unreachable.</source>
        <translation>No se puede guardar las preferencias del programa, qbittorrent probablemente no es accesible.</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="136"/>
        <source>Language</source>
        <translation>Idioma</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="137"/>
        <source>Downloaded</source>
        <comment>Is the file downloaded or not?</comment>
        <translation>Bajado</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="138"/>
        <source>The port used for incoming connections must be greater than 1024 and less than 65535.</source>
        <translation>El puerto utilizado para conexiones entrantes debe ser mayor de 1024 y menor de 65535.</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="139"/>
        <source>The port used for the Web UI must be greater than 1024 and less than 65535.</source>
        <translation>El puerto utilizado para la Interfaz de Usuario Web debe ser mayor de 1024 y menor de 65535.</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="140"/>
        <source>The Web UI username must be at least 3 characters long.</source>
        <translation>El nombre de Interfaz de Usuario web debe ser de al menos 3 caracteres.</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="141"/>
        <source>The Web UI password must be at least 3 characters long.</source>
        <translation>La contraseña de Interfaz de Usuario Web debe ser de al menos 3 caracteres.</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="142"/>
        <source>Save</source>
        <translation>Guardar</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="143"/>
        <source>qBittorrent client is not reachable</source>
        <translation>El cliente qBittorrent no es accesible</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="144"/>
        <source>HTTP Server</source>
        <translation>Servidor HTTP</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="145"/>
        <source>The following parameters are supported:</source>
        <translation>Los siguientes parámetros son compatibles:</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="146"/>
        <source>Torrent path</source>
        <translation>Ruta torrent</translation>
    </message>
    <message>
        <location filename="../webui/httpserver.cpp" line="147"/>
        <source>Torrent name</source>
        <translation>Nombre torrent</translation>
    </message>
</context>
<context>
    <name>LegalNotice</name>
    <message>
        <location filename="../main.cpp" line="93"/>
        <source>Legal Notice</source>
        <translation>Aviso Legal</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="94"/>
        <location filename="../main.cpp" line="105"/>
        <source>qBittorrent is a file sharing program. When you run a torrent, its data will be made available to others by means of upload. Any content you share is your sole responsibility.

No further notices will be issued.</source>
        <translation>qBittorrent es un programa para compartir archivos. Cuando se ejecuta un torrente, sus datos se pondrán a disposición de los demás usuarios por medio de las subidas. Por supuesto, cualquier contenido que usted comparta es bajo su propia responsabilidad.

Probablemente esto es algo que ya sabía, así que no se lo diré otra vez.</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="95"/>
        <source>Press %1 key to accept and continue...</source>
        <translation>Pulse cualquier tecla para aceptar y continuar ...</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="106"/>
        <source>Legal notice</source>
        <translation>Aviso Legal</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="107"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="108"/>
        <source>I Agree</source>
        <translation>Estoy de acuerdo</translation>
    </message>
</context>
<context>
    <name>LineEdit</name>
    <message>
        <location filename="../lineedit/src/lineedit.cpp" line="30"/>
        <source>Clear the text</source>
        <translation>Borrar texto</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="37"/>
        <source>&amp;Edit</source>
        <translation>&amp;Editar</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="60"/>
        <source>&amp;Tools</source>
        <translation>&amp;Herramientas</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="79"/>
        <source>&amp;File</source>
        <translation>&amp;Archivo</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="50"/>
        <source>&amp;Help</source>
        <translation>A&amp;yuda</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="88"/>
        <source>&amp;View</source>
        <translation>&amp;Ver</translation>
    </message>
    <message>
        <source>&amp;Add File...</source>
        <translation type="obsolete">&amp;Agregar archivo...</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation type="obsolete">&amp;Salir</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="148"/>
        <source>&amp;Options...</source>
        <translation>&amp;Opciones...</translation>
    </message>
    <message>
        <source>Add &amp;URL...</source>
        <translation type="obsolete">Añadir &amp;URL...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="187"/>
        <source>Torrent &amp;creator</source>
        <translation>Crear &amp;Torrent</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="197"/>
        <source>Set upload limit...</source>
        <translation>Límitie de Subidad...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="202"/>
        <source>Set download limit...</source>
        <translation>Límite de Bajada...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="153"/>
        <source>&amp;About</source>
        <translation>&amp;Acerca de</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="163"/>
        <source>&amp;Pause</source>
        <translation>&amp;Pausar</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="168"/>
        <source>&amp;Delete</source>
        <translation>&amp;Borrar</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="319"/>
        <source>P&amp;ause All</source>
        <translation>Pa&amp;usar Todas</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="158"/>
        <source>&amp;Resume</source>
        <translation>&amp;Reanudar</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="135"/>
        <source>&amp;Add torrent file...</source>
        <translation>&amp;Añadir archivo torrent...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="140"/>
        <location filename="../mainwindow.ui" line="143"/>
        <source>Exit</source>
        <translation>Salir</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="314"/>
        <source>R&amp;esume All</source>
        <translation>R&amp;eanudar Todas</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="177"/>
        <source>Visit &amp;Website</source>
        <translation>&amp;Visite mi sitio Web</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="64"/>
        <source>Auto-Shutdown on downloads completion</source>
        <translation>Cerrar cuando se completen las descargas</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="182"/>
        <source>Add &amp;link to torrent...</source>
        <translation>Añadir &amp;enlace torrent...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="192"/>
        <source>Report a &amp;bug</source>
        <translation>Comunicar un &amp;bug</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="207"/>
        <source>&amp;Documentation</source>
        <translation>&amp;Documentación</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="212"/>
        <source>Set global download limit...</source>
        <translation>Límite global de Bajada...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="217"/>
        <source>Set global upload limit...</source>
        <translation>Límite global de Subida...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="338"/>
        <source>Exit qBittorrent</source>
        <translation>Cerrar qBittorrent</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="346"/>
        <source>Suspend system</source>
        <translation>Suspender sistema</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="354"/>
        <source>Shutdown system</source>
        <translation>Cerrar sistema</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="362"/>
        <source>Disabled</source>
        <translation>Deshabilitado</translation>
    </message>
    <message>
        <source>&amp;Log viewer...</source>
        <translation type="obsolete">Visor de &amp;registros...</translation>
    </message>
    <message>
        <source>Log viewer</source>
        <translation type="obsolete">Visor de registros</translation>
    </message>
    <message>
        <source>Shutdown computer when downloads complete</source>
        <translation type="obsolete">Apagar el equipo al finalizar las descargas</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="287"/>
        <location filename="../mainwindow.ui" line="290"/>
        <source>Lock qBittorrent</source>
        <translation>Bloquear qBittorrent</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="293"/>
        <source>Ctrl+L</source>
        <translation>Ctrl+L</translation>
    </message>
    <message>
        <source>Shutdown qBittorrent when downloads complete</source>
        <translation type="obsolete">Apagar qBittorrent cuando la descarga esté completa</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="298"/>
        <source>Import existing torrent...</source>
        <translation>Importar torrent existente...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="301"/>
        <source>Import torrent...</source>
        <translation>Importar torrent...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="306"/>
        <source>Donate money</source>
        <translation>Donar</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="309"/>
        <source>If you like qBittorrent, please donate!</source>
        <translation>Si le gusta qBittorrent, por favor realice una donación!</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="327"/>
        <source>Execution &amp;Log</source>
        <translation>Ejecución &amp;Log</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="330"/>
        <location filename="../mainwindow.cpp" line="1327"/>
        <source>Execution Log</source>
        <translation>Ejecución Log</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="241"/>
        <location filename="../mainwindow.ui" line="244"/>
        <source>Alternative speed limits</source>
        <translation>Límites de velocidad alternativa</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="274"/>
        <source>&amp;RSS reader</source>
        <translation>&amp;Lector RSS</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="282"/>
        <source>Search &amp;engine</source>
        <translation>&amp;Motor de búsqueda</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="252"/>
        <source>Top &amp;tool bar</source>
        <translation>Barra &amp;Herramientas superior</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="255"/>
        <source>Display top tool bar</source>
        <translation>Mostrar barra heramientas superior</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="263"/>
        <source>&amp;Speed in title bar</source>
        <translation>&amp;Velocidad en la barra</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="266"/>
        <source>Show transfer speed in title bar</source>
        <translation>Mostrar velocidad en la barra de título</translation>
    </message>
    <message>
        <source>Preview file</source>
        <translation type="obsolete">Previsualizar archivo</translation>
    </message>
    <message>
        <source>Clear log</source>
        <translation type="obsolete">Limpiar registro</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="222"/>
        <source>Decrease priority</source>
        <translation>Disminuir prioridad</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="230"/>
        <source>Increase priority</source>
        <translation>Incrementar prioridad</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="103"/>
        <location filename="../mainwindow.cpp" line="1251"/>
        <source>qBittorrent %1</source>
        <comment>e.g: qBittorrent v0.x</comment>
        <translation>qBittorrent %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="140"/>
        <source>Set the password...</source>
        <translation>Configurar Contraseña...</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="174"/>
        <source>Transfers</source>
        <translation>Transferencia</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="287"/>
        <source>Torrent file association</source>
        <translation>Asociación de archivos Torrent</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="288"/>
        <source>qBittorrent is not the default application to open torrent files or Magnet links.
Do you want to associate qBittorrent to torrent files and Magnet links?</source>
        <translation>qBittorrent no es la aplicación por defecto para abrir archivos Torrent o enlaces Magnet.
¿Quiere que qBittorrent sea el programa por defecto para gestionar estos archivos?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="381"/>
        <location filename="../mainwindow.cpp" line="401"/>
        <location filename="../mainwindow.cpp" line="651"/>
        <source>UI lock password</source>
        <translation>Contraseña de bloqueo</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="381"/>
        <location filename="../mainwindow.cpp" line="401"/>
        <location filename="../mainwindow.cpp" line="651"/>
        <source>Please type the UI lock password:</source>
        <translation>Por favor, escriba la contraseña de bloqueo:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="385"/>
        <source>The password should contain at least 3 characters</source>
        <translation>Cómo mínimo la contraseña debe tener 3 caracteres</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="391"/>
        <source>Password update</source>
        <translation>Actualizar Contraseña</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="391"/>
        <source>The UI lock password has been successfully updated</source>
        <translation>La contraseña de bloqueo de qBittorrent se ha actualizado correctamente</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="417"/>
        <source>RSS</source>
        <translation>RSS</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="432"/>
        <source>Search</source>
        <translation>Buscar</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="442"/>
        <source>Transfers (%1)</source>
        <translation>Transferencias (%1)</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="513"/>
        <source>Download completion</source>
        <translation>Descarga completada</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="513"/>
        <source>%1 has finished downloading.</source>
        <comment>e.g: xxx.avi has finished downloading.</comment>
        <translation>%1 ha terminado de descargarse.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="519"/>
        <source>I/O Error</source>
        <comment>i.e: Input/Output Error</comment>
        <translation>Error de Entrada/Salida</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="519"/>
        <source>An I/O error occured for torrent %1.
 Reason: %2</source>
        <comment>e.g: An error occured for torrent xxx.avi.
 Reason: disk is full.</comment>
        <translation>Se produjo un Error de Entrada/Salida, torrent %1.
 Razón: %2</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="526"/>
        <source>Alt+1</source>
        <comment>shortcut to switch to first tab</comment>
        <translation>Alt+1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="528"/>
        <source>Alt+2</source>
        <comment>shortcut to switch to third tab</comment>
        <translation>Alt+2</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="530"/>
        <source>Ctrl+F</source>
        <comment>shortcut to switch to search tab</comment>
        <translation>Ctrl+F</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="532"/>
        <source>Alt+3</source>
        <comment>shortcut to switch to fourth tab</comment>
        <translation>Alt+3</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="572"/>
        <source>Recursive download confirmation</source>
        <translation>Confirmación descargas recursivas</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="572"/>
        <source>The torrent %1 contains torrent files, do you want to proceed with their download?</source>
        <translation>Este torrent %1 contiene archivos torrent, ¿quiere seguir adelante con su descarga?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="573"/>
        <location filename="../mainwindow.cpp" line="744"/>
        <source>Yes</source>
        <translation>Sí</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="574"/>
        <location filename="../mainwindow.cpp" line="743"/>
        <source>No</source>
        <translation>No</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="575"/>
        <source>Never</source>
        <translation>Nunca</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="589"/>
        <source>Url download error</source>
        <translation>Error de descarga de Url</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="589"/>
        <source>Couldn&apos;t download file at url: %1, reason: %2.</source>
        <translation>No se pudo descargar el archivo en la url: %1, razón: %2.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="600"/>
        <source>Global Upload Speed Limit</source>
        <translation>Límite de velocidad global de subida</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="619"/>
        <source>Global Download Speed Limit</source>
        <translation>Límite de velocidad global de bajada</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="385"/>
        <location filename="../mainwindow.cpp" line="664"/>
        <source>Invalid password</source>
        <translation>Contraseña no válida</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="664"/>
        <source>The password is invalid</source>
        <translation>La contraseña no es válida</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="740"/>
        <source>Exiting qBittorrent</source>
        <translation>Cerrando qBittorrent</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="741"/>
        <source>Some files are currently transferring.
Are you sure you want to quit qBittorrent?</source>
        <translation>Algunos archivos aún están transfiriendose.
¿Está seguro que quiere salir?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="745"/>
        <source>Always</source>
        <translation>Siempre</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="903"/>
        <source>Open Torrent Files</source>
        <translation>Abrir archivos Torrent</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="904"/>
        <source>Torrent Files</source>
        <translation>Archivos torrent</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="983"/>
        <source>Options were saved successfully.</source>
        <translation>Opciones guardadas correctamente.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1092"/>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1095"/>
        <location filename="../mainwindow.cpp" line="1102"/>
        <source>DL speed: %1 KiB/s</source>
        <comment>e.g: Download speed: 10 KiB/s</comment>
        <translation>Vel. de Bajada: %1 KiB/s</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1098"/>
        <location filename="../mainwindow.cpp" line="1104"/>
        <source>UP speed: %1 KiB/s</source>
        <comment>e.g: Upload speed: 10 KiB/s</comment>
        <translation>Vel. de Subida: %1 KiB/s</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1109"/>
        <source>qBittorrent %1 (Down: %2/s, Up: %3/s)</source>
        <comment>%1 is qBittorrent version</comment>
        <translation>qBittorrent %1 (Bajada: %2/s, Subida: %3/s)</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1289"/>
        <source>A newer version is available</source>
        <translation>Hay una nueva versión disponible</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1290"/>
        <source>A newer version of qBittorrent is available on Sourceforge.
Would you like to update qBittorrent to version %1?</source>
        <translation>Hay disponible una versión más reciente de qBittorrent en Sourceforge.
¿Desea actualizar qBittorrent a la versión %1?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1305"/>
        <source>Impossible to update qBittorrent</source>
        <translation>Ha sido imposible actualizar qBittorrent</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1305"/>
        <source>qBittorrent failed to update, reason: %1</source>
        <translation>qBittorrent no pudo actualizarse, por la siguiente razón: %1</translation>
    </message>
</context>
<context>
    <name>PeerAdditionDlg</name>
    <message>
        <location filename="../properties/peeraddition.h" line="94"/>
        <source>Invalid IP</source>
        <translation>IP inválida</translation>
    </message>
    <message>
        <location filename="../properties/peeraddition.h" line="95"/>
        <source>The IP you provided is invalid.</source>
        <translation>La IP facilitada no es válida.</translation>
    </message>
</context>
<context>
    <name>PeerListDelegate</name>
    <message>
        <location filename="../properties/peerlistdelegate.h" line="64"/>
        <source>/s</source>
        <comment>/second (i.e. per second)</comment>
        <translation>/s</translation>
    </message>
</context>
<context>
    <name>PeerListWidget</name>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="61"/>
        <source>IP</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="62"/>
        <source>Connection</source>
        <translation>Conexión</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="63"/>
        <source>Client</source>
        <comment>i.e.: Client application</comment>
        <translation>Cliente</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="64"/>
        <source>Progress</source>
        <comment>i.e: % downloaded</comment>
        <translation>Progreso</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="65"/>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Vel. Bajada</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="66"/>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Vel. Subida</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="67"/>
        <source>Downloaded</source>
        <comment>i.e: total data downloaded</comment>
        <translation>Bajado</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="68"/>
        <source>Uploaded</source>
        <comment>i.e: total data uploaded</comment>
        <translation>Subido</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="139"/>
        <source>Add a new peer...</source>
        <translation>Añadir nuevo par...</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="148"/>
        <source>Copy IP</source>
        <translation>Copiar IP</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="150"/>
        <source>Limit download rate...</source>
        <translation>Tasa límite de Bajada...</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="151"/>
        <source>Limit upload rate...</source>
        <translation>Tasa límite de Subida...</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="153"/>
        <source>Ban peer permanently</source>
        <translation>Prohibición permanente de Pares</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="164"/>
        <location filename="../properties/peerlistwidget.cpp" line="166"/>
        <source>Peer addition</source>
        <translation>Incorporar Par</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="164"/>
        <source>The peer was added to this torrent.</source>
        <translation>Los Pares se agregaron al torrent.</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="166"/>
        <source>The peer could not be added to this torrent.</source>
        <translation>Los Pares no se han podido agregar al torrent.</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="196"/>
        <source>Are you sure? -- qBittorrent</source>
        <translation>¿Estás seguro? -- qBittorrent</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="196"/>
        <source>Are you sure you want to ban permanently the selected peers?</source>
        <translation>¿Seguro que desea prohibirle la compartición permanente de Pares?</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="197"/>
        <source>&amp;Yes</source>
        <translation>&amp;Sí</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="197"/>
        <source>&amp;No</source>
        <translation>&amp;No</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="202"/>
        <source>Manually banning peer %1...</source>
        <translation>Prohibir manualmente los Pares %1...</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="221"/>
        <source>Upload rate limiting</source>
        <translation>Tasa Límite de Subida</translation>
    </message>
    <message>
        <location filename="../properties/peerlistwidget.cpp" line="249"/>
        <source>Download rate limiting</source>
        <translation>Tasa Límite de Bajada</translation>
    </message>
</context>
<context>
    <name>Preferences</name>
    <message>
        <source>UI</source>
        <extracomment>User Interface</extracomment>
        <translation type="obsolete">IU</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="93"/>
        <source>Downloads</source>
        <translation>Descargas</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="104"/>
        <source>Connection</source>
        <translation>Conexión</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="115"/>
        <source>Speed</source>
        <translation>Velocidad</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="134"/>
        <source>Web UI</source>
        <translation>IU Web</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="145"/>
        <source>Advanced</source>
        <translation>Avanzado</translation>
    </message>
    <message>
        <source>Language:</source>
        <translation type="obsolete">Idioma:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="219"/>
        <source>(Requires restart)</source>
        <translation>(Es necesario reiniciar qBittorrent)</translation>
    </message>
    <message>
        <source>Visual style:</source>
        <translation type="obsolete">Estilo Visual:</translation>
    </message>
    <message>
        <source>Transfer list</source>
        <translation type="obsolete">Lista de Transferencia</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="253"/>
        <source>Use alternating row colors</source>
        <extracomment>In transfer list, one every two rows will have grey background.</extracomment>
        <translation>Usar colores alternos en la lista de Transferencia</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="301"/>
        <location filename="../preferences/options.ui" line="327"/>
        <source>Start / Stop Torrent</source>
        <translation>Iniciar / Parar Torrent</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="311"/>
        <location filename="../preferences/options.ui" line="337"/>
        <source>No action</source>
        <translation>Sin acción</translation>
    </message>
    <message>
        <source>File system</source>
        <translation type="obsolete">Opciones sobre archivos del Sistema</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="762"/>
        <source>Copy .torrent files to:</source>
        <translation>Copiar archivos .torrent en:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="918"/>
        <source>The following parameters are supported:
&lt;ul&gt;
&lt;li&gt;%f: Torrent path&lt;/li&gt;
&lt;li&gt;%n: Torrent name&lt;/li&gt;
&lt;/ul&gt;</source>
        <translation>Los siguientes parámetros son compatibles:
&lt;ul&gt;
&lt;li&gt;%f: Torrent ruta&lt;/li&gt;
&lt;li&gt;%n: Torrent nombre&lt;/li&gt;
&lt;/ul&gt;</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="960"/>
        <source>Listening Port</source>
        <translation>Puerto de escucha</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1025"/>
        <source>Connections Limits</source>
        <translation>Límites de conexión</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1145"/>
        <source>Proxy Server</source>
        <translation>Servidor Proxy</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1510"/>
        <source>Enable bandwidth management (uTP)</source>
        <translation>Habilitar gestión de ancho de banda (uTP)</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1896"/>
        <source>Enable Peer Exchange (PeX) to find more peers</source>
        <translation>Habilitar intercambio de pares (PeX) para encontrar más pares</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1909"/>
        <source>Enable Local Peer Discovery to find more peers</source>
        <translation>Habilitar Hallado Local de Pares para encontrar más pares</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1921"/>
        <source>Encryption mode:</source>
        <translation>Modo de cifrado:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1929"/>
        <source>Prefer encryption</source>
        <translation>Preferencia de cifrado</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1934"/>
        <source>Require encryption</source>
        <translation>Necesitan cifrado</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1939"/>
        <source>Disable encryption</source>
        <translation>Deshabilitar cifrado</translation>
    </message>
    <message>
        <source>Torrent queueing</source>
        <translation type="obsolete">Gestión de Colas</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1980"/>
        <source>Maximum active downloads:</source>
        <translation>Máximo de archivos Bajando:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2000"/>
        <source>Maximum active uploads:</source>
        <translation>Máximo de archivos Subiendo:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2020"/>
        <source>Maximum active torrents:</source>
        <translation>Máximo de archivos Torrents:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="504"/>
        <source>When adding a torrent</source>
        <translation>Al añadir un torrent</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="20"/>
        <location filename="../preferences/options.ui" line="1504"/>
        <source>Options</source>
        <translation>Opciones</translation>
    </message>
    <message>
        <source>User Interface</source>
        <translation type="obsolete">Interfaz de Usuario</translation>
    </message>
    <message>
        <source>Visual Appearance</source>
        <translation type="obsolete">Apariencia Visual</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="269"/>
        <source>Action on double-click</source>
        <translation>Acción a realizar con un doble-click</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="284"/>
        <source>Downloading torrents:</source>
        <translation>Torrents Descargando:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="306"/>
        <location filename="../preferences/options.ui" line="332"/>
        <source>Open destination folder</source>
        <translation>Abrir carpeta de destino</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="319"/>
        <source>Completed torrents:</source>
        <translation>Torrents Completados:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="351"/>
        <source>Desktop</source>
        <translation>Escritorio</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="357"/>
        <source>Show splash screen on start up</source>
        <translation>Mostrar pantalla de bienvenida al iniciar</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="367"/>
        <source>Start qBittorrent minimized</source>
        <translation>Iniciar qBittorrent minimizado</translation>
    </message>
    <message>
        <source>Show qBittorrent icon in notification area</source>
        <translation type="obsolete">Mostrar icono de qBittorrent en el area de notificación</translation>
    </message>
    <message>
        <source>Use monochrome system tray icon (requires restart)</source>
        <translation type="obsolete">Usar icono monocromático en la bandeja del sistema (es necesario reinicar)</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="393"/>
        <source>Minimize qBittorrent to notification area</source>
        <translation>Minimizar qBittorrent en el area de notificación</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="403"/>
        <source>Close qBittorrent to notification area</source>
        <comment>i.e: The systray tray icon will still be visible when closing the main window.</comment>
        <translatorcomment>El icono de la bandeja del sistema seguirá siendo visible al cerrar la ventana principal.</translatorcomment>
        <translation>Al cerrar qBittorrent dejadlo activo en el area de notificación</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="412"/>
        <source>Tray icon style:</source>
        <translation>Estilo del icono en el panel:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="420"/>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="425"/>
        <source>Monochrome (Dark theme)</source>
        <translation>Monochrome (Dark theme)</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="430"/>
        <source>Monochrome (Light theme)</source>
        <translation>Monochrome (Light theme)</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="374"/>
        <source>Ask for program exit confirmation</source>
        <translation>Pedir confirmación para salir del programa</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="190"/>
        <source>User Interface Language:</source>
        <translation>Lenguaje de la interfaz:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="247"/>
        <source>Transfer List</source>
        <translation>Lista de Transferencia</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="384"/>
        <source>Show qBittorrent in notification area</source>
        <translation>Mostrar qBittorrent en el área de notificación</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="446"/>
        <source>Power Management</source>
        <translation>Administración de energía</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="452"/>
        <source>Inhibit system sleep when torrents are active</source>
        <translation>Inhabilitar la suspensión del equipo cuando aún queden torrents activos</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="513"/>
        <source>Display torrent content and some options</source>
        <translation>Mostrar el contenido del Torrent y opciones</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="523"/>
        <source>Do not start the download automatically</source>
        <comment>The torrent will be added to download list in pause state</comment>
        <translatorcomment>El torrente se añadirá a la lista de descargas de pausados</translatorcomment>
        <translation>No iniciar las descargas de forma automática</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="539"/>
        <source>Hard Disk</source>
        <translation>Disco Duro</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="548"/>
        <source>Save files to location:</source>
        <translation>Guardar los archivos en su ubicación:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="596"/>
        <source>Append the label of the torrent to the save path</source>
        <translation>Añadir la etiqueta del torrente a la ruta donde se guarda</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="606"/>
        <source>Pre-allocate disk space for all files</source>
        <translation>Pre-asignar espacio en el disco para todos los archivos</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="613"/>
        <source>Keep incomplete torrents in:</source>
        <translation>Mantener torrents incompletos en:</translation>
    </message>
    <message>
        <source>Append .!qB extension to incomplete files&apos; names</source>
        <translation type="obsolete">Añadir la extensión .!qB a los nombres de los archivos incompletos</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="666"/>
        <source>Automatically add torrents from:</source>
        <translation>Cargar automáticamente archivos Torrents desde:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="719"/>
        <source>Add folder...</source>
        <translation>Agregar carpeta...</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="818"/>
        <source>Email notification upon download completion</source>
        <translation>Notificarme por correo electrónico de la finalización de las descargas</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="832"/>
        <source>Destination email:</source>
        <translation>Dirección de correo electrónico:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="842"/>
        <source>SMTP server:</source>
        <translation>Servidor SMTP:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="891"/>
        <source>This server requires a secure connection (SSL)</source>
        <translation>El servidor requiere una conexión segura (SSL)</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="903"/>
        <source>Run an external program on torrent completion</source>
        <translation>Ejecutar un programa externo al completarse el torrent</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1241"/>
        <source>Otherwise, the proxy server is only used for tracker connections</source>
        <translation>Por contra, el servidor proxy se utilizará solamente para las conexiones tracker</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1244"/>
        <source>Use proxy for peer connections</source>
        <translation>Usar proxy para las conexiones entre pares</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1402"/>
        <source>Global Rate Limits</source>
        <translation>Limites globales de Ratio</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1520"/>
        <source>Apply rate limit to uTP connections</source>
        <translation>Aplicar límite de ratio para conexiones uTP</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1527"/>
        <source>Apply rate limit to transport overhead</source>
        <translation>Aplicar límite de ratio para transporte sobrecargado</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1540"/>
        <source>Alternative Global Rate Limits</source>
        <translation>Limites de Ratio Global alternativo</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1646"/>
        <source>Schedule the use of alternative rate limits</source>
        <translation>Programar el uso de límites de ratio alternativa</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2249"/>
        <source>Use HTTPS instead of HTTP</source>
        <translation>Usar HTTPS en lugar de HTTP</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2292"/>
        <source>Import SSL Certificate</source>
        <translation>Importación de certificados SSL</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2345"/>
        <source>Import SSL Key</source>
        <translation>Importar clave SSL</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2280"/>
        <source>Certificate:</source>
        <translation>Certificado:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2333"/>
        <source>Key:</source>
        <translation>Clave:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2367"/>
        <source>&lt;a href=http://httpd.apache.org/docs/2.1/ssl/ssl_faq.html#aboutcerts&gt;Information about certificates&lt;/a&gt;</source>
        <translation>&lt;a href=http://httpd.apache.org/docs/2.1/ssl/ssl_faq.html#aboutcerts&gt;Información sobre los certificados&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2436"/>
        <source>Update my dynamic domain name</source>
        <translation>Actualizar mi nombre de dominio dinámico</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2448"/>
        <source>Service:</source>
        <translation>Servicio:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2471"/>
        <source>Register</source>
        <translation>Registro</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2480"/>
        <source>Domain name:</source>
        <translation>Nombre de dominio:</translation>
    </message>
    <message>
        <source>Use %f to pass the torrent path in parameters</source>
        <translation type="obsolete">Use % f para pasar al torrente la ruta de los parámetros</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1010"/>
        <source>Use UPnP / NAT-PMP port forwarding from my router</source>
        <translation>Usar UPnP / NAT-PMP reenvío de puertos del router</translation>
    </message>
    <message>
        <source>Proxy server</source>
        <translation type="obsolete">Servidor Proxy</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1316"/>
        <source>IP Filtering</source>
        <translation>filtrado IP</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1357"/>
        <source>Reload the filter</source>
        <translation>Actualizar el filtro</translation>
    </message>
    <message>
        <source>Schedule the use of alternative speed limits</source>
        <translation type="obsolete">Calendario para utilización de los límites de velocidad alternativa</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1663"/>
        <source>from</source>
        <extracomment>from (time1 to time2)</extracomment>
        <translatorcomment>De x hora hasta x hora</translatorcomment>
        <translation>a partir de</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1731"/>
        <source>When:</source>
        <translation>Cuándo:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1814"/>
        <source>Privacy</source>
        <translation>Privacidad</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1820"/>
        <source>Enable DHT (decentralized network) to find more peers</source>
        <translation>Activar DHT (red descentralizada) para encontrar más pares</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1832"/>
        <source>Use a different port for DHT and BitTorrent</source>
        <translation>Usar difrente puerto para DHT y BitTorrent</translation>
    </message>
    <message utf8="true">
        <location filename="../preferences/options.ui" line="1893"/>
        <source>Exchange peers with compatible Bittorrent clients (µTorrent, Vuze, ...)</source>
        <translation>Intercambiar pares con clientes Bittorrent compatibles (µTorrent, Vuze, ...)</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1965"/>
        <source>Torrent Queueing</source>
        <translation>Torrents en Cola</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2082"/>
        <source>Share Ratio Limiting</source>
        <translation>Limite de Ratio de Compartición</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2239"/>
        <source>Use UPnP / NAT-PMP to forward the port from my router</source>
        <translation>Use UPnP / NAT-PMP para transmitir al puerto de mi router</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2412"/>
        <source>Bypass authentication for localhost</source>
        <translation>Eludir la autenticación para localhost</translation>
    </message>
    <message>
        <source>Protocol encryption:</source>
        <translation type="obsolete">Protocolo de encriptación:</translation>
    </message>
    <message>
        <source>Share ratio limiting</source>
        <translation type="obsolete">Límite ratio compartición</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2093"/>
        <source>Seed torrents until their ratio reaches</source>
        <translation>Ratio compartición de semillas Torrent</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2125"/>
        <source>then</source>
        <translation>luego</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2136"/>
        <source>Pause them</source>
        <translation>Pausar</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2141"/>
        <source>Remove them</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="2190"/>
        <source>Enable Web User Interface (Remote control)</source>
        <translation>Habilitar interfaz Web de usuario (Control remoto)</translation>
    </message>
    <message>
        <source>Listening port</source>
        <translation type="obsolete">Puerto de escucha</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="968"/>
        <source>Port used for incoming connections:</source>
        <translation>Puerto utilizado para conexiones entrantes:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="988"/>
        <source>Random</source>
        <translation>Aleatorio</translation>
    </message>
    <message>
        <source>Enable UPnP port mapping</source>
        <translation type="obsolete">Habilitar mapeo de puertos UPnP</translation>
    </message>
    <message>
        <source>Enable NAT-PMP port mapping</source>
        <translation type="obsolete">Habilitar mapeo de puertos NAT-PMP</translation>
    </message>
    <message>
        <source>Connections limit</source>
        <translation type="obsolete">Límite de conexiones</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1031"/>
        <source>Global maximum number of connections:</source>
        <translation>Número global máximo de conexiones:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1057"/>
        <source>Maximum number of connections per torrent:</source>
        <translation>Número máximo de conexiones por torrent:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1080"/>
        <source>Maximum number of upload slots per torrent:</source>
        <translation>Número máximo de slots de subida por torrent:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1420"/>
        <location filename="../preferences/options.ui" line="1575"/>
        <source>Upload:</source>
        <translation>Subida:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1456"/>
        <location filename="../preferences/options.ui" line="1602"/>
        <source>Download:</source>
        <translation>Bajada:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1449"/>
        <location filename="../preferences/options.ui" line="1482"/>
        <location filename="../preferences/options.ui" line="1595"/>
        <location filename="../preferences/options.ui" line="1622"/>
        <source>KiB/s</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="79"/>
        <location filename="../preferences/options.ui" line="82"/>
        <source>Behavior</source>
        <translation>Comportamiento</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="123"/>
        <source>BitTorrent</source>
        <translation>Bittorrent</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="182"/>
        <source>Language</source>
        <translation>Idioma</translation>
    </message>
    <message>
        <source>Global speed limits</source>
        <translation type="obsolete">Límites de velocidad global</translation>
    </message>
    <message>
        <source>Alternative global speed limits</source>
        <translation type="obsolete">Límites de velocidad global alternativa</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1687"/>
        <source>to</source>
        <extracomment>time1 to time2</extracomment>
        <translation>a</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1739"/>
        <source>Every day</source>
        <translation>Todos</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1744"/>
        <source>Week days</source>
        <translation>Días laborales</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1749"/>
        <source>Week ends</source>
        <translation>Fines de Semana</translation>
    </message>
    <message>
        <source>Bittorrent features</source>
        <translation type="obsolete">Características de Bittorrent</translation>
    </message>
    <message>
        <source>Enable DHT network (decentralized)</source>
        <translation type="obsolete">Habilitar red DHT (descentralizada)</translation>
    </message>
    <message>
        <source>Use a different port for DHT and Bittorrent</source>
        <translation type="obsolete">Utilizar un puerto diferente para la DHT y Bittorrent</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1852"/>
        <source>DHT port:</source>
        <translation>Puerto DHT:</translation>
    </message>
    <message>
        <source>Enable Peer Exchange / PeX (requires restart)</source>
        <translation type="obsolete">Activar intercambio de Pares / PeX (es necesario reiniciar qBittorrent)</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1906"/>
        <source>Look for peers on your local network</source>
        <translation>Puede buscar pares en su Red local</translation>
    </message>
    <message>
        <source>Enable Local Peer Discovery</source>
        <translation type="obsolete">Habilitar la fuente de búsqueda local de Pares</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation type="obsolete">Habilitado</translation>
    </message>
    <message>
        <source>Forced</source>
        <translation type="obsolete">Forzado</translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation type="obsolete">Deshabilitado</translation>
    </message>
    <message>
        <source>HTTP Communications (trackers, Web seeds, search engine)</source>
        <translation type="obsolete">Comunicaciones HTTP (Trackers, Semillas Web, Motores de búsqueda)</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1153"/>
        <source>Type:</source>
        <translation>Tipo:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1161"/>
        <source>(None)</source>
        <translation>(Ninguno)</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1176"/>
        <source>HTTP</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1187"/>
        <source>Host:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1213"/>
        <location filename="../preferences/options.ui" line="2204"/>
        <source>Port:</source>
        <translation>Puerto:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="852"/>
        <location filename="../preferences/options.ui" line="1254"/>
        <location filename="../preferences/options.ui" line="2380"/>
        <source>Authentication</source>
        <translation>Autentificación</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="659"/>
        <source>Append .!qB extension to incomplete files</source>
        <translation>Añadir .!qB como extensión para los archivos incompletos</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="864"/>
        <location filename="../preferences/options.ui" line="1268"/>
        <location filename="../preferences/options.ui" line="2419"/>
        <location filename="../preferences/options.ui" line="2494"/>
        <source>Username:</source>
        <translation>Nombre de Usuario:</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="874"/>
        <location filename="../preferences/options.ui" line="1288"/>
        <location filename="../preferences/options.ui" line="2426"/>
        <location filename="../preferences/options.ui" line="2508"/>
        <source>Password:</source>
        <translation>Contraseña:</translation>
    </message>
    <message>
        <source>Peer Communications</source>
        <translation type="obsolete">Comunicaciones Pares</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1166"/>
        <source>SOCKS4</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1171"/>
        <source>SOCKS5</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="729"/>
        <source>Remove folder</source>
        <translation>Eliminar carpeta</translation>
    </message>
    <message>
        <location filename="../preferences/options.ui" line="1328"/>
        <source>Filter path (.dat, .p2p, .p2b):</source>
        <translation>Ruta de Filtro (.dat, .p2p, .p2b):</translation>
    </message>
    <message>
        <source>HTTP Server</source>
        <translation type="obsolete">Servidor HTTP</translation>
    </message>
</context>
<context>
    <name>PreviewSelect</name>
    <message>
        <location filename="../previewselect.cpp" line="48"/>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <location filename="../previewselect.cpp" line="49"/>
        <source>Size</source>
        <translation>Tamaño</translation>
    </message>
    <message>
        <location filename="../previewselect.cpp" line="50"/>
        <source>Progress</source>
        <translation>Progreso</translation>
    </message>
    <message>
        <location filename="../previewselect.cpp" line="75"/>
        <location filename="../previewselect.cpp" line="110"/>
        <location filename="../previewselect.cpp" line="116"/>
        <source>Preview impossible</source>
        <translation>Imposible vista previa</translation>
    </message>
    <message>
        <location filename="../previewselect.cpp" line="75"/>
        <location filename="../previewselect.cpp" line="110"/>
        <location filename="../previewselect.cpp" line="116"/>
        <source>Sorry, we can&apos;t preview this file</source>
        <translation>Lo siento, no se puede realizar una vista previa de este archivo</translation>
    </message>
</context>
<context>
    <name>ProgramUpdater</name>
    <message>
        <source>Could not create the file %1</source>
        <translation type="obsolete">No se pudo crear el archivo %1</translation>
    </message>
    <message>
        <source>Failed to download the update at %1</source>
        <comment>%1 is an URL</comment>
        <translation type="obsolete">Error al descargar la actualización %1</translation>
    </message>
</context>
<context>
    <name>PropListDelegate</name>
    <message>
        <location filename="../properties/proplistdelegate.h" line="107"/>
        <source>Not downloaded</source>
        <translation>No descargar</translation>
    </message>
    <message>
        <location filename="../properties/proplistdelegate.h" line="116"/>
        <location filename="../properties/proplistdelegate.h" line="171"/>
        <source>Normal</source>
        <comment>Normal (priority)</comment>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../properties/proplistdelegate.h" line="110"/>
        <location filename="../properties/proplistdelegate.h" line="172"/>
        <source>High</source>
        <comment>High (priority)</comment>
        <translation>Alta</translation>
    </message>
    <message>
        <location filename="../properties/proplistdelegate.h" line="104"/>
        <source>Mixed</source>
        <comment>Mixed (priorities</comment>
        <translation>Mixto</translation>
    </message>
    <message>
        <location filename="../properties/proplistdelegate.h" line="113"/>
        <location filename="../properties/proplistdelegate.h" line="173"/>
        <source>Maximum</source>
        <comment>Maximum (priority)</comment>
        <translation>Máxima</translation>
    </message>
</context>
<context>
    <name>PropTabBar</name>
    <message>
        <location filename="../properties/proptabbar.cpp" line="55"/>
        <source>General</source>
        <translation>General</translation>
    </message>
    <message>
        <location filename="../properties/proptabbar.cpp" line="62"/>
        <source>Trackers</source>
        <translation>Trackers</translation>
    </message>
    <message>
        <location filename="../properties/proptabbar.cpp" line="68"/>
        <source>Peers</source>
        <translation>Pares</translation>
    </message>
    <message>
        <location filename="../properties/proptabbar.cpp" line="74"/>
        <source>HTTP Sources</source>
        <translation>Fuentes HTTP</translation>
    </message>
    <message>
        <location filename="../properties/proptabbar.cpp" line="80"/>
        <source>Content</source>
        <translation>Contenido</translation>
    </message>
    <message>
        <source>URL Seeds</source>
        <translation type="obsolete">URL Semillas</translation>
    </message>
    <message>
        <source>Files</source>
        <translation type="obsolete">Archivos</translation>
    </message>
</context>
<context>
    <name>PropertiesWidget</name>
    <message>
        <location filename="../properties/propertieswidget.ui" line="351"/>
        <source>Save path:</source>
        <translation>Directorio de destino:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="459"/>
        <source>Torrent hash:</source>
        <translation>Hash de torrent:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="545"/>
        <source>Comment:</source>
        <translation>Comentario:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="211"/>
        <source>Share ratio:</source>
        <translation>Ratio de Compartición:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="82"/>
        <location filename="../properties/propertieswidget.ui" line="228"/>
        <source>Downloaded:</source>
        <translation>Progreso:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="136"/>
        <source>Availability:</source>
        <translation>Disponibilidad:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="171"/>
        <source>Transfer</source>
        <translation>Transferencia</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="177"/>
        <source>Uploaded:</source>
        <translation>Subido:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="279"/>
        <source>Wasted:</source>
        <translation>Perdido:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="296"/>
        <source>Time active:</source>
        <extracomment>Time (duration) the torrent is active (not paused)</extracomment>
        <translation>Tiempo activo:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="502"/>
        <source>Pieces size:</source>
        <translation>Tamaño de las piezas:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="774"/>
        <source>Torrent content:</source>
        <translation>Contenido del torrent:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="827"/>
        <source>Select All</source>
        <translation>Seleccionar Todo</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="834"/>
        <source>Select None</source>
        <translation>Quitar Selecciones</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="882"/>
        <location filename="../properties/propertieswidget.ui" line="885"/>
        <source>Do not download</source>
        <translation>No descargar</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="194"/>
        <source>UP limit:</source>
        <translation>Límite Subida:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="245"/>
        <source>DL limit:</source>
        <translation>Límite Bajada:</translation>
    </message>
    <message>
        <source>Time elapsed:</source>
        <translation type="obsolete">Tiempo transcurrido:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="262"/>
        <source>Connections:</source>
        <translation>Número Conexiones:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="313"/>
        <source>Reannounce in:</source>
        <translation>Republicar en:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="339"/>
        <source>Information</source>
        <translation>Información</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="413"/>
        <source>Created on:</source>
        <translation>Fecha de creación:</translation>
    </message>
    <message>
        <source>General</source>
        <translation type="obsolete">General</translation>
    </message>
    <message>
        <source>Trackers</source>
        <translation type="obsolete">Trackers</translation>
    </message>
    <message>
        <source>Peers</source>
        <translation type="obsolete">Pares</translation>
    </message>
    <message>
        <source>URL seeds</source>
        <translation type="obsolete">URL Semillas</translation>
    </message>
    <message>
        <source>Files</source>
        <translation type="obsolete">Archivos</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="476"/>
        <source>Priority</source>
        <translation>Prioridad</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="867"/>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="877"/>
        <source>Maximum</source>
        <translation>Máxima</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.ui" line="872"/>
        <source>High</source>
        <translation>Alta</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="329"/>
        <location filename="../properties/propertieswidget.cpp" line="330"/>
        <source>this session</source>
        <translation>en esta sesión</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="334"/>
        <location filename="../properties/propertieswidget.cpp" line="338"/>
        <source>/s</source>
        <comment>/second (i.e. per second)</comment>
        <translation></translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="341"/>
        <source>Seeded for %1</source>
        <comment>e.g. Seeded for 3m10s</comment>
        <translation>Semillas por %1</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="345"/>
        <source>%1 max</source>
        <comment>e.g. 10 max</comment>
        <translation></translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="435"/>
        <location filename="../properties/propertieswidget.cpp" line="457"/>
        <source>I/O Error</source>
        <translation>Error de Entrada/Salida</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="435"/>
        <source>This file does not exist yet.</source>
        <translation>Ese archivo todavía no existe.</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="457"/>
        <source>This folder does not exist yet.</source>
        <translation>Ese archivo todavía no existe.</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="467"/>
        <source>Rename...</source>
        <translation>Renombrar...</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="518"/>
        <source>Rename the file</source>
        <translation>Renombrar archivo</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="519"/>
        <source>New name:</source>
        <translation>Nuevo nombre:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="523"/>
        <location filename="../properties/propertieswidget.cpp" line="555"/>
        <source>The file could not be renamed</source>
        <translation>No se puede cambiar el nombre de archivo</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="524"/>
        <source>This file name contains forbidden characters, please choose a different one.</source>
        <translation>El nombre introducido contiene caracteres prohibidos, por favor elija otro.</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="556"/>
        <location filename="../properties/propertieswidget.cpp" line="594"/>
        <source>This name is already in use in this folder. Please use a different name.</source>
        <translation>Este nombre ya está en uso. Por favor, use un nombre diferente.</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="593"/>
        <source>The folder could not be renamed</source>
        <translation>No se puede cambiar el nombre de archivo</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="632"/>
        <source>New url seed</source>
        <comment>New HTTP source</comment>
        <translation>Nueva semilla url</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="633"/>
        <source>New url seed:</source>
        <translation>Nueva semilla url:</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="638"/>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="639"/>
        <source>This url seed is already in the list.</source>
        <translation>Esta semilla url ya está en la lista.</translation>
    </message>
    <message>
        <location filename="../properties/propertieswidget.cpp" line="681"/>
        <location filename="../properties/propertieswidget.cpp" line="684"/>
        <source>Choose save path</source>
        <translation>Seleccione un directorio de destino</translation>
    </message>
    <message>
        <source>Save path creation error</source>
        <translation type="obsolete">Error en la creación del directorio de destino</translation>
    </message>
    <message>
        <source>Could not create the save path</source>
        <translation type="obsolete">No se pudo crear el directorio de destino</translation>
    </message>
</context>
<context>
    <name>QBtSession</name>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="226"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="232"/>
        <source>%1 reached the maximum ratio you set.</source>
        <translation>%1 alcanzó el ratio máximo establecido.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="227"/>
        <source>Removing torrent %1...</source>
        <translation>Extrayendo torrent %1...</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="233"/>
        <source>Pausing torrent %1...</source>
        <translation>Torrent Pausado %1...</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="287"/>
        <source>qBittorrent is bound to port: TCP/%1</source>
        <comment>e.g: qBittorrent is bound to port: 6881</comment>
        <translation>qBittorrent está usando el puerto: TCP/%1</translation>
    </message>
    <message>
        <source>UPnP support [ON]</source>
        <translation type="obsolete">Soporte para UPnP [Encendido]</translation>
    </message>
    <message>
        <source>UPnP support [OFF]</source>
        <translation type="obsolete">Soporte para UPnP [Apagado]</translation>
    </message>
    <message>
        <source>NAT-PMP support [ON]</source>
        <translation type="obsolete">Soporte para NAT-PMP [Encendido]</translation>
    </message>
    <message>
        <source>NAT-PMP support [OFF]</source>
        <translation type="obsolete">Soporte para NAT-PMP[Apagado]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="384"/>
        <source>HTTP user agent is %1</source>
        <translation>HTTP de usuario es %1</translation>
    </message>
    <message>
        <source>Using a disk cache size of %1 MiB</source>
        <translation type="obsolete">Tamaño cache del Disco %1 MiB</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="494"/>
        <source>DHT support [ON], port: UDP/%1</source>
        <translation>Soporte para DHT [Encendido], puerto: UPD/%1</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="496"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="500"/>
        <source>DHT support [OFF]</source>
        <translation>Soporte para DHT [Apagado]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="504"/>
        <source>PeX support [ON]</source>
        <translation>Soporte para PeX [Encendido]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="506"/>
        <source>PeX support [OFF]</source>
        <translation>Soporte PeX [Apagado]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="509"/>
        <source>Restart is required to toggle PeX support</source>
        <translation>Es necesario reiniciar para activar el soporte PeX</translation>
    </message>
    <message>
        <source>Local Peer Discovery [ON]</source>
        <translation type="obsolete">Estado local de Pares [Encendido]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="517"/>
        <source>Local Peer Discovery support [OFF]</source>
        <translation>Soporte para estado local de Pares [Apagado]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="529"/>
        <source>Encryption support [ON]</source>
        <translation>Soporte para encriptado [Encendido]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="534"/>
        <source>Encryption support [FORCED]</source>
        <translation>Soporte para encriptado [Forzado]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="539"/>
        <source>Encryption support [OFF]</source>
        <translation>Sopote para encriptado [Apagado]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="600"/>
        <source>Embedded Tracker [ON]</source>
        <translation>Integrador de Tracker [Encendido]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="602"/>
        <source>Failed to start the embedded tracker!</source>
        <translation>Error al iniciar el integrado de Tracker!</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="605"/>
        <source>Embedded Tracker [OFF]</source>
        <translation>Integrador de Tracker  [Apagado]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="659"/>
        <source>The Web UI is listening on port %1</source>
        <translation>Puerto de escucha de Interfaz Usuario Web %1</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="661"/>
        <source>Web User Interface Error - Unable to bind Web UI to port %1</source>
        <translation>Error interfaz de Usuario Web - No se puede enlazar al puerto %1</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="796"/>
        <source>&apos;%1&apos; was removed from transfer list and hard disk.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>&apos;%1&apos; Fue eliminado de la lista de transferencia y del disco.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="798"/>
        <source>&apos;%1&apos; was removed from transfer list.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>&apos;%1&apos; Fue eliminado de la lista de transferencia.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="880"/>
        <source>&apos;%1&apos; is not a valid magnet URI.</source>
        <translation>&apos;%1&apos; no es una URI válida.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="896"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1018"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1023"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1025"/>
        <source>&apos;%1&apos; is already in download list.</source>
        <comment>e.g: &apos;xxx.avi&apos; is already in download list.</comment>
        <translation>&apos;%1&apos; ya está en la lista de descargas.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1169"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1177"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1182"/>
        <source>&apos;%1&apos; resumed. (fast resume)</source>
        <comment>&apos;/home/y/xxx.torrent&apos; was resumed. (fast resume)</comment>
        <translation>&apos;%1&apos; reiniciado. (reinicio rápido)</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="952"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1171"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1179"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1184"/>
        <source>&apos;%1&apos; added to download list.</source>
        <comment>&apos;/home/y/xxx.torrent&apos; was added to download list.</comment>
        <translation>&apos;%1&apos; agregado a la lista de descargas.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="375"/>
        <source>UPnP / NAT-PMP support [ON]</source>
        <translation>Soporte UPnP / NAT-PMP [ON]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="378"/>
        <source>UPnP / NAT-PMP support [OFF]</source>
        <translation>Soporte UPnP / NAT-PMP [OFF]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="440"/>
        <source>Reporting IP address %1 to trackers...</source>
        <translation>Dirección IP de infomes %1 de trackers...</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="514"/>
        <source>Local Peer Discovery support [ON]</source>
        <translation>Soporte Hallado Local de Pares [ON]</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="987"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="994"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="996"/>
        <source>Unable to decode torrent file: &apos;%1&apos;</source>
        <comment>e.g: Unable to decode torrent file: &apos;/home/y/xxx.torrent&apos;</comment>
        <translation>Imposible decodificar el archivo torrent: &apos;%1&apos;</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1000"/>
        <source>This file is either corrupted or this isn&apos;t a torrent.</source>
        <translation>Este archivo puede estar corrupto, o no ser un torrent.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1040"/>
        <source>Error: The torrent %1 does not contain any file.</source>
        <translation>Error: este torrent %1 no contiene ningún archivo.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1328"/>
        <source>Note: new trackers were added to the existing torrent.</source>
        <translation>Nota: nuevos Trackers se han añadido al torrent existente.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1354"/>
        <source>Note: new URL seeds were added to the existing torrent.</source>
        <translation>Nota: nuevas semillas URL se han añadido al Torrent existente.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1710"/>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;was blocked due to your IP filter&lt;/i&gt;</source>
        <comment>x.y.z.w was blocked</comment>
        <translation>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;fue bloqueado debido al filtro IP&lt;/i&gt;</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1712"/>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;was banned due to corrupt pieces&lt;/i&gt;</source>
        <comment>x.y.z.w was banned</comment>
        <translation>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; &lt;i&gt;Fue bloqueado debido a fragmentos corruptos&lt;/i&gt;</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1890"/>
        <source>The network interface defined is invalid: %1</source>
        <translation>La interfaz de la red definida no es válida: %1</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1891"/>
        <source>Trying any other network interface available instead.</source>
        <translation>Tratando cualquier interfaz de red disponibles en su lugar.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1914"/>
        <source>Listening on IP address %1 on network interface %2...</source>
        <translation>Escuchando la dirección IP %1 de la interfaz de red %2...</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="1917"/>
        <source>Failed to listen on network interface %1</source>
        <translation>No se ha podido escuchar la interfaz de red %1</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2113"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2115"/>
        <source>Recursive download of file %1 embedded in torrent %2</source>
        <comment>Recursive download of test.torrent embedded in torrent test2</comment>
        <translation>Descarga recursiva de archivo %1 inscrustada en Torrent %2</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2210"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2212"/>
        <source>Unable to decode %1 torrent file.</source>
        <translation>No se puede descodificar %1 archivo torrent.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2260"/>
        <source>The computer will now go to sleep mode unless you cancel within the next 15 seconds...</source>
        <translation>El equipo entrará en 15 segundos en estado de suspensión, a menos que lo cancele...</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2262"/>
        <source>The computer will now be switched off unless you cancel within the next 15 seconds...</source>
        <translation>El equipo se apagará en 15 segundos, a menos que lo cancele...</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2264"/>
        <source>qBittorrent will now exit unless you cancel within the next 15 seconds...</source>
        <translation>qBittorrent será cerrado en 15 segundos, a menos que lo cancele...</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2871"/>
        <source>Successfuly parsed the provided IP filter: %1 rules were applied.</source>
        <comment>%1 is a number</comment>
        <translation>Análisis exitoso de filtrado IP: %1 normas aplicadas.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2877"/>
        <source>Error: Failed to parse the provided IP filter.</source>
        <translation>Error: Falló el análisis de filtrado IP.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2160"/>
        <source>Torrent name: %1</source>
        <translation>Nombre del torrent: %1</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2161"/>
        <source>Torrent size: %1</source>
        <translation>Tamaño del torrent: %1</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2162"/>
        <source>Save path: %1</source>
        <translation>Guardar ruta: %1</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2163"/>
        <source>The torrent was downloaded in %1.</source>
        <comment>The torrent was downloaded in 1 hour and 20 seconds</comment>
        <translation>El torrernt se descargó en %1.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2164"/>
        <source>Thank you for using qBittorrent.</source>
        <translation>Gracias por utilizar qBittorrent.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2167"/>
        <source>[qBittorrent] %1 has finished downloading</source>
        <translation>[qBittorrent] %1 ha finalizado la descarga</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2427"/>
        <source>An I/O error occured, &apos;%1&apos; paused.</source>
        <translation>Error de E/S ocurrido, &apos;%1&apos; pausado.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2428"/>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2558"/>
        <source>Reason: %1</source>
        <translation>Razón: %1</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2517"/>
        <source>UPnP/NAT-PMP: Port mapping failure, message: %1</source>
        <translation>UPnP/NAT-PMP: Falló el mapeo del puerto, mensaje: %1</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2522"/>
        <source>UPnP/NAT-PMP: Port mapping successful, message: %1</source>
        <translation>UPnP/NAT-PMP: Mapeo del puerto exitoso, mensaje: %1</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2553"/>
        <source>File sizes mismatch for torrent %1, pausing it.</source>
        <translation>El tamaño de archivo no coincide con el torrent %1, pausandolo.</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2557"/>
        <source>Fast resume data was rejected for torrent %1, checking again...</source>
        <translation>Se negaron los datos para reinicio rápido del torrent: %1, verificando de nuevo...</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2563"/>
        <source>Url seed lookup failed for url: %1, message: %2</source>
        <translation>Falló la búsqueda de semilla por Url para la Url: %1, mensaje: %2</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/qbtsession.cpp" line="2692"/>
        <source>Downloading &apos;%1&apos;, please wait...</source>
        <comment>e.g: Downloading &apos;xxx.torrent&apos;, please wait...</comment>
        <translation>Descargando &apos;%1&apos;, por favor espere...</translation>
    </message>
</context>
<context>
    <name>RSS</name>
    <message>
        <location filename="../rss/rss.ui" line="17"/>
        <source>Search</source>
        <translation>Buscar</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="25"/>
        <source>New subscription</source>
        <translation>Nueva suscripción</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="35"/>
        <location filename="../rss/rss.ui" line="183"/>
        <location filename="../rss/rss.ui" line="186"/>
        <source>Mark items read</source>
        <translation>Marcar para leer</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="54"/>
        <source>Update all</source>
        <translation>Actualizar todo</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="83"/>
        <source>RSS Downloader...</source>
        <translation>Descargar RSS...</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="90"/>
        <source>Settings...</source>
        <translation>Configuración...</translation>
    </message>
    <message>
        <source>Feed URL</source>
        <translation type="obsolete">Canal URL</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="154"/>
        <source>Rename...</source>
        <translation>Renombrar...</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="162"/>
        <location filename="../rss/rss.ui" line="165"/>
        <source>Update</source>
        <translation>Actualizar</translation>
    </message>
    <message>
        <source>RSS feed downloader...</source>
        <translation type="obsolete">Descargar Canal RSS...</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="206"/>
        <source>New folder...</source>
        <translation>Nueva carpeta...</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="211"/>
        <source>Manage cookies...</source>
        <translation>Administrar Cookies...</translation>
    </message>
    <message>
        <source>RSS feeds</source>
        <translation type="obsolete">Canales RSS</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="112"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Torrents:&lt;/span&gt; &lt;span style=&quot; font-style:italic;&quot;&gt;(double-click to download)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Torrents:&lt;/span&gt; &lt;span style=&quot; font-style:italic;&quot;&gt;(doble-click para iniciar la descarga)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Article title</source>
        <translation type="obsolete">Título del artículo</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="170"/>
        <source>New subscription...</source>
        <translation>Nueva suscripción...</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="175"/>
        <location filename="../rss/rss.ui" line="178"/>
        <source>Update all feeds</source>
        <translation>Actualizar todos los Canales</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="146"/>
        <location filename="../rss/rss.ui" line="149"/>
        <source>Delete</source>
        <translation>Borrar</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="157"/>
        <source>Rename</source>
        <translation>Renombrar</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="191"/>
        <source>Download torrent</source>
        <translation>descargar torrent</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="196"/>
        <source>Open news URL</source>
        <translation>Abrir nueva URL</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="201"/>
        <source>Copy feed URL</source>
        <translation>Copiar Canal URL</translation>
    </message>
    <message>
        <location filename="../rss/rss.ui" line="51"/>
        <source>Refresh RSS streams</source>
        <translation>Actualizar los Canales RSS</translation>
    </message>
</context>
<context>
    <name>RSSImp</name>
    <message>
        <location filename="../rss/rss_imp.cpp" line="203"/>
        <source>Please type a rss stream url</source>
        <translation>Por favor escribe una URL de un Canal RSS</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="203"/>
        <source>Stream URL:</source>
        <translation>URL del Canal:</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="237"/>
        <location filename="../rss/rss_imp.cpp" line="241"/>
        <source>Are you sure? -- qBittorrent</source>
        <translation>¿Estás seguro? -- qBittorrent</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="238"/>
        <location filename="../rss/rss_imp.cpp" line="242"/>
        <source>&amp;Yes</source>
        <translation>&amp;Sí</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="238"/>
        <location filename="../rss/rss_imp.cpp" line="242"/>
        <source>&amp;No</source>
        <translation>&amp;No</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="149"/>
        <source>Please choose a folder name</source>
        <translation>Por favor elija un nombre para la carpeta</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="149"/>
        <source>Folder name:</source>
        <translation>Nombre de la carpeta:</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="149"/>
        <source>New folder</source>
        <translation>Nueva carpeta</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="170"/>
        <source>Overwrite attempt</source>
        <translation>Intentando sobrescribir</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="171"/>
        <source>You cannot overwrite %1 item.</source>
        <comment>You cannot overwrite myFolder item.</comment>
        <translation>Imposible sobrescribir %1 sector.</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="208"/>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="209"/>
        <source>This rss feed is already in the list.</source>
        <translation>Esta fuente de RSS ya está en la lista.</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="237"/>
        <source>Are you sure you want to delete these elements from the list?</source>
        <translation>¿Seguro que quiere eliminar estos elementos de la lista?</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="241"/>
        <source>Are you sure you want to delete this element from the list?</source>
        <translation>¿Seguro que desea eliminar este elemento de la lista?</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="351"/>
        <source>Please choose a new name for this RSS feed</source>
        <translation>Por favor, elija un nuevo nombre para el Canal RSS</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="351"/>
        <source>New feed name:</source>
        <translation>Nombre del nuevo Canal:</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="355"/>
        <source>Name already in use</source>
        <translation>Ese nombre ya se encuentra en uso</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="355"/>
        <source>This name is already used by another item, please choose another one.</source>
        <translation>Ese nombre ya se está usando, por favor, elija otro.</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="508"/>
        <source>Date: </source>
        <translation>Fecha:</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="511"/>
        <source>Author: </source>
        <translation>Autor:</translation>
    </message>
    <message>
        <location filename="../rss/rss_imp.cpp" line="554"/>
        <source>Unread</source>
        <translation>No leídos</translation>
    </message>
</context>
<context>
    <name>RssArticle</name>
    <message>
        <source>No description available</source>
        <translation type="obsolete">Sin descripción disponible</translation>
    </message>
</context>
<context>
    <name>RssFeed</name>
    <message>
        <location filename="../rss/rssfeed.cpp" line="292"/>
        <source>Automatically downloading %1 torrent from %2 RSS feed...</source>
        <translation>Descargar automática %1 Torrent %2 Canal RSS...</translation>
    </message>
</context>
<context>
    <name>RssItem</name>
    <message>
        <source>No description available</source>
        <translation type="obsolete">Sin descripción disponible</translation>
    </message>
</context>
<context>
    <name>RssSettings</name>
    <message>
        <source>RSS Reader Settings</source>
        <translatorcomment>Ajustaments Lector RSS</translatorcomment>
        <translation type="obsolete">Ajustes Lector RSS</translation>
    </message>
    <message>
        <source>RSS feeds refresh interval:</source>
        <translation type="obsolete">Intervalo de actualización de Canales RSS:</translation>
    </message>
    <message>
        <source>minutes</source>
        <translation type="obsolete">minutos</translation>
    </message>
    <message>
        <source>Maximum number of articles per feed:</source>
        <translation type="obsolete">Número máximo de artículos por Canal:</translation>
    </message>
</context>
<context>
    <name>RssSettingsDlg</name>
    <message>
        <location filename="../rss/rsssettingsdlg.ui" line="14"/>
        <source>RSS Reader Settings</source>
        <translation>Ajustes Lector RSS</translation>
    </message>
    <message>
        <location filename="../rss/rsssettingsdlg.ui" line="47"/>
        <source>RSS feeds refresh interval:</source>
        <translation>Intervalo de actualización de Canales RSS:</translation>
    </message>
    <message>
        <location filename="../rss/rsssettingsdlg.ui" line="70"/>
        <source>minutes</source>
        <translation>minutos</translation>
    </message>
    <message>
        <location filename="../rss/rsssettingsdlg.ui" line="77"/>
        <source>Maximum number of articles per feed:</source>
        <translation>Número máximo de artículos por Canal:</translation>
    </message>
</context>
<context>
    <name>RssStream</name>
    <message>
        <source>Automatically downloading %1 torrent from %2 RSS feed...</source>
        <translation type="obsolete">Descargar automática %1 Torrent %2 Canal RSS...</translation>
    </message>
</context>
<context>
    <name>ScanFoldersModel</name>
    <message>
        <location filename="../scannedfoldersmodel.cpp" line="103"/>
        <source>Watched Folder</source>
        <translation>Buscar ficheros .torrents</translation>
    </message>
    <message>
        <location filename="../scannedfoldersmodel.cpp" line="104"/>
        <source>Download here</source>
        <translation>Descargar Torrents aquí</translation>
    </message>
</context>
<context>
    <name>SearchCategories</name>
    <message>
        <location filename="../searchengine/supportedengines.h" line="51"/>
        <source>All categories</source>
        <translation>Todas las categorías</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="52"/>
        <source>Movies</source>
        <translation>Vídeos</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="53"/>
        <source>TV shows</source>
        <translation>Programas TV</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="54"/>
        <source>Music</source>
        <translation>Música</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="55"/>
        <source>Games</source>
        <translation>Juegos</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="56"/>
        <source>Anime</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="57"/>
        <source>Software</source>
        <translation>Programas Pc</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="58"/>
        <source>Pictures</source>
        <translation>Imágenes</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="59"/>
        <source>Books</source>
        <translation>Libros</translation>
    </message>
</context>
<context>
    <name>SearchEngine</name>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="332"/>
        <source>Empty search pattern</source>
        <translation>Patrón de búsqueda vacío</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="332"/>
        <source>Please type a search pattern first</source>
        <translation>Por favor escriba primero un patrón de búsqueda</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="370"/>
        <location filename="../searchengine/searchengine.cpp" line="466"/>
        <source>Results</source>
        <translation>Resultados</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="445"/>
        <source>Searching...</source>
        <translation>Buscando...</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="213"/>
        <source>Cut</source>
        <translation>Cortar</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="214"/>
        <source>Copy</source>
        <translation>Copiar</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="215"/>
        <source>Paste</source>
        <translation>Pegar</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="216"/>
        <source>Clear field</source>
        <translation>Eliminar de la lista</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="217"/>
        <source>Clear completion history</source>
        <translation>Limpiar historial de búsquedas</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="236"/>
        <source>Confirmation</source>
        <translation>Confirmación</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="236"/>
        <source>Are you sure you want to clear the history?</source>
        <translation>¿Estás seguro que desea borrar el historial?</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="290"/>
        <location filename="../searchengine/searchengine.cpp" line="320"/>
        <location filename="../searchengine/searchengine.cpp" line="321"/>
        <source>Search</source>
        <translation>Buscar</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="301"/>
        <source>Missing Python Interpreter</source>
        <translation>Falta intérprete de Python</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="302"/>
        <source>Python 2.x is required to use the search engine but it does not seem to be installed.
Do you want to install it now?</source>
        <translation>Python 2.x es necesario para utilizar el motor de búsqueda pero no parece que esté instalado.
¿Desea instalarlo ahora?</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="585"/>
        <source>Search Engine</source>
        <translation>Motor de Búsqueda</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="585"/>
        <location filename="../searchengine/searchengine.cpp" line="600"/>
        <source>Search has finished</source>
        <translation>Búsqueda terminada</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="591"/>
        <source>An error occured during search...</source>
        <translation>Ocurrió un error durante la búsqueda...</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="589"/>
        <location filename="../searchengine/searchengine.cpp" line="595"/>
        <source>Search aborted</source>
        <translation>Búsqueda abortada</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="178"/>
        <source>Download error</source>
        <translation>Error de descarga</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="178"/>
        <source>Python setup could not be downloaded, reason: %1.
Please install it manually.</source>
        <translation>La instalación de Python no se pudo realizar, la razón: %1.
Por favor, instálelo de forma manual.</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="598"/>
        <source>Search returned no results</source>
        <translation>La búsqueda no devolvió resultados</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="605"/>
        <source>Results</source>
        <comment>i.e: Search results</comment>
        <translation>Resultados</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="641"/>
        <location filename="../searchengine/searchengine.cpp" line="647"/>
        <source>Unknown</source>
        <translation>Desconocido</translation>
    </message>
</context>
<context>
    <name>SearchTab</name>
    <message>
        <location filename="../searchengine/searchtab.cpp" line="55"/>
        <source>Name</source>
        <comment>i.e: file name</comment>
        <translation>Nombre</translation>
    </message>
    <message>
        <location filename="../searchengine/searchtab.cpp" line="56"/>
        <source>Size</source>
        <comment>i.e: file size</comment>
        <translation>Tamaño</translation>
    </message>
    <message>
        <location filename="../searchengine/searchtab.cpp" line="57"/>
        <source>Seeders</source>
        <comment>i.e: Number of full sources</comment>
        <translation>Semillas</translation>
    </message>
    <message>
        <location filename="../searchengine/searchtab.cpp" line="58"/>
        <source>Leechers</source>
        <comment>i.e: Number of partial sources</comment>
        <translation>Leechers</translation>
    </message>
    <message>
        <location filename="../searchengine/searchtab.cpp" line="59"/>
        <source>Search engine</source>
        <translation>Motor de búsqueda</translation>
    </message>
</context>
<context>
    <name>ShutdownConfirmDlg</name>
    <message>
        <location filename="../qtlibtorrent/shutdownconfirm.h" line="44"/>
        <source>Shutdown confirmation</source>
        <translation>Cerrar confirmación</translation>
    </message>
</context>
<context>
    <name>SpeedLimitDialog</name>
    <message>
        <location filename="../speedlimitdlg.h" line="84"/>
        <source>KiB/s</source>
        <translation>KiB/s</translation>
    </message>
</context>
<context>
    <name>StatusBar</name>
    <message>
        <location filename="../statusbar.h" line="67"/>
        <location filename="../statusbar.h" line="180"/>
        <source>Connection status:</source>
        <translation>Estado de la conexión:</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="67"/>
        <location filename="../statusbar.h" line="180"/>
        <source>No direct connections. This may indicate network configuration problems.</source>
        <translation>No hay conexiones directas. Esto puede indicar problemas en la configuración de red.</translation>
    </message>
    <message>
        <source>D: %1 B/s - T: %2</source>
        <comment>Download speed: x B/s - Transferred: x MiB</comment>
        <translation type="obsolete">Bajada: %1 B/s - Total: %2</translation>
    </message>
    <message>
        <source>U: %1 B/s - T: %2</source>
        <comment>Upload speed: x B/s - Transferred: x MiB</comment>
        <translation type="obsolete">Subida: %1 B/s - Total: %2</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="95"/>
        <location filename="../statusbar.h" line="187"/>
        <source>DHT: %1 nodes</source>
        <translation>DHT: %1 nodos</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="150"/>
        <source>qBittorrent needs to be restarted</source>
        <translation>Es necesario reiniciar qBittorrent</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="160"/>
        <source>qBittorrent was just updated and needs to be restarted for the changes to be effective.</source>
        <translation>qBittorrent a sido actualizado y debe ser reiniciado para que los cambios sean efectivos.</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="172"/>
        <location filename="../statusbar.h" line="177"/>
        <source>Connection Status:</source>
        <translation>Estado de la conexión:</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="172"/>
        <source>Offline. This usually means that qBittorrent failed to listen on the selected port for incoming connections.</source>
        <translation>Fuera de línea. Esto normalmente significa que qBittorrent no puede escuchar el puerto seleccionado para las conexiones entrantes.</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="177"/>
        <source>Online</source>
        <translation>En línea</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="193"/>
        <location filename="../statusbar.h" line="194"/>
        <source>%1/s</source>
        <comment>Per second</comment>
        <translation>%1/s</translation>
    </message>
    <message>
        <source>D: %1/s - T: %2</source>
        <comment>Download speed: x KiB/s - Transferred: x MiB</comment>
        <translation type="obsolete">Bajada: %1/s - Total: %2</translation>
    </message>
    <message>
        <source>U: %1/s - T: %2</source>
        <comment>Upload speed: x KiB/s - Transferred: x MiB</comment>
        <translation type="obsolete">Subida: %1/s - Total: %2</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="204"/>
        <source>Click to switch to alternative speed limits</source>
        <translation>Clique para cambiar a los límites de velocidad alternativa</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="200"/>
        <source>Click to switch to regular speed limits</source>
        <translation>Clique para cambiar a los límites de velocidad normal</translation>
    </message>
    <message>
        <source>Click to disable alternative speed limits</source>
        <translation type="obsolete">Click para desactivar los límites de velocidad alternativa</translation>
    </message>
    <message>
        <source>Click to enable alternative speed limits</source>
        <translation type="obsolete">Click para activar los límites de velocidad alternativa</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="220"/>
        <source>Global Download Speed Limit</source>
        <translation>Velocidad límite global de descarga</translation>
    </message>
    <message>
        <location filename="../statusbar.h" line="245"/>
        <source>Global Upload Speed Limit</source>
        <translation>Velocidad límite global de subida</translation>
    </message>
</context>
<context>
    <name>TorrentCreatorDlg</name>
    <message>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="73"/>
        <source>Select a folder to add to the torrent</source>
        <translation>Seleccione otra carpeta para agregar el torrent</translation>
    </message>
    <message>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="89"/>
        <source>Select a file to add to the torrent</source>
        <translation>Seleccione otro archivo para agregar el torrent</translation>
    </message>
    <message>
        <source>Please type an announce URL</source>
        <translation type="obsolete">Por favor escribe una Dirección URL</translation>
    </message>
    <message>
        <source>Announce URL:</source>
        <comment>Tracker URL</comment>
        <translation type="obsolete">Dirección URL:</translation>
    </message>
    <message>
        <source>Please type a web seed url</source>
        <translation type="obsolete">Por favor escribe una Dirección Web para la Semilla</translation>
    </message>
    <message>
        <source>Web seed URL:</source>
        <translation type="obsolete">Dirección Web de la Semilla:</translation>
    </message>
    <message>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="112"/>
        <source>No input path set</source>
        <translation>Sin ruta de destino establecida</translation>
    </message>
    <message>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="112"/>
        <source>Please type an input path first</source>
        <translation>Por favor escriba primero una ruta de entrada</translation>
    </message>
    <message>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="122"/>
        <source>Select destination torrent file</source>
        <translation>Seleccione un destino para el archivo torrent</translation>
    </message>
    <message>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="122"/>
        <source>Torrent Files</source>
        <translation>Archivos Torrent</translation>
    </message>
    <message>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="149"/>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="165"/>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="180"/>
        <source>Torrent creation</source>
        <translation>Crear nuevo Torrent</translation>
    </message>
    <message>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="149"/>
        <source>Torrent creation was unsuccessful, reason: %1</source>
        <translation>La creación del torrent no ha sido exitosa, razón: %1</translation>
    </message>
    <message>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="165"/>
        <source>Created torrent file is invalid. It won&apos;t be added to download list.</source>
        <translation>La creación del  archivo torrent no es válida. No se añadirá a la lista de descargas.</translation>
    </message>
    <message>
        <location filename="../torrentcreator/torrentcreatordlg.cpp" line="180"/>
        <source>Torrent was created successfully:</source>
        <translation>El Torrent se creó con éxito:</translation>
    </message>
</context>
<context>
    <name>TorrentFilesModel</name>
    <message>
        <location filename="../torrentfilesmodel.h" line="343"/>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <location filename="../torrentfilesmodel.h" line="343"/>
        <source>Size</source>
        <translation>Tamaño</translation>
    </message>
    <message>
        <location filename="../torrentfilesmodel.h" line="343"/>
        <source>Progress</source>
        <translation>Progreso</translation>
    </message>
    <message>
        <location filename="../torrentfilesmodel.h" line="343"/>
        <source>Priority</source>
        <translation>Prioridad</translation>
    </message>
</context>
<context>
    <name>TorrentImportDlg</name>
    <message>
        <location filename="../torrentimportdlg.ui" line="14"/>
        <source>Torrent Import</source>
        <translation>Importar Torrent</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.ui" line="38"/>
        <source>This assistant will help you share with qBittorrent a torrent that you have already downloaded.</source>
        <translation>Este asistente le ayudará a compartir con qBittorrent, un torrente ya descargado.</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.ui" line="50"/>
        <source>Torrent file to import:</source>
        <translation>Archivo Torrent para importar:</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.ui" line="66"/>
        <location filename="../torrentimportdlg.ui" line="94"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.ui" line="75"/>
        <source>Content location:</source>
        <translation>Ubicación del contenido:</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.ui" line="106"/>
        <source>Skip the data checking stage and start seeding immediately</source>
        <translation>Saltarse la fase de control de datos y empezar a sembrar de inmediato</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.ui" line="116"/>
        <source>Import</source>
        <translation>Importar</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.cpp" line="70"/>
        <source>Torrent file to import</source>
        <translation>Archivo Torrent para importar</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.cpp" line="70"/>
        <source>Torrent files (*.torrent)</source>
        <translation>Archivos Torrent (*.torrent)</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.cpp" line="95"/>
        <source>%1 Files</source>
        <comment>%1 is a file extension (e.g. PDF)</comment>
        <translation>%1 Archivos</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.cpp" line="97"/>
        <source>Please provide the location of %1</source>
        <comment>%1 is a file name</comment>
        <translation>Por favor, indique la ubicación del %1</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.cpp" line="134"/>
        <source>Please point to the location of the torrent: %1</source>
        <translation>Por favor, elija la ubicación del torrent: %1</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.cpp" line="242"/>
        <source>Invalid torrent file</source>
        <translation>Archivo torrent no válido</translation>
    </message>
    <message>
        <location filename="../torrentimportdlg.cpp" line="242"/>
        <source>This is not a valid torrent file.</source>
        <translation>Esto no es un archivo torrent válido.</translation>
    </message>
</context>
<context>
    <name>TorrentModel</name>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="239"/>
        <source>Name</source>
        <comment>i.e: torrent name</comment>
        <translation>Nombre</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="241"/>
        <source>Size</source>
        <comment>i.e: torrent size</comment>
        <translation>Tamaño</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="242"/>
        <source>Done</source>
        <comment>% Done</comment>
        <translation>Progreso</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="243"/>
        <source>Status</source>
        <comment>Torrent status (e.g. downloading, seeding, paused)</comment>
        <translation>Estado</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="244"/>
        <source>Seeds</source>
        <comment>i.e. full sources (often untranslated)</comment>
        <translation>Semillas</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="245"/>
        <source>Peers</source>
        <comment>i.e. partial sources (often untranslated)</comment>
        <translation>Pares</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="246"/>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Vel. Bajada</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="247"/>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Vel. Subida</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="248"/>
        <source>Ratio</source>
        <comment>Share ratio</comment>
        <translation>Ratio</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="249"/>
        <source>ETA</source>
        <comment>i.e: Estimated Time of Arrival / Time left</comment>
        <translation>Tiemp aprox</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="250"/>
        <source>Label</source>
        <translation>Etiqueta</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="251"/>
        <source>Added On</source>
        <comment>Torrent was added to transfer list on 01/01/2010 08:00</comment>
        <translation>Añadido el</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="252"/>
        <source>Completed On</source>
        <comment>Torrent was completed on 01/01/2010 08:00</comment>
        <translation>Completado el</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="253"/>
        <source>Tracker</source>
        <translation>Tracker</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="254"/>
        <source>Down Limit</source>
        <comment>i.e: Download limit</comment>
        <translation>Límite Bajada</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="255"/>
        <source>Up Limit</source>
        <comment>i.e: Upload limit</comment>
        <translation>Límite Subida</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="256"/>
        <source>Amount downloaded</source>
        <comment>Amount of data downloaded (e.g. in MB)</comment>
        <translation>Cantidad descargada</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="257"/>
        <source>Amount left</source>
        <comment>Amount of data left to download (e.g. in MB)</comment>
        <translation>Cantidad que falta</translation>
    </message>
    <message>
        <location filename="../qtlibtorrent/torrentmodel.cpp" line="258"/>
        <source>Time Active</source>
        <comment>Time (duration) the torrent is active (not paused)</comment>
        <translation>Tiempo activo</translation>
    </message>
</context>
<context>
    <name>TrackerList</name>
    <message>
        <location filename="../properties/trackerlist.cpp" line="61"/>
        <source>URL</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="62"/>
        <source>Status</source>
        <translation>Estado</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="63"/>
        <source>Peers</source>
        <translation>Pares</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="64"/>
        <source>Message</source>
        <translation>Mensaje</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="66"/>
        <source>[DHT]</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="69"/>
        <source>[PeX]</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="72"/>
        <source>[LSD]</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="209"/>
        <location filename="../properties/trackerlist.cpp" line="219"/>
        <location filename="../properties/trackerlist.cpp" line="225"/>
        <location filename="../properties/trackerlist.cpp" line="256"/>
        <location filename="../properties/trackerlist.cpp" line="274"/>
        <source>Working</source>
        <translation>Trabajando</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="211"/>
        <location filename="../properties/trackerlist.cpp" line="221"/>
        <location filename="../properties/trackerlist.cpp" line="227"/>
        <source>Disabled</source>
        <translation>Deshabilitado</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="215"/>
        <source>This torrent is private</source>
        <translation>Este torrent es privado</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="260"/>
        <source>Updating...</source>
        <translation>Actualizando...</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="264"/>
        <location filename="../properties/trackerlist.cpp" line="278"/>
        <source>Not working</source>
        <translation>Parado</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="267"/>
        <location filename="../properties/trackerlist.cpp" line="281"/>
        <source>Not contacted yet</source>
        <translation>Todavía sin conexión</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="349"/>
        <source>Add a new tracker...</source>
        <translation>Añadir nuevo tracker...</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="352"/>
        <source>Remove tracker</source>
        <translation>Eliminar tracker</translation>
    </message>
    <message>
        <location filename="../properties/trackerlist.cpp" line="355"/>
        <source>Force reannounce</source>
        <translation>Forzar Re-publicar</translation>
    </message>
</context>
<context>
    <name>TrackersAdditionDlg</name>
    <message>
        <location filename="../properties/trackersadditiondlg.ui" line="14"/>
        <source>Trackers addition dialog</source>
        <translation>Diálogo para añadir trackers</translation>
    </message>
    <message>
        <location filename="../properties/trackersadditiondlg.ui" line="20"/>
        <source>List of trackers to add (one per line):</source>
        <translation>Lista de trackers a añadir (uno por línea):</translation>
    </message>
    <message utf8="true">
        <location filename="../properties/trackersadditiondlg.ui" line="44"/>
        <source>µTorrent compatible list URL:</source>
        <translation>Lista de URL de μTorrent compatibles:</translation>
    </message>
    <message>
        <location filename="../properties/trackersadditiondlg.h" line="81"/>
        <source>I/O Error</source>
        <translation>Error de Entrada/Salida</translation>
    </message>
    <message>
        <location filename="../properties/trackersadditiondlg.h" line="81"/>
        <source>Error while trying to open the downloaded file.</source>
        <translation>Error al intentar abrir el archivo descargado.</translation>
    </message>
    <message>
        <location filename="../properties/trackersadditiondlg.h" line="123"/>
        <source>No change</source>
        <translation>Sin cambios</translation>
    </message>
    <message>
        <location filename="../properties/trackersadditiondlg.h" line="123"/>
        <source>No additional trackers were found.</source>
        <translation>No se encontró ningún Tracker.</translation>
    </message>
    <message>
        <location filename="../properties/trackersadditiondlg.h" line="132"/>
        <source>Download error</source>
        <translation>Error de descarga</translation>
    </message>
    <message>
        <location filename="../properties/trackersadditiondlg.h" line="132"/>
        <source>The trackers list could not be downloaded, reason: %1</source>
        <translation>La lista de Trackers no pudo ser descargada. Razón: %1</translation>
    </message>
</context>
<context>
    <name>TransferListDelegate</name>
    <message>
        <location filename="../transferlistdelegate.h" line="94"/>
        <source>Downloading</source>
        <translation>Descargando</translation>
    </message>
    <message>
        <location filename="../transferlistdelegate.h" line="98"/>
        <source>Paused</source>
        <translation>Pausar</translation>
    </message>
    <message>
        <location filename="../transferlistdelegate.h" line="102"/>
        <source>Queued</source>
        <comment>i.e. torrent is queued</comment>
        <translation>En cola</translation>
    </message>
    <message>
        <location filename="../transferlistdelegate.h" line="106"/>
        <source>Seeding</source>
        <comment>Torrent is complete and in upload-only mode</comment>
        <translation>Sembrando</translation>
    </message>
    <message>
        <location filename="../transferlistdelegate.h" line="109"/>
        <source>Stalled</source>
        <comment>Torrent is waiting for download to begin</comment>
        <translation>Detenida</translation>
    </message>
    <message>
        <location filename="../transferlistdelegate.h" line="113"/>
        <source>Checking</source>
        <comment>Torrent local data is being checked</comment>
        <translation>Verificando</translation>
    </message>
    <message>
        <location filename="../transferlistdelegate.h" line="127"/>
        <source>/s</source>
        <comment>/second (.i.e per second)</comment>
        <translation></translation>
    </message>
    <message>
        <location filename="../transferlistdelegate.h" line="136"/>
        <source>KiB/s</source>
        <comment>KiB/second (.i.e per second)</comment>
        <translation>KiB/s</translation>
    </message>
    <message>
        <location filename="../transferlistdelegate.h" line="146"/>
        <source>Seeded for %1</source>
        <comment>e.g. Seeded for 3m10s</comment>
        <translation>Sembrando %1</translation>
    </message>
</context>
<context>
    <name>TransferListFiltersWidget</name>
    <message>
        <location filename="../transferlistfilterswidget.h" line="205"/>
        <location filename="../transferlistfilterswidget.h" line="287"/>
        <source>All</source>
        <translation>Todos</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="208"/>
        <location filename="../transferlistfilterswidget.h" line="288"/>
        <source>Downloading</source>
        <translation>Descargando</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="211"/>
        <location filename="../transferlistfilterswidget.h" line="289"/>
        <source>Completed</source>
        <translation>Completados</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="214"/>
        <location filename="../transferlistfilterswidget.h" line="290"/>
        <source>Paused</source>
        <translation>Pausados</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="217"/>
        <location filename="../transferlistfilterswidget.h" line="291"/>
        <source>Active</source>
        <translation>Activos</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="220"/>
        <location filename="../transferlistfilterswidget.h" line="292"/>
        <source>Inactive</source>
        <translation>Inactivos</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="234"/>
        <location filename="../transferlistfilterswidget.h" line="469"/>
        <source>All labels</source>
        <translation>Etiquetados</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="237"/>
        <location filename="../transferlistfilterswidget.h" line="470"/>
        <source>Unlabeled</source>
        <translation>No Etiquetados</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="319"/>
        <source>Remove label</source>
        <translation>Eliminar Etiqueta</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="320"/>
        <source>Add label...</source>
        <translation>Añadir Etiqueta...</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="322"/>
        <source>Resume torrents</source>
        <translation>Reanudar torrents</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="323"/>
        <source>Pause torrents</source>
        <translation>Pausar torrents</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="324"/>
        <source>Delete torrents</source>
        <translation>Eliminar torrents</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="350"/>
        <source>New Label</source>
        <translation>Nueva Etiqueta</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="350"/>
        <source>Label:</source>
        <translation>Etiqueta:</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="355"/>
        <source>Invalid label name</source>
        <translation>Nombre de Etiqueta no válido</translation>
    </message>
    <message>
        <location filename="../transferlistfilterswidget.h" line="355"/>
        <source>Please don&apos;t use any special characters in the label name.</source>
        <translation>Por favor, no utilice caracteres especiales para el nombre de la Etiqueta.</translation>
    </message>
</context>
<context>
    <name>TransferListWidget</name>
    <message>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation type="obsolete">Vel. Bajada</translation>
    </message>
    <message>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation type="obsolete">Vel. Subida</translation>
    </message>
    <message>
        <source>ETA</source>
        <comment>i.e: Estimated Time of Arrival / Time left</comment>
        <translation type="obsolete">Tiemp aprox</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="524"/>
        <source>Column visibility</source>
        <translation>Visibilidad de columnas</translation>
    </message>
    <message>
        <source>Name</source>
        <comment>i.e: torrent name</comment>
        <translation type="obsolete">Nombre</translation>
    </message>
    <message>
        <source>Size</source>
        <comment>i.e: torrent size</comment>
        <translation type="obsolete">Tamaño</translation>
    </message>
    <message>
        <source>Done</source>
        <comment>% Done</comment>
        <translation type="obsolete">Progreso</translation>
    </message>
    <message>
        <source>Status</source>
        <comment>Torrent status (e.g. downloading, seeding, paused)</comment>
        <translation type="obsolete">Estado</translation>
    </message>
    <message>
        <source>Seeds</source>
        <comment>i.e. full sources (often untranslated)</comment>
        <translation type="obsolete">Semillas</translation>
    </message>
    <message>
        <source>Peers</source>
        <comment>i.e. partial sources (often untranslated)</comment>
        <translation type="obsolete">Pares</translation>
    </message>
    <message>
        <source>Ratio</source>
        <comment>Share ratio</comment>
        <translation type="obsolete">Ratio</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="766"/>
        <source>Label</source>
        <translation>Etiqueta</translation>
    </message>
    <message>
        <source>Added On</source>
        <comment>Torrent was added to transfer list on 01/01/2010 08:00</comment>
        <translation type="obsolete">Añadido el</translation>
    </message>
    <message>
        <source>Completed On</source>
        <comment>Torrent was completed on 01/01/2010 08:00</comment>
        <translation type="obsolete">Completado el</translation>
    </message>
    <message>
        <source>Tracker</source>
        <translation type="obsolete">Tracker</translation>
    </message>
    <message>
        <source>Down Limit</source>
        <comment>i.e: Download limit</comment>
        <translation type="obsolete">Límite Bajada</translation>
    </message>
    <message>
        <source>Up Limit</source>
        <comment>i.e: Upload limit</comment>
        <translation type="obsolete">Límite Subida</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="227"/>
        <source>Choose save path</source>
        <translation>Seleccione un directorio de destino</translation>
    </message>
    <message>
        <source>Save path creation error</source>
        <translation type="obsolete">Error en la creación del directorio de destino</translation>
    </message>
    <message>
        <source>Could not create the save path</source>
        <translation type="obsolete">No se pudo crear el directorio de destino</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="449"/>
        <source>Torrent Download Speed Limiting</source>
        <translation>Límite de velocidad de Bajada Torrent</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="482"/>
        <source>Torrent Upload Speed Limiting</source>
        <translation>Límite de velocidad de Subida Torrent</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="589"/>
        <source>New Label</source>
        <translation>Nueva Etiqueta</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="589"/>
        <source>Label:</source>
        <translation>Etiqueta:</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="594"/>
        <source>Invalid label name</source>
        <translation>Nombre de Etiqueta no válido</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="594"/>
        <source>Please don&apos;t use any special characters in the label name.</source>
        <translation>Por favor, no utilice caracteres especiales para el nombre de la Etiqueta.</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="610"/>
        <source>Rename</source>
        <translation>Renombrar</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="610"/>
        <source>New name:</source>
        <translation>Nuevo nombre:</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="644"/>
        <source>Resume</source>
        <comment>Resume/start the torrent</comment>
        <translation>Reanudar</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="646"/>
        <source>Pause</source>
        <comment>Pause the torrent</comment>
        <translation>Pausar</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="648"/>
        <source>Delete</source>
        <comment>Delete the torrent</comment>
        <translation>Borrar</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="650"/>
        <source>Preview file...</source>
        <translation>Previsualizar archivo...</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="652"/>
        <source>Limit share ratio...</source>
        <translation>Límite ratio compartición...</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="654"/>
        <source>Limit upload rate...</source>
        <translation>Tasa límite de Subida...</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="656"/>
        <source>Limit download rate...</source>
        <translation>Tasa límite de Bajada...</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="811"/>
        <source>Priority</source>
        <translation>Prioridad</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="658"/>
        <source>Open destination folder</source>
        <translation>Abrir carpeta de destino</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="660"/>
        <source>Move up</source>
        <comment>i.e. move up in the queue</comment>
        <translation>Mover arriba</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="662"/>
        <source>Move down</source>
        <comment>i.e. Move down in the queue</comment>
        <translation>Mover abajo</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="664"/>
        <source>Move to top</source>
        <comment>i.e. Move to top of the queue</comment>
        <translation>Mover al principio</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="666"/>
        <source>Move to bottom</source>
        <comment>i.e. Move to bottom of the queue</comment>
        <translation>Mover al final</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="668"/>
        <source>Set location...</source>
        <translation>Establecer destino...</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="670"/>
        <source>Force recheck</source>
        <translation>Forzar verificación de archivo</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="672"/>
        <source>Copy magnet link</source>
        <translation>Copiar magnet link</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="675"/>
        <source>Super seeding mode</source>
        <translation>Modo de SuperSiembra</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="679"/>
        <source>Rename...</source>
        <translation>Renombrar...</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="681"/>
        <source>Download in sequential order</source>
        <translation>Descargar en orden secuencial</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="684"/>
        <source>Download first and last piece first</source>
        <translation>Descargar primero, primeras y últimas partes</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="767"/>
        <source>New...</source>
        <comment>New label...</comment>
        <translation>Nueva...</translation>
    </message>
    <message>
        <location filename="../transferlistwidget.cpp" line="768"/>
        <source>Reset</source>
        <comment>Reset label</comment>
        <translation>Borrar todas las Etiquetas</translation>
    </message>
</context>
<context>
    <name>UpDownRatioDlg</name>
    <message>
        <location filename="../updownratiodlg.ui" line="14"/>
        <source>Torrent Upload/Download Ratio Limiting</source>
        <translation>Límites de ratio de Subida/Bajada</translation>
    </message>
    <message>
        <location filename="../updownratiodlg.ui" line="20"/>
        <source>Use global ratio limit</source>
        <translation>Usar límite de ratio global</translation>
    </message>
    <message>
        <location filename="../updownratiodlg.ui" line="23"/>
        <location filename="../updownratiodlg.ui" line="33"/>
        <location filename="../updownratiodlg.ui" line="45"/>
        <source>buttonGroup</source>
        <translation>buttonGroup</translation>
    </message>
    <message>
        <location filename="../updownratiodlg.ui" line="30"/>
        <source>Set no ratio limit</source>
        <translation>Sin límites de ratio</translation>
    </message>
    <message>
        <location filename="../updownratiodlg.ui" line="42"/>
        <source>Set ratio limit to</source>
        <translation>Límitar ratio a</translation>
    </message>
</context>
<context>
    <name>UsageDisplay</name>
    <message>
        <location filename="../main.cpp" line="73"/>
        <source>Usage:</source>
        <translation>Uso:</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="74"/>
        <source>displays program version</source>
        <translation>Muestra la versión del programa</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="76"/>
        <source>disable splash screen</source>
        <translation>Desactivar pantalla de inicio</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="78"/>
        <source>displays this help message</source>
        <translation>Muestra mensaje de ayuda</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="79"/>
        <source>changes the webui port (current: %1)</source>
        <translation>Cambiar el puerto de IU Web (actual:%1)</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="80"/>
        <source>[files or urls]: downloads the torrents passed by the user (optional)</source>
        <translation>[archivos o URLs] : la descarga de torrents necesita aprobación por el usuario (opcional)</translation>
    </message>
</context>
<context>
    <name>about</name>
    <message>
        <location filename="../about_imp.h" line="51"/>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <location filename="../about_imp.h" line="61"/>
        <source>I would like to thank the following people who volunteered to translate qBittorrent:</source>
        <translation>Quiero agradecer a las siguientes personas que voluntariamente tradujeron qBittorrent:</translation>
    </message>
    <message>
        <location filename="../about_imp.h" line="93"/>
        <source>Please contact me if you would like to translate qBittorrent into your own language.</source>
        <translation>Por favor contáctame si quieres traducir qBittorrent a tu propio idioma.</translation>
    </message>
</context>
<context>
    <name>addPeerDialog</name>
    <message>
        <location filename="../properties/peer.ui" line="20"/>
        <source>Peer addition</source>
        <translation>Incorporar Par</translation>
    </message>
    <message>
        <location filename="../properties/peer.ui" line="36"/>
        <source>IP</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../properties/peer.ui" line="59"/>
        <source>Port</source>
        <translation>Puerto</translation>
    </message>
</context>
<context>
    <name>addTorrentDialog</name>
    <message>
        <location filename="../torrentadditiondlg.ui" line="14"/>
        <source>Torrent addition dialog</source>
        <translation>Diálogo para añadir un torrent</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="42"/>
        <source>Save path:</source>
        <translation>Directorio de destino:</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="62"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="73"/>
        <source>Torrent size:</source>
        <translation>Tamaño torrent:</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="80"/>
        <location filename="../torrentadditiondlg.ui" line="101"/>
        <source>Unknown</source>
        <translation>Desconocido</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="94"/>
        <source>Free disk space:</source>
        <translation>Espacio libre en el Disco:</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="132"/>
        <source>Label:</source>
        <translation>Etiqueta:</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="184"/>
        <source>Torrent content:</source>
        <translation>Contenido del torrent:</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="237"/>
        <source>Select All</source>
        <translation>Seleccionar Todo</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="244"/>
        <source>Select None</source>
        <translation>Quitar Selecciones</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="266"/>
        <source>Download in sequential order (slower but good for previewing)</source>
        <translation>Descargar en orden secuencial (más lento, pero mejor para la vista previa)</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="273"/>
        <source>Skip file checking and start seeding immediately</source>
        <translation>Anular verificación y empezar a sembrar de inmediato</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="352"/>
        <location filename="../torrentadditiondlg.ui" line="355"/>
        <source>Do not download</source>
        <translation>No descargar</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="280"/>
        <source>Add to download list in paused state</source>
        <translation>Agregar a la lista de descargas en estado pausado</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="308"/>
        <source>Add</source>
        <translation>Agregar</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="315"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="337"/>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="342"/>
        <source>High</source>
        <translation>Alta</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.ui" line="347"/>
        <source>Maximum</source>
        <translation>Máxima</translation>
    </message>
</context>
<context>
    <name>authentication</name>
    <message>
        <location filename="../login.ui" line="16"/>
        <location filename="../login.ui" line="66"/>
        <source>Tracker authentication</source>
        <translation>Autentificación del Tracker</translation>
    </message>
    <message>
        <location filename="../login.ui" line="94"/>
        <source>Tracker:</source>
        <translation>Tracker:</translation>
    </message>
    <message>
        <location filename="../login.ui" line="127"/>
        <source>Login</source>
        <translation>Autentificarse</translation>
    </message>
    <message>
        <location filename="../login.ui" line="147"/>
        <source>Username:</source>
        <translation>Usuario:</translation>
    </message>
    <message>
        <location filename="../login.ui" line="176"/>
        <source>Password:</source>
        <translation>Contraseña:</translation>
    </message>
    <message>
        <location filename="../login.ui" line="219"/>
        <source>Log in</source>
        <translation>Conectar</translation>
    </message>
    <message>
        <location filename="../login.ui" line="226"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>confirmDeletionDlg</name>
    <message>
        <location filename="../confirmdeletiondlg.ui" line="20"/>
        <source>Deletion confirmation - qBittorrent</source>
        <translation>Confirmar borrado - qBittorrent</translation>
    </message>
    <message>
        <location filename="../confirmdeletiondlg.ui" line="47"/>
        <source>Are you sure you want to delete the selected torrents from the transfer list?</source>
        <translation>¿Seguro que quiere eliminar los torrents seleccionados de la lista de transferencias?</translation>
    </message>
    <message>
        <location filename="../confirmdeletiondlg.ui" line="67"/>
        <source>Remember choice</source>
        <translation>Recordar siempre esta elección</translation>
    </message>
    <message>
        <location filename="../confirmdeletiondlg.ui" line="94"/>
        <source>Also delete the files on the hard disk</source>
        <translation>Eliminar también el archivo del disco físico</translation>
    </message>
</context>
<context>
    <name>createTorrentDialog</name>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="291"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="14"/>
        <source>Torrent Creation Tool</source>
        <translation>Herramienta de Creación de Torrent</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="43"/>
        <source>Torrent file creation</source>
        <translation>Creación de un nuevo archivo Torrent</translation>
    </message>
    <message>
        <source>Announce urls (trackers):</source>
        <translation type="obsolete">Dirección Trackers:</translation>
    </message>
    <message>
        <source>Comment (optional):</source>
        <translation type="obsolete">Comentario (opcional):</translation>
    </message>
    <message>
        <source>Web seeds urls (optional):</source>
        <translation type="obsolete">Dirección Semillas (opcional):</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="53"/>
        <source>File or folder to add to the torrent:</source>
        <translation>Archivo o carpeta a agregar al torrent:</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="65"/>
        <source>Add file</source>
        <translation>Nuevo archivo</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="72"/>
        <source>Add folder</source>
        <translation>Nueva carpeta</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="83"/>
        <source>Tracker URLs:</source>
        <translation>Tracker URLs:</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="93"/>
        <source>Web seeds urls:</source>
        <translation>Semillas web urls:</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="103"/>
        <source>Comment:</source>
        <translation>Comentario:</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="150"/>
        <source>Piece size:</source>
        <translation>Tamaño de la pieza:</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="167"/>
        <source>32 KiB</source>
        <translation>32 KiB</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="172"/>
        <source>64 KiB</source>
        <translation>64 KiB</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="177"/>
        <source>128 KiB</source>
        <translation>128 KiB</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="182"/>
        <source>256 KiB</source>
        <translation>256 KiB</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="187"/>
        <source>512 KiB</source>
        <translation>512 KiB</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="192"/>
        <source>1 MiB</source>
        <translation>1 MiB</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="197"/>
        <source>2 MiB</source>
        <translation>2 MiB</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="202"/>
        <source>4 MiB</source>
        <translation>4 MiB</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="210"/>
        <source>Auto</source>
        <translation>Auto</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="235"/>
        <source>Private (won&apos;t be distributed on DHT network if enabled)</source>
        <translation>Privado (no se distribuirá por red DHT si se habilita)</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="242"/>
        <source>Start seeding after creation</source>
        <translation>Comenzar con la siembra después de la creación</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="284"/>
        <source>Create and save...</source>
        <translation>Crear y guardar...</translation>
    </message>
    <message>
        <location filename="../torrentcreator/createtorrent.ui" line="249"/>
        <source>Progress:</source>
        <translation>Progreso:</translation>
    </message>
</context>
<context>
    <name>createtorrent</name>
    <message>
        <source>Select destination torrent file</source>
        <translation type="obsolete">Seleccione un destino para el archivo torrent</translation>
    </message>
    <message>
        <source>Torrent Files</source>
        <translation type="obsolete">Archivos Torrent</translation>
    </message>
    <message>
        <source>No input path set</source>
        <translation type="obsolete">Sin ruta de destino establecida</translation>
    </message>
    <message>
        <source>Please type an input path first</source>
        <translation type="obsolete">Por favor escribe primero una ruta de entrada</translation>
    </message>
    <message>
        <source>Torrent creation</source>
        <translation type="obsolete">Crear nuevo Torrent</translation>
    </message>
    <message>
        <source>Torrent was created successfully:</source>
        <translation type="obsolete">El Torrent se creó con éxito:</translation>
    </message>
    <message>
        <source>Select a folder to add to the torrent</source>
        <translation type="obsolete">Seleccione otra carpeta para agregar al torrent</translation>
    </message>
    <message>
        <source>Please type an announce URL</source>
        <translation type="obsolete">Por favor escribe una Dirección URL</translation>
    </message>
    <message>
        <source>Torrent creation was unsuccessful, reason: %1</source>
        <translation type="obsolete">La creación del torrent no ha sido exitosa, razón: %1</translation>
    </message>
    <message>
        <source>Announce URL:</source>
        <comment>Tracker URL</comment>
        <translation type="obsolete">Dirección URL:</translation>
    </message>
    <message>
        <source>Please type a web seed url</source>
        <translation type="obsolete">Por favor escribe una Dirección Web para la Semilla</translation>
    </message>
    <message>
        <source>Web seed URL:</source>
        <translation type="obsolete">Dirección Web de la Semilla:</translation>
    </message>
    <message>
        <source>Select a file to add to the torrent</source>
        <translation type="obsolete">Seleccione otro archivo para agregar al torrent</translation>
    </message>
    <message>
        <source>Created torrent file is invalid. It won&apos;t be added to download list.</source>
        <translation type="obsolete">La creación del  archivo torrent no es válida. No se añadirá a la lista de descargas.</translation>
    </message>
</context>
<context>
    <name>downloadFromURL</name>
    <message>
        <source>Download Torrents from URLs</source>
        <translation type="obsolete">Descargar torrents de URLs</translation>
    </message>
    <message>
        <source>Only one URL per line</source>
        <translation type="obsolete">Solo una URL por línea</translation>
    </message>
    <message>
        <location filename="../downloadfromurldlg.ui" line="45"/>
        <source>Add torrent links</source>
        <translation>Añadir enlace torrent</translation>
    </message>
    <message>
        <location filename="../downloadfromurldlg.ui" line="78"/>
        <source>Both HTTP and Magnet links are supported</source>
        <translation>Los dos HTTP y Magnet links son soportados</translation>
    </message>
    <message>
        <location filename="../downloadfromurldlg.ui" line="106"/>
        <source>Download</source>
        <translation>Descargar</translation>
    </message>
    <message>
        <location filename="../downloadfromurldlg.ui" line="113"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../downloadfromurldlg.ui" line="14"/>
        <source>Download from urls</source>
        <translation>Descargar de urls</translation>
    </message>
    <message>
        <location filename="../downloadfromurldlg.h" line="78"/>
        <source>No URL entered</source>
        <translation>No se ha escrito ninguna URL</translation>
    </message>
    <message>
        <location filename="../downloadfromurldlg.h" line="78"/>
        <source>Please type at least one URL.</source>
        <translation>Por favor escribe al menos una URL.</translation>
    </message>
</context>
<context>
    <name>downloadThread</name>
    <message>
        <source>I/O Error</source>
        <translation type="obsolete">Error de Entrada/Salida</translation>
    </message>
    <message>
        <source>The remote host name was not found (invalid hostname)</source>
        <translation type="obsolete">El nombre de host remoto no se ha encontrado (nombre de host no válido)</translation>
    </message>
    <message>
        <source>The operation was canceled</source>
        <translation type="obsolete">La operación fue cancelada</translation>
    </message>
    <message>
        <source>The remote server closed the connection prematurely, before the entire reply was received and processed</source>
        <translation type="obsolete">El servidor remoto cerró la conexión antes de tiempo, antes que fuese recibido y procesado</translation>
    </message>
    <message>
        <source>The connection to the remote server timed out</source>
        <translation type="obsolete">Conexión con el servidor remoto fallida, Tiempo de espera agotado</translation>
    </message>
    <message>
        <source>SSL/TLS handshake failed</source>
        <translation type="obsolete">SSL/TLS handshake fallida</translation>
    </message>
    <message>
        <source>The remote server refused the connection</source>
        <translation type="obsolete">El servidor remoto rechazó la conexión</translation>
    </message>
    <message>
        <source>The connection to the proxy server was refused</source>
        <translation type="obsolete">La conexión con el servidor proxy fue rechazada</translation>
    </message>
    <message>
        <source>The proxy server closed the connection prematurely</source>
        <translation type="obsolete">Conexión cerrada antes de tiempo por el servidor proxy</translation>
    </message>
    <message>
        <source>The proxy host name was not found</source>
        <translation type="obsolete">El nombre de host del proxy no se ha encontrado</translation>
    </message>
    <message>
        <source>The connection to the proxy timed out or the proxy did not reply in time to the request sent</source>
        <translation type="obsolete">La conexión con el servidor proxy se ha agotado, o el proxy no respondió a tiempo a la solicitud enviada</translation>
    </message>
    <message>
        <source>The proxy requires authentication in order to honour the request but did not accept any credentials offered</source>
        <translation type="obsolete">El proxy requiere autenticación con el fin de atender la solicitud, pero no aceptó las credenciales que ofreció</translation>
    </message>
    <message>
        <source>The access to the remote content was denied (401)</source>
        <translation type="obsolete">El acceso al contenido remoto ha sido rechazado (401)</translation>
    </message>
    <message>
        <source>The operation requested on the remote content is not permitted</source>
        <translation type="obsolete">La operación solicitada en el contenido remoto no está permitida</translation>
    </message>
    <message>
        <source>The remote content was not found at the server (404)</source>
        <translation type="obsolete">El contenido remoto no se encuentra en el servidor (404)</translation>
    </message>
    <message>
        <source>The remote server requires authentication to serve the content but the credentials provided were not accepted</source>
        <translation type="obsolete">El servidor remoto requiere autenticación para servir el contenido, pero las credenciales proporcionadas no son correctas</translation>
    </message>
    <message>
        <source>The Network Access API cannot honor the request because the protocol is not known</source>
        <translation type="obsolete">Protocolo desconocido</translation>
    </message>
    <message>
        <source>The requested operation is invalid for this protocol</source>
        <translation type="obsolete">La operación solicitada no es válida para este protocolo</translation>
    </message>
    <message>
        <source>An unknown network-related error was detected</source>
        <translation type="obsolete">Error de Red desconocido</translation>
    </message>
    <message>
        <source>An unknown proxy-related error was detected</source>
        <translation type="obsolete">Error de Proxy desconocido</translation>
    </message>
    <message>
        <source>An unknown error related to the remote content was detected</source>
        <translation type="obsolete">Error desconocido en el servidor remoto</translation>
    </message>
    <message>
        <source>A breakdown in protocol was detected</source>
        <translation type="obsolete">Error de protocolo</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation type="obsolete">Error desconocido</translation>
    </message>
</context>
<context>
    <name>engineSelect</name>
    <message>
        <location filename="../searchengine/engineselect.ui" line="17"/>
        <source>Search plugins</source>
        <translation>Buscar plugins</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="30"/>
        <source>Installed search engines:</source>
        <translation>Motores de búsqueda instalados:</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="50"/>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="55"/>
        <source>Url</source>
        <translation>Url</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="60"/>
        <location filename="../searchengine/engineselect.ui" line="119"/>
        <source>Enabled</source>
        <translation>Habilitado</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="78"/>
        <source>You can get new search engine plugins here: &lt;a href=&quot;http://plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</source>
        <translation>Puedes obtener nuevos plugins de motores de búsqueda aquí &lt;a href=&quot;http:plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="93"/>
        <source>Install a new one</source>
        <translation>Instalar uno nuevo</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="100"/>
        <source>Check for updates</source>
        <translation>Buscar actualizaciones</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="107"/>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <source>Enable</source>
        <translation type="obsolete">Habilitar</translation>
    </message>
    <message>
        <source>Disable</source>
        <translation type="obsolete">Deshabilitar</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="124"/>
        <source>Uninstall</source>
        <translation>Desinstalar</translation>
    </message>
</context>
<context>
    <name>engineSelectDlg</name>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="174"/>
        <source>Uninstall warning</source>
        <translation>Alerta de desinstalación</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="174"/>
        <source>Some plugins could not be uninstalled because they are included in qBittorrent.
 Only the ones you added yourself can be uninstalled.
However, those plugins were disabled.</source>
        <translation>Algunos plugins no pudieron ser instalados porque están incluídos en qBittorrent.
Solamente los que has agregado por tí mismo pueden ser desinstalados.
De cualquier forma, esos plugins fueron deshabilitados.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="176"/>
        <source>Uninstall success</source>
        <translation>Desinstalación correcta</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="340"/>
        <source>Select search plugins</source>
        <translation>Seleccione los plugins de búsqueda</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="341"/>
        <source>qBittorrent search plugins</source>
        <translation>Plugins de búsqueda de qBittorrent</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="237"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="262"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="267"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="276"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="279"/>
        <source>Search plugin install</source>
        <translation>Instalar plugin de búsqueda</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="117"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="188"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="299"/>
        <source>Yes</source>
        <translation>Sí</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="120"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="154"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="191"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="302"/>
        <source>No</source>
        <translation>No</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="237"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="262"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="267"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="276"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="279"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="393"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="426"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="447"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="454"/>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="237"/>
        <source>A more recent version of %1 search engine plugin is already installed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>Una versión más reciente del plugin de motor de búsqueda %1 ya está instalada.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="393"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="426"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="447"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="454"/>
        <source>Search plugin update</source>
        <translation>Actualización del plugin de búsqueda</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="426"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="447"/>
        <source>Sorry, update server is temporarily unavailable.</source>
        <translation>Lo siento, el servidor de actualización esta temporalmente no disponible.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="393"/>
        <source>All your plugins are already up to date.</source>
        <translation>Todos tus plugins ya están actualizados.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="262"/>
        <source>%1 search engine plugin could not be updated, keeping old version.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>El plugin de motor de búsqueda %1 no pudo ser actualizado, se mantendrá la versión antigua.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="267"/>
        <source>%1 search engine plugin could not be installed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>El plugin de motor de búsqueda %1 no pudo ser instalado.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="176"/>
        <source>All selected plugins were uninstalled successfully</source>
        <translation>Todos los plugins seleccionados fueron instalados exitosamente</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="276"/>
        <source>%1 search engine plugin was successfully updated.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>El plugin de motor de búsqueda %1 fue actualizado exitosamente.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="279"/>
        <source>%1 search engine plugin was successfully installed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>El plugin de motor de búsqueda %1 fue instalado exitosamente.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="454"/>
        <source>Sorry, %1 search plugin install failed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>Lo lamento, la instalación del plugin de búsqueda %1 ha fallado.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="329"/>
        <source>New search engine plugin URL</source>
        <translation>URL del nuevo plugin de motor de búsqueda</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="330"/>
        <source>URL:</source>
        <translation>URL:</translation>
    </message>
</context>
<context>
    <name>misc</name>
    <message>
        <location filename="../misc.cpp" line="307"/>
        <source>qBittorrent will shutdown the computer now because all downloads are complete.</source>
        <translation>Todas las descargas se han completado, qBittorrent apagará el equipo ahora.</translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="85"/>
        <source>B</source>
        <comment>bytes</comment>
        <translation>B</translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="86"/>
        <source>KiB</source>
        <comment>kibibytes (1024 bytes)</comment>
        <translation>KiB</translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="87"/>
        <source>MiB</source>
        <comment>mebibytes (1024 kibibytes)</comment>
        <translation>MiB</translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="88"/>
        <source>GiB</source>
        <comment>gibibytes (1024 mibibytes)</comment>
        <translation>GiB</translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="89"/>
        <source>TiB</source>
        <comment>tebibytes (1024 gibibytes)</comment>
        <translation>TiB</translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="755"/>
        <source>%1h %2m</source>
        <comment>e.g: 3hours 5minutes</comment>
        <translation></translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="760"/>
        <source>%1d %2h</source>
        <comment>e.g: 2days 10hours</comment>
        <translation></translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="695"/>
        <location filename="../misc.cpp" line="700"/>
        <location filename="../misc.cpp" line="704"/>
        <location filename="../misc.cpp" line="707"/>
        <location filename="../misc.cpp" line="712"/>
        <location filename="../misc.cpp" line="715"/>
        <source>Unknown</source>
        <translation>Desconocido</translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="583"/>
        <source>Unknown</source>
        <comment>Unknown (size)</comment>
        <translation>Desconocido</translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="746"/>
        <source>&lt; 1m</source>
        <comment>&lt; 1 minute</comment>
        <translation>&lt;1m</translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="750"/>
        <source>%1m</source>
        <comment>e.g: 10minutes</comment>
        <translation>%1m</translation>
    </message>
</context>
<context>
    <name>options_imp</name>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1090"/>
        <location filename="../preferences/options_imp.cpp" line="1092"/>
        <location filename="../preferences/options_imp.cpp" line="1107"/>
        <location filename="../preferences/options_imp.cpp" line="1109"/>
        <source>Choose a save directory</source>
        <translation>Seleccione un directorio para guardar</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1012"/>
        <source>Add directory to scan</source>
        <translation>Añadir directorio para escanear</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1018"/>
        <source>Folder is already being watched.</source>
        <translation>Esta carpeta ya está en seleccionada para escanear.</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1021"/>
        <source>Folder does not exist.</source>
        <translation>La carpeta no existe.</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1024"/>
        <source>Folder is not readable.</source>
        <translation>La carpeta no es legible.</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1032"/>
        <source>Failure</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1032"/>
        <source>Failed to add Scan Folder &apos;%1&apos;: %2</source>
        <translation>No se puede escanear esta carpetas &apos;%1&apos;: %2</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1055"/>
        <location filename="../preferences/options_imp.cpp" line="1057"/>
        <source>Choose export directory</source>
        <translation>Selecciona directorio de exportación</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1072"/>
        <location filename="../preferences/options_imp.cpp" line="1074"/>
        <source>Choose an ip filter file</source>
        <translation>Seleccione un archivo de filtro de ip</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1072"/>
        <location filename="../preferences/options_imp.cpp" line="1074"/>
        <source>Filters</source>
        <translation>Filtros</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1152"/>
        <source>SSL Certificate (*.crt *.pem)</source>
        <translation>Certificado SSL (*.crt *.pem)</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1163"/>
        <source>SSL Key (*.key *.pem)</source>
        <translation>Clave SSL (*.key *.pem)</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1194"/>
        <source>Parsing error</source>
        <translation>Error de análisis</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1194"/>
        <source>Failed to parse the provided IP filter</source>
        <translation>No se ha podido analizar el filtrado IP</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1196"/>
        <source>Successfully refreshed</source>
        <translation>Actualizado con éxito</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1263"/>
        <source>Invalid key</source>
        <translation>Clave no válida</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1263"/>
        <source>This is not a valid SSL key.</source>
        <translation>Esta no es una clave SSL válida.</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1278"/>
        <source>Invalid certificate</source>
        <translation>Certificado no válido</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1278"/>
        <source>This is not a valid SSL certificate.</source>
        <translation>Este no es un Certificado SSL válido.</translation>
    </message>
    <message>
        <source>Succesfully refreshed</source>
        <translation type="obsolete">Actualizado con éxito</translation>
    </message>
    <message>
        <location filename="../preferences/options_imp.cpp" line="1196"/>
        <source>Successfuly parsed the provided IP filter: %1 rules were applied.</source>
        <comment>%1 is a number</comment>
        <translation>Análisis exitoso de filtrado IP: %1 normas aplicadas.</translation>
    </message>
</context>
<context>
    <name>pluginSourceDlg</name>
    <message>
        <location filename="../searchengine/pluginsource.ui" line="13"/>
        <source>Plugin source</source>
        <translation>Fuente del plugin</translation>
    </message>
    <message>
        <location filename="../searchengine/pluginsource.ui" line="26"/>
        <source>Search plugin source:</source>
        <translation>Fuente del plugin de búsqueda:</translation>
    </message>
    <message>
        <location filename="../searchengine/pluginsource.ui" line="35"/>
        <source>Local file</source>
        <translation>Archivo local</translation>
    </message>
    <message>
        <location filename="../searchengine/pluginsource.ui" line="42"/>
        <source>Web link</source>
        <translation>Vínculo web</translation>
    </message>
</context>
<context>
    <name>preview</name>
    <message>
        <location filename="../preview.ui" line="16"/>
        <source>Preview selection</source>
        <translation>Selección de vista previa</translation>
    </message>
    <message>
        <location filename="../preview.ui" line="51"/>
        <source>File preview</source>
        <translation>Vista previa de archivo</translation>
    </message>
    <message>
        <location filename="../preview.ui" line="67"/>
        <source>The following files support previewing, &lt;br&gt;please select one of them:</source>
        <translation>Los siguientes archivos soportan vista previa, &lt;br&gt;por favor seleccione uno de ellos:</translation>
    </message>
    <message>
        <location filename="../preview.ui" line="101"/>
        <source>Preview</source>
        <translation>Vista previa</translation>
    </message>
    <message>
        <location filename="../preview.ui" line="108"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>previewSelect</name>
    <message>
        <source>Preview impossible</source>
        <translation type="obsolete">Imposible vista previa</translation>
    </message>
    <message>
        <source>Sorry, we can&apos;t preview this file</source>
        <translation type="obsolete">Lo siento, no se puede realizar una vista previa de este archivo</translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="obsolete">Nombre</translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="obsolete">Tamaño</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation type="obsolete">Progreso</translation>
    </message>
</context>
<context>
    <name>search_engine</name>
    <message>
        <location filename="../searchengine/search.ui" line="14"/>
        <location filename="../searchengine/search.ui" line="44"/>
        <source>Search</source>
        <translation>Buscar</translation>
    </message>
    <message>
        <location filename="../searchengine/search.ui" line="67"/>
        <source>Status:</source>
        <translation>Estado:</translation>
    </message>
    <message>
        <location filename="../searchengine/search.ui" line="91"/>
        <source>Stopped</source>
        <translation>Detenido</translation>
    </message>
    <message>
        <location filename="../searchengine/search.ui" line="135"/>
        <source>Download</source>
        <translation>Descargar</translation>
    </message>
    <message>
        <location filename="../searchengine/search.ui" line="145"/>
        <source>Go to description page</source>
        <translation>Página de descripción</translation>
    </message>
    <message>
        <location filename="../searchengine/search.ui" line="165"/>
        <source>Search engines...</source>
        <translation>Motores de búsqueda...</translation>
    </message>
</context>
<context>
    <name>torrentAdditionDialog</name>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="241"/>
        <location filename="../torrentadditiondlg.cpp" line="244"/>
        <source>Unable to decode torrent file:</source>
        <translation>Imposible decodificar el archivo torrent:</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="516"/>
        <location filename="../torrentadditiondlg.cpp" line="531"/>
        <location filename="../torrentadditiondlg.cpp" line="533"/>
        <source>Choose save path</source>
        <translation>Elegir directorio de destino</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="199"/>
        <source>Unable to decode magnet link:</source>
        <translation>No se puede descodificar el enlace magnet:</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="205"/>
        <source>Magnet Link</source>
        <translation>Enlace magnet</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="337"/>
        <source>Rename...</source>
        <translation>Renombrar...</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="381"/>
        <source>Rename the file</source>
        <translation>Renombrar archivo</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="382"/>
        <source>New name:</source>
        <translation>Nuevo nombre:</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="386"/>
        <location filename="../torrentadditiondlg.cpp" line="416"/>
        <source>The file could not be renamed</source>
        <translation>No se puede cambiar el nombre de archivo</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="387"/>
        <source>This file name contains forbidden characters, please choose a different one.</source>
        <translation>Este nombre de archivo contiene caracteres prohibidos, por favor, elija uno otro.</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="417"/>
        <location filename="../torrentadditiondlg.cpp" line="451"/>
        <source>This name is already in use in this folder. Please use a different name.</source>
        <translation>Este nombre ya está en uso. Por favor, use un nombre diferente.</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="450"/>
        <source>The folder could not be renamed</source>
        <translation>No se puede cambiar el nombre de archivo</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="498"/>
        <source>(%1 left after torrent download)</source>
        <comment>e.g. (100MiB left after torrent download)</comment>
        <translation>(%1 disponible después de descargar el torrent)</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="501"/>
        <source>(%1 more are required to download)</source>
        <comment>e.g. (100MiB more are required to download)</comment>
        <translation>(Se necesitan más %1)</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="586"/>
        <source>Empty save path</source>
        <translation>Ruta de destino vacía</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="586"/>
        <source>Please enter a save path</source>
        <translation>Por favor introduzca un directorio de destino</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="665"/>
        <source>Save path creation error</source>
        <translation>Error en la creación del directorio de destino</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="665"/>
        <source>Could not create the save path</source>
        <translation>Imposible crear el directorio de destino</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="607"/>
        <source>Invalid label name</source>
        <translation>Nombre de Etiqueta no válido</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="607"/>
        <source>Please don&apos;t use any special characters in the label name.</source>
        <translation>Por favor, no utilice caracteres especiales para el nombre de la Etiqueta.</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="650"/>
        <source>Seeding mode error</source>
        <translation>Error en la Siembra</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="650"/>
        <source>You chose to skip file checking. However, local files do not seem to exist in the current destionation folder. Please disable this feature or update the save path.</source>
        <translation>Usted ha decidido ignorar la verificación de archivos. Sin embargo, los archivos locales no parecen existir en la carpeta destino actual. Por favor, desactive esta función o actualice la ruta de destino.</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="657"/>
        <source>Invalid file selection</source>
        <translation>Selección de archivo inválida</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="657"/>
        <source>You must select at least one file in the torrent</source>
        <translation>Debe seleccionar al menos un archivo torrent</translation>
    </message>
    <message>
        <location filename="../torrentadditiondlg.cpp" line="341"/>
        <source>Priority</source>
        <translation>Prioridad</translation>
    </message>
</context>
</TS>
